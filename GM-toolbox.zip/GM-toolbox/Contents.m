% GM_TOOLBOX v2.0
%
% BILINEAR_FORMS: estimates of values of bilinear forms for symmetric matrices
% EIGENVALUES:    computation of eigenvalues, symmetric and non-symmetric matrices
% ISOTROPIC:      computation of isotropic vectors
% LINEAR SYSTEMS: solvers for linear systems, symmetric and non-symmetric matrices
% MATRICES:       examples of matrices
% MATRICES FUNC:  functions for examples of matrices
% OPTIMIZATION:   minimization of functionals using Praxis
% PRECOND:        preconditioners
% QUADRATURE:     quadrature rules
% UTILITIES:      miscellaneous functions

