function [files,errmaxL,errl2L]=gm_interpol_L2norm(fcn,ipb,iprint);
%GM_INTERPOL_L2NORM Exemple of 2D interpolation using bivariate orthogonal
%polynomials

% Warning: the folder must contain only files related to L2 minimization!

% Input:
% fcn = function to be interpolated
% ipb = problem number
% iprint = 1, with printing
%
% Output:
% files = file names
% errmaxL = error max norm
% errl2L = error l2 norm

%
% Author G. Meurant
% August 2015
%

% You might have to change this
fpath = 'C:\D\new_mfiles\gm_toolbox\Interpolation\PointsL2\';

cd(fpath);

switch ipb
 
 case 1
  Prob = 'square';
  
 case 2
  Prob = 'disk';
  
 case 3
  Prob = 'Lshape';
  
 case 4
  Prob = 'triangle';
  
 case 5
  Prob = 'dbubble';
  
 case 6
  Prob = 'ellipse';
  
 otherwise
  error('gm_interpol_L2norm: Wrong value of ipb')
end

% get the file names
files = ls;
% remove . and ..
files = files(3:end,:);
nfiles = size(files,1);
nchar = size(files,2);

% decode the file names
Pb = zeros(nfiles,nchar);
Ipb = zeros(1,nfiles);
Degree = zeros(1,nfiles);
Mu = zeros(1,nfiles);
Type = zeros(nfiles,nchar);
for k = 1:nfiles
 [pbb,ipbb,degreeb,mub,typeb] = gm_decode_fname(files(k,:));
 Pb(k,1:size(pbb,2)) = pbb;
 Ipb(k) = ipbb;
 Degree(k) = degreeb;
 Mu(k) = mub;
 Type(k,1:size(typeb,2)) = typeb;
end

% find the files related to problem ipb
I = find(Ipb == ipb);
if isempty(I)
 error('gm_interpol_L2norm: There is no file related to problem ipb')
end
Pb = Pb(I,:);
Degree = Degree(I);
Mu = Mu(I);
Type = Type(I,:);
files = files(I,:);

% sort the values of mu
[muu,I] = sort(Mu,'ascend');
Pb = Pb(I,:);
Degree = Degree(I);
Mu = muu;
Type = Type(I,:);
files = files(I,:);

n = length(Degree);
errmaxL = zeros(n,1);
errl2L = zeros(n,1);

% Cartesian grid
npts = 100;
xx = linspace(-1,1,npts);
yy = linspace(-1,1,npts);
XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% find the different values of mu
ms = 1;
loop = 1;
while loop == 1
 me = n;
 for k = 1:n
  if Mu(k) > Mu(ms)
   me = k - 1;
   break
  end
 end % for k
 
 % consider these values of mu
 for k = ms:me
  if iprint == 1
   mm = me - ms + 1;
   errmaxL2 = zeros(mm,1);
   errl2L2 = zeros(mm,1);
   errmaxLr = zeros(mm,1);
   errl2Lr = zeros(mm,1);
   errmaxLp = zeros(mm,1);
   errl2Lp = zeros(mm,1);
   deg = zeros(mm,1);
   kk = 1;
  end

  fn = [fpath files(k,:)];
  % read the points coordinates from the file
  [x,y] = gm_read_points(fn);
  
  nx = length(x);
  w = ones(nx,1) / nx;
  
  % Interpolation on a cartesian grid using the orthogonal polynomials
  % with the discrete inner product defined by x, y, w
 [Psinp,diff,errmax,errl2] = gm_comp_interpolant_OPHL(fcn,x,y,w,ipb,XY);
 errmaxL(k) = errmax;
 errl2L(k) = errl2;
 end % for k
 
 % sort by degree
 J = [ms:me];
 [d,I] = sort(Degree(ms:me),'ascend');
 I = J(I);
 Degree(ms:me) = Degree(I);
 Mu(ms:me) = Mu(I);
 Type(ms:me,:) = Type(I,:);
 files(ms:me,:) = files(I,:);
 errmaxL(ms:me) = errmaxL(I);
 errl2L(ms:me) = errl2L(I);
 
 if iprint == 1
  fprintf('\n\n %s, mu = %g  \n\n',Prob,Mu(ms))
 end
 
 % for a given value of mu, separate the degrees
 ds = ms;
 loop2 = 1;
 iloop = 0;
 while loop2 == 1
  iloop = iloop + 1;
  de = me;
  for k = ms:me
   if Degree(k) > Degree(ds)
    de = k - 1;
    break
   end
  end % for k
  
  % sort the file types (maximum = 3 files) for a given degree
  it = zeros(3,1);
  j = 1;
  for k = ds:de
   if Type(k,1) == 108
    % L2
    it(j) = k;
    j = j + 1;
    break
   end
  end
  for k = ds:de
   if Type(k,1) == 114
    % ref
    it(j) = k;
    j = j + 1;
    break
   end
  end
  for k = ds:de
   if Type(k,1) == 49
    % 1p
    it(j) = k;
    j = j + 1;
    break
   end
  end
  j = j - 1;
  
  errmaxL(ds:de) = errmaxL(it(1:j));
  errl2L(ds:de) = errl2L(it(1:j));
  files(ds:de,:) = files(it(1:j),:);
  Type(ds:de,:) = Type(it(1:j),:);
  
  if iprint == 1
   deg(kk) = Degree(ds);
   if j == 1
    if Type(ds,1) == 108
     errmaxL2(kk) = errmaxL(ds);
     errl2L2(kk) = errl2L(ds);
    elseif Type(ds,1) == 114
     errmaxLr(kk) = errmaxL(ds);
     errl2Lr(kk) = errl2L(ds);
    elseif Type(ds,1) == 49
     errmaxLp(kk) = errmaxL(ds);
     errl2Lp(kk) = errl2L(ds);
    end
    kk = kk + 1;
   elseif j == 2
    if Type(ds,1) == 108
     errmaxL2(kk) = errmaxL(ds);
     errl2L2(kk) = errl2L(ds);
     if Type(ds,1) == 114
      errmaxLr(kk) = errmaxL(ds+1);
      errl2Lr(kk) = errl2L(ds+1);
     else
      errmaxLp(kk) = errmaxL(ds+1);
      errl2Lp(kk) = errl2L(ds+1);
     end
    else
     errmaxLr(kk) = errmaxL(ds);
     errl2Lr(kk) = errl2L(ds);
     errmaxLp(kk) = errmaxL(ds+1);
     errl2Lp(kk) = errl2L(ds+1);
    end
    kk = kk + 1;
   elseif j == 3
    errmaxL2(kk) = errmaxL(ds);
    errl2L2(kk) = errl2L(ds);
    errmaxLr(kk) = errmaxL(ds+1);
    errl2Lr(kk) = errl2L(ds+1);
    errmaxLp(kk) = errmaxL(ds+2);
    errl2Lp(kk) = errl2L(ds+2);
    kk = kk + 1;
   end
  end % if iprint
  
  if iprint == 1
   for k = ds:de
    fprintf(' degree = %d, file = %s  errmax = %g \n',Degree(k),Type(k,:),errmaxL(k))
    fprintf('                           errl2  = %g \n',errl2L(k))
   end % for k
   fprintf(' \n')
  end % if
  
  ds = de + 1;
  if ds > me
   loop2 = 0;
  end

 end % while loop2
 
 if iprint == 1
  kk = kk - 1;
  figure
  semilogy(deg(1:kk),errmaxL2(1:kk),'b-*')
  hold on
  semilogy(deg(1:kk),errmaxLr(1:kk),'r-o')
  semilogy(deg(1:kk),errmaxLp(1:kk),'g->')
  legend('L2','ref','1p','Location','NorthEast')
  title(['Error max ' Prob ' mu = ' num2str(Mu(ms))])
  drawnow
    figure
  semilogy(deg(1:kk),errl2L2(1:kk),'b-*')
  hold on
  semilogy(deg(1:kk),errl2Lr(1:kk),'r-o')
  semilogy(deg(1:kk),errl2Lp(1:kk),'g->')
  legend('L2','ref','1p','Location','NorthEast')
  title(['Error l2 ' Prob ' mu = ' num2str(Mu(ms))])
  drawnow
 end
 
 ms = me + 1;
 if ms > n
  loop = 0;
 end
end % while







