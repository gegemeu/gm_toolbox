% EXAMPLES
%
% Files
%   gm_ex_interpol     - Exemple of 2D interpolation
%   gm_Ex_ratinterp    - Examples of rational interpolation with gm_TT
%   gm_interpol_L2norm - Exemple of 2D interpolation using bivariate orthogonal polynomials
