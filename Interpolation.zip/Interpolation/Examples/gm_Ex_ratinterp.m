% Examples of rational interpolation with gm_TT

% number of interpolation points
npts = 10;

% interpolation points
x = gm_cheb_max(-pi,pi,npts);

% function values
f = sin(x);

% test points
t = linspace(-pi,pi,100);

% values at test points
ft = sin(t);

% rational interpolation
b = gm_TT(x,f);

% interpolant at test points
r = gm_comp_TT(t,x,f,b);

% error at test points
err = abs(ft - r);

fprintf('\n function sin(x), nb of interpolation points = %d, max error = %g \n\n',npts,max(err))

plot(t,ft)
hold on
plot(t,r,'r')
title('sin(x)')

figure

semilogy(t,err)
title('sin(x), error')


% Another example

% number of interpolation points
npts = 5;

% interpolation points
x = gm_cheb_max(-1,1,npts);

% function values
f = 1 ./ (1 + 25 * x.^2);

% test points
t = linspace(-1,1,100);

% values at test points
ft = 1 ./ (1 + 25 * t.^2);

% rational interpolation
b = gm_TT(x,f);

% interpolant at test points
r = gm_comp_TT(t,x,f,b);

% error at test points
err = abs(ft - r);

fprintf('\n function 1/(1+25 x^2), nb of interpolation points = %d, max error = %g \n\n',npts,max(err))

figure

plot(t,ft)
hold on
plot(t,r,'r')
title('1/(1+25 x^2)')
legend('function','interp','location','NorthWest')
hold off

figure

semilogy(t,err)
title('1/(1+25 x^2), error')


% Another example

% number of interpolation points
npts = 9;

% interpolation points
x = gm_cheb_max(-1,1,npts);

% function values
f = (x.^3 - 2 * x + 5) ./ (x.^4 + 25 * x.^2 + 1);

% test points
t = linspace(-1,1,100);

% values at test points
ft = (t.^3 - 2 * t + 5) ./ (t.^4 + 25 * t.^2 + 1);

% rational interpolation
b = gm_TT(x,f);

% interpolant at test points
r = gm_comp_TT(t,x,f,b);

% error at test points
err = abs(ft - r);

fprintf('\n function (x^3-2x+5) / (x^4+25x^2+1), nb of interpolation points = %d, max error = %g \n\n',npts,max(err))

figure

plot(t,ft)
hold on
plot(t,r,'r')
title('(x^3 - 2 x + 5) / (x^4 + 25 x^2 + 1)')
legend('function','interp','location','NorthWest')
hold off

figure

semilogy(t,err)
title('(x^3 - 2 x + 5) / (x^4 + 25 x^2 + 1), error')


% Another example

% number of interpolation points
npts = 25;

% interpolation points
x = gm_cheb_max(-1,1,npts);

% function values
f = 0.75 * exp(-(9 * x - 2).^2 / 4);

% test points
t = linspace(-1,1,100);

% values at test points
ft = 0.75 * exp(-(9 * t - 2).^2 / 4);

% rational interpolation
b = gm_TT(x,f);

% interpolant at test points
r = gm_comp_TT(t,x,f,b);

% error at test points
err = abs(ft - r);

fprintf('\n function 0.75 exp(-(9x - 2)^2 / 4), nb of interpolation points = %d, max error = %g \n\n',npts,max(err))

figure

plot(t,ft)
hold on
plot(t,r,'r')
title('0.75 exp(-(9x - 2)^2 / 4)')
legend('function','interp','location','NorthWest')
hold off

figure

semilogy(t,err)
title('0.75 exp(-(9x - 2)^2 / 4), error')
