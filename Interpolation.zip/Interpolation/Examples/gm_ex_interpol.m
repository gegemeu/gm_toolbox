% Exemple of 2D interpolation

degree = 10;
% degree = 5;

fprintf('\n degree = %d \n',degree)

% Square
% ipb = 1;
% Disk
ipb = 2;
% L-shape region
% ipb = 3;
% triangle
% ipb = 4;
% Double bubble
% ipb = 5;
% Ellipse
% ipb = 6;

% Leja-like points
switch ipb
 
 case 1
  leja = gm_leja_square(degree);
  fprintf('\n Square \n\n')
  
 case 2
  leja = gm_leja_disk(degree);
  fprintf('\n Disk \n\n')
  
 case 3
  leja = gm_leja_Lshape(degree);
  fprintf('\n L-shape region \n\n')
  
 case 4
  leja = gm_leja_triangle(degree);
  fprintf('\n Triangle \n\n')
  
 case 5
  leja = gm_leja_dbubble(degree);
  fprintf('\n Double bubble \n\n')
  
 case 6
  leja = gm_leja_ellipse(degree,2,1);
  fprintf('\n Ellipse \n\n')
  
 otherwise
  error('gm_ex_interpol: Wrong value of ipb')
end

nw = size(leja,1);
% equal weights
w = ones(nw,1) / nw;

% We could have read a file instead of computing the points!

% l_2 optimal points starting from leja(;,1), leja(:,2)
% We do not use any refinement or correction
[x,y,maxL] = gm_min_praxis_L2norm(leja(:,1),leja(:,2),w,1e-3,ipb,1);

% fprintf('\n Lebesgue constant = %g \n',maxL)

% function to be interpolated
% fcn = @gm_cosxy;
fcn = @gm_cos5x5y;
% fcn = @gm_absxy;
% fcn = @gm_dist32;
% fcn = @gm_Franke;

% Interpolation at Leja points using the orthogonal polynomials
% with the discrete inner product defined by x, y, w
[Psinp,diff,errmax,errl2] = gm_comp_interpolant_OPHL(fcn,x,y,w,ipb,leja);

fprintf('\n Interpolation at Leja-like points: Err max = %g, Err l2 = %g \n',errmax,errl2)

plot(leja(:,1),leja(:,2),'ro')
hold on
plot(x,y,'b*')
title('Leja-like points: o, l2 optimal points: *')
hold off

% Cartesian grid
npts = 100;
xx = linspace(-1,1,npts);
if ipb == 6
 xx = linspace(-2,2,npts);
end
yy = linspace(-1,1,npts);
XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% Interpolation on a cartesian grid using the orthogonal polynomials
% with the discrete inner product defined by x, y, w
[Psinp,diff,errmax,errl2] = gm_comp_interpolant_OPHL(fcn,x,y,w,ipb,XY);

fprintf('\n Interpolation on a cartesian grid: Err max = %g, Err l2 = %g \n',errmax,errl2)

zmin = min(Psinp);
zmax = max(Psinp);

ldiff = log10(diff);
zmind = min(ldiff);
zmaxd = max(ldiff);

% reshape the vector to conform to the mesh
Psinp = reshape(Psinp,npts,npts)';
diff = reshape(diff,npts,npts)';

figure

%  surfl(xx,yy,Psinp);
shading interp
%  colormap jet
%  colormap hsv
%  colormap prism
%  colormap gray
%  colormap hot
%  colormap summer
%  colormap spring
%  colormap bone

% more traditional surface
surf(xx,yy,Psinp)

title('Interpolant ')
axis([-1 1 -1 1 zmin zmax]);
if ipb == 6
 axis([-2 2 -1 1 zmin zmax]);
end
xlabel('x');
ylabel('y');

figure

surf(xx,yy,log10(diff))

title('Error (log10)')
axis([-1 1 -1 1 zmind zmaxd]);
if ipb == 6
 axis([-2 2 -1 1 zmind zmaxd]);
end
xlabel('x');
ylabel('y');
