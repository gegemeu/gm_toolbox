
% POINTSL2
%
% Files containing sets of points for different degrees obtained with L2
% minimization

% gm_pointsL2_disk -sets of points with low Lebesgue constant for the disk
% obtained with L2 minimization and refinement
