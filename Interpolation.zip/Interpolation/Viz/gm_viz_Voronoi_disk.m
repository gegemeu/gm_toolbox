function CellArea=gm_viz_Voronoi_disk(x,y,toggleplot);
%GM_VIZ_VORONOI_DISK  Circle Bounded Voronoi Diagram
% This function compute the individual Voronoi cell area of point sets
% bounded in a unit circle

% Input:
%   x = M x 1 array of x-coordinates
%   y = M x 1 array of y-coordinates
%   toggleplot = 1 to turn on figures (may take longer time for large samples) 
%                0 to turn off figures;
%
% Output:
%   CellArea = M x 1 array of Voronoi cell area bounded in a unit circle

% from a code by
% Written by / send comments or suggestions to :
% Meng Sang, Ong  & Ye Chow, Kuang 
% Photonic, Semiconductor & Communication Research Group
% School of Engineering
% Monash University Sunway campus
% October 2010

if any(size(x) ~= size(y))
    error('gm_viz_Voronoi_disk: x,y dimensions are not consistent')
end

x = x(:); y = y(:); 

clear global x_VoronoiGlobal y_VoronoiGlobal
global x_VoronoiGlobal y_VoronoiGlobal

if toggleplot
    figure
end

x_VoronoiGlobal = x; 
y_VoronoiGlobal = y; 

% Voronoi tesselation using voronoin()
[V, C] = voronoin([x,y]);
[vx,vy] = voronoi(x,y);

% Force all voronoi vertices to be finite
[V,C] = gm_BoundVoronoin_UnitCircle(V, C, toggleplot);

% ---------------------------------------------------------------------

% Find boundary intersection points and each voronoi cell areas
NormV = realsqrt(sum(V.^2,2));
LenC  = length(C);
CellArea = zeros(LenC,1);
for index = 1 : LenC
    ptV = C{index};
    VSet = V(ptV,:);
    NormVSet = NormV(ptV);
    
    % =================================================================
    if toggleplot
        plot(cos(linspace(0,2*pi,100)),sin(linspace(0,2*pi,100)),'k-'); hold on
        plot(x,y,'*')
%         plot(x(index),y(index),'r*')
        plot(vx,vy,'b:')
        for jndex = 1 : length(ptV)
            if ptV(jndex) ~= 1
                plot(V(ptV(jndex),1),V(ptV(jndex),2),'gx');
            end
        end
        axis([-1.5 1.5 -1.5 1.5]);
        axis square;
%         set(gcf, 'Color', [1 1 1])
        set(gca,'FontSize', 14)
    end
    % =================================================================
    
    % Identify the vertex farthest from the origin to be the first scanning vertex
    if max(NormVSet) < 1
        % All points inside unit circle, calculate area
        CellArea(index) = polyarea(V(ptV,1),V(ptV,2));
    else
        % Find points outside unit circle
        bOutside = NormVSet>1;
        bTestStartPoint = bOutside;
        bTestStartPoint = or(bTestStartPoint,circshift(bTestStartPoint,-1));
        ptComplimentaryPoint = mod(find(bTestStartPoint),length(VSet))+1;
        % Find intersection points (if exist)
        TestPoint1 = VSet(bTestStartPoint,:);
        TestPoint2 = VSet(ptComplimentaryPoint,:);
        if size(VSet,1) == 2
            TestPoint1(2,:) = [];
            TestPoint2(2,:) = [];
        end
        
        % =============================================================
%         if toggleplot
%             plot([TestPoint1(:,1),TestPoint2(:,1)]',[TestPoint1(:,2),TestPoint2(:,2)]','c:')
%         end
        % =============================================================
        
        Norm1 = NormVSet(bTestStartPoint);
        Norm2 = NormVSet(ptComplimentaryPoint);
        if size(VSet,1) == 2
            Norm1(2,:) = [];
            Norm2(2,:) = [];
        end
        
        bOneInOneOut= xor(Norm1>1,Norm2>1);
        if any(bOneInOneOut)
            [xc1, yc1]  = gm_BoundaryIntersect_UnitCircle(TestPoint1(bOneInOneOut,:),TestPoint2(bOneInOneOut,:),1);
        else
            xc1 = [];
            yc1 = [];
        end
        bTwoOut     = and(Norm1>1,Norm2>1);
        if any(bTwoOut)
            [xc2, yc2]  = gm_BoundaryIntersect_UnitCircle(TestPoint1(bTwoOut,:),TestPoint2(bTwoOut,:),2);
            xc2 = reshape(xc2,numel(xc2),1);
            yc2 = reshape(yc2,numel(yc2),1);
            xc2(isnan(xc2)) = [];
            yc2(isnan(yc2)) = [];
        else
            xc2 = [];
            yc2 = [];
        end
        
        % =============================================================
        if toggleplot
            if ~isempty(xc1)
                plot(xc1,yc1,'mx');
            end
            if ~isempty(xc2)
                plot(xc2,yc2,'mx');
            end
        end
        % =============================================================
        
        % Calculate call area
        CellArea(index) = CalcArea_UnitCircle(VSet(NormVSet<=1,:), [xc1,yc1], [xc2,yc2], index);
    end
    
    % =================================================================
    if toggleplot
        hold off
        % pause(0.8)
    end
    % =================================================================
    
end

clear global x_VoronoiGlobal y_VoronoiGlobal
