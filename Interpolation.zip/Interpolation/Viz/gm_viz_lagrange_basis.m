function [Psinp,Psixy]=gm_viz_lagrange_basis(Hx,Hy,rowxy,V,Beta,x,y,w,npts,ipb);
%GM_VIZ_LAGRANGE_BASIS visualization of Lagrange basis functions
% for bivariate orthogonal polynomials

% Input:
% Hx, Hy, rowxy = matrices from gm_bivar_orthpol
% x, y = points defining the discrete inner product
% w = weights (sum(w) =1)
% npts = number of vizualization points in one direction
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Psinp = values of the Lagrange polynomial at test points
% Psixy = values at points (x,y)

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

global iprob

% set the global variable for gm_indic_func
iprob = ipb;

Psinp = 0; 
Psixy = 0;
% test points, linear = 1, Cheb max = 2
testp = 2;

% set up the mesh on a rectangle including the domain

switch ipb
 
 case 1
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 2
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 3
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  xmin = 0; ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_viz_lagrange_basis: Wrong value of ipb')
end % switch

% enlarge a bit the rectangle
fmin = 0.99;
fmax = 1.01;

rect = 1;
if rect == 1
 fmin = 1; fmax = 1;
end % if rect

if xmin > 0
 xmin = fmin * xmin;
else
 xmin = fmax * xmin;
end
if xmax > 0
 xmax = fmax * xmax;
else
 xmax = fmin * xmax;
end
if ymin > 0
 ymin = fmin * ymin;
else
 ymin = fmax * ymin;
end
if ymax > 0
 ymax = fmax * ymax;
else
 ymax = fmin * ymax;
end

% mesh in x and y
switch testp
 
 case 1
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_viz_lagrange_basis: testp must be 1 or 2')
end % switch

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% values at the inner product points 
[Phi,P] = gm_val_house(V,Beta,w);

% coefficients of the expansion
alp = Phi' * diag(w);

n = size(Hx,1);

% compute the values of the polynomials
Psi = gm_eval_orthpol(XY,1,Hx,Hy,rowxy,n);

% Psixy = gm_eval_orthpol([x y],1,Hx,Hy,rowxy,n);

nP = size(Psi,1);

npmax = size(Psi,2);

fprintf('\n The number of basis functions is %d \n\n',npmax)

viz = 1;

while viz ~= 0
 
 np = input('Number of the polynomial? ');
 
 if np == 0
  return
 end
 
 np = min(np,npmax);
 
 close
 
 sk = zeros(nP,1);
 for j = 1:nP
  for k = 1:n
   sk(j) = sk(j) + alp(k,np) * Psi(j,k);
  end % for k
 end % for j
 Psinp =  sk;
 
 npp = length(Psinp);
 for i = 1:npp
  if gm_indic_func([XY(i,1); XY(i,2)]) == 0
   % value outside the domain
   Psinp(i) = 0;
  end
 end
 
 sk = zeros(n,1);
 for j = 1:n
  for k = 1:n
   sk(j) = sk(j) + alp(k,np) * Phi(j,k);
  end % for k
 end % for j
 valxy =  sk;
 
 
 zmin = min(Psinp);
 zmax = max(Psinp);
 if zmin > 0
  zmin = fmin * zmin;
 else
  zmin = fmax * zmin;
 end
 if zmax > 0
  zmax = fmax * zmax;
 else
  zmax = fmin * zmax;
 end
 
 % reshape the vector to conform to the mesh
 Psinp = reshape(Psinp,npts,npts)';
 
 %  surfl(xx,yy,Psinp);
 shading interp
 %  colormap jet
 %  colormap hsv
 %  colormap prism
 %  colormap gray
 %  colormap hot
 %  colormap summer
 %  colormap spring
 %  colormap bone
 
 % more traditional surface
 surf(xx,yy,Psinp)
 
 title(['Polynomial ' num2str(np)])
 axis([xmin xmax ymin ymax zmin zmax]);
 xlabel('x');
 ylabel('y');
 
 hold on
 
 plot3(x,y,valxy,'y*');
 
 hold off
 
 pause;
 
end % while

