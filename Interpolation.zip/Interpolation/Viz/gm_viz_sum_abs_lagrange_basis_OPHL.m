function [Psinp,Psinp2]=gm_viz_sum_abs_lagrange_basis_OPHL(x,y,w,npts,ipb);
%GM_VIZ_SUM_ABS_LAGRANGE_BASIS_OPHL visualization of sums of Lagrange basis functions
% for bivariate orthogonal polynomials using Huhtanen-Larsen

% This works only for some examples (because of the definition of the
% enclosing rectangle)

% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% npts = number of vizualization points in one direction
% ipb = problem number
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Psinp = values of the Lagrange polynomial at test points
% Psixy = values at points (x,y)

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

% This is to communicate with gm_indic_func
global iprob

iprob = ipb;

Psinp = 0; Psixy = 0;

% choice of test points, linear = 1, Cheb max = 2
testp = 2;

% set up the mesh

% this is the only problem dependent part
if nargin == 4
 ipb = 1;
end

switch ipb
 
 case {1,2,3}
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  xmin = 0; ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_viz_abs_lagrange_basis_OPHL: Wrong value of ipb')
end % switch

if nargin == 4
 xmin = min(x); xmax = max(x);
 ymin = min(y); ymax = max(y);
end

% eventually enlarge a bit the rectangle
fmin = 0.99;
fmax = 1.01;

rect = 1;
if rect == 1
 fmin = 1; fmax = 1;
end % if rect

if xmin > 0
 xmin = fmin * xmin;
else
 xmin = fmax * xmin;
end
if xmax > 0
 xmax = fmax * xmax;
else
 xmax = fmin * xmax;
end
if ymin > 0
 ymin = fmin * ymin;
else
 ymin = fmax * ymin;
end
if ymax > 0
 ymax = fmax * ymax;
else
 ymax = fmin * ymax;
end

% mesh in x and y
switch testp
 
 case 1
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_viz_lagrange_basis_OPHL: testp must be 1 or 2')
end % switch

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% values at the inner product points 
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);
[Phi,A,xy] = gm_OPHL(d,x,y,w);

Psixy = Phi;

% coefficients of the expansion
alp = Phi' * diag(w);

% compute the values of the polynomials at test points
Psi = gm_OPHL_eval(d,XY(:,1),XY(:,2),w,A,1);

nP = size(Psi,1);

npmax = size(Psi,2);

fprintf('\n The number of basis functions is %d \n\n',npmax)

viz = 1;

while viz ~= 0
 
 np = input('Number of the first polynomial? ');
 
 np = min(np,npmax);
 
 if np == 0
  return
 end
 
 np2 = input('Number of the second polynomial? ');
 
 np2 = min(np2,npmax);
 
 close
 
 sk = zeros(nP,1);
 for j = 1:nP
  for k = 1:n
   sk(j) = sk(j) + alp(k,np) * Psi(j,k);
  end % for k
 end % for j
 Psinp =  abs(sk);
 
 sk2 = zeros(nP,1);
 for j = 1:nP
  for k = 1:n
   sk2(j) = sk2(j) + alp(k,np2) * Psi(j,k);
  end % for k
 end % for j
 Psinp2 =  abs(sk2);

 for i = 1:nP
  if gm_indic_func([XY(i,1); XY(i,2)]) == 0
   Psinp(i) = 0;
   Psinp2(i) = 0;
  end % if
 end % for i
 
 zmin = min(Psinp + Psinp2);
 zmax = max(Psinp + Psinp2);
 if zmin > 0
  zmin = fmin * zmin;
 else
  zmin = fmax * zmin;
 end
 if zmax > 0
  zmax = fmax * zmax;
 else
  zmax = fmin * zmax;
 end
 
 % reshape the vector to conform to the mesh
 Psinp = reshape(Psinp,npts,npts)';
 Psinp2 = reshape(Psinp2,npts,npts)';
 
 %  surfl(xx,yy,Psinp);
 shading interp
 % change the color map?
 %  colormap jet
 %  colormap hsv
 %  colormap prism
 %  colormap gray
 %  colormap hot
 %  colormap summer
 %  colormap spring
 %  colormap bone
 
 % more traditional surface
 surf(xx,yy,Psinp+Psinp2)
 
 title(['Lagrange polynomials ' num2str(np) ' + ' num2str(np2)])
 axis([xmin xmax ymin ymax zmin zmax]);
 xlabel('x');
 ylabel('y');
 
 hold off
 
 pause
 
end % while

