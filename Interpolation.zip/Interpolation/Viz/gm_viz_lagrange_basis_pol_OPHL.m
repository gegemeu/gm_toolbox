function Psinp=gm_viz_lagrange_basis_pol_OPHL(x,y,w,npts,ipb);
%GM_VIZ_LAGRANGE_BASIS_POL_OPHL visualization of Lagrange basis functions
% for bivariate orthogonal polynomials using Huhtanen-Larsen

% This works only for some examples (because of the definition of the
% enclosing rectangle)

% Uses the representation of the polynomials with the monomials
% Much less reliable than gm_viz_lagrange_basis_OPHL
% Works only for a very small number of points (< 10)

% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% npts = number of vizualization points in one direction
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Psinp = values of the Lagrange polynomial at test points

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

% This is to communicate with gm_indic_func
global iprob

% set the global variable
iprob = ipb;

Psinp = 0; 
Psixy = 0;
% test points, linear = 1, Cheb max = 2
testp = 2;

switch ipb
 
 case 1
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 2
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 3
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  xmin = 0; ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_viz_lagrange_basis_pol_OPHL: Wrong value of ipb')
end % switch

% eventually enlarge a bit the rectangle
fmin = 0.99;
fmax = 1.01;

rect = 1;
if rect == 1
 fmin = 1; fmax = 1;
end % if rect

if xmin > 0
 xmin = fmin * xmin;
else
 xmin = fmax * xmin;
end
if xmax > 0
 xmax = fmax * xmax;
else
 xmax = fmin * xmax;
end
if ymin > 0
 ymin = fmin * ymin;
else
 ymin = fmax * ymin;
end
if ymax > 0
 ymax = fmax * ymax;
else
 ymax = fmin * ymax;
end

% mesh in x and y
switch testp
 
 case 1
  % linear
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  % Chebyshev
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_viz_lagrange_basis_pol_OPHL: testp must be 1 or 2')
end

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% values of the polynomials phi
n = length(x);
[Exp,pol] = gm_coeff_pol_OPHL(x,y,w,n);

[Q,A,xy] = gm_OPHL(2,x,y,w);

viz = 1;

while viz ~= 0
 
 np = input('Number of the polynomial? ');
 
 if np == 0
  return
 end
 
 close
 
 Psinp = gm_eval_Lagrange_basis_pol_OPHL(np,Q,Exp,pol,w,XY(:,1),XY(:,2));
 
 npp = length(Psinp);
 for i = 1:npp
  if gm_indic_func([XY(i,1); XY(i,2)]) == 0
   % value outside the domain
   Psinp(i) = 0;
  end % if
 end % for i
 
 zmin = min(Psinp);
 zmax = max(Psinp);
 if zmin > 0
  zmin = fmin * zmin;
 else
  zmin = fmax * zmin;
 end
 if zmax > 0
  zmax = fmax * zmax;
 else
  zmax = fmin * zmax;
 end
 
 % reshape the vector to conform to the mesh
 Psinp = reshape(Psinp,npts,npts)';
 
 %  surfl(xx,yy,Psinp);
 shading interp
 %  colormap jet
 %  colormap hsv
 %  colormap prism
 %  colormap gray
 %  colormap hot
 %  colormap summer
 %  colormap spring
 %  colormap bone
 
 % more traditional surface
 surf(xx,yy,Psinp)
 
 title(['Polynomial ' num2str(np)])
 axis([xmin xmax ymin ymax zmin zmax]);
 xlabel('x');
 ylabel('y');
 
 pause;
 
end % while

