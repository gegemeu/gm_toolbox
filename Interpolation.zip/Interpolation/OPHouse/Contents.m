
% OPHOUSE, BIVARIATE ORTHOGONAL POLYNOMIALS USING HOUSEHOLDER
%
% Files
%   gm_bivar_orthpol       - computes the recurrence matrices Hx and Hy for bivariate orthogonal polynomials using Householder
%   gm_bivarpol_all_points - computes the values of the bivariate polynomials
%   gm_coeff_bivar_orthpol - computes the recurrence matrices Hx and Hy for OPS using Householder
%   gm_eval_Lorthpol       - compute the lower triangular matrix L of the recurrence coefficients
%   gm_eval_orthpol        - evaluates the bivariate orthonormal polynomials at points in XY
%   gm_eval_pol            - evaluates the bivariate polynomial given by Exp and coeff
%   gm_eval_xyorthpol      - computes the lower triangular matrix of the x and y part of the recuurence for OPs
%   gm_val_house           - computes the product of the Householder reflections and values of the OPs
