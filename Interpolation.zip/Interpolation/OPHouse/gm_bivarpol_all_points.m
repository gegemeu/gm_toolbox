function chi=gm_bivarpol_all_points(L,x,y,val0,Hx,Hy,rowxy);
%GM_BIVARPOL_ALL_POINTS computes the values of the bivariate polynomials
% from the lower triangular matrices L and xym

% Input:
% L = lower triangular matrix of recurrence coefficients from gm_eval_Lorthpol
% (x,y) = coordinates of the points
% val0 = value of the first constant polynomial
% Hx, Hy, rowxy = matrices from gm_bivar_orthpol
%
% Output:
% chi: the columns of chi contains the values of the polynomials
%      chi(:,1) = constant polynomial

%
% Author G. Meurant
% April 2014
% Updated August 2015
%

np = length(x);
n = size(L,1);
chi = zeros(np,n);

% right hand side
rhs = val0 * eye(n,1);

for k = 1:np
 % for each point compute the matrix containing x and y
 xym = gm_eval_xyorthpol(Hx,Hy,rowxy,x(k),y(k));
 LL = L - xym;
 % solve the triangular system with a better precision than double
 z = gm_solve_triangle(LL,rhs);
 chi(k,:) = z';
end % for k

