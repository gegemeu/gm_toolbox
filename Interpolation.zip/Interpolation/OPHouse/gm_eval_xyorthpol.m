function xym=gm_eval_xyorthpol(Hx,Hy,rowxy,x,y);
%GM_EVAL_XYORTHPOL computes the lower triangular matrix of the x and y
% part of the recurrence for bivariate orthogonal polynomials

% Input:
% Hx and Hy = matrices computed from gm_bivar_orthpol
% rowxy = description of the pivots (from gm_bivar_orthpol)
% x, y = the coordinates of one point
%
% Output:
% xym = matrix of the multiplication terms by x and y
%      xym has only one non zero entry per row

%
% must be used together with gm_eval_Lorthpol
%

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

n = size(Hx,1);
xym = zeros(n,n);

for k = 1:n
 piv = rowxy(k,1);
 if piv > n
  break
 end % if piv
 % we can compute the values of Psi_piv
 if (rowxy(k,2) ~= 0) && (rowxy(k,3) == 0)
  % from Hx
  col = rowxy(k,2);
  xym(piv,col) = x;
 elseif (rowxy(k,2) == 0) && (rowxy(k,3) ~= 0)
  % from Hy
  col = rowxy(k,3);
  xym(piv,col) = y;
 else
  % both are non zero, choose the max piv
  colx = rowxy(k,2); 
  coly = rowxy(k,3);
  %   if abs(Hx(piv,colx)) > abs(Hy(piv,coly))
  %    xym(piv,colx) = x;
  %   else
  %    xym(piv,coly) = y;
  %   end % if abs
  % !!!!!!! caution-------- to be consistent with Huhtanen-Larsen, choose y
  xym(piv,coly) = y;
  
 end % if rowxy
end % for k

