function [Hx,Hy,V,Beta,rowxy,w,x,y]=gm_coeff_bivar_orthpol(w,x,y,ord);
%GM_COEFF_BIVAR_ORTHPOL computes the recurrence matrices Hx and Hy for
% bivariate orthogonal polynomials using Householder transformations

% This is to be used if the number of points in the inner product does not
% corresponds exactly to a given polynomial degree d (in which case the number of
% points is (d+1)(d+2)/2)
% we use Alvise Sommariva's trick and cheat by putting some weights to zero

% Input:
% w = weights (sum(w) = 1)
% x, y = points defining the inner product
% ord = ordering for the monomials ('lex', 'grlex' or 'grevlex')
%       'grlex' must give results similar to the Huhtanen-Larsen method
%
% Output:
% Hx, Hy = recurrence matrices
% V = Householder vectors
% Beta = the coefficients of the Householder reflections
% rowxy = description of the pivots

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

% w, x, y must be of the same length

nw = length(w);

% find the smallest degree corresponding to N >= nw points

maxdeg = 100;
for k = 1:maxdeg
 N = gm_numb_bivar_pol(k);
 if N >= nw
  d = k;
  break
 end % if N
end % for k

if N > nw
 % use additional zero weights
 w = [w; zeros(N-nw,1)];
 % and random points (may not be the best to do!)
 x = [x; rand(N-nw,1)];
 y = [y; rand(N-nw,1)];
end % if N

% now we have a number of points corresponding exactly to the degree

[Hx,Hy,V,Beta,rowxy] = gm_bivar_orthpol(w,x,y,ord);

