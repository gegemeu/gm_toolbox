function L=gm_eval_Lorthpol(Hx,Hy,rowxy);
%GM_EVAL_LORTHPOL compute the lower triangular matrix L of the recurrence coefficients

% This is only the part coming from Hx or Hy
% it must be used with gm_eval_xyorthpol to compute the values of the
% bivariate orthogonal polynomials
% (L - xym) Phi = Phi1 eye(n,1) gives the values of the polynomial
% at the point x,y given in xym

% Input:
% Hx and Hy = matrices computed from gm_bivar_orthpol
% rowxy = description of the pivots (from gm_bivar_orthpol)
%
% Output:
% L = lower triangular matrix

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

n = size(Hx,1);
L = zeros(n,n);
L(1,1) = 1;

for k = 1:n
 piv = rowxy(k,1);
 if piv > n
  break
 end % if piv
 % we can compute the values of Psi_piv
 if (rowxy(k,2) ~= 0) && (rowxy(k,3) == 0)
  % from Hx
  col = rowxy(k,2);
  L(piv,1:piv) = Hx(1:piv,col)';
 elseif (rowxy(k,2) == 0) && (rowxy(k,3) ~= 0)
  % from Hy
  col = rowxy(k,3);
  L(piv,1:piv) = Hy(1:piv,col)';
 else
  % both are non zero, choose the max piv
  colx = rowxy(k,2); 
  coly = rowxy(k,3);
  %   if abs(Hx(piv,colx)) > abs(Hy(piv,coly))
  %    L(piv,1:piv) = Hx(1:piv,colx)';
  %   else
  %    L(piv,1:piv) = Hy(1:piv,coly)';
  %   end % if abs
  % !!!!!!!  caution--------- to be consistent with Huhtanen-Larsen, choose y
  L(piv,1:piv) = Hy(1:piv,coly)';
  
 end % if rowxy
end % for k

