function [Hx,Hy,V,Beta,rowxy]=gm_bivar_orthpol(w,x,y,ord);
%GM_BIVAR_ORTHPOL computes the recurrence matrices Hx and Hy for bivariate orthogonal polynomials
% using Householder transformations

% Discrete inner product defined by the points (x,y) and the weights w

% See: M. Van Barel and A. Chesnokov, A method to compute recurrence relation
%        coefficients for bivariate orthogonal polynomials by unitary matrix transformations,
%        Numerical Algorithms, v 55 n 2-3 (2010), pp.~383--402

% Input:
% w = weights (sum(w) = 1)
% x, y = points defining the inner product
% ord = ordering for the monomials ('lex', 'grlex' or 'grevlex')
%       'grlex' must give results similar to the Huhtanen-Larsen method
%
% Output:
% Hx, Hy = recurrence matrices
% V = Householder vectors
% Beta = the coefficients of the Householder reflections
% rowxy = description of the pivots

%
% author G. Meurant
% April 2014
% Updated July 2015
%

w = w(:);
x = x(:);
y = y(:);
nw = length(w);
if (length(x) ~= nw) || (length(y) ~= nw)
 error('gm_bivar_orthpol: w, x and y must be of the same length')
end

n = nw;
% we can compute at most n polynomials
% the total degree has to be such that gm_cnk(2+d,2) = n

% we start with diagonal matrices containing the coordinates of the points
% they will be the eigenvalues of Hx and Hy

Hx = diag(x); 
Hy = diag(y);
V = zeros(n,n-1); 
Beta = zeros(1,n-1);

% total degree
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% get the monomials in the correct order
Exponent = gm_sort_mon(d,ord);

% row numbers of the pivots (we put zeros below them in the transformed matrices)
rowx = gm_row_col_mon(Exponent,1,n,d);
rowy = gm_row_col_mon(Exponent,2,n,d);

% find the ordering of the transformations and to which matrix they apply
% rowxy(i,:): (1 = row number of the pivot, 2 = column in Hx or 0,
%              3 = column in Hy or 0)
% 2 and 3 can be both non zero if we have the same pivot row in Hx and Hy

rowxy = zeros(n,3);
rowxx =rowx;
rowyy = rowy;

% rowxy depends only on the ordering of the monomials
j = 0;
for k = 1:n
 j = j + 1;
 [minx,ix] = min(rowxx);
 [miny,iy] = min(rowyy);
 if minx < miny
  % choose from Hx
  rowxy(j,1) = minx; 
  rowxy(j,2) = ix;
  rowxx(ix) = NaN;
 elseif minx > miny
  % choose from Hy
  rowxy(j,1) = miny; 
  rowxy(j,3) = iy;
  rowyy(iy) = NaN;
 else
  % same pivot in Hx and Hy
  rowxy(j,1) = minx; 
  rowxy(j,2) = ix; 
  rowxy(j,3) = iy;
  rowxx(ix) = NaN; 
  rowyy(iy) = NaN;
 end % if minx
 
end % for k

% start modifying Hx and Hy

% if pivot == n, skip the transformations except for the sign of the pivot

% the first reflection is to put zeros in w(2:n)

[v,beta,P] = gm_house_orthpol(sqrt(w),1);
V(:,1) = v; 
Beta(1) = beta;

% apply the reflection to Hx and Hy (on both sides)

vt = v';
Hx = Hx - beta * v * (vt * Hx);
Hx = Hx - beta *( Hx * v) * v';
Hy = Hy - beta * v * (vt * Hy);
Hy = Hy - beta * (Hy * v) * v';

% now we have filled Hx and Hy

% Chase the fill-ins in Hx and Hy
% by applying the reflections to put zeros below the pivots

for k = 1:n
 if rowxy(k,1) > n
  % we are at the bottom, nothing to do
  continue
 end % if rowxy
 
 if rowxy(k,1) == n
  if rowxy(k,3) == 0
   if Hx(n,rowxy(k,2)) < 0
    % change the sign of the pivot
    Hx(n,:) = -Hx(n,:);
    Hx(:,n) = -Hx(:,n);
    % apply the same transformation to the other matrix
    Hy(n,:) = -Hy(n,:);
    Hy(:,n) = -Hy(:,n);
    % store the transformation
    v = zeros(n,1); 
    v(n) = 1;
    beta = 2;
    V(:,k+1) = v; 
    Beta(k+1) = beta;
   end % if Hx
  end % if rowxy
  if rowxy(k,2) == 0
   if Hy(n,rowxy(k,3)) < 0
    % change the sign of the pivot
    Hy(n,:) = -Hy(n,:);
    Hy(:,n) = -Hy(:,n);
    % apply the same transformation to the other matrix
    Hx(n,:) = -Hx(n,:);
    Hx(:,n) = -Hx(:,n);
    % store the transformation
    v = zeros(n,1); 
    v(n) = 1;
    beta = 2;
    V(:,k+1) = v; 
    Beta(k+1) = beta;
   end % if Hx
  end % if rowxy
  continue
 end % if rowxy(k,1)
 
 colxx = 0; 
 colyy = 0;
 % compute the reflection from Hx or from Hy
 if rowxy(k,3) == 0
  % the pivot comes from Hx
  piv = rowxy(k,1);
  [v,beta,P] = gm_house_orthpol(Hx(:,rowxy(k,2)),piv);
  colxx = rowxy(k,2);
 elseif rowxy(k,2) == 0
  % the pivot comes from Hy
  piv = rowxy(k,1);
  [v,beta,P] = gm_house_orthpol(Hy(:,rowxy(k,3)),piv);
  colyy = rowxy(k,3);
 else
  % from both Hx and Hy (must choose one)
  % choose the one with the largest pivot (or largest norm???)
  % this is the only place where the values in Hx or Hy influence
  % the choice of the pivots
  colx = rowxy(k,2); 
  coly = rowxy(k,3);
  colxx = colx; 
  colyy = coly;
  piv = rowxy(k,1);
  %   if abs(Hx(piv,colx)) > abs(Hy(piv,coly))
  %    %   if norm(Hx(:,colx)) > norm(Hy(:,coly))
  %    [v,beta,P] = gm_house_orthpol(Hx(:,colx),piv);
  %   else
  %    [v,beta,P] = gm_house_orthpol(Hy(:,coly),piv);
  %   end % if abs
  % !!!!!!!!! caution-------------- to be consistent with Huhtanen-Larsen choose y
  [v,beta,P] = gm_house_orthpol(Hy(:,coly),piv);
 end % if rowxy
 
 % apply the reflection
 
 % find the method to apply the Householder reflections
 % depending on the size of Hx and the pivot to optimize the speed
 
 met = 1;
 if piv > (n / 2)
  if n > 500
   met = 7;
  else
   met = 4;
  end % if n
 end % if piv
 
 switch met
  
  case 1
   vt = v';
   Hx = Hx - beta * v * (vt * Hx);
   Hx = Hx - beta *( Hx * v) * v';
   Hy = Hy - beta * v * (vt * Hy);
   Hy = Hy - beta * (Hy * v) * v';
   
  case 2
   vt = v';
   Hxv = Hx(:,piv:n) * v(piv:n);
   Hx = Hx - beta * v * (Hxv');
   Hx = Hx - beta * (Hx(:,piv:n) * v(piv:n)) * vt;
   Hyv = Hy(:,piv:n) * v(piv:n);
   Hy = Hy - beta * v * (Hyv');
   Hy = Hy - beta * (Hy(:,piv:n) * v(piv:n)) * vt;
   
  case 4
   vp = v(piv:n);
   vpt = vp';
   Hxvp = Hx(:,piv:n) * vp;
   Hx(piv:n,:) = Hx(piv:n,:) - beta * vp * (Hxvp');
   Hx(:,piv:n) = Hx(:,piv:n) - beta * (Hx(:,piv:n) * vp) * vpt;
   Hyvp = Hy(:,piv:n) * vp;
   Hy(piv:n,:) = Hy(piv:n,:) - beta * vp * (Hyvp');
   Hy(:,piv:n) = Hy(:,piv:n) - beta * (Hy(:,piv:n) * vp) * vpt;
   
  case 7
   piv1 = piv - 1;
   vp = v(piv:n);
   vv = vp * vp';
   z = beta * Hx(:,piv:n) * vp;
   Z = z * v(piv:n)';
   alpha = beta * v(piv:n)' * z(piv:n);
   Hx(piv:n,1:piv1) = Hx(piv:n,1:piv1) - Z(1:piv1,:)';
   Hx(1:piv1,piv:n) = Hx(1:piv1,piv:n) - Z(1:piv1,:);
   Hx(piv:n,piv:n) = Hx(piv:n,piv:n) - (Z(piv:n,:) + Z(piv:n,:)');
   Hx(piv:n,piv:n) = Hx(piv:n,piv:n) + alpha * vv;
   z = beta * Hy(:,piv:n) * vp;
   Z = z * v(piv:n)';
   alpha = beta * v(piv:n)' * z(piv:n);
   Hy(piv:n,1:piv1) = Hy(piv:n,1:piv1) - Z(1:piv1,:)';
   Hy(1:piv1,piv:n) = Hy(1:piv1,piv:n) - Z(1:piv1,:);
   Hy(piv:n,piv:n) = Hy(piv:n,piv:n) - (Z(piv:n,:) + Z(piv:n,:)');
   Hy(piv:n,piv:n) = Hy(piv:n,piv:n) + alpha * vv;
   
 end % switch
 
 if colxx ~= 0
  Hx(piv+1:n,colxx) = 0;
  Hx(colxx,piv+1:n) = 0;
 end % if colxx
 
 if colyy ~= 0
  Hy(piv+1:n,colyy) = 0;
  Hy(colyy,piv+1:n) = 0;
 end % if colyy
 
 % store the reflection (if useful)
 V(:,k+1) = v; 
 Beta(k+1) = beta;
 
end % for k

% the matrices must be zero under the pivots (and symmetric) instead of
% 10 to the minus something

% for k = 1:n
%  piv = rowxy(k,1);
%  if piv == n
%   % do nothing
%   continue
%  end
%  colx = rowxy(k,2); coly = rowxy(k,3);
%  if colx ~= 0
%   % pivot in x
%   Hx(piv+1:n,colx) = 0; Hx(colx,piv+1:n) = 0;
%  end
%  if coly ~= 0
%   Hy(piv+1:n,coly) = 0; Hy(coly,piv+1:n) = 0;
%  end
% end % for k

% the matrices Hx and Hy must be symmetric
% make them exactly symmetric

Hx = (Hx + Hx') / 2;
Hy = (Hy + Hy') / 2;
















