function polval=gm_eval_pol(Exp,coeff,x,y);
%GM_EVAL_POL evaluates the bivariate polynomial given by Exp and coeff at points (x,y)

% This is not the most efficient way to evaluate the polynomial
% It is not really reliable for large degrees

% Input:
% Exp = exponents of monomials
% coeff = coefficients of the monomial
% x, y = coordinates of the points
%
% Output:
% polval = values of the polynomials

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

n = size(Exp,1);

x = x(:)'; y = y(:)';
nx = length(x);
value = zeros(n,nx);

for k = 1:n
 value(k,:) = coeff(k) .* x.^Exp(k,1) .* y.^Exp(k,2);
end % for k

polval = sum(value)';





