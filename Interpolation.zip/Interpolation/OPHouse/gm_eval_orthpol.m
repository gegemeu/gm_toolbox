function Psi=gm_eval_orthpol(XY,Psi1,Hx,Hy,rowxy,nmax);
%GM_EVAL_ORTHPOL evaluates the bivariate orthonormal polynomials at points in XY

% Input:
% XY = pairs (x_i,y_i)
% Psi1 = arbitrary value of the constant polynomial
% Hx, Hy = matrices computed from gm_bivar_orthpol (containing the
%          recurrence coefficients)
% rowxy = description of the pivots (from gm_bivar_orthpol)
% nmax = max number of polynomials to be computed
%       must be smaller than the number of points defining the discrete inner product
%
% Output:
% Psi = values of the polynomials at (x_i,y_i)
%       col 1: Psi_1 (constant), col 2: Psi_2, ... , col j: Psi_j

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

x = XY(:,1); 
y = XY(:,2);
nx = length(x);
n = size(Hx,1);
Psi = zeros(nx,nmax);
Psi(:,1) = Psi1;
if nmax > n
 disp('gm_eval_orthpol: The number of polynomials is too large')
 nmax = n;
end % if nmax

for k = 1:nmax-1
 piv = rowxy(k,1);
 % we can compute the values of Psi_piv
 if (rowxy(k,2) ~= 0) && (rowxy(k,3) == 0)
  % pivot from Hx
  col = rowxy(k,2);
  s = sum(Psi(:,1:piv-1) * Hx(1:piv-1,col),2);
  Psi(:,k+1) = (x .* Psi(:,col) - s) / Hx(piv,col);
  
 elseif (rowxy(k,2) == 0) && (rowxy(k,3) ~= 0)
  % pivot from Hy
  col = rowxy(k,3);
  s = sum(Psi(:,1:piv-1) * Hy(1:piv-1,col),2);
  Psi(:,k+1) = (y .* Psi(:,col) - s) / Hy(piv,col);
  
 else
  % both are non zero, choose the max piv
  colx = rowxy(k,2); coly = rowxy(k,3);
  if abs(Hx(piv,colx)) > abs(Hy(piv,coly))
   s = sum(Psi(:,1:piv-1) * Hx(1:piv-1,colx),2);
   Psi(:,k+1) = (x .* Psi(:,colx) - s) / Hx(piv,colx);
  else
   s = sum(Psi(:,1:piv-1) * Hy(1:piv-1,coly),2);
   Psi(:,k+1) = (y .* Psi(:,coly) - s) / Hy(piv,coly);
  end % if abs
  
 end % if rowxy
end % for k

