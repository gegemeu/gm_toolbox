function [Psi,P]=gm_val_house(V,Beta,w);
%GM_VAL_HOUSE computes the product of the Householder reflections
% and the values of the polynomials at the points defining the inner product

% Input:
% V, Beta = Householder reflections from gm_bivar_orthpol
% w = weights
%
% Output:
% Psi = values of the polynomials at points defining the inner product
% P = product of the reflections
%

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

[n,m] = size(V);
W12 = diag(1 ./ sqrt(w));
II = eye(n,n);

v = V(:,1);
P = II - Beta(1) * (v * v');
for k = 2:m
 v = V(:,k);
 P = (II - Beta(k) * (v * v')) * P;
end % for k

Psi = W12 * P';

