function [x,y,maxL]=gm_min_praxis_Lebesgue(x0,y0,w,epsi,ipb,iprint,nfev);
%GM_MIN_PRAXIS_LEBESGUE looks for the min of the Lebesgue constant iterating with gm_praxis

% Bivariate orthogonal polynomials computed with Huhtanen-Larsen
% Works also for some bounds of the Lebesgue function
% the solution is improved by restarting

% Input:
% x0,y0 = starting points
% w = weights
% epsi = stopping criteria
% ipb = number of the problem to be solved
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global Ifunc
global iprob diam wparm

% Ifunc = 1 (or 6) Lebesgue constant, = 2 bound, = 3 norm(inv(L),1),
% = 4 upper bound, = 5 norm(inv(L-Z),1)
% this is used in gm_Leb_fcn_HL
Ifunc = 6;

% defaults
if nargin <= 4
 ipb = 1;
end

if nargin <= 5
 iprint = 1;
end

if nargin <= 6
 nfev = 2000;
end

iprob = ipb;
if abs(sum(w) - 1) > 1e-14
 error('gm_min_praxis_Lebesgue: The sum of the weights must be equal to 1')
end
I = find(w <= 0);
if ~isempty(I)
 error('gm_min_praxis_Lebesgue: There are negative or zero weights')
end
wparm = w;

% set the approximate diameter
switch iprob
 
 case {1,2,3}
  diam = 2;
  
 case 4
  diam = 1;
  
 case 5
  diam = 14;
  
 case 6
  diam = 4;
  
 case 7
  diam = 4;
  
end % switch

n = length(x0);
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;

% the number of function evaluations (last parameter) may be too small

% rough estimate to find a good starting point
[xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_Leb_fcn_OPHL,50,nfev+500);

if iprint == 1
 fprintf(' Init, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_OPHL,50,nfev);

if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

% improve the solution by restarting (?)
kmax = 20;
prax_old = prax;

for k = 1:kmax
 if iprint == 1
  fprintf('--------iteration %d \n',k)
 end
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_OPHL,50,nfev);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  maxL = prax;
  x = xp(1:n)'; y = xp(n+1:n2)';
  
  if iprint == 1
   fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  
  if iprint == 1
   fprintf(' Lebesgue const = %0.5f \n',maxL)
  end
  return
 end % if prax
 
 if iprint == 1
  fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  prax_old = prax;
 end % if abs
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
end

x = xp(1:n)'; 
y = xp(n+1:n2)';

% this may not be enough to compute the L-constant reliably!!!!!!

% compute the Lebesgue const on a fine mesh
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);

if iprint == 1
 fprintf(' Lebesgue constant (fine mesh) = %0.5f \n',maxL)
end




