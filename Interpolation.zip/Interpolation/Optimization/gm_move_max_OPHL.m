function [x,y,Psinp,maxL,x_opt,y_opt]=gm_move_max_OPHL(x,y,x_opt,y_opt,maxL_old,viz);
%GM_MOVE_MAX_OPHL moves the maximum to the max of (an approximation of) the Lebesgue function

% We assume equal weights

% Input:
% (x,y) = current points
% (x_opt,y_opt) = best points so far
% maxL_old = best Lebesgue constant so far
% viz = 1 visualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = new Lebesgue constant
% (x_opt,y_opt) = new best points

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm 
global iprob

n = length(x);
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;
% equal weights
w = ones(n,1) / n;
ww = ones(n-1,1) / (n - 1);

% compute the values of the Lebesgue function at (x,y)
if viz ~= 0
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
end % if viz

% max of the Lebesgue function
[maxP,I] = max(Psidot);

 xx = XY(I(1),1); 
 yy = XY(I(1),2);

 % find the point i closest to the max
 dist = (x - xx).^2 + (y - yy).^2;
 [mindist,I] = sort(dist);
 i = I(1);

if maxL < maxL_old
 % keep the configuration
 maxL_old = maxL;
 x_opt = x;
 y_opt = y;
end % if maxL

% remove the point i
if i < n
 X = [x(1:i-1); x(i+1:n)];
 Y = [y(1:i-1); y(i+1:n)];
else
 X = x(1:n-1);
 Y = y(1:n-1);
end % if i
xparm = x;
yparm = y;
wparm = w;

% computation of the Lebesgue constant without the point
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(X,Y,ww,npts,iprob);
% max of the function
[minP,J] = max(Psidot);
% new point to add
xx = XY(J(1),1);
yy = XY(J(1),2);

x(i) = xx;
y(i) = yy;

% recompute the Lebesgue function
if viz ~= 0
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 fprintf(' New approximate Lebesgue constant =  %0.5f \n',maxL)
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
end % if viz

if maxL >= maxL_old
 % restore the optimal points
 x = x_opt;
 y = y_opt;
 maxL = maxL_old;
end % if maxL



