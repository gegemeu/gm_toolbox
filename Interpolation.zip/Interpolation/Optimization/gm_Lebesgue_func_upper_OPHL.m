function f=gm_Lebesgue_func_upper_OPHL(X);
%GM_LEBESGUE_FUNC_UPPER_OPHL computation of the upper bound of the Lebesgue function
% using the bivariate othogonal polynomials computed using Huhtanen-Larsen

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm
global nfunc
global Aparm alpparm

nfunc = nfunc + 1;

% keep the points inside the domain
ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end % if ind

x = X(1); 
y = X(2);

% total degree
n = length(xparm);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% get the matrices from gm_OPHL

A = Aparm;
alp = alpparm;
% compute the values of the polynomials
Psi = gm_OPHL_eval(d,x,y,wparm,A,1);

np = size(Psi,1);

Psinp = zeros(np,1);

for j = 1:n
 sk = zeros(np,1);
 
 % values of the j-th Lagrange polynomial
 for k = 1:n
  sk = sk + abs(alp(k,j)) * abs(Psi(:,k));
 end % for k
 
 Psinp = Psinp + sk;
 
end % for j

f = -Psinp(1);



