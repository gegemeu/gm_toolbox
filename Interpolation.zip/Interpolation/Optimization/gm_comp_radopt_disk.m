
% gm_comp_radopt_disk

% computation of points with radii optimization

vt = clock;
savefile = ['tempradopt-' date '-' num2str(vt(4)) num2str(vt(5)) num2str(ceil(vt(6)))];

pts = gm_disk_wam(500);

ideg = 0;
degmax = 8;
nmax = (degmax + 1) * (degmax + 2) / 2;

degree = zeros(1,degmax);
xf_best = zeros(nmax,degmax);
yf_best = zeros(nmax,degmax);
rad_best = zeros(nmax,degmax);
maxLf_best = zeros(1,degmax);
initpoint = 'rad';

for deg = 6:degmax
 
 ideg = ideg + 1;
 degree(ideg) = deg;
 
 n = (deg + 1) * (deg + 2) / 2;
 w = ones(n,1) / n;
 epsi = 1e-5;
 nfev = 5000;
 nfevL = 10000;
 iprint = 1;
 iter = 1;
 
 if iprint == 1
  fprintf('\n degree %d \n\n',deg)
 end
 
 % start from Carnicer-Godes
 
 [ptscg,rad] = gm_car_go_disk(deg);

 x_opt = ptscg(:,1);
 y_opt = ptscg(:,2);
 
 [maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,pts,2);
 
 % Lebesgue constant minimization using praxis
 [x,y,Psinp,maxL_new,x_opt,y_opt,rad] = gm_Leb_radius_disk_OPHL(deg,w,x_opt,y_opt,maxL,iter,epsi,iprint,nfev);
  
 xf_best(1:n,ideg) = x_opt;
 yf_best(1:n,ideg) = y_opt;
 
 rad = rad(:);
 nrad = size(rad,1);
 rad_best(1:nrad,ideg) = rad;
 
 [maxLf,Psidot] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,pts,2);
 
 maxLf_best(ideg) = maxLf;
 
end % for deg

save(savefile);



