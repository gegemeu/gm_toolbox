function pts_out=gm_pointset_optimization(deg,domain_string,minimizer_string,...
 init_pointset_string,optimization_pointset_string,mildnessV,pts_in,iprint);
%GM_POINTSET_OPTIMIZATION

% From Alvise Sommariva

% Needs the Matlab optimization toolbox


if nargin < 2
 domain_string = 'unitdisk';
end

if nargin < 3
 minimizer_string = 'fminimax'; % 'fminimax', 'fmincon', 'greedy_algorithm', 'fminunc', 'fminsearch'
end

% INITIAL INTP SET. ('lebesgue' or 'maxabsdet' or 'fekete' or 'leja')
if nargin < 4
%  init_pointset_string='lebesgue'; % initial set
 init_pointset_string = 'leja'; % initial set
end

if nargin < 5
 optimization_pointset_string = 'lebesgue'; % optimization process (some constraints).
end

if nargin < 6
%  mildnessV=4:9;
 mildnessV = 2:10;
end

if nargin < 7
 pts_in = [];
end

if nargin < 8
 iprint = 1;
end

stages = 1; % 1: only initial stage. 2: initial stage + refinement stage.
% 3: only refinement stage


% ------------------- Main program starts here ----------------------------


switch domain_string
 
 case 'unitsimplex'
  domain_coordinates = [0 0; 1 0; 0 1; 0 0];
  
 case 'unitdisk'
  domain_coordinates = [0 2*pi];
  
 case 'unitsquare'
  domain_coordinates = [-1 -1; 1 -1; 1 1; -1 1; -1 -1];
  
end

if size(pts_in,1) == 0
 [pts_in,w] = as_define_intpsets(domain_string,domain_coordinates,deg,...
  init_pointset_string);
end
rect = as_determine_smaller_rectangle(domain_string,domain_coordinates);

for jj = 1:length(mildnessV)
 
 mildness = mildnessV(jj);
 if iprint == 1
  fprintf('\n \n \t %% ============== MILDNESS: %2.0f ',mildness);
  fprintf(' METHOD: '); fprintf(minimizer_string); fprintf(' ============== \n')
 end
 
 [pts_out,leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc] = pointset_optimization(deg,pts_in,...
  domain_string,optimization_pointset_string,domain_coordinates,...
  minimizer_string,mildness,stages,iprint);
 
 if leb_const_loc < leb_const_init
  if iprint == 1
   fprintf('\n \t %% IMPROVEMENT. USING NEW SET. NEW: %1.5e OLD: %1.5e DIFF: %1.1e',...
    leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
  end
  pts_in = pts_out;
 else
  if iprint == 1
   fprintf('\n \t %% NO IMPROVEMENT. USING OLD SET. NEW: %1.5e OLD: %1.5e DIFF: %1.1e',...
    leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
  end
  leb_const_loc = leb_const_init;
 end % if leb_const_loc
end % for jj

% leb_const = cond_pts_loc;

if iprint == 1
 fprintf('\n \t %% ----- Deg.: %3.0f Leb.: %1.8e Leb.In.: %1.8e ------------ \n \n',...
  deg,leb_const_loc,leb_const_init);
end

pts_out = pts_in;


% ------------------------ pointset_optimization --------------------------

function [pts_out,leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc]=pointset_optimization(deg,pts_in,...
 domain_string,optimization_pointset_string,domain_coordinates,minimizer_string,mildness,stages,iprint)

pts_out = pts_in;

switch stages
 
 case 1
  
  if iprint == 1
   fprintf('\n \t %% =============== INITIAL STAGE =================');
  end
  
  [pts_out] = as_pointset_optimizer(deg,pts_in,...
   domain_string,optimization_pointset_string,domain_coordinates,minimizer_string,mildness,'initial_stage');
  
  if iprint == 1
   fprintf('\n \t %% ------------ RESULTS INITIAL STAGE -------------');
  end
  
  [leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc] = describe_pointset(...
   domain_string,domain_coordinates,pts_out,pts_in,deg,[],iprint);
  
  if leb_const_loc >= leb_const_init
   pts_out = pts_in;
   if iprint == 1
    fprintf('\n \t %% USING OLD POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  else
   if iprint == 1
    fprintf('\n \t %% USING NEW POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  end
  
 case 2
  
  if iprint == 1
   fprintf('\n \t %% =============== INITIAL STAGE =================');
  end
  
  [pts_out] = as_pointset_optimizer(deg,pts_in,...
   domain_string,optimization_pointset_string,domain_coordinates,minimizer_string,mildness,'initial_stage');
  
  if iprint == 1
   fprintf('\n \t %% ------------ RESULTS INITIAL STAGE -------------');
  end
  
  [leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc] = describe_pointset(...
   domain_string,domain_coordinates,pts_out,pts_in,deg,[],iprint);
  
  if leb_const_loc >= leb_const_init
   pts_out = pts_in;
   if iprint == 1
    fprintf('\n \t %% USING OLD POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  else
   if iprint == 1
    fprintf('\n \t %% USING NEW POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  end % if leb_const_loc
  
  if iprint == 1
   fprintf('\n \t %% ================ FINAL STAGE ==================');
  end
  
  [pts_out] = as_pointset_optimizer(deg,pts_out,...
   domain_string,optimization_pointset_string,domain_coordinates,'greedy_algorithm',mildness,'final_stage');
  
  if iprint == 1
   fprintf('\n \t %% ------------ RESULTS FINAL STAGE -------------');
  end
  
  [leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc] = describe_pointset(...
   domain_string,domain_coordinates,pts_out,pts_in,deg,[],iprint);
  
  if leb_const_loc >= leb_const_init
   pts_out = pts_in;
   if iprint == 1
    fprintf('\n \t %% USING OLD POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  else
   if iprint == 1
    fprintf('\n \t %% USING NEW POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  end % if leb_const_loc
  
 otherwise
  
  if iprint == 1
   fprintf('\n \t %% ================ FINAL STAGE ==================');
  end
  
  [pts_out] = as_pointset_optimizer(deg,pts_out,...
   domain_string,optimization_pointset_string,domain_coordinates,...
   'greedy_algorithm',mildness,'final_stage');
  
  if iprint == 1
   fprintf('\n \t %% ------------- RESULTS FINAL STAGE --------------');
  end
  
  [leb_const_loc,leb_const_init,absdetV_loc,cond_pts_loc] = describe_pointset(...
   domain_string,domain_coordinates,pts_out,pts_in,deg,[],iprint);
  
  if leb_const_loc >= leb_const_init
   pts_out = pts_in;
   if iprint == 1
    fprintf('\n \t %% USING OLD POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  else
   if iprint == 1
    fprintf('\n \t %% USING NEW POINTSET FOR NEXT ANALYSIS. NEW: %1.3e OLD: %1.3e DIFF: %1.1e \n',...
     leb_const_loc,leb_const_init,leb_const_loc-leb_const_init);
   end
  end % if leb_const_loc
  
end


% ------------------------ describe_pointset ------------------------------

function [leb_const,leb_const0,absdetV,cond_pts]=describe_pointset(...
 domain_string,domain_coordinates,X,X0,deg,rect,iprint)

% POINTS OUT
[Xin,Iin] = as_indomain(X,domain_string,domain_coordinates);
card_pts_out = size(X,1)-size(Xin,1);

if card_pts_out > 0
 [X,card_pts_out] = postproduction(domain_string,X);
end

% COMPUTING LEBESGUE CONSTANTS
V0 = as_determine_vandermonde_matrix(domain_string,X0,deg,rect);
VX = as_determine_vandermonde_matrix(domain_string,X,deg,rect);

[XT,w,rect] = as_define_pointset(domain_string,'wam',...
 domain_coordinates,500);
VT = as_determine_vandermonde_matrix(domain_string,XT,deg,rect);

leb_const = norm(VX'\VT',1);
leb_const0 = norm(V0'\VT',1);


% MAX ABS DETERMINANT
% V = as_determine_vandermonde_matrix(domain_string,X,deg,rect);
% absdetV = abs(det(V));

absdetV = [];

% CONDITIONING
% cond_pts = condest(V);

cond_pts = [];

if iprint == 1
 fprintf('\n \t %% ----------------- DEGREE %2.0f --------------------',deg)
 
 fprintf('\n \n \t case %3.0f \n',deg)
 
 % [pts_in,ind_in]=indomain(X,domain_string,domain_coordinates);
 %
 %
 % if size(pts_in,1) < size(X,1)
 %     fprintf('\n \t %% WARNING: %4.0f POINTS ARE NOT IN THE DOMAIN',...
 %         -size(pts_in,1) + size(X,1));
 % end
 fprintf('\n \t %% LEBESGUE CONST.               : %1.5e',leb_const);
 fprintf('\n \t %% >> INITIAL SET LEBESGUE CONST.: %1.5e',leb_const0);
 %  fprintf('\n \t %% ABS.DET.VAND.MATRIX           : %1.5e',absdetV);
 %  fprintf('\n \t %% CONDITIONING                  : %1.5e',cond_pts);
 fprintf('\n \t %% CARDINALITY                   : %6.0f',size(X,1))
 fprintf('\n \t %% POINTS OUT DOMAIN             : %6.0f',card_pts_out)
 
 dim = size(X,1);
 
 fprintf('\n \n \t pts=[');
 for ii=1:dim
  fprintf('\n \t %1.25e %1.25e',X(ii,1),X(ii,2))
 end
 fprintf('\n \t ]; \n \n');
 
end



% --------------------------- postproduction ------------------------------

function [pts,card_pts_out]=postproduction(domain_string,pts)

% This routine tries to fix minor problems of the set, as points that are
% outside the domain, but very close to the boundary.

switch domain_string
 case 'unitsimplex'
  %fprintf('\n \n \t %% DOING POSTPRODUCTION, SOME FAILURE.');
  
  x = pts(:,1); y = pts(:,2);
  
  % ADJUSTING POINTS CLOSE TO THE BOUNDARY (ALSO OUTSIDE!).
  
  tol = 10^(-14);
  
  ix = find(x < tol);
  pts(ix,1) = 0.000000000000000000000000000000e+00;
  
  ix = find(x > 1);
  pts(ix,1) = 1.000000000000000000000000000000e+00;
  
  iy = find(y < tol);
  pts(iy,2) = 0.000000000000000000000000000000e+00;
  
  iy = find(y > 1);
  pts(iy,2) = 1.000000000000000000000000000000e+00;
  
  xp = pts(:,1); yp = pts(:,2);
  
  ss = find(xp + yp > 1);
  for index = 1:length(ss)
   ssloc = ss(index); xx = xp(ssloc); yy = yp(ssloc);
   if xx > yy
    pts(ssloc,2) = 1-xx;
   else
    pts(ssloc,1) = 1-yy;
   end
  end
  xp = pts(:,1); yp = pts(:,2);
  
  sp = (xp >= 0) + (yp >= 0) + (xp <= 1) + (yp <= 1) + (xp + yp <= 1) -5;
  
  sp_post = find(sp < 0);
  card_pts_out = size(sp_post,1);
  
  if card_pts_out == 0
   % fprintf('\n \t %% PASSED AFTER POST PRODUCTION.');
  else
   % fprintf('\n \t %% NOT PASSED AFTER POSTPRODUCTION');
  end
  
end % switch

