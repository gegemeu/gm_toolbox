function maxL=gm_read_LebesgueM(fname,npts,ipb,iprint);
%GM_READ_LEBESGUEM gets the points from a Lebesgue minimization file and compute the Lebesgue constant

% We assume equal weights

% Input:
% fname = name of the file
% npts = number of points on one side of the test grid
% ipb = problem number
% iprint = 1 printing and vizualization of the Lebesgue function
%
% Output:
% maxL = Lebesgue constant

%
% Author G. Meurant
% August 2015
%

% You might have to change this
fpath = 'C:\D\new_mfiles\gm_toolbox\Interpolation\PointsM\';

fn = [fpath fname];

% read the points coordinates from the file
[x,y] = gm_read_points(fn);

n = length(x);
% equal weights
w = ones(n,1) / n;

if iprint == 1
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,ipb);
 fprintf('\n Lebesgue constant = %g \n\n',maxL)
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,ipb);
end % if iprint

