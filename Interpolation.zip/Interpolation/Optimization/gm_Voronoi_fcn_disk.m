function f=gm_Voronoi_fcn_disk(X);
%GM_VORONOI_FCN_DISK inverses of squared pairwise distances 

%
% Author G. Meurant
% February 2017
%

global iprob

iprob = 2;

% for the evaluation we have to put back the first point = (0,1)

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

nX = length(X);
n = nX / 2;

x = X(1:n);
y = X(n+1:nX);

cell_area = gm_Voronoi_disk(x,y);

% mean
avc = sum(cell_area) / n;

diffc = (cell_area - avc).^2;

% this is proportional to the variance
f = sum(diffc);




