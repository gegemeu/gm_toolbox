
% gm_comp_points_rad_disk

% computation of points for the unit disk starting from the optimal raddi
% points

vt = clock;
savefile = ['temprad-' date '-' num2str(vt(4)) num2str(vt(5)) num2str(ceil(vt(6)))];

pts = gm_disk_wam(500);

ideg = 0;
degmax = 17;
nmax = (degmax + 1) * (degmax + 2) / 2;

degree = zeros(1,degmax);
xf_best = zeros(nmax,degmax);
yf_best = zeros(nmax,degmax);
maxLf_best = zeros(1,degmax);
initpoint = 'rad';

for deg = 17:degmax
 
 ideg = ideg + 1;
 degree(ideg) = deg;
 
 n = (deg + 1) * (deg + 2) / 2;
 w = ones(n,1) / n;
 epsi = 1e-15;
 nfev = 5000;
 nfevL = 10000;
 iprint = 1;
 
 if iprint == 1
  fprintf('\n degree %d \n\n',deg)
 end
 
 [ptsrad,radius,maxL] = gm_points_radius_opt_disk(deg);
 x_opt = ptsrad(:,1);
 y_opt = ptsrad(:,2);
 
 % Lebesgue constant minimization using fminimax (A. Sommariva)
 pts_out = gm_pointset_optimization(deg,'unitdisk','fminimax','leja','lebesgue',[10],[x_opt y_opt],iprint);
 
 xf_best(1:n,ideg) = pts_out(:,1);
 yf_best(1:n,ideg) = pts_out(:,2);
 
 [maxLf,Psidot] = gm_compXY_Lebesgue_func_OPHL(pts_out(:,1),pts_out(:,2),w,pts,2);
 
 maxLf_best(ideg) = maxLf;
 
end % for deg

save(savefile);



