function gm_write_points_L2norm_bnd(dmin,dmax,epsi,mu,ipb,iprint);
%GM_WRITE_POINTS_L2NORM_BND writes sets of points using l_2 minimization + a boundary integral

% Input:
% dmin = minimum degree
% dmax = maximum degree
% epsi = stopping criteria on the value of the objective function
% mu = coefficient of the boundary integral
% ipb = problem to be considered
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1 with printing

%
% Author G. Meurant
% August 2015
%

if nargin < 6
 iprint = 0;
end

ii = sqrt(-1);

% you might have to change this
fpath = 'C:\D\new_mfiles\gm_toolbox\Interpolation\PointsL2\';

dmin = max(dmin,2);

if dmin > dmax
 error('gm_write_points_L2norm_bnd: dmin > dmax')
end

if dmax > 20
 fprintf('\n gm_write_points_L2norm_bnd: The max degree may be too large, be patient! \n\n')
end

switch ipb
 
 case 1
  pb = 'square';
  
 case 2
  
  pb = 'disk';
  
 case 3
  
  pb = 'Lshape';
  
 case 4
  
  pb = 'triangle';
  
 case 5
  
  pb = 'dbubble';
  
 case 6
  
  pb = 'ellipse';
  
 case 7
  
  pb = 'hellipse';
  
 otherwise
  
  error('gm_write_points_L2norm_bnd: Wrong value of ipb')
  
end

for degree = dmin:dmax
 
 fprintf('\n Degree = %d \n',degree)
 
 nstr = num2str((mu-fix(mu))*100);
 if mu-fix(mu) == 0
  if fix(mu) == 0
   nstr = '0';
  else
   nstr = '00';
  end
 end
 
 fnam = [fpath 'gm_' pb num2str(degree) '-' num2str(fix(mu)) nstr];
 
 % equal weights
 n = ((degree + 1) * (degree + 2)) / 2;
 w = ones(n,1) / n;
 
 % Leja-like points for starting
 
 switch ipb
  
  case 1
   leja = gm_leja_square(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 2
   leja = gm_leja_disk(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 3
   leja = gm_leja_Lshape(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 4
   leja = gm_leja_triangle(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 5
   leja = gm_leja_dbubble(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 6
   leja = gm_leja_ellipse(degree,2,1);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 7
   leja = gm_leja_hellipse(degree,2,1);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
 end
 
 % L2 norm minimization
 
 if iprint == 1
  fprintf('\n --------Start of l2 minimization \n\n')
 end
 
 [xl,yl,maxLl] = gm_min_praxis_L2norm_bnd(x0,y0,w,epsi,mu,ipb,iprint);
 
 fname = [fnam '-l2'];
 
 gm_write_points(fname,xl,yl);
 
 if iprint == 1
  fprintf('\n --------End of the L2 minimization, mu = %g Lebesgue constant = %g \n',mu,maxLl)
  %   pause
  %   gm_clearallfig
 end
 
 % refinement algorithm
 
 it = 3; % number of iterations
 
 if iprint == 1
  fprintf('\n --------Start of refinement, %d iterations \n',it)
 end
 
 [xr,yr,Psinp,maxLr,x_opt,y_opt] = gm_Leb_refP_OPHL(xl,yl,w,xl,yl,maxLl,it,epsi,iprint);
 
 fname = [fnam '-ref'];
 
 gm_write_points(fname,x_opt,y_opt);
 
 if iprint == 1
  fprintf('\n --------End of the refinement, Lebesgue constant after this step = %g \n',maxLr)
%   pause
%   gm_clearallfig
 end
 
 % one point minimization
 
 if iprint == 1
  fprintf('\n --------Start of one point minimization, %d iterations \n',it)
 end
 
 [x1,y1,Psinp,maxL1,x_opt,y_opt]=gm_Leb_one_OPHL(x_opt,y_opt,w,x_opt,y_opt,maxLr,it,epsi,iprint);
 
 % Leja order of the best points
 z = gm_leja_ord(x_opt + ii * y_opt,n);
 x_opt = real(z);
 y_opt = imag(z);
 
 fname = [fnam '-1p'];
 
 gm_write_points(fname,x_opt,y_opt);
 
 % recompute the Lebesgue contant
 % this may not be enough to compute the L-constant reliably!!!!!!
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,400,ipb);
 
 if iprint == 1
  fprintf('\n end of degree %d, Lebesgue constant = %g \n',degree,maxL)
  fprintf('\n -------------------------------------------------------------------- \n')
 end
 
end % for degree





