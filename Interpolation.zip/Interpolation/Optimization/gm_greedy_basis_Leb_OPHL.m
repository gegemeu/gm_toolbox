function [x,y,Psinp,maxL]=gm_greedy_basis_Leb_OPHL(x,y,maxdeg,maxit,viz);
%GM_GREEDY_BASIS_LEB_OPHL enlarges a given set of points by selecting the max
% of (an approximation of) the Lebesgue function at each step
% and then iterates with gm_Leb_ref_OPHL to improve the Lebesgue constant

% We assume equal weights

% Input:
% x, y = given points
% maxdeg = degree to reach
% maxit = number of iterations
% viz = 1 with vizualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant

%
% Author G. Meurant
% July 2014
% Updated August 2015
%

global iprob

n = length(x);
% number of points
nmax = gm_numb_bivar_pol(maxdeg);
if nmax <= n
 error('greedy_basis_Leb_OPHL: The degree is not large enough')
end

% enlarge the set of points
[x,y,Psinp,maxL] = gm_greedy_OPHL(x,y,nmax,viz);
n = length(x);
w = ones(n,1) / n;

if viz == 1
 fprintf(' start iterating with gm_Leb_one_OPHL \n')
end

[x,y,Psinp,maxL,x_opt,y_opt] = gm_Leb_one_OPHL(x,y,x,y,maxL,2,1e-3,0);

if viz == 1
 % this may not be enough to compute the L-constant reliably!!!!!!
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,200,iprob);
 fprintf(' Final Lebesgue constant =  %0.5f \n ',maxL)
 figure
 plot(x,y,'*')
 title(['Lebesgue constant = ' num2str(maxL)])
else
 % this may not be enough to compute the L-constant reliably!!!!!!
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
end % if viz


