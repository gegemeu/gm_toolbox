function [x,y,Psinp,maxL,x_opt,y_opt]=gm_Leb_ref_OPHL(x,y,w,x_opt,y_opt,maxL_old,it,iprint);
%GM_LEB_REF_OPHL Refinement algorithm, iterates over a set of points by
% replacing in turn all the points by the max of (an approximation of) the Lebesgue function

% Input:
% (x,y) = coordinates of the points
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do 
%                 not improve the Lebesgue constant
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% iprint = 1 with printing and vizualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global xparm yparm wparm
global iprob

if nargin <= 7
 iprint = 1;
end

n = length(x);
maxLi = zeros(1,n);
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;

Psinp = 0;

for k = 1:it
 if iprint == 1
  fprintf('----------iteration %d \n',k)
 end
 
 % for all points in turn
 for i = 1:n
  % find an approximate max of the Lebesgue function
  % remove the point i
  X = [x(1:i-1); x(i+1:n)]; 
  Y = [y(1:i-1); y(i+1:n)];
  xparm = x; 
  yparm = y; 
  wparm = w;
  ww = [w(1:i-1); w(i+1:n)];
  ww = ww /sum(ww);
  % commputation of the Lebesgue constant without the point
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(X,Y,ww,npts,iprob);
  maxLi(i) = maxL;
  % max of the function
  [minP,J] = max(Psidot);
  % new point to add
  xx = XY(J(1),1); 
  yy = XY(J(1),2);
  
  x(i) = xx; 
  y(i) = yy;
  
  % computation of the new Lebesgue constant
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
  
  if maxL < maxL_old
   % we have some improvement, keep the configuration
   maxL_old = maxL;
   x_opt = x; 
   y_opt = y;
  end % if maxL
  
 end % for i
 
 if iprint == 1
  % viz and print
  [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,npts,iprob);
  fprintf(' New approximate Lebesgue constant = %0.5f \n',maxL)
  pause
 end % if iprint
 
end % for k (end of iterations)

if maxL >= maxL_old
 % restore the optimal points
 x = x_opt; 
 y = y_opt;
 maxL = maxL_old;
end % if maxL

if iprint == 1
 % viz on a fine mesh
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
 fprintf(' Final Lebesgue constant (restored) = %0.5f \n',maxL)
 
 figure
 
 % plot the points
 plot(x_opt,y_opt,'*')
 
end % if iprint





