function [x,y,Psinp,maxL]=gm_greedy_OPHL(x,y,nmax,viz);
%GM_GREEDY_OPHL enlarges a given set of points by selecting the max
% of (an approximation of) the Lebesgue function at each step

% we assume equal weights

% Input:
% x, y = given points
% nmax = number of points to reach
% viz = 1 with vizualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global iprob

n = length(x);
it = nmax - n;
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;

for k = 1:it
 if viz == 1
  fprintf('-------------------\n')
  fprintf(' add one point, n = %d \n',n+1)
  [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 else
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 end % if viz
 
 [ maxP,I] = max(Psidot);
 % add the max as a new point
 x = [x; XY(I(1),1)]; 
 y = [y; XY(I(1),2)];
 n = n + 1;
 
 % recompute the Lebesgue constant
 w = ones(n,1) / n;
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 
 % see if we can improve the Lebesgue constant by iterating with gm_greedy_it_OPHL
 maxL_old = maxL;
 x_old = x; 
 y_old = y;
 if viz == 1
  fprintf(' start iterations gm_greedy_it_OPHL, approximate Lebesgue constant = %0.5f \n',maxL)
 end
 [x,y,Psinp,maxL,x_opt,y_opt] = gm_greedy_it_OPHL(x,y,x,y,maxL_old,it,viz,0);
 if viz == 1
  fprintf(' end iterations gm_greedy_it_OPHL \n')
 end
 if maxL > maxL_old
  % get the points back (no improvement)
  maxL = maxL_old;
  x = x_old; y = y_old;
 else
  fprintf(' improvement greedy_OP, old Leb const = %0.5f, new Leb const = %0.5f \n',maxL_old,maxL)
  x = x_opt; y = y_opt;
 end % if maxL
 
 % see if we can improve the Lebesgue constant with gm_Leb_ref_OPHL
 if viz == 1
  fprintf(' Leb const = %0.5f, starting iterations with gm_Leb_refP_OPHL \n',maxL)
 end
 [x,y,Psinp,maxL,x_opt,y_opt] = gm_Leb_refP_OPHL(x,y,w,x,y,maxL,5,1e-3,0);
 if viz == 1
  fprintf('\n new Lebesgue constant = %0.5f \n',maxL)
 end
 % keep the best points
 x = x_opt; 
 y = y_opt;
 
 if viz == 1
  pause
 end
 
end % for k


