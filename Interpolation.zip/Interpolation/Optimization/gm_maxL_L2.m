
% computation of the Lebesgue constants for Leja, L2, L and fminimax

nw = 500;
% we compute on a WAM of order 500 (250501 points)
pts = gm_disk_wam(nw);

fprintf('\n Leja, L2, L and fminimax (from Leja), WAM of order %d, %d points \n',nw,size(pts,1))


for deg = 1:10
 n = (deg + 1) * (deg + 2) / 2;
 
 % Leja
 leja = gm_leja_disk(deg);
 x = leja(:,1);
 y = leja(:,2);
 w = ones(n,1) / n;
 
 % Vandermonde
 maxL_Leja = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % L2
 [ptsL2,maxL] = gm_pointsL2_disk(deg);
 x = ptsL2(:,1);
 y = ptsL2(:,2);
 
 % Vandermonde
 maxL_Ltwo = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % L2
 [ptsL,maxL] = gm_pointsL_disk(deg);
 x = ptsL(:,1);
 y = ptsL(:,2);
 
 % Vandermonde
 maxL_L = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % fminimax
 [ptsLAS,maxL]=gm_pointsL_AS_disk(deg);
 x = ptsLAS(:,1);
 y = ptsLAS(:,2);
 
 % % Huhtanen-Larsen
 % [maxL_OPHL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);
 
 % Vandermonde
 maxL_AS = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 
 fprintf('\n %3d Leja = %12.7f, L2 = %12.7f, L = %12.7f, fminimax = %12.7f \n',deg,maxL_Leja,maxL_Ltwo,maxL_L,maxL_AS)
 
end % for deg

