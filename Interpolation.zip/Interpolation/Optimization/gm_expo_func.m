function f=gm_expo_func(X);
%GM_EXPO_FUNC function for the minimization with the C-G exponent

%
% Author G. Meurant
% March 2017
%

global ptsw 
global wparm
global degree

% check if the radii are between 0 and 1

for k = 1:length(X)
 if (X(k)  < 1) || (X(k) > 2)
  f = (1 + rand) * 1e16;
  return
 end
end

expo = X;

% compute the C-G points from the exponent
n = degree;

lmax = floor(n/2) + 1;
np = (n + 1) * (n + 2) / 2;
pts_pol = zeros(np,2);

k = 1;
for l = 1:lmax
 lcg = l - 1;
 jmax = 2 * (n - 2 * lcg) + 1;
 r = 1 -(2 * lcg /n )^expo;
 theta = (2 * [0:jmax-1]' + 1) * pi / (2 * (n - 2 * lcg) + 1);
 pts_pol(k:k+jmax-1,:) = [r * ones(size(theta)) theta];
 k = k + jmax;
end % for l

rad = pts_pol(:,1); 
thet = pts_pol(:,2);
ptsrad = [rad .* cos(thet) rad .* sin(thet)];

% keep the points inside the unit disk
% the values of the function must not be larger than this value!
% XX = [ptsrad(:,1); ptsrad(:,2)];
% ind = gm_indic_func(XX);
% if ind == 0
%  f = (1 + rand) * 1e16;
%  fprintf(' reject \n')
%  return
% end % if ind

x = ptsrad(:,1);
y = ptsrad(:,2);
w = wparm;

% compute the values of the Lebesgue function on points ptsw

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);

f = maxL;

fprintf(' expo = % g, maxL = %g \n',expo,maxL)




