function f=gm_dist_Dub_fcn_disk(X);
%GM_DIST_DUB_FCN_DISK inverses of squared pairwise Dubiner distances 

%
% Author G. Meurant
% March 2017
%

global iprob

iprob = 2;

% for the evaluation we have to put back the first point = (0,1)

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
%  fprintf('reject \n')
 return
end

nX = length(X);
n = nX / 2;

x = X(1:n);
y = X(n+1:nX);

% [dmat,dmati] = gm_dist_mat_sq(x,y);
[dmat,dmati,vd,difmind,diffav] = gm_dist_Dub_mat(x,y);
dmati = dmati.^6;
% dmati = dmati.^4;
 
f = sum(sum(dmati));

% fprintf(' f = %g \n',f)

% f = max(max(dmati));
  
% vd is n times the variance of the minimal distances
% f = vd;

% sum of the squares of differences of minimal distances
% f = sum(sum(difmind));

% sum of the squares of differences of averaged distances
% f = sum(sum(diffav));


