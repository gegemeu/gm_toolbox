function [x,y,maxL,nf]=gm_max_praxis_Leb_upper_OPHL(epsi);
%GM_MAX_PRAXIS_LEB_UPPER_OPHL max of a bound of the Lebesgue function using praxis

% Input:
% epsi = stopping criteria
%
% Output:
% x, y = location of the max
% maxL = maximum of the Lebesgue function
% nf = number of function evaluations

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm
global Aparm alpparm
global iprob

ipb = iprob;

% look for the max on a coarse mesh to get
% a "good" starting point (note that this is not the right function!)
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(xparm,yparm,wparm,10,ipb);
[maxP,I] = max(Psidot);
x0 = XY(I(1),1); 
y0 = XY(I(1),2);
X0 = [x0 y0];
n2 = 2;

% refine by optimization

% total degree
n = length(xparm);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values at the inner product points
[Phi,A] = gm_OPHL(d,xparm,yparm,wparm);
% set the global variables for gm_Lebesgue_func_upper_OPHL
Aparm = A;

% coefficients of the expansion
alp = Phi' * diag(wparm);
alpparm = alp;

% minimize -function
[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,2,n2,X0,@gm_Lebesgue_func_upper_OPHL);

if exitflag == 1 && abs(prax) < maxP
 % no convergence and a worse max, get the one from the initialization
 prax = -maxP;
end % if exitflag

maxL = -prax;
x = xp(1); 
y = xp(2);


