
% computation of the Lebesgue constants for C-G, L2, L and fminimax

nw = 500;
% we compute on a WAM of order 500 (250501 points)
pts = gm_disk_wam(nw);

fprintf('\n C-G, L2, L and fminimax (from C-G), WAM of order %d, %d points \n',nw,size(pts,1))


for deg = 1:10
 n = (deg + 1) * (deg + 2) / 2;
 
 % Carnicer-Godes points (standard)
 [ptscg,radius] = gm_car_go_disk(deg,'cg');
 x = ptscg(:,1);
 y = ptscg(:,2);
 w = ones(n,1) / n;
 
 % Vandermonde
 maxL_Leja = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % L2
 [ptsL2,maxL] = gm_pointsL2cg_disk(deg);
 x = ptsL2(:,1);
 y = ptsL2(:,2);
 
 % Vandermonde
 maxL_Ltwo = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % L2
 [ptsL,maxL] = gm_pointsLcg_disk(deg);
 x = ptsL(:,1);
 y = ptsL(:,2);
 
 % Vandermonde
 maxL_L = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % fminimax
 [ptsLAS,maxL]=gm_pointsL_AScg_disk(deg);
 x = ptsLAS(:,1);
 y = ptsLAS(:,2);
 
 % % Huhtanen-Larsen
 % [maxL_OPHL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);
 
 % Vandermonde
 maxL_AS = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 
 fprintf('\n %3d C-G = %12.7f, L2 = %12.7f, L = %12.7f, fminimax = %12.7f \n',deg,maxL_Leja,maxL_Ltwo,maxL_L,maxL_AS)
 
end % for deg

