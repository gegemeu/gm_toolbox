% OPTIMIZATION
%
% Files
%   gm_comp_points_disk              - computation of points for the unit disk
%   gm_comp_points_rad_disk          - computation of points for the unit disk
%   gm_comp_pointsF_disk             - computation of points for the unit disk starting from points obtained by praxis
%   gm_comp_radopt_disk              - computation of points for the unit disk with radii optimization
%   gm_compXY_Lebesgue_func_Vdisk    - computation of the Lebesgue function on a given mesh
%   gm_dist_Dub_fcn_disk             - inverses of squared pairwise Dubiner distances 
%   gm_dist_fcn_disk                 - inverses of squared pairwise distances 
%   gm_dist_fcn_disk_old             - inverses of squared pairwise distances 
%   gm_expo_func                     - function for the minimization with the C-G exponent
%   gm_files_Lebesgue                - computes the Lebesgue constant for files related to one problem
%   gm_files_Lebesgue_mu             - computes the Lebesgue constant for files related to one problem and a given value of mu
%   gm_files_LebesgueM               - computes the Lebesgue constant for files related to one problem
%   gm_find_locmax                   - finds the local maxima of the Lebesgue function
%   gm_greedy_basis_Leb_OPHL         - enlarges a given set of points by selecting the max
%   gm_greedy_it_OPHL                - iterates over a set of points by selecting the max
%   gm_greedy_OPHL                   - enlarges a given set of points by selecting the max
%   gm_Lag_L2norm                    - function for the minimization of the l2-norm of the Lagrange function
%   gm_Lag_L2norm_bnd                - function for the minimization of the l2-norm of the Lagrange function + a boundary integral
%   gm_Lag_L2norm_bnd_disk           - function for the minimization of the l2-norm of the Lagrange function + a boundary integral
%   gm_Lag_L2norm_bnd_disk1          - function for the minimization of the l2-norm of the Lagrange function + a boundary integral
%   gm_Lag_L2norm_squared            - sum of the squares of the Lagrange polynomials at xx,yy
%   gm_Lag_Lpnorm_bnd                - function for the minimization of the lp-norm of the Lagrange function + a boundary integral
%   gm_Lag_Lpnorm_p                  - sum of the p-th power of the Lagrange polynomials at xx,yy
%   gm_Lagrange_locmax_disk_OPHL     - minimizes the Lagrange polynomials on the unit disk
%   gm_Lagrangemax_func              - function for the minimization of values of the Lagrange polynomial
%   gm_Lagrangemax_func1             - function for the minimization of values of the Lagrange polynomial
%   gm_Leb_expo_disk_OPHL            - minimizes the Lebesgue function on the exponent of the radius positions
%   gm_Leb_fcn_disk_OPHL             - Lebesgue constant for the minimization in the unit disk
%   gm_Leb_fcn_diskF_OPHL            - (bounds of the) Lebesgue constant for the
%   gm_Leb_fcn_OPHL                  - (bounds of the) Lebesgue constant for the minimization
%   gm_Leb_locmax_disk_OPHL          - minimizes the standard deviation of the local maxima on the unit disk
%   gm_Leb_one_disk_OPHL             - replaces the max by an optimization of the Lebesgue function
%   gm_Leb_one_disk_V                - replaces the max by an optimization of the Lebesgue function
%   gm_Leb_one_OPHL                  - replaces the max by an optimization of the Lebesgue function
%   gm_Leb_radius_disk_OPHL          - minimizes the Lebesgue function on the radius positions
%   gm_Leb_ref_disk                  - refinement algorithm for the disk, iterates over a set of points by
%   gm_Leb_ref_OPHL                  - refinement algorithm, iterates over a set of points by
%   gm_Leb_refP_OPHL                 - refinement algorithm, iterates over a set of points by
%   gm_Lebesgue_func1_OPHL           - computation of the max of the Lebesgue function
%   gm_Lebesgue_func1_V              - computation of the max of the Lebesgue function
%   gm_Lebesgue_func_OPHL            - computation of the Lebesgue function
%   gm_Lebesgue_func_upper1_OPHL     - computation of an upper bound of the Lebesgue function
%   gm_Lebesgue_func_upper_OPHL      - computation of the upper bound of the Lebesgue function
%   gm_locmax_func                   - function for the minimization of the standard deviation of
%   gm_max_Leb_func_disk_deg1        - utility function
%   gm_max_praxis_Leb_OPHL           - (approximate) max of the Lebesgue function using praxis
%   gm_max_praxis_Leb_upper1_OPHL    - max of a bound of the Lebesgue function using praxis
%   gm_max_praxis_Leb_upper_OPHL     - max of a bound of the Lebesgue function using praxis
%   gm_maxL_cg                       - computation of the Lebesgue constants for the Carnicer-Godes points
%   gm_maxL_cg_opt                   - computation of the Lebesgue constants for the Carnicer-Godes points
%   gm_maxL_cg_rad                   - computation of the Lebesgue constants for the Carnicer-Godes points and
%   gm_maxL_L2                       - computation of the Lebesgue constants for Leja, L2, L and fminimax
%   gm_maxL_L2_cg                    - computation of the Lebesgue constants for C-G, L2, L and fminimax
%   gm_maxL_LOC                      - computation of the Lebesgue constants for Leja, OCS and Carnicer-Godes points
%   gm_maxL_spiral                   - computation of the Lebesgue constants for the spiral points
%   gm_maxL_uniform                  - computation of the Lebesgue constants for the uniform points
%   gm_min_L2norm                    - looks for a good set of points using L2 minimization
%   gm_min_L2norm_bnd                - looks for a good set of points using l_2 minimization + a boundary integral
%   gm_min_Lebesgue                  - looks for a good set of points using Lebesgue constant minimization
%   gm_min_Lpnorm_bnd                - looks for a good set of points using l_P minimization + a boundary integral
%   gm_min_praxis_distance_disk      - looks for the maximization of the distances iterating with gm_praxis
%   gm_min_praxis_distance_disk_old  - looks for the maximization of the distances iterating with gm_praxis
%   gm_min_praxis_L2norm             - looks for the min of the 2-norm of the Lagrange polynomials using gm_praxis
%   gm_min_praxis_L2norm_bnd         - looks for the min of the 2-norm of the Lagrange polynomials using gm_praxis + a boundary integral
%   gm_min_praxis_L2norm_bnd_disk    - looks for the min of the 2-norm of the Lagrange polynomials using gm_praxis + a boundary integral
%   gm_min_praxis_L2norm_bnd_diskF   - looks for the min of the 2-norm of the Lagrange polynomials using gm_praxis + a boundary integral
%   gm_min_praxis_Lebesgue           - looks for the min of the Lebesgue constant iterating with gm_praxis
%   gm_min_praxis_Lebesgue_disk      - looks for the min of the Lebesgue constant iterating with gm_praxis
%   gm_min_praxis_Lebesgue_diskF     - looks for the min of the Lebesgue constant iterating with gm_praxis
%   gm_min_praxis_Lebesgue_diskR     - looks for the min of the Lebesgue constant iterating with gm_praxis
%   gm_min_praxis_Lpnorm_bnd         - looks for the min of the p-norm of the Lagrange
%   gm_min_praxis_Voronoi_disk       - looks for the homogeneization of the Voronoi cell areas iterating with gm_praxis
%   gm_move_max_OPHL                 - moves the maximum to the max of (an approximation of) the Lebesgue function
%   gm_move_one_OPHL                 - moves one point to the max of (an approximation of) the Lebesgue function
%   gm_points_ball_Teck              - Gunzburger and Teckentrup points for the unit disk
%   gm_points_dist_disk              - sets of points with uniform distributiont for the disk
%   gm_points_distref_disk           - sets of points with uniform distribution for the disk with refinement
%   gm_points_expo_disk              - using Carnicer-Godes angles for the unit disk with given exponent
%   gm_points_radius_disk            - using Carnicer-Godes angles for the unit disk with given radii
%   gm_points_radius_opt_disk        - optimization of the radii of the CG-like points
%   gm_pointset_optimization         - optimization with the Matlab optimization toolbox
%   gm_pointsF_new_disk              - sets of points with low Lebesgue constant for the disk
%   gm_pointsF_rad_disk              - sets of points with low Lebesgue constant for the disk
%   gm_pointsF_radius_disk           - sets of points with low Lebesgue constant for the disk
%   gm_pointsL2_new_disk             - sets of points with low Lebesgue constant for the disk
%   gm_pointsL2_rad_disk             - sets of points with low Lebesgue constant for the disk
%   gm_pointsL2cg_disk               - sets of points with low Lebesgue constant for the disk
%   gm_pointsL_AS_disk               - sets of points with low Lebesgue constant for the disk
%   gm_pointsL_AScg_disk             - sets of points with low Lebesgue constant for the disk
%   gm_pointsL_new_disk              - sets of points with low Lebesgue constant for the disk
%   gm_pointsL_rad_disk              - sets of points with low Lebesgue constant for the disk
%   gm_pointsLcg_disk                - sets of points with low Lebesgue constant for the disk
%   gm_print_points_dist_disk        - prints sets of points for the unit disk using distance maximization 
%   gm_print_points_dist_disk_old    - prints sets of points for the unit disk using distance maximization 
%   gm_print_points_L2norm_bnd       - prints sets of points using l_2 minimization + a boundary integral
%   gm_print_points_L2norm_bnd_deg   - prints sets of points using l_2 minimization + a boundary integral
%   gm_print_points_L2norm_bnd_disk  - prints sets of points using l_2 minimization + a boundary integral
%   gm_print_points_L2norm_bnd_diskF - prints sets of points using l_2 minimization + a boundary integral
%   gm_print_points_Lebesgue_deg     - prints sets of points using Lebesgue constant minimization 
%   gm_print_points_Lebesgue_degXY   - prints sets of points using Lebesgue constant minimization 
%   gm_print_points_Lebesgue_disk    - prints sets of points for the unit disk using Lebesgue constant minimization 
%   gm_print_points_Lebesgue_diskF   - prints sets of points for the unit disk using Lebesgue constant minimization 
%   gm_print_points_Lebesgue_diskR   - prints sets of points for the unit disk using Lebesgue constant minimization 
%   gm_print_points_Voronoi_disk     - prints sets of points for the unit disk using Voronoi cells
%   gm_radius_func                   - function for the minimization with the radii
%   gm_radius_funcf                  - function for the minimization with the radii
%   gm_read_Lebesgue                 - gets the points from an L2 file and compute the Lebesgue constant
%   gm_read_LebesgueM                - gets the points from a Lebesgue minimization file and compute the Lebesgue constant
%   gm_refine_maxL                   - mesh refinement to compute the Lebesgue constant
%   gm_uniform_disk                  - Uniform nodes for the unit disk
%   gm_vandermonde_koornwinder       - Vandermonde matrix for the unit disk
%   gm_Voronoi_fcn_disk              - inverses of squared pairwise distances 
%   gm_write_min_L2norm_bnd          - writes sets of points using l_2 minimization + a boundary integral
%   gm_write_points_L2norm_bnd       - writes sets of points using l_2 minimization + a boundary integral
%   gm_write_points_Lebesgue         - writes sets of points using Lebesgue constant minimization
