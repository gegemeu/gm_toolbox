function maxL=gm_compXY_Lebesgue_func_Vdisk(x,y,w,XY);
%GM_COMPXY_LEBESGUE_FUNC_VDISK computation of the Lebesgue function on a given mesh
% for bivariate orthogonal polynomials using Vandermonde matrices, unit disk

%
% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% XY = evaluation points, x = XY(:,1), y = XY(:,2)
%
% Output:
% maxL = approximate Lebesgue constant

%
% Author G. Meurant
% March 2017
%

x = x(:);
y = y(:);

% total degree
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

V_pts = gm_vandermonde_koornwinder(XY,d);

c_pts = [x y];

V_c_pts = gm_vandermonde_koornwinder(c_pts,d);

maxL = norm(V_c_pts'\V_pts',1);







