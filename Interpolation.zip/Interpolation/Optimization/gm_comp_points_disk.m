

% computation of points for the unit disk

vt = clock;
savefile = ['temp-' date '-' num2str(vt(4)) num2str(vt(5)) num2str(ceil(vt(6)))];

pts = gm_disk_wam(500);

ideg = 0;
degmax = 17;
nmax = (degmax + 1) * (degmax + 2) / 2;
xL2_best = zeros(nmax,degmax);
yL2_best = zeros(nmax,degmax);
maxL2_best = zeros(1,degmax);
degree = zeros(1,degmax);
mu_best = zeros(1,degmax);
xL_best = zeros(nmax,degmax);
yL_best = zeros(nmax,degmax);
maxL_best = zeros(1,degmax);
xf_best = zeros(nmax,degmax);
yf_best = zeros(nmax,degmax);
maxLf_best = zeros(1,degmax);
initpoint = 'rad';

for deg = 17:degmax
 
 ideg = ideg + 1;
 degree(ideg) = deg;
 
 n = (deg + 1) * (deg + 2) / 2;
 w = ones(n,1) / n;
 epsi = 1e-15;
 nfev = 5000;
 nfevL = 10000;
 iprint = 0;
 
 mumax = 4;
 xmu = zeros(n,mumax);
 ymu = zeros(n,mumax);
 maxLmu = zeros(mumax,1);
 
 muu = [0., 0.1, 0.2, 0.3];
 
 % L2 minimization + refinement
 for imu = 1:mumax
  
  mu = muu(imu);
  
  [xL2,yL2,maxLm] = gm_print_points_L2norm_bnd_disk(deg,epsi,mu,iprint,nfev,initpoint);
  
  [maxL2,Psidot] = gm_compXY_Lebesgue_func_OPHL(xL2,yL2,w,pts,2);
  
  xmu(:,imu) = xL2;
  ymu(:,imu) = yL2;
  maxLmu(imu) = maxL2;
  
 end % for imu
 
 % choose the best value of mu
 [ml,I] = min(maxLmu);
 mu_b = muu(I(1));
 maxL2_best(ideg) = maxLmu(I(1));
 xL2_best(1:n,ideg) = xmu(:,I(1));
 yL2_best(1:n,ideg) = ymu(:,I(1));
 mu_best(ideg) = mu_b;
 
 % Lebesgue constant minimization using praxis + refinement
 [x_opt,y_opt,maxLp] = gm_print_points_Lebesgue_disk(deg,epsi,iprint,nfevL,xL2_best(1:n,ideg),yL2_best(1:n,ideg));
 
 % iterate once
 [x_opt,y_opt,maxLp] = gm_print_points_Lebesgue_diskR(deg,1e-30,iprint,nfevL+5000,x_opt,y_opt);
 
 xL_best(1:n,ideg) = x_opt;
 yL_best(1:n,ideg) = y_opt;
 maxL_best(ideg) = maxLp;
 
 % Lebesgue constant minimization using fminimax (A. Sommariva)
 pts_out = gm_pointset_optimization(deg,'unitdisk','fminimax','leja','lebesgue',[10],[x_opt y_opt],iprint);
 
 xf_best(1:n,ideg) = pts_out(:,1);
 yf_best(1:n,ideg) = pts_out(:,2);
 
 [maxLf,Psidot] = gm_compXY_Lebesgue_func_OPHL(pts_out(:,1),pts_out(:,2),w,pts,2);
 
 maxLf_best(ideg) = maxLf;
 
end % for deg

save(savefile);



