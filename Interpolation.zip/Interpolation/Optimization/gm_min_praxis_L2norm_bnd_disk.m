function [x,y,maxL]=gm_min_praxis_L2norm_bnd_disk(x0,y0,w,epsi,mu,iprint,nfev);
%GM_MIN_PRAXIS_L2NORM_BND_DISK looks for the min of the 2-norm of the Lagrange polynomials using gm_praxis + a boundary integral
% for the unit disk

% Bivariate orthogonal polynomials computed with Huhtanen-Larsen
% the solution is improved by restarting

% Input:
% (x0,y0) = starting points
% w = weights (sum(w) = 1)
% epsi = stopping criteria on the value of the objective function
% mu = coefficient of the boundary integral
% iprint = 1, printing
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global iprob diam
global xnode ynode weight
global xbnd ybnd wbnd
global wparm muu

if nargin <= 4
 mu = 1;
end

if nargin <= 5
 iprint = 1;
end

if nargin <= 6
 nfev = 2000;
end

ipb = 2;
iprob = ipb;
muu = mu;

if abs(sum(w) - 1) > 1e-14
 error('gm_min_praxis_L2norm_bnd_disk: The sum of the weights must be equal to 1')
end
I = find(w <= 0);
if ~isempty(I)
 error('gm_min_praxis_L2norm_bnd_disk: There are negative or zero weights')
end
wparm = w;

n = length(x0);
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;

% nodes and weights for the integral

d = ceil((-3 + sqrt(1 + 8 * n)) / 2);
d2 = 2 * d;
% You may eventually remove the next 3 lines
if d > 20
 error('gm_min_praxis_L2norm_bnd_disk: The degree is too large')
end
d2 = min(d2,40);

% unit disk
diam = 2;
xyw = gm_gqcircsect(d2,pi,0.,1);
xnode = xyw(:,1);
ynode = xyw(:,2);
weight = xyw(:,3);

% boundary nodes
nbnd = d2;
[aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
[t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
ww = ww';
% go to [0 2 pi]
tet = (t + 1) * pi;
xbnd = cos(tet);
ybnd = sin(tet);
wbnd = ww;

n = length(x0);
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;
  
% rough estimate to find a good starting point
% [xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_Lag_L2norm_bnd_disk);
% fprintf('iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
% nftot = nftot + nf;

% the number of function evaluations (last parameter) may be too small

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Lag_L2norm_bnd_disk1,10,nfev+500);

if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

% improve the solution by restarting (?)
kmax = 20;
prax_old = prax;

for k = 1:kmax
 if iprint == 1
  fprintf('---------iteration %d \n',k)
 end
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Lag_L2norm_bnd_disk1,50,nfev);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  x = xp(1:n)'; y = xp(n+1:n2)';
  
  if iprint == 1
   fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  
  if iprint == 1
   fprintf('Lebesgue constant = %0.5f \n',maxL)
   return
  end
 end % if prax
 
 if iprint == 1
  fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  prax_old = prax;
 end % if abs
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
end

% maxL = prax;
x = xp(1:n)'; 
y = xp(n+1:n2)';

% compute the Lebesgue const on a fine mesh
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);

if iprint == 1
 fprintf(' Lebesgue constant = %0.5f \n',maxL)
end

end % function

function f=const(x,y,X);

f = 1;

end


