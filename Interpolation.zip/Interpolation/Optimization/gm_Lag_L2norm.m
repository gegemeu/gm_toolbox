function f=gm_Lag_L2norm(X);
%GM_LAG_L2NORM function for the minimization of the l2-norm of the Lagrange function

% computes the integral of the squares of the Lagrange polynomials
% using Padua cubature rules

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global Aparm alpparm wparm
global iprob
global xnode ynode weight

if isempty(X)
 f = 1e16;
 return
end

% the length of X must be even
nX = length(X);
n = nX / 2;

% keep the points inside the domain
ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

% points and weights for the discrete inner product
x = X(1:n); 
y = X(n+1:nX);
x = x'; 
y = y';
w = wparm;

% values at the inner product points
d = ceil((-3 + sqrt(1 + 8 * n)) / 2); % total degree
[Phi,A,xy] = gm_OPHL(d,x,y,w);
Aparm = A;

% coefficients of the expansion
alp = Phi' * diag(w);
alpparm = alp;

X = X';

fv = gm_Lag_L2norm_squared(xnode,ynode,X);
Int = fv * weight;

f = sqrt(Int);

