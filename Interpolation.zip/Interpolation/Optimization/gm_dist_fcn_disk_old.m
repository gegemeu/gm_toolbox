function f=gm_dist_fcn_disk_old(X);
%GM_DIST_FCN_DISK_OLD inverses of squared pairwise distances 

% the first point is fixed

%
% Author G. Meurant
% February 2017
%

global iprob

iprob = 2;

% for the evaluation we have to put back the first point = (0,1)

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

nX = length(X);
n = nX / 2;

x = [0 X(1:n)];
y = [1 X(n+1:nX)];

% [dmat,dmati] = gm_dist_mat_sq(x,y);
[dmat,dmati] = gm_dist_mat(x,y);
dmati = dmati.^6;
 
f = sum(sum(dmati));

% f = max(max(dmati));
  


