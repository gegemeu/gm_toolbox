function [x,y,Psinp,maxL,x_opt,y_opt]=gm_Leb_ref_disk(x,y,w,x_opt,y_opt,maxL_old,it,iprint,ow);
%GM_LEB_REF_DISK Refinement algorithm for the disk, iterates over a set of points by
% replacing in turn all the points by the max of (an approximation of) the Lebesgue function

% Input:
% (x,y) = coordinates of the points
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do 
%                 not improve the Lebesgue constant)
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% iprint = 1 with printing and vizualization
% ow = order of the WAM
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global xparm yparm wparm
global iprob

global WAM

if nargin <= 8
 ow = 100;
end


if nargin <= 7
 iprint = 1;
end

n = length(x);
deg = ceil((-3 + sqrt(1 + 8 * n)) / 2);
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;

WAM1 = gm_disk_wam(ow);

Psinp = 0;

maxL_old_old = maxL_old;
x_old = x_opt;
y_old = y_opt;
min_maxL = realmax;

for k = 1:it
 if iprint == 1
  fprintf('\n ----------iteration %d \n',k)
 end
 
 % for all points in turn
 for i = 1:n
  % find an approximate max of the Lebesgue function
  % remove the point i
  X = [x(1:i-1); x(i+1:n)]; 
  Y = [y(1:i-1); y(i+1:n)];
  xparm = x; 
  yparm = y; 
  wparm = w;
  ww = [w(1:i-1); w(i+1:n)];
  ww = ww /sum(ww);
  % if wam(100) is not enough, compute the WAM
  % WAM = gm_disk_wam(300);
  % computation of the Lebesgue constant without the point
%   [Psinp,maxLL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(X,Y,ww,npts,2);
  [maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(X,Y,ww,WAM1,2);
  XY = WAM1;
  % max of the function
  [minP,J] = max(Psidot);
  % new point to add
  xx = XY(J(1),1); 
  yy = XY(J(1),2);
  
  % check if the point is inside the unit disk
  if xx^2+yy^2 <= 1 
   x(i) = xx;
   y(i) = yy;
  else
   fprintf('\n point outside (%g, %g), %22.55e > 1 return \n',xx,yy,xx^2+yy^2)
   x = x_old;
   y = y_old;
   x_opt = x;
   y_opt = y;
   maxL = maxL_old_old;
   return
  end
  
  % computation of the new Lebesgue constant
%   V_pts = gm_vandermonde_koornwinder(WAM1,deg);
%   c_pts = [x y];
%   V_c_pts = gm_vandermonde_koornwinder(c_pts,deg);
%   maxL = norm(V_c_pts'\V_pts',1);
  
%   [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,2);
  [maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,WAM1,2);
  
  if abs(maxL - 1) < 1e-10
   maxL = realmax;
  end
  
  if maxL < maxL_old
   % we have some improvement, keep the configuration
   maxL_old = maxL;
   x_opt = x; 
   y_opt = y;
  else
   maxL = maxL_old;
  end % if maxL
  min_maxL = min(min_maxL,maxL);
  
 end % for i
 
 if iprint == 1
  % viz and print
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,npts,iprob);
  fprintf(' New approximate Lebesgue constant = %0.10f \n',maxL)
  pause
 end % if iprint
 
 if maxL_old < maxL_old_old
  x = x_opt;
  y = y_opt;
 end
 
end % for k (end of iterations)

if min_maxL >= maxL_old_old
 % restore the optimal points
 x = x_old; 
 y = y_old;
 maxL = maxL_old_old;
 x_opt = x_old;
 y_opt = y_old;
end % if maxL

if iprint == 1
 % viz on a fine mesh
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
 
%  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
  WAM2 = gm_disk_wam(100);
 [maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,WAM2,2);
 fprintf('\n Final Lebesgue constant = %0.10f \n',maxL)
 
 figure
 
 % plot the points
 gm_plot_points_disk([x_opt y_opt]);
 
end % if iprint





