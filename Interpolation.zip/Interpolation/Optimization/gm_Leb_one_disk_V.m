function [x,y,Psinp,maxL,x_opt,y_opt]=gm_Leb_one_disk_V(x,y,w,x_opt,y_opt,maxL_old,it,epsi,iprint,nfev);
%GM_LEB_ONE_DISK_V replaces the max by an optimization of the Lebesgue function
% minimizes over the position of one point

% use the Vandermonde determinants

% Input:
% (x,y) = coordinates of the points
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do
%                 not improve the Lebesgue constant
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% epsi = convergence criterion
% iprint = 1 with printing and vizualization
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% July 2014
% Updated August 2015
%

global xparm yparm wparm nfparm
global iprob

global WAM
global V_pts

xop = x_opt;
yop = y_opt;
maxL_old_old = maxL_old;

if nargin <= 7
 epsi = 1e-3;
end

if nargin <= 8
 iprint = 1;
end

if nargin <= 9
 nfev = 2000;
end

if iprint == 1
 fprintf('\n Init Lebesgue constant = %0.5f \n',maxL_old)
end

n = length(x);
wparm = w;

% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;
Leb_old = maxL_old;

deg = ceil((-3 + sqrt(1 + 8 * n)) / 2);
WAM = gm_disk_wam(300);
% compute V_pts
V_pts = gm_vandermonde_koornwinder(WAM,deg);

for k = 1:it
 if iprint == 1
  fprintf('\n----------iteration %d \n',k)
 end
 
 % find the max on a fine mesh
 % this may not be enough to compute the L-constant reliably!!!!!!
 if iprint == 1
  [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,200,iprob);
 end % if iprint
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
 [maxi,I] = max(Psidot);
 
 if iprint == 1
  fprintf('\n max Lebesgue function = %0.5f \n',maxi)
 end
 xx = XY(I(1),1);
 yy = XY(I(1),2);
 
 % find the closest point
 dist = (x - xx).^2 + (y - yy).^2;
 [mindist,I] = sort(dist);
 i = I(1);
 
 % remove the point i, add it at the end
 % except if it is (0,1)
 if x(i) ~= 0 || y(i) ~= 1
  x = [x(1:i-1); x(i+1:n); x(i)];
  y = [y(1:i-1); y(i+1:n),; y(i)];
  w = [w(1:i-1); w(i+1:n),; w(i)];
 end
 
 % minimize as a function of the coordinates of the last point
 if x(n) ~= 0 || y(n) ~= 1
  n2 = 2;
  X0 = [x(n) y(n)];
  xparm = x;
  yparm = y;
  wparm = w;
  
  [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,2,n2,X0,@gm_Lebesgue_func1_V,50,nfev);
  if iprint == 1
   fprintf('\n iter = %d, nfunc = %d, exitflag = %d, Lebesgue constant = %0.5f \n',iter,nf,exitflag,prax)
  end
  maxL = prax;
  
  % may not be necessary!!!!!
  % replace x(i),y(i)
  x(n) = xp(1);
  y(n) = xp(2);
  
  if prax < maxL_old
   % keep the configuration
   maxL_old = maxL;
   x_opt = x;
   y_opt = y;
  end % if prax
  
  if k > 3
   % check convergence
   if (abs(maxL - Leb_old) / Leb_old) <= epsi
    if iprint == 1
     fprintf('\n convergence it = %d, Lebesgue constant = %0.5f\n',k,maxL)
    end
    break
   else
    Leb_old = maxL;
   end
  else
   leb_old = maxL;
  end % if k
  
 end % if x
 
 % just for viz
 if iprint == 1
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
  fprintf(' Approximate Lebesgue constant = %0.5f \n',maxLL)
  drawnow
  pause
 end % if iprint
 
end % for k

% recompute the Lebesgue constant on a fine mesh
% this may not be enough to compute the L-constant reliably!!!!!!
if iprint == 1
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,200,iprob);
 fprintf('\n Final Lebesgue constant (fine mesh) = %0.5f \n',maxL)
 
 figure
 
 plot(x,y,'*')
 title(['Lebesgue constant = ' num2str(maxL)])
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
end % if iprint

if maxL >= maxL_old_old
 % restore the optimal points
 x = xop;
 y = yop;
 x_opt = xop;
 y_opt = yop;
 maxL = maxL_old_old;
 if iprint == 1
  fprintf('\n Final Lebesgue constant (restored) = %0.5f \n',maxL)
 end
end % if maxL



