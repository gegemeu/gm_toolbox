
% computation of the Lebesgue constants for the Carnicer-Godes points

nw = 500;
% we compute on a WAM of order 500 (250501 points)
pts = gm_disk_wam(nw);

fprintf('\n Carnicer-Godes, WAM of order %d, %d points \n',nw,size(pts,1))


for deg = 1:20
 n = (deg + 1) * (deg + 2) / 2;
 % Carnicer-Godes points (standard)
[ptscg,radius] = gm_car_go_disk(deg,'cg');
x = ptscg(:,1);
y = ptscg(:,2);
w = ones(n,1) / n;

% % Huhtanen-Larsen
% [maxL_OPHL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);

% Vandermonde
maxL_cg = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);

 % Carnicer-Godes points (optimized)
[ptscg,radius] = gm_car_go_disk(deg,'opt');
x = ptscg(:,1);
y = ptscg(:,2);

% % Huhtanen-Larsen
% [maxL_OPHL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);

% Vandermonde
maxL_opt = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);

fprintf('\n %3d cg = %12.7f, opt = %12.7f, diff = %12.5e \n',deg,maxL_cg,maxL_opt,abs(maxL_cg-maxL_opt))

end % for deg

