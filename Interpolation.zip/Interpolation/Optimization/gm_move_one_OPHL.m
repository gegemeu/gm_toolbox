function [x,y,Psinp,maxL,x_opt,y_opt]=gm_move_one_OPHL(k,x,y,x_opt,y_opt,maxL_old,viz);
%GM_MOVE_ONE_OPHL moves one point to the max of (an approximation of) the Lebesgue function

% We assume equal weights

% Input:
% k = number of the point
% (x,y) = current points
% (x_opt,y_opt) = best points so far
% maxL_old = best Lebesgue constant so far
% viz = 1 visualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = new Lebesgue constant
% (x_opt,y_opt) = new best points

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global iprob

n = length(x);
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;
% equal weights
w = ones(n,1) / n;

% compute the values of the Lebesgue function at XY
if viz ~= 0
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
end

% max of the Lebesgue function at XY
[maxP,I] = max(Psidot);

if maxL < maxL_old
 % keep the configuration
 maxL_old = maxL;
 x_opt = x; 
 y_opt = y;
end % if maxL

% replace (x(k),y(k)) by a point at the max
xI = XY(I(1),1); 
yI = XY(I(1),2);
x(k) = xI; 
y(k) = yI;

% recompute the Lebesgue function
if viz ~= 0
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 fprintf(' Approximate Lebesgue constant =  %0.5f \n',maxL)
 pause
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
end % if viz

if maxL >= maxL_old
 % restore the optimal points
 x = x_opt; 
 y = y_opt;
 maxL = maxL_old;
end % if maxL



