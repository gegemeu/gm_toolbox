function f=gm_Lag_L2norm_squared(xx,yy,X);
%GM_LAG_L2NORM_SQUARED sum of the squares of the Lagrange polynomials at xx,yy

% X contains the points defining the inner product
%

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global Aparm alpparm
global wparm

xx = xx(:); yy = yy(:);

% the length of X must be even
nX = length(X);
n = nX / 2;

w = wparm;

% total degree
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

A = Aparm;
alp = alpparm;

% compute the values of the orthogonal polynomials
Psi = gm_OPHL_eval(d,xx,yy,w,A,1);

nP = size(Psi,1);

% np number of the Lagrange polynomial

% f = 0;
f = zeros(nP,1);

for np = 1:n
 sk = zeros(nP,1);
 for k = 1:n
  sk = sk + alp(k,np) * Psi(:,k);
 end % for k
 
 f = f + sk.^2;
end % for np

for i = 1:nP
 if gm_indic_func([xx(i); yy(i)]) == 0
  % the point is outside the domain
  f(i) = 0;
 end % if
end % for i

f = f';

