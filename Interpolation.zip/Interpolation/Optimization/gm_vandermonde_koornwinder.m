function V=gm_vandermonde_koornwinder(pts,deg,a)
%GM_VANDERMONDE_KOORNWINDER Vandermonde matrix for the unit disk

%
% KOORNWINDER TYPE II BASIS ON THE UNIT DISK "B([0,0],1)".
%
%--------------------------------------------------------------------------
% Input:
% pts = SETS OF POINTS OF THE UNIT DISK "B([0,0],1)"
% deg = VANDERMONDE MATRIX UP TO DEGREE d INCLUDED
% a =   KOORNWINDER EXPONENT (DEFAULT "a=-0.5")
%
% Output:
% V = VANDERMONDE MATRIX w.r.t. THE KOORNWINDER TYPE II BASIS ON THE SET pts.
%
%--------------------------------------------------------------------------

% simplified version of a code by A. Sommariva
% Feb 2017


if nargin < 3
 a = 0;
end

nd = (deg + 1) * (deg + 2) / 2;

mod_op_type = 3; % ORTHONORMAL JACOBI.
op_type = 3; % ORTHONORMAL JACOBI.

x = pts(:,1); y = pts(:,2);
nx = size(pts,1);

c = sqrt(1 - x.^2);
t = y;

a1 = a; b1 = a;

ab = gm_r_jacobi(deg,a1,b1);
V1 = eval_mod_op(deg,ab,a1,b1,t,c,mod_op_type);

t = x;
V = zeros(nx,nd);
j = 1;

for k = 0:deg
 
 a2 = a + k + 0.5;
%  b2 = a + k + 0.5;
 b2 = a2;
 
 if deg-k > 0
  ab2 = gm_r_jacobi(deg-k,a2,b2);
 else
  ab2 = [];
 end % if
 
 V2loc = eval_op(deg-k,ab2,t,a2,b2,op_type);
 V1loc = repmat(V1(:,k+1),1,size(V2loc,2));
 sv = size(V1loc,2);
 
 V(:,j:j+sv-1) = V1loc .* V2loc;
 j = j + sv;
 
end % for


function V=eval_op(deg,ab,x,a,b,type)

L = size(x,1);

if deg > 0
 aa = ab(:,1);
 bb = ab(:,2);
else
 ab = gm_r_jacobi(1,a,b);
 aa = [];
 bb = [];
end

% ORTHONORMAL JACOBI POLYNOMIALS.
V = [zeros(L,1) (1/sqrt(ab(1,2)))*ones(L,1)]; % "ab(1,2)" IS "int_-1^1 w(x) dx".
[cn,co] = c_orthnrm(deg,a,b);

for ii = 1:deg
 Vloc = cn(ii) * (x-aa(ii)) .* V(:,ii+1) - co(ii) * bb(ii) * V(:,ii);
 V = [V Vloc];
end % for ii

V = V(:,2:end);


function [cn,co]=c_orthnrm(ade,a,b)

[cn_st,co_st] = c_standard(ade,a,b);

ab = gm_r_jacobi(1,a,b);
an0 = ab(1,2);

n = (1:ade)';

if length(n) > 0
 if abs(b) > 0
  anloc = (2^(a + b + 1)) .* gamma(n+a+1) .* gamma(n+b+1) ./ ((2 * n + a + b + 1) .* gamma(n + a + b + 1) .* gamma(n + 1));
 else
  anloc = 2^(a + b + 1) ./ (2 * n + a + b + 1);
 end % if abs
else
 anloc = [];
end % if length

an=[an0; anloc];

an = an.^(-1/2);
an_rat = an(2:end,:) ./ an(1:end-1,:);
cn = cn_st .* an_rat;
co = [1; cn(2:end,:) .* cn(1:end-1,:)];


function [cn,co]=c_standard(deg,a,b)

s = a + b;

% INITIALIZATION TO AVOID SOME POSSIBLE OVERFLOW PROBLEMS FOR NEGATIVE s
if (deg > 0)
 cn1 = 0.5 * gamma(2 + s + 1) / gamma(s + 2);
else
 cn1 = [];
end

n = 2:deg;
n = n';

if (abs(s-floor(s)) > 0)
 cnloc = (1 ./ (2 * n)) .* (gamma(2 * n +s + 1) ./ gamma(2 * n +s - 1)) .* (gamma(n + s) ./ gamma(n +s + 1));
else
 cnloc = (1 ./ (2 * n)) .* (2 * n + s) .* (2 * n + s - 1) ./ (n + s);
end

cn = [cn1; cnloc];

co = [1; cn(2:end,:).*cn(1:end-1,:)];


function V=eval_mod_op(deg,ab,a,b,t,c,type)

L = size(t,1);
aa = ab(:,1);
bb = ab(:,2);

% ORTHONORMAL JACOBI POLYNOMIALS.
V = [zeros(L,1) (1 / sqrt(ab(1,2))) * ones(L,1)]; % "ab(1,2)" IS "int_-1^1 w(x) dx".
[cn,co] = c_orthnrm(deg,a,b);

for ii = 1:deg
 Vloc = cn(ii) * (t - c .* aa(ii)) .* V(:,ii+1) - (c.^2) * co(ii) * bb(ii) .* V(:,ii);
 V = [V Vloc];
end

V = V(:,2:end);














