function [files,maxL]=gm_files_LebesgueM(ipb,iprint,viz);
%GM_FILES_LEBESGUEM computes the Lebesgue constant for files related to one problem

% Warning: the folder must contain only files related to Lebesgue constant minimization!

% Input:
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1, with printing
% viz = 1, with plots of maxL vs the degree
%
% Output:
% files = ordered list of files
% maxL = values of the Lebesgue constant

%
% Author G. Meurant
% August 2015
%

% You might have to change this
fpath = 'C:\D\new_mfiles\gm_toolbox\Interpolation\PointsM\';

cd(fpath);

switch ipb
 
 case 1
  Prob = 'square';
  
 case 2
  Prob = 'disk';
  
 case 3
  Prob = 'Lshape';
  
 case 4
  Prob = 'triangle';
  
 case 5
  Prob = 'dbubble';
  
 case 6
  Prob = 'ellipse';
  
 case 7
  Prob = 'hellipse';
  
 otherwise
  error('gm_files_Lebesgue: Wrong value of ipb')
end % switch

% get the file names
files = ls;
% remove . and ..
files = files(3:end,:);
nfiles = size(files,1);
nchar = size(files,2);

if iprint == 1
 fprintf('\n There are %d files in the folder \n\n',nfiles)
end

% decode the file names
Pb = zeros(nfiles,nchar);
Ipb = zeros(1,nfiles);
Degree = zeros(1,nfiles);
Type = zeros(nfiles,nchar);
for k = 1:nfiles
 [pbb,ipbb,degreeb,typeb] = gm_decode_fnameM(files(k,:));
 Pb(k,1:size(pbb,2)) = pbb;
 Ipb(k) = ipbb;
 Degree(k) = degreeb;
 Type(k,1:size(typeb,2)) = typeb;
end % for k

% find the files related to problem ipb
I = find(Ipb == ipb);
if isempty(I)
 error('gm_files_LebesgueM: There is no file related to problem ipb')
end
Pb = Pb(I,:);
Degree = Degree(I);
Type = Type(I,:);
files = files(I,:);

if iprint == 1
 fprintf(' There are %d files related to the %s problem \n\n',size(files,1),Prob)
end

n = length(Degree);
maxL = zeros(n,1);

ms = 1;
me = n;
for k = ms:me
 if viz == 1
  mm = me - ms + 1;
  mL2 = zeros(mm,1);
  mLr = zeros(mm,1);
  mLp = zeros(mm,1);
  deg = zeros(mm,1);
  kk = 1;
 end % if
 % get the points and compute the Lebesgue constant
 % this may not be enough to compute the L-constant reliably!!!!!!
 maxLeb = gm_read_LebesgueM(files(k,:),200,ipb,0);
 maxL(k) = maxLeb;
end % for k
% sort by degree
J = [ms:me];
[d,I] = sort(Degree(ms:me),'ascend');
I = J(I);
Degree(ms:me) = Degree(I);
Type(ms:me,:) = Type(I,:);
files(ms:me,:) = files(I,:);
maxL(ms:me) = maxL(I);

if iprint == 1
 fprintf('\n\n %s  \n\n',Prob)
end

% separate the degrees
ds = ms;
loop2 = 1;
iloop = 0;
while loop2 == 1
 iloop = iloop + 1;
 de = me;
 for k = ms:me
  if Degree(k) > Degree(ds)
   de = k - 1;
   break
  end % if
 end % for k
 
 % sort the file types (maximum = 3 files) for a given degree
 it = zeros(3,1);
 j = 1;
 for k = ds:de
  if Type(k,1) == 109
   % Lebesgue
   it(j) = k;
   j = j + 1;
   break
  end % of
 end % for k
 for k = ds:de
  if Type(k,1) == 114
   % ref
   it(j) = k;
   j = j + 1;
   break
  end % if
 end % for k
 for k = ds:de
  if Type(k,1) == 49
   % 1p
   it(j) = k;
   j = j + 1;
   break
  end % if
 end % for k
 j = j - 1;
 
 maxL(ds:de) = maxL(it(1:j));
 files(ds:de,:) = files(it(1:j),:);
 Type(ds:de,:) = Type(it(1:j),:);
 
 if viz == 1
  deg(kk) = Degree(ds);
  if j == 1
   if Type(ds,1) == 109
    mL2(kk) = maxL(ds);
   elseif Type(ds,1) == 114
    mLr(kk) = maxL(ds);
   elseif Type(ds,1) == 49
    mLp(kk) = maxL(ds);
   end % if
   kk = kk + 1;
  elseif j == 2
   if Type(ds,1) == 109
    mL2(kk) = maxL(ds);
    if Type(ds,1) == 114
     mLr(kk) = maxL(ds+1);
    else
     mLp(kk) = maxL(ds+1);
    end % if
   else
    mLr(kk) = maxL(ds);
    mLp(kk) = maxL(ds+1);
   end % if
   kk = kk + 1;
  elseif j == 3
   mL2(kk) = maxL(ds);
   mLr(kk) = maxL(ds+1);
   mLp(kk) = maxL(ds+2);
   kk = kk + 1;
  end % if j
 end % if viz
 
 if iprint == 1
  for k = ds:de
   fprintf(' degree = %d, file = %s  MaxL = %g \n',Degree(k),Type(k,:),maxL(k))
  end % for k
  fprintf(' \n')
 end % if
 
 ds = de + 1;
 if ds > me
  loop2 = 0;
 end
 
end % while loop2

if viz == 1
 kk = kk - 1;
 figure
 plot(deg(1:kk),mL2(1:kk),'b-*')
 hold on
 plot(deg(1:kk),mLr(1:kk),'r-o')
 plot(deg(1:kk),mLp(1:kk),'g->')
 legend('ML','ref','1p','Location','NorthWest')
 title([Prob])
 drawnow
end % if









