function [ptsu,radius]=gm_uniform_disk(degree);
%GM_UNIFORM_DISK Uniform nodes for the unit disk

%
% Input:
% degree = total degree of the bivariate polynomials
%
% Output:
% ptsu = coordinates of the nodes
% radius = radius of the circles

% from A. Sommariva
% March 2017

% n is the degree
n = degree;

lmax = floor(n/2) + 1;
np = (n + 1) * (n + 2) / 2;
pts_pol = zeros(np,2);
radius = zeros(lmax,1);

k = 1;
for l = 1:lmax
 lcg = l - 1;
 jmax = 2 * (n - 2 * lcg) + 1;
 r = 1 -(2 * lcg /n );
 % this is to avoid having points outside of the disk
%  if abs(r - 1) < 1e-15
%   r = r - eps;
%  end
 radius(l) = r;
 theta = (2 * [0:jmax-1]' + 1) * pi / (2 * (n - 2 * lcg) + 1);
 pts_pol(k:k+jmax-1,:) = [r * ones(size(theta)) theta];
 k = k + jmax;
end % for l

rad = pts_pol(:,1); 
thet = pts_pol(:,2);
ptsu = [rad .* cos(thet) rad .* sin(thet)];






