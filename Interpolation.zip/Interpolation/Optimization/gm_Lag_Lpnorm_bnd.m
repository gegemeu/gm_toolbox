function f=gm_Lag_Lpnorm_bnd(X);
%GM_LAG_LPNORM_BND function for the minimization of the lp-norm of the Lagrange function + a boundary integral

% computes the integral of the squares of the Lagrange polynomials
% using Padua cubature rules

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global Aparm alpparm wparm
global iprob
global xnode ynode weight
global xbnd ybnd wbnd
global muu
global p

if isempty(X)
 f = 1e16;
 return
end

% the length of X must be even
nX = length(X);
n = nX / 2;

% keep the points inside the square
ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end % if

% points and weights for the discrete inner product
x = X(1:n); 
y = X(n+1:nX);
x = x'; 
y = y';
w = wparm;

% values at the inner product points
d = ceil((-3 + sqrt(1 + 8 * n)) / 2); % total degree
[Phi,A,xy] = gm_OPHL(d,x,y,w);
Aparm = A;

% coefficients of the expansion
alp = Phi' * diag(w);
alpparm = alp;

X = X';

fv = gm_Lag_Lpnorm_p(xnode,ynode,X);
Int = fv * weight;

% boundary integral
fv = gm_Lag_Lpnorm_p(xbnd,ybnd,X);
Intb = fv * wbnd;

mu = muu;

f = sqrt(Int + mu * Intb);
