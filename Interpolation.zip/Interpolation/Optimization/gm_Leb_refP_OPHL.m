function [x,y,Psinp,maxL,x_opt,y_opt]=gm_Leb_refP_OPHL(x,y,w,x_opt,y_opt,maxL_old,it,epsi,iprint);
%GM_LEB_REFP_OPHL Refinement algorithm, iterates over a set of points by
% replacing in turn all the points by the max of (an approximation of) the Lebesgue function

% We use gm_praxis to find the maximum
% Simple minded method

% Input:
% (x,y) = coordinates of the points
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do 
%                 not improve the Lebesgue constant
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% epsi = convergence criterion
% iprint = 1 with printing and vizualization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global xparm yparm wparm nfparm
global iprob

if nargin <= 7
 epsi = 1e-3;
end

if nargin <= 8
 iprint = 1;
end

if iprint == 1
 fprintf('\n Init Lebesgue constant = %0.5f \n',maxL_old)
end

n = length(x);

% this may not be enough to compute the L-constant reliably!!!!!!
npts = 50;
Leb_old = maxL_old;
maxL_old_old = maxL_old;
xop = x_opt;
yop = y_opt;

Psinp = 0;
maxLk = maxL_old;

for k = 1:it
 if iprint == 1
  fprintf('\n----------init iteration %d \n',k)
 end
 
 % find the max with praxis
 xparm = x'; 
 yparm = y'; 
 wparm = w;
 [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_OPHL(1e-2);
 % find the point i closest to the max
 dist = (x - xx).^2 + (y - yy).^2;
 [mindist,I] = sort(dist);
 i = I(1);
 
 % remove the point i
 X = [x(1:i-1); x(i+1:n)]; 
 Y = [y(1:i-1); y(i+1:n)];
 ww = [w(1:i-1); w(i+1:n)];
 ww = ww /sum(ww);
 xparm = X'; 
 yparm = Y'; 
 wparm = ww;
 % rough new max using praxis
 [xx,yy,maxLL,nfleb] = gm_max_praxis_Leb_OPHL(1e-2);
 
 % check if the max is inside the domain
 ind = gm_indic_func([xx yy]);
 if ind == 0
  xx = x(i);
  yy = y(i);
 end
 
 % replace x(i),y(i) by the new max
 x(i) = xx; 
 y(i) = yy;
 
 % the following may not be necessary
 xparm = x'; 
 yparm = y'; 
 wparm = w;
 % rough max using praxis
 [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_OPHL(1e-2);
 maxLk = min(maxLk,maxL);
 
 if maxL < maxL_old
  % we have some improvement, keep the configuration
  maxL_old = maxL;
  x_opt = x; 
  y_opt = y;
 end % if maxL
 
 if k > 3
  % check convergence
  if (abs(maxL - Leb_old) / Leb_old) <= epsi
   if iprint == 1
    fprintf('\n convergence init %d, Leb constant = %0.5f\n',k,maxL)
   end
   break
  else
   Leb_old = maxL;
  end % if abs
 else
  Leb_old = maxL;
 end % if k
 
 % just for viz
 
 if iprint == 1
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,npts,iprob);
  fprintf('Approximate Lebesgue constant = %0.5f \n',maxLL)
  drawnow
  %   pause
 end % if iprint
 
end % for k

if maxL >= maxL_old
 % restore the optimal points
 x = x_opt; 
 y = y_opt;
 maxL = maxL_old;
 Leb_old = maxL;
end % if maxL

if iprint == 1
 fprintf('\n Init Lebesgue constant = %0.5f \n',maxL_old)
end

% look for all points now

Leb_old = 1e16;

if iprint == 1
 fprintf('\n end init \n')
end

for k = 1:it
 if iprint == 1
  fprintf('\n----------iteration %d \n',k)
 end
 iconv = 0;
 maxLk = maxL;
 for i = 1:n
  % find an approximate max of the Lebesgue function
  % remove the point i
  X = [x(1:i-1); x(i+1:n)]; 
  Y = [y(1:i-1); y(i+1:n)];
  ww = [w(1:i-1); w(i+1:n)];
  ww = ww /sum(ww);
  xparm = X'; 
  yparm = Y'; 
  wparm = ww;
  % rough max using praxis
  [xx,yy,maxLL,nfleb] = gm_max_praxis_Leb_OPHL(1e-2);
  
  % check if the max is inside the domain
  ind = gm_indic_func([xx yy]);
  if ind == 0
   xx = x(i);
   yy = y(i);
  end
  
  x(i) = xx; 
  y(i) = yy;
  
  % the following may not be necessary
  xparm = x'; 
  yparm = y'; 
  wparm = w;
  % rough new max using praxis
  [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_OPHL(1e-2);
  maxLk = min(maxLk,maxL);
  
  if maxL < maxL_old
   % we have some improvement, keep the configuration
   maxL_old = maxL;
   x_opt = x; 
   y_opt = y;
  end % if maxL
  
 end % for i
 
 % do at least 3 iterations
 if k > 3
  % check convergence
  if (abs(maxL_old - Leb_old) / Leb_old) <= epsi
   if iprint == 1
    fprintf('\n convergence it = %d, Lebesgue constant = %0.5f \n',k,maxL_old)
   end
   iconv = 1;
   break
  else
   Leb_old = maxL_old;
  end % if abs
 else
  Leb_old = maxL_old;
 end % if k
 
 % just for viz
 if iprint == 1
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,npts,iprob);
  fprintf(' Approximate min Lebesgue constant = %0.5f \n',maxLL)
  drawnow
  pause
 end % if iprint
 
 if iconv == 1
  % get out of the iteration loop
  break
 end
 
end % for k

% recompute the Lebesgue constant on a fine mesh
% this may not be enough to compute the L-constant reliably!!!!!!
if iprint == 1
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
 
 figure
 
 plot(x_opt,y_opt,'*')
 title([' Lebesgue constant = ' num2str(maxL)]) 
end % if iprint

[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
fprintf('\n Final Lebesgue constant (fine mesh) = %0.5f \n',maxL)

 if maxL >= maxL_old_old
 % restore the optimal points
 x = xop; 
 y = yop;
 x_opt = xop;
 y_opt = yop;
 maxL = maxL_old_old;
 if iprint == 1
  fprintf('\n Final Lebesgue constant (restored) = %0.5f \n',maxL)
 end
 end % if maxL



