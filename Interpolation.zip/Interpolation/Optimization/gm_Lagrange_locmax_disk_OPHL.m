function [x,y,Psinp,maxL,x_opt,y_opt]=gm_Lagrange_locmax_disk_OPHL(x,y,w,x_opt,y_opt,maxL_old,it,epsi,iprint,nfev);
%GM_LAGRANGE_LOCMAX_DISK_OPHL minimizes the Lagrange polynomials on the unit disk

% does not change much the result!

% Input:
% (x,y) = coordinates of the points
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do
%                 not improve the Lebesgue constant)
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% epsi = convergence criterion
% iprint = 1 with printing and vizualization
% nfev = approximate maximum number of function evaluations in minimization
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% March 2017
%

global xparm yparm wparm nfparm node xnode ynode
global iprob

global ptsw pbot ptop plef prig nr nt

global WAM V_pts

global maxLeb

xop = x_opt;
yop = y_opt;
maxL_old_old = maxL_old;

if nargin <= 7
 epsi = 1e-10;
end

if nargin <= 8
 iprint = 1;
end

if nargin <= 9
 nfev = 10000;
end

iprob = 2;

if iprint == 1
 fprintf('\n Init Lebesgue constant = %0.5f \n',maxL_old)
end

n = length(x);
wparm = w;

npts = 100;
Leb_old = maxL_old;

% WAM for the computation of the local maxima
[ptsw,pbot,ptop,plef,prig,nr,nt] = gm_disk_wam_order(200);

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,ptsw,2);

maxLeb = maxL;

if iprint == 1
 fprintf('\n Lebesgue constant on the WAM = %0.5f \n',maxL)
end

% set the approximate diameter for praxis
diam = 2;

n = length(x_opt);
n2 = 2 * (n - 1);
nftot = 0;

x = x_opt;
y = y_opt;

for k = 1:it
 if iprint == 1
  fprintf('\n----------iteration %d \n',k)
 end
 
 for knode = 1:n
  % choose the point to consider
  node = knode;
  if iprint == 1
   fprintf('\n\n----------------------------------------')
   fprintf('\n point %d \n\n',node)
  end
  
  % put it at the end of the list of points
  xnode = x(node);
  ynode = y(node);
  x0 = [x(1:node-1); x(node+1:n)];
  x = [x0; xnode];
  y0 = [y(1:node-1); y(node+1:n)];
  y = [y0; ynode];
  
  % minimize as a function of the coordinates of the points [x0 y0]
  
  minimizer = 'praxis';
    
  xparm = x;
  yparm = y;
  wparm = w;
  
  if strcmpi(minimizer,'praxis') == 1
   X0 = [x0 y0];
   [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,X0,@gm_Lagrangemax_func,50,nfev);
   
   x = [xp(1:n-1)'; xnode] ;
   y = [xp(n:n2)'; ynode];
   
  else
   % this solver is in the Matlab optimization toolbox
   X0 = [x0; y0];
   options = optimset('MaxIter',fix(nfev/10),...
    'MaxFunEvals',nfev,...
    'Display','off',...
    'TolX',100.,...
    'TolFun',epsi,...
    'DiffMaxChange',10.);
   
   A = []; B = []; Aeq = []; Beq = []; LB = []; UB = [];
   
   xp = fminimax(@gm_Lagrangemax_func1,X0,A,B,Aeq,Beq,LB,UB,[],options);
   
   x = [xp(1:n-1); xnode];
   y = [xp(n:n2); ynode];
   nf = 0;
   iter = 0;
   exitflag = 0;
   prax = 0;
   
  end % if minimizer
  
 end % for knode
 
 % compute the Lebesgue constant
 [maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);
 
 if maxL < maxL_old
  % keep the configuration
  maxL_old = maxL;
  x_opt = x;
  y_opt = y;
 end % if maxL
 
 if iprint == 1
  fprintf('\n iter = %d, nfunc = %d, exitflag = %d, value = %g, Lebesgue constant = %0.5f \n',iter,nf,exitflag,prax,maxL)
 end
 nftot = nftot + nf;
 
 if k > 3
  % check convergence
  if (abs(maxL - Leb_old) / Leb_old) <= epsi
   if iprint == 1
    fprintf('\n convergence it = %d, Lebesgue constant = %0.5f\n',k,maxL)
   end
   break
  else % if abs
   Leb_old = maxL;
  end
 else
  Leb_old = maxL;
 end % if k
 
 % just for viz
 if iprint == 1
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
  fprintf(' Approximate Lebesgue constant from viz = %0.5f \n',maxLL)
  drawnow
  pause
 end % if iprint
 
end % for k

x = x_opt;
y = y_opt;

% recompute the Lebesgue constant on a fine mesh
pts = gm_disk_wam(500);
[maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,pts,2);

if iprint == 1
 fprintf('\n Final Lebesgue constant (fine mesh) = %0.5f \n',maxL)
 
 figure
 
 plot(x,y,'*')
 title(['Lebesgue constant = ' num2str(maxL)])
else
 [Psinp,maxLL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,200,iprob);
end % if iprint

if maxL >= maxL_old_old
 % no improvement of the inputs, restore the optimal points
%  x = xop;
%  y = yop;
 x_opt = xop;
 y_opt = yop;
 maxL = maxL_old_old;
 if iprint == 1
  fprintf('\n Final Lebesgue constant (restored) = %0.5f \n',maxL)
 end
end % if maxL



