function [x,y,maxL]=gm_min_praxis_Lebesgue_diskF(x0,y0,w,epsi,iprint,nfev);
%GM_MIN_PRAXIS_LEBESGUE_DISKF looks for the min of the Lebesgue constant iterating with gm_praxis
% on the unit disk

% we have the first point which is fixed at (0,1)

% Bivariate orthogonal polynomials computed with Huhtanen-Larsen
% Works also for some bounds of the Lebesgue function
% the solution is improved by restarting

% Input:
% x0,y0 = starting points
% w = weights
% epsi = stopping criteria
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global Ifunc
global iprob diam wparm

% Ifunc = 1 (or 6) Lebesgue constant, = 2 bound, = 3 norm(inv(L),1),
% = 4 upper bound, = 5 norm(inv(L-Z),1)
% this is used in gm_Leb_fcn_HL
Ifunc = 6;

% defaults

if nargin <= 4
 iprint = 1;
end

if nargin <= 5
 nfev = 2000;
end

iprob = 2;
if abs(sum(w) - 1) > 1e-14
 error('gm_min_praxis_Lebesgue_diskF: The sum of the weights must be equal to 1')
end
I = find(w <= 0);
if ~isempty(I)
 error('gm_min_praxis_Lebesgue_diskF: There are negative or zero weights')
end
wparm = w;

% set the approximate diameter
diam = 2;

% remove the first point (fixed)
n = length(x0);
x0 = x0(2:n);
y0 = y0(2:n);
n = n - 1;
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;

% the number of function evaluations (last parameter) may be too small

% rough estimate to find a good starting point
[xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_Leb_fcn_diskF_OPHL,50,nfev+500);

if iprint == 1
 fprintf(' Init, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_diskF_OPHL,50,nfev);

if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

% improve the solution by restarting (?)
kmax = 20;
prax_old = prax;

for k = 1:kmax
 if iprint == 1
  fprintf('--------iteration %d \n',k)
 end
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_diskF_OPHL,50,nfev);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  maxL = prax;
  x = [ 0; xp(1:n)']; y = [1; xp(n+1:n2)'];
  
  if iprint == 1
   fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  
  if iprint == 1
   fprintf(' Lebesgue const = %0.5f \n',maxL)
  end
  return
 end % if prax
 
 if iprint == 1
  fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  prax_old = prax;
 end % if abs
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
end

x = [0; xp(1:n)']; 
y = [1; xp(n+1:n2)'];

% this may not be enough to compute the L-constant reliably!!!!!!

% compute the Lebesgue const on a fine mesh
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);

if iprint == 1
 fprintf(' Lebesgue constant (fine mesh) = %0.5f \n',maxL)
end




