function [x,y,Psinp,maxL,x_opt,y_opt,expo]=gm_Leb_expo_disk_OPHL(deg,w,x_opt,y_opt,maxL_old,it,epsi,iprint,nfev);
%GM_LEB_EXPO_DISK_OPHL minimizes the Lebesgue function on the exponent of the radius positions

% to be done

% We use the same angles than Carnicer-Godes

% Input:
% deg = degree
% w = weights
% (x_opt,y_opt) = best points found so far (we give them back if we do
%                 not improve the Lebesgue constant
% maxL_old = best Lebesgue constant so far
% it = number of iterations
% epsi = convergence criterion
% iprint = 1 with printing and vizualization
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue constant
% (x_opt,y_opt) = best points
% expo = exponent

%
% Author G. Meurant
% March 2017
%

global xparm yparm wparm nfparm
global iprob

global ptsw pbot ptop plef prig nr nt

global degree

degree = deg;

xop = x_opt;
yop = y_opt;
maxL_old_old = maxL_old;

if nargin < 7
 epsi = 1e-10;
end

if nargin < 8
 iprint = 1;
end

if nargin < 9
 nfev = 10000;
end

iprob = 2;

if iprint == 1
 fprintf('\n Init Lebesgue constant = %0.5f \n',maxL_old)
end

wparm = w;

npts = 100;
Leb_old = maxL_old;

% WAM for the computation of the Lebesgue function
[ptsw,pbot,ptop,plef,prig,nr,nt] = gm_disk_wam_order(200);

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x_opt,y_opt,w,ptsw,2);

if iprint == 1
 fprintf('\n Lebesgue constant on the WAM = %0.5f \n',maxL)
end

% set the approximate diameter
diam = 1;

% the number of function evaluations (last parameter) may be too small

nftot = 0;

x = x_opt;
y = y_opt;

% init Carnicer-Godes
expo = 1.46;
n2 = 1;

minimizer = 'fminimax';

for k = 1:it
 if iprint == 1
  fprintf('\n----------iteration %d \n',k)
 end
 
 % minimize as a function of the coordinates of the points
 
 xparm = x;
 yparm = y;
 wparm = w;
 
 if strcmpi(minimizer,'praxis') == 1
  X0 = expo;
  [expo,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,X0,@gm_expo_func,50,nfev);
  
  % coordinates of the points
  ptsrad = gm_points_expo_disk(degree,expo);
  
  x = ptsrad(:,1);
  y = ptsrad(:,2);
  
 elseif strcmpi(minimizer,'fminimax') == 1
  % this solver in the Matlab optimization toolbox
  X0 = expo;
  options = optimset('MaxIter',fix(nfev/10),...
   'MaxFunEvals',nfev,...
   'Display','off',...
   'Diagnostics','off',...
   'TolX',epsi,...
   'TolFun',epsi,...
   'DiffMaxChange',0.1);
  
  A = []; B = []; Aeq = []; Beq = []; LB = []; UB = [];
  
  expo = fminimax(@gm_expo_func,X0,A,B,Aeq,Beq,LB,UB,[],options); 
    
  % coordinates of the points
  ptsrad = gm_points_expo_disk(degree,expo);
  
  x = ptsrad(:,1);
  y = ptsrad(:,2);
  nf = 0;
  iter = 0;
  exitflag = 0;
  prax = 0;
  
 else
   % this solver in the Matlab optimization toolbox
%   X0 = expo;
%   options = optimset('MaxIter',fix(nfev/10),...
%    'MaxFunEvals',nfev,...
%    'Display','iter-detailed',...
%    'Diagnostics','on',...
%    'TolX',epsi,...
%    'TolFun',epsi,...
%    'DiffMaxChange',0.1);
%   
%   expo = fminunc(@gm_expo_func,X0,options); 
%   
%   % coordinates of the points
%   ptsrad = gm_points_expo_disk(degree,expo);
%   
%   x = ptsrad(:,1);
%   y = ptsrad(:,2);
%   nf = 0;
%   iter = 0;
%   exitflag = 0;
%   prax = 0;
  
 end % if minimizer
 
 % compute the Lebesgue constant
 [maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);
 
 if iprint == 1
  fprintf('\n iter = %d, nfunc = %d, exitflag = %d, value = %g, Lebesgue constant = %0.5f \n',iter,nf,exitflag,prax,maxL)
 end
 nftot = nftot + nf;

 if maxL < maxL_old
  % keep the configuration
  maxL_old = maxL;
  x_opt = x;
  y_opt = y;
 end % if maxL
 
 if k > 3
  % check convergence
  if (abs(maxL - Leb_old) / Leb_old) <= epsi
   if iprint == 1
    fprintf('\n convergence it = %d, Lebesgue constant = %0.5f\n',k,maxL)
   end
   break
  else % if abs
   Leb_old = maxL;
  end
 else
  Leb_old = maxL;
 end % if k
 
 % just for viz
 if iprint == 1
  [Psinp,maxLL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
  fprintf(' Approximate Lebesgue constant = %0.5f \n',maxL)
  drawnow
  pause
 end % if iprint
 
end % for k

% recompute the Lebesgue constant on a fine mesh
pts = gm_disk_wam(500);
[maxL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);

if iprint == 1
 fprintf('\n Final Lebesgue constant (fine mesh) = %0.5f \n',maxL)
 
 figure
 
 plot(x,y,'*')
 title(['Lebesgue constant = ' num2str(maxL)])
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
end % if iprint

if maxL >= maxL_old_old
 % no improvement of the inputs, restore the optimal points
 x = xop;
 y = yop;
 x_opt = xop;
 y_opt = yop;
 maxL = maxL_old_old;
 if iprint == 1
  fprintf('\n Final Lebesgue constant (restored) = %0.5f \n',maxL)
 end
end % if maxL



