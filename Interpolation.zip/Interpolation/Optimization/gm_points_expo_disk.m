function ptsrad=gm_points_expo_disk(degree,expo);
%GM_POINTS_EXPO_DISK using Carnicer-Godes angles for the unit disk with given exponent

%
% Input:
% degree = total degree of the bivariate polynomials
% expo = exponent
%
% Output:
% ptscg = coordinates of the nodes

% from A. Sommariva
% G. Meurant
% March 2017

% n is the degree
n = degree;

lmax = floor(n/2) + 1;
np = (n + 1) * (n + 2) / 2;
pts_pol = zeros(np,2);

k = 1;
for l = 1:lmax
 lcg = l - 1;
 jmax = 2 * (n - 2 * lcg) + 1;
 r = 1 -(2 * lcg /n )^expo;
 theta = (2 * [0:jmax-1]' + 1) * pi / (2 * (n - 2 * lcg) + 1);
 pts_pol(k:k+jmax-1,:) = [r * ones(size(theta)) theta];
 k = k + jmax;
end % for l

rad = pts_pol(:,1); 
thet = pts_pol(:,2);
ptsrad = [rad .* cos(thet) rad .* sin(thet)];

