function [maxL,xmax,ymax]=gm_refine_maxL(x,y,w,iprint,nw);
%GM_REFINE_MAXL mesh refinement to compute the Lebesgue constant

%
% Input:
% x,y = coordinates of the points defining the inner product
% w = weights
% iprint = 1, with printing
% nw = order of the WAM
%
% Output:
% maxL = Lebesgue constant
% xmax,ymax = coordinates of the point giving the max
%

%
% Author G. Meurant
% March 2017
%

% find the local maxima
[stdev,locmax,valmax,xloc,yloc,vpts] = gm_find_locmax(x,y,w,iprint,nw);

nloc = length(locmax);
xmax = zeros(nloc,1);
ymax = zeros(nloc,1);

radloc = 0.01;
pts = gm_disk_wam_radius(100,radloc);
npts = size(pts,1);

maxL = 0;

for k =1:nloc
 xl = xloc(k);
 yl = yloc(k);
 % set up a WAM around that point
 ptsloc = pts + [xl*ones(npts,1) yl*ones(npts,1)];
 % check if the points are within the unit disk
 p2 = ptsloc(:,1).^2 + ptsloc(:,2).^2;
 I = find(p2 > 1);
 ptsloc(I,1) = xl;
 ptsloc(I,2) = yl;
 % compute the Lebesgue constant for these points
 [maxLloc,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsloc,2);
 [maxloc,I] = max(vpts);
 if maxLloc > maxL
  maxL = maxLloc;
 end % if maxloc
 xmax(k) = ptsloc(I(1),1);
 ymax(k) = ptsloc(I(1),2);
end % for k


 
 
 
 
 