function [x,y,maxL]=gm_min_praxis_Lebesgue_disk(x0,y0,w,epsi,iprint,nfev);
%GM_MIN_PRAXIS_LEBESGUE_DISK looks for the min of the Lebesgue constant iterating with gm_praxis
% on the unit disk

% Bivariate orthogonal polynomials 
% Works also for some bounds of the Lebesgue function
% the solution is improved by restarting

% Input:
% x0,y0 = starting points
% w = weights
% epsi = stopping criteria
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global WAM
global V_pts

global iprob diam wparm

% defaults

if nargin <= 4
 iprint = 1;
end

if nargin <= 5
 nfev = 2000;
end

n = length(x0);
deg = ceil((-3 + sqrt(1 + 8 * n)) / 2); % total degree
d5 = ceil(deg / 5);

iprob = 2;
if abs(sum(w) - 1) > 1e-14
 error('gm_min_praxis_Lebesgue_disk: The sum of the weights must be equal to 1')
end
I = find(w <= 0);
if ~isempty(I)
 error('gm_min_praxis_Lebesgue_disk: There are negative or zero weights')
end
wparm = w;

% set the approximate diameter
diam = 2;

% the number of function evaluations (last parameter) may be too small

nw = 100;
WAM = gm_disk_wam(nw);
V_pts = gm_vandermonde_koornwinder(WAM,deg);

n = length(x0);
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;

% % rough estimate to find a good starting point
% [xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_Leb_fcn_disk_OPHL,50,nfev+500);
% 
% if iprint == 1
%  fprintf(' Init, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
% end
% nftot = nftot + nf;

kmax = 20;
xp = X0;
if iprint == 1
 fprintf('\n start of gm_praxis, max iterations = %d, nfunc max = %d \n\n',kmax,nfev)
end

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_disk_OPHL,50,nfev);

if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

best_prax = prax;
best_xp = xp;

% improve the solution by restarting (?)
prax_old = prax;

% nw = ceil(30 * d5 * 10);
% WAM = gm_disk_wam(nw);
% V_pts = gm_vandermonde_koornwinder(WAM,deg);

for k = 1:kmax
 if iprint == 1
  fprintf('--------iteration %d \n',k)
 end
 
 nw = ceil(30 * d5 * k / 2);
 nw = min(nw,200);
%  nw = 200;
 WAM = gm_disk_wam(nw);
 V_pts = gm_vandermonde_koornwinder(WAM,deg);
 
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Leb_fcn_disk_OPHL,50,nfev);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  maxL = prax;
  x = xp(1:n)'; y = xp(n+1:n2)';
  
  if iprint == 1
   fprintf(' nw = %d, nb wam = %d, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',nw,size(WAM,1),iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  
  if iprint == 1
   fprintf(' Lebesgue const = %0.5f \n',maxL)
  end
  return
 end % if prax
 
 if prax < best_prax && nw > 100
  best_prax = prax;
  best_xp = xp;
 end % if
 
 if iprint == 1
  fprintf(' nw = %d, nb wam = %d, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',nw,size(WAM,1),iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  if prax > prax_old
   % no improvement, compute a new rough starting point
   [xp,prax,iter,nf,exitflag] = gm_praxis(1e-3,1e-3,diam,n2,xp,@gm_Leb_fcn_disk_OPHL,50,nfev);
   nftot = nftot + nf;
   if iprint == 1
    fprintf(' restart: nw = %d, nb wam = %d, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',nw,size(WAM,1),iter,nf,exitflag,prax)
   end
  end % if prax
  prax_old = prax;
 end % if abs
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
 fprintf('\n best maxL = %0.5f \n',best_prax)
end

xp = best_xp;

x = xp(1:n)'; 
y = xp(n+1:n2)';

% this may not be enough to compute the L-constant reliably!!!!!!

% compute the Lebesgue const on a fine mesh
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);

if iprint == 1
 fprintf(' Lebesgue constant (fine mesh) = %0.5f \n',maxL)
end




