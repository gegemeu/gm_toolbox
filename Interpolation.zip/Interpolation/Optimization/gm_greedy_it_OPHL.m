function [x,y,Psinp,maxL,x_opt,y_opt]=gm_greedy_it_OPHL(x,y,x_opt,y_opt,maxL_old,it,viz,random);
%GM_GREEDY_IT_OPHL iterates over a set of points by selecting the max
% of (an approximation of) the Lebesgue function at each step which replaces the min

% We assume equal weights

% Input:
% (x,y) = coordinates of points
% (x_opt,y_opt) = best points so far
% maxL_old = Lebesgue const
% it = number of iterations
% viz = 1 visualization
% random = 1 perturb the result for next time
%
% Output:
% (x,y) = new points
% Psinp = values of the Lebesgue function
% maxL = Lebesgue const
% (x_opt,y_opt) = best points

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global iprob

% default
if nargin == 7
 random = 0;
end

n = length(x);
% this may not be enough to compute the L-constant reliably!!!!!!
npts = 100;
w = ones(n,1) / n;
d = ceil((-3 + sqrt(1 + 8 * n)) / 2); % total degree
rep_old = [realmax realmax];

for k = 1:it
 % compute the values of the Lebesgue function at XY
 if viz ~= 0
  [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,npts,iprob);
  fprintf(' Lebesgue const = %0.5f \n',maxL)
 else
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,npts,iprob);
 end % if viz
 
 if maxL < maxL_old
  % keep the configuration
  maxL_old = maxL;
  x_opt = x; 
  y_opt = y;
 end % if maxL
 
 [Psi,A] = gm_OPHL(d,x,y,w);
 % max of the Lebesgue function at XY
 [maxP,I] = max(Psidot);
 % values of the Lebesgue function at (x,y)
 % coefficients of the expansion
 alp = Psi' * diag(w);
 np = size(Psi,1);
 Psinp = zeros(np,1);
 for j = 1:n
  sk = zeros(np,1);
  % values of the j-th Lagrange polynomial
  for l = 1:np
   for kk = 1:n
    sk(l) = sk(l) + alp(kk,j) * Psi(l,kk);
   end % for kk
  end % for l
  Psinp = Psinp + abs(sk);
 end % for j
 [minP,J] = min(Psinp);
 
 % replace the min by a point at the max
 xI = XY(I(1),1); 
 yI = XY(I(1),2);
 old = [x(J(1)) y(J(1))];
 if norm(old - rep_old) <= 1e-12
  % we are in a cycle
  [val,I] = sort(Psinp,'descend');
  % try the next point (I(1)=J(1))
  J(1) = I(2);
 end
 x(J(1)) = xI; 
 y(J(1)) = yI;
 rep = [x(J(1)) y(J(1))];
 rep_old = rep;
 if viz ~= 0
  pause
 end
end % for k

if maxL >= maxL_old
 % restore the optimal points
 x = x_opt; 
 y = y_opt;
 maxL = maxL_old;
 if random == 1
  % randomize one point to restart next time
  [val,J] = sort(Psinp,'descend');
  x(J(1)) = rand * x(J(1));
  y(J(1)) = rand * y(J(1));
  % randomize another point?
  x(J(2)) = rand * x(J(2));
  y(J(2)) = rand * y(J(2));
 end % if random
end % if maxL



