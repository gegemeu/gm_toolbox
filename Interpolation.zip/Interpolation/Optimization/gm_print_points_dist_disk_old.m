function [x_opt,y_opt,maxL]=gm_print_points_dist_disk_old(degree,epsi,iprint,nfev,x0,y0);
%GM_PRINT_POINTS_DIST_DISK_OLD prints sets of points for the unit disk using distance maximization 

% given starting points but we fix a point at (0, 1)

% Input:
% degree = given degree
% epsi = stopping criteria on the value of the objective function
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
% x0, y0 = starting points
%
% Output:
% x_opt, y_opt = coordinates of the set of points
% maxL  = approximate Lebesgue constant
%

%
% Author G. Meurant
% February 2017
%

global WAM

if nargin < 3
 iprint = 0;
end

if nargin < 4
 nfev = 2000;
end

if degree > 20
 fprintf('\n gm_print_points_dist_disk: The degree may be too large, be patient! \n\n')
end
  
pb = 'disk';
WAM = gm_disk_wam(100);
  
if iprint == 1
 fprintf('\n Degree = %d, Problem %s \n\n',degree,pb)
end

% equal weights
n = ((degree + 1) * (degree + 2)) / 2;
w = ones(n,1) / n;

if nargin < 5
 
 % Leja-like points for starting
 leja = gm_leja_disk(degree);
 x0 = leja(:,1);
 y0 = leja(:,2);
 
end % if nargin

% find the closest point to (0, 1)
distsq = x0.^2 + (y0 - 1).^2;
[md,I] = min(distsq);
% remove it and put (0, 1) in first place
j = I(1);
x0(j:n-1) = x0(j+1:n);
y0(j:n-1) = y0(j+1:n);
x0 = [0; x0(1:n-1)];
y0 = [1; y0(1:n-1)];

% distance maximization

if iprint == 1
 fprintf('\n --------Start of distance maximization \n\n')
end

[xl,yl] = gm_min_praxis_distance_disk(x0,y0,epsi,iprint,nfev);

gm_print_points(xl,yl);

x_opt = xl; y_opt = yl;

[dmat,dmati] = gm_dist_mat(x_opt,y_opt);

if iprint == 1
 fprintf('\n min of distances = % g, max of distances = %g \n',min(min(dmat+100*eye(n))),max(max(dmat)))
 fprintf('\n --------End of the distance maximization \n')
%  pause
%  gm_clearallfig
end

% % refinement algorithm
% 
% it = 3; % number of iterations
% 
% if iprint == 1
%  fprintf('\n --------Start of refinement, %d iterations \n',it)
% end
% 
% [xr,yr,Psinp,maxLr,x_opt,y_opt] = gm_Leb_refP_OPHL(xl,yl,w,xl,yl,maxLl,it,epsi,iprint);
% 
% % best points so far
% gm_print_points(x_opt,y_opt);
% 
% if iprint == 1
%  fprintf('\n --------End of the refinement, Lebesgue constant after this step = %g \n',maxLr)
%  pause
%  gm_clearallfig
% end

% x_opt = xl; y_opt = yl;
% maxLr = maxLl;
% 
% % one point minimization
% 
% it = 3; % number of iterations
% 
% if iprint == 1
%  fprintf('\n --------Start of one point minimization, %d iterations \n',it)
% end
% 
% [x1,y1,Psinp,maxL1,x_opt,y_opt]=gm_Leb_one_disk_OPHL(x_opt,y_opt,w,x_opt,y_opt,maxLr,it,epsi,iprint);
% 
% % Leja order of the best points
% z = gm_leja_ord(x_opt + ii * y_opt,n);
% x_opt = real(z);
% y_opt = imag(z);
% 
% % best points so far
% gm_print_points(x_opt,y_opt);
% 
% if iprint == 1
%  fprintf('\n --------End of the one point minimization, Lebesgue constant after this step = %g \n',maxL1)
% end

% recompute the Lebesgue contant
% this may not be enough to compute the L-constant reliably!!!!!!
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,400,2);

if iprint == 1
 fprintf('\n end of degree %d, Lebesgue constant = %g \n',degree,maxL)
 fprintf('\n -------------------------------------------------------------------- \n')
end







