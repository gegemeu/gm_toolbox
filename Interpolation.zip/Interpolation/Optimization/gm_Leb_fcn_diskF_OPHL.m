function f=gm_Leb_fcn_diskF_OPHL(X);
%GM_LEB_FCN_DISKF_OPHL (bounds of the) Lebesgue constant for the
%minimization in the unit disk
% uses the Huhtanen-Larsen approach

% the first point is fixed

% We assume equal weights

%
% Author G. Meurant
% February 2017
%

global xparm yparm wparm nfparm
global Ifunc
global iprob



% "exact" Lebesgue constant

% for the evaluation we have to put back the first point = (0,1)

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

nX = length(X);
n = nX / 2;

x = [0 X(1:n)];
y = [1 X(n+1:nX)];
w = wparm;

% look for the (approximate) max of the Lebesgue constant
% this may not be enough to compute the L-constant reliably!!!!!!
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,100,iprob);

f = maxL;
  


