
% computation of the Lebesgue constants for Leja, OCS and Carnicer-Godes points

nw = 500;
% we compute on a WAM of order 500 (250501 points)
pts = gm_disk_wam(nw);

fprintf('\n Leja, OCS and C-G, WAM of order %d, %d points \n',nw,size(pts,1))


for deg = 1:20
 n = (deg + 1) * (deg + 2) / 2;
 
 % Leja
 leja = gm_leja_disk(deg);
 x = leja(:,1);
 y = leja(:,2);
 w = ones(n,1) / n;
 
 % Vandermonde
 maxL_Leja = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % OCS
 [x,y] = gm_OCS_points_disk(deg);
 
 % Vandermonde
 maxL_OCS = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 % Carnicer-Godes points (standard)
 [ptscg,radius] = gm_car_go_disk(deg,'cg');
 x = ptscg(:,1);
 y = ptscg(:,2);
 
 % % Huhtanen-Larsen
 % [maxL_OPHL,Psidot] = gm_compXY_Lebesgue_func_OPHL(x,y,w,pts,2);
 
 % Vandermonde
 maxL_cg = gm_compXY_Lebesgue_func_Vdisk(x,y,w,pts);
 
 
 fprintf('\n %3d Leja = %12.7f, OCS = %12.7f, C-G = %12.7f \n',deg,maxL_Leja,maxL_OCS,maxL_cg)
 
end % for deg

