function [x,y,maxL,nf]=gm_max_praxis_Leb_OPHL(epsi);
%GM_MAX_PRAXIS_LEB_OPHL (approximate) max of the Lebesgue function using praxis

% Input:
% epsi = stopping criteria
%
% Output:
% x, y = location of the max
% maxL = maximum of the Lebesgue function
% nf = number of function evaluations

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm
global Aparm alpparm
global iprob diam

% look for the max on a coarse mesh to get a "good" starting point
npt = 50;
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(xparm,yparm,wparm,npt,iprob);
[maxP,I] = max(Psidot);
x0 = XY(I(1),1); 
y0 = XY(I(1),2);
X0 = [x0 y0];
n2 = 2;

% refine by optimization

% total degree
n = length(xparm);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% computation of the orthogonal polynomials

% values at the inner product points
[Phi,A,xy] = gm_OPHL(d,xparm,yparm,wparm);
% set the global variables for gm_Lebesgue_funcOP
Aparm = A;

% coefficients of the expansion
alp = Phi' * diag(wparm);
alpparm = alp;

% minimize -function
[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,X0,@gm_Lebesgue_func_OPHL);

if exitflag == 1 && abs(prax) < maxP
 % no convergence and a worse max, get the one from the initialization
 prax = -maxP;
end % if exitflag

maxL = -prax;
x = xp(1); 
y = xp(2);


