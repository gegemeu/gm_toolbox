function f=gm_Leb_fcn_disk_OPHL(X);
%GM_LEB_FCN_DISK_OPHL  Lebesgue constant for the minimization in the unit disk

% We assume equal weights

%
% Author G. Meurant
% February 2017
%

global WAM
global V_pts
global iprob


% "exact" Lebesgue constant

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

nX = length(X);
n = nX / 2;
deg = ceil((-3 + sqrt(1 + 8 * n)) / 2); % total degree

x = X(1:n)';
y = X(n+1:nX)';
c_pts = [x y];

V_c_pts = gm_vandermonde_koornwinder(c_pts,deg);

f = norm(V_c_pts'\V_pts',1);

%  look for the (approximate) max of the Lebesgue constant
% [maxL,Psidot]=gm_compXY_Lebesgue_func_OPHL(x,y,w,WAM,iprob);
% 
% f = maxL;
  


