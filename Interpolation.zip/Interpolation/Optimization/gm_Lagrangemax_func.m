function f=gm_Lagrangemax_func(X);
%GM_LAGRANGEMAX_FUNC function for the minimization of values of the Lagrange polynomial

%
% Author G. Meurant
% March 2017
%

global node xnode ynode
global ptsw pbot ptop plef prig nr nt
global wparm
global maxLeb

% keep the points inside the unit disk
% the values of the function must not be larger than this value!
ind = gm_indic_func(X);
if ind == 0
 f = (1 + rand) * 1e16;
 fprintf(' reject \n')
 return
end % if ind

nX = length(X);
n = nX / 2;
% add the missing node
x = [X(1:n) xnode];
y = [X(n+1:nX) ynode];
w = wparm;

% compute the values of the Lagrange polynomial on points ptsw

[maxL,vpts] = gm_compXY_Lagrange_func_OPHL(node,x,y,w,ptsw,2);

fprintf(' maxL = %g \n',maxL)

% find the local maxima of the Lagrange polynomials and their values

[locmax,valmax,xl,yl] = gm_Leb_local_max_disk(ptsw,vpts,pbot,ptop,plef,prig,nr,nt);

% remove the largest one
lm = length(locmax);
[truemax,I] = max(valmax);
ind = I(1);
locmax = [locmax(1:ind-1); locmax(ind+1:lm)];
valmax = [valmax(1:ind-1); valmax(ind+1:lm)];

if length(valmax) == 0
 f = 1e16;
 return
end

% % compute the maximum of the other points

f = max(valmax);

fprintf('number of max = %d, f = %g \n',length(locmax),f)


