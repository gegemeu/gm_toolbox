function f=gm_locmax_func(X);
%GM_LOCMAX_FUNC function for the minimization of the standard deviation of
% the local maxima

%
% Author G. Meurant
% March 2017
%

global ptsw pbot ptop plef prig nr nt
global wparm
global maxLeb

[p,q] = size(X);
if p == 1
 X = X(:);
end

% keep the points inside the unit disk
% the values of the function must not be larger than this value!
ind = gm_indic_func(X);
if ind == 0
 f = (1 + rand) * 1e16;
 fprintf(' reject \n')
 return
end % if ind

nX = length(X);
n = nX / 2;
x = X(1:n);
y = X(n+1:nX);
w = wparm;

% compute the values of the Lebesgue function on points ptsw

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);

% fprintf(' maxL = %g \n',maxL)

% if the Lebesgue constant is too large reject
if maxL > 1.001 * maxLeb
% if maxL > 1.5 * maxLeb
 f = (1 + rand) * 1e16;
 fprintf(' reject MaxL \n')
 return
end % if

% find the local maxima and their values

[locmax,valmax,xl,yl] = gm_Leb_local_max_disk(ptsw,vpts,pbot,ptop,plef,prig,nr,nt);

% keep only the largest ones

val_old = valmax;
valmax = valmax(find(valmax>0.98*max(val_old)));

if length(valmax) == 1
 valmax = val_old;
end

if length(valmax) == 1
 f = 1e16;
 return
end

% % compute the standard deviation

f = std(valmax,1);

% f = max(valmax) - min(valmax);

fprintf('number of max = %d, f = %g, maxL = %0.10f \n',length(valmax),f,maxL)


