function f=gm_radius_func(X);
%GM_RADIUS_FUNC function for the minimization with the radii

%
% Author G. Meurant
% March 2017
%

global ptsw 
global wparm
global degree

% check if the radii are between 0 and 1

for k = 1:length(X)
 if (X(k)  < 0) || (X(k) > 1)
  f = (1 + rand) * 1e16;
  return
 end
end

  if mod(degree,2) == 0
   radi = [X 0]';
  else
   radi = X';
  end % if

% if (any(X) < 0) || (any(X) > 1)
%  f = (1 + rand) * 1e16
%  return
% end

% compute the points from the radii
ptsrad = gm_points_radius_disk(degree,radi);
XX = [ptsrad(:,1); ptsrad(:,2)];

% keep the points inside the unit disk
% the values of the function must not be larger than this value!
ind = gm_indic_func(XX);
if ind == 0
 f = (1 + rand) * 1e16;
 fprintf(' reject \n')
 return
end % if ind

x = ptsrad(:,1);
y = ptsrad(:,2);
w = wparm;

% compute the values of the Lebesgue function on points ptsw

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);

f = maxL;

fprintf(' maxL = % g \n',maxL)




