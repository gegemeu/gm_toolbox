function [x,y,maxL,nf]=gm_max_praxis_Leb_upper1_OPHL(epsi);
%GM_MAX_PRAXIS_LEB_UPPER1_OPHL max of a bound of the Lebesgue function using praxis

% input:
% epsi = stopping criteria
%
% Output:
% x, y = location of the max
% maxL = maximum of the Lebesgue function
% nf = number of function evaluations

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm
global Aparm alpparm Lparm xyparm
global iprob

ipb = iprob;

% look for the max on a coarse mesh to get
% a good starting point (note that this is not the right function!)
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(xparm,yparm,wparm,10,ipb);
[maxP,I] = max(Psidot);
x0 = XY(I(1),1); 
y0 = XY(I(1),2);
X0 = [x0 y0];
n2 = 2;

% refine by optimization

% total degree
n = length(xparm);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values at the inner product points
[Q,A,xy] = gm_OPHL(d,xparm,yparm,wparm);
% set the global variables for Lebesgue_funcOP
Aparm = A;
xyparm = xy;

% lower triangular matrix
L = gm_L_OPHL(A);
Lparm = L;

% minimize -function
[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,2,n2,X0,@gm_Lebesgue_func_upper1_OPHL);

maxL = -prax;
x = xp(1); 
y = xp(2);


