function [x_opt,y_opt,maxL]=gm_print_points_Lebesgue_degXY(degree,epsi,ipb,iprint,nfev,x0,y0);
%GM_PRINT_POINTS_LEBESGUE_DEGXY prints sets of points using Lebesgue constant minimization 

% given starting points

% Input:
% degree = given degree
% epsi = stopping criteria on the value of the objective function
% ipb = problem to be considered
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
% x0, y0 = starting points
%
% Output:
% x_opt, y_opt = coordinates of the set of points
% maxL  = approximate Lebesgue constant
%

%
% Author G. Meurant
% January 2017
%

if nargin < 4
 iprint = 0;
end

if nargin < 5
 nfev = 2000;
end

ii = sqrt(-1);

if degree > 20
 fprintf('\n gm_print_points_Lebesgue_degXY: The degree may be too large, be patient! \n\n')
end

switch ipb
 
 case 1
  pb = 'square';
  
 case 2
  
  pb = 'disk';
  
 case 3
  
  pb = 'Lshape';
  
 case 4
  
  pb = 'triangle';
  
 case 5
  
  pb = 'dbubble';
  
 case 6
  
  pb = 'ellipse';
  
 case 7
  
  pb = 'hellipse';
  
 otherwise
  
  error('gm_print_points_Leebesgue_deg: Wrong value of ipb')
  
end % switch


if iprint == 1
 fprintf('\n Degree = %d, Problem %s \n\n',degree,pb)
end

% equal weights
n = ((degree + 1) * (degree + 2)) / 2;
w = ones(n,1) / n;

if nargin < 6
 
 % Leja-like points for starting
 
 switch ipb
  
  case 1
   leja = gm_leja_square(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 2
   leja = gm_leja_disk(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 3
   leja = gm_leja_Lshape(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 4
   leja = gm_leja_triangle(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 5
   leja = gm_leja_dbubble(degree);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 6
   leja = gm_leja_ellipse(degree,2,1);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
  case 7
   leja = gm_leja_hellipse(degree,2,1);
   x0 = leja(:,1);
   y0 = leja(:,2);
   
 end % switch
 
end % if nargin

% Lebesgue minimization

if iprint == 1
 fprintf('\n --------Start of Lebesgue constant minimization \n\n')
end

[xl,yl,maxLl] = gm_min_praxis_Lebesgue(x0,y0,w,epsi,ipb,iprint,nfev);

gm_print_points(xl,yl);

if iprint == 1
 fprintf('\n --------End of the Lebesgue constant minimization, Lebesgue constant = %g \n',maxLl)
 pause
 gm_clearallfig
end

% refinement algorithm

it = 3; % number of iterations

if iprint == 1
 fprintf('\n --------Start of refinement, %d iterations \n',it)
end

[xr,yr,Psinp,maxLr,x_opt,y_opt] = gm_Leb_refP_OPHL(xl,yl,w,xl,yl,maxLl,it,epsi,iprint);

% best points so far
gm_print_points(x_opt,y_opt);

if iprint == 1
 fprintf('\n --------End of the refinement, Lebesgue constant after this step = %g \n',maxLr)
 pause
 gm_clearallfig
end

% one point minimization

if iprint == 1
 fprintf('\n --------Start of one point minimization, %d iterations \n',it)
end

[x1,y1,Psinp,maxL1,x_opt,y_opt]=gm_Leb_one_OPHL(x_opt,y_opt,w,x_opt,y_opt,maxLr,it,epsi,iprint);

% Leja order of the best points
z = gm_leja_ord(x_opt + ii * y_opt,n);
x_opt = real(z);
y_opt = imag(z);

% best points so far
gm_print_points(x_opt,y_opt);

if iprint == 1
 fprintf('\n --------End of the one point minimization, Lebesgue constant after this step = %g \n',maxL1)
end

% recompute the Lebesgue contant
% this may not be enough to compute the L-constant reliably!!!!!!
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x_opt,y_opt,w,400,ipb);

if iprint == 1
 fprintf('\n end of degree %d, Lebesgue constant = %g \n',degree,maxL)
 fprintf('\n -------------------------------------------------------------------- \n')
end







