function f=gm_Lebesgue_func1_V(X);
%GM_LEBESGUE_FUNC1_V computation of the max of the Lebesgue function
% when searching for gm_Leb_one_disk_V with gm_comp_Lebesgue_func_OPHL

%
% Author G. Meurant
% July 2014
% Updated August 2015
%

global xparm yparm wparm
global nfunc iprob

global V_pts

nfunc = nfunc + 1;

ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end

x = X(1); 
y = X(2);

% total degree
n = length(xparm);
deg = ceil((-3 + sqrt(1 + 8 * n)) / 2);

xparm(n) = x; 
yparm(n) = y;

c_pts = [xparm yparm];

V_c_pts = gm_vandermonde_koornwinder(c_pts,deg);

f = norm(V_c_pts'\V_pts',1);


% % this (100) may not be enough to compute the L-constant reliably!!!!!!
% [Psinp,maxLL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(xparm,yparm,wparm,100,iprob);
% f = maxLL;







