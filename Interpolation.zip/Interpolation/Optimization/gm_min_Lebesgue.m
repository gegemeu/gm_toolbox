function [x,y,maxL]=gm_min_Lebesgue(x0,y0,w,epsi,ipb,iprint);
%GM_MIN_LEBESGUE looks for a good set of points using Lebesgue constant minimization

% We use a Leja ordering of the points

% Input:
% (x0,y0) = starting points
% w = weights (sum(w) = 1)
% epsi = stopping criteria on the value of the objective function
% ipb = problem to be considered
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1, printing
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% August 2015
%

ii = sqrt(-1);
n = length(x0);

% Leja order
z = gm_leja_ord(x0+ ii * y0,n);
x0 = real(z);
y0 = imag(z);

% Lebesgue constant minimization

[xl,yl,maxLl] = gm_min_praxis_Lebesgue(x0,y0,w,epsi,ipb,iprint);

% Leja order
z = gm_leja_ord(xl + ii * yl,n);
xl = real(z);
yl = imag(z);

if iprint == 1
 fprintf('\n --------End of the Lebesgue contant minimization, Lebesgue constant = %g \n',maxLl)
 pause
 gm_clearallfig
end % if iprint

% refinement algorithm

it = 3; % number of iterations

[xr,yr,Psinp,maxLr,x_opt,y_opt] = gm_Leb_refP_OPHL(xl,yl,w,xl,yl,maxLl,it,epsi,iprint);

% Leja order
z = gm_leja_ord(x_opt + ii * y_opt,n);
x_opt = real(z);
y_opt = imag(z);

if iprint == 1
 fprintf('\n --------End of the refinement, Lebesgue constant = %g \n',maxLr)
 pause
 gm_clearallfig
end % if iprint

% one point minimization

[x1,y1,Psinp,maxL1,x_opt,y_opt]=gm_Leb_one_OPHL(x_opt,y_opt,w,x_opt,y_opt,maxLr,it,epsi,iprint);

% Leja order
z = gm_leja_ord(x_opt + ii * y_opt,n);
x_opt = real(z);
y_opt = imag(z);

x = x_opt;
y = y_opt;

if iprint == 1
 fprintf('\n --------End of the one point minimization, Lebesgue constant = %g \n',maxL1)
 pause
 gm_clearallfig
end % if iprint

% this may not be enough to compute the L-constant reliably!!!!!!
if iprint == 1
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,200,ipb);
 fprintf('\n Final Lebesgue constant = %g \n\n',maxL)
else
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,ipb);
end % if iprint



