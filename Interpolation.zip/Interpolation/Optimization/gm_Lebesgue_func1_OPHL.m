function f=gm_Lebesgue_func1_OPHL(X);
%GM_LEBESGUE_FUNC1_OPHL computation of the max of the Lebesgue function
% when searching for gm_Leb_one_OPHL with gm_comp_Lebesgue_func_OPHL

%
% Author G. Meurant
% July 2014
% Updated August 2105
%

global xparm yparm wparm
global nfunc iprob

nfunc = nfunc + 1;

ind = gm_indic_func(X);
if ind == 0
 f = (1 + rand) * 1e16;
%  fprintf(' reject \n')
 return
end

x = X(1); 
y = X(2);

% total degree
n = length(xparm);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

xparm(n) = x; 
yparm(n) = y;

% this (100) may not be enough to compute the L-constant reliably!!!!!!
[Psinp,maxLL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(xparm,yparm,wparm,100,iprob);
f = maxLL;








