function [stdev,locmax,valmax,xloc,yloc,vpts]=gm_find_locmax(x,y,w,iprint,nw);
%GM_FIND_LOCMAX finds the local maxima of the Lebesgue function
% and their standard deviation

%
% Input:
% x,y = coordinates of the points defining the inner product
% w = weights
% iprint = 1, with printing
% nw = order of the WAM
%
% Output:
% stdev = standard deviation
% locmax = positions in vpts
% valmax = values of the local maxima
% xloc,yloc = coordinates of the local maxima
% vpts = values of the Lebesgue function on the WAM
%

%
% Author G. Meurant
% March 2017
%

if nargin < 5
 nw = 300;
end

% WAM for the computation of the local maxima
[ptsw,pbot,ptop,plef,prig,nr,nt] = gm_disk_wam_order(nw);

[maxL,vpts] = gm_compXY_Lebesgue_func_OPHL(x,y,w,ptsw,2);

if iprint == 1
 fprintf('\n Lebesgue constant on the WAM (%d points) = %0.10f \n',size(ptsw,1),maxL)
end

% find all the local maxima and their values
[locmax,valmax,xloc,yloc] = gm_Leb_local_max_disk(ptsw,vpts,pbot,ptop,plef,prig,nr,nt);

% keep only the largest ones
I = find(valmax>0.98*max(valmax));
valmax = valmax(I);
locmax = locmax(I);
xloc = xloc(I);
yloc = yloc(I);

stdev = std(valmax,1);

if iprint == 1
 fprintf('\n number of local maxima = %d, standard deviation = %g, min = %g, max = %g \n\n',length(locmax),stdev,min(valmax),max(valmax))
end



