function f=gm_Leb_fcn_OPHL(X);
%GM_LEB_FCN_OPHL (bounds of the) Lebesgue constant for the minimization
% uses the Huhtanen-Larsen approach

% We assume equal weights

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm nfparm
global Ifunc
global iprob

switch Ifunc
 
 case 1
  
  % "exact" Lebesgue constant
  
  % the values of the function must not be larger than this value!
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end % if ind
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); 
  y = X(n+1:nX);
  w = wparm;
  
  % look for the (approximate) max of the Lebesgue constant
  
  xparm = x'; 
  yparm = y'; 
  % rough max using praxis
  [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_OPHL(0.5);
  nfparm = nfparm + nfleb;
  
  f = maxL;
  
 case 2
  
  % upper bound (approximate 1-norm of phi(xi))
  
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end % if ind
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); y = X(n+1:nX);
  x = x(:); y = y(:);
  w = wparm;
  e1 = eye(n,1);
  % total degree
  d = ceil((-3 + sqrt(1 + 8 * n)) / 2);
  
  % compute the recurrence matrices
  
  [Q,A,xy] = gm_OPHL(d,x,y,w);
  
  % compute L from A
  
  L = gm_L_OPHL(A);
  
  % coefficients
  W = diag(w);
  WP = abs(W * Q);
  beta = sum(WP)';
  
  % check a few points inside the square
  [xx,yy,xm,ym] = gm_cheb_grid(4);
  nxy = length(xm);
  f = realmin;
  
  for k = 1:nxy
   xyj = gm_eval_xy_OPHL(xy,xm(k),ym(k));
   y = (L - xyj) \ e1;
   y = beta .* abs(y);
   fj = sum(y);
   f = max(f,fj);
  end % for k
  
 case 3
  
  % norm of inv(L)
  
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end % if ind
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); 
  y = X(n+1:nX);
  x = x(:); 
  y = y(:);
  w = wparm;
  e1 = eye(n,1);
  % total degree
  d = ceil((-3 + sqrt(1 + 8 * n)) / 2);
  
  % compute the recurrence matrices
  
  [Q,A,xy] = gm_OPHL(d,x,y,w);
  
  % compute L from A
  
  L = gm_L_OPHL(A);
  
  f = norm(inv(L),1);
  
 case 4
  
  % upper bound of the Lebesgue constant
  
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end % if ind
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); 
  y = X(n+1:nX);
  w = wparm;
  
  xparm = x'; 
  yparm = y'; 
  wparm = w;
  % rough max using praxis
  [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_upper_OPHL(0.5);
  nfparm = nfparm + nfleb;
  
  f = maxL;
  
 case 5
  
  % upper bound of the Lebesgue constant
  % || (L-Z)^{-1}||_1
  
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end % if ind
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); 
  y = X(n+1:nX);
  w = wparm;
  
  xparm = x'; 
  yparm = y'; 
  wparm = w;
  % rough max using praxis
  [xx,yy,maxL,nfleb] = gm_max_praxis_Leb_upper1_OPHL(1e-2);
  nfparm = nfparm + nfleb;
  
  f = maxL;
  
 case 6
  
  % "exact" Lebesgue constant
  
  ind = gm_indic_func(X);
  if ind == 0
   f = 1e16;
   return
  end
  
  nX = length(X);
  n = nX / 2;
  
  x = X(1:n); 
  y = X(n+1:nX);
  w = wparm;
  
  % look for the (approximate) max of the Lebesgue constant
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,100,iprob);
  
  f = maxL;
  
 otherwise
  error('gm_Leb_fcn_OPHL: Ifunc must be 1, 2, 3, 4, 5 or 6')
  
end % switch

