function [x,y]=gm_min_praxis_distance_disk_old(x0,y0,epsi,iprint,nfev);
%GM_MIN_PRAXIS_DISTANCE_DISK_OLD looks for the maximization of the distances iterating with gm_praxis
% on the unit disk

% we have the first point which is fixed at (0,1)

% the solution is improved by restarting

% Input:
% x0,y0 = starting points
% w = weights
% epsi = stopping criteria
% iprint = 1 with printing
% nfev = approximate maximum number of function evaluations in praxis
%
% Output:
% (x,y) = new set of points

%
% Author G. Meurant
% February 2017
%

% defaults

if nargin <= 3
 iprint = 1;
end

if nargin <= 4
 nfev = 2000;
end

iprob = 2;

% set the approximate diameter
diam = 2;

% remove the first point (fixed)
n = length(x0);
w = ones(n,1) / n;
x0 = x0(2:n);
y0 = y0(2:n);
n = n - 1;
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;

% the number of function evaluations (last parameter) may be too small

% rough estimate to find a good starting point
[xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_dist_fcn_disk,50,nfev+500);

if iprint == 1
 fprintf(' Init, iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_dist_fcn_disk,50,nfev);

if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

% improve the solution by restarting (?)
kmax = 20;
prax_old = prax;

for k = 1:kmax
 if iprint == 1
  fprintf('--------iteration %d \n',k)
 end
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_dist_fcn_disk,50,nfev);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  x = [ 0; xp(1:n)']; y = [1; xp(n+1:n2)'];
  
  if iprint == 1
   fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  
  if iprint == 1
   fprintf(' Lebesgue const = %0.5f \n',maxL)
  end
  return
 end % if prax
 
 if iprint == 1
  fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  prax_old = prax;
 end % if abs
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
end

x = [0; xp(1:n)']; 
y = [1; xp(n+1:n2)'];

% this may not be enough to compute the L-constant reliably!!!!!!

% compute the Lebesgue const on a fine mesh
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);

figure
plot(x,y,'b*')
hold on
gm_draw_circle(50,0,0,1);
hold off

if iprint == 1
 fprintf(' Lebesgue constant (fine mesh) = %0.5f \n',maxL)
end




