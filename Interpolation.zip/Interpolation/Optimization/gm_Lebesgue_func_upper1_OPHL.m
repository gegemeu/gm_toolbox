function f=gm_Lebesgue_func_upper1_OPHL(X);
%GM_LEBESGUE_FUNC_UPPER1_OPHL computation of an upper bound of the Lebesgue function
% computed using Huhtanen-Larsen

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

global xparm yparm wparm
global nfunc
global Aparm alpparm Lparm xyparm

nfunc = nfunc + 1;

% keep the points inside the domain
ind = gm_indic_func(X);
if ind == 0
 f = 1e16;
 return
end % if ind

x = X(1); 
y = X(2);

n = length(x);

% get the matrices from gm_OPHL

L = Lparm;
xy = xyparm;
e1 = eye(size(L,1),1);

f = realmin;

for j = 1:n
 xyj = gm_eval_xy_OPHL(xy,x(j),y(j));
 f = max(f,norm((L-xyj)\e1,1));
end % for j

f = -f;



