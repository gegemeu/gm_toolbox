function [x,y,maxL]=gm_min_praxis_Lpnorm_bnd(x0,y0,w,epsi,mu,pp,ipb,iprint);
%GM_MIN_PRAXIS_LPNORM_BND looks for the min of the p-norm of the Lagrange
% polynomials using gm_praxis + a boundary integral

% Input:
% (x0,y0) = starting points
% w = weights (sum(w) = 1)
% epsi = stopping criteria on the value of the objective function
% mu = coefficient of the boundary integral
% pp = we consider the l_pp norm
% ipb = problem to be considered
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1, printing
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue const

%
% Author G. Meurant
% June 2014
% Updated August 2015
%

global iprob diam
global xnode ynode weight
global xbnd ybnd wbnd
global wparm muu
global p

if nargin <= 4
 mu = 1;
end

if nargin <= 5
 ipb = 1;
end

if nargin <= 6
 iprint = 1;
end

iprob = ipb;
muu = mu;
p = pp;

if p <= 0
 error('gm_min_praxis_Lpnorm_bnd: pp must be positive')
end

if abs(sum(w) - 1) > 1e-14
 error('gm_min_praxis_Lpnorm_bnd: The sum of the weights must be equal to 1')
end
I = find(w <= 0);
if ~isempty(I)
 error('gm_min_praxis_Lpnorm_bnd: There are negative or zero weights')
end
wparm = w;

n = length(x0);
X0 = [x0 y0];
n2 = 2 * n;
nftot = 0;
xp = X0;

% nodes and weights for the integral

d = ceil((-3 + sqrt(1 + 8 * n)) / 2);
d2 = 2 * d;
% You may eventually remove the next 3 lines
if d >= 20
 error('gm_min_praxis_Lpnorm_bnd: The degree is too large')
end
d2 = min(d2,40);

switch iprob
 
 case 1
  % unit square
  diam = 2;
  % use Padua points (param = 2)
  % Int is not used
  [Int,nodes,weight] = gm_quadPD(@const,d2,[-1 1],[-1 1],2,X0');
  xnode = nodes(:,1); 
  ynode = nodes(:,2);
  
  % boundary nodes
  nbnd = d2;
  % Legendre nodes and weights
  [aa,bb,mu0] = gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % 4 sides of the square
  nbnd4 = 4 * nbnd;
  xbnd = zeros(nbnd4,1);
  ybnd = zeros(nbnd4,1);
  wbnd = zeros(nbnd4,1);
  xbnd(1:nbnd) = t;
  ybnd(1:nbnd) = -1;
  wbnd(1:nbnd) = ww;
  xbnd(nbnd+1:2*nbnd) = 1;
  ybnd(nbnd+1:2*nbnd) = t;
  wbnd(nbnd+1:2*nbnd) = ww;
  xbnd(2*nbnd+1:3*nbnd) = t;
  ybnd(2*nbnd+1:3*nbnd) = 1;
  wbnd(2*nbnd+1:3*nbnd) = ww;
  xbnd(3*nbnd+1:nbnd4) = -1;
  ybnd(3*nbnd+1:nbnd4) = t;
  wbnd(3*nbnd+1:nbnd4) = ww;
  
 case 2
  % unit disk
  diam = 2;
  xyw = gm_gqcircsect(d2,pi,0.,1);
  xnode = xyw(:,1);
  ynode = xyw(:,2);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % go to [0 2 pi]
  tet = (t + 1) * pi;
  xbnd = cos(tet);
  ybnd = sin(tet);
  wbnd = ww;
  
 case 3
  % L-shape region
  diam = 2;
  polygon_sides = [-1 -1; 1 -1; 1 0; 0 0; 0 1; -1 1; -1 -1];
  xyw = gm_polygauss_2013(d2,polygon_sides);
  xnode = xyw(:,1);
  ynode = xyw(:,2);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % go to [0 1]
  x1 = (t + 1) / 2;
  % 6 sides of the region
  nbnd6 = 6 * nbnd;
  xbnd = zeros(nbnd6,1);
  ybnd = zeros(nbnd6,1);
  wbnd = zeros(nbnd6,1);
  xbnd(1:nbnd) = t;
  ybnd(1:nbnd) = -1;
  wbnd(1:nbnd) = ww;
  xbnd(nbnd+1:2*nbnd) = -1;
  ybnd(nbnd+1:2*nbnd) = t;
  wbnd(nbnd+1:2*nbnd) = ww;
  xbnd(2*nbnd+1:3*nbnd) = 1;
  ybnd(2*nbnd+1:3*nbnd) = x1 - 1;
  wbnd(2*nbnd+1:3*nbnd) = ww;
  xbnd(3*nbnd+1:4*nbnd) = x1;
  ybnd(3*nbnd+1:4*nbnd) = 0;
  wbnd(3*nbnd+1:4*nbnd) = ww;
  xbnd(4*nbnd+1:5*nbnd) = 0;
  ybnd(4*nbnd+1:5*nbnd) = x1;
  wbnd(3*nbnd+1:4*nbnd) = ww;
  xbnd(5*nbnd+1:nbnd6) = x1 - 1;
  ybnd(5*nbnd+1:nbnd6) = 1;
  wbnd(5*nbnd+1:nbnd6) = ww;
  
 case 4
  % simplex = triangle
  diam = 1;
  polygon_sides = [0 0; 1 0; 0 1; 0 0];
  xyw = gm_polygauss_2013(d2,polygon_sides);
  xnode = xyw(:,1);
  ynode = xyw(:,2);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % go to [0 1]
  x1 = (t + 1) / 2;
  % got to [0 sqrt(2)] with the angle
  x2 = (t + 1) / 2;
  % 3 sides of the triangle
  nbnd3 = 3 * nbnd;
  xbnd = zeros(nbnd3,1);
  ybnd = zeros(nbnd3,1);
  wbnd = zeros(nbnd3,1);
  xbnd(1:nbnd) = x1;
  ybnd(1:nbnd) = 0;
  wbnd(1:nbnd) = ww;
  xbnd(nbnd+1:2*nbnd) = 0;
  ybnd(nbnd+1:2*nbnd) = x1;
  wbnd(nbnd+1:2*nbnd) = ww;
  xbnd(2*nbnd+1:nbnd3) = x2;
  ybnd(2*nbnd+1:nbnd3) = 1 - x2;
  wbnd(2*nbnd+1:nbnd3) = ww;
  
 case 5
  % double bubble
  % center (0,0) radius 5, center (6,0) radius 3
  diam = 14;
  xyw = gqdbubble(d2,0,0,5,6,0,3);
  xnode = xyw(:,1);
  ynode = xyw(:,2);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % boundary nodes
  nbnd2 = 2 * nbnd;
  xbnd = zeros(nbnd2,1);
  ybnd = zeros(nbnd2,1);
  wbnd = zeros(nbnd2,1);
  % left circle
  teta = acos(13/15);
  tet = (1 - t) * (teta / 2) + (t + 1) * (2 * pi - teta) / 2;
  xbnd(1:nbnd) = 5 * cos(tet);
  ybnd(1:nbnd) = 5 * sin(tet);
  wbnd(1:nbnd) = ww;
  % right circle
  teta = acos(-5/9);
  tet = (1 - t) * (-teta) / 2 + (t + 1) * teta / 2;
  xbnd(nbnd+1:nbnd2) = 6 + 3 * cos(tet);
  ybnd(nbnd+1:nbnd2) = 3 * sin(tet);
  wbnd(nbnd+1:nbnd2) = ww;
  
 case 6
  % ellipse with semi axes 2 (x) and 1 (y)
  diam = 4;
  xyw = gm_gqcircsect(d2,pi,0.,1);
  xnode = 2 * xyw(:,1);
  ynode = xyw(:,2);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % go to [0 2 pi]
  tet = (t + 1) * pi;
  xbnd = 2 * cos(tet);
  ybnd = sin(tet);
  wbnd = ww;
  
 case 7
  % half-ellipse with semi axes 2 (x) and 1 (y), y >= 0
  diam = 4;
  xyw = gm_gqcircsect(d2,pi/2,0.,1);
  xnode = 2 * xyw(:,2);
  ynode = xyw(:,1);
  weight = xyw(:,3);
  
  % boundary nodes
  nbnd = d2;
  [aa,bb,mu0]= gm_classicorthopoly('le',nbnd,0,0);
  [t,ww] = gm_gaussquadrule_m(aa,bb,mu0);
  ww = ww';
  % go to [0 pi]
  tet = (t + 1) * pi / 2;
  xbnd = 2 * cos(tet);
  ybnd = sin(tet);
  wbnd = ww;
  nbnd2 =  2 * nbnd;
  xbnd(nbnd+1:nbnd2) = 2 * t;
  ybnd(nbnd+1:nbnd2) = 0;
  wbnd(nbnd+1:nbnd2) = ww;
  
end % switch

% rough estimate to find a good starting point
% [xp,prax,iter,nf,exitflag] = gm_praxis(1e-1,1e-1,diam,n2,X0,@gm_Lag_Lpnorm_bnd);
% fprintf('iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
% nftot = nftot + nf;

% the number of function evaluations (last parameter) may be too small

[xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Lag_Lpnorm_bnd,10,2500);
if iprint == 1
 fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
end
nftot = nftot + nf;

% improve the solution by restarting (?)
kmax = 20;
prax_old = prax;

for k = 1:kmax
 if iprint == 1
  fprintf('---------iteration %d \n',k)
 end
 xp_old = xp;
 [xp,prax,iter,nf,exitflag] = gm_praxis(epsi,epsi,diam,n2,xp,@gm_Lag_Lpnorm_bnd,10,2000);
 nftot = nftot + nf;
 
 if prax > 10 * prax_old
  % there is something wrong
  xp = xp_old;
  prax = prax_old;
  x = xp(1:n)'; y = xp(n+1:n2)';
  if iprint == 1
   fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
   fprintf(' total nfunc = %d \n',nftot)
  end
  % this may not be enough to compute the L-constant reliably!!!!!!
  [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
  if iprint == 1
   fprintf('Lebesgue constant = %0.5f \n',maxL)
   return
  end
 end % if prax
 
 if iprint == 1
  fprintf(' iter = %d, nfunc = %d, exitflag = %d, f = %0.5f \n',iter,nf,exitflag,prax)
 end
 
 % convergence test
 if (abs(prax - prax_old) / prax_old) <= epsi / 3
  break
 else
  prax_old = prax;
 end
end % for k

if iprint == 1
 fprintf('\n total number of function evaluations = %d \n',nftot)
end

% maxL = prax;
x = xp(1:n)'; y = xp(n+1:n2)';

% this may not be enough to compute the L-constant reliably!!!!!!

[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,iprob);
if iprint == 1
 fprintf(' Lebesgue constant = %0.5f \n',maxL)
end

end % function

function f=const(x,y,X);

f = 1;

end


