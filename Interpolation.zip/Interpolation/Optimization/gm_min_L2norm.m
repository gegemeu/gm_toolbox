function [x,y,maxL]=gm_min_L2norm(x0,y0,w,epsi,ipb,iprint);
%GM_MIN_L2NORM looks for a good set of points using L2 minimization

% Input:
% (x0,y0) = starting points
% w = weights (sum(w) = 1)
% epsi = stopping criteria on the value of the objective function
% ipb = problem to be considered
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% iprint = 1, printing
%
% Output:
% (x,y) = new set of points
% maxL = Lebesgue constant

%
% Author G. Meurant
% August 2015
%

% L2 norm minimization

[xl,yl,maxLl] = gm_min_praxis_L2norm(x0,y0,w,epsi,ipb,iprint);

if iprint == 1
 fprintf('\n --------End of the L2 minimization, Lebesgue constant = %g \n',maxLl)
 pause
 gm_clearallfig
end % if iprint

% refinement algorithm

it = 5; % number of iterations

[xr,yr,Psinp,maxLr,x_opt,y_opt] = gm_Leb_refP_OPHL(xl,yl,w,xl,yl,maxLl,it,epsi,iprint);

if iprint == 1
 fprintf('\n --------End of the refinement, Lebesgue constant = %g \n',maxLr)
 pause
 gm_clearallfig
end % if iprint

% one point minimization

[x1,y1,Psinp,maxL1,x_opt,y_opt]=gm_Leb_one_OPHL(xr,yr,w,x_opt,y_opt,maxLr,it,epsi,iprint);

x = x_opt;
y = y_opt;

if iprint == 1
 fprintf('\n --------End of the one point minimization, Lebesgue constant = %g \n',maxL1)
 pause
 gm_clearallfig
end % if iprint

% this may not be enough to compute the L-constant reliably!!!!!!
if iprint == 1
 [Psinp,maxL,Psidot,XY] = gm_viz_Lebesgue_func_OPHL(x,y,w,200,ipb);
 fprintf('\n Final Lebesgue constant = %g \n\n',maxL)
else
[Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(x,y,w,200,ipb);
end % if iprint



