function gm_max_Leb_func_disk_deg1(x,y);
%GM_MAX_LEB_FUNC_DISK_DEG1

% x1 must be zero
x1 = x(1);
if x1 ~= 0
 error('gm_max_Leb_func_disk_deg1: x(1) must be zero')
end

xy = x.^2 + y.^2;
if any(xy > 1)
 error('gm_max_Leb_func_disk_deg1: the points are not all inside the unit disk')
end

x2 = x(2); x3 = x(3);
y1 = y(1); y2 = y(2); y3 = y(3);

 A = [x1 y1 1; x2 y2 1; x3 y3 1];
 invA = inv(A);
 niA = norm(invA);
 
 invA(3,1) + invA(3,2) + invA(3,3)

% coefficients of the planes
a1 = y2 - y3; a2 = y3 - y1; a3 = y1 - y2;
b1 = x3 - x2; b2 = - x3; b3 = x2;
d1 = x2 * y3 - y2 * x3; d2 = y1 * x3; d3 = -y1 * x2;

% determinant
d = d1 + d2 + d3

detA = y1 * (x3  - x2) + x2 * y3 - x3 * y2

deriv = -(x3 - x2)^2 - (x3 - x2) * (x3 * y2 - x2  * y3)

(x3 - x2) * (x3 * y2 - x2  * y3)

 (x3 * y2 - x2  * y3) / (x3 - x2)

% myinvA = [a1 a2 a3; b1 b2 b3; d1 d2 d3] / d

% signs (7 regions)
sig = zeros(3,7);
sig(:,1) = [-1 ; 1; 1];
sig(:,2) = [1 ; -1; 1];
sig(:,3) = [1 ; 1; -1];
sig(:,4) = [1 ; -1; -1];
sig(:,5) = [-1 ; 1; -1];
sig(:,6) = [-1 ; -1; 1];
sig(:,7) = [1 ; 1; 1];

% coefficients of the Lebesgue function
zeta = zeros(7,1);
xi = zeros(7,1);
eta = zeros(7,1);

for k = 1:7
 zeta(k) = sig(1,k) * a1 + sig(2,k) * a2 + sig(3,k) * a3;
 xi(k) = sig(1,k) * b1 + sig(2,k) * b2 + sig(3,k) * b3;
 eta(k) = sig(1,k) * d1 + sig(2,k) * d2 + sig(3,k) * d3;
end

maxL_reg = abs(sqrt(zeta.^2 + xi.^2) + eta) / abs(d);

minL_reg = abs((zeta.^2 - xi.^2) ./ sqrt(zeta.^2 + xi.^2) + eta) / abs(d);


[d det(A)]
% eta / d
% (sqrt(zeta.^2 + xi.^2) + eta) / d
%(sqrt(zeta.^2 + xi.^2) + abs(eta)) / abs(d)
maxL_reg


