function f=gm_absxy(x,y);
%GM_ABSXY exemple of a 2D function to be interpolated

f = abs(x - 0.5) + abs(y - 0.5);