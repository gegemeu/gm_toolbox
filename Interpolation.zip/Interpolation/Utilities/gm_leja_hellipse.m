function leja=gm_leja_hellipse(deg,a,b);
%GM_LEJA_HELLIPSE Leja-like points in a half ellipse, center (0,0), semi-axes a and b

% Input:
% deg = degree of the bivariate polynomial
%       it yields (deg + 1) * (deg + 2) / 2 points
% a, b = semi-axes
%
% Output:
% leja = coordinates of the points, x = leja(:,1), y = leja(:,2)

%
% adapted from M. Vianello
% May 2014
% Updated by G. Meurant
% Oct 2015
%

rect = [-a a 0 b];

H = gm_haltonseq(2*deg^3,2);
x = 2 * a * H(:,1) - a;
y = 2 * b * H(:,2) - b;
H(:,1) = x; 
H(:,2) = y;

% keep the points in the disk
ind = find((H(:,1)).^2 / a^2 +(H(:,2)).^2 / b^2 < 1 & H(:,2) >= 0);
gmmesh = H(ind,:);

% computing the rectangular Chebyshev-Vandermonde matrix on the mesh

V = gm_chebvand(deg,gmmesh,rect);

% computing the approximate Leja points using the LU factorization

dim = (deg +1 ) * (deg + 2) / 2;
[L,U,perm] = lu(V,'vector');
leja = gmmesh(perm(1:dim),:);







