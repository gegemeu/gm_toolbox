function H=gm_haltonseq(NUMPTS,NDIMS);
%GM_HALTONSEQ Generate a Halton sequence in NDIMS dimensional space

% This yields points in [0, 1]^2 or [0, 1]^3

% Input:
% NUMPTS = number of points
% NDIMS = number of dimensions
%
% Output:
% H = coordinates of the points

%
% From M. Vianello
% Updated by G. Meurant
% July 2015
%

if (NDIMS < 12)
 P = [2 3 5 7 11 13 17 19 23 29 31];
else
 P = primes(1.3  *NDIMS * log(NDIMS));
 P = P(1:NDIMS);
end % if

if isequal(size(NUMPTS),[1 1])
 int_pts = [1:NUMPTS];
else 
 int_pts = NUMPTS;
 NUMPTS = length(int_pts);
end % if isequal

H = zeros(NUMPTS,NDIMS);

for i = 1:NDIMS 
 % Generate the components for each dimension
 V = fliplr(gm_dec2bigbase(int_pts,P(i)));
 pows = -repmat([1:size(V,2)],size(V,1),1);
 H(:,i) = sum(V .* (P(i).^pows),2);
end % for i



