function f=gm_cos5x5y(x,y);
%GM_COS5X5Y exemple of a 2D function to be interpolated

f = cos(5 * x + 5 * y);