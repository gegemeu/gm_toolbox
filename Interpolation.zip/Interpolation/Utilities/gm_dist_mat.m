function [dmat,dmati,vd,difmind,diffav]=gm_dist_mat(x,y);
%GM_DIST_MAT matrix of the pairwise distances between points

%
% Input:
% x,y = coordinates of the points
%
% Output:
% dmat = matrix of the pairwise distances
% dmati = matrix of the inverses of the distances 
%         except for the diagonal which is zero
% vd = proportional to the variance of the minimal distances
% difmind = differences of the minimal distances squared
% diffav = differences of the average distances squared
%

%
% Author G. Meurant
% February 2017
%

[xi,xj] = meshgrid(x,x);
[yi,yj] = meshgrid(y,y);

dmat = sqrt((xi - xj).^2 + (yi - yj).^2);

n = length(x);
dmati = dmat + eye(n,n);
dmati = 1 ./ dmati - eye(n,n);

% minimum distances for each point
mind = min(dmat+100*eye(n,n));

% mean of the minimum distances
avd = sum(mind) / n;

% n times variance
vd = sum((mind - avd).^2);

% differences of the minimal distances squared
[di,dj] = meshgrid(mind,mind);
difmind =  (di - dj).^2;

% % average distances
% avdist = sum(dmat) / n;
% % differences of the average distances squared
% [di,dj] = meshgrid(avdist,avdist);
% diffav = (di - dj).^2;
diffav = 0;

