function gm_max_Leb_regionI
%GM_MAX_LEB_REGIONI value of the Lebesgue constant in region I

% value of the Lebesgue constant in region I as a function of the angles
% theta2, theta3, for theta1 = pi / 2

npts = 10;
% tet2 = linspace(0,80,npts);
tet2 = 330;
tet3 = linspace(180,270,npts);

Lambda = zeros(1,npts);

imin = 0;
jmin = 0;
minL = realmax;

for i = 1:1
 theta2 = tet2(i);
 for j = 1:npts
  theta3 = tet3(j);

  s2 = sind(theta2); c2 = cosd(theta2);
  s3 = sind(theta3); c3 = cosd(theta3);
  
  % determinant
  d = sind(theta3 - theta2) + c3 - c2
  % constant term
  c = -sind(theta3 - theta2) + c3 - c2;
  
  numer = -2 * sqrt((s3 - s2)^2 + (c2 - c3)^2)   + c;
  f = numer / d;
  % Lebesgue constant
  Lambda(i,j) = f;
  
  if Lambda(i,j) < minL;
   imin = i;
   jmin = j;
   minL = Lambda(i,j);
  end
  
 end % for j
end % for i

fprintf('\n Min value = % g for theta2 = %d and theta3 = %g \n',minL,tet2(imin),tet3(jmin))

shading interp
% surf(tet2,tet3,Lambda)
plot(tet3,Lambda)


