function gm_plot_maxLeb_xi2
%GM_PLOT_MAXLEB_XI2 Lebesgue constant in region I with xi_1 and xi_3 fixed

% x_1 = 0, y_1 = 1

% xi_3 is fixed at the optimal value
x3 = -sqrt(3) / 2;
y3 = -1/2;

% perturbation of xi_3
x3 = x3 + 0.1
y3 = -sqrt(1 - x3^2)

npts = 1000;
nptsx = 1000;
xx = linspace(0,1,npts);
tet = zeros(nptsx,1);

Lambda = zeros(npts,1);

% lower quadrant

for i = 1:npts
 x2 = xx(i);
 y2 = -sqrt(1 - x2^2);
 
 d = x3 - x2 + x2 * y3 - x3 * y2;
 
 % angle of x2
 theta2 = acos(x2);
 theta2 = 2 * pi - theta2;
 
 % angle of x3
 theta3 = acos(x3);
 theta3 = 2 * pi - theta3;
 
 % region I
 
 dtet = (theta2 - theta3) / (nptsx - 1);
 tet(1) = theta3;
 for j = 2:nptsx
  tet(j) = tet(j-1) + dtet;
 end
 x = cos(tet);
 y = sin(tet);
 
 numer = 2 * (y3 - y2) .* x + 2 * (x2 - x3) .* y + x3 * y2 - x2 * y3 + x3 - x2;
 
 f1 = numer / d;
 
 maxf1 = max(f1);
 
%  plot(x,f1)
%  title('f1')
%  pause
 
 % region II
 
 dtet = (theta3 - pi/2) / (nptsx - 1);
 tet(1) = theta3;
 for j = 2:nptsx
  tet(j) = tet(j-1) - dtet;
 end
 x = cos(tet);
 y = sin(tet);
 
 numer = 2 * (1 - y3) .* x + 2 * x3 .* y - x3 * y2 + x2 * y3 - x3 - x2;
 
 f2 = numer / d;
 
 maxf2 = max(f2);
 
%  plot(x,f2)
%  title('f2')
%  pause
 
 % region III
 
 dtet = (pi/2 + acos(x2)) / (nptsx - 1);
 tet(1) = 2 * pi - acos(x2);
 for j = 2:nptsx
  tet(j) = tet(j-1) + dtet;
  tet(j) = mod(tet(j),2*pi);
 end
 x = cos(tet);
 y = sin(tet);
 
 numer = 2 * (y2 - 1) .* x - 2 * x2 .* y - x3 * y2 + x2 * y3 + x3 + x2;
 
 f3 = numer / d;
 
 maxf3 = max(f3);
 
%  plot(x,f3)
%  title('f3')
%  pause
 
 Lambda(i) = max([maxf1 maxf2 maxf3]);
 
end % for i

[minL,I] = min(Lambda);
xmin = xx(I);
ymin = -sqrt(1 - xmin^2);
fprintf('\n minimum of Lebesgue constant = %g for x = %g, y = %g \n',minL,xmin,ymin)

plot(xx,Lambda)

