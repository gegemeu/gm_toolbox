function [Degree,MaxL]=gm_Leja_Lebesgue(dmin,dmax,ipb);
%GM_LEJA_LEBESGUE Lebesgue constants for Leja-like points

% Input:
% dmin, dmax = ends of the degree interval
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Degree = degrees
% Lebesgue constants

%
% Author G. Meurant
% August 2015
%

n = dmax - dmin + 1;
Degree = zeros(n,1);
MaxL = zeros(n,1);
kk = 0;
npts = 200;

for k = dmin:dmax
 kk = kk + 1;
 
 nd = (k + 1) * (k + 2) / 2;
 % equal weights
 w = ones(nd,1) / nd;
 
 switch ipb
 
 case 1
  leja = gm_leja_square(k);
  
 case 2
  leja = gm_leja_disk(k);
  
 case 3
  leja = gm_leja_Lshape(k);
  
 case 4
  leja = gm_leja_triangle(k);
  
 case 5
  leja = gm_leja_dbubble(k);
  
 case 6
  leja = gm_leja_ellipse(k,2,1);
  
 case 7
  leja = gm_leja_hellipse(k,2,1);
  
 otherwise
  error('gm_Leja_Lebesgue: Wrong value of ipb')
 end % switch

 Degree(kk) = k;
 [Psinp,maxL,Psidot,XY] = gm_comp_Lebesgue_func_OPHL(leja(:,1),leja(:,2),w,npts,ipb);
 MaxL(kk) = maxL;
 
end % for k

