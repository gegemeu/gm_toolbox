function [ptscg,radius]=gm_car_go_disk(degree,expo);
%GM_CAR_GO_DISK Carnicer-Godes nodes for the unit disk

%
% Input:
% degree = total degree of the bivariate polynomials
% expo = type of exponents, 'cg' or 'opt'
%
% Output:
% ptscg = coordinates of the nodes
% radius = radius of the circles

% from A. Sommariva
% March 2017

% n is the degree
n = degree;

if nargin < 2
 expo = 'opt';
end

if strcmpi(expo,'opt') == 1
 e_exp = carnicer_godes_opt_exps(n);
else
 % e_exp=carnicer_godes_exps(n) %% CARNICER-GODES EXPS FROM PAPER
 e_exp = carnicer_godes_exps(n);
end

lmax = floor(n/2) + 1;
np = (n + 1) * (n + 2) / 2;
pts_pol = zeros(np,2);
radius = zeros(lmax,1);

k = 1;
for l = 1:lmax
 lcg = l - 1;
 jmax = 2 * (n - 2 * lcg) + 1;
 r = 1 -(2 * lcg /n )^e_exp;
 % this is to avoid having points outside of the disk
%  if abs(r - 1) < 1e-15
%   r = r - eps;
%  end
 radius(l) = r;
 theta = (2 * [0:jmax-1]' + 1) * pi / (2 * (n - 2 * lcg) + 1);
 pts_pol(k:k+jmax-1,:) = [r * ones(size(theta)) theta];
 k = k + jmax;
end % for l

rad = pts_pol(:,1); 
thet = pts_pol(:,2);
ptscg = [rad .* cos(thet) rad .* sin(thet)];

end


function e_exp=carnicer_godes_opt_exps(n)

%  	| deg | leb  lebopt     | card  card_opt |
%  	 ------------------------------------------
%  	    1 |  1.667    1.667 |      3      3 |
%  	    2 |  1.989    1.989 |      6      6 |
%  	    3 |  2.615    2.467 |     10     10 |
%  	    4 |  3.234    2.972 |     15     15 |
%  	    5 |  3.718    3.501 |     21     21 |
%  	    6 |  4.299    4.182 |     28     28 |
%  	    7 |  4.978    4.751 |     36     36 |
%  	    8 |  5.519    5.373 |     45     45 |
%  	    9 |  5.958    5.804 |     55     55 |
%  	   10 |  6.743    6.477 |     66     66 |
%  	   11 |  7.358    7.163 |     78     78 |
%  	   12 |  7.877    7.795 |     91     91 |
%  	   13 |  8.898    8.679 |    105    105 |
%  	   14 |  9.639    9.471 |    120    120 |
%  	   15 |  11.173  10.620 |    136    136 |
%  	   16 |  12.131  11.745 |    153    153 |
%  	   17 |  14.074  13.068 |    171    171 |
%  	   18 |  15.120  14.554 |    190    190 |
%  	   19 |  17.218  16.017 |    210    210 |
%  	   20 |  19.528  18.100 |    231    231 |


% The Lebesgue constants of Alvise are too optimistic!

switch n
 case 1
%   %  	 DEG:  1 EXP: 1.999933893038648e+000 LEB: 1.667
%   e_exp = 1.999933893038648e+000;
  e_exp = 1.46;
 case 2
%   %  	 DEG:  2 EXP: 1.999933893038648e+000 LEB: 1.989
%   e_exp = 1.999933893038648e+000;
  e_exp = 1.46;
 case 3
%   %  	 DEG:  3 EXP: 1.577304261499011e+000 LEB: 2.615
%   e_exp = 1.577304261499011e+000;
  e_exp = 1.573727360524050;
 case 4
%   %  	 DEG:  4 EXP: 1.671199387382095e+000 LEB: 3.234
%   e_exp = 1.671199387382095e+000;
  e_exp = 1.671331489679350;
 case 5
%   %  	 DEG:  5 EXP: 1.562679145997165e+000 LEB: 3.718
%   e_exp = 1.562679145997165e+000;
  e_exp = 1.558529601118508;
 case 6
%   %  	 DEG:  6 EXP: 1.425072195317330e+000 LEB: 4.299
%   e_exp = 1.425072195317330e+000;
  e_exp = 1.430743570198477;
 case 7
%   %  	 DEG:  7 EXP: 1.398543204107687e+000 LEB: 4.978
%   e_exp = 1.398543204107687e+000;
  e_exp = 1.398856042012025;
 case 8
%   %  	 DEG:  8 EXP: 1.383914405945986e+000 LEB: 5.519
%   e_exp = 1.383914405945986e+000;
  e_exp = 1.397491808383378;
 case 9
%   %  	 DEG:  9 EXP: 1.421121388998961e+000 LEB: 5.958
%   e_exp = 1.421121388998961;
  e_exp = 1.413193377455141;
 case 10
%   %  	 DEG: 10 EXP: 1.449658921647662e+000 LEB: 6.743
%   e_exp = 1.449658921647662;
  e_exp = 1.436728874808097;
 case 11
%   %  	 DEG: 11 EXP: 1.412397690570399e+000 LEB: 7.358
%   e_exp = 1.412397690570399;
  e_exp = 1.417968881502763;
 case 12
%   %  	 DEG: 12 EXP: 1.445370977545562e+000 LEB: 7.877
%   e_exp = 1.445370977545562;
  e_exp = 1.425475078702931;
 case 13
%   %  	 DEG: 13 EXP: 1.427292796679739e+000 LEB: 8.898
%   e_exp = 1.427292796679739;
  e_exp = 1.436016579251704;
 case 14
%   %  	 DEG: 14 EXP: 1.442350994931807e+000 LEB: 9.639
%   e_exp = 1.442350994931807;
  e_exp = 1.439490478993657;
 case 15
%   %  	 DEG: 15 EXP: 1.446937432187778e+000 LEB: 11.173
%   e_exp = 1.446937432187778;
  e_exp = 1.446316890932234;
 case 16
%   %  	 DEG: 16 EXP: 1.449382133322619e+000 LEB: 12.131
%   e_exp = 1.449382133322619;
  e_exp = 1.450925707619910;
 case 17
%   %  	 DEG: 17 EXP: 1.452567777771495e+000 LEB: 14.074
%   e_exp = 1.452567777771495;
  e_exp = 1.455106040212301;
 case 18
%   %  	 DEG: 18 EXP: 1.451568294782966e+000 LEB: 15.120
%   e_exp = 1.451568294782966;
  e_exp = 1.458860431343240;
 case 19
%   %  	 DEG: 19 EXP: 1.454533297412912e+000 LEB: 17.218
%   e_exp = 1.454533297412912;
  e_exp = 1.463488746884683;
 case 20
%   %  	 DEG: 20 EXP: 1.449384018807812e+000 LEB: 19.528
%   e_exp = 1.449384018807812;
  e_exp = 1.465242878098235;
 case 21
  %  	 DEG: 21 EXP: 1.454174618970034e+000 LEB: 22.374
  e_exp = 1.454174618970034;
 case 22
  %  	 DEG: 22 EXP: 1.463559213287043e+000 LEB: 24.900
  e_exp = 1.463559213287043;
 case 23
  %  	 DEG: 23 EXP: 1.466795019635319e+000 LEB: 30.031
  e_exp = 1.466795019635319;
 case 24
  %  	 DEG: 24 EXP: 1.469911273701785e+000 LEB: 35.651
  e_exp = 1.469911273701785;
 case 25
  %  	 DEG: 25 EXP: 1.475620872874883e+000 LEB: 41.218
  e_exp = 1.475620872874883;
 case 26
  %  	 DEG: 26 EXP: 1.479100486553221e+000 LEB: 48.111
  e_exp = 1.479100486553221;
 case 27
  %  	 DEG: 27 EXP: 1.481184865216799e+000 LEB: 57.955
  e_exp = 1.481184865216799;
 case 28
  %  	 DEG: 28 EXP: 1.483573265277405e+000 LEB: 68.229
  e_exp=1.483573265277405;
 case 29
  %  	 DEG: 29 EXP: 1.487258928238027e+000 LEB: 79.557
  e_exp = 1.487258928238027;
 case 30
  %  	 DEG: 30 EXP: 1.488156564314026e+000 LEB: 95.211
  e_exp = 1.488156564314026;
 case 31
  %  	 DEG: 31 EXP: 1.490024444636492e+000 LEB: 113.848
  e_exp = 1.490024444636492;
 case 32
  %  	 DEG: 32 EXP: 1.491537953706961e+000 LEB: 134.139
  e_exp = 1.491537953706961;
 case 33
  %  	 DEG: 33 EXP: 1.493320926423402e+000 LEB: 159.189
  e_exp = 1.493320926423402;
 case 34
  %  	 DEG: 34 EXP: 1.493964084704894e+000 LEB: 190.218
  e_exp = 1.493964084704894;
 case 35
  %  	 DEG: 35 EXP: 1.495096905850271e+000 LEB: 226.545
  e_exp = 1.495096905850271;
 case 36
  %  	 DEG: 36 EXP: 1.496060594252055e+000 LEB: 267.818
  e_exp = 1.496060594252055;
 case 37
  %  	 DEG: 37 EXP: 1.496846051769460e+000 LEB: 320.158
  e_exp = 1.496846051769460;
 case 38
  %  	 DEG: 38 EXP: 1.497180191476411e+000 LEB: 381.281
  e_exp = 1.497180191476411;
 case 39
  %  	 DEG: 39 EXP: 1.497790636105958e+000 LEB: 453.264
  e_exp = 1.497790636105958;
 case 40
  %  	 DEG: 40 EXP: 1.498219000573149e+000 LEB: 538.082
  e_exp = 1.498219000573149;
 case 41
  %  	 DEG: 41 EXP: 1.498532485160414e+000 LEB: 642.451
  e_exp = 1.498532485160414;
 case 42
  %  	 DEG: 42 EXP: 1.498635091660183e+000 LEB: 763.650
  e_exp = 1.498635091660183;
 case 43
  %  	 DEG: 43 EXP: 1.498814296850027e+000 LEB: 907.021
  e_exp = 1.498814296850027;
 case 44
  %  	 DEG: 44 EXP: 1.498858801695735e+000 LEB: 1078.249
  e_exp = 1.498858801695735;
 case 45
  %  	 DEG: 45 EXP: 1.498851811171941e+000 LEB: 1282.998
  e_exp = 1.498851811171941;
 case 46
  %  	 DEG: 46 EXP: 1.498733530160081e+000 LEB: 1522.859
  e_exp = 1.498733530160081;
 case 47
  %  	 DEG: 47 EXP: 1.498591238148900e+000 LEB: 1805.303
  e_exp = 1.498591238148900;
 case 48
  %  	 DEG: 48 EXP: 1.498315936677180e+000 LEB: 2143.360
  e_exp = 1.498315936677180;
 case 49
  %  	 DEG: 49 EXP: 1.498014225549632e+000 LEB: 2540.282
  e_exp = 1.498014225549632;
 case 50
  %  	 DEG: 50 EXP: 1.497669821063911e+000 LEB: 3007.986
  e_exp = 1.497669821063911;
  
 otherwise
  e_exp = 1.5;
end % switch

end % function

function e_exp=carnicer_godes_exps(n)


%  	| deg | leb  lebopt     | card  card_opt |
%  	 ------------------------------------------
%  	    1 |  1.667    1.667 |      3      3 |
%  	    2 |  1.989    1.989 |      6      6 |
%  	    3 |  2.615    2.467 |     10     10 |
%  	    4 |  3.234    2.972 |     15     15 |
%  	    5 |  3.721    3.501 |     21     21 |
%  	    6 |  4.309    4.182 |     28     28 |
%  	    7 |  4.978    4.751 |     36     36 |
%  	    8 |  5.538    5.373 |     45     45 |
%  	    9 |  6.134    5.804 |     55     55 |
%  	   10 |  6.749    6.477 |     66     66 |
%  	   11 |  7.396    7.163 |     78     78 |
%  	   12 |  7.925    7.795 |     91     91 |
%  	   13 |  8.976    8.679 |    105    105 |
%  	   14 |  9.773    9.471 |    120    120 |
%  	   15 |  11.213  10.620 |    136    136 |
%  	   16 |  12.183  11.745 |    153    153 |
%  	   17 |  14.138  13.068 |    171    171 |
%  	   18 |  15.433  14.554 |    190    190 |
%  	   19 |  17.711  16.017 |    210    210 |
%  	   20 |  20.698  18.100 |    231    231 |


switch n
 case 3
  e_exp = 1.5734;
 case 4
  e_exp = 1.67132;
 case 5
  e_exp = 1.5585;
 case 6
  e_exp = 1.4308;
 case 7
  e_exp = 1.3988;
 case 8
  e_exp = 1.3975;
 case 9
  e_exp = 1.4045;
 case 10
  e_exp = 1.4346;
 case 11
  e_exp = 1.4182;
 case 12
  e_exp = 1.4253;
 case 13
  e_exp = 1.4360;
 case 14
  e_exp = 1.4395;
 case 15
  e_exp = 1.4463;
 case 16
  e_exp = 1.4509;
 case 17
  e_exp = 1.4545;
 case 18
  e_exp = 1.4592;
 case 19
  e_exp = 1.4632;
 case 20
  e_exp = 1.4650;
  
 otherwise
  e_exp = 1.46;
end % switch

end % function

