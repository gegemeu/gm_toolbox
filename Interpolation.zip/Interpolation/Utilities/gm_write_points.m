function gm_write_points(fname,x,y);
%GM_WRITE_POINTS writes point coordinates to a text file

% Writes x first and then y

% Input:
% fname = file name
% x, y = coordinates


% 
% Author G. Meurant
% August 2015
%

fid = fopen(fname,'w+');

if fid < 0
 error('gm_write_points: Cannot create file')
end

XY = [x; y];

fprintf(fid,'%22.15e %22.15e \n',XY);

fclose(fid);

