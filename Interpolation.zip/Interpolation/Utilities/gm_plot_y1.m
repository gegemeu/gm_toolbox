function gm_plot_y1(y1,x2,y2,x3,y3);
%GM_PLOT_Y1 utility function

npts = 100;

y = linspace(y1,1,npts);

% value at y = -1 when y1 varies between the given value and 1

x23 = x2 * y2 - x3 * y2;

denom = y * (x3 - x2) + x23;

numer = 2 * (x3 - x2) - x23 + y .* (x3 - x2);

f= numer ./ denom;

plot(y,f)

