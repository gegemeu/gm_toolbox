function [pts,pbot,ptop,plef,prig,nr,nt]=gm_disk_wam_order(n);
%GM_DISK_WAM_ORDER Computation of WAM points for the unit disk

% A different (and more regular) ordering of the nodes than in gm_disk_wam

% Output:
% pts = coordinates of the nodes
% pbot, ptop, plef, prig = numbers of the neighbours of a node

%
% Authors:
%          Len Bos           <leonardpeter.bos@univr.it>
%          Stefano De Marchi <demarchi@math.unipd.it>
%          Alvise Sommariva  <alvise@math.unipd.it>
%          Marco Vianello    <marcov@math.unipd.it>
%
%  October 18, 2010
%
% Modified by G. Meurant
% March 2017
%

% take n odd
if mod(n,2) == 0
 n = n + 1;
end

 r = -cos([(n+1)/2:n] * pi / n);
 theta = [0:2*n+1] * pi / (n + 1);
 
 nr = length(r);
 nt = length(theta);
 nd = nr * nt + 1;
 pts = zeros(nd,2);
 pts(1,:) = [0 0];
 pbot = zeros(nd,1);
 ptop = zeros(nd,1);
 plef = zeros(nd,1);
 prig = zeros(nd,1);
 
 % coordinates
 i = 1;
 for j = 1:nr
  for k = 1:nt
   i = i + 1;
   pts(i,1) = r(j) * cos(theta(k));
   pts(i,2) = r(j) * sin(theta(k));
  end % for k
 end % for j
 
 % neighbours
 % we have a periodic grid
 % nodes are ordered from the center to the boundary
 % and counterclockwise on a circle
  
 i = 1;
 for j = 1:nr
  for k = 1:nt
   i = i + 1;
   pbot(i) = i - nt;
   if j == 1 
    pbot(i) = 1;
   end % if
   ptop(i) = i + nt;
   if j == nr
    ptop(i) = 0;
   end % if
   plef(i) = i + 1;
   if k == nt 
    plef(i) = i - nt + 1;
   end % if
   prig(i) = i - 1;
   if k == 1
    prig(i) = i + nt - 1;
   end % if
%    [j k i pbot(i) ptop(i) plef(i) prig(i)]
  end % for k
 end % for j
    



