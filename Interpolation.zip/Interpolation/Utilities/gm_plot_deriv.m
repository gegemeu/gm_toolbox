function gm_plot_deriv(x2,y2);
%GM_PLOT_DERIV plot the derivative

npts = 100;

x = linspace(-1+eps,1-eps,npts);
y = x;

% set up the mesh
XY = [repmat(x',npts,1) kron(y,ones(1,npts))'];

x3 = XY(:,1);
y3 = XY(:,2);

f = (x3 - x2).^2 + (x3 - x2) .* (y2 * x3 - x2 * y3);

I = find( (x3.^2 + y3.^2) >= 1);
f(I) = 0;

II = find(f<0);
nII = length(II);
if nII > 0
 fprintf('\n there are %d points with f < 0 \n',nII)
%  [x3(II) y3(II) f(II)]
 gm_plot_points_disk([x3(II) y3(II)])
 hold on
 plot(x2,y2,'ro')
 hold off
 pause
end

% II = find( (x3.^2 + y3.^2) < 1);
% 
% gm_plot_points_disk([x3(II) y3(II)])
% pause

ff = reshape(f,npts,npts)';

shading interp
surf(x,y,ff)

