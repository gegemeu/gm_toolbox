function ind=gm_indic_func(X);
%GM_INDIC_FUNC indicating function for a 2D domain Omega

% Input:
% X = coordinates of the points (n x 2)
%
% Output:
% ind = 1 if all the points are within Omega, 0 otherwise

%
% Author G. Meurant
% July 2014
% Updated July 2015
%

global iprob


switch iprob
 
 case 1
  % unit square
  ind = 1;
  if any(X < -1) || any(X > 1)
   ind = 0;
  end % if any
  
 case 2
  % disk centered at (0,0), radius 1
  [p,q] = size(X);
  if p == 1
   X = X(:);
   [p,q] = size(X);
  end
  if q == 1
   nX = length(X) / 2;
   x = X(1:nX);
   y = X(nX+1:end);
  else
   nX = p;
   x = X(:,1);
   y = X(:,2);
  end
  I = find(((x).^2 + (y).^2 -1) > 0);
  if isempty(I)
   ind = 1;
  else
   ind = 0;
  end % if isempty
  
 case 3
  % L-shape region
  ind = 1;
  if any(X < -1) || any(X > 1)
   ind = 0;
  end % if any
  nX = length(X) / 2;
  x = X(1:nX);
  y = X(nX+1:end);
  if any(x > 0 & y > 0)
   ind = 0;
  end % if any
 
 case 4
  % triangle = simplex
  ind = 1;
  nX = length(X) / 2;
  x = X(1:nX);
  y = X(nX+1:end);
  if any(x < 0 | y < 0 | (x + y - 1 > 0))
   ind = 0;
  end % if any
   
 case 5
  % double bubble
  nX = length(X) / 2;
  x = X(1:nX);
  y = X(nX+1:end);
  I = find((x.^2 + y.^2 - 25 > 0) & ((x - 6).^2 + y.^2 - 9 > 0));
  if isempty(I)
   ind = 1;
  else
   ind = 0;
  end % if isempty
  
 case 6
  % ellipse centered at (0,0), semi-axes 2 and 1
  nX = length(X) / 2;
  x = X(1:nX);
  y = X(nX+1:end);
  I = find((x / 2).^2+(y).^2 -1 > 0);
  if isempty(I)
   ind = 1;
  else
   ind = 0;
  end % if isempty
  
 case 7
  % half-ellipse centered at (0,0), semi-axes 2 and 1, y >= 0 
  nX = length(X) / 2;
  x = X(1:nX);
  y = X(nX+1:end);
  I = find((x / 2).^2+(y).^2 -1 > 0);
  if isempty(I) & y >= 0
   ind = 1;
  else
   ind = 0;
  end % if isempty
  
 otherwise
  error('gm_infic_func: Wrong value of iprob')
end % switch



