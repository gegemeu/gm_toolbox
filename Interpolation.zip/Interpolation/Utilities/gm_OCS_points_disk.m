function [x,y]=gm_OCS_points_disk(degree);
%GM_OCS_POINTS_DISK OCS points in the unit disk

% See:  D.~Ramos-L�pez, M.A.~S�nchez-Granero, M.~Fern�ndez-Mart�nez and A.~Mart�nez�Finkelshtein, 
%         Optimal sampling patterns for Zernike polynomials, 
%         Applied Mathematics and Computation, v~274 (2016), pp.~247--257

%
% Input:
% degree = total degree of the bivariate polynomials
%
% Output:
% x, y = coordinate of the points
%

%
% Author G. Meurant
% Feb 2017
%

d = degree;
% number of points
n = (d + 1) * (d + 2) / 2;
x = zeros(n,1);
y = zeros(n,1);

kd = floor(d / 2) + 1;
nj = 2 * d + 5 - 4 * [1:kd]';

% radius
r = zeros(kd,1);
xij = cos((2 * [1:kd]' - 1) * pi / (2 * (d + 1)));
r = 1.1565 * xij - 0.76535 * xij.^2 + 0.60517 * xij.^3;

k = 0;
for j = 1:kd
 rj = r(j);
 % angles
 s = [1:nj(j)]';
 theta = 2 * pi * (s - 1) / nj(j);
 for i = 1:nj(j)
  k = k + 1;
  x(k) = rj * cos(theta(i));
  y(k) = rj * sin(theta(i));
 end % for i
end % for j

