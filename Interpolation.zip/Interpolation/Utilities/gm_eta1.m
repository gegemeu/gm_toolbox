function [mineta1,maxeta1,minchi1,maxchi1,minsum1,maxsum1]=gm_eta1(tet2,tet3);
%GM_ETA1 function eta1 for degree1, unit disk

c2 = cosd(tet2);
c3 = cosd(tet3);
s23 = sind(tet3-tet2);
c23 = cosd(tet3-tet2);

nptr = 50;
r = linspace(eps,1,nptr);

eta1 = zeros(nptr,nptr,nptr);
chi1 = eta1;
sum1 = eta1;

for i = 1:nptr
 r1 = r(i);
 for j = 1:nptr
  r2 = r(j);
  for k = 1:nptr
   r3 = r(k);
   num = r1 * r3 * c3 - r1 * r2 * c2 - r2 * r3 * s23;
   denom = r1 * r3 * c3 - r1 * r2 * c2 + r2 * r3 * s23;
   eta1(i,j,k) = abs(num / denom);
   %eta1(i,j,k) = abs(num);
   %eta1(i,j,k) = abs(denom);
   num2 = sqrt(r2^2 +  r3^2 - 2 * r2 * r3 * c23);
   chi1(i,j,k) = abs(num2 / denom);
   sum1(i,j,k) = eta1(i,j,k) + 2 * chi1(i,j,k);
  end % for k
 end % for j
end % for i

% values on the boundary
etar1 = abs((c3 - c2 -s23) / (c3 - c2 + s23))
chir1 = sqrt(2 - 2 * c23) / abs(c3 - c2 + s23)
sumr1 = etar1 + 2 * chir1

% mineta1 = min(min(min(eta1)));
% maxeta1 = max(max(max(eta1)));

et = eta1(:);
mineta1 = min(et);
maxeta1 = max(et);

ch = chi1(:);
minchi1 = min(ch);
maxchi1 = max(ch);

su = sum1(:);
minsum1 = min(su);
maxsum1 = max(su);





