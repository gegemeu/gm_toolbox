function leja=gm_leja_dbubble(deg);
%GM_LEJA_DBUBBLE Leja-like points in the double bubble
% center (0,0) radius 5
% center (6,0) radius 3

% Input:
% deg = degree of the bivariate polynomial
%       it yields (deg + 1) * (deg + 2) / 2 points
%
% Output:
% leja = coordinates of the points, x = leja(:,1), y = leja(:,2)

%
% adapted from M. Vianello
% May 2014
% Updated by G. Meurant
% July 2015
%

rect = [-5 9 -5 5];

H = gm_haltonseq(deg^3,2);
x = 14 * H(:,1) - 5;
y = 10 * H(:,2) - 5;
H(:,1) = x; 
H(:,2) = y;
ind = find(((H(:,1)).^2+(H(:,2)).^2 < 25) | ((H(:,1) - 6).^2+(H(:,2)).^2 < 9));
gmmesh = H(ind,:);

% computing the rectangular Chebyshev-Vandermonde matrix on the mesh

V = gm_chebvand(deg,gmmesh,rect);

% computing the approximate Leja points using the LU factorization
dim = (deg + 1) * (deg + 2) / 2;
[L,U,perm] = lu(V,'vector');
leja = gmmesh(perm(1:dim),:);







