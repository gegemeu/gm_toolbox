function [CellArea,V,C]=gm_Voronoi_disk(x,y);
%GM_VORONOI_DISK  Circle Bounded Voronoi Diagram

% This function computes the individual Voronoi cell area of point sets
% bounded in a unit circle

% Input:
% x = M x 1 array of x-coordinates
% y = M x 1 array of y-coordinates
%
% Output:
% CellArea   : M x 1 array of Voronoi cell area bounded in a unit circle
% V = coordinates of the vertices of the cells
% C = pointers to boundary nodes of the cells

% from a code by
% Meng Sang, Ong  & Ye Chow, Kuang (
% Photonic, Semiconductor & Communication Research Group
% School of Engineering
% Monash University Sunway campus
% October 2010

if any(size(x) ~= size(y))
 error('gm_Voronoi_disk: x,y dimensions are not consistent')
end

x = x(:); y = y(:);

clear global x_VoronoiGlobal y_VoronoiGlobal
global x_VoronoiGlobal y_VoronoiGlobal

x_VoronoiGlobal = x;
y_VoronoiGlobal = y;

% Voronoi tesselation using voronoin()
[V, C] = voronoin([x,y]);
[vx,vy] = voronoi(x,y);

% Force all voronoi vertices to be finite
[V,C] = gm_BoundVoronoin_UnitCircle(V, C);

% ---------------------------------------------------------------------

% Find boundary intersection points and each voronoi cell areas
NormV = realsqrt(sum(V.^2,2));
LenC  = length(C);
CellArea = zeros(LenC,1);
for index = 1 : LenC
 ptV = C{index};
 VSet = V(ptV,:);
 NormVSet = NormV(ptV);
 
 % Identify the vertex farthest from the origin to be the first scanning
 % vertex
 if max(NormVSet) < 1
  % All points inside unit circle, calculate area
  CellArea(index) = polyarea(V(ptV,1),V(ptV,2));
 else
  % Find points outside unit circle
  bOutside = NormVSet>1;
  bTestStartPoint = bOutside;
  bTestStartPoint = or(bTestStartPoint,circshift(bTestStartPoint,-1));
  ptComplimentaryPoint = mod(find(bTestStartPoint),length(VSet))+1;
  % Find intersection points (if exist)
  TestPoint1 = VSet(bTestStartPoint,:);
  TestPoint2 = VSet(ptComplimentaryPoint,:);
  if size(VSet,1) == 2
   TestPoint1(2,:) = [];
   TestPoint2(2,:) = [];
  end
  
  Norm1 = NormVSet(bTestStartPoint);
  Norm2 = NormVSet(ptComplimentaryPoint);
  if size(VSet,1) == 2
   Norm1(2,:) = [];
   Norm2(2,:) = [];
  end
  
  bOneInOneOut= xor(Norm1>1,Norm2>1);
  if any(bOneInOneOut)
   [xc1, yc1]  = gm_BoundaryIntersect_UnitCircle(TestPoint1(bOneInOneOut,:),TestPoint2(bOneInOneOut,:),1);
  else
   xc1 = [];
   yc1 = [];
  end
  bTwoOut     = and(Norm1>1,Norm2>1);
  if any(bTwoOut)
   [xc2, yc2]  = gm_BoundaryIntersect_UnitCircle(TestPoint1(bTwoOut,:),TestPoint2(bTwoOut,:),2);
   xc2 = reshape(xc2,numel(xc2),1);
   yc2 = reshape(yc2,numel(yc2),1);
   xc2(isnan(xc2)) = [];
   yc2(isnan(yc2)) = [];
  else
   xc2 = [];
   yc2 = [];
  end
  
  % Calculate cell area
  CellArea(index) = gm_CalcArea_UnitCircle(VSet(NormVSet<=1,:), [xc1,yc1], [xc2,yc2], index);
 end
 
 
end

% TotalArea = sum(CellArea);
% Err = TotalArea-pi;

% fprintf('Mean absolute Error = %.3e\n',mean(abs(Err)))
% fprintf('Largest absolute Error = %.3e\n',max(abs(Err)))

clear global x_VoronoiGlobal y_VoronoiGlobal
