function gm_plot_y1_angles(y1,x2,y2,x3,y3);
%GM_PLOT_Y1_ANGLES utility function

npts = 100;

y = linspace(y1,1,npts)';

% intersections with the unit circle
a = 1 + ((y2 - y1) / x2)^2;
b = 2 * y1 * (y2 - y1) / x2;
c = y1^2 - 1;
d = b^2 - 4 * a * c;
xi1 = (-b + sqrt(d)) / (2 * a);
xi2 = (-b - sqrt(d)) / (2 * a);
yi1 = xi1 * (y2 - y1) / x2 + y1;
yi2 = xi2 * (y2 - y1) / x2 + y1;
xp2 = xi1;
yp2 = yi1;
if yi2 == min(yi1,yi2)
 xp2 = xi2;
 yp2 = yi2;
end
a = 1 + ((y3 - y1) / x3)^2;
b = 2 * y1 * (y3 - y1) / x3;
c = y1^2 - 1;
d = b^2 - 4 * a * c;
xi1 = (-b + sqrt(d)) / (2 * a);
xi2 = (-b - sqrt(d)) / (2 * a);
yi1 = xi1 * (y3 - y1) / x3 + y1;
yi2 = xi2 * (y3 - y1) / x3 + y1;
xp3 = xi1;
yp = yi1;
if yi2 == min(yi1,yi2)
 xp3 = xi2;
 yp3 = yi2;
end

% find the angles corresponding to (xp2,yp2) and (xp3,yp3)
if xp2 == 0
 if yp2 > 0
  theta2 = 90;
 else
  theta2 = 270;
 end
else
 theta2 = atand(yp2 / xp2);
 if (xp2<0) && (yp2<0)
  theta2 = theta2 + 180;
 end
 if (xp2>0) && (yp2<0)
  theta2 = 360 + theta2;
 end
 if (xp2<0) && (yp2>0)
  theta2 = 180 + theta2;
 end
end

if xp3 == 0
 if yp3 > 0
  theta3 = 90;
 else
  theta3 = 270;
 end
else
 theta3 = atand(yp3 / xp3);
 if (xp3<0) && (yp3<0)
  theta3 = theta3 + 180;
 end
 if (xp3>0) && (yp3<0)
  theta3 = 360 + theta3;
 end
 if (xp3<0) && (yp3>0)
  theta3 = 180 + theta3;
 end
end

[theta2 theta3]

deriv1 = -1 - y3 + x3 * (y3 - y2) /(x3 - x2)

% set up the mesh in angles
% thetamin = min(theta2,theta3);
% thetamax = max(theta2,theta3);
npth = 100;
% theta = linspace(theta3,theta2,npth)';
diff = abs(theta3 - theta2);
if theta2 < 180
 diff = 360 - diff;
end
dtet = diff / (npth - 1);
theta = zeros(npth,1);
theta(1) = theta3;
for k = 2:npth;
 theta(k) = theta(k-1) + dtet;
end

x23 = x2 * y3 - x3 * y2;
xx = cosd(theta);
yy = sind(theta);
ff = zeros(npts,1);

gm_plot_points_disk([[0;x2;x3],[y1;y2;y3]])
hold on
plot(xx,yy,'r+')
hold off
pause

for j = 1:npts
 % x1 is zero
 y1 = y(j);
 
 % value at (xx,yy) given the value y1
 denom = y1 * (x3 - x2) + x23;
 
 numer = 2 * (y3 - y2) .* xx + 2 * (x2 - x3) .* yy - x23 + y1 .* (x3 - x2);
 
 f = numer ./ denom;
%  f = abs(f);
 
 I = find(f<0);
 if length(I) > 0
  fprintf('\n There are %d negative values for y = %g \n',length(I),y1)
 end
 
 ff(j) = max(f);
 
end

max(ff)
min(ff)

plot(y,ff)
title('Lebesgue constant as function of y > y1')



