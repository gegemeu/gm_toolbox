function [x,y]=gm_read_points(fname);
%GM_READ_POINTS reads point coordinates from a text file

% all x's first and then all y's

% Input:
% fname = file name
%
% Output:
% x, y = coordinates


% 
% Author G. Meurant
% August 2015
%

fid = fopen(fname,'r');

if fid < 0
 fname
 error('gm_read_points: Cannot open file')
end

r = fscanf(fid,'%g',inf);

nr = length(r);

x = r(1:nr/2);
y = r(nr/2+1:end);

fclose(fid);

