function f=gm_dist32(x,y);
%GM_DIST32 exemple of a 2D function to be interpolated

f = (x - 0.5).^2 + (y - 0.5).^(3/2);