function leja=gm_leja_triangle(deg);
%GM_LEJA_TRIANGLE Leja-like points in a triangular region [0 0; 1 0; 0 1];

% Input:
% deg = degree of the bivariate polynomial
%       it yields (deg + 1) * (deg + 2) / 2 points
%
% Output:
% leja = coordinates of the points, x = leja(:,1), y = leja(:,2)

%
% adapted from M. Vianello
% May 2014
% Updated by G. Meurant
% July 2015
%

rect = [-1 1 -1 1];

H = gm_haltonseq(deg^3,2);
x = H(:,1);
y = H(:,2);
xv = [0 0; 1 0; 0 1; 0 0];
in = inpolygon(x,y,xv(:,1),xv(:,2));
ind = find(in > 0);
gmmesh = H(ind,:);

% computing the rectangular Chebyshev-Vandermonde matrix on the mesh

V = gm_chebvand(deg,gmmesh,rect);

% computing the approximate Leja points using the LU factorization
dim = (deg + 1) * (deg + 2) / 2;
[L,U,perm] = lu(V,'vector');
leja = gmmesh(perm(1:dim),:);







