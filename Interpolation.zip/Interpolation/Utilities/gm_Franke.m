function f=gm_Franke(x,y);
%GM_FRANKE exemple of a 2D function

% Franke's function
term1 = 0.75 * exp(-(9 * x - 2).^2 / 4 - (9 * y - 2).^2 / 4);
term2 = 0.75 * exp(-(9 *x + 1).^2 / 49 - (9 * y + 1) / 10);
term3 = 0.5 * exp(-(9 * x - 7).^2 / 4 - (9 * y - 3).^2 / 4);
term4 = -0.2 * exp(-(9 * x - 4).^2 - (9 * y - 7).^2);

f = term1 + term2 + term3 + term4;