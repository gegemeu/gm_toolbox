function CellArea=gm_CalcArea_UnitCircle(VSet, V1, V2, ptS)
%GM_CALCAREA_UNITCIRCLE utility function

global x_VoronoiGlobal y_VoronoiGlobal

x = x_VoronoiGlobal;
y = y_VoronoiGlobal;

S               = [x(ptS),y(ptS)];
xOther          = x;
xOther(ptS)     = [];
yOther          = y;
yOther(ptS)     = [];

VBoundary       = [V1;V2];
VAll            = [VSet;VBoundary];
Centre          = mean(VAll,1);
% SAngle          = atan2(S(2)-Centre(2),S(1)-Centre(1));
% Angle           = atan2([VBoundary(:,2)]-Centre(2),[VBoundary(:,1)-Centre(1)]);
Angle           = atan2([VBoundary(:,2)],[VBoundary(:,1)]);
[Angle,index]   = sort(Angle);
VBoundary       = VBoundary(index,:);

% Starting point is characterised by ascribed angle greater than pi
AngleNext           = [Angle(2:end);Angle(1)];
DAngle              = AngleNext-Angle;
bCrossOver          = DAngle < 0;
DAngle(bCrossOver)  = DAngle(bCrossOver) + 2*pi;

RefAngle = Angle + 0.5*DAngle;
RefPoint = [cos(RefAngle),sin(RefAngle)];


% [MaxDAngle,index]   = max(DAngle);
% VBoundary           = circshift(VBoundary,[-index+1,0]);
% Angle               = circshift(Angle,[-index+1,0]);
% DAngle              = circshift(DAngle,[-index+1,0]);

ptNext      = [2:size(VBoundary,1),1];
SegAreaV    = 0;
for index = 1 : size(VBoundary,1)
 % Determine if there is a point inside the segment
 dx = VBoundary(index,1)-VBoundary(ptNext(index),1);
 dy = VBoundary(index,2)-VBoundary(ptNext(index),2);
 Side    = sign((xOther-VBoundary(index,1))*dy - (yOther-VBoundary(index,2))*dx);
 RefSide = sign((RefPoint(index,1)-VBoundary(index,1))*dy - (RefPoint(index,2)-VBoundary(index,2))*dx);
 if ~any(Side==RefSide)
  segAngV = atan2(VBoundary(ptNext(index),2),VBoundary(ptNext(index),1))-atan2(VBoundary(index,2),VBoundary(index,1));
  if segAngV < 0
   segAngV = segAngV + 2*pi;
  end
  SegAreaV  = SegAreaV  + 0.5*(segAngV-sin(segAngV));
 end
end

if size(VAll,1)>2
 vec             = VAll - repmat(Centre, size(VAll,1),1);
 Angle           = atan2(vec(:,2),vec(:,1));
 [sorted,index]  = sort(Angle); %#ok<ASGLU>
 VAll            = VAll(index,:);
 PolygonArea     = polyarea(VAll(:,1), VAll(:,2));
else
 PolygonArea     = 0;
end

CellArea = PolygonArea + SegAreaV;
