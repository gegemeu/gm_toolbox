function s=gm_dec2bigbase(d,base,n);
%GM_DEC2BIGBASE Convert decimal integer to base B vector

%   Returns the representation of D as a vector of digits in base B
%   D must be a non-negative integer smaller than 2^52
%   and base = B must be an integer greater than 1
%
%   DEC2BIGBASE(D,B,N) produces a representation with at least n digits.
%

%   written by Douglas M. Schwarz
%   Eastman Kodak Company
%   1 October 1998

error(nargchk(2,3,nargin));

if size(d,2) ~= 1
 d = d(:);
end

base = floor(base);
if base < 2
 error('B must be greater than 1.');
end % if base <
if base == 2,
 [x,nreq] = log2(max(d));
else
 nreq = ceil(log2(max(d) + 1) / log2(base));
end % if base ==

if nargin == 3
 nreq = max(nreq,1);
 n = max(n,nreq);
 last = n - nreq + 1;
else
 n = max(nreq,1);
 last = 1;
end % if nargin

s(:,n) = rem(d,base);
while n ~= last
 n = n - 1;
 d = floor(d/base);
 s(:,n) = rem(d,base);
end % while


