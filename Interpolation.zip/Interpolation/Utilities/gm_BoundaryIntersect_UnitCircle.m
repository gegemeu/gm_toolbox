function [xc, yc]=gm_BoundaryIntersect_UnitCircle(P1, P2, Mode)
%GM_BOUNDARYINTERSECT_UNITCIRCLE utility function

M = size(P1,1);

x1 = P1(:,1);
y1 = P1(:,2);
x2 = P2(:,1);
y2 = P2(:,2);

dx = x1 - x2;
dy = y1 - y2;

bNonsingular = (dx~=0);
bSingular    = ~bNonsingular;

switch Mode
 
 case 1
  % One point outside of unit circle while the other inside
  xc = zeros(M,1);
  yc = zeros(M,1);
  
  % Non-singular case
  if any(bNonsingular)    % Regular equation of line
   m = zeros(length(dx),1);
   c = zeros(length(dx),1);
   
   m(bNonsingular) = dy(bNonsingular)./dx(bNonsingular);
   c(bNonsingular) = P1(bNonsingular,2) - m(bNonsingular).*P1(bNonsingular,1);
   
   % Calculate circle intersect
   mc = m(bNonsingular).*c(bNonsingular);
   m2 = m(bNonsingular).^2;
   c2 = c(bNonsingular).^2;
   % Determinant is always positive due to the point configuration
   SqrtDeterminant = realsqrt(mc.^2 - (m2+1).*(c2-1));
   
   xBoundary1 = (-mc + SqrtDeterminant)./(m2+1);
   xBoundary2 = (-mc - SqrtDeterminant)./(m2+1);
   yBoundary1 = m(bNonsingular).*xBoundary1 + c(bNonsingular);
   yBoundary2 = m(bNonsingular).*xBoundary2 + c(bNonsingular);
   intersect1(bNonsingular,:) = [xBoundary1, yBoundary1];
   intersect2(bNonsingular,:) = [xBoundary2, yBoundary2];
  end
  
  % Singular case
  if any(bSingular)   % vertical line
   % Calculate circle intersect
   xBoundary = x1(bSingular);
   yBoundary = sqrt(1 - xBoundary.^2);
   intersect1(bSingular,:) = [xBoundary, yBoundary];
   intersect2(bSingular,:) = [xBoundary,-yBoundary];
  end
  
  % The dot product of (p1-intersect).(p2-intersect) is negative if the intersection point
  % lie between two points, as the two vectors take on different direction
  % Due to the point configuration, only one "intersect" test is
  % needed (the other one is logial compliment)
  v1 = sum((P1-intersect1).*(P2-intersect1),2);
  %         v2 = sum((P1-intersect2).*(P2-intersect2),2);
  
  v1neg = v1<0;
  v2neg = ~v1neg;
  
  xc(v1neg) = intersect1(v1neg,1);
  xc(v2neg) = intersect2(v2neg,1);
  yc(v1neg) = intersect1(v1neg,2);
  yc(v2neg) = intersect2(v2neg,2);
  
  
 case 2
  % Both points are outside of unit circle
  xc = nan(size(P1,1),2);
  yc = nan(size(P1,1),2);
  
  if any(bNonsingular)    % Regular equation of line
   
   m = dy(bNonsingular)./dx(bNonsingular);
   c = y1(bNonsingular) - m.*x1(bNonsingular);
   
   % Calculate circle intersect
   mc = m.*c;
   m2 = m.^2;
   c2 = c.^2;
   Determinant = mc.^2 - (m2+1).*(c2-1);
   SqrtDeterminant = sqrt(Determinant);
   
   xBoundary(:,1) = (-mc + SqrtDeterminant)./(m2+1);
   xBoundary(:,2) = (-mc - SqrtDeterminant)./(m2+1);
   yBoundary(:,1) = m.*xBoundary(:,1) + c;
   yBoundary(:,2) = m.*xBoundary(:,2) + c;
   % Remove complex solutions
   xBoundary(Determinant<0,1:2) = nan;
   yBoundary(Determinant<0,1:2) = nan;
   
   % Ensures that [xc,yc] is between the two voronoi vertices.
   % Perform dot product on one point is sufficient
   v = sum((P1(bNonsingular,:)-[xBoundary(:,1),yBoundary(:,1)])...
    .* (P2(bNonsingular,:)-[xBoundary(:,1),yBoundary(:,1)]),2);
   
   xBoundary(v>0,1:2) = nan;
   yBoundary(v>0,1:2) = nan;
   
   xc(bNonsingular,:) = xBoundary;
   yc(bNonsingular,:) = yBoundary;
  end
  
  if any(bSingular)   % vertical line
   xBoundary = P1(bSingular,1);
   xBoundary(abs(xBoundary)>1)= nan;
   xc(bSingular,:) = repmat(xBoundary,1,2);
   yc(bSingular,1) = realsqrt(1 - xBoundary.^2);
   yc(bSingular,2) = -yc(bSingular,1);
  end
  
end

