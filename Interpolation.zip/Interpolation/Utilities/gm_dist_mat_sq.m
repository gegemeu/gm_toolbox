function [dmat,dmati]=gm_dist_mat_sq(x,y);
%GM_DIST_MAT_SQ matrix of the squares of the pairwise distances between points

%
% Input:
% x,y = coordinates of the points
%
% Output:
% dmat = matrix of the squares of the pairwise distances
% dmati = matrix of the inverses of the distances squared
%         except for the diagonal which is zero
%

%
% Author G. Meurant
% February 2017
%

[xi,xj] = meshgrid(x,x);
[yi,yj] = meshgrid(y,y);

dmat = (xi - xj).^2 + (yi - yj).^2;

n = length(x);
dmati = dmat + eye(n,n);
dmati = 1 ./ dmati - eye(n,n);

