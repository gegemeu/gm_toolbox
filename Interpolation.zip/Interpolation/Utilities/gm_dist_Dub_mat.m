function [dmat,dmati,vd,difmind,diffav]=gm_dist_Dub_mat(x,y);
%GM_DIST_DUB_MAT matrix of the pairwise Dubiner distances between points

%
% Input:
% x,y = coordinates of the points
%
% Output:
% dmat = matrix of the pairwise Dubiner distances
% dmati = matrix of the inverses of the Dubiner distances 
%         except for the diagonal which is zero
% vd = proportional to the variance of the minimal Dubiner distances
% difmind = differences of the minimal Dubiner distances squared
% diffav = differences of the average Dubiner distances squared
%

%
% Author G. Meurant
% March 2017
%

% to be done

[xi,xj] = meshgrid(x,x);
[yi,yj] = meshgrid(y,y);

% dmat = sqrt((xi - xj).^2 + (yi - yj).^2);

% Dubiner distance for the unit disk
dmat = abs(acos(xi .* xj + yi .* yj + sqrt(1 - xi.^2 - yi.^2) .* sqrt(1 - xj.^2 - yj.^2)));

n = length(x);
dmati = dmat + eye(n,n);
dmati = 1 ./ dmati - eye(n,n);

% minimum distances for each point
mind = min(dmat+100*eye(n,n));

% mean of the minimum distances
avd = sum(mind) / n;

% n times variance
vd = sum((mind - avd).^2);

% differences of the minimal distances squared
[di,dj] = meshgrid(mind,mind);
difmind =  (di - dj).^2;

% % average distances
% avdist = sum(dmat) / n;
% % differences of the average distances squared
% [di,dj] = meshgrid(avdist,avdist);
% diffav = (di - dj).^2;
diffav = 0;

