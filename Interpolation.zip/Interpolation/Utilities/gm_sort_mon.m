function Exponent=gm_sort_mon(d,ord);
%GM_SORT_MON sorts the monomials x^i y^j according to the order ord

% Input:
% d = total maximum degree of the monomials
% ord = ordering, can be 'lex', 'grlex', 'grevlex'
%
% Output:
% Exponent = exponents of the monomials

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

% generate the exponents of the lexicographic ordering
% keep only the tuples for which sum <= d

Expo = [repmat([0:d],1,d+1); kron([0:d],ones(1,d+1))];
% remove those with sum > degree
I = find(sum(Expo) <= d);
Exp = Expo(:,I)';

switch ord
 
 case 'lex'
  Exponent = Exp;
  
 case 'grlex'
  
  Exp = sortrows([sum(Exp,2) Exp]);
  
  Exponent = [Exp(:,3) Exp(:,2)];
  
 case 'grevlex'
  
  Exp = sortrows([sum(Exp,2) Exp]);
  
  Exponent = Exp(:,2:3);
  
 case 'rand'
  
  % this ordering can lead to zero pivots
  
  Expp = Exp(2:end,:);
  I = randperm(size(Expp,1));
  
  Exponent = [Exp(1,:); Expp(I,:)];
  
 otherwise
  
  error('gm_sort_mon: This ordering does not exist')
  
end % switch





