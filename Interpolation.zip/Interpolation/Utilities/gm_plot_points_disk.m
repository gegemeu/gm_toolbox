function gm_plot_points_disk(pts);
%GM_PLOT_POINTS_DISK plot of the given points in the unit disk

%
% Input:
% pts = coordinates of the points, x = pts(:,1), y = pts(:,2)
%

%
% Author G. Meurant
% Feb 2017

plot(pts(:,1),pts(:,2),'b*')

hold on

gm_draw_circle(50,0,0,1);

hold off

