function [v,beta,P]=gm_house_orthpol(x,m);
%GM_HOUSE_ORTHPOL Householder transformation to zero components m+1 to n of x

% doesn't touch components 1 to m-1
% from Golub and Van Loan without normalization
% to be used for bivariate orthogonal polynomials
% The Householder matrix is P = eye(nx,nx) - beta * v * v'
% P is not computed and returned (too expensive!)

% Input:
% x = vector
% m = we zero the components below component m (m < n)
%
% Output:
% v = transformed vector
% beta = used to construct and apply the transformation

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

% get the components we want to modify
% nx = length(x);
x = x(m:end);
n = length(x);

sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];

if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1) = -sig / (x(1) + mu);
 end % if x
 
 beta = 2 / (sig + v(1)^2);

end %  if sig

v = [zeros(m-1,1); v];

% this is the orthogonal Householder matrix
% P = eye(nx,nx)-beta*v*v';
P = 0;


