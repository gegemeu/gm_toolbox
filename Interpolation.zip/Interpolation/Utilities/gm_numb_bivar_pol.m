function N=gm_numb_bivar_pol(d);
%GM_NUMB_BIVAR_POL number of bivariate polynomials of total degree d

%
% Author G. Meurant
% April 2014
%

N = ((d + 1) * (d + 2)) / 2;

