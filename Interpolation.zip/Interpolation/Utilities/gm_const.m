function f=gm_const(x,y,X);
%GM_CONST constant function

f = 1;

end