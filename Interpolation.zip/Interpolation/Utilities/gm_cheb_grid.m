function [x,y,xm,ym]=gm_cheb_grid(d);
%GM_CHEB_GRID a grid of Chebyshev points on [-1,1]^2

% Input:
% d = number of points on one side
%
% Output:
% x,y = zeros
% xm,ym = maxima

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

% zeros of Chebyshev polynomials

pis2p = pi / (2 * d);

% zeros on [-1,1]

k = [0:d-1];
z = cos((2 * k + 1) * pis2p);

z = z(end:-1:1);
xx = z;
yy = z;
npts = length(z);

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];
x = XY(:,1);
y = XY(:,2);


% max of Chebyshev polynomials

J = [0:d];
z = cos(J * pi / d);
z = z(end:-1:1);
xx = z;
yy = z;
npts = length(z);

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];
xm = XY(:,1);
ym = XY(:,2);
