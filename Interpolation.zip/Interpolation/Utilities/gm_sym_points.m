function [xs,ys]=gm_sym_points(x,y);
%GM_SYM_POINTS symmetrize a set of points in a symmetric compact set of R^2
% containing the origin

%
% Author G. Meurant
% August 2015
%

x = x(:);
y = y(:);

n = length(x);

I = find(y > 0);
In = find(y < 0);

nI = length(I);
nIn = length(In);

if 2 * nI == n
 xs = [x(I); x(I)];
 ys = [y(I); -y(I)];
 return
end % if

xmin = min(x);
xmax = max(x);

if nI > nIn
 dif = nI - nIn;
 xdif = xmin + rand(dif,1) * (xmax - xmin);
 xs = [x(In); x(In); xdif];
 ys = [-y(In); y(In); zeros(dif,1)];
else
 dif = nIn - nI;
 xdif = xmin + rand(dif,1) * (xmax - xmin);
 xs = [x(I); x(I); xdif];
 ys = [y(I); -y(I); zeros(dif,1)];
end % if


