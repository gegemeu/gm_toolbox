function [locmax,valmax,x,y]=gm_Leb_local_max_disk(pts,vpts,pbot,ptop,plef,prig,nr,nt);
%GM_LEB_LOCAL_MAX_DISK finds the local maxima of the Lebesgue function in the
% unit disk

% A local maxima is defined as a point whose value is larger than the max
% at its 4 neighbours

% the inputs are computed in gm_disk_wam_order

%
% Input:
% pts = coordinates of the nodes
% vpts = (positive) values of the Lebesgue function at nodes pts
% pbot, ptop, plef, prig = numbers of the neighbours of points in pts
% nr, nt = numbers of nodes in the radial and azimuthal directions
%
% Output:
% locmax = numbers (in vpts) of the local maxima
% valmax = values at the local maxima
% x, y = coordinates of the local maxima


%
% Author G. Meurant
% March 2017
%

n = size(pts,1);
ns4 = ceil(n/4);
locmax = zeros(ns4,1);
valmax = zeros(ns4,1);
x  = zeros(ns4,1);
y = zeros(ns4,1);

iloc = 0;

% The first node is the origin and is special
% it has nt neighbours

val0 = vpts(2:nt+1);
if vpts(1) > max(val0)
 % the origin is a local max
 iloc = iloc + 1;
 locmax(iloc) = 1;
 valmax(iloc) = vpts(1);
 x(iloc) = pts(1,1);
 y(iloc) = pts(1,2);
end % if

% the first circle has less neighbours
for k = 2:nt+1
 vb = vpts(pbot(k));
 vt = vpts(ptop(k));
 vl = vpts(plef(k));
 vr = vpts(prig(k));
 ptopr = prig(ptop(k));
 vtr = vpts(ptopr);
 ptopl = plef(ptop(k));
 vtl = vpts(ptopl);
 max_neighb = max([vb vt vl vr vtr vtl]);
 if vpts(k) > max_neighb
  % the point k is a local max
  iloc = iloc + 1;
  locmax(iloc) = k;
  valmax(iloc) = vpts(k);
  x(iloc) = pts(k,1);
  y(iloc) = pts(k,2);
 end % if
end % for k

% other nodes (not including the boundary) have 8 neighbours
for k = nt+2:n-nt
 vb = vpts(pbot(k));
 vt = vpts(ptop(k));
 vl = vpts(plef(k));
 vr = vpts(prig(k));
 pbotr = prig(pbot(k));
 vbr = vpts(pbotr);
 pbotl = plef(pbot(k));
 vbl = vpts(pbotl);
 ptopr = prig(ptop(k));
 vtr = vpts(ptopr);
 ptopl = plef(ptop(k));
 vtl = vpts(ptopl);
 max_neighb = max([vb vt vl vr vbr vbl vtr vtl]);
 if vpts(k) > max_neighb
  % the point k is a local max
  iloc = iloc + 1;
  locmax(iloc) = k;
  valmax(iloc) = vpts(k);
  x(iloc) = pts(k,1);
  y(iloc) = pts(k,2);
 end % if
end % for k

% points on the boundary have only 5 neighbours
for k = n-nt+1:n
 vb = vpts(pbot(k));
 vl = vpts(plef(k));
 vr = vpts(prig(k));
 pbotl = plef(pbot(k));
 vbl = vpts(pbotl);
 pbotr = prig(pbot(k));
 vbr = vpts(pbotr);
 max_neighb = max([vb vl vr vbr vbl]);
 if vpts(k) > max_neighb
  % the point k is a local max
  iloc = iloc + 1;
  locmax(iloc) = k;
  valmax(iloc) = vpts(k);
  x(iloc) = pts(k,1);
  y(iloc) = pts(k,2);
 end % if
end % for k
  
locmax = locmax(1:iloc);
valmax = valmax(1:iloc);
x = x(1:iloc);
y = y(1:iloc);



