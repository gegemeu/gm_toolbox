function x=gm_cheb_max(xmin,xmax,npts);
%GM_CHEB_MAX max of Chebyshev polynomials in [xmin,xmax]

%
% Author G. Meurant
% May 2014
%

% max of Chebyshev polynomials
J = [0:npts-1];
z = cos(J * pi / (npts - 1));
z = z(end:-1:1);

% change to [xmin,xmax]
x = ((xmax - xmin) * z + xmax + xmin) / 2;

