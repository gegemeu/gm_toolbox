function pts=gm_spiral_disk(deg);
%GM_SPIRAL_DISK spiral points in the unit disk

%
% Input:
% deg = degree of the bivariate polynomials
%
% Output:
% pts = coordinates of the points (x = pts(:,1), y = pts(:,2))
%

% 
% Author G. Meurant
% February 2017
%

tet = (3 - sqrt(5)) * pi;

n = ((deg + 1) * (deg + 2)) / 2;

% angles
rho = tet * [1:n]';

%radius
n1 = 1 / n;
tau = sqrt(n1 * [1:n]');

size(tau)

pts  = zeros(n,2);
pts(:,1) = tau .* cos(rho);
pts(:,2) = tau .* sin(rho);

