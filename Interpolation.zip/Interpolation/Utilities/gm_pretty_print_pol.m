function str=gm_pretty_print_pol(Exp,coeff);
%GM_PRETTY_PRINT_POL prints the bivariate polynomial defined by Exp and coeff

% Input:
% Exp = exponents (n x 2)
% coeff = coefficients of the polynomial
%
% Output;
% str = printable character string

%
% Author G. Meurant
% May 2014
% Updated August 2015
%

coeff = coeff(:);
if length(coeff) < size(Exp,1)
 error('gm_pretty_print_pol: The length of coeff is too short')
end

I = find(abs(coeff)>0);
n = I(length(I));

if coeff(n) == 1
 str = '1';
else
 str = [num2str(coeff(n),'%10.5e')];
end % if coeff
E = Exp(n,:);
mon = '';
if sum(E) == 0
 % nothing to do
else
 if E(1) ~= 0
  if E(1) ~= 1
   mon = ['*x^' num2str(E(1))];
  else
   mon = ['*x'];
  end % if E
 end % if E ~= 0
 if E(2) ~= 0
  if E(2) ~= 1
   mon = [mon '*y^' num2str(E(2))];
  else
   mon = [mon '*y'];
  end % if E
 end % if E ~= 0
end % if sum
str = [str mon];

for k = n-1:-1:1
 if coeff(k) > 0
  str = [str '+'];
 elseif coeff(k) == 0
  continue
 end % if coeff
 if coeff(k) == 1
  strr = '';
 else
  strr = num2str(coeff(k),'%10.5e');;
 end % if coeff
 E = Exp(k,:);
 mon = '';
 if sum(E) == 0
  if coeff(k) ~= 0
   mon = '';
  end % if coeff
 else
  if E(1) ~= 0
   if E(1) ~= 1
    mon = ['*x^' num2str(E(1))];
   else
    mon = ['*x'];
   end % if E
  end % if E ~= 0
  if E(2) ~= 0
   if E(2) ~= 1
    mon = [mon '*y^' num2str(E(2))];
   else
    mon = [mon '*y'];
   end % if E
  end % if E ~= 0
 end % if sum
 str = [str strr mon];
end % for k

