function [pb,ipb,degree,mu,type]=gm_decode_fname(fname);
%GM_DECODE_FNAME decodes the name of files containing point coordinates

% Input:
% fname = character string, local name of the file (in the folder)
%
% Output:
% pb = character string, name of the problem
% ipb = problem number
% degree = degree of the bivariate orthogonal polynomials
% mu = value of the multiplicative coeeficient for the boundary integral
% type = type of the file ('l2', 'ref' or '1p')

%
% Author G. Meurant
% August 2015
%

if strcmpi(fname(1:9),'gm_square') == 1
 pb = 'square';
 ipb = 1;
 % start of the remaining part of the string
 st = 10;
elseif strcmpi(fname(1:7),'gm_disk') == 1
 pb = 'disk';
 ipb = 2;
 % start of the remaining part of the string
 st = 8;
elseif strcmpi(fname(1:9),'gm_Lshape') == 1
 pb = 'Lshape';
 ipb = 3;
 % start of the remaining part of the string
 st = 10;
elseif strcmpi(fname(1:11),'gm_triangle') == 1
 pb = 'triangle';
 ipb = 4;
 % start of the remaining part of the string
 st = 12;
elseif strcmpi(fname(1:10),'gm_dbubble') == 1
 pb = 'dbubble';
 ipb = 5;
 % start of the remaining part of the string
 st = 11;
elseif strcmpi(fname(1:10),'gm_ellipse') == 1
 pb = 'ellipse';
 ipb = 6;
 % start of the remaining part of the string
 st = 11;
 elseif strcmpi(fname(1:11),'gm_hellipse') == 1
 pb = 'hellipse';
 ipb = 7;
 % start of the remaining part of the string
 st = 12;
end % if strcmpi

nf = length(fname);

for i = st:nf
 if strcmpi(fname(i),'-') == 1
  se = i - 1;
  break
 end % if strcmpi
end % for i

degree = str2num(fname(st:se));

st = se + 2;

for i = st:nf
 if strcmpi(fname(i),'-') == 1
  se = i - 1;
  break
 end % if strcmpi
end % for i

mu = str2num(fname(st:se)) / 100;

st = se + 2;

type = fname(st:nf);




