function gm_print_points(x,y);
%GM_PRINT_POINTS prints point coordinates 

% Writes x first and then y

% Input:
% x, y = coordinates


% 
% Author G. Meurant
% January 2017
%

n = size(x,1);

fprintf('\n -----------coordinates \n\n')

for k = 1:n
 fprintf('%24.17e   %24.17e \n',x(k),y(k));
end

fprintf(' ------------- \n\n')


