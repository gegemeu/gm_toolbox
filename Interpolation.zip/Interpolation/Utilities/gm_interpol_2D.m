%Interpol_2D Interpolation using bivariate orthogonal polynomials

%
% Author G. Meurant
% August 2014
% Updated August 2015
%

% ipb = 1 (square), 2 (disk), 3 (Lshape), 4 (simplex), 5 (Dbubble), 
% 6 (ellipse)

ipb = 2;

% dmax is the maximum total degree of the polynomials
switch ipb
 
 case 1
  pb = 'square';
  dmax = 10;
  dmin = 3;
  
 case 2
  pb = 'disk';
  dmax = 5;
  dmin = 2;
  
 case 3
  pb = 'Lshape';
  dmax = 10;
  dmin =2;
  
 case 4
  pb = 'simplex';
  dmax = 10;
  dmin = 2;
  
 case 5
  pb = 'dbubble';
  dmax = 10;
  dmin = 2;
  
%  case 6
%   pb = 'ellipse';
%   dmax = 20;
%   dmin = 2;
  
end

errleja = zeros(1,5);
errxb = zeros(1,5);
errxit = zeros(1,5);
errxb2 = zeros(1,5);
errxit2 = zeros(1,5);
errx1 = zeros(1,5);
errx12 = zeros(1,5);
errPad = zeros(1,5);

eleja = zeros(dmax,5);
exb = zeros(dmax,5);
exit = zeros(dmax,5);
exb2 = zeros(dmax,5);
exit2 = zeros(dmax,5);
ex1 = zeros(dmax,5);
ex2 = zeros(dmax,5);
ePad = zeros(dmax,5);

for d = dmin:dmax
 % d = degree
 % those files are in Work
%  pbc = ['gm_' pb num2str(d) '-0'];
 pbc = [pb num2str(d) '-0'];
 load(pbc,'leja','xb','yb','xit4','yit4','x1','y1','w')
 
 [Int,Pad,weight] = gm_quadPD(@gm_const,d,[-1 1],[-1 1],2,0);
 
%  Pad = VB_pdpts(d);
 
 for ifcn = 1:5
  [Psinp,maxL,diff,XY,errleja(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,leja(:,1),leja(:,2),w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errxb(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,xb,yb,w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errxit(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,xit4,yit4,w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errx1(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,x1,y1,w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errPad(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,Pad(:,1),Pad(:,2),w,100,ipb,ifcn);
 end % for ifcn
 
%  pbc = ['gm_' pb num2str(d) '-05'];
 pbc = [pb num2str(d) '-05'];
%  if ipb == 5
%   pbc = [pb num2str(d) '-3'];
%  end
 load(pbc,'xb','yb','xit4','yit4','x1','y1','w')
 
 for ifcn = 1:5
  [Psinp,maxL,diff,XY,errxb2(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,xb,yb,w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errxit2(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,xit4,yit4,w,100,ipb,ifcn);
  [Psinp,maxL,diff,XY,errx12(ifcn),errl2] = gm_comp_interp_OPHL(@gm_func_interp,x1,y1,w,100,ipb,ifcn);
 end % for ifcn
 
 eleja(d,:) = errleja;
 exb(d,:) = errxb;
 exit(d,:) = errxit;
 exb2(d,:) = errxb2;
 exit2(d,:) = errxit2;
 ex1(d,:) = errx1;
 ex2(d,:) = errx12;
 ePad(d,:) = errPad;
 
 fprintf(' degree = %d \n',d)
 fprintf('                    f1,        f2,         f3,         f4,        f5 \n')
 fprintf('  mu = 0 \n')
 fprintf(' leja:         %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errleja)
 fprintf(' l2 min :      %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errxb)
 fprintf(' ref:          %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errxit)
 fprintf(' 1-point min : %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errx1)
 fprintf('  mu = 0.5 \n')
 fprintf(' leja:         %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errxb2)
 fprintf(' ref:          %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errxit2)
 fprintf(' 1-point min:  %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errx12)
 
 if ipb == 1
  fprintf(' Pad points:  %0.3e, %0.3e, %0.3e, %0.3e, %0.3e \n',errPad)
 end % if ipb
 
 fprintf('----------------------------------------------------------------------------\n')
 
end % for d

for ifcn = 1:5
 figure
 semilogy([dmin:dmax],eleja(dmin:dmax,ifcn),'-*')
 hold on
 semilogy([dmin:dmax],exb(dmin:dmax,ifcn),'r-+')
 semilogy([dmin:dmax],exit(dmin:dmax,ifcn),'g-o')
 semilogy([dmin:dmax],ex1(dmin:dmax,ifcn),'b-<')
 semilogy([dmin:dmax],exb2(dmin:dmax,ifcn),'m-d')
 semilogy([dmin:dmax],exit2(dmin:dmax,ifcn),'k->')
 semilogy([dmin:dmax],ex2(dmin:dmax,ifcn),'b-^')
 
 if ipb == 1
  semilogy([dmin:dmax],ePad(3:dmax,ifcn),'c-v')
 end % if ipb
 ft = ['f_' num2str(ifcn)];
 title(ft)
 if ipb == 1
  legend('Leja','mu=0','R mu=0','loc mu=0','mu=0.5','R mu=0.5','loc mu=0.5','Pad')
 else
  legend('Leja','mu=0','R mu=0','loc mu=0','mu=0.5','R mu=0.5','loc mu=0.5')
 end % if ipb
%  if ipb == 5
%   legend('Leja','mu=0','R mu=0','loc mu=0','mu=3','R mu=3','loc mu=3')
%  end

 hold off
end % for ifcn









