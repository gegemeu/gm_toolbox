function leja=gm_leja_square(deg);
%GM_LEJA_SQUARE Leja-like points in [-1,1]^2

% Input:
% deg = degree of the bivariate polynomial
%       it yields (deg + 1) * (deg + 2) / 2 points
%
% Output:
% leja = coordinates of the points, x = leja(:,1), y = leja(:,2)

%
% adapted from M. Vianello
% May 2014
% Updated by G. Meurant
% July 2015
%

rect = [-1 1 -1 1];

H = gm_haltonseq(deg^3,2);
 
x = 2 * H(:,1) - 1;
y = 2 * H(:,2) - 1;
H(:,1) = x; 
H(:,2) = y;
gmmesh = H;

% computing the rectangular Chebyshev-Vandermonde matrix on the mesh

V = gm_chebvand(deg,gmmesh,rect);

% computing the approximate Leja points using the LU factorization

dim = (deg + 1) * (deg + 2) / 2;
[L,U,perm] = lu(V,'vector');
leja = gmmesh(perm(1:dim),:);







