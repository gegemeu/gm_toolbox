% UTILITIES
%
% Files
%   gm_absxy                        - exemple of a 2D function to be interpolated
%   gm_BoundaryIntersect_UnitCircle - utility function
%   gm_BoundVoronoin_UnitCircle     - utility function
%   gm_CalcArea_UnitCircle          - utility function
%   gm_car_go_disk                  - Carnicer-Godes nodes for the unit disk
%   gm_cheb_grid                    - a grid of Chebyshev points on [-1,1]^2
%   gm_cheb_max                     - max of Chebyshev polynomials in [xmin,xmax]
%   gm_chebvand                     - computes the Chebyshev-Vandermonde matrix on a 2d or 3d given mesh
%   gm_const                        - constant function
%   gm_cos5x5y                      - exemple of a 2D function to be interpolated
%   gm_cosxy                        - exemple of a 2D function to be interpolated
%   gm_dec2bigbase                  - Convert decimal integer to base B vector
%   gm_decode_fname                 - decodes the name of files containing point coordinates
%   gm_decode_fnameM                - decodes the name of files containing point coordinates
%   gm_disk_wam                     - computation of WAM points for the unit disk
%   gm_disk_wam_order               - computation of WAM points for the unit disk
%   gm_disk_wam_radius              - computation of WAM points for a given disk
%   gm_dist32                       - exemple of a 2D function to be interpolated
%   gm_dist_Dub_mat                 - matrix of the pairwise Dubiner distances between points
%   gm_dist_mat                     - matrix of the pairwise distances between points
%   gm_dist_mat_sq                  - matrix of the squares of the pairwise distances between points
%   gm_ellipse_wam                  - Computation of WAM points for an ellipse of center 0,0 and semi-axes a,b
%   gm_eta1                         - function eta1 for degree1, unit disk
%   gm_Franke                       - exemple of a 2D function
%   gm_func_interp                  - function for 2D interpolation tests
%   gm_haltonseq                    - generate a Halton sequence in NDIMS dimensional space
%   gm_house_orthpol                - Householder transformation to zero components m+1 to n of x
%   gm_indic_func                   - indicating function for a 2D domain Omega
%   gm_interpol_2D                  - Interpol_2D Interpolation using bivariate orthogonal polynomials
%   gm_Leb_local_max_disk           - finds the local maxima of the Lebesgue function in the
%   gm_leja_dbubble                 - Leja-like points in the double bubble
%   gm_leja_disk                    - Leja-like points in the unit disk, center (0,0), radius 1
%   gm_leja_ellipse                 - Leja-like points in an ellipse, center (0,0), semi-axes a and b
%   gm_leja_hellipse                - Leja-like points in a half ellipse, center (0,0), semi-axes a and b
%   gm_Leja_Lebesgue                - Lebesgue constants for Leja-like points
%   gm_leja_Lshape                  - Leja-like points for the L-shape region
%   gm_leja_square                  - Leja-like points in [-1,1]^2
%   gm_leja_triangle                - Leja-like points in a triangular region [0 0; 1 0; 0 1];
%   gm_max_Leb_regionI              - value of the Lebesgue constant in region I
%   gm_numb_bivar_pol               - number of bivariate polynomials of total degree d
%   gm_OCS_points_disk              - OCS points in the unit disk
%   gm_plot_deriv                   - plot the derivative
%   gm_plot_maxLeb_xi2              - Lebesgue constant in region I with xi_1 and xi_3 fixed
%   gm_plot_maxLeb_y2               - minimum of the Lebesgue constant in region I and III
%   gm_plot_points_disk             - plot of the given points in the unit disk
%   gm_plot_y1                      - utility function
%   gm_plot_y1_angles               - utility function
%   gm_pretty_print_pol             - prints the bivariate polynomial defined by Exp and coeff
%   gm_print_points                 - prints point coordinates 
%   gm_read_points                  - reads point coordinates from a text file
%   gm_row_col_mon                  - row numbers (pivots) of H_x or H_y
%   gm_sort_mon                     - sorts the monomials x^i y^j according to the order ord
%   gm_spiral_disk                  - spiral points in the unit disk
%   gm_sym_points                   - symmetrize a set of points in a symmetric compact set of R^2
%   gm_Voronoi_disk                 - Circle Bounded Voronoi Diagram
%   gm_write_points                 - writes point coordinates to a text file
