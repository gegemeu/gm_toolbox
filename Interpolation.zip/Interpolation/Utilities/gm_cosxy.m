function f=gm_cosxy(x,y);
%GM_COSXY exemple of a 2D function to be interpolated

f = cos( x + y);

