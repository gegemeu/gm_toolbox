function row=gm_row_col_mon(Exp,dir,nmax,d);
%GM_ROW_COL_MON row numbers (pivots) of H_x or H_y

% This is used to construct rowxy which describes the structure of Hx, Hy

% Input:
% Exp = ordered monomials (x^i y^j)
% dir = 1 (x), dir = 2 (y)
% nmax = max number of rows in Hx and Hy
% d = total degree
%
% Output:
% row = row numbers

%
% Author G. Meurant
% April 2014
% Updated July 2015
%

n = size(Exp,1);
row = zeros(n,1);

switch dir
 
 case 1
  % look for monomials to the right
  E = Exp(:,1) + 1;
  I = find((E + Exp(:,2))  > d);
  E(I) = NaN;
  Exps = [E, Exp(:,2)];
  
 case 2
  % look for the ones to the top
  E = Exp(:,2) + 1;
  I = find((E + Exp(:,1)) > d);
  E(I) = NaN;
  Exps = [Exp(:,1), E];
  
 otherwise
  error('gmrow_col_mon: dir has to be 1 or 2')
end % switch

% find the positions of the pairs in Exps with respect to Exp

dExps = Exps(:,1) + Exps(:,2);
dExp = Exp(:,1) + Exp(:,2);

for k = 1:n
 I = find(dExp == dExps(k));
 if isempty(I)
  row(k) = n + 1;
 else
  for j = 1:length(I)
   if Exps(k,dir) == Exp(I(j),dir)
    break
   end % if
  end % for j
  row(k) = I(j);
 end % if
end % for k

row = min(row,nmax + 1);





