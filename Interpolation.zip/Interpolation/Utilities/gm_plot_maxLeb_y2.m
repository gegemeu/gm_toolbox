function gm_plot_maxLeb_y2
%GM_PLOT_MAXLEB_Y minimum of the Lebesgue constant in region I and III

% We assume thatxi_1 = (0,1) that y_3 = y_2 and look for the
% minimum of the Lebesgue constant in region I (that is for (0,-1) and III) as a
% function of y_2

npts = 500;
yy = linspace(0.1,-0.95,npts)';
yy = sort(yy,'descend');

Lambda = zeros(npts,1);

for i = 1:npts
 y2 = yy(i);
 % x_2 is positive
 x2 = sqrt(1 - y2^2);
 
 d = -2 * (1 - y2) * x2;
 
 f1 = (-6 * x2 - 2 * x2 * y2) / d;
 ff1(i) = f1;
 
 % angle for region III
 theta = acos(x2);
 if y2 <= 0
  theta = pi / 4 - theta / 2;
  theta = 2 * pi - theta;
 else
  theta = pi / 4 + theta / 2;
 end
 xb = cos(theta);
 yb = sin(theta);
 
 f3 = (2 * (y2 - 1) * xb  + 2 * x2 * yb + 2 * x2 * y2) / d;
 ff3(i) = f3;
 
 Lambda(i) = max(f1,f3);
 
end % for i

plot(yy,ff1,'r')
hold on
plot(yy,ff3,'g')
plot(yy,Lambda)
hold off

[minL,I] = min(Lambda);
fprintf('\n min value of Lebesgue constant = %g for y = %g, x = %g \n',minL,yy(I),sqrt(1-yy(I)^2))

