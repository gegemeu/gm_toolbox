function pts=gm_ellipse_wam(n,a,b);
%GM_ELLIPSE_WAM Computation of WAM points for an ellipse of center 0,0 and semi-axes a,b

%
% Authors:  
%          Len Bos           <leonardpeter.bos@univr.it>
%          Stefano De Marchi <demarchi@math.unipd.it>
%          Alvise Sommariva  <alvise@math.unipd.it>
%          Marco Vianello    <marcov@math.unipd.it>    
%
%  October 18, 2010
%
% Edited by G. Meurant
% August 2015
%


if mod(n,2) == 0
    % SOME ZEROS COULD BE REPEATED IN THE ORIGINAL FORMULATION THAT
    % HAS BEEN CONSEQUENTLY MODIFIED
    % The number of points is n(n+1) + 1
    j = 0:n;
    j = setdiff(j,n/2); % WE ADD [0 0] LATER
    k = 0:n;
    [rho,theta] = meshgrid(cos(j*pi/n),k*pi/(n+1));
    meshA = [rho(:).*cos(theta(:)) rho(:).*sin(theta(:))];
    % ADDING [0 0]        
    nodes_x = [meshA(:,1); 0];
    nodes_y = [meshA(:,2); 0];
else
    % ALL POINTS ARE DISTINCT
    % The number of points is (n + 1)^2
    j = 0:n; 
    k = 0:n;
    [rho,theta] = meshgrid(cos(j*pi/n),k*pi/(n+1));
    meshA = [rho(:).*cos(theta(:)) rho(:).*sin(theta(:))];   
    nodes_x = meshA(:,1);
    nodes_y = meshA(:,2);
end % if mod

pts = [a*nodes_x b*nodes_y];


