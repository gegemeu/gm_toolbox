function f=gm_func_interp(x,y,ifcn);
%GM_FUNC_INTERP function for 2D interpolation tests

%
% Author G. Meurant
% July 2014
% Updated August 2015
%

switch ifcn
 
 case 1
  f = cos(x + y);
  
 case 2
  f = cos(5 * x + 5 * y);
  
 case 3
  f = (x - 0.5).^2 + (y - 0.5).^(3/2);
  
 case 4
  f = abs(x - 0.5) + abs(y - 0.5);
  
 case 5
  % franke's function
  term1 = 0.75 * exp(-(9 * x - 2).^2 / 4 - (9 * y - 2).^2 / 4);
  term2 = 0.75 * exp(-(9 *x + 1).^2 / 49 - (9 * y + 1) / 10);
  term3 = 0.5 * exp(-(9 * x - 7).^2 / 4 - (9 * y - 3).^2 / 4);
  term4 = -0.2 * exp(-(9 * x - 4).^2 - (9 * y - 7).^2);
  
  f = term1 + term2 + term3 + term4;
  
 otherwise
  error('gm_func_interp: This function does not exist')
  
end % switch



