function pts=gm_disk_wam(n);
%GM_DISK_WAM Computation of WAM points for the unit disk

%
% Authors:
%          Len Bos           <leonardpeter.bos@univr.it>
%          Stefano De Marchi <demarchi@math.unipd.it>
%          Alvise Sommariva  <alvise@math.unipd.it>
%          Marco Vianello    <marcov@math.unipd.it>
%
%  October 18, 2010
%
% Edited by G. Meurant
% August 2015
%


if mod(n,2) == 0
 % SOME ZEROS COULD BE REPEATED IN THE ORIGINAL FORMULATION THAT
 % HAS BEEN CONSEQUENTLY MODIFIED
 % The number of points is n(n+1) + 1
 j = 0:n;
 j = setdiff(j,n/2); % WE ADD [0 0] LATER
 k = 0:n;
 [rho,theta] = meshgrid(cos(j*pi/n),k*pi/(n+1));
 meshA = [rho(:).*cos(theta(:)) rho(:).*sin(theta(:))];
 % ADDING [0 0]
 nodes_x = [meshA(:,1); 0];
 nodes_y = [meshA(:,2); 0];
else
 % ALL POINTS ARE DISTINCT
 % The number of points is (n + 1)^2
 j = 0:n;
 k = 0:n;
 [rho,theta] = meshgrid(cos(j*pi/n),k*pi/(n+1));
 meshA = [rho(:).*cos(theta(:)) rho(:).*sin(theta(:))];
 nodes_x = meshA(:,1);
 nodes_y = meshA(:,2);
end % if mod

pts = [nodes_x nodes_y];


