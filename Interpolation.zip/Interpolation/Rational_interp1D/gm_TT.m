function b=gm_TT(x,f);
%GM_TT computation of the coefficients of Thacher-Tukey rational interpolation

% The values of the interpolant at some given points can be computed with
% gm_comp_TT

% Input:
% x = vector of interpolation points
% f = vector of values at interpolation points
%
% Output:
% b = coefficients of the continued fraction to be used in gm_comp_TT

% b corresponds to the points x(1:end-1) 

%
% Author G. Meurant
% Mar 2012
% Updated August 2015
%

n = length(f) - 1;
f = f(:);
x = x(:);
if length(f) ~= length(x);
 error('gm_TT: f and x must be of the same length')
end % if
b = zeros(1,n);

% initialization
t = zeros(n+1,n);
t(:,1) = f - f(1);
b(1) = (x(2) - x(1)) / (f(2) - f(1));
t(2:n+1,2) = b(1) * t(2:n+1,1) - (x(2:n+1) - x(1));

for j = 3:n+1
 b(j-1) = (x(j-1) - x(j)) * t(j,j-2) / t(j,j-1);
 % values of t at all remaining points
 t(j:n+1,j) = b(j-1) * t(j:n+1,j-1) + (x(j:n+1) - x(j-1)) .* t(j:n+1,j-2);
end % for j



