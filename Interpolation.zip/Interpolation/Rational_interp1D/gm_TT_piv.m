function [xt,b,ft]=gm_TT_piv(x,f);
%GM_TT_PIV computation of the coefficients of Thacher-Tukey rational interpolation with pivoting

% The values of the interpolant at some given points can be computed with
% gm_comp_TT

% Input:
% x = vector of interpolation points
% f = vector of values at interpolation points
%
% Output:
% xt = reordered interpolation points
% b = coefficients of the continued fraction to be used in gm_comp_TT
% ft = values at reordered points

% b corresponds to the points xt(1:end-1) 

%
% Author G. Meurant
% March 2012
% Updated August 2015
%

n1 = length(f);
n = n1 - 1;
f = f(:);
x = x(:);
xt = x;
ft = f;
ind = [1:n1]';
b = zeros(1,n);

% initialization
t = zeros(n1,n);
t(:,1) = f - f(1);

% choose xt(2)
y = t(2:n1,1).^2 + (xt(2:n1) - xt(1)).^2;
[ym,I] = max(y);
indold = ind(2:n1);
ind(2) = I(1) + 1;
xt(2) = x(ind(2));
ft(2) = f(ind(2));
ind(3:n1) = setdiff(indold,ind(2));
xt(3:n1) = x(ind(3:n1));
ft(3:n1) = f(ind(3:n1));

b(1) = (xt(2) - xt(1)) / (f(ind(2)) - f(1));
ind2 = ind(2:n1);
t(ind2,2) = b(1) * t(ind2,1) - (xt(2:n1) - xt(1));

for j = 3:n1
 % choose xt(j)
 indj = ind(j:n1);
 y = t(indj,j-1).^2 + ((xt(j:n1) - xt(j-1)) .* t(indj,j-2)).^2;
 [ym,I] = max(y);
 indold = ind(j:n1);
 ind(j) = indold(I(1));
 xt(j) = x(ind(j));
 ft(j) = f(ind(j));
 ind(j+1:n1) = setdiff(indold,ind(j));
 xt(j+1:n1) = x(ind(j+1:n1));
 ft(j+1:n1) = f(ind(j+1:n1));
 b(j-1) = (xt(j-1) - xt(j)) * t(ind(j),j-2) / t(ind(j),j-1);
 % values of t at all remaining points
 indj = ind(j:n1);
 t(indj,j) = b(j-1) * t(indj,j-1) + (xt(j:n1) - xt(j-1)) .* t(indj,j-2);
end % for j

xt = xt(1:n)';



