function y=gm_TT_numer(t,x,f,b);
%GM_TT_NUMER numerator of the Thacher-Tukey rational interpolant

% this can be used to see if the numerator cancels the poles of the
% denominator
%

% Input:
% t = test points
% x = interpolation points
% f values at interpolation points
% b = coefficients of the continued fraction (from gm_TT or gm_TT_piv)
%
% Output:
% y = values of the numerator at test points, a column corresponds to all
% test points

%
% Author G. Meurant
% Mar 2012
% Updated August 2015
%

n = length(b);
nt = length(t);
t = t(:);

y = zeros(nt,n);
y(:,1) = b(1) * f(1) + t - x(1);
y(:,2) = b(2) * y(:,1) + (t - x(2)) * f(1);

for k = 3:n
 y(:,k) = b(k) * y(:,k-1) + (t - x(k)) .* y(:,k-2);
end % for k