
% RATIONAL_INTERPOLATION 1D (THACHER-TUKEY)
%
% Files
%   gm_comp_TT  - computation of the values of the Thacher-Tukey rational interpolant
%   gm_TT       - computation of the coefficients of Thacher-Tukey rational interpolation
%   gm_TT_denom - denominator of the Thacher-Tukey rational interpolant
%   gm_TT_numer - numerator of the Thacher-Tukey rational interpolant
%   gm_TT_piv   - computation of the coefficients of Thacher-Tukey rational interpolation with pivoting
