function r=gm_comp_TT(t,x,f,b);
%GM_COMP_TT computation of the values of the Thacher-Tukey rational interpolant
% using the continued fraction

% Input:
% t = test points
% x = interpolation points
% f = values at interpolation points
% b = coefficients (computed by gm_TT or gm_TT_piv)
%
% Output:
% r = values of the interpolant at test points

%
% Author G. Meurant
% March 2012
% Updated August 2015
%

n = length(b);

r = (t - x(n)) / b(n);

% computation of the continued fraction
for k = n-1:-1:1
 r = (t - x(k)) ./ (b(k) + r);
end % for k

r = r + f(1);




