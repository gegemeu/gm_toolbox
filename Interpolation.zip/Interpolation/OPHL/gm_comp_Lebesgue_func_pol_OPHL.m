function [Psinp,maxL,Psidot,XY]=gm_comp_Lebesgue_func_pol_OPHL(x,y,w,npts,ipb);
%GM_COMP_LEBESGUE_FUNC_POL_OPHL computation of the Lebesgue function
% for bivariate orthogonal polynomials using Huhtanen-Larsen

% This works only for some examples (because of the definition of the
% enclosing rectangle)

% Uses the representation of the polynomials with the monomials
% Much less reliable than gm_comp_Lebesgue_func_OPHL
% Works only for a very small number of points (< 10)

% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% npts = number of vizualization points in one direction
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Psinp = values of the Lebesgue function at test points
% maxL = approximate Lebesgue constant
% Psidot = values of the Lebesgue function as a vector
% XY = test points

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

% This is to communicate with gm_indic_func
global iprob

% set the global variable
iprob = ipb;

Psinp = 0; 
maxL = 0;
% test points, linear = 1, Cheb max = 2
testp = 2;

% set up the mesh on a rectangle including the domain

switch ipb
 
 case 1
  % square
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 2
  % disk
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 3
  % L-shape region
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  % simplex
  xmin = 0;, ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  % double bubble
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  % ellipse
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_comp_Lebesgue_func_pol_OPHL: Wrong value of ipb')
end

% mesh in x and y
switch testp
 
 case 1
  % linear
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  % Chebyshev
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_comp_Lebesgue_func_pol_OPHL: testp must be 1 or 2')
end

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

n = length(x);

[Exp,pol] = gm_coeff_pol_OPHL(x,y,w,n);

[Q,A,xy] = gm_OPHL(2,x,y,w);

Psinp = zeros(size(XY,1),1);

for j = 1:n
 % j-th Lagrange basis
 lag = gm_eval_Lagrange_basis_pol_OPHL(j,Q,Exp,pol,w,XY(:,1),XY(:,2));
 Psinp = Psinp + abs(lag);
end % for j

np = length(Psinp);
for i = 1:np
 if gm_indic_func([XY(i,1); XY(i,2)]) == 0
  % value outside the domain
  Psinp(i) = 1;
 end % if
end % for i

maxL = max(Psinp);

Psidot = Psinp;

% reshape the vector to conform to the mesh
Psinp = reshape(Psinp,npts,npts)';


