
% OPHL, BIVARIATE ORTHOGONAL POLYNOMIALS
%
% Files
%   gm_coeff_pol_OPHL               - coefficients of the bivariate orthogonal polynomials using Huhtanen-Larsen
%   gm_comp_interp_OPHL             - computation of the interpolating polynomial using the bivariate orthogonal polynomials (OP)
%   gm_comp_interpolant_OPHL        - computation of the interpolating polynomial using OPs on a given test mesh
%   gm_comp_Lebesgue_func_OPHL      - computation of the Lebesgue function using OPs
%   gm_comp_Lebesgue_func_pol_OPHL  - computation of the Lebesgue function using monomials
%   gm_compXY_Lagrange_func_OPHL    - computation of the Lagrange polynomial on a given mesh
%   gm_compXY_Lebesgue_func_OPHL    - computation of the Lebesgue function on a given mesh using OPs
%   gm_compXY_Lebesgue_func_p_OPHL  - computation of the Lebesgue p-function on a given mesh
%   gm_eval_all_pol                 - evaluates all the bivariate polynomials given by Exp and pol at points (x,y)
%   gm_eval_Lagrange_basis_pol_OPHL - evaluates the j-th Lagrange basis function at points (X,Y) using monomials
%   gm_eval_xy_OPHL                 - evaluates the matrix xy at point (x,y);
%   gm_L_OPHL                       - lower triangular matrix of recurrence coefficients for Huhtanen-Larsen
%   gm_OPHL                         - Bivariate orthogonal polynomials using Huhtanen-Larsen method 
%   gm_OPHL_eval                    - computes the values of the bivariate polynomials at given points
