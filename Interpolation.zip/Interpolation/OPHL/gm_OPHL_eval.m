function Q=gm_OPHL_eval(deg,Hx,Hy,w,A,val0)
%GM_OPHL_EVAL computes the values of the bivariate polynomials at given points

% Input:
% deg = degree of the bivariate orthogonal polynomials
% Hx = x-components of the points (xi, yi)
% Hy = y-components of the points (xi, yi)
% w = weights, sum(w) = 1
% A = matrix from gm_OPHL
% val0 = value of the constant polynomial
%
% Output:
% Q = contains the weighted evaluation

% 
% Authors A. Sommariva and G. Meurant
% 2015


n = size(Hx,1);

q0 = val0 * ones(n,1);

% number of points
M = (deg + 2) * (deg + 1) / 2; 
Q = zeros(n,M);

% exchange Hx and Hy to be consistent with the other functions
temp = Hx;
Hx = Hy;
Hy = temp;

% nop = 0;

% initialize Q
Q(:,1) = q0;

% first cycle k = 1
p = Hy .* Q(:,1);
% Q,w,S
S = A(1:2,3:4);
p = p - Q(:,1) * S(1:end-1,1);
p = p - Q(:,1) * S(1:end-1,2);
p = p / S(end,2);
Q(:,2) = p;

% nop = nop + 4 * n;

p = Hx .* Q(:,1);
S = A(1:3,5:6);
p = p - Q(:,1:2) * S(1:end-1,1);
p = p - Q(:,1:2) * S(1:end-1,2);
p = p / S(end,2);
Q(:,3) = p;

% nop = nop + 8 * n;

% second cycle k = 2
p = Hy .* Q(:,2);
S = A(1:4,7:8);
p = p - Q(:,1:3) * S(1:end-1,1);
p = p - Q(:,1:3) * S(1:end-1,2);
p = p / S(end,2);
Q(:,4) = p;

% nop = nop + 12 * n;

j = 4;
for l = 2:3
 p= Hx .* Q(:,l);
 ii = 5 + 2 * l;
 S = A(1:3+l,ii:ii+1);
 p = p - Q(:,1:j) * S(1:end-1,1);
 p = p - Q(:,1:j) * S(1:end-1,2);
 p = p / S(end,2);
 Q(:,j+1) = p;
%  nop = nop + 4 * j * n;
 j = j + 1;
end % for l

for k = 3:deg
 k1 = (k - 1) * k / 2 + 1;
 k2 = k * (k + 1) / 2 + 1;
 p = Hy .* Q(:,k1);
 ii = 2 * k2 - 1;
 S = A(1:k2,ii:ii+1);
 p = p - Q(:,1:j) * S(1:end-1,1);
 p = p - Q(:,1:j) * S(1:end-1,2);
 p = p / S(end,2);
%  nop = nop + 4 * j * n;
 Q(:,j+1) = p;
 j = j + 1;
 
 for l = k1:k2-1
  p = Hx .* Q(:,l);
  ii = 2 * (l + k) + 1;
  S = A(1:l+k+1,ii:ii+1);
  p = p - Q(:,1:j) * S(1:end-1,1);
  p = p - Q(:,1:j) * S(1:end-1,2);
  p = p / S(end,2);
  Q(:,j+1) = p;
%   nop = nop + 4 * j * n;
  j = j + 1;
 end % for l
 
end % for k







