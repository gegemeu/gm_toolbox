function [maxL,Psidot]=gm_compXY_Lebesgue_func_p_OPHL(x,y,w,XY,ipb,p);
%GM_COMPXY_LEBESGUE_FUNC_P_OPHL computation of the Lebesgue p-function on a given mesh
% for bivariate orthogonal polynomials using Huhtanen-Larsen method

%
% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% XY = evaluation points, x = XY(:,1), y = XY(:,2)
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% p = integer in the p-function
%
% Output:
% maxL = approximate Lebesgue constant
% Psidot = values of the Lebesgue function as a vector

%
% Author G. Meurant
% Feb 2017
%

% Communication with gm_indic_func
global iprob

iprob = ipb;

x = x(:); 
y = y(:);

maxL = 0;

% total degree
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values at the inner product points
[Phi,A,xy] = gm_OPHL(d,x,y,w);

% coefficients of the expansion
alp = Phi' * diag(w);

% compute the values of the polynomials
Psi = gm_OPHL_eval(d,XY(:,1),XY(:,2),w,A,1);

np = size(Psi,1);

Psidot = zeros(np,1);

for j = 1:n
 sk = zeros(np,1);
 
 % values of the j-th Lagrange polynomial
 for k = 1:n
  sk = sk + alp(k,j) * Psi(:,k);
 end % for k
 
 Psidot = Psidot + abs(sk).^p;
 
end % for j

Psidot = Psidot.^(1/p);

for i = 1:np
 if gm_indic_func([XY(i,1); XY(i,2)]) == 0
  Psidot(i) = 1;
 end % if
end % for i

maxL = max(Psidot);




