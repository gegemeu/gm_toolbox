function [Psinp,diff,errmax,errl2]=gm_comp_interpolant_OPHL(fcn,x,y,w,ipb,XY);
%GM_COMP_INTERPOLANT_OPHL computation of the interpolating polynomial
% using the bivariate orthogonal polynomials on a given test mesh

% computed using Huhtanen-Larsen algorithm

% Input:
% fcn = function to be interpolated
% (x,y) =  points defining the discrete inner product
% w = weights
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% XY = test mesh, x = XY(:,1), y = XY(:,2)
%
% Output:
% Psinp = values of the interpolant at test points
% diff = differences with the function values
% errmax = max of the absolute interpolation error
% errl2 = l2-norm of the interpolation error

%
% Author G. Meurant
% May 2014
% Updated August 2014
%

global iprob

iprob = ipb;


% values of the function

f = feval(fcn,x,y);

Psinp = 0;
maxbnd = 0;
errmax = 0;
errl2 = 0;

% values of the function at the test points

tf = feval(fcn,XY(:,1),XY(:,2));

% total degree
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values of the polynomials at the inner product points 

[Phi,A,xy] = gm_OPHL(d,x,y,w);

% coefficients of the expansion
alp = Phi' * diag(w);

% compute the values of the polynomials at test points

Psi = gm_OPHL_eval(d,XY(:,1),XY(:,2),w,A,1);

% note that the interpolate can be computed directly from the OPs!

np = size(Psi,1);

Psinp = zeros(np,1);
for j = 1:n
 sk = zeros(np,1);
 
 % values of the j-th Lagrange polynomial
 for k = 1:n
  sk = sk + alp(k,j) * Psi(:,k);
 end % for k
 
 Psinp = Psinp + f(j) * sk;
 
end % for j

diff = abs(Psinp - tf);

% value = 0 outside of the domain
for k = 1:size(XY,1)
 if gm_indic_func([XY(k,1); XY(k,2)]) == 0
  diff(k) = 0;
  Psinp(k) = 0;
  tf(k) = 0;
 end % if
end % for k

errmax = max(diff);
errl2 = norm(diff) / sqrt(size(Psinp,1));



