function [Psinp,maxL,diff,XY,errmax,errl2]=gm_comp_interp_OPHL(fcn,x,y,w,npts,ipb,ifcn);
%GM_COMP_INTERP_OPHL computation of the interpolating polynomial using the bivariate orthogonal polynomials

% computed using Huhtanen-Larsen algorithm

% Input:
% fcn = function to be interpolated
% (x,y) =  points defining the discrete inner product
% w = weights
% npts = number of computational points in one direction
% ipb = problem number (1,...,7)
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
% ifcn = function number (1,...,5)
%
% Output:
% Psinp = values of the interpolant at test points
% maxL = Lebesgue constant
% diff = differences with the function values
% XY = test points
% errmax = max of the absolute interpolation error
% errl2 = l2-norm of the interpolation error

%
% Author G. Meurant
% May 2014
% Updated August 2014
%

global iprob

iprob = ipb;

% values of the function

f = feval(fcn,x,y,ifcn);
% for a general function this could be replaced by f = feval(fcn,x,y);

Psinp = 0;
maxL = 0;
maxbnd = 0;
errmax = 0;
errl2 = 0;

% test points, linear = 1, Cheb max = 2
testp = 2;

% set up the mesh

switch iprob
 
 case 1
  % square
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 2
  % disk
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 3
  % L-shape region
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  % simplex
  xmin = 0;, ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  % double bubble
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  % ellipse
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_comp_interp_OPHL: Wrong value of ipb')
end % switch

if nargin == 4
 xmin = min(x);
 xmax = max(x);
 ymin = min(y);
 ymax = max(y);
end % if

% enlarge a bit the rectangle
fmin = 0.99;
fmax = 1.01;

rect = 1;
if rect == 1
 fmin = 1;
 fmax = 1;
end % if rect

if xmin > 0
 xmin = fmin * xmin;
else
 xmin = fmax * xmin;
end
if xmax > 0
 xmax = fmax * xmax;
else
 xmax = fmin * xmax;
end
if ymin > 0
 ymin = fmin * ymin;
else
 ymin = fmax * ymin;
end
if ymax > 0
 ymax = fmax * ymax;
else
 ymax = fmin * ymax;
end

% mesh in x and y
switch testp
 
 case 1
  % linear
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  % Chebyshev
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_comp_interp_OPHL: testp must be 1 or 2')
end % switch

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

% values of the function at the test points

tf = feval(fcn,XY(:,1),XY(:,2),ifcn);

nX = size(XY,1);
for k = 1:nX
 if gm_indic_func([XY(k,1); XY(k,2)]) == 0
  tf(k) = 0;
 end % if 
end % for k

% total degree
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values at the inner product points 

[Phi,A,xy] = gm_OPHL(d,x,y,w);

% coefficients of the expansion
alp = Phi' * diag(w);

% compute the values of the polynomials
Psi = gm_OPHL_eval(d,XY(:,1),XY(:,2),w,A,1);

% note that the interpolate can be computed directly from the OPs!

np = size(Psi,1);

Psinp = zeros(np,1);
for j = 1:n
 sk = zeros(np,1);
 
 % values of the j-th Lagrange polynomial
 for k = 1:n
  sk = sk + alp(k,j) * Psi(:,k);
 end % for k
 
 Psinp = Psinp + f(j) * sk;
 
end % for j

% value = 0 outside of the domain
for k = 1:nX
 if gm_indic_func([XY(k,1); XY(k,2)]) == 0
  Psinp(k) = 0;
 end % if
end % for k

diff = abs(Psinp - tf);

errmax = max(diff);
errl2 = norm(diff) / sqrt(size(Psinp,1));



