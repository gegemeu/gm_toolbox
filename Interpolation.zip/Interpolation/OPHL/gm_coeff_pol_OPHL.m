function [Exponent,pol]=gm_coeff_pol_OPHL(x,y,w,kmax);
%GM_COEFF_POL_OPHL coefficients of the bivariate orthogonal polynomials
% for the discrete inner product defined by x,y,w using Huhtanen-Larsen

% Input:
% x, y = points defining the discrete inner product
% w = weights, sum(w) = 1
% kmax = number of polynomials to be computed
%
% Output:
% Exponent = monomials x^i y^j as [i,j]
% pol =  corresponding coefficients of the monomials

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

n = length(x);
% degree
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% number of polynomials of degree d
N = gm_numb_bivar_pol(d);
kmax = min(kmax,N);

[Phi,A,xy] = gm_OPHL(d,x,y,w);

% lower triangular matrix of the recurrence coefficients
L = gm_L_OPHL(A);

% monomials (ordering grlex)
Expo = [repmat([0:d],1,d+1); kron([0:d],ones(1,d+1))];

% remove those with sum > degree
I = find(sum(Expo) <= d);
Exp = Expo(:,I)';
Exp = sortrows([sum(Exp,2) Exp]);
Exponent = [Exp(:,3) Exp(:,2)];
nExp = size(Exponent,1);

% compute the multiplication by x and y
xExp = [Exponent(:,1)+1 Exponent(:,2)];
yExp = [Exponent(:,1) Exponent(:,2)+1];

% find the positions of the monomials of xExp in Exponent
xmult = zeros(nExp,1);
ymult = zeros(nExp,1);

% if the monomial is not in Exponent, xmult = 0
for k = 1:nExp
 for j = 1:nExp
  I = (xExp(k,:) == Exponent(j,:));
  if sum(I) == 2
   xmult(k) = j;
  end % if
  I = (yExp(k,:) == Exponent(j,:));
  if sum(I) == 2
   ymult(k) = j;
  end % if
 end % for j
end % for k
Ix = find(xmult>0);
Iy = find(ymult>0);

pol = zeros(nExp,kmax);
% first constant polynomial (value = 1)
pol(:,1) = eye(nExp,1);
% find the multiplications we have to deal with
[I,J] = find(xy);

for k = 2:kmax
 rhs = zeros(nExp,1);
 % indices in xy
 i = I(k-1); 
 j = J(k-1);
 if xy(i,j) == 1
  % multiplication by x of the jth polynomial
  val = pol(:,j);
  rhs(xmult(Ix)) = val(Ix);
 else
  % multiplication by y of the jth polynomial
  val = pol(:,j);
  rhs(ymult(Iy)) = val(Iy);
 end % if xy
 
 % get the other terms of the right-hand side
 for j = 1:k-1
  rhs = rhs - L(k,j) * pol(:,j);
 end % for j
 
 % divide by the diagonal entry
 pol(:,k) = rhs / L(k,k);
 
end % for k

