function polval=gm_eval_all_pol(Exp,pol,X,Y);
%GM_EVAL_ALL_POL evaluates all the bivariate polynomials given by Exp and pol at points (x,y)

% Input:
% Exp = the monomials (computed by gm_coeff_pol_OPHL)
% pol = coefficients
% X, Y = test points
%
% Output:
% polval = values at test points


% this is not the most efficient way to evaluate the polynomial


%
% Author G. Meurant
% May 2014
% Updated July 2015
%

nE = size(Exp,1);

X = X(:)'; Y = Y(:)';
nx = length(X);
value = zeros(nE,nx);
n = size(pol,2);
polval = zeros(nx,n);

for j = 1:n
 coeff = pol(:,j);
 for k = 1:nE
  value(k,:) = coeff(k) .* X.^Exp(k,1) .* Y.^Exp(k,2);
 end % for k
 
 polval(:,j) = sum(value)';
end % for j




