function L=gm_L_OPHL(A);
%GM_L_OPHL lower triangular matrix of coefficients for Huhtanen-Larsen
% gives the recurrence coefficients (without the x,y part)

% Input:
% A = matrix from gm_OPHL
%
% Output:
% L = lower triangular matrix of the coefficients

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

n = size(A,2) / 2;
L = zeros(n,n);
L(1,1) = 1;

j = 0;
for k = 3:2:size(A,2)
 j = j + 1;
 L(j+1,1:j) = A(1:j,k)';
 L(j+1,j+1) = A(j+1,k+1);
end % for k



