function lag=gm_eval_Lagrange_basis_pol_OPHL(j,Q,Exp,pol,w,X,Y);
%GM_EVAL_LAGRANGE_BASIS_POL_OPHL evaluates the j-th Lagrange basis function
% at points (X,Y) from the orthogonal polynomial using monomials

% Input:
% j = number of the basis function
% Q = values at points of the discrete inner product
% Exp, pol = exponents and coefficients computed by gm_coeff_pol_OPHL
% w = weights, sum(w) = 1
% X, Y = test points
%
% Output:
% lag = values at test points

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

n = size(Q,1);

% values of all the polynomials at X,Y
polval = gm_eval_all_pol(Exp,pol,X,Y);

% values of the polynomials at xi_j
Phikj = Q(j,:);

lag = w(j) * sum(polval * diag(Phikj),2);


 