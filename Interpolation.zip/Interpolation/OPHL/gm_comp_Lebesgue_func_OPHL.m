function [Psinp,maxL,Psidot,XY]=gm_comp_Lebesgue_func_OPHL(x,y,w,npts,ipb);
%GM_COMP_LEBESGUE_FUNC_OPHL computation of the Lebesgue function
% for bivariate orthogonal polynomials using Huhtanen-Larsen method

% This works only for some examples (because of the definition of the
% enclosing rectangle)

% Input:
% (x,y) = the points defining the discrete inner product
% w = weights, sum(w) = 1
% npts = number of vizualization points in one direction
% ipb = problem number
%        ipb = 1 square
%        ipb = 2 disk
%        ipb = 3 L-shape region
%        ipb = 4 triangle (simplex)
%        ipb = 5 double bubble
%        ipb = 6 ellipse
%        ipb = 7 half-ellipse
%
% Output:
% Psinp = values of the Lebesgue function at test points
% maxL = approximate Lebesgue constant
% Psidot = values of the Lebesgue function as a vector
% XY = test points

%
% Author G. Meurant
% May 2014
% Updated July 2015
%

% Communication with gm_indic_func
global iprob
global WAM

iprob = ipb;

x = x(:); 
y = y(:);

Psinp = 0;
maxL = 0;
% test points, linear = 1, Cheb max = 2
testp = 2;

% set up the mesh

switch ipb
 
 case 1
  % square
  xmin = -1; ymin = -1;
  xmax = 1; ymax = 1;
  
 case 2
  % disk
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 3
  % L-shape region
  xmin = -1;, ymin = -1;
  xmax = 1; ymax = 1;
  
 case 4
  % simplex
  xmin = 0;, ymin = 0;
  xmax = 1; ymax = 1;
  
 case 5
  % double bubble
  xmin = -5; ymin = -5;
  xmax = 9; ymax = 5;
  
 case 6
  % ellipse
  xmin = -2; ymin = -1;
  xmax = 2; ymax = 1;
  
 case 7
  % half-ellipse
  xmin = -2; ymin = 0;
  xmax = 2; ymax = 1;
  
 otherwise
  error('gm_comp_Lebesgue_func_OPHL: Wrong value of ipb')
end % switch

if nargin == 4
 xmin = min(x); xmax = max(x);
 ymin = min(y); ymax = max(y);
end

% mesh in x and y
switch testp
 
 case 1
  % linear
  xx = linspace(xmin,xmax,npts);
  yy = linspace(ymin,ymax,npts);
  
 case 2
  % Chebyshev
  xx = gm_cheb_max(xmin,xmax,npts);
  yy = gm_cheb_max(ymin,ymax,npts);
  
 otherwise
  error('gm_comp_Lebesgue_func_OPHL: testp must be 1 or 2')
end % switch

XY = [repmat(xx',npts,1) kron(yy,ones(1,npts))'];

if ipb == 2 && npts >= 100
 %  XY = gm_disk_wam(100);
 if ~isempty(WAM)
  XY = WAM;
 else
  XY = gm_disk_wam(100);
 end % if isempty
end % if ipb
 
% total degree
n = length(x);
d = ceil((-3 + sqrt(1 + 8 * n)) / 2);

% values at the inner product points
[Phi,A,xy] = gm_OPHL(d,x,y,w);

% coefficients of the expansion
alp = Phi' * diag(w);

% compute the values of the polynomials
Psi = gm_OPHL_eval(d,XY(:,1),XY(:,2),w,A,1);

np = size(Psi,1);

Psinp = zeros(np,1);

for j = 1:n
 sk = zeros(np,1);
 
 % values of the j-th Lagrange polynomial
 for k = 1:n
  sk = sk + alp(k,j) * Psi(:,k);
 end % for k
 
 Psinp = Psinp + abs(sk);
 
end % for j

for i = 1:np
 if gm_indic_func([XY(i,1); XY(i,2)]) == 0
  Psinp(i) = 1;
 end % if
end % for i

Psidot = Psinp;

maxL = max(Psinp);

if ipb ~= 2
 % reshape the vector to conform to the mesh
 Psinp = reshape(Psinp,npts,npts)';
end


