function [Q,A,xy]=gm_OPHL(deg,Hx,Hy,w);
%GM_OPHL Bivariate orthogonal polynomials using Huhtanen-Larsen method 

% The points and the weights define the discrete inner product

% Input:
% deg = degree of the polynomials
% Hx = vector corresponding to x
% Hy = vector corresponding to y
% w  = (positive) weights, sum(w) = 1
%
% Output:
% Q = nearly orthonormal matrices for the given inner product
%     contains the weighted evaluation of the orthogonal polynomials produced at the nodes
% A = matrix of the recurrence coefficients
% xy = ?

%
% Author A. Sommariva
% July 2014
% Optimized by G. Meurant
% July 2015
%

if abs(sum(w) - 1) > 1e-14
 w = w / sum(w);
end

Hx = Hx(:);
Hy = Hy(:);
w = w(:);
n = size(Hx,1);
q0 = ones(n,1);
Q = zeros(n,n);
xy = zeros(n,n);

% exchange Hx and Hy to be consistent with other functions
temp = Hx;
Hx = Hy;
Hy = temp;

% number of points corresponding to the degree
M = (deg + 2) * (deg + 1) / 2; 
A = zeros(M,2*M);

% initialize Q
Q(:,1) = q0;

% first cycle k = 1
p = Hy .* Q(:,1);
j = 1;
S = zeros(j+1,2);
wmod = w .* p;
S(1:end-1,1) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,1);
wmod = w .* p;
S(1:end-1,2) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,2);
wmod = w .* p;
S(j+1,2) = sqrt(p' * wmod);
p = p / S(j+1,2);
A(1:2,3:4) = S;
xy(2,1) = 1;
Q(:,2) = p;
p = Hx .* Q(:,1);

j = 2;
S = zeros(j+1,2);
wmod = w .* p;
S(1:end-1,1) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,1);
wmod = w .* p;
S(1:end-1,2) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,2);
wmod = w .* p;
S(j+1,2) = sqrt(p' * wmod);
p = p / S(j+1,2);
A(1:3,5:6) = S;
Q(:,3) = p;
xy(3,1) = 2;

%second cycle k = 2
p = Hy .* Q(:,2);
j = 3;
S = zeros(j+1,2);
wmod = w .* p;
S(1:end-1,1) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,1);
wmod = w .* p;
S(1:end-1,2) = Q(:,1:j)' * wmod;
p = p - Q(:,1:j) * S(1:end-1,2);
wmod = w .* p;
S(j+1,2) = sqrt(p' * wmod);
p = p / S(j+1,2);
A(1:4,7:8) = S;
xy(4,2) = 1;
Q(:,4) = p;

j = 4;
for l = 2:3
 p = Hx .* Q(:,l);
 S = zeros(j+1,2);
 wmod = w .* p;
 S(1:end-1,1) = Q(:,1:j)' * wmod;
 p = p - Q(:,1:j) * S(1:end-1,1);
 wmod = w .* p;
 S(1:end-1,2) = Q(:,1:j)' * wmod;
 p = p - Q(:,1:j) * S(1:end-1,2);
 wmod = w .* p;
 S(j+1,2) = sqrt(p' * wmod);
 p = p / S(j+1,2);
 ii = 5 + 2 * l;
 A(1:3+l,ii:ii+1) = S;
 xy(3+l,l) = 2;
 Q(:,j+1) = p;
 j = j + 1;
end % for l

for k = 3:deg
 k1 = (k - 1) * k / 2 + 1;
 k2 = k * (k + 1) / 2 + 1;
 p = Hy .* Q(:,k1);
 S = zeros(j+1,2);
 wmod = w .* p;
 S(1:end-1,1) = Q(:,1:j)' * wmod;
 p = p - Q(:,1:j) * S(1:end-1,1);
 wmod = w .* p;
 S(1:end-1,2) = Q(:,1:j)' * wmod;
 p = p - Q(:,1:j) * S(1:end-1,2);
 wmod = w .* p;
 S(j+1,2) = sqrt(p' * wmod);
 p = p / S(j+1,2);
 ii = 2 * k2 - 1;
 A(1:k2,ii:ii+1) = S;
 xy(k2,k1) = 1;
 Q(:,j+1) = p;
 j = j + 1;
 
 for l = k1:k2-1
  p = Hx .* Q(:,l);
  S = zeros(j+1,2);
  wmod = w .* p;
  S(1:end-1,1) = Q(:,1:j)' * wmod;
  p = p - Q(:,1:j) * S(1:end-1,1);
  wmod = w .* p;
  S(1:end-1,2) = Q(:,1:j)' * wmod;
  p = p - Q(:,1:j) * S(1:end-1,2);
  wmod = w .* p;
  S(j+1,2) = sqrt(p' * wmod);
  p = p / S(j+1,2);
  ii = 2 * (l + k) + 1;
  A(1:l+k+1,ii:ii+1) = S;
  xy(l+k+1,l) = 2;
  Q(:,j+1) = p;
  j = j + 1;
 end % for l
end % for k





