function xym=gm_eval_xy_OPHL(xy,x,y);
%GM_EVAL_XY_OPHL evaluates the matrix xy at point (x,y);

% non zeros entries of xy are 1 (for x) and 2 (for y)
% we replace them with floating point numbers x and y in xym

% Input: 
% xy = matrix with integer entries
% x,y = coordinates of the point
%
% Output:
% xym = matrix where 1 has been replaced with x and 2 by y

% 
% Author G. Meurant
% May 2014
% Updated August 2015
%

XY = xy(:);
I = find(XY == 1);
XY(I) = x;
I = find(XY == 2);
XY(I) = y;

[n,m] = size(xy);
xym = reshape(XY,n,m);

