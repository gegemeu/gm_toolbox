
% POINTSM
%
% Files 

% Files containing sets of points for different degrees obtained with 
% minimization of the Lebesgue constant

%gm_pointsL_disk  -sets of points with low Lebesgue constant for the disk
