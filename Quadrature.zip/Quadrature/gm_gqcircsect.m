function xyw=gm_gqcircsect(n,omega,r1,r2);
%GM_GQCIRCSECT computes the nodes and weights of a product gaussian
% formula on a circular annular sector centered at the origin
% with angles in [-omega,omega]

% uses the routines:
% gm_r_jacobi.m, gm_gauss.m from
% www.cs.purdue.edu/archives/2002/wxg/codes/OPQ.html
%
% gm_trigauss.m 
% http://www.math.unipd.it/~marcov/mysoft/trigauss.m

% Input:
% n = algebraic degree of exactness
% omega = half-length of the angular interval, 0 < omega <= pi
% r1,r2 = internal and external radius, 0<=r1<r2

% Output:
% xyw = (ceil((n+2)/2) x (n+1)) x 3 array of (xnodes,ynodes,weights)

%
% by Gaspare Da Fies and Marco Vianello, University of Padova
% 8 Nov 2011
%

% trigonometric gaussian formula on the arc
tw = gm_trigauss(n,-omega,omega);

% algebraic gaussian formula on the radial segments (r1, r2]
ab = gm_r_jacobi(ceil((n+2)/2),0,0);
xw = gm_gauss(ceil((n+2)/2),ab);
xw(:,1) = xw(:,1) * (r2 - r1) / 2 + (r2 + r1) / 2;
xw(:,2) = xw(:,2) * (r2 - r1) / 2;

% creating the polar grid
[r,theta] = meshgrid(xw(:,1),tw(:,1));
[w1,w2] = meshgrid(xw(:,2),tw(:,2));

% nodal cartesian coordinates and weights
xyw(:,1) = r(:) .* cos(theta(:));
xyw(:,2) = r(:) .* sin(theta(:));
xyw(:,3) = r(:) .* w1(:) .* w2(:);


