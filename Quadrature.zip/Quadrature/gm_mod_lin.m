function [am,bm,mu0m] = gm_mod_lin(a,b,mu0,beta);
%GM_MOD_LIN Jacobi matrix for a multiplication of w by a linear factor r = x - beta

% beta must be outside of the interval of definition

% Input:
% a, b = 3-term recurrence coefficients
% mu0 = moment of order 0
% beta = multiplication by x - beta
%
% Output:
% am, bm = modified coefficients
% mu0m = moment of order 0

%
% Author G. Meurant
% July 2008
% Updated July 2015
%

% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 
n = size(J,1);

% Cholesky factorization of J - beta I
Jb = J - beta * eye(n,n);
% R upper triangular
R = chol(Jb);

J1 = R * R' + beta * eye(n,n);

% The Jacobi matrix for rw is the n-1 leading matrix of J1
J1 = J1(1:n-1,1:n-1);

am = diag(J1);
bm = diag(J1,-1);

mu0m = mu0 * (a(1) - beta);

