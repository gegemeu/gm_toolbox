function J=gm_jacobi(a,b);
%GM_JACOBI Jacobi matrix from the recurrence coefficients

% Input:
% a = vector of the diagonal
% b = vector of the sub-diagonal
%
% Output:
% J = Jacobi matrix

%
% Author G. Meurant
% Updated July 2015
%

a = a(:);
b = b(:);
% upper diagonal
c = [0; b(1:end-1)];

n = length(a);
if length(b) == n-1
 c = [0; b];
 b = [b; 0];
end
 
J = spdiags([b a c],-1:1,n,n);
