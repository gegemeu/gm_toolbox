function int = gm_int_Legendre(fcn,liminf,limsup,n);
%GM_INT_LEGENDRE integral of a function with the Legendre weight

% Input:
% fcn = function to be integrated
% [liminf, limsup] = interval of integration
% n = number of nodes in the Gauss quadrature rule
%
% Ouput:
% int = value of the integral

%
% Author G. Meurant
% July 2015
%

% computation of the nodes and weights on [-1, 1]
% for the Legendre weight (w = 1)
[a,b,mu0] = gm_classicorthopoly('le',n,0,0);
[t,w] = gm_gaussquadrule(a,b,0,mu0,0);

% mapping of the nodes to [liminf, limsup]
tt = ((limsup - liminf) * t + liminf + limsup) / 2;

% function values
ftt = feval(fcn,tt);

int = sum(w .* ftt) * (limsup - liminf) / 2;

