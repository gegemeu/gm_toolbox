function [tcc,wcc] = gm_Clenshaw_Curtis(n);
%GM_CLENSHAW_CURTIS Clenshaw-Curtis quadrature rule, nodes and weights

% interval [-1, 1]

% Input:
% n = number of nodes on [-1, 1]
%
% Output:
% tcc = nodes
% wcc = weights

%
% Author G. Meurant
% from a code of Waldvogel
% July 2015
%

N = [1:2:n-1]'; 
l = length(N); 
m = n-l; 

% Clenshaw-Curtis nodes
k = [n:-1:0]';
tcc = cos(k * pi / n);
 
% vector of weights: wcc, wcc_n = wcc_0
v0 = [2 ./ N ./ (N-2); 1 / N(end); zeros(m,1)];
v2 = -v0(1:end-1) - v0(end:-1:2); 
g0 = -ones(n,1); 
g0(1+l) = g0(1+l) + n; 
g0(1+m) = g0(1+m) + n;
g = g0 / (n^2 - 1 + mod(n,2)); 
wcc = ifft(v2 + g);
wcc = [wcc; wcc(1)];

