function xw=gm_symmRadau(N,ab,end0);
%GM_SYMMRADAU Gauss-Radau quadrature rule

% Needs the OPQ package from W. Gautschi

% Input:
% N = number of nodes
% ab = 3-term recurrence for the monic orthogonal polynomials
%      same as in OPQ
%      ab(1,2) is the 0th moment
% end0 = prescribed node

% Output:
% xw = xw(:,1) nodes, xw(:,2) weights of the quadrature rule

%
% Author A. Sommariva
% Adapted from OPQ from W. Gautschi
% June 2012
% Updated by G. Meurant
% July 2015
%


p0 = 0;
p1 = 1;

for n = 1:N
 pm1 = p0;
 p0 = p1;
 p1 = (end0 - ab(n,1)) * p0 - ab(n,2) * pm1;
end

ab(N+1,1) = end0 - ab(N+1,2) * p0 / p1;
xw = gauss(N+1,ab);

