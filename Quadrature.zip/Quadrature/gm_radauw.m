function xw=gm_radauw(N,ab,end0);
%GM_RADAUW Gauss-Radau quadrature rule

% use gauss for the nodes and the 3-term recurrence for the weights
% Needs the OPQ package from W. Gautschi

% Input:
% N = number of nodes
% ab = 3-term recurrence for the orthogonal polynomials
%      same as in OPQ
%      ab(1,2) is the 0th moment
% end0 = prescribed node

% Output:
% xw = xw(:,1) nodes, xw(:,2) weights of the quadrature rule

%
% Author A. Sommariva
% Adapted from OPQ from W. Gautschi
% June 2012
% Updated by G. Meurant, July 2015
%

p0 = 0;
p1 = 1;

for n = 1:N
 pm1 = p0;
 p0 = p1;
 p1 = (end0 - ab(n,1)) * p0 - ab(n,2) * pm1;
end

ab(N+1,1) = end0 - ab(N+1,2) * p0 / p1;

mu0 = ab(1,2);
n = size(ab,1);
b(1:n-1) = sqrt(ab(2:n,2));
% compute the tridiagonal matrix
J = diag(ab(:,1)) + diag(b(1:n-1),1) + diag(b(1:n-1),-1);
x = sort(eig(J));
w = gm_weights_dqds(x',ab(:,1),b);
% w are the squares of the first components
w = mu0 * w;
xw = [x w'];

