function [tk,wk,tn,wn]=gm_gausskronquadrule_m(a,b,mu0);
%GM_GAUSSKRONQUADRULE_M computes nodes and weights of the Gauss-Kronrod rule
% using the Matlab QR algorithm

% Input:
% a and b = elements of the diagonal and subdiagonal of the Jacobi
%           matrix for the orthonormal polynomials associated with the measure
% mu0 = moment of order 0
%
% Ouput:
% tk, wk = Kronrod nodes and weights (2n+1 nodes)
% tn, wn = Gauss nodes and weights

%
% Author G. Meurant
% July 2008
% updated July 2015
%

m = length(a);
if m == 1
  tk = a(1);
  wk = mu0;
  tn = tk;
  wn = wk;
  return
end

% m must be of the form 3n/2+1
% where n is the number of nodes in the Gauss rule
% is m-1 divisible by 3?
if rem(m-1,3) ~= 0
  error('gm_gausskronquadrule_m: The size of a must be 3n/2+1')
end

n = 2 * (m-1) / 3;

% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 

% n-point Gauss rule
Jn = J(1:n,1:n);
Jn = full(Jn);
[Zn,Dn] = eig(Jn);
% Gauss nodes
tn = diag(Dn);
[tn,ind] = sort(tn);
% Gauss weights
wn = mu0 * Zn(1,ind).^2;
Zn = Zn(:,ind);

% trailing submatrix of J
% assume that mu0=1 ????
Js = J(n+2:m,n+2:m);
Js = full(Js);
[Zs,Ds] = eig(Js);
ts = diag(Ds);
ws = Zs(1,:).^2;

% compute the first element of the eigenvector of the unknown part
% Lagrange interpolation
wt = zeros(1,n);
for k = 1:n
  wtt = 0;
  for j = 1:n/2
    lk = 1;
    for mm = 1:n
      if mm ~= k
        lk = lk * (ts(j) - tn(mm)) / (tn(k) - tn(mm));
      end
    end
    wtt = wtt + lk * ws(j);
  end
  if wtt <= 0 
    error('gm_gausskronquadrule_m: Negative weights, the Kronrod rule does not exist')
  end
  wts(k) = wtt;
  wt(k) = sqrt(wtt);
end

% construct the "arrowhead" matrix
% last row of Zn
Zne = Zn(n,:);
gamman = J(n+1,n);
gammap = J(n+2,n+1);
om = J(n+1,n+1);
T = [diag(tn) gamman*Zne' zeros(n,n); gamman*Zne om gammap*wt; zeros(n,n) gammap*wt' diag(tn)];
% eigensystem of T
[Zt,Dt] = eig(T);
tt = diag(Dt);

% compute the first element of the eigenvectors of the Kronrod matrix
wk = Zn(1,:) * Zt(1:n,:);
wk = wk.^2;
% normalize
s = sum(wk);
wk = mu0 * wk / s;
tk = tt';
tn = tn';

