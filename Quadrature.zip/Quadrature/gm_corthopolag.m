function [a,b,mu0]=gm_corthopolag(swt,n,alpha,beta);
%GM_CORTHOPOLAG computes the Jacobi matrix for classical orthogonal
% polynomials for the Anti-Gauss rule

% modification by sqrt(2) of the last non diagonal coefficient

% Input parameters as in gm_classicorthopoly

%
% Author G. Meurant
% March 2008
% updated July 2015
%

if n == 1
 error('gm_corthopolag: n must be larger than 1')
end

% compute the Gauss Jacobi matrix
[a,b,mu0] = gm_classicorthopoly(swt,n,alpha,beta);

% modify the last element of b
b(n-1) = sqrt(2) * b(n-1);
