function [t,w] = gm_gaussradquadrule_m(a,b,mu0,node);
%GM_GAUSSRADQUADRULE_M nodes and weights of the Gauss-Radau rule using the Matlab QR algorithm

% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
% mu0 is the moment of order zero
%

% Input: 
% a, b = 3-term recurrence coefficients
% muzero = moment of order 0
% node = prescribed node
%
% Output:
% t, w = nodes and weights

% Author G. Meurant
% June 2007
%

if nargin < 4
 error('gm_gaussradquadrule_m: the prescribed node is undefined')
end

n = length(a);

if n == 1
  t = a(1);
  w = mu0;
  return
end

% modify the last element diagonal element

% tridiagonal solve of (T_{n-1}- node I) delta = b_{n-1}^2 (0 0 ... 1)^T

T = spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e = zeros(n-1,1);
e(n-1) = 1;
d = (T - node * speye(n-1)) \ (b(n-1)^2 * e);

a(n) = node + d(n-1);

% modified Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 
J = full(J);
% Eigenvalues and eigenvectors
[V,D] = eig(J);
% nodes
t = diag(D);
[t,i] = sort(t);
% weights
w = mu0 * V(1,i).^2;
t = t';

