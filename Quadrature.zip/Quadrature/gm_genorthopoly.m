function [a,b] = gm_genorthopoly(n,mu);
%GM_GENORTHOPOLY given the 2n+1 moments mu of the weight function  generates the recursion coefficients of the normalized orthogonal polynomials

% Input:
% n = length of vector a
% mu = moments, must be of length 2 n + 1
%
% Output:
% a, b = 3-term recurrence coefficients

%
% From Golub and Welsch
% Author G. Meurant
% June 2007
% Updated July 2015
%

nmu = length(mu);
if nmu ~= 2 * n + 1
 error('gm_genorthopoly: The number of moments is wrong')
end

% Cholesky decomposition of the moment matrix
% this may not be efficient
r = sparse(n+1,n+1);
for i = 1:n+1
 for j = i:n+1
  sum = mu(i+j-1);
  for k = i-1:-1:1
   sum = sum - r(k,i) * r(k,j);
  end
  if i == j
    if sum <= 0
      error('gm_genorthopoly: The moment matrix is not positive definite')
    end
   r(i,i) = sqrt(sum);
  else
   r(i,j) = sum / r(i,i);
  end
 end
end

% compute the recursion coefficients
a = zeros(1,n);
if n == 1
  a(n) = r(n,n+1) / r(n,n);
  b = 0;
  return
end
b = zeros(1,n-1);
a(n) =r(n,n+1) / r(n,n) - r(n-1,n) / r(n-1,n-1);
for j = n-1:-1:2
 b(j) = r(j+1,j+1) / r(j,j);
 a(j) = r(j,j+1) / r(j,j) - r(j-1,j) / r(j-1,j-1);
end
b(1) = r(2,2) / r(1,1);
a(1) = r(1,2) / r(1,1);


