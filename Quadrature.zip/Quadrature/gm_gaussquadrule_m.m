function [t,w] = gm_gaussquadrule_m(a,b,mu0);
%GM_GAUSSQUADRULE_M nodes and weights of the Gauss rule using the Matlab QR algorithm

% a and b are the elements of the diagonal and subdiagonal of the Jacobi
% matrix for the orthonormal polynomials associated with the measure
% mu0 is the moment of order zero

% Input: 
% a, b = 3-term recurrence coefficients
% muzero = moment of order 0
%
% Output:
% t, w = nodes and weights

%
% Author G. Meurant
% June 2007
% Updated July 2015
%

if length(a) == 1
  t = a(1);
  w = mu0;
  return
end

% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 
J = full(J);
% Eigenvalues and eigenvectors
[V,D] = eig(J);
% nodes
t = diag(D);
[t,i] = sort(t);
% weights
w = mu0 * V(1,i).^2;
t = t';

