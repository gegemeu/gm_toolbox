function tw=gm_trigauss(n,alpha,beta)
%GM_TRIGAUSS computes the n+1 angles and weights of a trigonometric gaussian
% quadrature formula on [alpha,beta], 0 < beta - alpha <= 2 * pi

% the formula integrates the canonical trigonometric basis with accuracy
% from about 10^(-15) (small omega) to about 10^(-13) (omega-->pi)
% up to n=300

% Input:
% n = trigonometric degree of exactness
% [alpha,beta] = angular interval, 0 < beta - alpha <= 2 * pi
%
% Output:
% tw = (n+1) x 2 array of (angles,weights)

% by Gaspare Da Fies, Alvise Sommariva and Marco Vianello
% University of Padova
% February 28, 2013

n = n + 1;
omega = (beta - alpha) / 2;
ab = r_subchebyshev(n,omega);
[t,w] = gm_symmMw(n,ab);
xw_symm_eigw = [t' w'];
tw = trigauss_conversion(xw_symm_eigw,omega);
tw(:,1) = tw(:,1) + (beta + alpha) / 2;

end

function ab=r_subchebyshev(n,omega)

% Input:
% n = NUMBER OF POINTS
% omega = ARC ANGLE
%
% Output:
% ab = COEFFS of THREE TERM RECURSION

% Authors:
% Gerard Meurant and Alvise Sommariva
% June 3, 2012
%

N = n;
n = n - 1;

% modified Chebyshev moments by recurrence

if rem(N,2) == 1
 NN = N + 1;
 nn = n + 1;
else
 NN = N;
 nn = n;
end

mom = fast_moments_computation(omega,2*nn+1);

% recurrence coeffs of the monic Chebyshev polynomials
abm(:,1) = zeros(2*nn+1,1);
abm(:,2) = 0.25 * ones(2*nn+1,1);
abm(1,2) = pi;
abm(2,2) = 0.5;

% recurrence coeffs for the monic OPS w.r.t. the weight function
% w(x)=2*sin(omega/2)/sqrt(1-sin^2(omega/2)*x^2)
% by the modified Chebyshev algorithm

ab = fast_chebyshev(NN,mom,abm);

end


function x=tridisolve(a,b,c,d)
%TRIDISOLVE  Solve tridiagonal system of equations
% From Cleve Moler's Matlab suite
% http://www.mathworks.it/moler/ncmfilelist.html

% optimized version
x = d;
n = length(x);
bi = zeros(n,1);

for j = 1:n-1
 bi(j) = 1 / b(j);
 mu = a(j) * bi(j);
 b(j+1) = b(j+1) - mu * c(j);
 x(j+1) = x(j+1) - mu * x(j);
end

x(n) = x(n) / b(n);
for j = n-1:-1:1
 x(j) = (x(j) - c(j) * x(j+1)) * bi(j);
end

end


function ab=fast_chebyshev(N,mom,abm)
%FAST_CHEBYSHEV Modified Chebyshev algorithm
% this works only for the subperiodic weight function

% From Gautschi's code (simplified)
% Mar 2012
%

ab = zeros(N,2);
sig = zeros(N+1,2*N);

ab(1,2) = mom(1);

sig(1,1:2*N) = 0;
sig(2,:) = mom(1:2*N);

for n = 3:N+1
 for m = n-1:2*N-n+2
  sig(n,m) = sig(n-1,m+1) + abm(m,2) * sig(n-1,m-1) - ab(n-2,2) * sig(n-2,m);
 end
 
 ab(n-1,2) = sig(n,n-1) / sig(n-1,n-2);
end

end

function mom=fast_moments_computation(omega,n)

mom = zeros(1,n+1);
mom(1) = 2 * omega; % FIRST MOMENT.

if n >= 2
 
 if omega <= 1/4*pi
  l = 10;
 elseif omega <= 1/2*pi
  l = 20;
 elseif omega <= 3/4*pi
  l = 40;
 else
  if omega == pi
   l = 2 * ceil(10 * pi);
  else
   l = 2 * ceil(10 * pi / (pi - omega));
  end
 end
 
 temp = (2:2:n+2*l-2); 
 temp2 = temp.^2 - 1;
 
 dl = 1 / 4 - 1 ./ (4 * (temp - 1)); 
 dc = 1 / 2 - 1 / sin(omega / 2)^2 - 1 ./ (2 * temp2);
 du = 1 / 4 + 1 ./ (4 * (temp + 1));
 
 d = 4 * cos(omega / 2) / sin(omega / 2) ./ temp2'; 
 d(end) = d(end);                         % PUT LAST MOMENT NULL ?????
 
 z = tridisolve(dl(2:end),dc,du(1:end-1),d); % SOLVE SYSTEM
 mom(3:2:n+1) = z(1:floor(n/2)); % SET ODD MOMENTS
 
end

mom = mom';

normalized = 0;

if normalized == 0
 M = length(mom);
 kk = 2.^(-((1:2:M)-2))';
 kk(1) = 1;
 v = ones(M,1);
 v(1:2:M) = kk;
 mom = v .* mom;
end

end

function tw=trigauss_conversion(xw,omega)

tw(:,1) = 2 * asin(sin(omega / 2) * xw(:,1));
tw(:,2) = xw(:,2);

end

