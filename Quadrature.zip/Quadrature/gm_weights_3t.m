function w=gm_weights_3t(t,a,b);
%GM_WEIGHTS_3T squares of the 1st components of eigenvectors from the 3-term  
% recurrence relation of the orthogonal polynomials

% Input:
% t = nodes
% a, b =  coefficients of the 3-term recurrence
%
% Ouput:
% w = squares of the first components of the eigenvectors
%

%
% Authors G. Meurant and A. Sommariva
% June 2012
% Updated July 2015
%

N = length(t);

P = zeros(N,N);
P(1,:) = ones(1,N);
P(2,:) = (t - a(1)) / b(1);

for k = 3:N
 k1 = k - 1;
 k2 = k - 2;
 P(k,:) = ((t - a(k1)) .* P(k1,:) - b(k2) * P(k2,:)) / b(k1);
end

P2 = P .* P;



w = 1 ./ sum(P2);

