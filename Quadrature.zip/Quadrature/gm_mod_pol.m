function [am,bm,mu0m] = gm_mod_pol(a,b,mu0);
%GM_MOD_POL Jacobi matrix for a multiplication of w by a polynomial r 

% the roots of the polynomial must be outside of the interval of definition
% and the polynomial must be positive there
% the polynomial is defined in the subfunction mod_pol_r below

% Input:
% a, b = 3-term recurrence coefficients
% mu0 = moment of order 0
%
% Output:
% am, bm = modified coefficients
% mu0m = moment of order 0

%
% Author G. Meurant
% July 2008
% Updated July 2015
%

% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 
n = size(J,1);
% eigensystem of J
[Z,DJ] = eig(J);
tetJ = diag(DJ);

% QR factorization of D Z' 
[D2,deg,coeff] = mod_pol_r(tetJ);
D = sqrt(D2);
D = diag(D);
[Q,R] = qr(D * Z');

J1 = Q' * DJ * Q;

% The Jacobi matrix for rw is a leading matrix of J1
m = n - floor(deg / 2) - 1;

J1 = J1(1:m,1:m);

am = diag(J1);
bm = abs(diag(J1,-1));

% computation of the first moment
% compute the Gauss rule for w
[t,w] = gm_gaussquadrule_m(a,b,mu0);
% computation of the moments for w
mom = zeros(1,deg+1);
mom(1) = mu0;
for k = 1:deg
  ft = t.^k;
  mom(k+1) = sum(w .* ft);
end

mu0m = coeff(1) * mom(1);
for k = 2:deg+1;
  mu0m = mu0m + coeff(k) * mom(k);
end

end


function [y,deg,coeff]=mod_pol_r(x);
%MOD_POL_R polynomial r at x

% must be modified to define the polynomial
% below are some examples

pb = 2;
beta = -2;

switch(pb)
 
  case 1
    deg = 1;
    y = x - beta;
    % coefficients of the polynomial in ascending order
    coeff(1) = -beta;
    coeff(2) = 1;
    
  case 2
    deg = 2;
    y = (x - beta).^2;
    coeff(1) = beta^2;
    coeff(2) = -2 * beta;
    coeff(3) = 1;
    
  case 3
    deg = 2;
    y = 1 - x.^2;
    coeff(1) = 1;
    coeff(2) = 0;
    coeff(3) = -1;
    
  case 4
    deg = 2;
    y = x.^2;
    coeff(1) = 0;
    coeff(2) = 0;
    coeff(3) = 1;
end
  

end