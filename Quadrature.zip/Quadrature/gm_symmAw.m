function [t,w]=gm_symmAw(N,ab);
%GM_SYMMAW computation of the nodes and weights for a symmetric weight
% function

% this version uses the reduced polynomials and gauss from OPQ for the
% nodes and computes the weights using the 3-term recurrence
% Needs the OPQ package from W. Gautschi

% see: Fast variants of the Golub and Welsch algorithm for symmetric
% weight functions by G. Meurant and A. Sommariva
% Numer. Algo. 67, v 3 (2014), pp. 491-506

% Input:
% N = number of nodes
% ab = 3-term recurrence for the orthogonal polynomials
%      same as in OPQ
%      ab(1,2) is the 0th moment

% Output:
% t, w = nodes and weights

%
% Authors G. Meurant and A. Sommariva
% June 2012
% Updated July 2015
%

N0 = size(ab,1);
if N0 < N
 error('gm_symmAw: Input array ab is too short')
end

na = norm(ab(:,1));
if na > 0
 error('gm_symmAw: The weight function must be symmetric')
end

% computation of the 3-term recurrence for the reduced weight function

nu = ab(:,2);
nu_odd = nu(1:2:end);
nu_even = nu(2:2:end);
D = [nu(2); nu_odd(2:end) + nu_even(2:end)];
E = [nu(1) / 2; nu_odd(2:end) .* nu_even(1:end-1)];
ab_symm = [D E];

if rem(N,2) == 0
 % N even
 n=length(D);
 a = D;
 b(1:n-1) = sqrt(E(2:n));
 % construct the tridiagonal matrix
 J = diag(D) + diag(b(1:n-1),1) + diag(b(1:n-1),-1);
 % compute only the eigenvalues
 x = sort(eig(J));
 % compute the weights from 3-term recurrence
 w = weights_3t(x',a,b);
 % w are the squares of the first components
 w = E(1) * w;
 x = sqrt(x);
 w = w';
 xw = [-flipud(x) flipud(w); x w];
 
else
 % N odd
 N_symm = (N-1)/2;
 xw_symm = gm_radauw(N_symm,ab_symm,0);
 w0 = 2 * xw_symm(1,2);
 x = sqrt(xw_symm(2:end,1));
 w = xw_symm(2:end,2);
 xw = [-flipud(x) flipud(w); 0 w0; x w];
end

t = xw(:,1)';
w = xw(:,2)';



