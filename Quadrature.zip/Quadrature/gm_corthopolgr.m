function [a,b,mu0] = gm_corthopolgr(swt,n,alpha,beta,node);
%GM_CORTHOPOLGR Jacobi matrix for classical orthogonal polynomials for the Gauss-Radau rule 

% with a preassigned node
% modification  of the last diagonal coefficient

% Input parameters as in gm_classicorthopoly

%
% Author G. Meurant
% March 2008
% updated July 2015
%

% compute the Gauss Jacobi matrix
[a,b,mu0] = gm_classicorthopoly(swt,n,alpha,beta);

% modify the last element diagonal element

% tridiagonal solve of (T_{n-1}- node I) delta = b_{n-1}^2 (0 0 ... 1)^T

T = spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e = zeros(n-1,1);
e(n-1) = 1;
d = (T - node * speye(n-1)) \ (b(n-1)^2 * e);

a(n) = node + d(n-1);

