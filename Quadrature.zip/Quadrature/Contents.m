% QUADRATURE
%
% Files
%   gm_antigaussquadrule_m - computes nodes and weights of the anti-Gauss rule
%   gm_classicorthopoly    - the coefficients a,b of the normalized recurrences
%   gm_Clenshaw_Curtis     - Clenshaw-Curtis quadrature rule, nodes and weights
%   gm_corthopolag         - computes the Jacobi matrix for classical orthogonal polynomials (anti-Gauss)
%   gm_corthopolgl         - computes the Jacobi matrix for classical orthogonal polynomials (Gauss-Lobatto)
%   gm_corthopolgr         - computes the Jacobi matrix for classical orthogonal polynomials (Gauss-Radau)
%   gm_fejer1              - Fejer 1 quadrature rule, nodes and weights
%   gm_fejer2              - Fejer 2 quadrature rule, nodes and weights
%   gm_gauss               - Gauss quadrature rule from Gautschi's OPQ
%   gm_gausskronquadrule_m - computes nodes and weights of the Gauss-Kronrod rule
%   gm_gausslobquadrule_m  - computes nodes and weights of the Gauss-Lobatto rule
%   gm_gaussquadrule       - Golub and Welsch algorithm for computing the nodes
%   gm_gaussquadrule_m     - computes nodes and weights of the Gauss rule
%   gm_gaussradquadrule_m  - computes nodes and weights of the Gauss-Radau rule
%   gm_genorthopoly        - generates the recursion coefficients given the 2n+1 moments mu of the weight function 
%   gm_gqcircsect          - computes the nodes and weights of a product gaussian formula on a circular annular sector
%   gm_gqdbubble           - computes the nodes and weights of a product gaussian formula on a planar double bubble
%   gm_GWo                 - vectorized coding of the Golub and Welsch algorithm
%   gm_GWx                 - vectorized coding of the Golub and Welsch algorithm
%   gm_int_Legendre        - integral of a function with the Legendre weight
%   gm_int_weight          - integral of a function with a weight
%   gm_jacobi              - Jacobi matrix from the recurrence coefficients
%   gm_mod_div_lin         - computation of the Jacobi matrix for the division of w
%   gm_mod_lin             - computation of the Jacobi matrix for a multiplication of w
%   gm_mod_pol             - computation of the Jacobi matrix for a multiplication of w
%   gm_polygauss_2013      - cubature rule for polygons
%   gm_quadPD              - 2-dimensional cubature on the square from Padua University
%   gm_r_jacobi            - recurrence coefficients for monic Jacobi polynomials
%   gm_radau_gw            - Gauss-Radau quadrature rule
%   gm_radauw              - Gauss-Radau quadrature rule
%   gm_symmAG              - computation of the nodes and weights for a symmetric weight
%   gm_symmAGWo            - computation of the nodes and weights for a symmetric weight
%   gm_symmAw              - computation of the nodes and weights for a symmetric weight
%   gm_symmMGWo            - computation of the nodes and weights for a symmetric weight
%   gm_symmMw              - computation of the nodes and weights for a symmetric weight
%   gm_symmRadau           - Gauss-Radau quadrature rule
%   gm_trigauss            - computes the n+1 angles and weights of a trigonometric gaussian quadrature formula
%   gm_weights_3t          - squares of the 1st components of eigenvectors from the 3-term recurrence
%   gm_weights_dqds        - squares of the 1st components of eigenvectors from the 3-term recurrence  
