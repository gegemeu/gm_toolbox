% QUADRATURE
%
% functions related to Gauss qudrature rules
%
% Files
%   gm_antigaussquadrule_m - nodes and weights of the anti-Gauss rule using the Matlab QR algorithm 
%   gm_classicorthopoly    - coefficients a,b of the normalized recurrences for various classical orthogonal polynomials 
%   gm_Clenshaw_Curtis     - Clenshaw-Curtis quadrature rule, nodes and weights
%   gm_corthopolag         - Jacobi matrix for classical orthogonal polynomials for the anti-Gauss rule
%   gm_corthopolgl         - Jacobi matrix for classical orthogonal polynomials for the Gauss-Lobatto rule 
%   gm_corthopolgr         - Jacobi matrix for classical orthogonal polynomials for the Gauss-Radau rule 
%   gm_fejer1              - Fejer 1 quadrature rule, nodes and weights
%   gm_fejer2              - Fejer 2 quadrature rule, nodes and weights
%   gm_gauss               - Gauss quadrature rule from Gautschi's OPQ
%   gm_gausskronquadrule_m - nodes and weights of the Gauss-Kronrod rule using the Matlab QR algorithm
%   gm_gausslobquadrule_m  - nodes and weights of the Gauss-Lobatto rule using the Matlab QR algorithm
%   gm_gaussquadrule       - nodes and weights of a Gauss quadrature rule using the Golub and Welsch algorithm
%   gm_gaussquadrule_m     - nodes and weights of the Gauss rule using the Matlab QR algorithm
%   gm_gaussradquadrule_m  - nodes and weights of the Gauss-Radau rule using the Matlab QR algorithm
%   gm_genorthopoly        - given the 2n+1 moments mu of the weight function  generates the recursion coefficients of the normalized orthogonal polynomials
%   gm_GWo                 - vectorized coding of the Golub and Welsch algorithm
%   gm_GWx                 - vectorized coding of the Golub and Welsch algorithm
%   gm_int_Legendre        - integral of a function with the Legendre weight
%   gm_int_weight          - integral of a function with a weight
%   gm_jacobi              - Jacobi matrix from the recurrence coefficients
%   gm_mod_div_lin         - Jacobi matrix for the division of w by a linear factor r = x - beta
%   gm_mod_lin             - Jacobi matrix for a multiplication of w by a linear factor r = x - beta
%   gm_mod_pol             - Jacobi matrix for a multiplication of w by a polynomial r 
%   gm_r_jacobi            - recurrence coefficients for monic Jacobi polynomials
%   gm_radau_gw            - Gauss-Radau quadrature rule
%   gm_radauw              - Gauss-Radau quadrature rule
%   gm_symmAG              - nodes and weights for a symmetric weight function
%   gm_symmAGWo            - nodes and weights for a symmetric weight function
%   gm_symmAw              - nodes and weights for a symmetric weight function
%   gm_symmMGWo            - nodes and weights for a symmetric weight function
%   gm_symmMw              - nodes and weights for a symmetric weight function
%   gm_symmRadau           - Gauss-Radau quadrature rule
%   gm_weights_3t          - squares of the 1st components of eigenvectors from the 3-term recurrence relation of the orthogonal polynomials
%   gm_weights_dqds        - squares of the 1st components of eigenvectors from the 3-term recurrence relation
