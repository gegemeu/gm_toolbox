function [t,w,nloop] = gm_gaussquadrule(a,b,c,muzero,symm);
%GM_GAUSSQUADRULE nodes and weights of a Gauss quadrature rule using the Golub and Welsch algorithm

% given the coefficients (a,b,c) of the orthogonal polynomials
% p(k)=(a(k) x + b(k)) p(k-1) - c(k) p(k-2)
% computes the abscissas t and the weights w of the Gauss type quadrature
% associated with orthogonal polynomials by QR iteration with shift

% Input: 
% a, b ,c = 3-term recurrence coefficients
%           in many cases c is not needed
% muzero = moment of order 0
% symm = 1, symmetrization of the Jacobi matrix
%
% Output:
% t, w = nodes and weights
% nloop = number of iterations in QR

%
% Author G. Meurant
% June 2007
% Updated July 2015
%

n = length(a);

if symm == 1
 % symmetrization of the matrix of coefficients
 for i = 1:n-1
  ai = a(i);
  % error correction Apr 2012
%   a(i) = b(i) / ai;
  a(i) = -b(i) / ai;
  b(i) = sqrt(c(i+1) / (ai * a(i+1)));
 end % for i
 a(n) = -b(n) / a(n);
end % if

if size(b,1) ~= 1
  b = b';
end % if
if size(a,1) ~= 1
  a = a';
end % if

a_old = a; b_old = b;

% find the maximum row sum norm
 ni = n;
 % Jacobi matrix
 J = spdiags([[b(1:ni-1)'; 0] a(1:ni)' [0; b(1:ni-1)']], -1:1, ni,ni);
 J = abs(J);
 nJ = J * ones(n,1);
 normJ = max(nJ);
 
 w = zeros(1,n);
 t = zeros(1,n);
 w(1) = 1;
 % relative zero tolerance
 epss = eps * normJ;
 lambda = normJ;
 lambda1 = lambda;
 lambda2 = lambda;
 rho = lambda;
 m = n;
 
 inspect = 1;
 nloop = 0;
 
 while inspect == 1 && nloop < 10000
  
  nloop = nloop + 1;
  
  if m == 0
   % sort the abscissas
   [t,ind] = sort(t);
   w = w(ind);
   return
  end % if
  
  i = m - 1;
  k = i;
  m1 = i;
  if m1 >= 1
   if abs(b(m1)) <= epss
    t(m) = a(m);
    w(m) = muzero * w(m)^2;
    rho = min(lambda1,lambda2);
    m = m1;
    continue
   end % if
  else
   t(1) = a(1);
   w(1) = muzero * w(1)^2;
   m = 0;
   continue
  end % of m1
  
  % small off diagonal element means the matrix can be split
  % correction Apr 2012
   if abs(b(i)) <= epss 
    k = i;
    break
   else
    k = 1;
   end % if

  % find the shift with the eigenvalues of lower 2x2 block
  b2 = b(m1)^2;
  det = sqrt((a(m1) - a(m))^2 + 4 * b2);
  aa = a(m1) + a(m);
  if aa > 0
   lambda2 = (aa + det) / 2;
  else
   lambda2 = (aa - det) / 2;
  end % if
  lambda1 = (a(m1) * a(m) - b2) / lambda2;
  eigmax = max(lambda1,lambda2);
  if abs(eigmax - rho) <= abs(eigmax) / 8
   lambda = eigmax;
   rho = eigmax;
  else
   rho = eigmax;
  end % if
  
  % transform block k to m
  cj = b(k);
  bk1 = a(k) - lambda;
  for j = k:m1
   % compute and apply rotations
   r = sqrt(cj^2 + bk1^2);
   st = cj / r;
   %ct = b(j-1) / r;
   ct = bk1 / r;
   aj = a(j);
   if j > 1
    b(j-1) = r;
   end % if
   if j < n-1
    cj = b(j+1) * st;
    b(j+1) = -b(j+1) * ct;
   end % if
   f = aj * ct + b(j) * st;
   q = b(j) * ct + a(j+1) * st;
   a(j) = f * ct + q * st;
   b(j) = f * st - q * ct;
   wj = w(j);
   a(j+1) = aj + a(j+1) - a(j);
   w(j) = wj * ct + w(j+1) * st;
   w(j+1) = wj * st - w(j+1) * ct;
   bk1 = b(j);
  end % for j
  
 end % while
 
 % if we have not converged, use gauss
fprintf('\n gm_gaussquadrule: Warning, GW has not converged \n')
J = diag(a_old)+diag(b_old(1:n-1),-1)+diag(b_old(1:n-1),1); 
J = full(J);
[V,D] = eig(J);
t = diag(D);
[t,i] = sort(t);
w = V(1,i).^2;
t = t';
 
 