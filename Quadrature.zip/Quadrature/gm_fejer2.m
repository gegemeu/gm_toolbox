function [tf2,wf2]=gm_fejer2(n);
%GM_FEJER2 Fejer 2 quadrature rule, nodes and weights
% interval [-1, 1]

% Input:
% n = number of nodes on [-1, 1] (in fact, n-1 nodes)
%
% Output:
% tf2 = nodes
% wf2 = weights

%
% Author G. Meurant
% from a code of Waldvogel
% July 2015
%

N = [1:2:n-1]'; 
l = length(N); 
m = n-l; 

% Fejer2 nodes
% remove 0 and n (zero weights)
k = [n-1:-1:1]';
tf2 = cos(k * pi / n);

% vector of weights: wf2, wf2_n = wf2_0 = 0
v0 = [2 ./ N ./ (N-2); 1 / N(end); zeros(m,1)];
v2 = -v0(1:end-1) - v0(end:-1:2); 

wf2 = ifft(v2);
wf2 = wf2(2:end);

