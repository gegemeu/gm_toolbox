function err=gm_plot_quadgausslobex(iex,nmax);
%GM_PLOT_QUADGAUSSLOBEX plot of the error in Gauss-Lobatto quadrature
% for some examples

% Input:
% iex = problem number (see gm_quadgausslobex)
% nmax = maximum number of nodes

%
% Author G. Meurant
% July 2015
%

err = zeros(1,nmax);

for k = 2:nmax
 [int,intex,errint] = gm_quadgausslobex(iex,k);
 err(k) = errint;
end

semilogy(err)
title(['Pb ' num2str(iex)])

