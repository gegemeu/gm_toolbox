% gm_test_symm

% Test of symmetric Gauss quadrature

% clear all;

N = 200; % NUMBER OF POINTS
% N = 400;
% JACOBI SETTINGS
alpha = -1/2; beta = alpha;
MM = 50; % NUMBER OF EXPERIMENTS


ab = gm_r_jacobi(N,alpha,beta);
% OPQ
cpu(1) = cputime;

for M = 1: MM
    xw = gm_gauss(N,ab);
end
cpu(2)=cputime;

for M = 1:MM
 [t,w] = gm_symmAG(N,ab);
 xw_symm = [t' w'];
end
cpu(3)=cputime;

for M=1:MM
 [t,w,nloop] = gm_symmMGWo(N,ab);
 xw_symm_GM = [t' w'];
end
cpu(4)=cputime;

dt=diff(cpu) / M;

ratio(1) = dt(1) / dt(2);
ratio(2) = dt(1) / dt(3);

err(1)=norm(xw-xw_symm);
err(2)=norm(xw-xw_symm_GM);
err(3)=norm(xw_symm_GM-xw_symm);

fprintf('\n \t >> Data');
fprintf('\n \t Cardinality: %3.0f',N);
fprintf('\n \t alpha: %g',alpha);
fprintf('\n \t beta : %g',beta);
fprintf('\n \t Tests: %3.0f',MM);

fprintf('\n \n \t >> Cputime');
fprintf('\n \t Gauss:    %1.15e',dt(1));
fprintf('\n \t SymmAG:   %1.15e',dt(2));
fprintf('\n \t SymmMGWo: %1.15e',dt(3));
fprintf('\n \n \t RatAG:   %1.15e',ratio(1));
fprintf('\n \t RatMGWo: %1.15e',ratio(2));

fprintf('\n \n \t >> Error');
fprintf('\n \t Gs-AG:   %1.15e',err(1));
fprintf('\n \t Gs-MGWo: %1.15e',err(2));
fprintf('\n \t AG-MGWo: %1.15e \n \n',err(3));
