function err = gm_plot_quadantigaussex(iex,nmax);
%GM_PLOT_QUADANTIGAUSSEX plot of the error in anti-Gauss quadrature
% for some examples

% Input:
% iex = problem number (see gm_quadantigaussex)
% nmax = maximum number of nodes

%
% Author G. Meurant
% July 2015
%

err = zeros(1,nmax);

for k = 2:nmax
 [int,intex,errint] = gm_quadantigaussex(iex,k);
 err(k) = errint;
end

semilogy(err)
title(['Pb ' num2str(iex)])

