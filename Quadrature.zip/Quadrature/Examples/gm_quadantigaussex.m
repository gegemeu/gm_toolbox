function [int,intex,errint]=gm_quadantigaussex(iex,n);
%GM_QUADANTIGAUSSEX examples of computations of integrals with Anti-Gauss quadrature

% Input:
% iex = problem number (see below)
% n = number of nodes
%
% Output:
% int = value of the integral
% intex = exact value of the integral
% errint = error

%
% Author G. Meurant
% March 2008
% Updated July 2015
%


switch(iex)
 
 case 1
  % Legendre weight function, f(x) = x^20
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = 2 / 21;
  
  ft = t.^(20);
  
 case 2
  % Legendre weight function, f(x) = exp(x)
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = exp(1) - exp(-1);
  
  ft = exp(t);
  
 case 3
  % Legendre weight function, f(x) = 1/(1+10 x^2)
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = 0.7997520101115316;
  
  ft = 1 ./ (1 + 10 * t.^2);
  
 case 4
  % Legendre weight function, f(x) = exp(-1/x^2)
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = 0.1781477117815611;
  
  ft = exp(-1 ./ t.^2);
  
 case 5
  % Legendre weight function, f(x) = (1-x^2)^(-1/2)
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = pi;
  
  ft = 1 ./ sqrt(1 - t.^2);
  
 case 6
  % Chebyshev weight function, f(x) = (1-x^2)^(-1/2)
  [a,b,mu0] = gm_corthopolag('c1',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = pi;
  
  ft = ones(1,n);
  
 case 7
  % Legendre weight function, f(x) = (1-x^2)^(1/2)/(2+x)^(1/2)
  [a,b,mu0] = gm_corthopolag('le',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = 1.139488044069456;
  
  ft = sqrt(1 - t.^2) ./ sqrt(2 + t);
  
   case 8
  % Chebyshev second kind weight function, f(x) = 1/(2+x)^(1/2)
  [a,b,mu0] = gm_corthopolag('c2',n,0,0);
  [t,w] = gm_gaussquadrule(a,b,0,mu0,0);
  intex = 1.139488044069456;
  
  ft = 1 ./ sqrt(2 + t);
  
 otherwise
  error('gm_quadantigaussex: Unknown example')
  
end

int = sum(w .* ft);
errint = abs(intex - int);

