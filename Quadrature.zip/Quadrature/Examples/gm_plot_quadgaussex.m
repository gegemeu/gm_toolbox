function err = gm_plot_quadgaussex(iex,nmax);
%GM_PLOT_QUADGAUSSEX plot of the error in Gauss quadrature for some examples

% Input:
% iex = problem number (see gm_quadgaussex)
% nmax = maximum number of nodes

%
% Author G. Meurant
% July 2015
%

err = zeros(1,nmax);

for k = 1:nmax
 [int,intex,errint] = gm_quadgaussex(iex,k);
 err(k) = errint;
end

semilogy(err)
title(['Pb ' num2str(iex)])

