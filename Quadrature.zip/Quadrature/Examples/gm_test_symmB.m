% Test of symmetric Gauss quadrature as functions of the number of nodes

% Needs OPQ package from W. Gautschi

clear all;

Nv = 100:500:2600; % NUMBER OF POINTS
% Nv = 4:4:200;
% Nv = 4:1:50;
alpha=0.75; beta=0.75; % JACOBI SETTINGS
MM = 2; % NUMBER OF EXPERIMENTS

ratio_hist=[];
ratio_GL = [];
cpu_hist=[];
dt =zeros(1,8);
iter = zeros(1,length(Nv));
iterS = zeros(1,length(Nv));
iterd = zeros(1,length(Nv));
err1 = 0;
errw1 = 0;
err2 = 0;
errw2 = 0;
err3 = 0;
errw3 = 0;
err4 = 0;
errw4 = 0;
err5 = 0;
errw5 = 0;
err6 = 0;
errw6 = 0;
err7 = 0;
errw7 = 0;

for kk = 1:length(Nv)
 N = Nv(kk);
 
 % CLASSIC GAUSS
 
 tic;
 for M = 1:MM
  ab = gm_r_jacobi(N,alpha,beta);
  xw = gauss(N,ab);
 end
 tt = toc;
 dt(1) = tt  /M;
 
 % Symmetric A with Gauss
 
 tic;
 for M = 1:MM
  if rem(N,2) == 0
   ab = gm_r_jacobi(N,alpha,beta);
  else
   ab = gm_r_jacobi(N+1,alpha,beta);
  end
  [t,w] = gm_symmAG(N,ab);
  xw_symm_ASG = [t' w'];
 end
 tt = toc;
 dt(2) = tt / M;
 
 % Symmetric A with GW opt
 
 tic;
 for M = 1:MM
  if rem(N,2) == 0
   ab = gm_r_jacobi(N,alpha,beta);
  else
   ab = gm_r_jacobi(N+1,alpha,beta);
  end
  [t,w,nloopS] = gm_symmAGWo(N,ab);
  xw_symm_AS = [t' w'];
 end
 tt = toc;
 dt(3) = tt / M;
 
 % Block elimination Mw
 
 tic;
 for M = 1:MM
  ab = gm_r_jacobi(N,alpha,beta);
  [t,w] = gm_symmMw(N,ab);
  xw_symm_GM = [t' w'];
  
 end
 tt = toc;
 dt(4) = tt / M;
 
 % Block elimination MGWo
 
 tic;
 for M = 1:MM
  ab = gm_r_jacobi(N,alpha,beta);
  [t,w,nloopd] = gm_symmMGWo(N,ab);
  xw_symm_dqds = [t' w'];
  
 end
 tt = toc;
 dt(5) = tt / M;
 
 % Symmetric A with eig and 3-term recurrence
 
 tic;
 for M = 1:MM
  if rem(N,2) == 0
   ab = gm_r_jacobi(N,alpha,beta);
  else
   ab = gm_r_jacobi(N+1,alpha,beta);
  end
  [t,w]= gm_symmAw(N,ab);
  xw_symm_A = [t' w'];
 end
 tt = toc;
 dt(6) = tt / M;
 
 % STATS
 ratio(1) = dt(1) / dt(2);
 ratio(2) = dt(1) / dt(3);
 ratio(3) = dt(1) / dt(4);
 ratio(4) = dt(1) / dt(5);
 ratio(5) =  dt(1) / dt(6);
 
 ratio_hist = [ratio_hist; ratio];

 cpu_hist = [cpu_hist; dt];
 
 
 err(1) = norm(xw(:,1)-xw_symm_ASG(:,1),inf);
 err(2) = norm(xw(:,1)-xw_symm_AS(:,1),inf);
 err(3) = norm(xw(:,1)-xw_symm_GM(:,1),inf);
 err(4) = norm(xw(:,1)-xw_symm_dqds(:,1),inf);
 err(5) = norm(xw(:,1)-xw_symm_A(:,1),inf);
 err1  = max(err1,err(1));
 err2  = max(err2,err(2));
 err3  = max(err3,err(3));
 err4  = max(err4,err(4));
 err5  = max(err5,err(5));
 
 errw(1)=norm(xw(:,2)-xw_symm_ASG(:,2),inf);
 errw(2)=norm(xw(:,2)-xw_symm_AS(:,2),inf);
 errw(3)=norm(xw(:,2)-xw_symm_GM(:,2),inf);
 errw(4)=norm(xw(:,2)-xw_symm_dqds(:,2),inf);
 errw(5)=norm(xw(:,2)-xw_symm_A(:,2),inf);
 errw1  = max(errw1,errw(1));
 errw2  = max(errw2,errw(2));
 errw3  = max(errw3,errw(3));
 errw4  = max(errw4,errw(4));
 errw5  = max(errw5,errw(5));
 
 fprintf('\n\n \t >> Data');
 fprintf('\n \t Cardinality: %3.0f',N);
 fprintf('\n \t alpha: %g',alpha);
 fprintf('\n \t beta : %g',beta);
 fprintf('\n \t Tests: %3.0f',MM);
 
 fprintf('\n \n \t >> Cputime');
 fprintf('\n \t Gauss   : %1.15e',dt(1));
 fprintf('\n \t SymAG   : %1.15e',dt(2));
 fprintf('\n \t SymAGWo : %1.15e',dt(3));
 fprintf('\n \t SymMw   : %1.15e',dt(4));
 fprintf('\n \t SymMGWo : %1.15e',dt(5));
 fprintf('\n \t SymAw   : %1.15e',dt(6));

 
 fprintf('\n \n \t >> Ratios to Gauss');
 fprintf('\n \t RatAG    : %1.15e',ratio(1));
 fprintf('\n \t RatAGWo  : %1.15e',ratio(2));
 fprintf('\n \t RatMw    : %1.15e',ratio(3));
 fprintf('\n \t RatMGWo  : %1.15e',ratio(4));
 fprintf('\n \t RatAw    : %1.15e',ratio(5));
 
 fprintf('\n \n \t >> Error nodes');
 fprintf('\n \t Gs-AG   : %1.15e',err(1));
 fprintf('\n \t Gs-AGWo : %1.15e',err(2));
 fprintf('\n \t Gs-Mw   : %1.15e',err(3));
 fprintf('\n \t Gs-MGWo : %1.15e',err(4));
 fprintf('\n \t Gs-Aw   : %1.15e',err(5));
 
 fprintf('\n \n \t >> Error weights');
 fprintf('\n \t Gs-AG   : %1.15e',errw(1));
 fprintf('\n \t Gs-AGWo : %1.15e',errw(2));
 fprintf('\n \t Gs-Mw   : %1.15e',errw(3));
 fprintf('\n \t Gs-MGWo : %1.15e',errw(4));
 fprintf('\n \t Gs-Aw   : %1.15e',errw(5));
 
end

fprintf('\n\n \t max Gs-AG   : %1.15e',err1);
fprintf('\n \t max Gs-AGWo : %1.15e',err2);
fprintf('\n \t max Gs-Mw   : %1.15e',err3);
fprintf('\n \t max Gs-MGWo : %1.15e',err4);
fprintf('\n \t max Gs-Aw   : %1.15e',err5);

fprintf('\n \n \t max w Gs-SG : %1.15e',errw1);
fprintf('\n \t max w Gs-AGWo  : %1.15e',errw2);
fprintf('\n \t max w Gs-Mw    : %1.15e',errw3);
fprintf('\n \t max w Gs-MGWo  : %1.15e',errw4);
fprintf('\n \t max w Gs-Aw    : %1.15e\n\n',errw5);


figure
plot(Nv',ratio_hist(:,1),'b-o',Nv',ratio_hist(:,2),'r-*',Nv',ratio_hist(:,3),'g-+',Nv',ratio_hist(:,4),'m-d'...
 ,Nv',ratio_hist(:,5),'k-h');
legend('SymmAG','SymmAGWo','SymmMw','SymmMGWo','SymmAw');
title('Speed up relative to Gauss')
hold on
plot([min(Nv) max(Nv)],[1 1],'r')
hold off




