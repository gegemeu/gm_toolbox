% EXAMPLES
%
% Test functions for quadrature rules
%
% Files
%   gm_plot_quadantigaussex - plot of the error in anti-Gauss quadrature
%   gm_plot_quadgaussex     - plot of the error in Gauss quadrature
%   gm_plot_quadgausslobex  - plot of the error in Gauss-Lobatto quadrature
%   gm_plot_quadgaussradex  - plot of the error in Gauss-Radau quadrature
%   gm_quadantigaussex      - examples of computations of integrals with Anti-Gauss quadrature
%   gm_quadgaussex          - examples of computations of integrals with Gauss quadrature
%   gm_quadgausslobex       - examples of computations of integrals with Gauss-Lobatto quadrature
%   gm_quadgaussradex       - examples of computations of integrals with Gauss-Radau quadrature
%   gm_test_gaussquadrule   - test program for gm_gaussquadrule
%   gm_test_gaussquadrule_m - test program for gm_gaussquadrule_m
%   gm_test_quadrule        - test program for Gauss quadrature rules
%   gm_test_quadrule_m      - test program for Gauss quadrature rules
%   gm_test_symm            - test of symmetric Gauss quadrature
%   gm_test_symmB           - test of symmetric Gauss quadrature as functions of the number of nodes
