function err = gm_plot_quadgaussradex(iex,nmax);
%GM_PLOT_QUADGAUSSRADEX plot of the error in Gauss-Radau quadrature for some examples

% Input:
% iex = problem number, 1 <= iex <= 8 (see gm_quadgaussradex)
% nmax = maximum number of nodes

%
% Author G. Meurant
% July 2015
%

err = zeros(1,nmax);

for k = 2:nmax
 [int,intex,errint] = gm_quadgaussradex(iex,k);
 err(k) = errint;
end

semilogy(err)
title(['Pb ' num2str(iex)])

