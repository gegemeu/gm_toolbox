function gm_test_quadrule(n);
%GM_TEST_QUADRULE test program for Gauss quadrature rules

% computes the nodes and weights from the Jacobi matrix
%
% gm_gaussquadrule is the Golub and Welsch original algorithm

% Input:
% n = number of nodes

%
% Author G. Meurant
% June 2007
% Updated July 2015
%

format long e

% Legendre polynomials on [-1,1]

fprintf('\n------ Legendre quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('le',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Shifted Legendre polynomials on [0,1]

fprintf('\n\n------ Shifted Legendre quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('sl',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% First kind Chebyshev polynomials on [-1,1]

fprintf('\n\n------ Chebyshev (first kind) quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('c1',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Second kind Chebyshev polynomials on [-1,1]

fprintf('\n\n------ Chebyshev (second kind) quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('c2',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Third kind Chebyshev polynomials on [-1,1]

fprintf('\n\n------ Chebyshev (third kind) quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('c3',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Fourth kind Chebyshev polynomials on [-1,1]

fprintf('\n\n------ Chebyshev (fourth kind) quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('c4',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Gegenbauer polynomials on [-1,1]

fprintf('\n\n------ Gegenbauer quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('ge',n,1,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Jacobi polynomials on [-1,1]

fprintf('\n\n------ Jacobi quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('ja',n,1/2,1/2);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                   Weights \n')
[t' w']

% Laguerre polynomials

fprintf('\n\n----- Laguerre quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('la',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                  Weights \n')
[t' w']  

% Generalized Laguerre polynomials

fprintf('\n\n----- Generalized Laguerre quadrature with alpha = -0.75 \n\n')
[a,b,mu0] = gm_classicorthopoly('gl',n,-0.75,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                  Weights \n')
[t' w']

% Hermite polynomials

fprintf('\n\n----- Hermite quadrature \n\n')
[a,b,mu0] = gm_classicorthopoly('he',n,0,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                  Weights \n')
[t' w']

% Generalized Hermite polynomials

fprintf('\n\n----- Generalized Hermite quadrature with mu = 1 \n\n')
[a,b,mu0] = gm_classicorthopoly('gh',n,1,0);
[t,w] = gm_gaussquadrule(a,b,ones(n,1),mu0,0);
fprintf('          Abscissas                  Weights \n')
[t' w']

format short e




