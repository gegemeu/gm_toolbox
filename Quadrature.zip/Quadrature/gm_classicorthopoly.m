function [a,b,mu0]=gm_classicorthopoly(swt,n,alpha,beta);
%GM_CLASSICORTHOPOLY the coefficients a,b of the normalized
% recurrences for various classical orthogonal polynomials and the moment
% mu0 of order zero of its weight function

% Caution: This corresponds to a symmetric Jacobi matrix
% do not use this for monic polynomials

% Input:
% swt = choice of polynomial
%      'le' = Legendre
%      'c1' = Chebyshev first kind
%      'c2' = Chebyshev second kind
%      'c3' = Chebyshev third kind
%      'c4' = Chebyshev fourth kind
%      'ge' = Gegenbauer
%      'ja' = Jacobi
%      'la' = Laguerre
%      'gl' = generalized Laguerre
%      'he' = Hermite
%      'gh' = generalized Hermite
%
% n = order of the tridiagonal matrix
% alpha, beta = exponents for Gegenbauer and Jacobi polynomials
%
% Output:
% a, b = coefficients of the 3-term recurrence
% mu0 = moment of order 0

%
% From Golub and Welsch
% Author G. Meurant
% June 2007
% Updated July 2015
%

if nargin < 3
 alpha = -1 / 2;
 beta = alpha;
end

switch(swt)
 
 case 'le'
  % Legendre polynomials on [-1,1], weight function = 1
  mu0 = 2;
  % symmetric Jacobi matrix (so we take the square root)
  a = zeros(1,n);
  I = [1:n-1];
  b = I ./ sqrt(4 * I.^2 - 1);
  
 case 'sl'
  % Shifted Legendre polynomials on [0,1], weight function = 1
  mu0 = 1;
  a = ones(1,n)/2;
  I = [1:n-1];
  b = I ./ (2 * sqrt(4 * I.^2 - 1));
  
 case 'c1'
  % Chebyshev polynomials of the first kind on [-1,1]
  mu0 = pi;
  a = zeros(1,n);
  b = ones(1,n-1) / 2;
  b(1) = sqrt(1 / 2);
  
 case 'c2'
  % Chebyshev polynomials of the second kind on [-1,1]
  mu0 = pi / 2;
  a = zeros(1,n);
  b(1:n-1) = ones(1,n-1) / 2;
  
 case 'c3'
  % Chebyshev polynomials of the third kind on [-1,1]
  mu0 = pi;
  a = zeros(1,n);
  a(1) = 1 / 2;
  b(1:n-1) = ones(1,n-1) / 2;
  
 case 'c4'
  % Chebyshev polynomials of the fourth kind on [-1,1]
  mu0 = pi;
  a = zeros(1,n);
  a(1) = -1 / 2;
  b(1:n-1) = ones(1,n-1) / 2;
  
 case 'ge'
  % Gegenbauer polynomials on [-1,1]
  lambda = alpha;
  if lambda <= -1/2
   error('gm_classicorthopoly: Wrong parameters for Gegenbauer polynomials')
  end
  mu0 = sqrt(pi) * gamma(lambda + 1 / 2) / gamma(lambda + 1);
  a = zeros(1,n);
  I = [1:n-1];
  b = sqrt((I .* (I + 2 * lambda - 1)) ./ (4 * (I + lambda) .* (I + lambda - 1)));
  
 case 'ja'
  % Jacobi polynomials on [-1,1] with parameters alpha and beta
  if alpha <= -1 || beta <= -1
   error('gm_classicorthopoly: Wrong parameters for Jacobi polynomials')
  end
  abi = alpha + beta + 2;
  mu0 = 2^(alpha + beta + 1) * gamma(alpha + 1) * gamma(beta + 1)/ gamma(abi);
  a(1) = (beta - alpha) / abi;
  a2b2 = beta^2 - alpha^2;
  I = [2:n];
  abi = 2 * I + alpha + beta;
  a(2:n) = a2b2 ./ ((abi - 2) .* abi);
  % corrections Gautschi, error corrected on Oct 9, 2008
  b(1) = sqrt(4 * (alpha + 1) * (beta + 1) / ((alpha + beta + 2)^2 * (alpha + beta + 3)));
  I = [2:n-1];
  II = [1:n-1];
  abi = 2 * II + alpha + beta;
  abi = abi(2:n-1);
  b(2:n-1) = sqrt(4 * I .* (I + alpha) .* (I + beta) .* (I + alpha + beta) ./ ((abi.^2 - 1) .* abi.^2));
  
 case 'la'
  % Laguerre polynomials on [0,'inf'] 
  mu0 = 1;
  I = [1:n];
  % disagreement between GW and Gautschi
  a = 2 * I - 1;
  I = [1:n-1];
  b = -sqrt(I.^2);
  
 case 'gl'
  % Generalized Laguerre polynomials on [0,'inf'] (Laguerre is alpha = 0)
  if alpha <= -1 
   error('gm_classicorthopoly: Wrong parameters for Laguerre polynomials')
  end
  mu0 = gamma(alpha + 1);
  I = [1:n];
  % disagreement between GW and Gautschi
  a = 2 * I - 1 + alpha;
  I = [1:n-1];
  b = -sqrt(I .* (I + alpha));
  
 case 'he'
  % Hermite polynomials on [-'inf','inf']
  mu0 = sqrt(pi);
  a = zeros(1,n);
  I = [1:n-1];
  b = sqrt(I / 2);
  
 case 'gh'
  % Generalized Hermite polynomials on [-'inf','inf']
  mu = alpha;
  mu0 = sqrt(gamma(mu + 1 / 2));
  a = zeros(1,n);
  for i = 1:2:n-1
   b(i) = sqrt(i / 2 + mu);
   b(i+1) = sqrt(i / 2);
  end
  b = b(1:n-1);
  
 otherwise
  error('gm_classicorthopoly: Unknown polynomials')
end


  