function [I_wght,nodes,weights]=gm_quadPD(intfcn,n,xrange,yrange,ptype_index,varargin)
%GM_QUADPD 2-dimensional cubature on the square from Padua University

%------------------------------------------------------------------------------------------------
% OBJECT:
% PROCEDURE FOR THE CUBATURE ON THE SQUARE VIA PADUA NODES.
%------------------------------------------------------------------------------------------------
% INPUT:
% [intfcn]      : INTEGRAND FUNCTION. IT IS DEFINED AS IN "QUADL".
% [n]           : DEGREE OF PADUA INTERPOLANT.
% [xrange]      : RANGE OF THE DOMAIN IN THE "x" DIRECTION.
% [yrange]      : RANGE OF THE DOMAIN IN THE "y" DIRECTION.
% [ptype_index] : IT SELECTS THE FAMILY OF POINTS.
%                 [ptype_index=1] : XU POINTS.
%                 [ptype_index=2] : PADUA 1 POINTS.
%                 [ptype_index=3] : PADUA 2 POINTS.
%                 [ptype_index=4] : PADUA 3 POINTS.
%                 [ptype_index=5] : PADUA 4 POINTS.
%------------------------------------------------------------------------------------------------
% OUTPUT:
% [I_wght]      : CUBATURE VIA "weights" (COMMON WAY).
% [nodes]       : CUBATURE NODES.
% [weights]     : CUBATURE WEIGHTS.
%------------------------------------------------------------------------------------------------
% ROUTINES USED.
%
% [xhi2a]          : IT IS A PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
% [matrixPD1_fast] : NO CALLS.
%
% [xhi2a]          : IT CALLS  [bldxu], [bldTxi], [bldpadua1], [bldpadua2], [bldpadua3], [bldpadua4],
%                    [bldTxiP].
% [bldxu]          : NO CALLS. IT IS A PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldTxi]         : IT CALLS [T]. IT IS PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldpadua1]      : NO CALLS. IT IS A PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldpadua2]      : NO CALLS. IT IS A PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldpadua3]      : NO CALLS. IT IS A PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldpadua4]      : NO CALLS. IT IS A PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
% [bldTxiP]        : IT CALLS [T]. IT IS PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
%
% [T]              : NO CALLS. IT IS PROCEDURE WRITTEN BY M. CALIARI AND MONTAGNA.
%
%------------------------------------------------------------------------------------------------

[B0,x_intp,y_intp,wxi,Txi1,Txi2,f_pts] = xhi2a(intfcn,n,xrange,yrange,ptype_index,varargin{:});

% SCALING PRELIMINARIES
rxmin = xrange(1); 
rxmax = xrange(2); 
rymin = yrange(1); 
rymax = yrange(2); 

x_intp = ((rxmax - rxmin) * x_intp + (rxmax + rxmin)) / 2;  % INTERPOLATION POINTS, (x_intp,y_intp)
y_intp = ((rymax - rymin) * y_intp + (rymax + rymin)) / 2;     

nodes = [x_intp' y_intp'];

A = matrixPD1_fast(n);

A(n+1,1) = 0.5 * A(n+1,1);
weights = wxi' .* diag(Txi1' * A * Txi2);

I_wght = f_pts * weights;   % CUBATURE PADUA RULE


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [xhi2a]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [B0,x_pts,y_pts,wxi,Tx_pts,Ty_pts,f_pts] = xhi2a(intfcn,n,xrange,yrange,ptype_index,varargin)

% INPUT:
%
% [intfcn]     : FUNCTION TO STUDY. 
% [n]          : HYPER-INTERPOLATION DEGREE.
% [xrange]     : RANGE IN "x" DIRECTION. IT IS A VECTOR 1 x 2.
% [yrange]     : RANGE IN "y" DIRECTION. IT IS A VECTOR 1 x 2.
% [ptype_index]: IT DETERMINES A SET OF POINTS:
%                [ptype_index=1]: XU, [ptype_index=2]: PADUA1 [ptype_index=3]: PADUA2
%                [ptype_index=4]: PADUA3, [ptype_index=5]: PADUA4.
% [varagin]    : VARIABLE POSSIBLY USED BY THE DEFINITION OF THE FUNCTION IN "intfcn".
%
% OUTPUT:
%
% [B0]           :
% [x_pts]        : "x" COORDINATES OF THE CHOOSEN SET OF POINTS.
% [y_pts]        : "y" COORDINATES OF THE CHOOSEN SET OF POINTS.
% [wxi]          :
% [Tx_pts]       :
% [Ty_pts]       :
% [f_pts]        :
% [est]          :

switch ptype_index    % COMPUTING POINTS, WEIGHTS AND USEFUL MATRICES
 
 case 1
  [x_pts,y_pts,wxi] = bldxu(n+1);   
  [Tx_pts,Ty_pts] = bldTxi(n+1,x_pts);
  
 case 2
  [x_pts,y_pts,wxi] = bldpadua1(n); 
  [Tx_pts,Ty_pts] = bldTxiP(n,x_pts,y_pts);
  
 case 3
  [x_pts,y_pts,wxi] = bldpadua2(n);
  [Tx_pts,Ty_pts] = bldTxiP(n,x_pts,y_pts);
  
 case 4
  [x_pts,y_pts,wxi] = bldpadua3(n);
  [Tx_pts,Ty_pts] = bldTxiP(n,x_pts,y_pts);
  
 case 5
  [x_pts,y_pts,wxi] = bldpadua4(n);
  [Tx_pts,Ty_pts] = bldTxiP(n,x_pts,y_pts);
  
 otherwise
  fprintf('\n \t gm_quadPD [WARNING]: SET OF POINTS NOT AVAILABLE. PADUA1 WILL BE USED \n');
  [x_pts,y_pts,wxi] = bldpadua1(n);
  [Tx_pts,Ty_pts] = bldTxiP(n,x_pts,y_pts);
  
end

f = fcnchk(intfcn);
f_pts = feval(f,((xrange(2) - xrange(1)) * x_pts + (xrange(2) + xrange(1))) / 2,...
 ((yrange(2) - yrange(1)) * y_pts + (yrange(2) + yrange(1))) / 2,varargin{:});

D_xi_f = repmat(wxi .* f_pts,n+1,1);
B0 = Tx_pts .* D_xi_f * Ty_pts';

B0 = fliplr(triu(fliplr(B0)));

if ptype_index == 2 || ptype_index == 3 
 B0(n+1,1) = 0.5 * B0(n+1,1);
elseif  ptype_index == 4 || ptype_index == 5 
 B0(1,n+1) = 0.5 * B0(1,n+1);
end

%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [matrixA_fast].
%------------------------------------------------------------------------------------------------

function A=matrixPD1_fast(n)

set_of_index = 0:n;                                % "set_of_index"   : COLUMN VECTOR: (N+1) x 1.
A = zeros(n+1,n+1);                                % "A"              : MATRIX: (N+1) x (N+1).
[q p] = meshgrid(set_of_index);                    % "p", "q"         : MATRIX: (N+1) x (N+1).

den_p = (1 - abs(sign(1 - p.^2))) * eps + ( 1- p.^2);   % "den_p"          : MATRIX: (N+1) x (N+1).
den_q = (1 - abs(sign(1 - q.^2))) * eps + (1 - q.^2);   % "den_q"          : MATRIX: (N+1) x (N+1).

even_p = mod(p + 1,2); 
even_q = mod(q + 1,2);            % "even_p","even_q": MATRIX: (N+1) x (N+1).
A = (even_p .* even_q) * 8 ./ (den_p .* den_q);           

index_odd = 1:2:(n+1);

A(1,index_odd) = 4 * sqrt(2) ./ den_q(1,index_odd);    % MODIFICATION OF THE FIRST ROW.
A(index_odd,1) = 4 * sqrt(2) ./ den_p(index_odd,1);    % MODIFICATION OF THE FIRST COLUMN.

A = fliplr(triu(fliplr(A)));

A(1,1) = 4;


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldxu]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [xi1,xi2,wxi,ptype]=bldxu(n)

% [xi1, xi2, wxi] = bldxu(n)
%
% Builds Xu points of n-th degree.
%
% n = the degree of the Xu points. Must be a positive integer.
%
% xi1 = the x values of Xu points.
% xi2 = the y values of Xu points.
% wxi = the weights associated to each Xu point.
% ptype = an integer containing the point type. Needed by other functions.

z = cos([0:n] * pi / n);

if mod(n,2) == 0
 m = n / 2;
 xi1 = repmat(z(2:2:n),1,m+1);
 wxi = [ones(1,m) repmat(2*ones(1,m),1,m-1) ones(1,m)]; 
 xi1 = [xi1 reshape(repmat(z(1:2:n+1),m,1),1,m*(m+1))];
 wxi = [wxi ones(1,m) 2*ones(1,m*(m-1)) ones(1,m)]; 
 xi2 = xi1([m*(m+1)+1:2*m*(m+1),1:m*(m+1)]);
else
 m = (n - 1) / 2;
 xi1 = repmat(z(1:2:n),1,m+1);
 wxi = [0.5 ones(1,m) repmat([1 2*ones(1,m)],1,m)];
 xi1 = [xi1 reshape(repmat(z(n+1:-2:2),m+1,1),1,(m+1)^2)];
 wxi = [wxi 0.5 ones(1,m) repmat([1 2*ones(1,m)],1,m)];
 xi2 = -xi1([(m+1)^2+1:2*(m+1)^2,1:(m+1)^2]);
end

wxi =wxi / n^2;
ptype = 0;

%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldTxi]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [Txi1,Txi2]=bldTxi(n,xi1)



rad2 = sqrt(2);

if mod(n,2) == 0
 m = n / 2;
 Txi1 = repmat(cos([0:n-1]' * acos(xi1(1:m))),1,m+1);
 Txi1 = [Txi1 reshape(repmat(cos([0:n-1]' * acos(xi1(m*(m+1)+1:m:2*m*(m+1)))),m,1),n,m*(m+1))];
 Txi1(2:n,:) = rad2 * Txi1(2:n,:);
 Txi2 = Txi1(:,[m*(m+1)+1:2*m*(m+1),1:m*(m+1)]);
else
 m = (n - 1) / 2;
 Txi1 = repmat(cos([0:n-1]' * acos(xi1(1:m+1))),1,m+1);
 Txi1 = [Txi1 reshape(repmat(cos([0:n-1]' * acos(xi1((m+1)^2+1:m+1:2*(m+1)^2))),m+1,1),n,(m+1)^2)];
 Txi1(2:n,:) = rad2 * Txi1(2:n,:);
 Txi2 = Txi1(:,[(m+1)^2+1:2*(m+1)^2,1:(m+1)^2]);
 Txi2(2:2:n-1,:) = -Txi2(2:2:n-1,:);
end


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldpadua1]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [xi1,xi2,wxi]=bldpadua1(n)

zn = cos([0:n] * pi / n); 
zn1 = cos([0:n+1] * pi / (n + 1)); 

if mod(n,2) == 0
 m = n / 2;
 xi1 = repmat(zn(2:2:n+1),1,m+1); 
 wxi = 2 * ones(1,length(xi1)); 
 
 xi1 = [xi1,repmat(zn(1:2:n+1),1,m+1)]; 
 dummy = 2 * ones(1,m+1);
 dummy(1) = 1;
 dummy(m+1) = 1;
 wxi = [wxi,repmat(dummy,1,m+1)];
 
 xi2 = reshape(repmat(zn1(1:2:n+1),m,1),1,m*(m+1));
 
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff = reshape(repmat(coeff,m,1),1,m*(m+1));
 xi2 = [xi2,reshape(repmat(zn1(2:2:n+2),m+1,1),1,(m+1)^2)];
 tmp = ones(1,m+1);
 tmp(m+1) = .5;
 coeff = [coeff, reshape(repmat(tmp,m+1,1),1,(m+1)^2)];
 wxi = wxi .* coeff;
else 
 m = (n - 1) / 2;
 xi1 = repmat(zn(2:2:n+1),1,m+2); 
 wxi = 2 * ones(1,m+1);
 wxi(m+1) = 1;
 wxi = repmat(wxi,1,m+2);
 xi1 = [xi1, repmat(zn(1:2:n+1),1,m+1)]; 
 dummy = 2 * ones(1,m+1);
 dummy(1) = 1;
 wxi = [wxi, repmat(dummy,1,m+1)];
 

 xi2 = reshape(repmat(zn1(1:2:n+2),m+1,1),1,(m+1)*(m+2));
 coeff = ones(1,m+2);
 coeff(1) = .5;
 coeff(m+2) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)*(m+2));
 xi2 = [xi2, reshape(repmat(zn1(2:2:n+2),m+1,1),1,(m+1)^2)];
 coeff = [coeff, ones(1,(m+1)^2)];
 wxi = wxi .* coeff;
end

wxi = wxi / (n * (n + 1));


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldpadua2]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [xi1,xi2,wxi]=bldpadua2(n)

% Padua points

zn = cos([0:n] * pi / n); 
zn1 = cos([0:n+1] * pi / (n + 1)); 

if mod(n,2) == 0 
 m = n / 2;
 xi1 = repmat(zn(1:2:n+1),1,m+1); 
 wxi = 2 * ones(1,m+1); 
 wxi(1) = 1;
 wxi(m+1) = 1;
 wxi = repmat(wxi,1,m+1);
 
 
 xi1 = [xi1, repmat(zn(2:2:n+1),1,m+1)]; 
 wxi = [wxi, repmat(2*ones(1,m),1,m+1)];

 xi2 = reshape(repmat(zn1(1:2:n+1),m+1,1),1,(m+1)^2);
 
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)^2);
 xi2 = [xi2, reshape(repmat(zn1(2:2:n+2),m,1),1,m*(m+1))];
 tmp = ones(1,m+1);
 tmp(m+1) = .5;
 coeff = [coeff, reshape(repmat(tmp,m,1),1,m*(m+1))];
 wxi = wxi .* coeff;
else 
 m = (n - 1) / 2;
 xi1 = repmat(zn(1:2:n+1),1,m+2);
 wxi = 2 * ones(1,m+1);
 wxi(1) = 1;
 wxi = repmat(wxi,1,m+2);
 xi1 = [xi1, repmat(zn(2:2:n+1),1,m+1)]; 
 dummy = 2 * ones(1,m+1);
 dummy(m+1) = 1;
 wxi = [wxi, repmat(dummy,1,m+1)];
 
 xi2 = reshape(repmat(zn1(1:2:n+2),m+1,1),1,(m+1)*(m+2));
 coeff = ones(1,m+2);
 coeff(1) = .5;
 coeff(m+2) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)*(m+2));
 xi2 = [xi2, reshape(repmat(zn1(2:2:n+2),m+1,1),1,(m+1)^2)];
 coeff = [coeff, ones(1,(m+1)^2)];
 wxi = wxi .* coeff;
end

wxi = wxi / (n * (n + 1));


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldpadua3]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [xi1,xi2,wxi]=bldpadua3(n)

zn = cos([0:n] * pi / n);  
zn1 = cos([0:n+1]  *pi / (n + 1));  

if mod(n,2) == 0 
 m = n / 2;
 xi1 = repmat(zn1(2:2:n+2),1,m+1);  
 wxi = 2 * ones(1,m+1); 
 wxi(m+1) = 1;
 wxi = repmat(wxi,1,m+1);
 
 xi1 = [xi1, repmat(zn1(1:2:n+1),1,m)];  
 dummy = 2 * ones(1,m+1);
 dummy(1) = 1;
 wxi = [wxi, repmat(dummy,1,m)];
 
 xi2 = reshape(repmat(zn(1:2:n+1),m+1,1),1,(m+1)^2);
 
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff(m+1) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)^2);
 xi2 = [xi2, reshape(repmat(zn(2:2:n+1),m+1,1),1,m*(m+1))];
 coeff = [coeff, ones(1,m*(m+1))];
 wxi = wxi .* coeff;
else 
 m = (n - 1) / 2;
 xi1 = repmat(zn1(2:2:n+2),1,m+1);  
 wxi = 2 * ones(1,m+1);
 wxi = repmat(wxi,1,m+1);
 xi1 = [xi1, repmat(zn1(1:2:n+2),1,m+1)];  
 dummy = 2 * ones(1,m+2);
 dummy(1) = 1;
 dummy(m+2) = 1;
 wxi = [wxi, repmat(dummy,1,m+1)];
 
 xi2 = reshape(repmat(zn(1:2:n+1),m+1,1),1,(m+1)^2);
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)^2);
 xi2 = [xi2, reshape(repmat(zn(2:2:n+1),m+2,1),1,(m+1)*(m+2))];
 dummy = ones(1,m+1);
 dummy(m+1) = .5;
 coeff = [coeff, reshape(repmat(dummy,m+2,1),1,(m+1)*(m+2))];
 wxi = wxi .* coeff;
end

wxi = wxi / (n * (n + 1));


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldpadua4]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [xi1,xi2,wxi]=bldpadua4(n)


zn = cos([0:n] * pi / n); 
zn1 = cos([0:n+1] * pi / (n + 1));  

if mod(n,2) == 0 
 m = n / 2;
 xi1 = repmat(zn1(1:2:n+2),1,m+1); % 
 wxi = 2 * ones(1,m+1); 
 wxi(1) = 1;
 wxi = repmat(wxi,1,m+1);
 
 xi1 = [xi1, repmat(zn1(2:2:n+2),1,m)]; 
 dummy = 2 * ones(1,m+1);
 dummy(m+1) = 1;
 wxi = [wxi, repmat(dummy,1,m)];
 
 xi2 = reshape(repmat(zn(1:2:n+1),m+1,1),1,(m+1)^2);
 
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff(m+1) = .5;
 coeff = reshape(repmat(coeff,m+1,1),1,(m+1)^2);
 xi2 = [xi2, reshape(repmat(zn(2:2:n+1),m+1,1),1,m*(m+1))];
 coeff = [coeff, ones(1,m*(m+1))];
 wxi = wxi .* coeff;
else 
 m = (n - 1) / 2;
 xi1 = repmat(zn1(1:2:n+2),1,m+1); 
 wxi = 2 * ones(1,m+2);
 wxi(1) = 1;
 wxi(m+2) = 1;
 wxi = repmat(wxi,1,m+1);
 xi1 = [xi1, repmat(zn1(2:2:n+2),1,m+1)]; 
 wxi = [wxi, 2*ones(1,(m+1)^2)];

 xi2 = reshape(repmat(zn(1:2:n+1),m+2,1),1,(m+1)*(m+2));
 coeff = ones(1,m+1);
 coeff(1) = .5;
 coeff = reshape(repmat(coeff,m+2,1),1,(m+1)*(m+2));
 xi2 = [xi2, reshape(repmat(zn(2:2:n+1),m+1,1),1,(m+1)^2)];
 dummy = ones(1,m+1);
 dummy(m+1) = .5;
 coeff = [coeff, reshape(repmat(dummy,m+1,1),1,(m+1)^2)];
 wxi = wxi .* coeff;
end

wxi = wxi / (n * (n + 1));


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [bldTxiP]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function [Txi1,Txi2]=bldTxiP(n,xi1,xi2)

Txi1 = T(n,xi1);
Txi2 = T(n,xi2);

rad2 = sqrt(2);
Txi1(2:n+1,:) = rad2 * Txi1(2:n+1,:);
Txi2(2:n+1,:) = rad2 * Txi2(2:n+1,:);


%------------------------------------------------------------------------------------------------
% ATTACHED FUNCTION:
% [T]. PROCEDURE WRITTEN BY CALIARI AND MONTAGNA (SEE MARCO CALIARI HOMEPAGE).
%------------------------------------------------------------------------------------------------

function y=T(n,x)

y = cos([0:n]' * acos(x));

