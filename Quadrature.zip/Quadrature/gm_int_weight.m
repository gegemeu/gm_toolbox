function int = gm_int_weight(fcn,weight,liminf,limsup,n,alpha,beta);
%GM_INT_WEIGHT integral of a function with a weight

% Input:
% fcn = function to be integrated
% weight = weight function defined on [-1, 1]
%         'le' = Legendre
%         'c1' = Chebyshev first kind
%         'c2' = Chebyshev second kind
%         'c3' = Chebyshev third kind
%         'c4' = Chebyshev fourth kind
%         'ge' = Gegenbauer
%         'ja' = Jacobi
% [liminf, limsup] = interval of integration
% n = number of nodes in the Gauss quadrature rule
% alpha, beta = exponents for the Jacobi weight function
%
% Ouput:
% int = value of the integral

%
% Author G. Meurant
% July 2015
%

listw = cell(7);
listw(1) = {'le'}; listw(2) = {'c1'}; listw(3) = {'c2'}; listw(4) = {'c3'};
listw(5) = {'c4'}; listw(6) = {'ge'}; listw(7) = {'ja'};
iw = 0;
for k = 1:7
 if strcmpi(weight,listw{k}) == 1
  iw = 1;
 end
end
if iw == 0
 error('gm_int_weight: Unknown weight function')
end

if nargin < 6
 alpha = 0;
 beta = 0;
end

% computation of the nodes and weights on [-1, 1]
% for the given weight 
[a,b,mu0] = gm_classicorthopoly(weight,n,alpha,beta);
[t,w] = gm_gaussquadrule(a,b,0,mu0,0);

% mapping of the nodes to [liminf, limsup]
tt = ((limsup - liminf) * t + liminf + limsup) / 2;

% function values
ftt = feval(fcn,tt);

int = sum(w .* ftt) * (limsup - liminf) / 2;

