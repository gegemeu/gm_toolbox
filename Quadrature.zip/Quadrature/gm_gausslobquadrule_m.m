function [t,w]=gm_gausslobquadrule_m(a,b,mu0,node1,node2);
%GM_GAUSSLOBQUADRULE_M computes nodes and weights of the Gauss-Lobatto rule
% using the Matlab QR algorithm

% Input:
% a and b = elements of the diagonal and subdiagonal of the Jacobi
%           matrix for the orthonormal polynomials associated with the measure
% mu0 = moment of order 0
% node1, node2 = prescribed nodes
%
% Ouput:
% t, w = nodes and weights

%
% Author G. Meurant
% June 2007
% updated July 2015
%

n = length(a);
if n == 1
  t = a(1);
  w = mu0;
  return
end

% modify the last element diagonal element and the last subdiagonal element

% tridiagonal solve of (T_{n-1} - node I) delta = (0 0 ... 1)^T

T = spdiags([b' a(1:n-1)' [0 b(1:n-2)]'], -1:1, n-1, n-1);

e = zeros(n-1,1);
e(n-1) = 1;
d1 = (T - node1 * speye(n-1)) \ e;
d2 = (T -node2 * speye(n-1)) \ e;

x = [1 -d1(n-1); 1 -d2(n-1)] \ [node1; node2];

% modified coefficients
a(n) = x(1);
b(n-1) = sqrt(x(2));

% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1); 
J = full(J);
[V,D] = eig(J);
% nodes
t = diag(D);
[t,i] = sort(t);
% weights
w = mu0 * V(1,i).^2;
t = t';

