function [am,bm,mu0m]=gm_mod_div_lin(a,b,mu0,beta);
%GM_MOD_DIV_LIN computation of the Jacobi matrix for the division of w
% by a linear factor r = x - beta

% algorithm of Elhay and Kautsky
% beta must be outside of the interval of definition and  > 1

% Input:
% a, b = 3-term recurrence coefficients
% mu0 = moment of order 0
% beta = division by x - beta
%
% Output:
% am, bm = modified coefficients
% mu0m = moment of order 0

%
% Author G. Meurant
% July 2008
% Updated July 2015
%

warning off

% Legendre
mu0m = log((beta - 1) / (beta + 1));
if mu0m < 0
  error('gm_mod_div_lin: Zeroth moment is < 0')
end

n = length(a);
L = zeros(n,n);
LT = L;
% Jacobi matrix
J = diag(a) + diag(b,-1) + diag(b,1);
a = a - beta;

L(1,1) = sqrt(mu0m / mu0);
LT(1,1) = L(1,1);
L(2,1) = (1 / L(1,1) - a(1) * L(1,1)) / b(1);
LT(1,2) = L(2,1);

for i = 2:n-1
  L(i+1,1) = -(b(i-1) * L(i-1,1) + a(i) * L(i,1)) / b(i);
  LT(1,i+1) = L(i+1,1);
end
% d(1) = -(b(n-1) * L(n-1,1) + a(n) * L(n,1)) * L(1,1);

for j = 2:n
  if j > 2
    s = b(j-2) * L(j-2,1:j-2) * LT(1:j-2,j) + a(j-1) * L(j-1,1:j-1) ...
     * LT(1:j-1,j) + b(j-1) * L(j,1:j-1) * LT(1:j-1,j);
  else
    s = a(j-1) * L(j-1,1:j-1) * LT(1:j-1,j) + b(j-1) * L(j,1:j-1) * LT(1:j-1,j);
  end
  L(j,j) = sqrt(-s / b(j-1));
  LT(j,j) = L(j,j);
  
  for i = j:n-1
    s = b(i-1) * L(i-1,1:min(i-1,j)) * LT(1:min(i-1,j),j) + a(i) ...
     * L(i,1:j) * LT(1:j,j) + b(i) * L(i+1,1:j-1) * LT(1:j-1,j);
    if i == j
      L(i+1,j) = (1 - s) / (b(i) * L(j,j));
    else
      L(i+1,j) = - s / (b(i) * L(j,j));
    end
    LT(j,i+1) = L(i+1,j);
  end
%   d(j) = -(b(n-1) * L(n-1,1:min(n-1,j)) * LT(1:min(n-1,j),j) + a(n) * L(n,1:j) * LT(1:j,j));
end

Jh = inv(L) * J * L;
Jh = Jh(1:n-1,1:n-1);

am = diag(Jh);
bm = diag(Jh,-1);

warning on

