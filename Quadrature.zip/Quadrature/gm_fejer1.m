function [tf1,wf1] = gm_fejer1(n);
%GM_FEJER1 Fejer 1 quadrature rule, nodes and weights

% interval [-1, 1]

% Input:
% n = number of nodes on [-1, 1]
%
% Output:
% tf1 = nodes
% wf1 = weights

%
% Author G. Meurant
% from a code of Waldvogel
% July 2015
%

N = [1:2:n-1]'; 
l = length(N); 
m = n-l; 
K= [0:m-1]';

% Fejer1 nodes
k = [n-1:-1:0]' + 1/2;
tf1 = cos(k * pi / n);

% vector of weights
v0 = [2 * exp(1i * pi * K / n) ./ (1 - 4 * K.^2);  zeros(l+1,1)];
v1 = v0(1:end-1) + conj(v0(end:-1:2)); 
wf1 = ifft(v1);

