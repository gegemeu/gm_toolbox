function [t,w,nloop]=gm_GWo(a,b,c,muzero,symm)
%GM_GWO vectorized coding of the Golub and Welsch algorithm

% Input:
% (a,b,c) = coefficients of the orthogonal polynomials
%           p(k)=(a(k) x + b(k)) p(k-1) - c(k) p(k-2)
%           a is the diagonal of the tridiagonal matrix, 
%           b and c the sub and super diagonals
% muzero =  moment of order 0
% symm = 1 symmetrize the matrix
%           In the symmetric case (symm=0), c is not used (given as [])
%
% Output:
% t, w = nodes and weights
% nloop = number of QR iterations

%
% Author G. Meurant
% optimized version Apr 2012
% Updated July 2015
%

n = length(a);
if symm == 1
 ac = cumprod(a);
 a = -b ./ a;
 b(1:n-1) = sqrt(c(2:n) ./ ac(2:n));
end

b = b(:)';
a = a(:)';

% computation of the norm of the tridiagonal matrix
abb = abs(b(1:n-1));
apb = [abs(a(1:n-1)) + abb, abs(a(n))];
apb(2:n) = apb(2:n) + abb;
normJ = max(apb);

w = zeros(1,n);
t = zeros(1,n);
w(1) = 1;
% relative zero tolerance
epss = eps * normJ;
lambda = normJ; 
lambda1 = lambda;
lambda2 = lambda;
rho = lambda;
m = n;

inspect = 1;
nloop = 0;

while inspect == 1
 
 nloop = nloop + 1;
 
 m1 = m-1; 
 k = m1;
 i = m1;

 if m1 == 0
  t(1) = a(1);
  w(1) = muzero * w(1)^2;
  % sort the abscissas and return
  [t,ind] = sort(t);
  w = w(ind);
  return
 end
 
 if abs(b(m1)) <= epss
  t(m) = a(m);
  w(m) = muzero * w(m)^2;
  rho = min(lambda1,lambda2);
  m  = m1;
  continue
 end
 
 if abs(b(i)) <= epss
  k = i;
  break
 else
  k = 1;
 end

 % find the shift with the eigenvalues of lower 2x2 block
 b2 = b(m1)^2;
 det = sqrt((a(m1) - a(m))^2 + 4 * b2);
 aa = a(m1) + a(m);
 
 if aa > 0
  lambda2 = (aa + det) / 2;
 else
  lambda2 = (aa - det) / 2;
 end
 
 lambda1 = (a(m1) * a(m) - b2) / lambda2;
 eigmax = max(lambda1,lambda2);
 
 if abs(eigmax - rho) <= abs(eigmax) / 8
  lambda = eigmax;
 end
 rho = eigmax;
 
 % transform block from k to m
 cj = b(k);
 % shift the diagonal
 bk1 = a(k) - lambda;
 
 if k == 1
  % this is handled separately to avoid a test for b(j-1) at each step in
  % the for loop on j
  kdeb = 2;
  r = sqrt(cj^2 + bk1^2);
  st = cj / r;
  ct = bk1 / r;
  aj = a(1);
  f = aj * ct + b(1) * st;
  q = b(1) * ct + a(2) * st;
  a(1) = f * ct + q * st;
  b(1) = f * st - q * ct;
  wj = w(1);
  a(2) = aj + a(2) - a(1);
  w(1) = wj * ct + w(2) * st;
  w(2) = wj * st - w(2) * ct;
  bk1 = b(1);
  cj = b(2) * st;
  b(2) = -b(2) * ct;
 else
  kdeb = k;
 end % if k 
 
 for j = kdeb:m1
  
  % compute and apply rotations
  j1 = j + 1;
  r = sqrt(cj^2 + bk1^2);
  r1 = 1 / r;
  st = cj * r1;
  ct = bk1 * r1;
  aj = a(j); 
  b(j-1) = r;
  f = aj * ct + b(j) * st;
  q = b(j) * ct + a(j1) * st;
  a(j) = f * ct + q * st;
  b(j) = f * st - q * ct;
  wj = w(j);
  a(j1) = aj + a(j1) - a(j);
  w(j) = wj * ct + w(j1) * st;
  w(j1) = wj * st - w(j1) * ct;
  bk1 = b(j);
  cj = b(j+1) * st;
  b(j1) = -b(j1) * ct;
  
 end % for
 
end % while


