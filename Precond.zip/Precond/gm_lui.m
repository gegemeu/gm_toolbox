function [d,L,U] = gm_lui(A);
%GM_LUI  incomplete LU decomposition LU(0) without pivoting of a sparse matrix A

% L * diag(d) * U with d vector and L (and U) unit lower (upper) triangular

%
% Author G. Meurant
% July 2006
%

n = size(A,1);

B = A;
L = sparse(n,n);
U = sparse(n,n);
d = zeros(n,1);

for k = 1:n-1
 m = size(B,1);
 if abs(B(1,1)) <= 1e-14
  error('gm_lui: too small pivot')
 end
 b1 = 1 / B(1,1);
 il = find(A(k:n,k));
 iu = find(A(k,k:n));
 sl = sparse(il,1,B(il,1)*b1,m,1);
 su = sparse(1,iu,B(1,iu)*b1,1,m);
 L(k:n,k) = sl;
 L(k,k) = 1;
 d(k) = B(1,1);
 U(k,k:n) = su;
 U(k,k) = 1;
 % Schur complement
 % B = B(2:m,2:m)-b(1,1) * l(k+1:n,k) * l(k+1:n,k)';
 indl = il(2:end)-1;
 indu = iu(2:end)-1;
 sl = sl(2:m);
 su = su(2:m);
 BB = B(2:m,2:m);
 for i=indl
   BB(i,indu) = BB(i,indu) - B(1,1) * sl(i) * su(indu);
 end
 B = BB;
end % for k

L(n,n) = 1;
d(n) = B(1,1);
U(n,n) = 1;

