function [f,c,w]=gm_coarsenhmis(A,S);
%GM_COARSENHMIS HMIS coarsening algorithm, find the fine and coarse nodes
%
% S is an influence matrix for A
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w are the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%

%
% author G. Meurant
% Mar 2009
% Updated March 2015
%

f = [];
c = [];

n = size(S,1);
AA = A - diag(diag(A));

% use the same weights as in CLJP
%w = gm_wght_cljp(A,S);
% randomized weights
w = gm_wght_r(A,S);
dim = 0;

ind = [];
for i = 1:n
 indi = find(S(:,i) == 0);
 if isempty(indi)
  ind = [ind i];
 end % if
end % for i

% flag these nodes as fine
if length(ind) > 0
 f = [f ind];
 w(ind) = -50;
 dim = dim + length(ind);
end

while dim < n
 % find an independent set of nodes
 % use the coarse nodes from the result of the Ruge-Stuben algorithm
 if dim == 0
  [ff,cc,ww] = gm_coarsenstnew(A,S);
  isn = sort(cc);
 else
  isn = gm_ind_set(w,s);
 end

 if isempty(isn)
  % flag the remaining nodes as fine if not all their neighbours are fine
  ind = find(w > -50);
  indc = [];
  indf =[];
  for ii = 1:length(ind)
   i = ind(ii);
   % use S instead for interpolation
   ineighb = gm_neighb1(S,i);
   sw = sum(w(ineighb));
   if sw == -50 * length(ineighb)
    indc = [indc i];
   else
    indf = [indf i];
   end
  end
  
  w(indc) = -100;
  c = [c indc];
    
  w(indf) = -50;
  f = [f indf];
  dim = dim + length(ind);
  
 else
  % flag the nodes in the set as coarse
  w(isn) = -100;
  % c = c U {i}
  c = [c isn];
  dim = dim + length(isn);
  
  indf = [];
  for ii = 1:length(isn)
   i = isn(ii);
   % find nodes j such that i in S_j
   % neighbours of i
   ineighb = gm_neighb1(AA,i);
   for jj = 1:length(ineighb)
    j = ineighb(jj);
    sj = find(S(j,:));
    for kk = 1:length(sj)
     k = sj(kk);
     if k == i & w(j) > -50 
      indf = [indf j];
      break
     end
    end % for k
   end % for j
  end % for i
  indf = gm_unique(indf);
  
  f = [f indf];
  w(indf) = -50;
  dim = dim + length(indf);
  
  % remove isn and indf from the graph
  ind = [isn indf];
  for ii = 1:length(ind)
   i = ind(ii);
   S(i,:)=0;
   S(:,i)=0;
  end
  
 end % if isn
   
end % while





