function [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err]=gm_amg_init(A,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,normal,iprint);
%GM_AMG_INIT init of multi level preconditioner

% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%
% Input
%  matrix = A, rhs = b, init vector = x0,
%  truncation coeff = alpmax for the grid and alb for smoothing
%  max nb levels = lmax
%  gama = 1 V-cycle, gama = 2 W-cycle -----------------------------
%  smooth = smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normal = normalization
%  iprint = print level 
%
% Output
%  matrices for each level in cell arrays
%  cA = matrix on level l (ell)
%  cM = preconditioner on level l
%  cP = prolongation on level l
%  cR = restriction on level l
%  cperm = permutation on level l
%  ciperm = inverse permutation on level l
%  cdf = number of fine nodes on level l
%  cZ = factor of the AINV decomposition on level l (coarsening)
%  cD = diagonal factor of the AINV dec on level l (coarsening)
%  cZb = factor of the AINV decomposition on level l (smoothing)
%  cDb = diagonal factor of the AINV dec on level l (smoothing)
%  cL = Cholesky factor (for the coarsest level only)

%
% author G. Meurant,
% Aug 2000
%

if normal == 1
 [Ad,da] = gm_normaliz(A);
 cda(1)={da};
else
 cda(1)={[]};
end

err = 0;
done = 0;
alp = alpmax;
alpb = alb;
q = qmin;
nmax = size(A,1);
nnza = nnz(A);
A0 = A;

totstr = nnza;
tota = totstr;
totpt = nmax;
% exact solve if less than nmin nodes
nmin = 9;

if strcmpi(smooth,'lv')
 ialb = fix(alb);
 if ialb == 0
  ialb = 1;
 end
 if iprint == 1
  fprintf(' level for lv = %d \n',ialb')
 end
end

if strcmpi(smooth,'ch') && iprint == 1
 fprintf(' epsilon for ch = %11.4e \n',alb)
end


% -----------------------start going down the levels
l = 0;
nnold = nmax;

while done == 0
 n = size(A,1);

 if n <= nmin || l == lmax
  % we are on the coarsest level
  if iprint == 1
   fprintf('\n gm_amg_init: stop the recursion on levels \n')
   fprintf('----------------------------------------------\n\n')
  end
  lmax = l;
  if l > 1
   cAa = cA{l-1};
   % compute Cholesky decomposition of the coarsest matrix for the exact solve
   R = chol(cAa);
   cL(l) = {R};
  else
   % error if we just have one level
   err = 1;
   return
  end
  if iprint == 1
   fprintf('\n number of levels = %g \n',lmax);
  end
  % get out of the loop
  break
 end
 
 % ----------------go down the levels
 l = l + 1;
 
 % modification to truncate on all levels except the fine one
 %if l == 1
 % q = nmax;
 %else
 % q = qmin;
 %end
 
 % initialize the cell arrays on level l (ell)
 cf(l) = {[]};
 cc(l) = {[]};
 cw(l) = {[]};
 cdf(l) = {[]};
 cZ(l) = {[]};
 cD(l) = {[]};
 cP(l) = {[]};
 cA(l) = {[]};
 cM(l) = {[]};
 cL(l) = {[]};
 cZb(l) = {[]};
 cDb(l) = {[]};
 cda(l+1) = {[]};
 zb = [];
 pb = [];
 nz_of_A = nnz(A);
 
 if iprint == 1
  fprintf('\n---------------- level=%g, n = %g \n',l,n);
  fprintf(' nb of non zero entries = %g \n',nz_of_A);
 end
 
 % Construction of the smoother
 
 if strcmpi(smooth,'gs') | strcmpi(smooth,'ga')
  % Symmetric Gauss-Seidel smoother
  % gs = symmetric, ga = non symmetric
  tL = tril(A);
  tU = triu(A);
  % store the smoother
  cZ(l) = {tL};
  cD(l) = {tU};
  cZb(l)={tL};
  cDb(l)={tU};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iM = tL * diag(1 ./ diag(A)) *tL';
   M = inv(iM);
   cM(l) = {M};
  end
  nnna(l) = nz_of_A;
  nnnz(l) = nnz(tL);
  Za = tL;
  zAp = A;
  spA = A;
 
 elseif strcmpi(smooth,'ai') || strcmpi(smooth,'cg')
  % AINV smoother or preconditoner for CG smoother
  % AINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet = 0; % shift
  beta = bet * max(max(abs(A)));
  As = A + beta * speye(n);
  if abs(alp-alpb) > 1e-10
   [Za,pa,Zb,pb] = gm_ainvn4(As,alp,alpb,q);
  else
   % if alp = alpb compute only one factorization
   [Za,pa] = gm_ainvn2(As,alp,q); 
   Zb = Za;
   pb = pa;
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(Za);
  if nnz(find(pa < 0)) ~= 0
   fprintf('\n gm_amg_init: non positive definite matrix on level %d \n',l)
  end
  % store the AINV factorizations
  cZ(l) = {Za};
  cD(l) = {pa};
  cZb(l) = {Zb};
  cDb(l) = {pb};
  % compute the preconditioner M = Z P Z'
  M = Za * spdiags(pa,0,n,n) * Za';
  spA = spdiags(sqrt(pa),0,n,n);
  zAp = Za * spA;
  cM(l) = {M};
  
 elseif strcmpi(smooth,'sa')
  % SAINV smoother
  % SAINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet = 0; % shift
  beta = bet * max(max(abs(A)));
  As = A + beta * speye(n);
  if abs(alp-alpb) > 1e-10
   [Za,pa,Zb,pb] = gm_sainvn4(As,alp,alpb,q); 
  else
   % if alp = alpb compute only one factorization
   [Za,pa] = gm_sainvn2(As,alp,q); 
   Zb = Za;
   pb = pa;
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(Za);
  if nnz(find(pa < 0)) ~= 0
   fprintf('gm_amg_init: non positive definite matrix on level %d \n',l)
  end
  % store the AINV factorizations
  cZ(l) = {Za};
  cD(l) = {pa};
  cZb(l) = {Zb};
  cDb(l) = {pb};
  % compute the preconditioner M = Z P Z'
  M = Za * spdiags(pa,0,n,n) * Za';
  spA = spdiags(sqrt(pa),0,n,n);
  zAp = Za * spA;
  cM(l) = {M};
  
 elseif strcmpi(smooth,'tw')
  % Tang approximate inverse (symmetrized)
  M = gm_saitw(A,0,1);
  cM(l) = {M};
  cZ(l) = {M};
  cD(l) = {M};
  cZb(l) = {M};
  cDb(l) = {M};
  nnna(l) = nnz(A);
  nnnz(l) = nnz(M);
  Za = M;
  zAp = M;
  spA = M;
 
 elseif strcmpi(smooth,'po')
  % polynomial smoothing
  [lmi,lma] = gm_gerschgo(A);
  lmi = max(0,lmi);
  % degree of the polynomial
  degpol = 1;
  M = gm_setmcarre(degpol,lmi,lma);
  cM(l) = {M};
  cZb(l) = {lmi};
  cDb(l) = {lma};
  cZ(l) = {A};
  cD(l) = {A};
  nnna(l) = nnz(A);
  nnnz(l) = nnz(A);
  Za = A;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'ma')
  % multiplication by 2D-A
  Di = diag(diag(A));
  M = 2 * Di - A;
  cM(l) = {M};
  cZb(l) = {M};
  cDb(l) = {M};
  cZ(l) = {A};
  cD(l) = {A};
  nnna(l) = nnz(A);
  nnnz(l) = nnz(A);
  Za = A;
  zAp = A;
  spA = A;
 
 elseif strcmpi(smooth,'ic')
  % Incomplete Cholesky smoother IC(0) of a symmetric matrix
  [dd,LL] = gm_chic(A);
  ind = find(dd < 0);
  if length(ind) ~= 0
   error('gm_amg_init: Pb with incomplete factorization')
  end
  dd = 1 ./ dd;
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l) = {LL};
  cDb(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iL = inv(LL);
   M = iL' * spdiags(dd,0,n,n) * iL;
   cM(l) = {M};
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp= A;
  spA = A;
  
 elseif strcmpi(smooth,'ci')
  % Matlab incomplete Cholesky
  [R,mes] = cholinc(A,'0');
  if mes ~= 0
   error('gm_amg_init: Pb in the incomplete Cholesky factorization')
  end
  LL = R';
  cZ(l) = {LL};
  cD(l) = {speye(n)};
  cZb(l) = {LL};
  cDb(l) = {speye(n)};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iL = inv(LL);
   M = iL' * spdiags(dd,0,n,n) * iL;
   cM(l) = {M};
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp= A;
  spA = A;
  
 elseif strcmpi(smooth,'ch')
  % Incomplete Cholesky with fill IC(epsilon) of a symmetric matrix
  [dd,LL] = gm_cheps(A,alb);
  ind = find(dd < 0);
  if length(ind) ~= 0
   error('gm_amg_init: Pb with incomplete factorization')
  end
  dd = 1 ./ dd;
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l)= {LL};
  cDb(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iL = inv(LL);
   M = iL' * spdiags(dd,0,n,n) * iL;
   cM(l) = {M};
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'lv')
  % Incomplete Cholesky with levels IC(level) of a symmetric matrix
  [dd,LL] = gm_chlev(A,ialb);
  ind=find(dd < 0);
  if length(ind) ~= 0
   disp('gm_amg_init: Pb with incomplete factorization')
  end
  dd = 1 ./ dd;
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l) = {LL};
  cDb(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iL = inv(LL);
   M = iL' * spdiags(dd,0,n,n) * iL;
   cM(l) = {M};
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'sh')
  % Incomplete Cholesky of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  if iprint == 0
   [LU,bdown] = gm_miluk(A,alb,3);
  else
   [LU,bdown] = gm_miluk(A,alb,3,iprint);
  end
  LL = tril(LU);
  dd = diag(LL);
  ind = find(dd < 0);
  if length(ind) ~= 0
   disp('gm_amg_init: Pb with incomplete factorization')
  end
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l) = {LL};
  cDb(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   iL = inv(LL);
   M = iL' * spdiags(dd,0,n,n) * iL;
   cM(l) = {M};
  end
  nnna(l) = nnz(A);
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'gc')
  % CG with diagonal preconditioner smoother
  dd = 1 ./ diag(A);
  cD(l) = {dd};
  cZ(l) = {A};
  Za = A;
  cZ(l) = {Za};
  cZb(l) = {Za};
  cDb(l) = {dd};
  nnna(l) = nnz(A);
  nnnz(l) = 0;
  M = A;
  cM(l) = {A};
  zAp = A;
  spA = A;

 elseif strcmpi(smooth,'bj')
  % tridiagonal smoother
  % corresponds to Block Jacobi for a rectangular mesh
  DD = diag(diag(A,0),0) + diag(diag(A,-1),-1) + diag(diag(A,1),1);
  cD(l) = {DD};
  cZ(l) = {A};
  Za = A;
  cZ(l) = {Za};
  cZb(l) = {DD};
  cDb(l) = {DD};
  nnna(l) = nnz(A);
  nnnz(l) = 0;
  M = A;
  cM(l) = {A};
  zAp = A;
  spA = A;
 else
  error('gm_amg_init: smoother not implemented')
 end
 
 % smoothing operator (for 'wi' interpolation)
 if strcmpi(interpo,'wi')
  Sm = speye(n,n) - sparse(M * A);
 else
  Sm = speye(n,n);
 end
  
 % influence matrix
 
 if strcmpi(infl,'b')
  % same as the standard 'a' except keeps at least one element per row
  S = gm_influstb1(A,alp);
  
 elseif strcmpi(infl,'a')
  % corresponds to 'a': standard algorithm using A
  % and the strong connections defined by alpha
  S = gm_influst(A,alp);
 
 elseif strcmpi(infl,'m')
  % use the preconditioner M to define the coarse grid
  if exist('M')
   S = gm_influm(M);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end

 elseif strcmpi(infl,'mi')
  % variants of M (when there is not enough coarse nodes)
  % better to use 2 values of alpha
  if exist('M')
   S = gm_influin(M,alp);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmpi(infl,'mc')
  if exist('M')
   S = gm_influ(M,alp);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmpi(infl,'mt') || strcmpi(infl,'mu')
  if exist('M')
   S = gm_influmt(M);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmpi(infl,'z')
  % when using AINV, use Z to define the coarse grid
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   S = gm_influm(Zzt);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
   
 elseif strcmpi(infl,'zc')
  % variants of Z
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   S = gm_influ(Zzt,alp);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 elseif strcmpi(infl,'zi')
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   S = gm_influin(Zzt,alp);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 elseif strcmpi(infl,'zt') || strcmpi(infl,'zu')
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   S = gm_influmt(Zzt);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 else
  error('gm_amg_init: this influence algorithm does not exist')
 end
 
 % store the influence matrix
 cS(l) = {S};
 
 % modify the values of parameters for next level
 alp = falp * alp;
 alpb = falp * alpb;
 q = fix(alq * q);
 
 % if there is nothing in S or if Z is diagonal
 % go up one level and stop the coarsening process
 if nnz(S) == 0 || nnz(Za) == size(Za,1)
  if iprint == 1
   fprintf('\n Pb: S is empty or Z is diagonal, %d %d \n',nnz(S),nnz(Za))
  end
  % go up one level and stop
  if l == 1
   error('gm_amg_init: cannot go back on level 1')
  else
   % change the max level
   lmax = l - 1;
  end
  % need to compute the Cholesky decomposition of the corasest matrix
  cAA = cA{l-2};
  R = chol(cAA);
  cL(lmax) = {R};
  if iprint == 1
   disp(' ')
   fprintf('\n\n after correction final number of levels = %g \n',lmax);
  end
  % get out of the loop on levels
  break
 end

 % construction of  the coarse mesh

 if strcmpi(coarse,'st')
  % standard algorithm
  [f,c,w] = gm_coarsenstnew(A,S);
  
 elseif strcmpi(coarse,'cl')
  % (modified) CLJP algorithm
  [f,c,w] = gm_coarsencljp(A,S);
  
 elseif strcmpi(coarse,'pm')
  % PMIS algorithm
  [f,c,w] = gm_coarsenpmis(A,S);
  
 elseif strcmpi(coarse,'hm')
  % HMIS algorithm
  [f,c,w] = gm_coarsenhmis(A,S);
  
 elseif strcmpi(coarse,'fa')
  % (modified) CLJP algorithm
  [f,c,w] = gm_coarsenfalg(A,S);
  
 elseif strcmpi(coarse,'mz')
  % needs M to be defined by the smoother
  % standard algorithm + check of neighbours in A
  if ~exist('M')
   M = speye(n,n);
  end
  [f,c,w] = cgml_coarsenstmz(A,M,S);

 elseif strcmpi(coarse,'n1')
  % standard algorithm + add coarse nodes using Brandt's ideas
  if exist('pa')
   [f,c,w] = gm_coarsenstn1(A,S,Za,pa);
  else
   error('gm_amg_init: ZA is not defined, use (S)AINV as a smoother')
  end
  
 elseif strcmpi(coarse,'p')
  % modifed Falgout algorithm
  [f,c,w] = gm_coarsenp(A,S);
  
 elseif strcmpi(coarse,'p1')
  % variant of the preceding one
  [f,c,w] = gm_coarsenp1(A,S);
  
 elseif strcmpi(coarse,'im')
  % coarsening using the preconditioner M
  if exist('M')
   [f,c,w] = gm_coarsenstin(A,M,S);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmpi(coarse,'iz')
  % coarsening using Z from AINV
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   [f,c,w] = gm_coarsenstin(A,Zzt,S);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 elseif strcmpi(coarse,'m2')
  % my 'm2' algorithm
  if exist('M')
   [f,c,w] = gm_coarsenm2(A,S,M,alp);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 else
  error('gm_amg_init: this coarsening algorithm does not exist')
 end
 
 % permutation of the nodes
 p = [sort(f) sort(c)];
 cperm(l) = {p};
 Ap = A(p,p);
 ip = gm_invperm(p);
 ciperm(l) = {ip};
 dimf = length(f);
 dimc = length(c);
 
 % construction of the interpolation matrix
 itp = 0;
 
 if strcmpi(interpo,'st')
  % standard AMG interpolation
  weight = gm_winterp(A,S,f,c,w);
  
 elseif strcmpi(interpo,'sc')
  % Schur interpolation
  if exist('M')
   Mp = M(p,p);
   weight = -Mp(1:dimf,1:dimf) * Ap(1:dimf,dimf+1:n);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmpi(interpo,'im')
  % interpolation using the approximate inverse M
  if exist('M')
   weight = gm_wintinv(M,f,c,w);
  else
   error('gm_amg_init: M is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'iz')
  % interpolation using Z
  if exist('zAp')
   Zzt = zAp + zAp' - spA;
   weight = gm_wintinv(Zzt,f,c,w);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 elseif strcmpi(interpo,'em')
  % energy minimization interpolation (Wan and Chan like)
  itp = 1;
  prol = gm_enermin(A,f,c);
  prol = prol(p,:);
  
 elseif strcmpi(interpo,'ez')
  % energy minimization using Z (?)
  itp = 1;
  if exist('zAp')
   Zzt = zAp + zAp - spA;
   prol = gm_enermin(Zzt,f,c);
   prol = prol(p,:);
  else
   error('gm_amg_init: ZAP is not defined for this smoother')
  end
  
 elseif strcmpi(interpo,'wi')
  % Wagner like interpolation with minimization
  if exist('Sm')
   weight = gm_wagint(A,S,Sm,f,c,w);
  else
   error('gm_amg_init: SM is not defined for this smoother')
  end
  
 elseif strcmpi(interpo,'wm')
  % my algorithm (with neighbours of neighbours)
  weight = gm_wmeur(A,f,c,w);
  
 else
  error('gm_amg_init: this interpolation algorithm does not exist')
 end
 
 % store the fine and coarse nodes and the interpolation weights
 cf(l) = {f};
 cc(l) = {c};
 cw(l) = {w};
 cdf(l) = {length(f)};
 
 % interpolation (prolongation) matrix prol
 % identity on the coarse nodes
 
 if itp == 0
  
  % Jacobi improvement of interpolation?
  % this corresponds to long range interpolation
  % it increases the complexity of the coarse matrices
  jac = 0;
  if jac == 1
   Aff = Ap(1:dimf,1:dimf);
   Dff = diag(1./diag(Aff));
   Afc = Ap(1:dimf,dimf+1:end);
   njac = 1;
   for jj = 1:njac
    weight = (speye(dimf) - Dff * Aff) * weight - Dff * Afc;
   end
  end
   
  prol = [weight ; speye(dimc,dimc)];
 end
 % store the interpolation matrix
 cP(l) = {prol};
 % restriction matrix (needs to be symmetric for CG)
 res = prol';
 cR(l)={res};
 
 %spy(prol)
 %title('prol')
 %pause
 
 % construction of the coarse matrix (next level)
 % always use Galerkin
 A = res * Ap * prol;
 
 if normal ==1
  % normalize on all levels
  [A,da] = gm_normaliz(A);
 end
 
 % store the next matrix
 cA(l) = {A};
 
 if normal == 1
  % store the normalizing factor
  cda(l+1) = {da};
 end
 
 nn = length(c);
 % Do we have enough differences in the sizes of the grids?
 if (nnold - nn) / nnold <= 0.05
  if iprint == 1
   fprintf('\n not enough difference between two levels, old = %d, new = %d \n',nnold,nn)
  end
  % not enough difference of number of nodes between two consecutive levels
  % stop the recursion and solve exactly
  lmax = l;
  nnold = nn;
 else
  nnold = nn;
 end
 
end

% lmax is the number of levels
if lmax > 0
 
 % visualization of the coarse grids (only for 2D grid problems)
 % for other problems comment the next line
%  gm_plotgrids1(A0,cA,cS,cw,lmax,iprint);
 
 stockz = 0;
 stockm = 0; 
 for l = 1:lmax
  P = cP{l};
  D = cDb{l};
  A = cA{l};
  w = cw{l};
  M = cM{l};
  Z = cZb{l};
  nnzn = nnz(Z);
  nnzd = nnz(D);
  if strcmpi(smooth,'gs') || strcmpi(smooth,'po')
   nnzn = 0;
   nnzd = 0;
  end
  if strcmpi(smooth,'tw')
   nnzd = 0;
  end
  
  % viz of the AINV factor or GS or IC matrices
  %spy(z)
  
  if iprint == 1
   % statistics
   % total storage for Z and M
   stockz = stockz + nnz(Z);
   stockm = stockm + nnz(M);
   totstr = totstr + nnz(A) + nnzn + nnzd + nnz(P);
   totpt = totpt + size(A,1);
   tota = tota + nnz(A);
   fprintf('\n level %d, n = %d \n',l,size(cZ{l},1));
   fprintf(' storage A = %g, storage Z = %g \n',nnna(l),nnnz(l));
  end
 end
 
 if iprint == 1
  sgrid = totpt / nmax;
  sa = tota / nnza;
  fprintf('\n total storage = %g, /n = %g, /nnza = %g, sgrid = %g, sa = %g \n',...
   totstr,totstr/nmax,totstr/nnza,sgrid,sa);
 end
 
end

