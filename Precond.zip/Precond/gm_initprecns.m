function [D,L,U]=gm_initprecns(A,precond,tb);
%GM_INITPRECNS computes preconditioners for a non symmetric A
%
% Input:
% A = matrix
% precond = type of preconditioner
% = 'no' M = I
% = 'sc' diagonal
% = 'gs' Gauss-Seidel
% = 'ss' SSOR like
% = 'lu' Incomplete LU(0)
% = 'lm' Matlab ILU(0)
% = 'lb' block ILU
% = 'ai' approximate inverse AINV
% = 'tw' Tang and Wang approximate inverse
% = 'sh' or 'wl' ILU factorizations from V. Eijkhout
% = 'gp' given preconditioner 
% = 'gm' GMRES iterations
% tb = block size for 'lb'
%    = threshold for 'lm'
%    = [alp,q] for 'ai'
%    = nb of GMRES iter for 'gm'
% 
%
% Output: (depends on precond)
%  for incomplete factorizations 
%   L - lower triangular factor
%   U - upper triangular factor
%   D - inverse of the diagonal matrix (to multiply the rhs)
%

%
% Author G. Meurant
% july 2006
%

n = size(A,1);

switch precond
 
case 'no'
 % no preconditioning
 D = speye(n);
 L = speye(n);
 U = speye(n);
 
case 'sc'
 % diagonal preconditioning
 dd = 1 ./ diag(A);
 if sum(isinf(dd)) > 0
  error(' gm_initprecns: There are zeros on the diagonal of A')
 end
 D = spdiags(dd,0,n,n);
 L = speye(n);
 U = speye(n);
 
case 'ss'
 %  SSOR = L D^{-1} U with D diag of A
 L = tril(A);
 dd = 1 ./ diag(A);
  if sum(isinf(dd)) > 0
  error(' gm_initprecns: There are zeros on the diagonal of A')
 end
 D = spdiags(dd,0,n,n);
 U = triu(A);
 
case 'gs'
 %  Gauss-Seidel = L  with L lower part of A
 L = tril(A);
 D = speye(n);
 U = speye(n);
 
case 'lu'
 % Incomplete LU with the same structure as A
 % computes L D U with diag(L,U)=1
 % send back D^{-1}
 [d,L,U] = gm_lui(A);
 ind = find(d == 0);
 if length(ind) > 0
  error(' gm_initprecns: Pb with the incomplete factorization')
 end
 D = spdiags(1./d,0,n,n);
 
 case 'lb'
 % Incomplete block LU with the same structure as A
 % computes L D U with diag(L,U)=1
 % send back D^{-1}
 if isempty(tb)
  error('gm_initprecns: Error, the block size tb was not provided')
 end
 if rem(n,tb) ~= 0
  error('gm_initprecns: Error, the block size has to divide exactly the dimension of A')
 end
 [D,L,U,D1] = gm_luib(A,tb);
 D = D1;
 
 case 'gp'
 % given preconditioning
 D = speye(n);
 L = speye(n);
 U = speye(n);
 
 case 'ai'
  % AINV factorization, keep only the q largest elements
  alp = tb(1);
  q = tb(2);
  % use eventually a shifted matrix
  bet = 0; % shift
  beta = bet * max(max(abs(A)));
  As = A + beta * speye(n);
  [L,U,pa] = gm_ainvq_ns(As,alp,q);
  D = spdiags(pa,0,n,n);
  
 case 'tw'
  % Tang approximate inverse 
  % could eventually increase the number of levels in gm_saitw
  L = gm_saitw(A,0,1);
  U = [];
  D = [];
  
 case 'sh'
  % Incomplete factorization of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  % alb = number of levels, must be an integer
  alb = ceil(tb);
  [LU,bdown] = gm_miluk(A,alb,3);
  L = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  U = triu(LU);
  D = [];
  
 case 'wl'
  % Weighted incomplete Cholesky of Eijkhout with levels
  % IC(level) of a general matrix
  % alb must be an integer
  alb = ceil(tb);
  [LU,bdown] = gm_wiluk(A,alb);
  L = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  U = triu(LU);
  D = [];
  
 case 'lm'
  % Matlab built-in incomplete LU(0)
%   opts.droptol = tb; % use this if you want to use ilu with drop tolerance
%   opts.type = 'ilutp'; % use this if you want to use ilu with drop tolerance
%   [L,U,D] = luinc(sparse(A),opts); % old versions of Matlab
  opts.type = 'nofill';
  opts.udiag = 1;
  [L,U] = ilu(sparse(A),opts);
  D = speye(n,n);
  
 case 'ld'
  % Matlab built-in incomplete LU(droptol)
  opts.droptol = tb;
  opts.type = 'ilutp';
  %   [L,U,D] = luinc(sparse(A),opts); % old versions of Matlab
  opts.udiag = 1;
  [L,U] = ilu(sparse(A),opts);
  D = speye(n,n);
  
 case 'gm'
  D = speye(n);
  D(1,1) = tb;
  L = speye(n);
  U = speye(n);
 
 
otherwise
 error('gm_initprecns: Error, the given preconditioner does not exist')
end

