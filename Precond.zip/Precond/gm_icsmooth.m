function x = gm_icsmooth(A,L,d,b,x0,nu);
%GM_ICSMOOTH  Richardson smoothing with IC for AMG

% Input:
% A = symmetric matrix
% the preconditioner is L D^-1 L^T
% d = vector which contains the inverse of diag(D)
% x0 = starting vector
% nu = number of iterations

%
% Author G. Meurant
% Aug 2000
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 y = Lt \ (d .* z);
 x = x + y;
end

