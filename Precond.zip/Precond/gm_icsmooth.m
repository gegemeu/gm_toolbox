function x=gm_icsmooth(A,L,d,b,x0,nu);
%GM_ICSMOOTH  Richardson smoothing with IC for AMG

% nu iterations
% the preconditioner is L D^-1 L^T
% d is a vector which contains the inverse of diag(D)

%
% Author G. Meurant
% Aug 2000
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 y = Lt \ (d .* z);
 x = x + y;
end

