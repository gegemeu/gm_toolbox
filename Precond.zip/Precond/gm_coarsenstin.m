function [f,c,w]=gm_coarsenstin(A,M,S);
%GM_COARSENSTIN find the fine and coarse nodes algorithm mainly for 'im' and 'iz' interpolations 

% Input:
% A = matrix
% S = influence matrix for A

% wght computes the initial weights
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%   =-100 for coarse nodes, -50 for fine nodes

%  does not use the second pass

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

% percentage of F nodes for one C node
pf = 0.3;

f = [];
c = [];

n = size(S,1);

w = gm_wght(S);
dim = 0;

while dim < n
 % flag as Coarse the node with maximum weight
 [y,i] = max(w);
 w(i) = -100;
 % c = c U {i}
 c = [c i];
 dim = dim + 1;
 
 % flag pf per cent of the influences as F points
 % (the largest ones in the smoother M)
 ind = find(S(:,i) > 0 & w' > -50);
 lind = length(ind);
 if lind ~= 0
  [x,indx] = sort(abs(M(ind,i)));
  pff = fix(pf * lind + 1);
  indl = indx(lind-pff+1:lind)';
  indw = ind(indl);
  ind = indw;
  w(ind) = -50;
  dim = dim + length(ind);
  f = [f ind'];
  
  % find the points which influences the new F points
  % for all j in ind
  for j = ind'
   indk = find(S(:,j) >0 & w' > -50);
   % increase their value
   w(indk) = w(indk) + 1;
  end
  
  % decrease the weights of the nodes which are influenced by i
  ind = find(S(i,:) > 0 & w > -50);
  w(ind) = w(ind) - 1;
 end
end

dimf = length(f);



