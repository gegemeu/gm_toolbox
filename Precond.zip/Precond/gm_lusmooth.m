function x=gm_lusmooth(smooth,A,L,U,d,b,x0,nu);
%GM_LUSMOOTH  Richardson smoothing for 'gs', 'lu', etc...
%
% nu iterations
% the preconditioner is L d U (d is a vector)
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

x = x0;

if strcmpi(smooth,'gs') == 1
 for i = 1:nu
  y = b - A * x;
  z = L \ y;
  x = x + y;
  y = b - A * x;
  z = U \ y;
  x = x + y;
 end
 return
end

if strcmpi(smooth,'lb') == 1
 for i = 1:nu
 % residual
 y = b - A * x;
 z = L \ y;
 z = d \ z;
 y = U \ z;
 x = x + y;
 end
 return
end

if strcmpi(smooth,'sh') == 1 || strcmpi(smooth,'wl') == 1
 for i = 1:nu
 % residual
 y = b - A * x;
 z = L \ y;
 y = U \ z;
 x = x + y;
 end
 return
end

for i = 1:nu
 % residual
 y = b - A * x;
 z = (L \ y) ./ d;
 y = U \ z;
 x = x + y;
end

