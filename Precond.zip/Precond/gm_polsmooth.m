function x = gm_polsmooth(A,M,b,x0,nu,lmin,lmax);
%GM_POLSMOOTH  Richardson smoothing with polynomial preconditioner

% Input:
% A = matrix
% M = matrix 
% x0 = starting vector
% nu number of iterations

%
% Author G. Meurant
% Sept 2000
%

x = x0;

for i = 1:nu
 r = b - A * x;
 z = gm_evmcarre(A,r,M,lmin,lmax);
 x = x + z;
end

