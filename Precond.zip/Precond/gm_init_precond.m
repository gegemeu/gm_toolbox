function [cprec,cprec_amg] = gm_init_precond(A,precond,iprint,params);
%GM_INIT_PRECOND initialization of preconditioners

% Input:
% A = symmetric positive definite matrix
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
%  = 'gp' = preconditioner M given by the user
%
% iprint  = 1, printing 
%
% params = structure giving the parameter(s) needed by some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh', 'wl'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml' and 'dd'
%  = block size for block methods
%  = matrix M for 'gp'
%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%  params.tb = block size for 'mb'
%
% Output;
% cell arrays needed for the solution of M z = r

%
% Author G. Meurant
% January 2025
%

% init of preconditioners

n = size(A,1);

if nargin == 1
 precond = 'no';
 iprint = 0;
 params = [];
end % if
if nargin == 2
 iprint = 0;
 params = [];
end % if
if nargin == 3
 params = [];
end % if
ee = ones(n,1);

switch precond
 
 case 'no'
  % no preconditioning
  d = ones(n,1);
  L = speye(n);
  tb = 1;
  ldd = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'sc'
  % diagonal preconditioning
  d = diag(A);
  L = speye(n);
  tb = 1;
  ldd = max(1./sqrt(d));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case {'ss','gs'}
  %  SSOR = L D^{-1} L^T with D diag of A (omega = 1)
  L = tril(A);
  d = diag(A);
  I = find(d==0);
  if ~isempty(I)
   error('gm_init_precond: There are zeros on the diagonal of A')
  end % if
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'bc'
  % Incomplete block Cholesky
  if isempty(params)
   tb = 1;
  else
   tb = params.p1;
  end % if
  if rem(n,tb) ~= 0
   error('gm_init_precond: Error, the block size has to divide exactly the dimension of A')
  end
  [d,L,d1] = gm_icb(A,tb);
  if iprint == 1
   fprintf('  bc, block size = %g \n',tb)
  end % if
  ldd = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'ic'
  % Incomplete point Cholesky with the same structure as A
  % computes L D L^T with diag(L) = 1
  % send back D^{-1}
  B = A;
  L = sparse(n,n);
  for k = 1:n-1
   m = size(B,1);
   b1 = 1 / B(1,1);
   i = find(A(k:n,k));
   sl = sparse(i,1,B(i,1)*b1,m,1);
   L(k:n,k) = sl;
   L(k,k) = 1;
   d(k) = B(1,1);
   % Schur complement
   ind = i(2:end)-1;
   sl = sl(2:m);
   BB = B(2:m,2:m);
   % do not take care of symmetry (faster)
   for i = ind
    BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
   end % for i
   B = BB;
  end % fork
  L(n,n) = 1;
  d(n) = B(1,1);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the incomplete factorization, negative diagonal entries')
  end % if
  d = d';
  d1 = sqrt(d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  % to avoid divisions in the solve
  d = 1 ./ d;
  tb = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'ch'
  % Incomplete point Cholesky keeping some fill-in
  % same kind of factorization as the previous one
  if isempty(params)
   epsdrop = 0.01;
  else
   epsdrop = params.p1;
  end % if
  if iprint == 1
   fprintf('  ch, epsi = %g \n',epsdrop)
  end % if
  B = A;
  L = sparse(n,n);
  % norm of each row of A
  anorm = zeros(1,n);
  for i=1:n
   anorm(i) = norm(A(i,:),inf);
  end % for i
  for k = 1:n-1
   m = size(B,1);
   b1 = 1 / B(1,1);
   ii = find(B(:,1));
   sl = sparse(ii,1,B(ii,1)*b1,m,1);
   L(k:n,k) = sl;
   % dropping strategy
   i = find(abs(L(k+1:n,k)) ./ anorm(k+1:n)' <= epsdrop);
   L(i+k,k) = zeros(length(i),1);
   L(k,k) = 1;
   d(k) = B(1,1);
   % Schur complement
   ind = find(L(k+1:n,k))';
   sl = sl(2:m);
   BB = B(2:m,2:m);
   for i = ind
    BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
   end % for i
   B = BB;
  end % for k
  L(n,n) = 1;
  d(n) = B(1,1);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the incomplete factorization, negative diagonal entries')
  end % if
  d = d';
  d1 = sqrt(d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  d = 1 ./ d;
  tb = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'lv'
  % Incomplete point Cholesky with levels
  % same kind of factorization as the previous ones
  % this does not work as it should, see 'll' below
  if isempty(params)
   levmax = 1;
  else
   levmax = params.p1;
  end % if
  if iprint == 1
   fprintf('  lv, level max = %g \n',levmax)
  end % if
  B = A;
  L = sparse(n,n);
  Lev = sparse(n,n);
  levm = 100;
  Lev = spones(A);
  for k = 1:n-1
   m = size(B,1);
   b1 = 1 / B(1,1);
   ii = find(B(:,1));
   sl = sparse(ii,1,B(ii,1)*b1,m,1);
   L(k:n,k) = sl;
   % dropping strategy
   i = find(Lev(2:end,1) > levmax);
   L(i+k,k) = zeros(length(i),1);
   Lev(i+1,1) = levm * ones(length(i),1);
   L(k,k) = 1;
   d(k) = B(1,1);
   % Schur complement
   Level = Lev;
   ind = find(L(k+1:n,k))';
   sl = sl(2:m);
   BB = B(2:m,2:m);
   Lev = Level(2:m,2:m);
   % do not take care of symmetry (faster)
   for i = ind
    BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
    j = find(B(i+1,:) ~= 0) - 1;
    indj = gm_fmt(ind,j);
    ll = Level(i+1,1);
    Lev(i,indj) = ll + Level(indj+1,1)';
   end % for i
   B = BB;
  end % for k
  L(n,n) = 1;
  d(n) = B(1,1);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the incomplete factorization, negative diagonal entries')
  end % if
  d = d'; d1 = sqrt(d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  d = 1 ./ d;
  tb = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'll'
  % Incomplete point Cholesky with levels
  % same kind of factorization as the previous one
  if isempty(params)
   levmax = 1;
  else
   levmax = params.p1;
  end % if
  if iprint == 1
   fprintf('  ll, level max = %g \n',levmax)
  end % if
  B = A;
  n = size(A,1);
  L = sparse(n,n);
  Lev = Inf * ones(n,n);
  for i = 1:n
   for j = 1:n
    if A(i,j) ~= 0
     Lev(i,j) = 1;
    end % if
   end % for j
  end % for i
  d = zeros(n,1);
  for k = 1:n-1
   m = size(B,1);
   b1 = 1 / B(1,1);
   ii = find(B(:,1));
   sl = sparse(ii,1,B(ii,1)*b1,m,1);
   L(k:n,k) = sl;
   % dropping strategy
   i = find(Lev(2:end,1) > levmax);
   L(i+k,k) = zeros(length(i),1);
   L(k,k) = 1;
   d(k) = B(1,1);
   % Schur complement
   ind = find(L(k+1:n,k))';
   sl = sl(2:m);
   for i = 1:m
    for j = 1:m
     Lev(i,j) = min(Lev(i,j), Lev(i,1) + Lev(1,j) + 1);
    end % for j
   end % for j
   BB = B(2:m,2:m);
   Lev = Lev(2:m,2:m);
   % do not take care of symmetry (faster)
   for i = ind
    BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
   end % for i
   B = BB;
  end % for k
  L(n,n) = 1;
  d(n) = B(1,1);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the incomplete factorization, negative diagonal entries')
  end
  d = d; % ?????
  d1 = sqrt(d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  d = 1 ./ d;
  tb = 1;
  cprec = {d, L, tb};
  cprec_amg = {};
  
 case 'sh'
  % Incomplete point Cholesky of Manteuffel (Eijkhout) with levels
  % L inv(D) L^T with diag(L)=D
  % something wrong????
  if isempty(params)
   levmax = 1;
  else
   levmax = params.p1;
  end % if
  if iprint == 1
   fprintf('  sh, level max = %g \n',levmax)
  end % if
  if iprint >= 1
   [LU,bdown] = gm_miluk(A,levmax,3,iprint);
  else
   [LU,bdown] = gm_miluk(A,levmax,3);
  end % if
  L = tril(LU);
  d = diag(L);
  ind = find(d <= 0);
  if length(ind) > 0 && iprint >= 1
   fprintf('\n gm_init_precond: Pb with the incomplete factorization, negative diagonal entries \n')
  end % if
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);;
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'wl'
  % Weighted incomplete Cholesky of Eijkhout with levels
  % IC(level) of a general matrix
  % alb must be an integer
  if isempty(params)
   alb = 1;
  else
   alb = params.p1;
  end % if
  if iprint == 1
   fprintf('  wl, level max = %g \n',alb)
  end % if
  alb = ceil(alb);
  [LU,bdown] = gm_wiluk(A,alb);
  L = tril(LU);
  d = diag(L);
  ind = find(d <= 0);
  if length(ind) > 0 && iprint >= 1
   fprintf('\n gm_init_precond: Pb with the incomplete factorization, negative diagonal entries \n')
  end % if
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'ci'
  %  [R,mes] = cholinc(A,'0');
  opts.type = 'nofill';
  opts.shape = 'upper';
  R = ichol(sparse(A),opts);
  L = R';
  d = diag(L);
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'ce'
  if isempty(params)
   p1 = 0.01;
   lparams = 0;
  else
   lparams = length(fieldnames(params));
   if lparams > 1
    p1 = params.p1;
    p2 = params.p2;
   else
    p1 = params.p1;
   end % if
  end % if
  if iprint == 1
   fprintf('  ce, ic threshold = %g \n',p1)
  end % if
  opts.type = 'ict';
  opts.shape = 'upper';
  if lparams > 1
   opts.droptol = p1;
   opts.diagcomp = p2;
  else
   opts.droptol = p1;
  end % if
  R = ichol(sparse(A),opts);
  L = R';
  d = diag(L);
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 's3' % this is just for s3dkt3m2
  opts.type = 'ict';
  opts.diagcomp = 1e-2;
  opts.droptol = 1e-5;
  opts.shape = 'upper';
  R = ichol(sparse(A),opts);
  L = R';
  d = diag(L);
  tb = 1;
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  w = Ls \ ee;
  ldd = max(abs(w));
  cprec = {d, L, tb};
  cprec_amg = {};
  
 case 'po'
  % least squares polynomial of degree k
  if isempty(params)
   k = 1;
  else
   k = params.p1;
  end % if
  if iprint == 1
   fprintf('  po, polynomial degree = %g \n',k)
  end % if
  % compute the Gerschgorin bounds
  un = ones(n,1);
  AA = abs(A);
  DA = spdiags(diag(AA),0,n,n);
  % put zeros on the diagonal
  AA = spdiags(zeros(n,1),0,AA);
  b = (DA - AA) * un;
  bb = (DA + AA) * un;
  lmin = min(b);
  lmax = max(bb);
  s = zeros(k+2,1);
  mu0 = -(lmin + lmax) / (lmax - lmin);
  s(1) = 1 / sqrt(pi);
  s(2) = sqrt(2 / pi) * (lmin + lmax) / (lmin - lmax);
  s(3) = sqrt(2 / pi) * ((2 * (lmin + lmax)^2 / (lmin - lmax)^2) - 1);
  for j = 4:k+2
   s(j) = 2 * mu0 * s(j-1) - s(j-2);
  end % for j
  d = s;
  d(k+3) = lmin;
  d(k+4) = lmax;
  L = [];
  ldd = 1;
  cprec = {d, L, k, ldd};
  cprec_amg = {};
  
 case 'ai'
  % AINV approximate inverse of Benzi and Tuma
  if isempty(params)
   tau = 0.01;
  else
   tau = params.p1;
  end % if
  if iprint == 1
   fprintf('  ai, alpha = %g \n',tau)
  end % if
  [L,d] = gm_ainv(A,tau);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the AINV approximate inverse, negative diagonal entries, try SAINV')
  end % if
  tb = 1;
  dd = sqrt(d);
  Ls = L * spdiags(dd,0,n,n);
  ldd = norm(Ls,inf);
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'a2'
  % AINV approximate inverse of Benzi and Tuma with a max number of entries
  if isempty(params)
   tau = 0.01;
   q = 10;
  else
   tau = params.p1;
   q = params.p2;
  end % if
  if iprint == 1
   fprintf('  a2, alpha = %g, q = %d \n',tau,q)
  end % if
  [L,d] = gm_ainvn2(A,tau,q);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the AINV approximate inverse, negative diagonal entries, try SAINV')
  end % if
  tb = 1;
  dd = sqrt(d);
  Ls = L * spdiags(dd,0,n,n);
  ldd = norm(Ls,inf);
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'sa'
  % SAINV approximate inverse of Benzi and Tuma
  if isempty(params)
   tau = 0.01;
  else
   tau = params.p1;
  end % if
  if iprint == 1
   fprintf('  sa, alpha = %g \n',tau)
  end % if
  [L,d] = gm_sainv(A,tau);
  ind = find(d <= 0);
  if length(ind) > 0
   error('gm_init_precond: Pb with the SAINV approximate inverse, negative diagonal entries')
  end
  tb = 1;
  dd = sqrt(d);
  Ls = L * spdiags(dd,0,n,n);
  ldd = norm(Ls,inf);
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'tw'
  % Tang and Wan approximate inverse
  if isempty(params)
   k = 0;
   l = 1;
  else
   k = params.p1;
   l = params.p2;
  end % if
  L = gm_saitws(A,k,l);
  d = ones(n,1);
  tb = 1;
  ldd = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'sp'
  % SPAI approximate inverse symmetrized
  % this may not be positive definite
  % epss = ceil(nnz(A) / n);
  if isempty(params)
   epss = 0.01;
   nzk = min(10,n);
  else
   epss = params.p1;
   nzk = params.p2;
  end % if
  if iprint == 1
   fprintf('  sp, epss = %g, nzk = % d \n',epss,nzk)
  end % if
  L = gm_SPAI(A,epss,nzk);
  L = (L + L') / 2; % symmetrization
  d = [];
  tb = 1;
  ldd = 1;
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'fs'
  % FSAI factorized approximate inverse
  if isempty(params)
   m = 2;
  else
   m = params.p1;
  end % if
  if iprint == 1
   fprintf('  fs, power = %d \n',m)
  end % if
  S = speye(n,n);
  for k = 1:m
   S = S * A;
  end % for
  S = tril(S);
  G = gm_FSAI_S(A,S);
  L = G * G';
  d = [];
  tb = 1;
  ldd = norm(G,inf);
  cprec = {d, L, tb, ldd};
  cprec_amg = {};
  
 case 'gp'
  % matrix given by the user
  if isempty(params)
   error('gm_init_precond: There must be a matrix')
  end % if
  dd = [];
  L = params.p1;
  if size(L,1) ~= n
   error('gm_init_precond: Error, M has to be of the same order as A')
  end % if
  tb = 1;
  ldd = 1;
  cprec = {dd, L, tb, ldd};
  cprec_amg = {};
  
 case {'ml', 'mb'}
  % algebraic multigrid
  if isempty(params)
   % defaults for AMG
   lmax = 10;
   nu = 1;
   alpmax = 0.1;
   alb = 0.1;
   smooth = 'gs';
   infl = 'b';
   coarse = 'st';
   interpo = 'st';
   qmin = n;
   falp = 1;
   alq = 1;
   normal = 0;
   if strcmpi(precond,'mb') ~= 1
    tb = 2;
   end % if
   gama = 1;
   xin = zeros(n,1);
   
  else
   % get the input parameters for the multilevel AMG method
   if length(fieldnames(params)) < 8
    error('gm_init_precond: Some parameters are not defined for ML')
   end
   
   if strcmpi(precond,'mb') == 1
    tb = params.tb;
   end % if
   if isfield(params,'lmax')
    lmax = params.lmax;
   else
    lmax = 10;
   end % if
   if isfield(params,'nu')
    nu = params.nu;
   else
    nu = 1;
   end % if
   if isfield(params,'alpmax')
    alpmax = params.alpmax;
   else
    alpmax = 0.1;
   end % if
   if isfield(params,'alb')
    alb = params.alb;
   else
    alb = 0.1;
   end % if
   if isfield(params,'smooth')
    smooth = params.smooth;
   else
    smooth = 'gs';
   end % if
   if isfield(params,'infl')
    infl = params.infl;
   else
    infl = 'b';
   end % if
   if isfield(params,'coarse')
    coarse = params.coarse;
   else
    coarse = 'st';
   end % if
   if isfield(params,'interpo')
    interpo = params.interpo;
   else
    interpo = 'st';
   end % if
   if isfield(params,'qmin')
    qmin = params.qmin;
   else
    qmin = n;
   end % if
   gama = 1;
   falp = 1;
   alq = 1;
   normal = 0;
   xin = zeros(n,1);
   
  end % if
  
  if iprint == 1
   fprintf('\n -----------multilevel parameters \n')
   fprintf(' lmax = %d \n',lmax)
   fprintf(' nu = %d \n',nu)
   fprintf(' alpmax = %g \n',alpmax)
   fprintf(' alb = %g \n',alb)
   fprintf(' smooth = %s \n',smooth)
   fprintf(' infl = %s \n',infl)
   fprintf(' coarse = %s \n',coarse)
   fprintf(' interpo = %s \n',interpo)
   if gama == 1
    fprintf(' V-cycle \n')
   else
    fprintf(' W-cycle \n')
   end % if
  end % if
  
  if strcmpi(precond,'ml') == 1
   % multilevel preconditioner
   [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_init(A,alpmax,alb,lmax,falp,qmin,alq,...
    smooth,infl,coarse,interpo,normal,iprint);
   if err == 1
    fprintf('\n gm_init_precond: Error in gm_amg_init \n')
    return
   end % if
   tb = 1;
   ldd = 1;
   cprec = {};
   cprec_amg  = {xin, nu, 1, cA, cM, cP, cR, cperm, ciperm, cdf, cZb, cDb, cL, cda, lmax, smooth, gama, normal, tb, ldd};
   
  elseif strcmpi(precond,'mb') == 1
   % multilevel block preconditioner
   [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_initb(A,alpmax,alb,lmax,falp,qmin,alq,...
    smooth,infl,coarse,interpo,normal,tb,iprint);
   if err == 1
    error('gm_gm_init_precond: Error in gm_amg_initb')
   end % if
   ldd = 1;
   cprec = {};
   cprec_amg = {xin, nu, 1, cA, cM, cP, cR, cperm, ciperm, cdf, cZb, cDb, cL, cda, lmax, smooth, gama, normal, tb, ldd};
   
  end % if
  
 otherwise
  error('gm_init_precond: This preconditioner does not exist')
  
  
end % switch


