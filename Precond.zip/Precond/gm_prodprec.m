function z=gm_prodprec(r,A,d,L,precond,param);
%GM_PRODPREC computes z = M r
%
% A matrix
% d and L computed by gm_initprec
% precond - type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal (scaling)
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'bc' block Incomplete Cholesky

% param - parameter needed by some preconditioners
% = nothing for 'no' and 'ic'
% = epsilon for 'ch' or 'ce'
% = level for 'lv'
% = degree of polynomial for 'po'
% = tau for 'ai'
% = nothing for 'tw'
% = number of levels for 'ml'
%
%
% output
% z - solution of M z = r

%
% Author G. Meurant
% December 2016
%

switch precond
 case 'no'
  z = r;
  
 case 'sc'
  z = r.* d;
  
 case {'ic','ch','lv','ss','sh','gs','wl'}
  y = L' * r;
  z = L * (y ./ d);
  
 case 'bc'
  % in this case d is a matrix
  y = L' * r;
  z = L * (d * y);
  
 case 'tw'
  z = L \ r;
  
 case 'gp'
  z = L * r;
  
 case 'po'
  % does not work!
  z = r;
  
 case {'ai','sa'}
  y = L \ r;
  z = L' * (y ./ d);
  
 case {'ci','ce'}
  y = L' * r;
  z = L * y;
  
 otherwise
  z = r;
  
end


