function S=gm_influstbl(A,alp,tb);
%GM_INFLUSTBL block influence matrix of A

% tb is the block size
% computes a sparse matrix S (order n/tb) of ones where
% ||A(I,J)||_F >= alp * max_K ||A(I,K)||_F, I,J,K are block indices

%
% author G. Meurant
% Aug 2006
%
 
A = gm_normfrob1(A,tb);
maxs = max(abs(A'))';
A = A - diag(diag(A));

if nnz(A) == 0
 fprintf('\n gm_iniflustbl: normfrob(A) is block diagonal \n')
 S = spones(A);
 return
end

n = size(A,1);
S = sparse(n,n);

for i = 1:n
 ind = find(abs(A(i,:)) >= alp * maxs(i));
 if length(ind) == 0 
  [y,j] = max(abs(A(i,:)));
  if y > 0
   ind = j;
  else
   ind = [];
  end
 end
 if length(ind) > 0
  S(i,ind) = spones(ind);
 end
end

if nnz(S) == 0
 error('gm_influstbl: S is empty!')
end


 
