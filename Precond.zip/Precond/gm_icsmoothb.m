function x = gm_icsmoothb(A,L,D,b,x0,nu);
%GM_ICSMOOTHB  Richardson smoothing with block IC

% Input:
% A = symmetric matrix
% the preconditioner is L D L^T
% d = vector which contains the inverse of diag(D)
% x0 = starting vector
% nu = number of iterations

%
% Author G. Meurant
% Aug 2006
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 zz = D \ z;
 y = Lt \ zz;
 x = x + y;
end

