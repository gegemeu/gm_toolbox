function x=gm_icsmoothb(A,L,D,b,x0,nu);
%GM_ICSMOOTHB  Richardson smoothing with block IC

% nu iterations
% the preconditioner is L D L^T

%
% Author G. Meurant
% Aug 2006
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 zz = D \ z;
 y = Lt \ zz;
 x = x + y;
end

