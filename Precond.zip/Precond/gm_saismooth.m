function x = gm_saismooth(A,M,b,x0,nu);
%GM_SAISMOOTH SAI Richardson smoothing for AMG

% Input:
% A = symmetric matrix
% M = inverse of a preconditioner
% x0 = starting vector
% nu = number of iterations
%
% Output:
% x = result of the smoothing

%
% Author G. Meurant
% Sept 2000
%

x = x0;

for i = 1:nu
 x = x + M * (b - A * x);
end

