function x=gm_saismooth(A,M,b,x0,nu);
%GM_SAISMOOTH SAI Richardson smoothing for AMG

% nu iterations
% the preconditioner is M 
% M computed by an approximate inverse routine

%
% Author G. Meurant
% Sept 2000
%

x = x0;

for i = 1:nu
 x = x + M * (b - A * x);
end

