function M = gm_saitw(A,k,l);
%GM_SAITW  sparse approximate inverse of A by Tang ang Wan

% Input:
% A = matrix
% k and l defines the neighboring sets that are used for solving the least squares problems

%
% Author G. Meurant
% Sept 2000
% Updated March 2015
%

n = size(A,1);
M = sparse(n,n);

% solve a least squares problem for each row of M
for i = 1:n
 % compute the neighboring sets of degree k and l
 indk = gm_neighbset(A,i,k);
 indl = gm_neighbset(A,i,l);
 
 % extract the matrix
 Akl = A(indk,indl);
 Aklt = Akl';
 se = size(Aklt,1);
 
 % rhs zero everywhere except for i
 rhs = zeros(se,1);
 ii = find( indl == i);
 rhs(ii) = 1;
 
 % solve the normal equation to solve the least squares problems
 Mi = (Akl * Aklt) \ (Akl * rhs);
 % this is line i of the approximate inverse
 M(i,indk) = Mi';
end

% % symmetrize in gm_saitws
% M = 0.5 * (M + M');
