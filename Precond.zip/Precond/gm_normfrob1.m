function Af=gm_normfrob1(A,tb);
%GM_NORMFROB1 returns the matrix of the Frobenius norms of the blocks of A

% the blocks are square of order tb

%
% Author G. Meurant
% August 2006
%
 
n = size(A,1);
% number of blocks
ntb = n / tb;
Af = sparse(ntb,ntb);
% square of the elements of A
AA = A.^2;
Acol = sparse(n,ntb);
% sum of AA by columns, tb columns each time
for j = 1:tb
Acol(:,1:ntb) = Acol(:,1:ntb) + AA(:,j:tb:n-tb+j);
end

Arow = sparse(ntb,ntb);
% sum of Acol by rows, tb rows each time
for i = 1:tb
 Arow(1:ntb,:) = Arow(1:ntb,:) + Acol(i:tb:n-tb+i,:);
end
Af = sqrt(Arow);
 
