function [L,d]=gm_ic(A);
%GM_IC Incomplete point Cholesky factorization with the same structure as A
% IC(0)
 % computes L D L^T with diag(L) = 1

 %
 % Author G. Meurant
 % May 2015
 %
 
 B = A;
 n = size(A,1);
 L = sparse(n,n);
 d = zeros(n,1);
 
 for k = 1:n-1
  m = size(B,1);
  b1 = 1 / B(1,1);
  i = find(A(k:n,k));
  sl = sparse(i,1,B(i,1)*b1,m,1);
  L(k:n,k) = sl;
  L(k,k) = 1;
  d(k) = B(1,1);
  % Schur complement
  ind = i(2:end)-1;
  sl = sl(2:m);
  BB = B(2:m,2:m);
  % do not take care of symmetry (faster)
  for i = ind
   BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
  end
  B = BB;
 end
 L(n,n) = 1;
 d(n) = B(1,1);
 
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the incomplete factorization, negative diagonal entries')
 end
 
 