function Weight = gm_wintinv(M,f,c,w);
%GM_WINTINV computes the interpolation weights using AINV interpolation

% Input:
% M = approximate inverse or the factors
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%  =-100 for coarse nodes, -50 for fine nodes

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

n = size(M,1);

d = zeros(n,1);
Weight = sparse(n,n);

for ii = 1:length(f)
 i = f(ii);
 % find the coarse neighbours in m c_i, neighbours indi
 [ci,indi] = gm_coarsno(M,w,i);
 if length(ci) == 0
  error('gm_wintinv: no coarse neighbour in M')
 end
 
 % compute the sum of the entries for the coarse neighbours
 if length(ci) > 1
  d(i) = sum(abs(M(i,ci)));
  Weight(i,ci) = abs(M(i,ci)) / d(i);
 elseif length(ci) == 1
  Weight(i,ci) = abs(M(i,ci));
 end
end

Weight = sparse(Weight);
p = [sort(f) sort(c)];
dimf = length(f);
Wp = Weight(p,p);
Weight = Wp(1:dimf,dimf+1:n);


