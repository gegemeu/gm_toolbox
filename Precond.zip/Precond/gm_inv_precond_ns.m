function Mi = gm_inv_precond_ns(A,precond,cprec);
%GM_INV_PRECOND_NS inverse of a non symmetric preconditioner

% Input:
% A = matrix
% precond - type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'gs' Gauss-Seidel
%  = 'ss' SSOR like with omega=1
%  = 'lu' Incomplete LU(0)
%  = 'lm' Matlab ILU(0)
%  = 'ld' Matlab ILU with drop threshold
%  = 'lb' block ILU
%  = 'ai' approximate inverse AINV
%  = 'tw' Tang and Wang approximate inverse
%  = 'sp' SPAI approximate inverse (Huckle and Grote)
%  = 'sh' or 'wl' ILU factorizations from V. Eijkhout
%  = 'gp' given preconditioner 

% cprec = cell array coming from gm_init_precond
%
%
% Output:
% Mi = inverse of the preconditioner M

%
% Author G. Meurant
% February 2025
%

if ~isempty(cprec)
 D = cprec{1};
 L = cprec{2};
 U = cprec{3};
end % if

n = size(A,1);

switch precond
 case 'no'
  Mi = speye(n,n);
  
 case 'sc'
  Mi = D;
  
 case {'ss', 'lu', 'gs', 'lb'};
  Mi = inv(U) * D * inv(L);
  
 case  'gp'
  Mi = inv(L);
  
 case 'ai'
  Mi = L * D * U;
  
 case {'tw', 'sp'}
  Mi = L;
  
 case {'sh', 'wl'}
  Mi = inv(U) * inv(L);
  
 case {'lm', 'ld'}
  Mi = inv(U) * D * inv(L);
  
 otherwise
  error('gm_inv_precond_ns: No inverse for this preconditioner')
  
end % switch



