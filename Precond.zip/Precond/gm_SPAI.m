function M = gm_SPAI(A,epss,nzk);
%GM_SPAI Huckle and Grote approximate inverse

% Caution: M is nonsymmetric, even if A is symmetric

% Input:
% A = matrix
% epss = threshold for the residual norms
% nzk = maximum number of nonzero entries in a column of M
%
% Output:
% M = approximate inverse

%
% Author G. Meurant
% December 2024
%

n = size(A,1);

% Defaults
if nargin == 2
 nzk = min(10,n);
elseif nargin == 1
 epss = 0.001;
 nzk = min(10,n);
end % if

warning('off')

J = A;
% J = eye(n,n);
% I = eye(n); % this does not always work
I = A; % this may be too much
M = zeros(n,n);
nza = nnz(A) / n;
nzk = max(nzk,nza);
% find the indices of nonzero entries in rows and columns of A
[rowpA,colindA] = gm_sparse_2_csr(A);
[rowpAt,colindAt] = gm_sparse_2_csr(A');

n2j = zeros(1,n);
for j = 1:n
 n2j(j) = norm(full(A(:,j)));
end % for j

for k = 1:n
 % computation of kth column of M
 ek = I(:,k);
 Jk = find(J(:,k));
 nrk = realmax;
 nit = 0;
 nitmax = 10;
 
 % Construct set Ik
 Ipp = [];
 for jj = 1:length(Jk)
  j = Jk(jj);
  Ipp = [Ipp colindAt(rowpAt(j):rowpAt(j+1)-1)];
 end % for jj
 Ik = unique(Ipp);
 
 Atk = A(Ik,Jk); % submatrix
 etk = ek(Ik);
 % solve of least squares problem
 [Qt,Rt] = qr(Atk,0);
 Mtk = Rt \ (Qt' * etk);
 if any(isinf(Mtk))
  error('gm_SPAI: Some entries are infinite')
 end % if
 M(Jk,k) = Mtk;
 rtk = ek - A(:,Jk) * Mtk; % residual
 nrk = norm(rtk);
 
 while length(Jk) < nzk && nrk > epss && nit <= nitmax
  nit = nit + 1;
  
  % Construct index set Lk
  Lk = find(rtk);
  Jtk = [];
  ind = [];
  for ll = 1:length(Lk)
   l = Lk(ll);
   ind = [ind colindA(rowpA(l):rowpA(l+1)-1)];
  end % for ll
  Jtk = union(Jtk,ind);
  Jtk = setdiff(Jtk,Jk);
  
  jro = [];
  roj = zeros(1,length(Jtk));
  for jj = 1:length(Jtk)
   j = Jtk(jj);
   jro = [jro j];
   % residual norm
   roj(jj) = sqrt(abs((nrk^2 - ((rtk' * A(:,j))^2 / n2j(j)^2))));
  end % for jj
  lIk = length(Ik);
  [~,II] = sort(roj,'ascend');
  mjk = 5; % number of candidates
  Jp = jro(II(1:min(length(II),mjk)));
  Ip = [];
  for jj = 1:length(Jp)
   j = Jp(jj);
   Ipp = colindAt(rowpAt(j):rowpAt(j+1)-1);
   if lIk + length(Ipp) > nzk
    diff = lIk + length(Ipp) - nzk;
    Ipp = Ipp(1:length(Ipp)-diff);
   end % if
   Ip = union(Ip,Ipp);
  end % for jj
  Ik = union(Ik,Ip);
  Jk = union(Jk,Jp);
  
  Atk = A(Ik,Jk); % submatrix
  etk = ek(Ik);
  % solve of least squares problem
  [Qt,Rt] = qr(Atk,0);
  Mtk = Rt \ (Qt' * etk);
  if any(isinf(Mtk))
   error('gm_SPAI: Some entries are infinite')
  end % if
  M(Jk,k) = Mtk;
  rtk = ek - A(:,Jk) * Mtk; % residual
  nrk = norm(rtk);
  
 end % while
end % for k

M = sparse(M);

warning('on')






