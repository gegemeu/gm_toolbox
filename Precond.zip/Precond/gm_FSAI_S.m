function G = gm_FSAI_S(A,S);
%GM_FSAI_S factorized approximate inverse, symmetric case

% Input:
% A = symmetric positive definite matrix
% S = lower triangular sparse matrix giving the nonzero pattern of G
%
% Output:
% G = lower trinagular matrix
%  the approximate inverse is G G^T

%
% Author G. Meurant
% December 2024
%

n = size(A,1);
G = zeros(n,n);
% find the nonzero entries in rows of S
[rowpS,colindS] = gm_sparse_2_csr(S);

G(1,1) = 1 / sqrt(A(1,1));

for k = 2:n
 Ik = colindS(rowpS(k):rowpS(k+1)-1);
 nzk = length(Ik);
 Ak = A(Ik,Ik);
 ek = zeros(nzk,1);
 ek(nzk) = 1;
 gkk = Ak \ ek;
 gk = (gkk / sqrt(abs(gkk(nzk))))';
 G(k,Ik) = gk;
end % for k

G = sparse(G);

