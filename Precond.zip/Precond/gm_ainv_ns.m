function [Z,Wt,p]=gm_ainv_ns(A,epss);
%GM_AINV_NS sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
% M = Z D^{-1} W', Z and W upper triangular
% returns Z, W' and inv(D)
%

%
% Author G. Meurant
% 1999
% Updated April 2015
%

n = size(A,1);

Z = speye(n,n);
W = speye(n,n);
p = zeros(n,1);
q = zeros(n,1);

anorm = epss * max(abs(A'))';

for i = 1:n-1
 
 x = abs(Z(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Z(ind,i) = 0;
 end % if
 x = abs(W(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  W(ind,i) = 0;
 end % if
 
 % diagonal entries
 p(i:n) = A(i,:) * Z(:,i:n);
 p1 = 1 / p(i);
 q(i:n) = A(:,i)' * W(:,i:n);
 q1 = 1 / q(i);
 
 indp = find(abs(p(i+1:n)) > 0) + i;
 % update of column j>i of Z by column i
 for j = indp'
  Z(:,j) = Z(:,j) - p(j) * p1 * Z(:,i);
 end % for j
 
 indq = find(abs(q(i+1:n)) > 0) + i;
 % update of column j>i of W by column i
 for j = indq'
  W(:,j) = W(:,j) - q(j) * q1 * W(:,i);
 end % for j
 
end % for i

% last column of Z and W
for j = 1:n-1
 x = abs(Z(j,n));
 if x < anorm(j) & x > 0
% drop some entries
  Z(j,n) = 0;
 end % if
 x = abs(W(j,n));
 if x < anorm(j) & x > 0
% drop some entries
  W(j,n) = 0;
 end % if
end % for j

% last diagonal entry
p(n) = A(n,:) * Z(:,n);

% return the inverse of the diagonal
p = 1 ./ p;

Wt = W';


