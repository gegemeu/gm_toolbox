function [f,c,w]=gm_coarsenp1(A,S);
%GM_COARSENP1 Variant of the parallel LLNL coarsening algorithm  (Falgout & consort)

% S is an influence matrix 
% flag as a fine point when weight = 1
% refuse C-C connections

%
% Author G. Meurant
% Aug 2000
%

f = [];
c = [];
n = size(S,1);
w = gm_wght(S);
dim = 0;
SS = S;

while dim < n
 % flag as Coarse the node with maximum weight
 [y,i] = max(w);
 ind = find(SS(i,:) > 0 & w == -100);
 
 % check if this introduces a C-C connection
 if length(ind) ~= 0
  % decrease and skip
  w(i) = w(i) - 1;
 else
  % C = C U i
  w(i) = -100;
  c = [c i];
  dim = dim + 1;
  
  % P5 
  ind = find(S(i,:) > 0 & w > -50);
  w(ind) = w(ind) - 1;
  S(i,ind) = zeros(1,length(ind));
  
  % P6
  ind = find(S(:,i) > 0 & w' > -50);
  for j = ind'
   S(j,i) = 0;
   indk = find(S(:,j) > 0 & w' > -50);
   for k = indk'
    if S(k,i) ~= 0
     w(j) = w(j) - 1;
     S(k,j) = 0;
    end
   end
  end
 end
 
 % if w = 1 flag as a fine node
 indw = find(w <= 1 & w > -50);
 w(indw) = -50;
 f = [f indw];
 dim = dim + length(indw);
end

% check if all F points have a C point in s
for i = f
 [ci,indi] = gm_coarsno(SS,w,i);
 if length(ci) == 0
  % flag i as a C node and exit
  f = gm_setdiff(f,[i]);
  c = [c i];
  w(i) = -100;
 end
end


