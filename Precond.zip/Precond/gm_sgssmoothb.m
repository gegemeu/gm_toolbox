function x=gm_sgssmoothb(A,Dl,b,x0,nu,tb);
%GM_SGSSMOOTHB Symmetric block Gauss-Seidel smoothing 

% nu iterations starting from x0
% Dl contains the block lower triangular part of A
% tb block size

%
% Author G. Meurant
% Aug 2006
%

x = x0;
Lt = A - Dl;
Dlt = Dl';
L = Lt';

for i = 1:nu
 x = Dl \ (b - Lt * x);
 x = Dlt \ (b - L * x);
end


