function Weight = gm_wmeur(A,f,c,w);
%GM_WMEUR computes the interpolation weights, Meurant's algorithm

% Input:
% A = matrix
% S = influence matrix
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%  =-100 for coarse nodes, -50 for fine nodes

% WARNING : can compute negative weights !!!!

%
% Author G. Meurant
% Sept 2000
% Updated April 2015
%

n = size(A,1);

Weight = sparse(n,n);
mins = realmax;
maxs = realmin;

for ii = 1:length(f)
 i = f(ii);
 % find the fine and coarse neighbours in A c_i, neighbours indi
 [ci,indi] = gm_coarsno(A,w,i);
 % list of nodes we are interested in
 ind = indi;
 % set of fine neighbours
 fi = gm_setdiff(indi,ci);
 lci = length(ci);
 if lci == 0
  error('gm_wmeur: no coarse neighbour in A')
 end
 
 % find the coarse neighbours of the fine neighbours of i
 for jj = 1:length(fi)
  j =fi(jj);
  [cj,indj] = gm_coarsno(A,w,j);
  % add cj to the list we are interested in but remove duplicates at the end
  ind = [ind cj];
 end % for j
 ind = unique(ind);
 
 % get the fine nodes
 indff = find(w(ind) == -50);
 indf = ind(indff);
 
 % get the coarse nodes
 indcc = find(w(ind) == -100);
 indc =ind(indcc);
 
 % add node i in first position
 indf = [i indf];
 
 mins = min(mins,length(indf) + length(indc));
 maxs = max(maxs,length(indf) + length(indc));
 % extract the fine-fine matrix
 Bff = A(indf,indf);
 % extract the fine-coarse matrix
 Bfc = A(indf,indc);
 % eliminate the fine nodes
 invff = inv(Bff);
 % filter the inverse (remove small elements)
 invff = gm_filmatr(invff,0.5);
 Bc = -invff * Bfc;
 % positive weights?
 %Bc = abs(Bc);
 % the weights are on the first row
 % normalize
 sum1 = sum(full(Bc(1,:)));
 if abs(sum1) > 1e-10
  Weight(i,indc) = Bc(1,:) / sum1;
 else
  Weight(i,indc) = Bc(1,:);
 end
end % for i

Weight = sparse(Weight);
p = [sort(f) sort(c)];
dimf = length(f);
Wp = Weight(p,p);
Weight = Wp(1:dimf,dimf+1:n);


 
