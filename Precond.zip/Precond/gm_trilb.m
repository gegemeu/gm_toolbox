function L=gm_trilb(A,tb);
%GM_TRILB block lower triangular part of A with blocks of order tb
% tb has to divide exactly the order of A

%
% Author G. Meurant
% August 2006
%

L = A;
n = size(A,1);
ntb = fix(n / tb);

for I = 1:ntb
  ideb = (I - 1) * tb + 1;
  jdeb = ideb + tb;
  L(ideb:min(ideb+tb-1,n),jdeb:n) = 0;
end
