function [ci,indi]=gm_coarsno1(S,w,i);
%GM_COARSNO1 find the coarse nodes and neigbours of i in S
% w = -100 for coarse nodes
% assume the diagonal is zero
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

indi = find(S(i,:));

if length(indi) ~= 0
 wi = w(indi);
 % coarse nodes
 indci = find(wi == -100);
 if length(indci) ~= 0
  ci = indi(indci);
 else
  ci = [];
 end
else
 indi = [];
 ci = [];
end



