function S=gm_influ(A,alp);
%GM_INFLU influence matrix of A

% computes a sparse matrix S of ones where
% |A(i,j)| >= alp * max_i |A(i,k)|

%
% author G. Meurant
% Aug 2000
%
 
maxs = max(abs(A'))';
n = size(A,1);
S = sparse(n,n);

for i = 1:n
 ind = find(abs(A(i,:)) >= alp * maxs(i));
 S(i,ind) = spones(ind);
end
S = S - diag(diag(S));
if nnz(S) == 0
 error('gm_influ: S is empty!')
end
