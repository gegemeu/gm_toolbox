function z = gm_solve_precond(A,r,precond,cprec,cprec_amg);
%GM_SOLVE_PRECOND solves M z = r

% M is the symmetric positive definite preconditioner defined by 'precond'

% cprec, cpre_amg = cell arrays computed in gm_init_precond

%
% Author G. Meurant
% January 2025
%

if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
 % cprec = {d, L, tb};
 d = cprec{1};
 L = cprec{2};
end % if
 
 switch precond
  case 'no'
   z = r;
   
  case 'sc'
   z = r ./ d;
   
  case {'ic', 'ch', 'lv', 'ss', 'sh', 'gs', 'wl', 'll'}
   y = L \ r;
   if size(r,2) > 1
    D = diag(d);
    z = L' \ (D * y);
   else
    z = L' \ (d .* y);
   end % if
   
  case 'bc'
   y = L \ r;
   % in this case d is a matrix
   yy = d \ y;
   z = L' \ yy;
   
  case {'tw', 'sp', 'fs'}
   z = L * r;
   
  case 'gp'
   z = L \ r;
   
  case 'po'
   k = cprec{3};
   if isempty(k)
    k = 1;
   end
   s = d(1:k+2);
   ss = sum(s(1:k+2).^2);
   b = s / ss;
   lmin = d(k+3);
   lmax = d(k+4);
   z(:,k+1) = b(k+2) * r;
   z(:,k) = b(k+1) * r + (2 / (lmax - lmin)) * (2 * A * z(:,k+1) - (lmax + lmin) * z(:,k+1));
   for j = k-1:-1:1
    z(:,j) = b(j+1) * r + (2 / (lmax - lmin)) * (2 * A * z(:,j+1) - (lmax + lmin) * z(:,j+1)) - z(:,j+2);
   end
   u = (4 / (lmin - lmax)) * s(k+1) * z(:,k+1);
   for j = k-1:-1:1
    u = (4 / (lmin - lmax)) * s(j+1) * z(:,j+1) + u;
   end
   z = sqrt(2 / pi) * (2 /(lmin - lmax)) * z(:,1) + u;
   
  case {'ai', 'a2', 'sa'}
   y = L' * r;
   if size(r,2) > 1
    D = diag(d);
    z = L * (D * y);
   else
    z = L * (d .* y);
   end % if
   
  case {'ci','ce','s3'}
   y = L \ r;
   z = L' \ y;
   
  case {'ml', 'mb'}
   
   % cprec_amg = {xin, nu, 1, cA, cM, cP, cR, cperm, ciperm, cdf, cZb, cDb, cL, cda, lmax, smooth, gama, normal, tb};
   xin = cprec_amg{1};
   nu = cprec_amg{2};
   un = cprec_amg{3};
   cA = cprec_amg{4};
   cM = cprec_amg{5};
   cP = cprec_amg{6};
   cR = cprec_amg{7};
   cperm = cprec_amg{8};
   ciperm = cprec_amg{9};
   cdf = cprec_amg{10};
   cZb = cprec_amg{11};
   cDb = cprec_amg{12};
   cL = cprec_amg{13};
   cda = cprec_amg{14};
   lmax = cprec_amg{15};
   smooth = cprec_amg{16};
   gama = cprec_amg{17};
   normal = cprec_amg{18};
   
   if strcmpi(precond,'mb') == 1
    % multilevel block preconditioner
    tb = cprec_amg{19};
    z = gm_amgitb(A,r,xin,nu,un,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
    
   elseif strcmpi(precond,'ml') == 1
    % multilevel preconditioner
    z = gm_amgit(A,r,xin,nu,un,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
   end % if strcmpi
   
  otherwise
   
   error('gm_solve_precond: This preconditioner does not exist')
   
 end % switch
 
 z = full(z);
 
 
