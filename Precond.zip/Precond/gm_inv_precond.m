function Mi = gm_inv_precond(A,precond,cprec,params);
%GM_INV_PRECOND inverse of a preconditioner

% Input:
% A = matrix
% precond - type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal (scaling)
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'bc' block Incomplete Cholesky
% cprec = cell array computed by gm_init_precond
% params = structure giving the parameter(s) needed by some preconditioners
%  if params is empty, default values are used
%  one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh', 'wl'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml'
%  = block size for block methods
%  = matrix M for 'gp'
%
%
% output
% Mi = inverse of the preconditioner M

%
% Author G. Meurant
% August 2023
%

n = size(A,1);

if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
 % cprec = {d, L, tb};
 d = cprec{1};
 L = cprec{2};
end % if

switch precond
 case {'no', 'ml'}
  Mi = speye(n,n);
  
 case 'sc'
  di = 1 ./ d;
  Mi = spdiags(di,0,n,n);
  
 case {'ic','ch','lv','ss','sh','gs','wl'}
  Li = inv(L);
  D = spdiags(d,0,n,n);
  Mi = Li' * D * Li;
  
 case 'bc'
  % in this case d is a matrix
  Li = inv(L);
  Di = inv(d);
  Mi = Li' * Di * Li;
  
 case {'tw', 'sp', 'fs'}
  Mi = L;
  
 case 'gp'
  Mi = L;
  
 case 'po'
  I  = eye(n,n);
  Mi = zeros(n,n);
  if isempty(params)
   k = 1;
  else
   k = params.p1;
  end % if
  if isempty(k) || k == 0
   k = 1;
  end
  s = d(1:k+2);
  ss = sum(s(1:k+2).^2);
  b = s / ss;
  lmin = d(k+3);
  lmax = d(k+4);
  for kk = 1:n
   r = I(:,kk);
   z(:,k+1) = b(k+2) * r;
   z(:,k) = b(k+1) * r + (2 / (lmax - lmin)) * (2 * A * z(:,k+1) - (lmax + lmin) * z(:,k+1));
   for j = k-1:-1:1
    z(:,j) = b(j+1) * r + (2 / (lmax - lmin)) * (2 * A * z(:,j+1) - (lmax + lmin) * z(:,j+1)) - z(:,j+2);
   end
   u = (4 / (lmin - lmax)) * s(k+1) * z(:,k+1);
   for j = k-1:-1:1
    u = (4 / (lmin - lmax)) * s(j+1) * z(:,j+1) + u;
   end
   z = sqrt(2 / pi) * (2 /(lmin - lmax)) * z(:,1) + u;
   Mi(:,kk) = z;
  end % for kk
  
 case {'ai','sa'}
  Mi = L * spdiags(d,0,n,n) * L';
  
 case {'ci','ce','s3'}
  Li = inv(L);
  Mi = Li' * Li;
  
 otherwise
  Mi = speye(n,n);
  
end % switch



