function indi = gm_neighbs(S,i);
%GM_NEIGHBS find the neigbours for nodei in the graph of S

% assume S(i,i) = 0 and S symmetric

%
% Author G. Meurant
% Mar 2009
%

indi = find(S(:,i))';



