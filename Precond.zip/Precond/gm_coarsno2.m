function [ci,fi,indi,diw] = gm_coarsno2(A,S,w,i);
%GM_COARSNO2 find the coarse, fine nodes and neigbours of node i in S

% w = -100 for coarse nodes
% assume that the diagonal is zero

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

% neighbours
indi = find(S(i,:));
wi = w(indi);
ci = indi(wi == -100);
fi = indi(wi > -100);
diw = find(A(i,:) & (S(i,:) == 0));


