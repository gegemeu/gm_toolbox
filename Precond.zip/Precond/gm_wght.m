function w=gm_wght(S);
%GM_WGHT weights from the influence matrix S
%
% number of non zeros of one row = number of neighbours in S
%

%
% Author G. Meurant
% Aug 2000
%

n = size(S,1);
w = zeros(1,n);

for i = 1:n
 w(i) = nnz(S(:,i));
end


