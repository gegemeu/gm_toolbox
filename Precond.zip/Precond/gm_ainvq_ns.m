function [Z,Wt,p]=gm_ainvq_ns(A,epss,qmin);
%GM_AINVQ_NS sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)

% keep only the q largest entries in a column

% Input:
% A = nonsymmetric matrix
% epss = dropping threshold
% qmin = maximum number of entries in a column
%
% Output:
% M = Z D^{-1} W', Z and W upper triangular
% returns Z, W' and inv(D)

%
% Author G. Meurant
% 1999
% Updated April 2015
%

n = size(A,1);

Z = speye(n,n);
W = speye(n,n);
p = zeros(n,1);
q = zeros(n,1);

anorm = epss * max(abs(A'))';

for i = 1:n-1

 xold = Z(:,i);
 xold(i) = 0;
 xxold = W(:,i);
 xxold(i) = 0;
 x = abs(Z(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Z(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(Z(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  Z(indl,i)=0;
  x = abs(Z(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xold));
   Z(iold(1),i) = xold(iold(1));
  end % if nnz
 end % if size
 x = abs(W(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  W(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(W(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  W(indl,i)=0;
  x = abs(W(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xxold));
   W(iold(1),i) = xxold(iold(1));
  end % if nnz
 end % if size

 % diagonal entries
 p(i:n) = A(i,:) * Z(:,i:n);
 p1 = 1 / p(i);
 q(i:n) = A(:,i)' * W(:,i:n);
 q1 = 1 / q(i);

 indp = find(abs(p(i+1:n)) > 0) + i;
 % update of column j>i of Z by column i
 for j = indp'
  Z(:,j) = Z(:,j) - p(j) * p1 * Z(:,i);
 end % for j
 
 indq = find(abs(q(i+1:n)) > 0) + i;
 % update of column j>i of W by column i
 for j = indq'
  W(:,j) = W(:,j) - q(j) * q1 * W(:,i);
 end % for j

end % for i

% last column of Z and W
xold = Z(:,n);
xold(n) = 0;
xxold = W(:,n);
xxold(n) = 0;

for j = 1:n-1
 x = abs(Z(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  Z(j,n) = 0;
 end % if
 x = abs(W(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  W(j,n) = 0;
 end % if
end % for j

[x,indx] = sort(abs(Z(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
Z(indl,n) = 0;
x = abs(Z(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xold));
 Z(iold(1),n) = xold(iold(1));
end
[x,indx] = sort(abs(W(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
W(indl,n) = 0;
x = abs(W(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xxold));
 W(iold(1),n) = xxold(iold(1));
end

% last diagonal entry
p(n) = A(n,:) * Z(:,n);

% return the inverse of the diagonal
p = 1 ./ p;

Wt = W';


