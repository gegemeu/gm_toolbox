function [w,iw]=gm_wght1(A);
%GM_WGHT1 weights from the matrix A (approximate inverse)
% used by 'm2' coarsening algorithm
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

n = size(A,1);

B = abs(A);

% symmetric scaling of B
D = diag(1 ./ sqrt(diag(B)));
Bs = D * B * D;
B = sparse(Bs - diag(diag(Bs)));
w = zeros(1,n);
[w,iw] = max(B);
