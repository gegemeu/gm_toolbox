function [f,c,w]=gm_coarsenstnew(A,S);
%GM_COARSENSTNEW Standard AMG coarsening algorithm, find the fine and coarse nodes
%  
% S is an influence matrix for A
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w are the final weights 
% = -100 for coarse nodes, -50 for fine nodes
%  does not use the second pass
%

%
% author G. Meurant
% Aug 2000
%

f = [];
c = [];

n = size(S,1);

w = gm_wght(S);
dim = 0;

% first pass of standard algo (from Wagner)

while dim < n
 % flag to C the node with maximum weight
 [y,i] = max(w);
 w(i) = -100;
 % c = c U {i}
 c = [c i];
 dim = dim + 1;
 
 % flag the influences of node i as F points
 ind = find(S(:,i) > 0 & w' > -50);
 w(ind) = -50;
 dim = dim + length(ind);
 f = [f ind'];
 
 % find the points (neighbours) which influence the new F points
 % for all j in ind
 for j = ind'
  indk = find(S(:,j) >0 & w' > -50);
  % increase their weights
  w(indk) = w(indk) + 1;
 end
 
 % decrease the weights of nodes which are influenced by i
 ind = find(S(i,:) > 0 & w > -50);
 w(ind) = w(ind) - 1;
end


 


