function [cA,cM,cP,cR,cPerm,ciPerm,cS,cw,cdf,cL,cU,cd,cda,lmax,err]=gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
 smooth,infl,coarse,interpo,normal,iprint);
%GM_AMG_NS_INIT init of non symmetric multi level preconditioner
%
% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%
% Input:
%  A = matrix, b = rhs, x0 = init vector
%  epss = stopping criterion
%  alpmax, alb = truncation threshold for building the grids and for smoothing
%  alb = number of levels for multilevel smoothers 'sh', 'wl' (0 without fill-in)
%  lmax = max nb levels
%  falp = multiplicative factor of alpmax and alb at each level
%  qmin = minimum value of q in AINV
%  alq = multiplicative factor of q in AINV
%  smooth = choice of smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normal = normalization (0 or 1)
%  iprint = print level
%
% Output:
%  matrices for each level in cell arrays
%  ca = matrix on level l (ell)
%  cM = preconditioner on level l
%  cP = prolongation (interpolation) on level l
%  cR = restriction on level l
%  cPerm = permutation of the nodes on level l
%  ciPerm = inverse permutation on level l
%  cS = influence matrices
%  cw = symbolic weights (-100 for coarse nodes)
%  cdf = number of fine nodes on level l
%  cL, cU, cd =  LU factors and permutation (for LU)
%   or AINV factors or Gauss-Seidel factors, etc...
%  cda = normalization factor
%  lmax = final number of levels
%  err = error code
%

%
% author G. Meurant,
% April 2015
%

Ad = A;
if normal == 1
 % diagonal normalization of A
 [Ad,Da] = gm_normaliz(A);
 % store the normalizing factor on the finest level
 cda(1) = {Da};
else
 cda(1) = {[]};
end

err = 0;
done = 0;
alp = alpmax;
alpb = alb;
q = qmin;
nmax = size(A,1);
nnza = nnz(A);
totpt = nmax;

% exact solve if less than nmin nodes
nmin = 9;

% start going down the levels
l = 0;
% store the size of the matrix on the previous level
nnold = nmax;

while done == 0
 
 n = size(A,1);

 if n <= nmin || l == lmax
  % we are at the coarsest level, stop the recursion
  
  if iprint >= 1
   if n <= nmin
    fprintf('\n gm_amg_ns_init: too few nodes, stop the recursion on levels, l = %d \n',l)
   else
    fprintf('\n gm_amg_ns_init: maximum number of levels, stop the recursion on levels, l = %d \n',l)
   end
   fprintf('\n ------------------------------------------------------------------- \n\n')
  end
  
  lmax = l;
  if l > 1
   % compute the LU factorization of the coarsest matrix for the exact solve
   [L,U,P] = lu(cA{l-1});
   cL(l) = {L};
   cU(l) = {U};
   cd(l) = {P};
  else
   % error if we just have one level
   if iprint >= 1
    fprintf('\n gm_amg_ns_init: error, max number of levels = %g \n',lmax);
   end
   err = 1;
   return
  end
  
  if iprint >= 1
   fprintf('\n--------------total number of levels (including the finest level) = %g \n\n',lmax+1);
  end
  % we are finished, exit
  break
 end
 
 % go down the levels
 l = l + 1;
 
 % initialize the cell arrays on level l (ell)
 cA(l) = {[]};
 cM(l) = {[]};
 cP(l) = {[]};
 cR(l) = {[]};
 cPerm(l) = {[]};
 ciPerm(l) = {[]};
 cw(l) = {[]};
 cdf(l) = {[]};
 cL(l) = {[]};
 cU(l) = {[]};
 cd(l) = {[]};
 cda(l+1) = {[]};
 cf(l) = {[]};
 cc(l) = {[]};
 cS(l) = {[]};

 nz_of_A = nnz(A);
 
 if iprint >= 1
  fprintf('\n -----------------level = %g, order of A at the beginning = %g \n',l,n);
  fprintf(' nb of non zero entries of the matrix A = %g \n',nz_of_A);
 end
 
 % ------------Construct the smoother
 
 if strcmpi(smooth,'gs') 
  % Gauss-Seidel smoother
  LL = tril(A);
  UU = triu(A);
  % store the smoother
  cL(l) = {LL};
  cU(l) = {UU};
  cd(l) = {ones(n,1)};
  % compute the Richardson matrix M for 'wi' interpolation if needed
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm') || strcmpi(coarse,'im') || strcmpi(coarse,'m2')
%    im = tL * diag(1 ./ diag(A)) * tU;
   im = LL;
   M = inv(im);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(diag(A),0,n,n);
 
 elseif strcmpi(smooth,'ai') 
  % AINV smoother or preconditoner for GMRES smoother
  % AINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet = 0; % shift
  beta = bet * max(max(abs(A)));
  As = A + beta * speye(n);
  % cases for which we may need two factorizations if alp ~= alpb
  twof = strcmpi(infl,'z') == 1 || strcmpi(coarse,'iz') == 1 || strcmpi(interpo,'iz') == 1;
  if abs(alp-alpb) > 1e-10 && twof
   [Za,Wa,pa,Zb,Wb,pb] = gm_ainvq2_ns(As,alp,alpb,q);
  else
   % if alp = alpb compute only one factorization
   [Za,Wa,pa] = gm_ainvq_ns(As,alp,q);
   Zb = Za;
   Wb = Wa;
   pb = pa;
  end
  % store the AINV factorizations
  cL(l) = {Za};
  cU(l) = {Wa};
  cd(l) = {pa};
  % compute the preconditioner M = Z P W
  M = Za * spdiags(pa,0,n,n) * Wa;
  cM(l)={M};
  spb = spdiags(sqrt(pb),0,n,n);
  Zzt = Zb * spb + spb * Wb - spb;
   
 elseif strcmpi(smooth,'tw')
  % Tang approximate inverse 
  % could eventually increase the number of levels in gm_saitw
  M = gm_saitw(A,0,1);
  cM(l) = {M};
  cL(l) = {[]};
  cU(l) = {[]};
  cd(l) = {[]};
  Zzt = M;
  
 elseif strcmpi(smooth,'ma')
  % multiplication by 2D-A
  Di = diag(diag(A));
  M = 2 * Di - A;
  cM(l) = {M};
  cL(l)={[]};
  cU(l)={[]};
  cd(l)={[]};
  Zzt = M;
 
 elseif strcmpi(smooth,'lu')
  % Incomplete LU smoother ILU(0) of a general matrix
  % without permutation (so it may fail!)
  [dd,LL,UU] = gm_lui(A);
  ind = find(dd == 0);
  if length(ind) ~= 0
  fprintf('\n gm_amg_ns_init: Pb with incomplete LU factorization, zeros on the diagonal \n')
  err = 1;
  return
  end
%   dd = 1 ./ dd; % gm_lusmooth assumes to receive dd and not the inverse!
  cL(l) = {LL};
  cU(l) = {UU};
  cd(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm') || strcmpi(coarse,'m2')
   M = inv(UU) * spdiags(1./dd,0,n,n) * inv(LL);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(dd,0,n,n);
  
  elseif strcmpi(smooth,'lb')
  % Incomplete block LU smoother of a general matrix
  % without permutation (so it may fail!)
  blk = ceil(alb);
  [DD,LL,UU] = gm_luib(A,blk);
  dd = diag(DD);
  ind = find(dd == 0);
  if length(ind) ~= 0
   fprintf('\n gm_amg_ns_init: Pb with block incomplete LU factorization, zeros on the diagonal \n')
   err = 1;
   return
  end
  cL(l) = {LL};
  cU(l) = {UU};
  cd(l) = {DD};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm') || strcmpi(coarse,'m2')
   M = inv(UU) * spdiags(dd,0,n,n) * inv(LL);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(dd,0,n,n);
  
 elseif strcmpi(smooth,'sh')
  % Incomplete factorization of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  % alb = number of levels, must be an integer
  alb = ceil(alb);
  if iprint == 0
   [LU,bdown] = gm_miluk(A,alb,3);
  else
   [LU,bdown] = gm_miluk(A,alb,3,iprint);
  end
  LL = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  UU = triu(LU);
  dd = diag(LU);
  ind = find(dd < 0);
  if length(ind) ~= 0
   fprintf('gm_amg_ns_init: Pb with shifted incomplete LU factorization \n')
   err = 1;
   return
  end
  cL(l) = {LL};
  cU(l) = {UU};
  cd(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   M = inv(UU) * inv(LL);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(dd,0,n,n);
  
   elseif strcmpi(smooth,'wl')
  % Weighted incomplete Cholesky of Eijkhout with levels
  % IC(level) of a general matrix
  % alb must be an integer
  alb = ceil(alb);
  if iprint == 0
   [LU,bdown] = gm_wiluk(A,alb);
  else
   [LU,bdown] = gm_wiluk(A,alb,iprint);
  end
  LL = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  UU = triu(LU);
  dd = diag(LU);
  ind = find(dd < 0);
  if length(ind) ~= 0
   fprintf('gm_amg_ns_init: Pb with weighted incomplete LU factorization \n')
   err = 1;
   return
  end
  cL(l) = {LL};
  cU(l) = {UU};
  cd(l) = {dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   M = inv(UU) * inv(LL);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(dd,0,n,n);
  
 elseif strcmpi(smooth,'gm')
  % GMRES with ILU preconditioner smoother
  [dd,LL,UU] = gm_lui(A);
  ind = find(dd == 0);
  if length(ind) ~= 0
  fprintf('\n gm_amg_ns_init: Pb with incomplete LU factorization, zeros on the diagonal \n')
  err = 1;
  return
  end
  cL(l) = {LL * spdiags(dd,0,n,n) * UU};
  cU(l) = {[]};
  cd(l) = {[]};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmpi(interpo,'wi') || strcmpi(interpo,'wm')
   M = inv(UU) * spdiags(1./dd,0,n,n) * inv(LL);
   cM(l) = {M};
  end
  Zzt = LL + UU - spdiags(dd,0,n,n);

 else
  fprintf('\n gm_amg_ns_init: smoother not implemented \n')
  err = 1;
  return
 end
 
 % smoothing operator (for 'wi' interpolation) if needed
 if strcmpi(interpo,'wi') & exist('M')
  SM = speye(n,n) - sparse(M * A);
 else
  SM = [];
 end
  
 % ------------influence matrix

 if strcmpi(infl,'a')
  % standard algorithm using A and the strong connections defined by alpha
  S = gm_influst(A,alp);

 elseif strcmpi(infl,'b')
  % same as the standard 'a' except it keeps at least one entry per row of
  % S
  S = gm_influstb1(A,alp);

 elseif strcmpi(infl,'m')
  % use the preconditioner M to define the coarse grid
  if exist('M')
   S = gm_influm(M);
  else
   fprintf('\n gm_amg_ns_init: M is not defined for this smoother \n')
  end

 elseif strcmpi(infl,'z')
  % when using AINV, use Z and W to define the coarse grid
  if exist('Zzt')
   S = gm_influm(Zzt);
  else
   fprintf('\n gm_amg_ns_init: Zzt is not defined for this smoother \n')
   err = 1;
   return
  end

 else
  fprintf('\n gm_amg_ns_init: this influence algorithm does not exist \n')
  err = 1;
  return
 end
 
 % store the influence matrix
 cS(l) = {S};
 
 % modify the values of parameters for next level
 alp = falp * alp;
 alpb = falp * alpb;
 q = fix(alq * q);
 
 % if there is nothing in S 
 % go up one level and stop the coarsening process
 if nnz(S) == 0 
  if iprint >= 1
   fprintf('gm_amg_ns_init: Problem, S is empty (%d) \n',nnz(S))
  end
  % go up one level and stop
  if l == 1
   fprintf('gm_amg_ns_init: Cannot go back on level 1 \n')
   err = 1;
   return
  else
   % change the max level
   lmax = l - 1;
  end
  
  % need to compute the LU factorization of the coarsest matrix
  % before exiting
  [LC,UC,PC] = lu(cA{l-2});
  cL(lmax) = {LC};
  cU(lmax) = {UC};
  cd(lmax) = {PC};
  if iprint >= 1
   fprintf('\n  after correction final number of levels = %g \n',lmax+1);
  end
  % exit
  break
 end

 % S is not empty
 % -------------construction of the coarse mesh for the next level

 if strcmpi(coarse,'st')
  % standard algorithm
  [f,c,w] = gm_coarsenstnew(A,S);
  
 elseif strcmpi(coarse,'cl')
  % (modified) CLJP algorithm
  % generally this is expensive
  [f,c,w] = gm_coarsencljp(A,S);
  
 elseif strcmpi(coarse,'pm')
  % PMIS algorithm
  [f,c,w] = gm_coarsenpmis(A,S);
  
 elseif strcmpi(coarse,'hm')
  % HMIS algorithm
  [f,c,w] = gm_coarsenhmis(A,S);
  
 elseif strcmpi(coarse,'fa')
  % Falgout: (modified) CLJP algorithm
  [f,c,w] = gm_coarsenfalg(A,S);
  
 elseif strcmpi(coarse,'mz')
  % standard algorithm + check of neighbours in A
  [f,c,w] = gm_coarsenstmz(A,S);
  
 elseif strcmpi(coarse,'p')
  % modifed Falgout algorithm
  [f,c,w] = gm_coarsenp(A,S);
  
 elseif strcmpi(coarse,'im')
  % coarsening using the preconditioner M
  if exist('M')
   [f,c,w] = gm_coarsenstin(A,M,S);
  else
   fprintf('\n gm_amg_ns_init: M is not defined for this coarsening \n')
   err = 1;
   return
  end
  
 elseif strcmpi(coarse,'iz')
  % coarsening using Z from AINV
  if exist('Zzt')
   [f,c,w] = gm_coarsenstin(A,Zzt,S);
  else
   fprintf('\n gm_amg_ns_init: Zzt is not defined for this coarsening \n')
   err = 1;
   return
  end
  
 elseif strcmpi(coarse,'m2')
  % my 'm2' algorithm
  if exist('M')
   [f,c,w] = gm_coarsenm2(A,S,M,alp);
  else
   fprintf('\n gm_amg_ns_init: M is not defined for this coarsening \n')
   err = 1;
   return
  end
  
 else
  fprintf('\n gm_amg_ns_init: this coarsening algorithm does not exist \n')
  err = 1;
  return
 end
 
 % permutation of the nodes according to fine and coarse nodes
 p = [sort(f) sort(c)];
 cPerm(l) = {p};
 Ap = A(p,p);
 ip = gm_invperm(p);
 ciPerm(l) = {ip};
 dimf = length(f);
 dimc = length(c);
 
 % ----------------construction of the interpolation matrix
 itp = 0;
 
 if strcmpi(interpo,'st')
  % standard AMG interpolation
  Weight = gm_winterp(A,S,f,c,w);
  
 elseif strcmpi(interpo,'sc')
  % Schur interpolation
  if exist('M')
   Mp = M(p,p);
   Weight = -Mp(1:dimf,1:dimf) * Ap(1:dimf,dimf+1:n);
  else
   fprintf('\n gm_amg_ns_init: M is not defined for this interpolation \n')
   err = 1;
  end
  
 elseif strcmpi(interpo,'im')
  % interpolation using the approximate inverse M
  if exist('M')
   Weight = gm_wintinv(M,f,c,w);
  else
   fprintf('\n gm_amg_ns_init: M is not defined for this interpolation \n')
  end
  
 elseif strcmpi(interpo,'iz')
  % interpolation using Z
  if exist('Zzt')
   Weight = gm_wintinv(Zzt,f,c,w);
  else
   fprintf('\n gm_amg_ns_init: Zzt is not defined for this interpolation \n')
   err = 1;
   return
  end
  
 elseif strcmpi(interpo,'em')
  % energy minimization interpolation (Wan and Chan like)
  itp = 1;
  Prol = gm_enermin(A,f,c);
  Prol = Prol(p,:);
  
 elseif strcmpi(interpo,'wi')
  % Wagner like interpolation with minimization
  if exist('SM')
   Weight = gm_wagint(A,S,SM,f,c,w);
  else
   fprintf('\n gm_amg_ns_init: SM is not defined for this interpolation \n')
   err = 1;
   return
  end
  
 elseif strcmpi(interpo,'wm')
  % my algorithm (with neighbours of neighbours)
  Weight = gm_wmeur(A,f,c,w);
  
 else
  fprintf('\n gm_amg_ns_init: this interpolation algorithm does not exist \n')
  err = 1;
  return
 end
 
 % store the fine and coarse nodes as well as the interpolation weights
 cf(l) = {f};
 cc(l) = {c};
 cw(l )= {w};
 cdf(l) = {length(f)};
 
 % interpolation (prolongation) matrix prol
 % identity on the coarse nodes
 
 if itp == 0
  
  % Jacobi improvement of interpolation?
  % this corresponds to long range interpolation
  % it increases the complexity of the coarse matrices
  jac = 0;
  if jac == 1
   Aff = Ap(1:dimf,1:dimf);
   Dff = diag(1 ./ diag(Aff));
   Afc = Ap(1:dimf,dimf+1:end);
   njac = 1;
   for jj = 1:njac
    Weight = (speye(dimf) - Dff * Aff) * Weight - Dff * Afc;
   end
  end % if jac
   
  Prol = [Weight ; speye(dimc,dimc)];
 end % if itp
 
 % ----------------------store the interpolation and restriction matrices
 cP(l) = {Prol};
 % restriction matrix R = P'
 Res = Prol';
 cR(l) = {Res};
 
 % -----------------------construction of the coarse matrix (next level)
 % always use Galerkin
 A = Res * Ap * Prol;
 
 if iprint == 1
  fprintf(' order of A at the end = %g \n',size(A,1));
 end
 
 if normal == 1
  % normalize on all levels
  [A,da] = gm_normaliz(A);
 end
 
 % ------------------------store the next matrix
 cA(l) = {A};
 
 if normal == 1
  % store the normalizing factor
  cda(l+1) = {da};
 end
 
 nn = length(c);
 % Do we have enough differences in the sizes of the grids?
 if ((nnold - nn) / nnold) <= 0.05
  if iprint >= 1
   fprintf('\n not enough difference in the number of nodes, level %d \n',l)
   [nnold nn]
  end
  % not enough difference of number of nodes between two consecutive levels
  % stop the recursion and solve exactly
  lmax = l;
  nnold = nn;
 else
  nnold = nn;
 end
 
end

% lmax is the number of levels
if lmax > 0
 
 % viz of the coarse grids (only for 2D grid problems on squares)
 % for other problems comment the next line
%  gm_plotgrids1(Ad,cA,cS,cw,lmax)
 
 stockA = nnz(Ad);
 stockL = 0;
 stockU = 0;
 stockd = 0;
 stockPR = 0;
 stockM = 0;
 
 if iprint == 1
  fprintf('--------------level %g, n = %g \n',0,nmax)
  fprintf(' storage A = %g, sparsity = %g \n\n',nnza,nnza/nmax^2)
 end
 
 for l = 1:lmax
  P = cP{l};
  d = cd{l};
  A = cA{l};
  w = cw{l};
  M = cM{l};
  L = cL{l};
  U = cU{1};
  nnzL = nnz(L);
  nnzd = nnz(d);
  nnzU = nnz(U);
  totpt = totpt + size(A,1);
  if strcmpi(smooth,'gs') 
   nnzL = 0;
   nnzd = 0;
   nnzU = 0;
  end
  if strcmpi(smooth,'tw')
   nnzd = 0;
  end
  
  if iprint >= 1
   % statistics
   % total storage 
   stockA = stockA + nnz(A);
   stockL = stockL + nnzL;
   stockU = stockU + nnzU;
   stockd = stockd + nnzd;
   stockM = stockM + nnz(M);
   stockPR = stockPR + 2 * nnz(P);
   fprintf('--------------level %g, n = %g \n',l,size(cA{l},1))
   fprintf(' storage A = %g, sparsity = %g, storage LU = %g \n\n',nnz(A),nnz(A)/size(A,1)^2,nnzL+nnzU+nnzd)
  end
 end
 
 totstr = stockA + stockL + stockU + stockd + stockPR;
 if iprint >= 1
  % totpt is the total storage for the coarse matrices (except the finest
  % level), nmax is size(A,1)
  sgrid = totpt / nmax;
  % stockA is the total storage for the coarse matrices (including the
  % finest level), nnza is nnz(A)
  sa = stockA / nnza;
  fprintf('\n total storage = %g, /n = %g, /nnzA = %g, sgrid = %g, sA = %g \n\n',totstr,totstr/nmax,...
   totstr/nnza,sgrid,sa)
 end
 
end

