function w = gm_wght_cljp(A,S);
%GM_WGHT_CLJP weights for the (modified) CLJP algorithm

% Input:
% A =matrix of the problem
% S = influence matrix


%
% Author G. Meurant
% Feb 2009
%

n = size(A,1);

w = zeros(1,n);

% color the graph of A
% [ncolor,color] = gm_graph_colorb(A);
[ncolor,color] = gm_graph_color1(A);

cw = ([1:ncolor]' - 1) / ncolor;

rand('state',0);
randn('state',0)

for i = 1:n
 % modified CLJP weights
 w(i) = nnz(S(:,i)) + rand / ncolor + cw(color(i));
 % usual CLJP weights
 %w(i) = nnz(S(:,i)) + rand;
 % other possibility 
 %w(i) = nnz(S(:,i)) + randn;
end

 
