function [d,L,H] = gm_choic(A);
%GM_CHOIC Incomplete Cholesky decomposition of a symmetric sparse matrix

% IC(0), same structure as A

% Input:
% A = symmetric matrix

% L inv(d) L^T with diag(L) = d, L lower triangular
% the output is d and not d^{-1} to avoid a division in the solve
% H is used in the updating algorithm of order 1 for epsi I + A

%
% Author G. Meurant
% 2002
% Updated June 2015
%

n = size(A,1);
L = spalloc(n,n,nnz(A));
H = spalloc(n,n,nnz(A));
d = zeros(n,1);
B = A;

for k = 1:n-1
 m = size(B,1);
% drop the entries not in the structure of A
 I = find(A(k:n,k));
 sl = sparse(m,1);
 sl = sl + sparse(I,1,B(I,1),m,1);
 L(k:n,k) = sl;

 dk = 1 / B(1,1);
 d(k) = B(1,1);
 
% Schur complement
 HHH = dk * L(k+1:n,k) * L(k+1:n,k)';
 HH = dk * HHH;

% remove the fill from HH
 I = find(A(k+1:n,k+1));
 sl = sparse(m-1,1);
 sl = sl + sparse(I,1,HH(I,1),m-1,1);
 H(k+1:n,k+1) = sl;
 B = B(2:m,2:m) - HHH;
end

% last element
L(n,n) = B(1,1);
d(n) = B(1,1);


 