function [f,c,w]=gm_coarsenstmz(A,S);
%GM_COARSENSTMZ Standard AMG coarsening algorithm + check for A
%
% S is an influence matrix computed by gm_influst
% gm_wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  does not use the second pass
%

%
% Author G. Meurant
% Aug 2000
% Updated March 2015
%

f = [];
c = [];

n = size(S,1);

w = cgml_wght(S);
dim = 0;

while dim < n
 % flag as Coarse the node with maximum weight
 [y,i ]= max(w);
 w(i) = -100;
 % c = c U {i}
 c = [c i];
 dim = dim + 1;
 
 % flag the influences as F points
 % 
 ind = find(S(:,i) > 0 & w' > -50);
 w(ind) = -50;
 dim = dim + length(ind);
 f = [f ind'];
 
 % find the points which influences the new F points
 % for all j in ind
 for j = ind'
  indk = find(S(:,j) >0 & w' > -50);
  % increase their value
  w(indk) = w(indk) + 1;
 end
 
 % decrease the value of the nodes which are influenced by i
 ind = find(S(i,:) > 0 & w > -50);
 w(ind) = w(ind) - 1;
end
dimf = length(f);

% now we check if every fine node i has a coarse node in A for standard interpolation
fold = f;
for i = fold
 [ci,indi] = gm_coarsno(A,w,i);
 % check if there is a coarse neighbour of i in A
 if length(ci) == 0
  % if not flag i as a coarse node 
  f = gm_setdiff(f,i);
  c = [c i];
  w(i) = -100;
 end
end
 

