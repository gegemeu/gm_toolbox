function [d,L]=gm_chic(A);
%GM_CHIC Incomplete Cholesky decomposition of a symmetric sparse matrix, same structure as A 
% L * diag(d) * L' with d vector and L unit lower triangular

%
% Author G. Meurant
% March 2001
%
 
n = size(A,1);
L = spalloc(n,n,nnz(A));
d = zeros(n,1);
B = A;

for k = 1:n-1
 m = size(B,1);
 % dropping strategy
 b1 = 1 / B(1,1);
 i = find(A(k:n,k));
 sl = sparse(i,1,B(i,1)*b1,m,1);
 L(k:n,k) = sl;
 L(k,k) = 1;
 d(k) = B(1,1);
 % Schur complement
 ind = i(2:end) - 1;
 sl = sl(2:m);
 BB = B(2:m,2:m);
 % do not take care of symmetry (faster)
 for i = ind
   BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
 end
 B = BB;
end
L(n,n) = 1;
d(n) = B(1,1);
% d = d';
