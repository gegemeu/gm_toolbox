function Weight=gm_wagint(A,S,SM,f,c,w);
%GM_WAGINT computes the interpolation weights inspired by Wagner's interpolation
%
% A matrix
% S influence matrix
% SM = I - M A
% cannot be used with smoothers not defined by Richardson
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% WARNING : may compute negative weights !!!!
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

n = size(A,1);
Weight = sparse(n,n);

for i = f
 % find the coarse neighbours in s c_i, neighbours indi
 [ci,indi] = gm_coarsno(S,w,i);
 lci = length(ci);
 if lci == 0
  error('gm_wagint: no coarse neighbour in S')
 end
 
 % compute the linear system for the minimization
 nq = lci + 1;
 Q = sparse(nq,nq);
 kl = 0;
 si = SM(i,:);
 for k = ci
  kl = kl + 1;
  sk = SM(k,:);
  secm(kl) = -si * sk';
  kj = 0;
  for l = ci
   kj = kj + 1;
   sl = SM(l,:);
   Q(kl,kj) = sk * sl';
  end
  Q(kl,nq) = 1;
 end
 % last line for the lagrange multiplier
 Q(nq,1:lci) = ones(1,lci);
 secm(nq) = 1;
 % solve
 pik = Q \ secm(1:nq)';
 Weight(i,ci) = pik(1:lci)';
end

Weight = sparse(Weight);
p = [sort(f) sort(c)];
dimf = length(f);
Wp = Weight(p,p);
Weight = Wp(1:dimf,dimf+1:n);


