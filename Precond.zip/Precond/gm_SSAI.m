function M = gm_SSAI(A,lfil,itmax);
%GM_SSAI approximate inverse for symmetric positive definite matrices

% Input:
% A = symmetric positive definite matrix
% lfil = maximum number of nonzero entries in a column
% itmax = maximum number of iterations for a column
%
% Output:
% M = symmetric preconditioner

%
% Author G. Meurant
% December 2024
%

n = size(A,1);
% defaults
if nargin == 1
 lfil = ceil(nnz(A) / n);
 itmax = 2 * lfil;
elseif nargin == 2
 itmax = 2 * lfil;
end % if

C = zeros(n,n);

d = diag(A);
D = diag(1 ./ sqrt(d));
A = D * tril(A,-1) * D;
A = A + A' + eye(n,n);

for j = 1:n
 c = zeros(n,1);
 r = zeros(n,1);
 r(j) = 1;
 for k = 1:itmax
  [~, i] = max(abs(r));
  %del = r(i)/A(i,i); %uncomment this row and comment the next one if matrix is unscaled
  del = r(i);
  c(i) = c(i) + del;
  if nnz(c) >= lfil
   break
  end % if
  r = r - del * A(:,i);
 end % for k
 C(:,j) = c;
end % for j

M = sparse((C + C') / 2);

