function z=gm_solveprecns(r,A,D,L,U,precond);
%GM_SOLVEPRECNS solves M z = r
%
% Input:
% A = matrix
% D and L,U computed by gm_initprecns
% D contains the inverse of the (block) diagonal matrix
% precond = type of preconditioning
% = 'no' M = I
% = 'sc' diagonal
% = 'gs' Gauss-Seidel
% = 'ss' SSOR like
% = 'lu' Incomplete LU(0)
% = 'lm' Matlab ILU with threshold
% = 'lb' block ILU
% = 'ai' approximate inverse AINV
% = 'tw' Tang and Wang approximate inverse
% = 'sh' or 'wl' ILU factorizations from V. Eijkhout
% = 'gp' given preconditioner 
% = 'gm' GMRES iterations
%
%
% Output:
% z = solution of M z = r
%

%
% Author G. Meurant
% july 2006
%

n = size(A,1);

switch precond
 
case 'no'
 z = r;
 
case 'sc'
 z = D * r;
 
case {'ss','lu','gs'}
 y = L \ r;
 z  = U \ (D * y);
 
 case 'lb'
 y = L \ r;
 z  = U \ (D * y);
 
 case  'gp'
  z = L \ r;
  
 case 'ai'
  z = L * D * U * r;
  
 case 'tw'
  z = L * r;
  
 case {'sh','wl'}
  y = L \ r;
  z = U \ y;
  
 case {'lm','ld'}
  y = L \ (D * r);
  z = U \ y;
  
 case 'gm'
  nitmax = fix(D(1,1));
  n = size(A,1);
  x0 = zeros(n,1);
  [z,nitg,iret,resng,resngt,time_matg] = gm_GMRESm_prec(A,r,x0,1e-20,nitmax,n/10,'left','reorth','noscaling','notrueres','noprint','gs',0);
 
  
end


