function w=gm_wght_r(A,S);
%GM_WGHT_R random weights for the CLJP and PMIS algorithms
%
% A matrix of the problem, S influence matrix
%

%
% Author G. Meurant
% Mar 2009
%

n = size(A,1);
w = zeros(1,n);

rand('state',0);
randn('state',0)

for i = 1:n
 % usual CLJP weights
 w(i) = nnz(S(:,i)) + rand;
 
 % other possibility 
 %w(i) = nnz(S(:,i)) + randn;
end

 
