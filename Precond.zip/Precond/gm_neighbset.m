function ind = gm_neighbset(A,i,k);
%GM_NEIGHBSET set of nodes which are at distance k of node i in the graph of matrix A

% k=0 neighbors of i
% k=1 neighbors + neighbors of neighbors 
% etc...

%
% Author G. Meurant
% Sept 2000
 
ind = gm_neighboset(A,i,k,i);

ind = gm_compr(ind);


