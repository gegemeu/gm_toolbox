function [LU,bdown] = gm_miluk(M,klev,ntry,varargin);
%GM_MILUK Manteuffel ILU factorization

% Manteuffel ILU factorisation of up to k levels.
% This factorises A+cI where c is guessed a few times.

%
% from Victor Eijkhout (eijkhout@cs.utk.edu), 1998/9;
% edited by G. Meurant
% April 2015
%

warning off

if size(varargin) > 0
 diagnostic = deal(varargin{:}) ;
else
 diagnostic = 0;
end

if diagnostic > 0
 fprintf('\n gm_miluk: Constructing milu(k) preconditioner to %d levels\n',klev);
 fprintf('           -- maximum %d tries of adding positive diagonal\n',ntry);
end

[m,n] = size(M);
[I_M,J_M,S_M] = find(M);
LU = sparse(I_M,J_M,S_M);

% record levels of elements
[I,J,V] = find(LU~=0);
Z = sparse(I,J,V,m,n);

[I,J] = find(LU < 0);
V = ones(size(I,1),1);
Pn = sparse(I,J,V,m,n) .* LU;
[I,J] = find(LU > 0);
V = ones(size(I,1),1);
Pp = sparse(I,J,V,m,n) .* LU;
MP = Pp - Pn;
for i = 1:n
 MP(i,i) = 0;
end
rs = max(MP * ones(m,1) - diag(LU),zeros(n,1));
Msave = LU;

for itry = 1:ntry
 try_fraction = (itry-1) / ntry;
 if itry > 1,
  LU = Msave;
  for i=1:n
   LU(i,i) = LU(i,i) + try_fraction * rs(i);
  end
 end
 
 % record breakdown points
 bd = [];
 
 for k = 1:m
  p = LU(k,k);
  I = find(LU(k+1:m,k))' + k;
  if p <= 0,          % if numerical breakdown
   bd = [bd, k];   % record breakdown location
  end
  for i = I
   J = find(LU(k,i+1:n)) + i;
   for j = J
    mij = LU(i,k)*LU(k,j) / p;
    mji = LU(j,k)*LU(k,i) / p;
    f = 0;
    if LU(i,j) ~= 0
     f = j;
     el = min(Z(i,j),1+max(Z(i,k),Z(k,j)));
    else
     rnij = max(Z(i,k),Z(k,j));
     if rnij <= klev
      f = j;
      el = rnij + 1;
     end
    end
    if f > 0,
     LU(i,f) = LU(i,f) - mij;
     Z(i,f) = el;
     LU(f,i) = LU(f,i) - mji;
     Z(f,i) = el;
    end
   end
   dia_fill = LU(i,k) * LU(k,i) / p;
   LU(i,i) = LU(i,i) - dia_fill;
  end
 end
 
 bdown = size(bd,2);
 if bdown ~= 0
  if diagnostic > 0
   fprintf(' gm_miluk: Manteuffel factorisation failed with %e fraction; retrying\n',try_fraction);
  end
 else
  if diagnostic > 0
   fprintf(' gm_miluk: Manteuffel factorisation succeeded with %e fraction.\n\n',try_fraction);
  end
  break
 end
 
end % end of Manteuffel loop

if diagnostic > 0,
 [I,J,V] = find(M);
 n1 = size(V);
 [I,J,V] = find(LU);
 n2 = size(V);
 fprintf('M/A element ratio: %d\n',n2/n1);
 if bdown ~= 0
  fprintf('Breakdown in %d locations\n',bdown);
 end
end

warning on



