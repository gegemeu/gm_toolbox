function [f,c,w]=gm_coarsenp(A,S);
%GM_COARSENP Variant of the parallel LLNL coarsening algorithm (Falgout and al)
% + check for C neighbours in S
% S is an influence matrix
% flag as fine point when weight = 0
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

f = [];
c = [];

n = size(S,1);

w = gm_wght(S);
dim = 0;
SS = S;

while dim < n
 % flag as Coarse the node with maximum weight
 [y,i] = max(w);
 w(i) = -100;
 % c = c U {i}
 c = [c i];
 dim = dim + 1;

 % P5
 ind = find(S(i,:) > 0);
 w(ind) = w(ind) - 1;
 S(i,ind) = zeros(1,length(ind));

 % P6 in Falgout's paper
 ind = find(S(:,i));
 for j = ind'
  S(j,i) = 0;
  indk = find(S(:,j) > 0);
  for k = indk'
   if S(k,i) ~= 0
    w(j) = w(j) - 1;
    S(k,j)=0;
   end
  end
 end

 % if w = 0 flag as a fine node
 indw = find(w < 1 & w > -50);
 w(indw) = -50;
 f = [f indw];
 dim = dim + length(indw);
end

% check if all F points have a C point in S for interpolation
ff = f;
for i = f
 [ci,indi] = gm_coarsno(SS,w,i);
 if length(ci) == 0
  ff = gm_setdiff(ff,[i]);
  c = [c i];
  w(i) = -100;
 end
end
f = ff;



