function S=gm_influm(A);
%GM_INFLUM influence matrix of A, = 1 when |A(i,j)| > 0 
%
% computes a sparse matrix s of ones where
% |A(i,j)| > 0 except on the diagonal
%

%
% author G. Meurant
% Aug 2000
%
 
n = size(A,1);
S = sparse(n,n);

% scan all rows
for i = 1:n
 ind = find(abs(A(i,:)) > 0);
 S(i,ind) = spones(ind);
end

% remove the diagonal
S = S - diag(diag(S));
if nnz(S) == 0
 error('gm_influm: S is empty!')
end


