function [f,c,w] = gm_coarsenfalg(A,S);
%GM_COARSENFALG Falgout coarsening algorithm, find the fine and coarse nodes

% Input:
% A = matrix
% S = influence matrix for A

% wght computes the initial weights
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%   =-100 for coarse nodes, -50 for fine nodes
%

%
% author G. Meurant
% Mar 2009
% Updated March 2015
%

f = [];
c = [];

n = size(S,1);

% modified weights using the coloring of the graph
%w = gm_wght_cljp(A,S);
% usual random weights
w = gm_wght_r(A,S);
dim=0;

while dim < n
 % find an independent set of nodes
 % use the coarse nodes of the result of the Ruge-Stuben algorithm
 if dim == 0
  [ff,cc,ww] = gm_coarsenstnew(A,S);
  isn = sort(cc);
 else
  isn = gm_ind_set(w,S);
 end

 % then use CLJP with isn as the independent set
 if length(isn) == 0
  % flag the remaining nodes as fine if not all their neighbours are fine
  ind = find(w > -50);
  indc =[];
  indf = [];
  for ii = 1:length(ind)
   i = ind(ii);
   % use S instead for interpolation
   ineighb =gm_neighb1(S,i);
   sw = sum(w(ineighb));
   if sw == -50*length(ineighb)
    indc = [indc i];
   else
    indf = [indf i];
   end
  end
  
  w(indc) = -100;
  c = [c indc];
    
  w(indf) = -50;
  f = [f indf];
  dim = dim + length(ind);
  
 else
  % flag the nodes in the set as coarse
  w(isn) = -100;
  % c = c U {i}
  c = [c isn];
  dim = dim + length(isn);

  for ii = 1:length(isn)
   i = isn(ii);
   % update the weights of the neighbours
   ind = find(S(i,:) > 0 & w > -50);
   if length(ind) > 0
    w(ind) = w(ind)-1;
    S(i,ind) = 0;
   end

   ind = find(S(:,i) > 0 & w' > -50);
   if length(ind) > 0
    for jj = 1:length(ind)
     j = ind(jj);
     S(j,i) = 0;
     indi = find(S(:,j) > 0 & w' > -50);
     if length(indi) > 0
      for kk = 1:length(indi)
       k = indi(kk);
       if S(k,i) > 0
        if w(j) > -50
         w(j) = w(j) - 1;
        end
        S(k,j) = 0;
       end % if
      end % for k
     end % if
    end % for j
   end % if

   % if the modified weights are zero flag the nodes as fine
   ind = find(w <= 1 & w > -50);
   if length(ind > 0)
    w(ind) = -50;
    f = [f ind];
    dim = dim + length(ind);
   end

  end % for i
 end % if isn

end % while





