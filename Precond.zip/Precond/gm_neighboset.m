function ind = gm_neighboset(A,i,k,ind);
%GM_NEIGHBOSET set of nodes which are at distance k from node i in the graph of matrix A

% k=0 neighbors of i
% k=1 neighbors + neighbors of neighbors 
% etc...
% ind is initialized to i ?
%

%
% Author G. Meurant
% Sept 2000
%

if k < 0
 return
elseif k == 0
 ind = [i gm_neighb(A,i)];
elseif k > 0
 indi = [i gm_neighb(A,i)];
 for j = indi
  ind = [ind  gm_neighboset(A,j,k-1,j)];
 end
end

