function [indi]=gm_neighb1(S,i);
%GM_NEIGHB1 find the neigbours for i in the graph of S
% assume s(i,i) = 0
%

%
% Author G. Meurant
% Aug 2000
%

indi = find(S(i,:));



