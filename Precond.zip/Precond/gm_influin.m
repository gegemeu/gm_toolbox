function S = gm_influin(M,alp);
%GM_INFLUIN influence matrix of M

% computes a sparse matrix S of ones where |M(i,j)| >= alp * max_i |M(i,k)|

% if there is no element for a row, take the largest one

%
% author G. Meurant
% Aug 2000
%

maxs = max(abs(M'))';
n = size(M,1);
S = sparse(n,n);
err = 0;

for i = 1:n
 ind = find(abs(M(i,:)) >= alp * maxs(i));
 indm = find(abs(M(i,:)) > 0);
 if length(indm) <= 1
  err = 1;
 end
 if length(ind) == 1
  b = full(M(i,:));
  b(i) = 0;
  [maxm,j] = max(abs(b));
  S(i,j) = 1;
 else
  S(i,ind) = spones(ind);
 end
end
S = S - diag(diag(S));
if nnz(S) == 0
 error('gm_influin: S is empty!')
end
if err == 1
 fprintf('\n gm_influin: pb with some empty rows \n')
end

