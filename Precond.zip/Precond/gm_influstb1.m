function S = gm_influstb1(A,alp);
%GM_INFLUSTB1 influence matrix of A standard AMG choice

% keep at least one element per row

% computes a sparse matrix S of ones where
% |A(i,j)| >= alp * max_i |A(i,k)|

%
% author G. Meurant
% Mar 2009
% corrected Sept 2010
%
 
maxs = max(abs(A'))';
%remove the diagonal
A = A - diag(diag(A));

if nnz(A) == 0
 fprintf('\n gm_influstb: Caution, the matrix A is diagonal \n')
 S = spones(A);
 return
end

n = size(A,1);

C = abs(A) - alp * maxs * ones(1,n);

S = spones(C >= 0);

% correction to avoid zero rows

for i = 1:n
 ss = S(i,:);
 if nnz(ss) == 0
  [y,j] = max(abs(A(i,:)));
  S(i,j(1)) = 1;
 end
end



