function Prol = gm_enermin(A,f,c);
%GM_ENERMIN computes the energy minimizing interpolation

% see Wan's PhD thesis
% very primitive coding not cost efficient

% Input: 
% A = matrix
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
% =-100 for coarse nodes, -50 for fine nodes

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

n = size(A,1);
m = length(c);
 
% q has m diagonal blocks of size n x n stored in a cell array
% bt is made of diagonal matrices stored in vectors
l = 0;
Hai = speye(n,n);
zer = zeros(n,1);

for i = sort(c)
 l = l + 1;
 Ai = Hai;
 indi = gm_neighb(A,i);
 indi = [i indi];
 Avois = A(indi,indi);
 Ai(indi,indi) = Avois;
 iq(l) = {inv(Ai)};
 ii = zer;
 ii(indi) = ones(length(indi),1);
 bt(l) = {ii};
end

% solution phase
% solve for the Lagrange multiplier, see Wan's PhD thesis
Bqb = sparse(n,n);
l = 0;
for i = sort(c)
 l = l + 1;
 ii = spdiags(bt{l},0,n,n);
 Bqb = Bqb + ii * iq{l} * ii;
end
b = -ones(n,1);
lamb = Bqb \ b;

% solve for the weights column by column
l = 0;
for i = sort(c)
 l = l + 1;
 phi = -iq{l} * (bt{l} .* lamb);
 Prol(:,l) = phi;
 Prol = sparse(Prol);
end

Prol = sparse(Prol);




 