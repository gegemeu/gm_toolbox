function [d,L,d1,ld,ldd]=gm_initprec(A,precond,iprint,param);
%GM_INITPREC computes many preconditioners for CG
% point and block preconditioners (except multilevel)

% A - matrix
% precond - type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal (scaling)
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'bc' block Incomplete Cholesky

% param - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv' 
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = nothing for 'tw'
%  = number of levels for 'ml'
%  = block size for 'bc'
% 
%
% output (depends on precond)
%  for incomplete factorizations or AINV
%   L - lower triangular factor
%   d - inverse of the diagonal matrix (to multiply the rhs)
%   d1 - square root of the diagonal (or its inverse) for accuracy estimates
%   ld - estimated norm of L sqrt(d) or L sqrt(1/d)
%   ldd - inf norm of the inverse of L sqrt(d)
% for least squares polynomial
%   L - empty
%   d - coefficients of the polynomial and max min Gerschgorin bounds

%
% Author G. Meurant
% Feb 2001
% Updated May 2015
%

warning off

n = size(A,1);
ee = ones(n,1);

switch precond
 
case 'no'
 % no preconditioning
 d = ones(n,1);
 d1 = d;
 L = speye(n);
 ld = 1;
 ldd = 1;
 
case 'sc'
 % diagonal preconditioning
 d = diag(A);
 d1 = d;
 L = speye(n);
 ld = 1;
 ldd = max(1./sqrt(d));
 
case {'ss','gs'}
 %  SSOR = L D^{-1} L^T with D diag of A (omega = 1)
 L = tril(A);
 d = diag(A);
 I = find(d==0);
 if ~isempty(I)
  error('gm_initprec: there are zeros on the diagonal of A')
 end
 d1 = sqrt(1 ./ d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 
case 'bc'
 % Incomplete block Cholesky
 [d,L,d1] = gm_icb(A,param); 
 ld = 1;
 ldd = 1;

case 'ic'
 % Incomplete point Cholesky with the same structure as A
 % computes L D L^T with diag(L) = 1
 % send back D^{-1}
 B = A;
 L = sparse(n,n);
 for k = 1:n-1
  m = size(B,1);
  b1 = 1 / B(1,1);
  i = find(A(k:n,k));
  sl = sparse(i,1,B(i,1)*b1,m,1);
  L(k:n,k) = sl;
  L(k,k) = 1;
  d(k) = B(1,1);
  % Schur complement
  ind = i(2:end)-1;
  sl = sl(2:m);
  BB = B(2:m,2:m);
  % do not take care of symmetry (faster)
  for i = ind
   BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
  end
  B = BB;
 end
 L(n,n) = 1;
 d(n) = B(1,1);
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the incomplete factorization, negative diagonal entries')
 end
 d = d';
 d1 = sqrt(d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 % to avoid divisions in the solve
 d = 1 ./ d;
 
case 'ch'
 % Incomplete point Cholesky keeping some fill-in
 % same kind of factorization as the previous one
 epsdrop = param;
 B = A;
 L = sparse(n,n);
 %
 % norm of each row of A
 %
 anorm = zeros(1,n);
 for i=1:n
  anorm(i) = norm(A(i,:),inf);
 end
 for k = 1:n-1
  m = size(B,1);
  b1 = 1 / B(1,1);
  ii = find(B(:,1));
  sl = sparse(ii,1,B(ii,1)*b1,m,1);
  L(k:n,k) = sl;
  % dropping strategy
  i = find(abs(L(k+1:n,k)) ./ anorm(k+1:n)' <= epsdrop);
  L(i+k,k) = zeros(length(i),1);
  L(k,k) = 1;
  d(k) = B(1,1);
  % Schur complement
  ind = find(L(k+1:n,k))';
  sl = sl(2:m);
  BB = B(2:m,2:m);
  for i = ind
   BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
  end
  B = BB;
 end
 L(n,n) = 1;
 d(n) = B(1,1);
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the incomplete factorization, negative diagonal entries')
 end
 d = d';
 d1 = sqrt(d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 d = 1 ./ d;
 
case 'lv'
 % Incomplete point Cholesky with levels
 % same kind of factorization as the previous ones
 levmax = param;
 B = A;
 L = sparse(n,n);
 Lev = sparse(n,n);
 levm = 100;
 Lev = spones(A);
 for k = 1:n-1
  m = size(B,1); 
  b1 = 1 / B(1,1);
  ii = find(B(:,1));
  sl = sparse(ii,1,B(ii,1)*b1,m,1);
  L(k:n,k) = sl;
  % dropping strategy
  i = find(Lev(2:end,1) > levmax);
  L(i+k,k) = zeros(length(i),1);
  Lev(i+1,1) = levm * ones(length(i),1);
  L(k,k) = 1;
  d(k) = B(1,1);
  % Schur complement
  Level = Lev;
  ind = find(L(k+1:n,k))';
  sl = sl(2:m);
  BB = B(2:m,2:m);
  Lev = Level(2:m,2:m);
  % do not take care of symmetry (faster)
  for i = ind
   BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
   j = find(B(i+1,:) ~= 0) - 1;
   indj = gm_fmt(ind,j);
   ll = Level(i+1,1);
   Lev(i,indj) = ll + Level(indj+1,1)';
  end
  B = BB;
 end
 L(n,n) = 1;
 d(n) = B(1,1);
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the incomplete factorization, negative diagonal entries')
 end
 d = d';
 d1 = sqrt(d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 d = 1 ./ d;
 
case 'sh'
 % Incomplete point Cholesky of Manteuffel (Eijkhout) with levels
 % L inv(D) L^T with diag(L)=D
 levmax = param;
 if iprint >= 1
  [LU,bdown] = gm_miluk(A,levmax,3,iprint);
 else
  [LU,bdown] = gm_miluk(A,levmax,3);
 end
 L = tril(LU);
 d = diag(L);
 ind = find(d <= 0);
 if length(ind) > 0 && iprint >= 1
  fprintf('\n gm_initprec: Pb with the incomplete factorization, negative diagonal entries \n')
 end
 d1 = sqrt(1 ./ d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 
 case 'wl'
  % Weighted incomplete Cholesky of Eijkhout with levels
  % IC(level) of a general matrix
  % alb must be an integer
  alb = ceil(param);
  [LU,bdown] = gm_wiluk(A,alb);
  L = tril(LU);
  d = diag(L);
  ind = find(d <= 0);
  if length(ind) > 0 && iprint >= 1
   fprintf('\n gm_initprec: Pb with the incomplete factorization, negative diagonal entries \n')
  end
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  ld = normest(Ls);
  w = Ls \ ee;
  ldd = max(abs(w));
 
case 'ci'
%  [R,mes] = cholinc(A,'0');
 opts.type = 'nofill';
 opts.shape = 'upper';
 R = ichol(sparse(A),opts);
%  if mes ~= 0
%   error('gm_initprec: Pb in the incomplete Cholesky factorization')
%  end
 L = R';
 d = diag(L);
 d1 = sqrt(1 ./ d);
 Ls = L * spdiags(d1,0,n,n);
 ld = normest(Ls);
 w = Ls \ ee;
 ldd = max(abs(w));
 
 case 'ce'
%   R = cholinc(A,param);
  opts.type = 'ict';
  opts.shape = 'upper';
  opts.droptol = param;
  R = ichol(sparse(A),opts);
  %  if mes ~= 0
  %   error('gm_initprec: Pb in the incomplete Cholesky factorization')
  %  end
  L = R';
  d = diag(L);
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  ld = normest(Ls);
  w = Ls \ ee;
  ldd = max(abs(w));
  
   case 's3' % this is for s3dkt3m2
%   R = cholinc(A,param);
  opts.type = 'ict';
  opts.diagcomp = 1e-2;
  opts.droptol = 1e-5;
  opts.shape = 'upper';
  R = ichol(sparse(A),opts);
  L = R';
  d = diag(L);
  d1 = sqrt(1 ./ d);
  Ls = L * spdiags(d1,0,n,n);
  ld = normest(Ls);
  w = Ls \ ee;
  ldd = max(abs(w));
 
case 'po'
 % least squares polynomial of degree k
 k = param;
 if isempty(k)
  k = 1;
 end
 % compute the Gerschgorin bounds
 un = ones(n,1);
 AA = abs(A);
 DA = spdiags(diag(AA),0,n,n);
 % put zeros on the diagonal
 AA = spdiags(zeros(n,1),0,AA);
 b = (DA - AA) * un;
 bb = (DA + AA) * un;
 lmin = min(b);
 lmax = max(bb);
 s = zeros(k+2,1);
 mu0 = -(lmin + lmax) / (lmax - lmin);
 s(1) = 1 / sqrt(pi);
 s(2) = sqrt(2 / pi) * (lmin + lmax) / (lmin - lmax);
 s(3) = sqrt(2 / pi) * ((2 * (lmin + lmax)^2 / (lmin - lmax)^2) - 1);
 for j = 4:k+2
  s(j) = 2 * mu0 * s(j-1) - s(j-2);
 end
 d = s;
 d(k+3) = lmin;
 d(k+4) = lmax;
 L = [];
 d1 = speye(n);
 ld = 1;
 ldd = 1;
 
case 'ai'
 % AINV approximate inverse of Benzi and Tuma
 tau = param;
 if isempty(tau)
  tau = 0.1;
 end
 [L,d] = gm_ainv(A,tau); %-------------------------------
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the AINV approximate inverse, negative diagonal entries, try SAINV')
 end
 dd = sqrt(d);
 d1 = sqrt(1 ./ d);
 Ls = L * spdiags(dd,0,n,n);
 ld = 1;
 ldd = norm(Ls,inf);
 
case 'sa'
 % SAINV approximate inverse of Benzi and Tuma
 tau = param;
 [L,d] = gm_sainv(A,tau); %-----------------------------------------
 ind = find(d <= 0);
 if length(ind) > 0
  error('gm_initprec: Pb with the SAINV approximate inverse, negative diagonal entries')
 end
 dd = sqrt(d);
 d1 = sqrt(1 ./ d);
 Ls = L * spdiags(dd,0,n,n);
 ld = 1;
 ldd = norm(Ls,inf);
 
case 'tw'
 % Tang and Wan approximate inverse
 L = cgml_saitw(A,0,1);
 d1 = ones(n,1);
 d = d1;
 ld = 1;
 ldd = 1;
 
otherwise
 error('gm_initprec: this preconditioner does not exist')
end

warning on
