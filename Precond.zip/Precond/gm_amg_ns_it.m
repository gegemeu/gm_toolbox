function x=gm_amg_ns_it(A,b,x0,nu,level,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
%GM_AMG_NS_IT One cycle of multilevel AMG iteration with several smoothers 
% non symmetric matrix A
% gam=1 V cycle, gam=2 W cycle 
% b = right-hand side, x0 = starting vector
% the arguments are defined in gm_amg_ns_init
%
% f and c are the fine and coarse nodes
% the coarse problem on each level is solved recursively and exactly on the coarsest level
% nu = number of pre and post smoothings steps
% matrices for each level are in cell arrays
% l = 1 fine grid, l = lmax coarsest grid
% 

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

% to see the residual norms on each level put iprint = 1
iprint = 0;

if normal == 1
 % normalization of the right-hand side
 b = cda{l} .* b;
end

l = level;

if l == lmax
 % coarsest level, exact using with LU with permutation
 L = cL{l};
 U = cU{l};
 P = cd{l};
 y = L \ (P * b);
 x = U \ y;
 if normal == 1
  x = cda{l} .* x;
 end
 if iprint == 1
  fprintf(' gm_amg_ns_it: level = %d, residual norm = %12.5e \n',level,norm(b-A*x))
 end
 % we are finished
 return
end

%-----------------other levels

% permutation
p = cperm{l};
ip=ciperm{l};
M = cM{l};
% interpolation matrix
Prol = cP{l};
% number of fine nodes
dimf = cdf{l};

% smoother
L = cL{l};
U = cU{l};
d = cd{l};

% restriction matrix
Res = cR{l};

% initial vector
x = x0;

% V (gam = 1) or W cycle (gam = 2)
for j = 1:gam
 
 % -----------nu steps of pre smoothing
 
 if strcmpi(smooth,'gs') == 1 || strcmpi(smooth,'lu') == 1 || strcmpi(smooth,'lb') == 1 || strcmpi(smooth,'sh') == 1 ...
   || strcmpi(smooth,'wl') == 1
  x = gm_lusmooth(smooth,A,L,U,d,b,x,nu);
  
 elseif strcmpi(smooth,'ai') == 1
  x = gm_msmooth(A,M,b,x,nu);
  
 elseif strcmpi(smooth,'tw') == 1 || strcmpi(smooth,'ma') == 1
  x = gm_msmooth(A,M,b,x,nu);
  
 elseif strcmp(smooth,'gm')
  nitmax = 3;
  [x,nit,iret,resn,resnt] = gm_GMRESm_prec(A,b,x,1e-20,nitmax,nitmax,'left','noreorth','noscal','nores','noprint','lu',L);
  
 else
  error('gm_amg_ns_it: the given smoother does not exist')
 end
 
 % residual
 r = b - A * x;
 
 if iprint == 1
 fprintf(' gm_amg_ns_it: level = %d, residual norm = %12.5e \n',level,norm(r))
 end

 % permute x and r
 xp = x(p);
 rp = r(p);
 
 % ------------restrict the residual to the next coarsest grid
 rc = Res * rp;
 
 % ------------recursively solve Ac ec = rc starting from 0
 Ac = cA{l};
 x0 = zeros(size(Ac,1),1);

 ec = gm_amg_ns_it(Ac,rc,x0,nu,l+1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 
 % ------------interpolate the result back to the fine grid
 e = Prol * ec;
 
 % ------------add correction
 xp = xp + e;
 
 % permute x back
 x = xp(ip);
 
 % ------------nu steps of post smoothing
 
 if strcmpi(smooth,'gs') == 1 || strcmpi(smooth,'lu') == 1 || strcmpi(smooth,'lb') == 1 || strcmpi(smooth,'sh') == 1 ...
   || strcmpi(smooth,'wl') == 1
  x = gm_lusmooth(smooth,A,L,U,d,b,x,nu);
  
 elseif strcmpi(smooth,'ai') == 1
  x = gm_msmooth(A,M,b,x,nu);
  
 elseif strcmpi(smooth,'tw') == 1 || strcmpi(smooth,'ma') == 1
  x = gm_msmooth(A,M,b,x,nu);
  
 elseif strcmp(smooth,'gm')
  [x,nit,iret,resn,resnt] = gm_GMRESm_prec(A,b,x,1e-20,nitmax,nitmax,'left','noreorth','noscal','nores','noprint','lu',L);
  
 else
  error('gm_amg_ns_it: the given smoother does not exist')
 end
 
end % for j

% if normalization
if normal == 1
 x = cda{l} .* x;
end


