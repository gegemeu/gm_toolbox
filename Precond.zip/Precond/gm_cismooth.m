function x = gm_cismooth(A,L,b,x0,nu);
%GM_CISMOOTH  Richardson smoothing with IC for AMG

% Input:
% A = symmetric matrix
% b = right-hand side
% x0 = init vector
% nu = number of iterations
% the preconditioner is L L^T

%
% Author G. Meurant
% May 2015
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 y = Lt \ z;
 x = x + y;
end

