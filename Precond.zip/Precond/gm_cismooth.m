function x=gm_cismooth(A,L,b,x0,nu);
%GM_CISMOOTH  Richardson smoothing with IC for AMG

% nu iterations
% the preconditioner is L L^T

%
% Author G. Meurant
% May 2015
%

x = x0;
Lt = L';

for i = 1:nu
 y = b - A * x;
 z = L \ y;
 y = Lt \ z;
 x = x + y;
end

