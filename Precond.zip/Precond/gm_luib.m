function [D,L,U,D1] = gm_luib(A,tb);
%GM_LUIB  block incomplete LU decomposition LU(0) without pivoting of a sparse matrix A 

% L * D * U with d block diagonal matrix and Ll (and U) unit lower (upper) triangular
% tb = block size
% D1 is the inverse of D

%
% Author G. Meurant
% July 2006
%

n = size(A,1);

B = A;
L = sparse(n,n);
U = sparse(n,n);
D= sparse(n,n);
D1 = sparse(n,n);

% adjust the block size if needed
% number of blocks
nb = fix(n / tb);
if n ~= nb*tb
 warning('gm_luib: Error, the block size has to divide exactly the dimension of A')
 ind = rem(size(A,1)*ones(1,10),[tb:tb+9]);
 I = find(ind(2:10)==0);
 % change the block size
 % take the smallest compatible with the dimension
 tb = tb + I(2);
 nb = fix(n / tb);
 if rem(n,tb) ~= 0
   error('gm_luib: Error, the block size has to divide exactly the dimension of A')
 end
end

for kk = 1:nb-1
 k = (kk-1) * tb + 1;
 ktb = k + tb - 1;
 m = size(B,1);
 BB = B(1:tb,1:tb);
 B1 = inv(BB);
 Al = A(ktb+1:n,k:ktb);
 indl = find(Al);
 Au = A(k:ktb,ktb+1:n);
 indu = find(Au);
 sl = sparse(m-tb,tb);
 BBl= B(tb+1:m,1:tb);
 sl(indl) = BBl(indl);
 sl = sl * B1;
 su = sparse(tb,m-tb);
 BBu = B(1:tb,tb+1:m);
 su(indu) = BBu(indu);
 su = B1*su;
 L(ktb+1:n,k:ktb) = sl;
 L(k:ktb,k:ktb) = speye(tb);
 D(k:ktb,k:ktb) = BB;
 D1(k:ktb,k:ktb) = B1;
 U(k:ktb,ktb+1:n) = su;
 U(k:ktb,k:ktb) = speye(tb);
 % Schur complement
 Bc = B(tb+1:m,tb+1:m); 
 Bc = Bc - sl *BB * su;
 B = Bc;
end % for k

L(n-tb+1:n,n-tb+1:n) = speye(tb);
D(n-tb+1:n,n-tb+1:n) = B;
D1(n-tb+1:n,n-tb+1:n) = B1;
U(n-tb+1:n,n-tb+1:n) = speye(tb);

