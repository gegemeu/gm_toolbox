function isn=gm_ind_set(w,S);
%GM_IND_SET finds an independent set 
%
% {i: w(i) > w(j) for all j in S_i U S_i^T}
%

%
% Author G. Meurant
% Mar 2009
%

isn = [];
n = size(S,1);
% this is probably not needed
S = S - diag(diag(S));

for i = 1:n
 if w(i) > -50
  indi = find(S(:,i) > 0 & w' > -50);
  indit = find(S(i,:) > 0 & w > -50);
  ind = unique([indi(:)' indit(:)']);
  if length(ind) > 0
   maxw = max(w(ind));
  else
   maxw = realmax;
  end
  if w(i) > maxw
   isn = [isn i];
  end
 end
end



