function x=gm_sgssmoothn(A,Dl,b,x0,nu,tb);
%GM_SGSSMOOTHN  Block Gauss-Seidel smoothing 
% not symmetric!

% nu iterations starting from x0
% Dl contains the block lower triangular part of A
% tb block size

%
% Author G. Meurant
% Aug 2006
%

x = x0;
Lt = A - Dl;

for i = 1:nu
 x = Dl \ (b - Lt * x);
end


