function x = gm_sgssmoothn(A,Dl,b,x0,nu,tb);
%GM_SGSSMOOTHN  block Gauss-Seidel smoothing 

% Input:
% A = matrix
% Dl = lower triangular part of A
% b = right-hand side
% x0 = starting vector
% nu = number of iterations
% tb = block size

% not symmetric!

%
% Author G. Meurant
% Aug 2006
%

x = x0;
Lt = A - Dl;

for i = 1:nu
 x = Dl \ (b - Lt * x);
end


