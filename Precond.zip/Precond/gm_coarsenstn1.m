function [f,c,w]=gm_coarsenstn1(A,S,Za,pa);
%GM_COARSENSTN1 Standard AMG coarsening + addition of a few coarse nodes
% at the end using Brandt's idea

% standard AMG algorithm 
% S is an influence matrix computed by influst
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  does not use the second pass
%
% add a few coarse nodes at the end using Brandt's idea
% coded only for AINV smoothing

%
% Author G. Meurant
% Aug 2000
%

f = [];
c = [];
n = size(S,1);
w = gm_wght(S);
dim = 0;

% first pass
while dim < n
 % flag the node with maximum weight as Coarse
 [y,i] = max(w);
 w(i) = -100;
 % c = c U {i}
 c = [c i];
 dim = dim + 1;
 
 % flag the influences as F points
 ind = find(S(:,i) > 0 & w' > -50);
 w(ind) = -50;
 dim = dim + length(ind);
 f = [f ind'];
 
 % find the points which influences the new F points
 % for all j in ind
 for j = ind'
  indk = find(S(:,j) >0 & w' > -50);
  % increase their value
  w(indk) = w(indk) + 1;
 end
 
 % decrease the weights of the nodes which are influenced by i
 ind = find(S(i,:) > 0 & w > -50);
 w(ind) = w(ind) - 1;
end
dimf = length(f);

% add a few nodes
% except maybe on the finest level
% iterate from the vectors of all ones
%if l ~= 1
 x0 = ones(n,1);
 b = zeros(n,1);
 x = x0;
 iter = 2;
 % this is coded only for AINV
 for i = 1:iter
  x = x + Za * (pa .* (Za' * (b - A * x)));
  x(c) = zeros(length(c),1);
 end
 r = x;
 % find the q largest components of r
 q = min(fix(n/4),n);
 q = min(q,length(f)-1);
 [xx,j] = sort(abs(r));
 jjq = j(n-q+1:n);
 % flag these nodes as coarse
 for j = jjq'
  if w(j) == -50
   f = gm_fmt(f,j);
   c = [c j];
   w(j) = -100;
  end
 end






