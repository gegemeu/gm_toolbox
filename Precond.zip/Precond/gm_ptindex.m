function [ff,cc,ww] = gm_ptindex(A,f,c,w,tb);
%GM_PTINDEX computes the point index from the block index in block AMG

%
% Author G. Meurant
% August 2006
%

itb = [1:tb];
nf = length(f);
ff = zeros(1,tb*nf);

for I = 1:nf
  ff((I-1)*tb+1:I*tb) = (f(I)-1) * tb + itb';
end

nc = length(c);
cc = zeros(1,tb*nc);
for I = 1:nc
  cc((I-1)*tb+1:I*tb) = (c(I)-1) * tb + itb';
end

% w 
nw = length(w);
ww = zeros(1,tb*nw);
for I = 1:nw
  ww((I-1)*tb+1:I*tb) = w(I);
end