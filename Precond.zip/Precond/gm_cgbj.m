function x=gm_cgbj(A,D,b,x0,nu);
%GM_CGBJ Conjugate gradient smoothing with block diagonal preconditioner

% preconditioner d (block diagonal matrix)
% rhs b

%
% Author G. Meurant
% Aug 2000
%

x = x0;
r = b - A * x;
z = D \ r;
p = z;
rtr = z' * r;

for ll = 1:nu
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 z = D \ r;
 rtrz = z' * r;
 bet = rtrz / rtr;
 rtr = rtrz;
 p = z + bet * p;
end


