function x = gm_cgbj(A,D,b,x0,nu);
%GM_CGBJ conjugate gradient smoothing with block diagonal preconditioner

% Input:
% A = matrix
% b = right-hand side
% X0 = starting vector
% D = preconditioner (block diagonal matrix)
% nu = number of iterations

%
% Author G. Meurant
% Aug 2000
%

x = x0;
r = b - A * x;
z = D \ r;
p = z;
rtr = z' * r;

for ll = 1:nu
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 z = D \ r;
 rtrz = z' * r;
 bet = rtrz / rtr;
 rtr = rtrz;
 p = z + bet * p;
end % for


