function [d,L]=gm_iceps(epsi,A,d,L,H);
%GM_ICEPS computes the incomplete Cholesky decomposition IC without fill 
% for epsi*I+A (general 1rst order)

% We keep only the zero-th and a part of the first order perturbations
% d and L are the IC decomp of A obtained from gm_choic
% L inv(d) L^T with diag(L) = d
% H is the first order correction term coming from gm_choic
 
%
% Author G. Meurant
% 2002
% Updated June 2015
%

n = size(A,1);
 
% add the zero th order perturbation to the diagonal
d = d + epsi;

% add a part of the first order perturbation
 
dd = spdiags(d,0,n,n) + epsi * H;
d = diag(dd);

LL = tril(L,-1);
L = LL + dd;

 