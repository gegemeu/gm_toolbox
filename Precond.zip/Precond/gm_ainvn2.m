function [Z,p]=gm_ainvn2(A,epss,q);
%GM_AINVN2 Sparse approximate inverse of Benzi and Tuma (SISSC 97),
% keep q largest elements

% we keep only the q largest elements of each column
% returns the inverse of the diagonal

%
% author G. Meurant
% Aug 2000
%

n = size(A,1);
Z = speye(n);
p = zeros(n,1);
anorm = epss * max(abs(A'))'; % for dropping

for i = 1:n-1
 xold = Z(:,i);
 xold(i) = 0;
 x = abs(Z(1:i-1,i));
 if size(x,1) ~= 0
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Z(ind,i) = 0;
  % keep only the q largest elements
  [x,indx] = sort(abs(Z(1:i-1,i)));
  qq = min(q,i-1);
  indl = indx(1:i-1-qq);
  Z(indl,i) = 0;
  x = abs(Z(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal element
   [maxold,iold] = max(abs(xold));
   Z(iold(1),i) = xold(iold(1));
  end
 end
 p(i:n) = A(i,:) * Z(:,i:n);
 p1 = 1 / p(i);
 indp = find(abs(p(i+1:n)) > 0) + i;
 for j = indp'
  Z(:,j) = Z(:,j) - p(j) * p1 * Z(:,i);
 end
end

% last column
xold = Z(:,n);
xold(n) = 0;
for j = 1:n-1
 x = abs(Z(j,n));
 if x < anorm(j) & x > 0
  Z(j,n) = 0;
 end
end
[x,indx] = sort(abs(Z(1:n-1,n)));
qq = min(q,n-1);
indl = indx(1:n-1-qq);
Z(indl,n) = 0;
x = abs(Z(:,n));
if nnz(x) == 1
 % keep the largest non diagonal element
 [maxold,iold] = max(abs(xold));
 Z(iold(1),n) = xold(iold(1));
end
p(n) = A(n,:) * Z(:,n);
p = 1 ./ p;


