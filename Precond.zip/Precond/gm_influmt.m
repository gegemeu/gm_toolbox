function S=gm_influmt(A);
%GM_INFLUMT influence matrix of A, |a(i,j)| > 0, q largest elements

% computes a sparse matrix S of ones where |A(i,j)| > 0
% keep only the q largest elements

%
% author G. Meurant
% Aug 2000
%
 
q = 2;
n = size(A,1);
T = abs(triu(A,1));
S = sparse(n,n);

for i = 1:n-1
 ind = find(T(i,:) > 0);
 lti = length(ind);
 if lti > 0
  qq = min(q,lti);
  % find the q largest in t
  [x,indx] = sort(T(i,i+1:n));
  lx = length(indx);
  indl = indx(lx-qq+1:lx) + i;
  S(i,indl) = spones(indl);
 end
end
S = S + S';
if nnz(S) == 0
 error('gm_influmt: S is empty!')
end

