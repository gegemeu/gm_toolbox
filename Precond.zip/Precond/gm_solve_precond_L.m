function z = gm_solve_precond_L(r,ell,precond,cprec);
%GM_SOLVE_PRECOND_L solves L z = r or L' z = r with M = L L'

% r = right-hand side (could be a matrix)
% precond - type of preconditioner
%  = 'no' M = I
%  = 'sc' diagonal (scaling)
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
% cprec = cell array computed by gm_init_precond
%
%
% output
% z - solution

%
% Author G. Meurant
% February 2025
%

d = cprec{1};
L = cprec{2};

switch precond
 case 'no'
  z = r;
  
 case 'sc'
  D = diag(1 ./ sqrt(d));
  z = D * r;
  
 case {'ic','ch','lv','ss','sh','gs'}
  D = diag(1 ./ sqrt(d));
  if ell == 1
   z = D * (L \ r);
  else
   z = L' \ (D * r);
  end
  
 case {'ci','ce'}
  if ell == 1
   z = L \ r;
  else
   z = L' \ r;
  end
  
 case {'ai', 'a2', 'sa'}
  D = diag(sqrt(d));
  if ell == 1
   z = L * D * r;
  else
   z = D * L' * r;
  end % if
  
end % switch

z = full(z);

