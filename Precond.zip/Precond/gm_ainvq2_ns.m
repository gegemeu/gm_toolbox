function [Za,Wat,pa,Zb,Wbt,pb]=gm_ainvq2_ns(A,epssa,epssb,qmin);
%GM_AINVQ2_NS sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
% computes two factorizations (one for computing the grids, the other for
% smoothing)
% keep only the q largest entries in a column
% M = Z D^{-1} W', Z and W upper triangular
% returns Z, W' and inv(D)
%

%
% Author G. Meurant
% 1999
% Updated April 2015
%

n = size(A,1);

Za = speye(n,n);
Wa = speye(n,n);
pa = zeros(n,1);
q = zeros(n,1);

maxA = max(abs(A'))';
anorm = epssa * maxA;

for i = 1:n-1

 xold = Za(:,i);
 xold(i) = 0;
 xxold = Wa(:,i);
 xxold(i) = 0;
 x = abs(Za(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Za(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(Za(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  Za(indl,i)=0;
  x = abs(Za(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xold));
   Za(iold(1),i) = xold(iold(1));
  end % if nnz
 end % if size
 x = abs(Wa(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Wa(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(Wa(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  Wa(indl,i)=0;
  x = abs(Wa(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xxold));
   Wa(iold(1),i) = xxold(iold(1));
  end % if nnz
 end % if size

 % diagonal entries
 pa(i:n) = A(i,:) * Za(:,i:n);
 p1 = 1 / pa(i);
 q(i:n) = A(:,i)' * Wa(:,i:n);
 q1 = 1 / q(i);

 indp = find(abs(pa(i+1:n)) > 0) + i;
 % update of column j>i of Z by column i
 for j = indp'
  Za(:,j) = Za(:,j) - pa(j) * p1 * Za(:,i);
 end % for j
 
 indq = find(abs(q(i+1:n)) > 0) + i;
 % update of column j>i of W by column i
 for j = indq'
  Wa(:,j) = Wa(:,j) - q(j) * q1 * Wa(:,i);
 end % for j

end % for i

% last column of Z and W
xold = Za(:,n);
xold(n) = 0;
xxold = Wa(:,n);
xxold(n) = 0;

for j = 1:n-1
 x = abs(Za(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  Za(j,n) = 0;
 end % if
 x = abs(Wa(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  Wa(j,n) = 0;
 end % if
end % for j

[x,indx] = sort(abs(Za(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
Za(indl,n) = 0;
x = abs(Za(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xold));
 Za(iold(1),n) = xold(iold(1));
end
[x,indx] = sort(abs(Wa(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
Wa(indl,n) = 0;
x = abs(Wa(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xxold));
 Wa(iold(1),n) = xxold(iold(1));
end

% last diagonal entry
pa(n) = A(n,:) * Za(:,n);

% return the inverse of the diagonal
pa = 1 ./ pa;

Wat = Wa';

if epssa == epssb
 Zb = Za;
 Wbt = Wat;
 pb = pa;
 return
end
 
% second factorization

Zb = speye(n,n);
Wb = speye(n,n);
pb = zeros(n,1);
q = zeros(n,1);

anorm = epssb * maxA;

for i = 1:n-1

 xold = Zb(:,i);
 xold(i) = 0;
 xxold = Wb(:,i);
 xxold(i) = 0;
 x = abs(Zb(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Zb(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(Zb(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  Zb(indl,i)=0;
  x = abs(Zb(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xold));
   Zb(iold(1),i) = xold(iold(1));
  end % if nnz
 end % if size
 x = abs(Wb(1:i-1,i));
 if size(x,1) ~= 0
  % drop some entries
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Wb(ind,i) = 0;
  % keep only the q largest entries
  [x,indx] = sort(abs(Wb(1:i-1,i)));
  qq = min(qmin,i-1);
  indl = indx(1:i-1-qq);
  Wb(indl,i)=0;
  x = abs(Wb(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal entry
   [maxold,iold] = max(abs(xxold));
   Wb(iold(1),i) = xxold(iold(1));
  end % if nnz
 end % if size

 % diagonal entries
 pb(i:n) = A(i,:) * Zb(:,i:n);
 p1 = 1 / pb(i);
 q(i:n) = A(:,i)' * Wb(:,i:n);
 q1 = 1 / q(i);

 indp = find(abs(pb(i+1:n)) > 0) + i;
 % update of column j>i of Z by column i
 for j = indp'
  Zb(:,j) = Zb(:,j) - pb(j) * p1 * Zb(:,i);
 end % for j
 
 indq = find(abs(q(i+1:n)) > 0) + i;
 % update of column j>i of W by column i
 for j = indq'
  Wb(:,j) = Wb(:,j) - q(j) * q1 * Wb(:,i);
 end % for j

end % for i

% last column of Z and W
xold = Zb(:,n);
xold(n) = 0;
xxold = Wb(:,n);
xxold(n) = 0;

for j = 1:n-1
 x = abs(Zb(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  Zb(j,n) = 0;
 end % if
 x = abs(Wb(j,n));
 if x < anorm(j) & x > 0
  % drop some entries
  Wb(j,n) = 0;
 end % if
end % for j

[x,indx] = sort(abs(Zb(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
Zb(indl,n) = 0;
x = abs(Zb(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xold));
 Zb(iold(1),n) = xold(iold(1));
end
[x,indx] = sort(abs(Wb(1:n-1,n)));
qq = min(qmin,n-1);
indl = indx(1:n-1-qq);
Wb(indl,n) = 0;
x = abs(Wb(:,n));
if nnz(x) == 1
 % keep the largest non diagonal entry
 [maxold,iold] = max(abs(xxold));
 Wb(iold(1),n) = xxold(iold(1));
end

% last diagonal entry
pb(n) = A(n,:) * Zb(:,n);

% return the inverse of the diagonal
pb = 1 ./ pb;

Wbt = Wb';


