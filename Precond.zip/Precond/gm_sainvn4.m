function [Za,pa,Zb,pb] = gm_sainvn4(A,epssa,epssb,q);
%GM_SAINVN4 sparse approximate inverse of Benzi and Tuma (SISSC 97), stabilized version of gm_ainvn4
 
% Input:
% A = symmetric matrix
% epss, epssb = dropping thresholds
% q = �axi�u� number of entries in a column
%
% Output:
% inv(M) = Z D Z^T
% returns the inverse of the diagonal of D in p

% keep at least one non diagonal element to be able to use
% interpolation (not sure that it will always work)
% computes two decompositions, one with epssa and one with epssb
% this is needed by gm_amg_init
% not cheap, computes both decompositions (could be done in one path instead)

%
% author G. Meurant
% March 2001
%
 
n = size(A,1);
Za = speye(n);
Zb = speye(n);
pa = zeros(n,1);
pb = zeros(n,1);
maxa = max(abs(A'))';
anorm = epssa * maxa; % for dropping

for i = 1:n-1
 xold = Za(:,i);
 xold(i) = 0;
 x = abs(Za(1:i-1,i));
 if size(x,1) ~= 0
  ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  Za(ind,i) = 0;
  [x,indx] = sort(abs(Za(1:i-1,i)));
  qq = min(q,i-1);
  indl = indx(1:i-1-qq);
  Za(indl,i) = 0;
  x = abs(Za(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal element
   [maxold,iold] = max(abs(xold));
   Za(iold(1),i) = xold(iold(1));
  end
 end
 v = A * Za(:,i);
 pa(i:n) = v' * Za(:,i:n);
 p1 = 1 / pa(i);
 indp = find(abs(pa(i+1:n)) > 0) + i;
 for j = indp'
  Za(:,j) = Za(:,j) - pa(j) * p1 * Za(:,i);
 end
end

% last column
xold = Za(:,n);
xold(n) = 0;
for j = 1:n-1
 x = abs(Za(j,n));
 if x < anorm(j) && x > 0
  Za(j,n)=0;
 end
end
[x,indx] = sort(abs(Za(1:n-1,n)));
qq = min(q,n-1);
indl = indx(1:n-1-qq);
Za(indl,n) = 0;
x = abs(Za(:,n));
if nnz(x) == 1
 % keep the largest non diagonal element
 [maxold,iold] = max(abs(xold));
 Za(iold(1),n) = xold(iold(1));
end
pa(n) = Za(:,n)' * A * Za(:,n);
pa = 1 ./ pa;

if epssa == epssb
 Zb = Za;
 pb = pa;
else
 % compute the second decomposition
 anorm = epssb* maxa;
 for i = 1:n-1
  xold = Zb(:,i);
  xold(i) = 0;
  x = abs(Zb(1:i-1,i));
  if size(x,1) ~= 0
   ind = find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
   Zb(ind,i) = 0;
   [x,indx] = sort(abs(Zb(1:i-1,i)));
   qq = min(q,i-1);
   indl = indx(1:i-1-qq);
   Zb(indl,i) = 0;
   x = abs(Zb(:,i));
   if nnz(x) == 1
    % keep the largest non diagonal element
    [maxold,iold] = max(abs(xold));
    Zb(iold(1),i) = xold(iold(1));
   end
  end
  v = A * Zb(:,i);
  pb(i:n) = v' * Zb(:,i:n);
  p1 =1 / pb(i);
  indp = find(abs(pb(i+1:n)) > 0) + i;
  for j = indp'
   Zb(:,j) = Zb(:,j) - pb(j) * p1 * Zb(:,i);
  end
 end
 xold = Zb(:,n);
 xold(n) = 0;
 for j = 1:n-1
  x = abs(Zb(j,n));
  if x < anorm(j) && x > 0
   Zb(j,n) = 0;
  end
 end
 [x,indx] = sort(abs(Zb(1:n-1,n)));
 qq = min(q,n-1);
 indl = indx(1:n-1-qq);
 Zb(indl,n) = 0;
 x = abs(Zb(:,n));
 if nnz(x) == 1
  % keep the largest non diagonal element
  [maxold,iold] = max(abs(xold));
  Zb(iold(1),n) = xold(iold(1));
 end
 pb(n) = Zb(:,n)' * A * Zb(:,n);
 pb = 1 ./ pb;
end
