function S = gm_influst(A,alp);
%GM_INFLUST influence matrix of A, standard AMG

% computes a sparse matrix S of ones where
% |A(i,j)| >= alp * max_i |A(i,k)|
%

%
% author G. Meurant
% Aug 2000
%

n = size(A,1);
S = sparse(n,n);
 
maxs = max(abs(A'))';

for i = 1:n
 ind = find(abs(A(i,:)) >= alp * maxs(i));
 S(i,ind) = spones(ind);
end

% remove the diagonal
S = S - diag(diag(S));

if nnz(S) == 0
 error('gm_influst: S is empty!')
end
