function x=gm_msmooth(A,M,b,x0,nu);
%GM_MSMOOTH  Richardson smoothing for AMG with M
%
% nu iterations
% the preconditioner is M 
%

%
% Author G. Meurant
% Sept 2000
% Updated April 2015
%

x = x0;

for i = 1:nu
 x = x + M * (b - A * x);
end



