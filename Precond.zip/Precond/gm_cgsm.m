function x = gm_cgsm(A,d,b,x0,nu);
%GM_CGSM conjugate gradient smoothing with diagonal preconditioner 

% Input:
% A = matrix
% b = right-hand side
% X0 = starting vector
% d = preconditioner (diagonal of the matrix)
% nu = number of iterations

%  
% Author G. Meurant
% Aug 2000
%

x = x0;
r = b - A * x;
z = d .* r;
p = z;
rtr = z' * r;

for ll = 1:nu
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 z = d .* r;
 rtrz = z' * r;
 bet = rtrz / rtr;
 rtr = rtrz;
 p = z + bet * p;
end % for


