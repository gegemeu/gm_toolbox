function x=gm_cgsm(A,d,b,x0,nu);
%GM_CGSM Conjugate gradient smoothing with diagonal preconditioner 

% preconditioner d
% rhs b

%  
% Author G. Meurant
% Aug 2000
%

x = x0;
r = b - A * x;
z = d .* r;
p = z;
rtr = z' * r;

for ll = 1:nu
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 z = d .* r;
 rtrz = z' * r;
 bet = rtrz / rtr;
 rtr = rtrz;
 p = z + bet * p;
end


