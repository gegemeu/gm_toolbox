function SS = gm_pts(S,tb);
%GM_PTS translates the block influence matrix S to point form

% tb = block size

%
% Author G. Meurant
% August 2006
%

ntb = size(S,1);
n = ntb * tb;
SS = sparse(n,n);

% this yields diagonal blocks
% for I = 1:tb
%   ideb = (I-1) * ntb + 1;
%   ifin = ideb + ntb - 1;
%   SS(ideb:ifin,ideb:ifin) = S;
% end

% this yields full blocks
SS = repmat(S,tb,tb);

% permutation to blocks of order tb
p = zeros(1,n);
ii = [1:ntb];
for I = 1:tb
  p(I:tb:end) = (I-1) * ntb + ii;
end
SS = SS(p,p);

