function x=gm_gssmooth(A,b,x0,nu);
%GM_GSSMOOTH Gauss-Seidel smoothing for AMG

% nu iterations starting from x0

%
% Author G. Meurant
% Aug 2000
%

x = x0;
Dl = tril(A);
Lt =A -Dl;

for i = 1:nu
 x = Dl \ (b - Lt * x);
end

