function [] = gm_plotgrids1(A,cA,cS,cw,lmax,iprint);
%GM_PLOTGRIDS1 plots the AMG coarse meshes on the graph for a square mesh

% cA, cS and cw are cell arrays
% cA = coarse matrices
% cS = influence matrices
% cw = -100 for a coarse point
% this routine assumes a lexicographic ordering of the mesh points

%
% Author G. Meurant
% Aug 2001
% Updated April 2015
%

if nargin < 6
 iprint = 0;
end

% fine grid
n = size(A,1);

if iprint == 1
 fprintf('--------------level %g, n = %g \n',0,size(A,1))
 fprintf(' storage A = %g \n\n',nnz(A))
end

set(0,'ShowHiddenHandles','on')

xy = gm_gmesh(sqrt(n));
xw = xy;

spy(A)
title('Matrix structure, level 0')
figure
gplot(A,xw)
title('Matrix graph, level 0')
figure
gplot(cS{1},xw)
title('Graph of the matrix of influence, level 0')
pause

delete(get(0,'Children'))

% go down the levels
for l = 1:lmax
 spy(cA{l})
 title(['Matrix structure, level = ' num2str(l)])
 figure
 % plot the graph
 gplot(cS{l},xw)
 hold on
 w = cw{l};
 xz =xw;
 ind = find(w == -100);
 if length(ind) > 0
  xw = xw(ind,:);
  % plot a red square
  gm_plotsq(xw(:,1),xw(:,2))
 end
 ind = find(w ~= -100);
 if length(ind) > 0
  xz = xz(ind,:);
  % plot a green square
  gm_plotsqg(xz(:,1),xz(:,2))
 end
 tit=['level = ' num2str(l) ', nb of points = ' num2str(size(cS{l},1)) ', nb of (red) C points = ' num2str(length(xw))];
 title(tit)

 if iprint == 1
  A = cA{l};
  fprintf('--------------level %g, n = %g \n',l,size(cA{l},1))
  fprintf(' storage A = %g \n\n',nnz(A))
 end

 pause
 hold off
 delete(get(0,'Children'))
end



