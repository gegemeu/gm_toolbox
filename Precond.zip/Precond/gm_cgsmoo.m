function x=gm_cgsmoo(A,L,d,b,x0,nu);
%GM_CGSMOO conjugate gradient smoothing with AINV preconditioner 

% Input:
% A = matrix
% b = right-hand side
% X0 = starting vector
% M^-1 = L d L^T (ex: Benzi sparse inverse)
% nu = number of iterations

%
% Author G. Meurant
% Aug 2000
%

x = x0;
r = b - A * x;
y = L' * r;
z = L * (d .* y);
p = z;
rtr = z' * r;

for ll = 1:nu
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 y = L' * r;
 z = L * (d .* y);
 rtrz = z' * r;
 bet = rtrz / rtr;
 rtr = rtrz;
 p = z + bet * p;
end


