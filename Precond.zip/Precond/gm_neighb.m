function [indi]=gm_neighb(S,i);
%GM_NEIGHB find the neigbours for i in the graph of S
%

%
% Author G. Meurant
% Aug 2000
%

indi = find(S(i,:));

indi = gm_setdiff(indi,i);



