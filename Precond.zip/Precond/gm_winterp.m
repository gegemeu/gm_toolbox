function Weight = gm_winterp(A,S,f,c,w);
%GM_WINTERP computes the interpolation weights, standard AMG interpolation
% Input:
% A = matrix
% S = influence matrix computed by influ
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%  =-100 for coarse nodes, -50 for fine nodes

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

n = size(A,1);

d = zeros(n,1);
Weight = sparse(n,n);
AA = A - diag(diag(A));

for ii = 1:length(f)
 i = f(ii);
 % coarse nodes c_i, neighbours indi
 [cia,india] = gm_coarsno1(AA,w,i);
 if isempty(cia)
  error('gm_winterp: no coarse neighbour in A')
 end
 % diw weak neighbours in A (need the neighbours of i in inda)
 [ci,dis,indi,diw] = gm_coarsno2(AA,S,w,i);
 % ci = C inter S_i
 if isempty(ci)
  ci = cia;
  indi = india;
 end
 
 % compute d_i and d_j
 d(i) = A(i,i) + sum(A(i,diw));
 d(ci) = A(i,ci);
 for kk = 1:length(dis)
  k = dis(kk);
  % compute dj
  suma = sum(A(k,ci));
  if suma ~= 0
   d(ci) = d(ci) + A(i,k) * A(k,ci)' / suma;
  end
 end
 Weight(i,ci) = -d(ci)' / d(i);
end

Weight = sparse(Weight);
p = [sort(f) sort(c)];
dimf = length(f);
Wp = Weight(p,p);
Weight = Wp(1:dimf,dimf+1:n);





