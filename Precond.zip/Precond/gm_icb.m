function [D,L,D1] = gm_icb(A,tb);
%GM_ICB block incomplete Cholesky decomposition IC(0) of a sparse matrix

% Input:
% A = symmetric matrix
% tb = block size

% L * D * L' with D matrix and L unit lower triangular
% D is a block diagonal matrix

%
% Author G. Meurant
% July 2006
%

n = size(A,1);
B = A;
L = sparse(n,n);
D = sparse(n,n);
D1 = sparse(n,n);

% number of blocks
nb = n / tb;
if rem(n,tb) ~= 0
 error('gm_icb: Wrong block size, it has to divide the order of A exactly')
end

for kk = 1:nb-1
 k = (kk - 1) * tb + 1;
 ktb = k + tb - 1;
 m = size(B,1);
 BB = B(1:tb,1:tb);
 B1 = inv(BB);
 Al = A(ktb+1:n,k:ktb);
 indl = find(Al);
 Sl = sparse(m-tb,tb);
 BBl = B(tb+1:m,1:tb);
 Sl(indl) = BBl(indl);
 Sl = Sl * B1;
 Su = Sl';
 L(ktb+1:n,k:ktb) = Sl;
 L(k:ktb,k:ktb) = speye(tb);
 D(k:ktb,k:ktb) = BB;
 D1(k:ktb,k:ktb) = B1;
 % Schur complement
 BC = B(tb+1:m,tb+1:m);
 BC = BC - Sl* BB * Su;
 B = BC;
end

L(n-tb+1:n,n-tb+1:n) = speye(tb);
D(n-tb+1:n,n-tb+1:n) = B;
D1(n-tb+1:n,n-tb+1:n) = inv(B);


