function x=gm_matsmooth(A,M,b,x0,nu);
%GM_MATSMOOTH  Richardson smoothing with A

% nu iterations

%
% Author G. Meurant
% Sept 2000
%

x = x0;

for i = 1:nu
 r = b - A * x;
 z = M * r;
 x = x + z;
end

