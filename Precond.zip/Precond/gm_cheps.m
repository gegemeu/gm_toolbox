function [d,L]=gm_cheps(A,epsdrop);
%GM_CHEPS Incomplete Cholesky decomposition of a symmetric sparse matrix with threshold 

%
% epsdrop = threshold for dropping elements
% d is a vector and L lower triangular with a unit diagonal

%
% Author G. Meurant
% March 2001
%
 
n = size(A,1);
B = A;
L = sparse(n,n);
d = zeros(n,1);
 
% norm of each row of A
anorm = zeros(1,n);
for i = 1:n
 anorm(i) = norm(A(i,:),inf);
end

for k = 1:n-1
 m = size(B,1);
 b1 = 1 / B(1,1);
 ii = find(B(:,1));
 sl = sparse(ii,1,B(ii,1)*b1,m,1);
 L(k:n,k) = sl;
 % dropping strategy
 i = find(abs(L(k+1:n,k)) ./ anorm(k+1:n)' <= epsdrop);
 L(i+k,k) = zeros(length(i),1);
 L(k,k) = 1;
 d(k) = B(1,1);
 % Schur complement
 ind = find(L(k+1:n,k))';
 sl = sl(2:m);
 BB = B(2:m,2:m);
 for i = ind
  BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
 end
 B = BB;
end
L(n,n) = 1;
d(n) = B(1,1);
% d=d';

