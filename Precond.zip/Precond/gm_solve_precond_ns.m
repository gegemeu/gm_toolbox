function z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
%GM_SOLVE_PRECOND_NS solves M z = r, nonsymmetric case

% M is the nonsymmetric preconditioner defined by 'precond'

% cprec, cpre_amg = cell arrays computed in gm_init_precond

%
% Author G. Meurant
% January 2025
%

if strcmpi(precond,'ml') ~= 1 
 % cprec = {D, L, U};
 D = cprec{1};
 L = cprec{2};
 U = cprec{3};
end % if
 
 switch precond
  case 'no'
   z = r;
   
  case 'sc'
   z = D * r;
   
  case {'ss','lu','gs'}
   y = L \ r;
   z  = U \ (D * y);
   
  case 'lb'
   y = L \ r;
   z  = U \ (D * y);
   
  case  'gp'
   z = L \ r;
   
  case 'im'
   z = L * r;
   
  case 'ai'
   z = L * D * U * r;
   
  case {'tw', 'sp'}
   z = L * r;
   
  case {'sh', 'wl'}
   y = L \ r;
   z = U \ y;
   
  case {'lm', 'ld'}
   y = L \ (D * r);
   z = U \ y;
   
  case 'gm'
   nitmax = fix(D(1,1));
   n = size(A,1);
   x0 = zeros(n,1);
   [z,nitg,iret,resng,resngt,time_matg] = gm_GMRESm_prec(A,r,x0,1e-20,nitmax,n/10,'left','reorth','noscaling','notrueres','noprint','gs',0);
   
  case 'ml'
   
   % cprec_amg = {xin, nu, 1, cA, cM, cP, cR, cperm, ciperm, cdf, cZb, cDb, cL, cda, lmax, smooth, gama, normal, tb};
   xin = cprec_amg{1};
   nu = cprec_amg{2};
   level = cprec_amg{3};
   cA = cprec_amg{4};
   cM = cprec_amg{5};
   cP = cprec_amg{6};
   cR = cprec_amg{7};
   cperm = cprec_amg{8};
   ciperm = cprec_amg{9};
   cS = cprec_amg{10};
   cw = cprec_amg{11};
   cdf = cprec_amg{12};
   cL = cprec_amg{13};
   cU = cprec_amg{14};
   cd = cprec_amg{15};
   cda = cprec_amg{16};
   lmax= cprec_amg{17};
   smooth = cprec_amg{18};
   gam = cprec_amg{19};
   normal = cprec_amg{20};
   
   % multilevel preconditioner
   z = gm_amg_ns_it(A,r,xin,nu,level,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    
   
  otherwise
   
   error('gm_solve_precond: This preconditioner does not exist')
   
 end % switch
 
 z = full(z);
 
 
