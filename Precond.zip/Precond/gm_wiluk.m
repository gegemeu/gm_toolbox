function [LU,bdown] = gm_wiluk(M,klev,varargin);
%GM_WILUK weighted ILU

% Eijkhout's weighted-modification ILU of up to k levels

%
% from Victor Eijkhout (eijkhout@cs.utk.edu), 1998/9;
% edited by G. Meurant
% April 2015
%

if size(varargin) > 0
 diagnostic = deal(varargin{:});
else
 diagnostic = 0;
end

if diagnostic > 0
 fprintf('\n gm_miluk: Constructing wilu(k) preconditioner to %d levels\n',klev);
end

[m,n] = size(M);
[I_M,J_M,S_M] = find(M);
LU = sparse(I_M,J_M,S_M);

% record levels of elements
[I,J,V] = find(LU ~= 0);
Z = sparse(I,J,V,m,n);

% record breakdown points
bd = [];

% degeneracy correction
sigma = .5;
% van der Vorst modification correction
vdv = .95;
% record v-components that have been fixed
fix = zeros(m,1);
% record rows where we can safely fill on the diagonal
dia = ones(m,1);
% record amount of Jennings vs Eijkhout fills
jen = 0;
dis = 0;
% record diagonal fill accepted vs ignored
did = 0;
dig = 0;
% record degenerate modification
dg = 0;

for k = 1:m
 p = LU(k,k);
 I = find(LU(k+1:m,k))'+ k;
 [col,ind] = sort(LU(I,k));
 I = I(ind(size(ind):-1:1));
 if p <= 0,          % if numerical breakdown
  bd = [bd, k];   % record breakdown location
 end
 for i = I
  J = find(LU(k,i+1:n)) + i;
  [row,ind] = sort(LU(k,J));
  J = J(ind(size(ind,2):-1:1));
  mi = 0;
  for j = J
   mij = LU(i,k)*LU(k,j) / p;
   mji = LU(j,k)*LU(k,i) / p;
   f = 0;
   if LU(i,j) ~= 0 | LU(j,i) ~= 0
    f = j;
    el = min(Z(i,j),1 + max(Z(i,k),Z(k,j)));
   else
    rnij = max(Z(i,k),Z(k,j));
    if rnij <= klev
     f = j;
     el = rnij + 1;
    end
   end
   if f  > 0
    LU(i,f) = LU(i,f) - mij;
    Z(i,f) = el;
    LU(f,i) = LU(f,i) - mji;
    Z(f,i) = el;
   else
    pm = sqrt(LU(i,i) * LU(j,j));
    pd = sqrt(LU(i,i) / LU(j,j));
    rhox = abs(mij) / pm;
    rhoy = abs(mji) / pm;
    md = 0;
    fxi = 0;
    fxj = 0;
    fyi = 0;
    fyj = 0;
    if mij < 0,
     fxi = mij;
     jen = jen + 1; % do a Jennings fill
    else
     if fix(j) == 0 | fix(i) == 0 % weighted distributed fill
      dis = dis + 1;
      fix(i) = 1;
      fix(j) = 1;
      if rhox >= 1
       x = sign(mij) * sigma * pm;
       dg = dg + 1;
      else
       x = vdv * mij;
      end
      fxi = x * pd / 2;
      fxj = x / pd / 2;
     else
      dia(i) = 0;
      dia(j) = 0;
     end % unsafe for diagonal fill
    end
    if mji < 0;
     fyj = mji;
     jen = jen + 1; % do a Jennings fill
    else,
     if fix(j) == 0 | fix(i) == 0 % weighted distributed fill
      dis = dis + 1;
      fix(i) = 1;
      fix(j) = 1;
      if rhoy >= 1
       y = sign(mji) * sigma * pm;
       dg = dg + 1;
      else
       y = vdv * mji;
      end
      fyi = y * pd / 2;
      fyj = y / pd / 2;
     else
      dia(i) = 0;
      dia(j) = 0;
     end % unsafe for diagonal fill
    end
    LU(i,i) = LU(i,i) - fxi - fyi;
    LU(j,j) = LU(j,j) - fxj - fyj;
   end
  end
  dia_fill = LU(i,k) * LU(k,i) / p;
  if dia(i) == 1 | dia_fill < 0
   LU(i,i) = LU(i,i) - dia_fill;
   did = did + 1;
  else
   dig = dig + 1;
  end
 end
end

% report degenerate modification
if dg > 0
 fprintf('Degenerate modification in %d places\n',dg)
end
if diagnostic > 0
 fprintf('Fill elimination: %d jennings, %d distributed\n',jen,dis)
 fprintf('Diagonal fill accepted %d, ignored %d times\n\n',did,dig)
end

bdown = size(bd,2);
if diagnostic > 0,
 [I,J,V] = find(M);
 n1 = size(V);
 [I,J,V] = find(LU);
 n2 = size(V);
 fprintf('M/A element ratio: %d\n\n',n2/n1)
 if bdown ~= 0
   fprintf('Breakdown in %d locations\n\n',bdown)
 end
end
