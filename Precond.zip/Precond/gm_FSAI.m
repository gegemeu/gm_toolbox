function [GL,GU] = gm_FSAI(A,SL,SU);
%GM_FSAI factorized approximate inverse, nonsymmetric case

% Input:
% A = matrix
% SL = lower triangular sparse matrix giving the nonzero pattern of GL
%
% Output:
% GL = lower triangular matrix
% GU = upper triangular matrix
%  the approximate inverse is GL GU

%
% Author G. Meurant
% December 2024
%

GL = gm_FSAI_S(A,SL);
GU = gm_FSAI_S(A',SU');
GU = GU';

GAG = GL * A * GU;
D = sparse(diag(1 ./ diag(GAG)));
GU = GU * D;

