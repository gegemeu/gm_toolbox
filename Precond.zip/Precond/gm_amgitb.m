function x = gm_amgitb(A,b,x0,nu,l,cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cL,cda,lmax,smooth,gam,normal,tb);
%GM_AMGITB one cycle of block multi grid AMG iteration

% Input:
% A = symmetric matrix 
% b = right-hand side
% x0 = starting vector
% gam=1 V cycle, gam=2 W cycle

% f and c are the fine and coarse nodes
% the coarse problem is solved recursively and exactly on the coarsest level
% nu is the number of pre and post smoothings steps
% matrices for each level are in cell arrays
% l=1 fine grid, l=lmax coarsest grid

% 
% Author G. Meurant
% Aug 2000
%

if normal == 1
 % normalization
 b = cda{l} .* b;
end

if l == lmax
 % coarsest level, exact solve
 Lt = cL{l};
 y = Lt' \ b;
 x = Lt \ y;
 if normal == 1
  x = cda{l} .* x;
 end
 return
end

% permutation
p = cperm{l};
M = cM{l};
ip = ciperm{l};
prol = cP{l};
dimf = cdf{l};

% smoother
Z = cZ{l};
D = cD{l};

% restriction
res = cR{l};

x = x0;

for j = 1:gam
 
 % nu steps of pre smoothing
 if strcmpi(smooth,'gb') == 1
  x = gm_sgssmoothb(A,Z,b,x,nu,tb);
  
 elseif strcmpi(smooth,'gn') == 1
  x = gm_sgssmoothn(A,Z,b,x,nu,tb);
  
 elseif strcmpi(smooth,'gs') == 1
  x = gm_sgssmooth(A,Z,b,x,nu);
  
elseif strcmpi(smooth,'ib') == 1
  x = gm_icsmoothb(A,Z,D,b,x,nu);
  
elseif strcmpi(smooth,'ic') == 1
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 else
  error('gm_amgitb: smoother not defined')
 end
 
 r = b - A * x;
 % permute x and r
 xp = x(p);
 rp = r(p);
 
 % restrict to the coarse grid
 rc = res * rp;
 
 % recursively solve starting from 0
 Ac = cA{l};
 x0 = zeros(size(Ac,1),1);
 ec = gm_amgitb(Ac,rc,x0,nu,l+1,cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cL,cda,lmax,smooth,gam,normal,tb);
 
 %interpolate back to the fine grid
 e = prol * ec;
 
 % add correction
 xp = xp + e;
 
 % permute x back
 x = xp(ip);
 
 % nu steps of post smoothing
 if strcmpi(smooth,'gb') == 1
  x = gm_sgssmoothb(A,Z,b,x,nu,tb);
  
 elseif strcmpi(smooth,'gn') == 1
  x = gm_sgssmoothn(A,Z,b,x,nu,tb);
  
 elseif strcmpi(smooth,'gs') == 1
  x = gm_sgssmooth(A,Z,b,x,nu);
  
elseif strcmpi(smooth,'ib') == 1
  x = gm_icsmoothb(A,Z,D,b,x,nu);
  
elseif strcmpi(smooth,'ic') == 1
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 else
  error('gm_amgitb: smoother not defined')
 end
 
end

if normal == 1
 x = cda{l} .* x;
end

