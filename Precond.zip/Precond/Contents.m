% PRECOND
%
% Files
%   gm_ainv         - sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
%   gm_ainv_ns      - sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
%   gm_ainvn2       - sparse approximate inverse of Benzi and Tuma (SISSC 97),
%   gm_ainvn4       - sparse approximate inverse of Benzi and Tuma (SISSC 97),
%   gm_ainvq2_ns    - sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
%   gm_ainvq_ns     - sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
%   gm_aismooth     - AINV Richardson smoothing for AMG
%   gm_amg_init     - init of multi level preconditioner
%   gm_amg_initb    - init of block multi level preconditioner
%   gm_amg_ns_init  - init of non symmetric multi level preconditioner
%   gm_amg_ns_it    - one cycle of multilevel AMG iteration with several smoothers 
%   gm_amgit        - one cycle of multi grid amg iteration with several smoothers (gs, ic, ainv,...)
%   gm_amgitb       - one cycle of block multi grid AMG iteration with several smoothers (gs, ic,..)
%   gm_cgbj         - conjugate gradient smoothing with block diagonal preconditioner
%   gm_cgsm         - conjugate gradient smoothing with diagonal preconditioner 
%   gm_cgsmoo       - conjugate gradient smoothing with AINV preconditioner 
%   gm_cheps        - incomplete Cholesky decomposition of a symmetric sparse matrix with threshold 
%   gm_chic         - incomplete Cholesky decomposition of a symmetric sparse matrix, same structure as A 
%   gm_chlev        - incomplete Cholesky decomposition of a symmetric sparse matrix by levels
%   gm_choic        - incomplete Cholesky decomposition of a symmetric sparse matrix
%   gm_cismooth     - Richardson smoothing with IC for AMG
%   gm_coarsencljp  - CLJP coarsening algorithm, find the fine and coarse nodes
%   gm_coarsenfalg  - Falgout coarsening algorithm, find the fine and coarse nodes
%   gm_coarsenhmis  - HMIS coarsening algorithm, find the fine and coarse nodes
%   gm_coarsenm2    - find the fine and coarse nodes: my own algorithm
%   gm_coarsenp     - variant of the parallel LLNL coarsening algorithm (Falgout and al)
%   gm_coarsenp1    - variant of the parallel LLNL coarsening algorithm  (Falgout & consort)
%   gm_coarsenpmis  - PMIS coarsening algorithm, find the fine and coarse nodes
%   gm_coarsenstin  - find the fine and coarse nodes algorithm mainly for 'im' and 'iz' interpolations 
%   gm_coarsenstmz  - standard AMG coarsening algorithm + check for A
%   gm_coarsenstn1  - standard AMG coarsening + addition of a few coarse nodes
%   gm_coarsenstnew - standard AMG coarsening algorithm, find the fine and coarse nodes
%   gm_coarsno      - find the coarse nodes and neigbours of i in S
%   gm_coarsno1     - find the coarse nodes and neigbours of i in S
%   gm_coarsno2     - find the coarse, fine nodes and neigbours of i in S
%   gm_enermin      - computes the energy minimizing interpolation
%   gm_evmcarre     - least squares polynomial times r
%   gm_gssmooth     - Gauss-Seidel smoothing for AMG
%   gm_ic           - incomplete point Cholesky factorization with the same structure as A
%   gm_icb          - block incomplete Cholesky decomposition IC(0) of a sparse matrix
%   gm_iceps        - computes the incomplete Cholesky decomposition IC without fill 
%   gm_icsmooth     - Richardson smoothing with IC for AMG
%   gm_icsmoothb    - Richardson smoothing with block IC
%   gm_ind_set      - finds an independent set 
%   gm_influ        - influence matrix of A
%   gm_influin      - influence matrix of M
%   gm_influm       - influence matrix of A, = 1 when |A(i,j)| > 0 
%   gm_influmt      - influence matrix of A, |a(i,j)| > 0, q largest elements
%   gm_influst      - influence matrix of A, standard AMG
%   gm_influstb1    - influence matrix of A standard AMG choice
%   gm_influstbl    - block influence matrix of A
%   gm_initprec     - computes many preconditioners for CG
%   gm_initprecns   - computes preconditioners for a non symmetric A
%   gm_lui          - incomplete LU decomposition LU(0) without pivoting of a sparse matrix
%   gm_luib         - block incomplete LU decomposition LU(0) without pivoting of a sparse matrix 
%   gm_lusmooth     - Richardson smoothing for 'gs', 'lu', etc...
%   gm_matsmooth    - Richardson smoothing with A
%   gm_miluk        - Manteuffel ILU factorization 
%   gm_msmooth      - Richardson smoothing for AMG with M
%   gm_neighb       - find the neigbours for i in the graph of S
%   gm_neighb1      - find the neigbours for i in the graph of S
%   gm_neighboset   - set of the nodes which are at distance k from node i
%   gm_neighbs      - find the neigbours for i in the graph of S
%   gm_neighbset    - set of the nodes which are at distance k of node i 
%   gm_normfrob1    - returns the matrix of the Frobenius norms of the blocks of A
%   gm_plotgrids1   - plots the AMG coarse meshes on the graph for a square mesh
%   gm_plotsq       - plots a filled red square at position x,y
%   gm_plotsqg      - plots a filled green square at position x,y
%   gm_polsmooth    - Richardson smoothing with polynomial preconditioner
%   gm_prodprec     - computes z = M r
%   gm_ptindex      - computes the point index from the block index in block AMG
%   gm_pts          - translates the block influence matrix S to point form
%   gm_sainv        - CGML_SAINV sparse approximate inverse of Benzi (SISSC 97), stabilized
%   gm_sainvn2      - sparse approximate inverse of Benzi and Tuma (SISSC 97),
%   gm_sainvn4      - sparse approximate inverse of Benzi and Tuma (SISSC 97),
%   gm_saismooth    - SAI Richardson smoothing for AMG
%   gm_saitw        - sparse approximate inverse of A by Tang ang Wan
%   gm_sgssmooth    - symmetric Gauss Seidel smoothing for AMG
%   gm_sgssmoothb   - Symmetric block Gauss-Seidel smoothing 
%   gm_sgssmoothn   - block Gauss-Seidel smoothing 
%   gm_solveprec    - solves M z = r
%   gm_solveprecns  - solves M z = r
%   gm_trilb        - block lower triangular part of A with blocks of order tb
%   gm_wagint       - computes the interpolation weights inspired by Wagner's interpolation
%   gm_wght         - weights from the influence matrix S
%   gm_wght1        - weights from the matrix A (approximate inverse)
%   gm_wght_cljp    - weights for the (modified) CLJP algorithm
%   gm_wght_r       - random weights for the CLJP and PMIS algorithms
%   gm_wiluk        - weighted ILU
%   gm_winterp      - computes the interpolation weights, standard AMG interpolation
%   gm_wintinv      - computes the interpolation weights using AINV interpolation
%   gm_wmeur        - computes the interpolation weights, Meurant's algorithm
