function [cprec,cprec_amg] = gm_init_precond_ns(A,precond,iprint,params);
%GM_INIT_PRECOND_NS initialization of nonsymmetric preconditioners

% Input:
% A = matrix
% precond = type of preconditioner
% = 'no' M = I
% = 'sc' diagonal
% = 'gs' Gauss-Seidel
% = 'ss' SSOR like
% = 'lu' Incomplete LU(0)
% = 'lm' Matlab ILU(0)
% = 'ld' Matlab ILU with drop threshold
% = 'lb' block ILU
% = 'ai' approximate inverse AINV
% = 'tw' Tang and Wang approximate inverse
% = 'sp' SPAI approximate inverse (Huckle and Grote)
% = 'sh' or 'wl' ILU factorizations from V. Eijkhout
% = 'gp' given preconditioner 
% = 'im' given inverse of preconditioner
% = 'gm' GMRES iterations

% iprint = 1, printing

% params = structure giving the parameter(s) needed by some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'lu', and 'ic'
%  = epsilon for 'ld'
%  = level for 'sh', 'wl'
%  = block size for 'lb'
%  = nb of GMRES iterations for 'gm'
%  = matrix M for 'gp'

% params.p1 and params.p2 
%  = threshold and number of nonzero entries  in a column for 'ai'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' are in params as (default)
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)
%
% Output;
% cell arrays needed for the solution of M z = r

%
% Author G. Meurant
% January 2025
%

n = size(A,1);

if nargin == 1
 precond = 'no';
 iprint = 0;
 params = [];
end % if
if nargin == 2
 iprint = 0;
 params = [];
end % if
if nargin == 3
 params = [];
end % if

switch precond
 
case 'no'
 % no preconditioning
 D = speye(n);
 L = speye(n);
 U = speye(n);
 cprec = {D, L, U};
 cprec_amg = {};
 
case 'sc'
 % diagonal preconditioning
 dd = 1 ./ diag(A);
 if sum(isinf(dd)) > 0
  error('gm_init_precond_ns: There are zeros on the diagonal of A')
 end
 D = spdiags(dd,0,n,n);
 L = speye(n);
 U = speye(n);
 cprec = {D, L, U};
 cprec_amg = {};
 
case 'ss'
 %  SSOR = L D^{-1} U with D diag of A
 L = tril(A);
 dd = 1 ./ diag(A);
  if sum(isinf(dd)) > 0
  error('gm_init_precond_ns: There are zeros on the diagonal of A')
 end
 D = spdiags(dd,0,n,n);
 U = triu(A);
 cprec = {D, L, U};
 cprec_amg = {};
 
case 'gs'
 %  Gauss-Seidel = L  with L lower part of A
 L = tril(A);
 D = speye(n);
 U = speye(n);
 cprec = {D, L, U};
 cprec_amg = {};
 
case 'lu'
 % Incomplete LU with the same structure as A
 % computes L D U with diag(L,U)=1
 % send back D^{-1}
 [d,L,U] = gm_lui(A);
 ind = find(d == 0);
 if length(ind) > 0
  error('gm_init_precond_ns: Pb with the incomplete factorization')
 end
 D = spdiags(1./d,0,n,n);
 cprec = {D, L, U};
 cprec_amg = {};
 
 case 'lb'
 % Incomplete block LU with the same structure as A
 % computes L D U with diag(L,U)=1
 % send back D^{-1}
 if isempty(params)
   tb = 1;
  else
   tb = params.p1;
  end % if
  if iprint == 1
   fprintf('  block size = %d \n',tb)
  end % if
 if isempty(tb)
  error('gm_init_precond_ns: Error, the block size tb was not provided')
 end
 if rem(n,tb) ~= 0
  error('gm_init_precond_ns: Error, the block size has to divide exactly the dimension of A')
 end
 [D,L,U,D1] = gm_luib(A,tb);
 D = D1;
 cprec = {D, L, U};
 cprec_amg = {};
 
 case {'gp', 'im'}
  % given preconditioner
  D = speye(n);
  U = speye(n);
  if isempty(params)
   error('gm_init_precond_ns: There must be a matrix')
  end % if
  L = params.p1;
  if size(L,1) ~= n
   error('gm_init_precond_ns: Error, M has to be of the same order as A')
  end % if
  cprec = {D, L, U};
  cprec_amg = {};
 
 case 'ai'
  % AINV factorization, keep only the q largest elements
  if isempty(params)
   alp = 0.01;
   q = 10;
  else
   alp = params.p1;
   q = params.p2;
  end % if
  if iprint == 1
   fprintf('  threshold = %g, q = %d \n',alp,q)
  end % if
  % use eventually a shifted matrix
  bet = 0; % shift
  beta = bet * max(max(abs(A)));
  As = A + beta * speye(n);
  [L,U,pa] = gm_ainvq_ns(As,alp,q);
  D = spdiags(pa,0,n,n);
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'tw'
  % Tang and Wan approximate inverse 
  % could eventually increase the number of levels in gm_saitw
  if isempty(params)
   k = 0;
   l = 1;
  else
   k = params.p1;
   l = params.p2;
  end % if
  if iprint == 1
   fprintf('  k = %d, l = %d \n',k,l)
  end % if
  L = gm_saitw(A,k,l);
  U = [];
  D = [];
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'sh'
  % Incomplete factorization of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  % alb = number of levels, must be an integer
  if isempty(params)
   alb = 2;
  else
   alb = params.p1;
  end % if
  if iprint == 1
   fprintf('  level = %d \n',alb)
  end % if
  [LU,bdown] = gm_miluk(A,alb,3);
  L = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  U = triu(LU);
  D = [];
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'wl'
  % Weighted incomplete Cholesky of Eijkhout with levels
  % IC(level) of a general matrix
  % alb must be an integer
  if isempty(params)
   alb = 2;
  else
   alb = params.p1;
  end % if
  if iprint == 1
   fprintf('  level = %d \n',alb)
  end % if
  [LU,bdown] = gm_wiluk(A,alb);
  L = speye(n,n) + tril(LU,-1) * diag(1 ./ diag(LU));
  U = triu(LU);
  D = [];
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'lm'
  % Matlab built-in incomplete LU(0)
  %   [L,U,D] = luinc(sparse(A),opts); % old versions of Matlab
  opts.type = 'nofill';
  opts.udiag = 1;
  [L,U] = ilu(sparse(A),opts);
  D = speye(n,n);
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'ld'
  % Matlab built-in incomplete LU(droptol)
  if isempty(params)
   tb = 0.01;
  else
   tb = params.p1;
  end % if
  if iprint == 1
   fprintf('  threshold = %g \n',tb)
  end % if
  opts.droptol = tb;
  opts.type = 'ilutp';
  %   [L,U,D] = luinc(sparse(A),opts); % old versions of Matlab
  opts.udiag = 1;
  [L,U] = ilu(sparse(A),opts);
  D = speye(n,n);
  cprec = {D, L, U};
  cprec_amg = {};
  
 case 'gm'
  % some GMRES iterations
  if isempty(params)
   m = 5;
  else
   m = params.p1;
  end % if
  if iprint == 1
   fprintf('  nb. iter = %d \n',m)
  end % if
  D = speye(n);
  D(1,1) = m;
  L = [];
  U = [];
  cprec = {D, L, U};
  cprec_amg = {};
  
  case 'sp'
  % SPAI approximate inverse symmetrized
  % epss = ceil(nnz(A) / n);
  if isempty(params)
   epss = 0.01;
   nzk = min(10,n);
  else
   epss = params.p1;
   nzk = params.p2;
  end % if
  if iprint == 1
   fprintf('  threshold = %g, nzk = % d \n',epss,nzk)
  end % if
  L = gm_SPAI(A,epss,nzk);
  D = [];
  U = [];
  cprec = {D, L, U};
  cprec_amg = {};
  
  case 'ml'
  % algebraic multigrid
  if isempty(params)
   % defaults for AMG
   lmax = 10;
   nu = 1;
   alpmax = 0.1;
   alb = 0.1;
   smooth = 'gs';
   infl = 'b';
   coarse = 'st';
   interpo = 'st';
   qmin = n;
   falp = 1;
   alq = 1;
   normal = 0;
   gama = 1;
   xin = zeros(n,1);
   
  else
   % get the input parameters for the multilevel AMG method
%    if length(fieldnames(params)) < 9
%     error('gm_init_precond_ns: Some parameters are not defined for ML')
%    end
   
   if isfield(params,'lmax')
    lmax = params.lmax;
   else
    lmax = 10;
   end % if
   if isfield(params,'nu')
    nu = params.nu;
   else
    nu = 1;
   end % if
   if isfield(params,'alpmax')
    alpmax = params.alpmax;
   else
    alpmax = 0.1;
   end % if
   if isfield(params,'alb')
    alb = params.alb;
   else
    alb = 2;
   end % if
   if isfield(params,'smooth')
    smooth = params.smooth;
   else
    smooth = 'gs';
   end % if
   if isfield(params,'infl')
    infl = params.infl;
   else
    infl = 'b';
   end % if
   if isfield(params,'coarse')
    coarse = params.coarse;
   else
    coarse = 'st';
   end % if
   if isfield(params,'interpo')
    interpo = params.interpo;
   else
    interpo = 'st';
   end % if
   if isfield(params,'qmin')
    qmin = params.qmin;
   else
    qmin = n;
   end % if
   gama = 1;
   falp = 1;
   alq = 1;
   normal = 0;
   xin = zeros(n,1);
   
  end % if
  
  if iprint == 1
   fprintf('\n -----------multilevel parameters \n')
   fprintf(' lmax = %d \n',lmax)
   fprintf(' nu = %d \n',nu)
   fprintf(' alpmax = %g \n',alpmax)
   fprintf(' alb = %g \n',alb)
   fprintf(' smooth = %s \n',smooth)
   fprintf(' infl = %s \n',infl)
   fprintf(' coarse = %s \n',coarse)
   fprintf(' interpo = %s \n',interpo)
   if gama == 1
    fprintf(' V-cycle \n')
   else
    fprintf(' W-cycle \n')
   end % if
  end % if
  
  % multilevel preconditioner
  [cA,cM,cP,cR,cPerm,ciPerm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
   smooth,infl,coarse,interpo,normal,iprint);
  if err == 1
   fprintf('\n gm_init_precond_ns: Error in gm_amg_init \n')
   return
  end % if
  cprec = {};
  cprec_amg  = {xin, nu, 1, cA, cM, cP, cR, cPerm, ciPerm, cS, cw, cdf, cL, cU, cd, cda, lmax, smooth, gama, normal};
  

otherwise
 error('gm_init_precond_ns: Error, the given preconditioner does not exist')
end

