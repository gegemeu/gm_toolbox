function [ci,indi]=gm_coarsno(S,w,i);
%GM_COARSNO find the coarse nodes and neigbours of i in S
% w = -100 for coarse nodes
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

indi = find(abs(S(i,:)) > 0);
% this is useless if S is an influence matrix
indi = gm_setdiff(indi,i);
if length(indi) ~= 0
 wi = w(indi);
 indci = find(wi == -100);
 if length(indci) ~= 0
  ci = indi(indci);
 else
  ci = [];
 end
else
 indi = [];
 ci = [];
end


