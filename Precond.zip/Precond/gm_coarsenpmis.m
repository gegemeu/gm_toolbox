function [f,c,w]=gm_coarsenpmis(A,S);
%GM_COARSENPMIS PMIS coarsening algorithm, find the fine and coarse nodes

% Input:
% A = matrix
% S = influence matrix for A

% wght computes the initial weights
% f (c) = list of the fine (coarse) nodes
% w = final weights for viz
%   =-100 for coarse nodes, -50 for fine nodes
%

%
% author G. Meurant
% Mar 2009
% Updated March 2015
%

f = [];
c = [];

n = size(S,1);

% use the same weights as in CLJP
%w = gm_wght_cljp(A,S);
% randomized weights
w = gm_wght_r(A,S);
dim = 0;

ind = [];
for i = 1:n
 indi = find(S(:,i) == 0);
 if length(indi) == 0
  ind = [ind i];
 end % if
end % for i

% flag these nodes as fines
if length(ind) > 0
 f = [f ind];
 w(ind) = -50;
 dim = dim + length(ind);
end

while dim < n
 % find an independent set of nodes
 isn = gm_ind_set(w,S);

 if length(isn) == 0
  % flag the remaining nodes as fine if not all their neighbours are fine
  ind = find(w > -50);
  indc = [];
  indf = [];
  for ii = 1:length(ind)
   i = ind(ii);
   % use S instead for interpolation
   ineighb = gm_neighb1(S,i);
   sw = sum(w(ineighb));
   if sw == -50 * length(ineighb)
    indc = [indc i];
   else
    indf = [indf i];
   end
  end
  
  w(indc) = -100;
  c = [c indc];
    
  w(indf) = -50;
  f = [f indf];
  dim = dim + length(ind);
  
 else
  % flag the nodes in the set as coarse
  w(isn) = -100;
  % c = c U {i}
  c = [c isn];
  dim = dim + length(isn);
  
  indf = [];
  for ii = 1:length(isn)
   i = isn(ii);
   % find nodes j such that i in S_j
   % neighbours of i
   ineighb = gm_neighb(A,i);
   ineighb = gm_setdiff(ineighb,[i]);
   for jj = 1:length(ineighb)
    j = ineighb(jj);
    sj = find(S(j,:) > 0);
    for kk = 1:length(sj)
     k = sj(kk);
     if k == i & w(j) > -50 
      indf=[indf j];
      break
     end
    end % for k
   end % for j
  end % for i
  indf = unique(indf);
  
  f = [f indf];
  w(indf) = -50;
  dim = dim + length(indf);
  
  % remove isn and indf from the graph
  ind = [isn indf];
  for ii = 1:length(ind)
   i = ind(ii);
   S(i,:) = 0;
   s(:,i) = 0;
  end
  
 end % if isn
   
end % while





