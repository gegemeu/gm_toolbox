function x = gm_amgit(A,b,x0,nu,l,cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cL,cda,lmax,smooth,gam,normal);
%GM_AMGIT one cycle of multi grid amg iteration 

% Input:
% A = non symmetric matrix 
% b = right-hand side
% x0 = starting vector
% gam=1 V cycle, gam=2 W cycle

% the arguments are defined in gm_amg_ns_init
% f and c are the fine and coarse nodes
% the coarse problem is solved recursively and exactly on the coarsest level
% nu is the number of pre and post smoothings steps
% matrices for each level are in cell arrays
% l = 1 fine grid, l = lmax coarsest grid

% 
% Author G. Meurant
% Aug 2000
%

if normal == 1
 % normalization
 b = cda{l} .* b;
end

if l == lmax
 % coarsest level, exact solve
 Lt = cL{l};
 y = Lt' \ b;
 x = Lt \ y;
 if normal == 1
  % rescale
  x = cda{l} .* x;
 end
 return
end

% permutation
p = cperm{l};
M = cM{l};
% inverse permutation
ip = ciperm{l};
% interpolation matrix
prol = cP{l};
dimf = cdf{l};

% smoother
Z = cZ{l};
D = cD{l};

% restriction
res = cR{l};
x = x0;

for j = 1:gam
 % nu steps of pre smoothing
 
 if strcmpi(smooth,'gs')
  x = gm_sgssmooth(A,Z,b,x,nu);
  
 elseif strcmpi(smooth,'ga')
  x = gm_gssmooth(A,b,x,nu);
  
 elseif strcmpi(smooth,'ic')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'ci')
  x = gm_cismooth(A,Z,b,x,nu);
  
 elseif strcmpi(smooth,'ch')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'lv')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'sh')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'ai')
  x = gm_aismooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'sa')
  x = gm_aismooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'tw')
  x = gm_saismooth(A,M,b,x,nu);
  
 elseif strcmpi(smooth,'cg')
  x = gm_cgsmoo(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'gc')
  x = gm_cgsm(A,D,b,x,nu);
  
 elseif strcmpi(smooth,'bj')
  x = gm_cgbj(A,D,b,x,nu);
  
 elseif strcmpi(smooth,'po')
  lmi = cZ{l};
  lma = cD{l};
  x = gm_polsmooth(A,M,b,x,nu,lmi,lma);
  
 elseif strcmpi(smooth,'ma')
  x = gm_matsmooth(A,M,b,x,nu);
  
 else
  error('gm_amgit: smoother not defined')
 end
 
 r = b - A * x;
 % permute x and r
 xp = x(p);
 rp = r(p);
 
 % restrict to the next coarsest grid
 rc = res * rp;
 
 % recursively solve starting from 0
 Ac = cA{l};
 x0 = zeros(size(Ac,1),1);
 ec = gm_amgit(Ac,rc,x0,nu,l+1,cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cL,cda,lmax,smooth,gam,normal);
 
 % interpolate back to the fine grid
 e = prol * ec;
 
 % add correction
 xp = xp + e;
 
 % permute x back
 x = xp(ip);
 
 % nu steps of post smoothing
 if strcmpi(smooth,'gs')
  x = gm_sgssmooth(A,Z,b,x,nu);
  
 elseif strcmpi(smooth,'ga')
  x = gm_gssmooth(A,b,x,nu);
  
 elseif strcmpi(smooth,'ic')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'ci')
  x = gm_cismooth(A,Z,b,x,nu);
  
 elseif strcmpi(smooth,'ch')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'lv')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'sh')
  x = gm_icsmooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'ai')
  x = gm_aismooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'sa')
  x = gm_aismooth(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'tw')
  x = gm_saismooth(A,M,b,x,nu);
  
 elseif strcmpi(smooth,'cg')
  x = gm_cgsmoo(A,Z,D,b,x,nu);
  
 elseif strcmpi(smooth,'gc')
  x = gm_cgsm(A,D,b,x,nu);
  
 elseif strcmpi(smooth,'bj')
  x = gm_cgbj(A,D,b,x,nu);
  
 elseif strcmpi(smooth,'po')
  lmi = cZ{l};
  lma = cD{l};
  x = gm_polsmooth(A,M,b,x,nu,lmi,lma);
  
 elseif strcmpi(smooth,'ma')
  x = gm_matsmooth(A,M,b,x,nu);
 
 else
  error('gm_amgit: smoother not defined')
 end
end

if normal == 1
 x = cda{l} .* x;
end

