function [d,L]= gm_chlev(A,levmax);
%GM_CHLEV Incomplete Cholesky decomposition of a symmetric sparse matrix by levels

% Input:
% A = symmetric matrix

% L diag(d) L' with d vector and L unit lower triangular

%
% Author G. Meurant
% March 2001
%
 
n = size(A,1);
B = A;
L = sparse(n,n);
d = zeros(n,1);

levm = 100;
Lev = spones(A);

for k = 1:n-1
 m = size(B,1); 
 b1 = 1 / B(1,1);
 ii = find(B(:,1));
 sl = sparse(ii,1,B(ii,1)*b1,m,1);
 L(k:n,k) = sl;
 % dropping strategy
 i = find(Lev(2:end,1) > levmax);
 L(i+k,k) = zeros(length(i),1);
 Lev(i+1,1) = levm * ones(length(i),1);
 L(k,k) = 1;
 d(k) = B(1,1);
 % Schur complement
 Level = Lev;
 ind = find(L(k+1:n,k))';
 sl = sl(2:m);
 BB = B(2:m,2:m);
 Lev = Level(2:m,2:m);
 % do not take care of symmetry (faster)
 for i = ind
  BB(i,ind) = BB(i,ind) - B(1,1) * sl(i) * sl(ind)';
  j = find(B(i+1,:)~=0) - 1;
  indj = gm_fmt(ind,j);
  ll = Level(i+1,1);
  Lev(i,indj) = ll + Level(indj+1,1)';
 end
 B = BB;
end
L(n,n) = 1;
d(n) = B(1,1);
% d=d';
 