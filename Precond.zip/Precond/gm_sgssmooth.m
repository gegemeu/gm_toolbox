function x = gm_sgssmooth(A,Dl,b,x0,nu);
%GM_SGSSMOOTH symmetric Gauss Seidel smoothing for AMG

% Input:
% A = matrix
% Dl = lower triangular part of A
% b = right-hand side
% x0 = starting vector
% nu = number of iterations

%
% Author G. Meurant
% Aug 2000
%

x = x0;
Lt = triu(A,1);
Dlt = Dl';
L = tril(A,-1);

for i = 1:nu
 x = Dl \ (b - Lt * x);
 x = Dlt \ (b - L * x);
end


