function x=gm_sgssmooth(A,Dl,b,x0,nu);
%GM_SGSSMOOTH symmetric Gauss Seidel smoothing for AMG

% nu iterations starting from x0
% Dl contains the lower triangular part of A

%
% Author G. Meurant
% Aug 2000
%

x = x0;
Lt = triu(A,1);
Dlt = Dl';
L = tril(A,-1);

for i = 1:nu
 x = Dl \ (b - Lt * x);
 x = Dlt \ (b - L * x);
end


