function x=gm_aismooth(A,Z,d,b,x0,nu);
%GM_AISMOOTH AINV Richardson smoothing for AMG

% nu iterations
% the preconditioner is M = Z D Z'
% d is a vector which contains the diagonal of D

%
% Author G. Meurant
% Aug 2000
%

x = x0;

for i = 1:nu
 x = x + Z * (d .* (Z' * (b - A * x)));
end

