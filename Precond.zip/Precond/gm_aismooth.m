function x = gm_aismooth(A,Z,d,b,x0,nu);
%GM_AISMOOTH AINV Richardson smoothing for AMG

% the preconditioner is M = Z D Z

% Input:
% A = symmetric matrix
% Z, d = AINV preconditioner
% d = vector which contains the diagonal of D
% x0 = starting vector
% nu = number of iterations
%
% Output:
% x = result of the smoothing

%
% Author G. Meurant
% August 2000
%

x = x0;

for i = 1:nu
 x = x + Z * (d .* (Z' * (b - A * x)));
end

