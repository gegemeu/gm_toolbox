function M = gm_saitws(A,k,l);
%GM_SAITWS sparse approximate inverse of Tang ang Wan

% Input:
% A = matrix
% k and l defines the neighboring sets that are used for solving the least squares problems

% with symmetrization

%
% Author G. Meurant
% September 2000
%

n = size(A,1);
M = sparse(n,n);

% solve a least squares problem for each row of M

for i = 1:n
 % compute the neighboring sets of degree k and l
 indk = gm_neighbset(A,i,k);
 indl = gm_neighbset(A,i,l);
 
 % extract the matrix
 Akl = A(indk,indl);
 Aklt = Akl';
 se = size(Aklt,1);
 
 % rhs zero everywhere except for i
 rhs = zeros(se,1);
 ii = find( indl == i);
 rhs(ii) = 1;
 
 % solve the normal equation to solve the least squares problems
 mi =( Akl * Aklt) \ (Akl * rhs);
 % this is line i of the approximate inverse
 M(i,indk)=mi';
end % for i

% symmetrize
M = (M + M') / 2;
