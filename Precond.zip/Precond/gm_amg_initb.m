function [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err]=gm_amg_initb(A,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,normal,tb,iprint);
%GM_AMG_INITB init of block multi level preconditioner

% Caution: it does not work for any block size

% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%
% Input
%  matrix = A, rhs = b, init vector = x0
%  truncation coeff = almax for the grid and alb for smoothing
%  max nb levels = lmax
%  smoother = smooth, influence type = influ, coarsening type = coarse
%  interpolation = interpo
%  gama=1 V-cycle, gama=2 W-cycle
%  smooth = smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normalization = normal
%  print level = iprint
%
% Output
%  matrices for each level in cell arrays
% cA = matrix on level l
% cM = preconditioner on level l
% cP = prolongation on level l
% cR = restriction on level l
% cperm = permutation on level l
% ciperm = inverse permutation on level l
% cdf = number of fine nodes on level l
% cZ = factor of the AINV decomposition on level l (coarsening)
% cD = diagonal factor of the AINV dec on level l (coarsening)
% cZb = factor of the AINV decomposition on level l (smoothing)
% cDb = diagonal factor of the AINV dec on level l (smoothing)
% cL = Cholesky factor (for the coarsest level only)

%
% author G. Meurant
% Aug 2006
%

A0 = A;

if normal == 1
 [Ad,da] = gm_normaliz(A);
 cda(1)={da};
else
 cda(1)={[]};
end

err = 0;
done = 0;
alp = alpmax;
alpb = alb;
q = qmin;
nmax = size(A,1);
nnza = nnz(A);
totstr = nnza;
tota = totstr;
totpt = nmax;

% exact solve if less than nmin nodes
nmin = 9;

% ---------------------------------start going down the levels
l = 0;
nnold = nmax;

while done == 0
 n = size(A,1);
 
 if n <= nmin | l == lmax
  % we are on the coarsest level
  if iprint == 1
   fprintf('\n gm_amg_initb: stop the recursion on levels \n')
   fprintf('----------------------------------------------\n\n')
  end
  lmax = l;
  
  if l > 1
   cAa = cA{l-1};
   % compute Cholesky decomposition for the exact solve
   R = chol(cAa);
   cL(l) = {R};
  else
   err = 1;
   return
  end
  if iprint == 1
   fprintf('\n number of levels = %g \n',lmax);
  end
  break
 end
 
 % ----------------------go down the levels
 l=l+1;
 
 % modification to truncate on all levels except the fine one
 %if l == 1
 % q = nmax;
 %else
 % q = qmin;
 %end
 
 % initialize the cell arrays
 cf(l) = {[]};
 cc(l) = {[]};
 cw(l) = {[]};
 cdf(l) = {[]};
 cZ(l) = {[]};
 cD(l) = {[]};
 cP(l) = {[]};
 cA(l) = {[]};
 cM(l) = {[]};
 cL(l) = {[]};
 cZb(l) = {[]};
 cDb(l) = {[]};
 cda(l+1) = {[]};
 zb = [];
 pb = [];
 nz_of_A = nnz(A);

 if iprint == 1
  fprintf('\n---------------- level=%g, n = %g \n',l,n);
  fprintf(' nb of non zero entries = %g \n',nz_of_A);
 end
 
 % construction of the smoother
 
 if strcmpi(smooth,'gs') 
  % Symmetric Gauss-Seidel smoother
  tL = tril(A);
  tU = tL';
  % store the smoother
  cZ(l) = {tL};
  cD(l) = {tU};
  cZb(l) = {tL};
  cDb(l) = {tU};
  nnna(l) = nz_of_A;
  nnnz(l) = 0;
  Za = tL;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'gb') || strcmpi(smooth,'gn')
  % Symmetric block Gauss-Seidel smoother
  % block lower triangular part
  tL = gm_trilb(A,tb);
  tU = tL';
  % store the smoother
  cZ(l) = {tL};
  cD(l) = {tU};
  cZb(l) = {tL};
  cDb(l) = {tU};
  nnna(l) = nz_of_A;
  nnnz(l) = 0;
  Za = tL;
  zAp = A;
  spA = A;
  
 elseif strcmpi(smooth,'ic')
  % Incomplete Cholesky smoother IC(0) of a symmetric matrix
  [dd,LL] = gm_chic(A);
  ind = find(dd < 0);
  if length(ind) ~= 0
   error('gm_amg_initb: Pb with incomplete factorization')
  end
  dd = 1 ./ dd;
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l) = {LL};
  cDb(l) = {dd};
  nnna(l) = nz_of_A;
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp= A;
  spA = A;
   
 elseif strcmpi(smooth,'ib')
  % block Incomplete Cholesky smoother
  % block IC(0) of a general matrix
  [dd,LL,dd1] = gm_icb(A,tb);
  cZ(l) = {LL};
  cD(l) = {dd};
  cZb(l) = {LL};
  cDb(l) = {dd};
  nnna(l) = nz_of_A;
  nnnz(l) = nnz(LL);
  Za = LL;
  zAp= A;
  spA = A;
  
 else
  error('gm_amg_initb: smoother not implemented')
 end
 
 % block influence matrix
 S = gm_influstbl(A,alp,tb);
 % modify the values of parameters for next level
 alp = falp * alp;
 alpb = falp * alpb;
 q = fix(alq * q);
 
 % if there is nothing in S 
 % go up one level and stop the coarsening process
 if nnz(S) == 0 
  if iprint >=1
   fprintf('\n Pb: S is empty %d',nnz(S))
  end
  % go up one level and stop
  if l == 1
   error('gm_amg_initb: cannot go back to level 1')
  else
   lmax = l - 1;
  end
  % need to compute the Cholesky decomposition of the last matrix
  cAa = cA{l-2};
  R = chol(cAa);
  cL(lmax) = {R};
  if iprint == 1
   fprintf('\n after correction final number of levels = %g',lmax);
  end
  break
 end
 
 % promote block S to point form
 S_old = S;
 S = gm_pts(S,tb);
 cS(l) = {S};
 
 % construction of block coarse mesh
 
 if strcmpi(coarse,'st')
  % standard algorithm
  % Note: A is not used in coarsenstnew
  [f,c,w] = gm_coarsenstnew(A,S);
  
 elseif strcmpi(coarse,'cl')
  % (modified) CLJP algorithm
  [f,c,w] = gm_coarsencljp(A,S);
  
 elseif strcmpi(coarse,'pm')
  % PMIS algorithm
  [f,c,w] = gm_coarsenpmis(A,S);
  
 elseif strcmpi(coarse,'hm')
  % HMIS algorithm
  [f,c,w] = gm_coarsenhmis(A,S);
  
 elseif strcmpi(coarse,'fa')
  % Falgout algorithm
  [f,c,w] = gm_coarsenfalg(A,S);
  
 else
  error('gm_amg_initb: this block coarsening algorithm does not exist')
 end
 
 % f and c give the indices of the blocks
 % from this, construct the indices of the points within the blocks
%  [f,c,w] = gm_ptindex(A,f,c,w,tb);
%  % promote block S to point form
%  S = gm_pts(S,tb);
 
 % permutation
 p = [sort(f) sort(c)];
 cperm(l) = {p};
 Ap = A(p,p);
 ip = gm_invperm(p);
 ciperm(l) = {ip};
 dimf = length(f);
 dimc = length(c);
 
 % interpolation
 itp = 0;
 if strcmpi(interpo,'st')
   na = size(A,1);
   AA = sparse(na,na);
   AA(find(S(:))) = A(find(S(:)));
   AA = AA + diag(diag(A));
  % standard AMG interpolation
  weight = gm_winterp(AA,S,f,c,w);
 else
  error('gm_amg_initb: the only available interpolation algorithm is st');
 end
 
 cf(l) = {f};
 cc(l) = {c};
 cw(l) = {w};
 cdf(l) = {length(f)};
 
 % interpolation (prolongation) matrix prol
 if itp == 0 
  prol = [weight ; speye(dimc,dimc)];
 end
 cP(l) = {prol};
 
 % restriction matrix (needs to be symmetric for CG)
 res = prol';
 cR(l) = {res};
 
 % coarse matrix always use Galerkin
 A = res * Ap * prol;
 if normal ==1
  [A,da] = gm_normaliz(A);
 end
 cA(l) = {A};
 if normal == 1
  cda(l+1) = {da};
 end
 nn = length(c);
 
 if (nnold-nn)/nnold <= 0.05
  if iprint == 1
   fprintf('\n not enough difference between two levels, old = %d, new = %d \n',nnold,nn)
  end
  % not enough difference of number of nodes between two consecutive levels
  % solve exactly
  lmax = l;
  nnold = nn;
 else
  nnold = nn;
 end
 
end

if lmax > 0
 
% visualization of the coarse grids (only for 2D grid problems on 
% rectangular domains)
% for other problems comment the next line
%  gm_plotgrids1(A0,cA,cS,cw,lmax,iprint);
 
 stockz = 0;
 stockm = 0; 
 for l = 1:lmax
  P = cP{l};
  D = cDb{l};
  A = cA{l};
  w = cw{l};
  M = cM{l};
  Z = cZb{l};
  nnzn = nnz(Z);
  nnzd = nnz(D);
  if strcmpi(smooth,'gs') || strcmpi(smooth,'po')
   nnzn = 0;
   nnzd = 0;
  end
  if strcmpi(smooth,'tw')
   nnzd = 0;
  end
 
  if iprint == 1
   % statistics
   % total storage for Z and M
   stockz = stockz + nnz(Z);
   stockm = stockm + nnz(M);
   totstr = totstr + nnz(A) + nnzn + nnzd + nnz(P);
   totpt = totpt + size(A,1);
   tota = tota + nnz(A);
   fprintf('\n level %d, n = %d \n',l,size(cZ{l},1));
   fprintf(' storage A = %g, storage Z = %g \n',nnna(l),nnnz(l));
  end
  
 end
 
 if iprint == 1
  sgrid = totpt/nmax;
  sa = tota / nnza;
  fprintf('\n total storage = %g, /n = %g, /nnza = %g, sgrid = %g, sa = %g \n',...
   totstr,totstr/nmax,totstr/nnza,sgrid,sa);
 end
 
end