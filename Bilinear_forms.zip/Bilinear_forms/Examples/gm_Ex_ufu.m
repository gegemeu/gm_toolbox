
% gm_Ex_ufu

% Examples of estimates of u^T fonc(A) u

m = 10;
% Poisson equation matrix, m x m mesh
A = gm_mat_diffu(1,10);
n = size(A,1);

fonc = @log;
sA = logm(full(A));
u = ones(n,1);
entry = u' * sA * u;

eigA = eig(full(A));
lmin = 0.99 * min(eigA);
lmax = 1.01 * max(eigA);

kmax = 20;

[bg,bgrl,bgru,bgl] = gm_bounds_gauss_fu(fonc,A,u,kmax,lmin,lmax);

semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss','Gauss-Radau lower','Gauss-Radau upper','Gauss-Lobatto')
title(['Gauss: Error for the quadratic form'])
hold off


