
% gm_Ex_dtx

% Examples of estimates of d^T inv(A) c

m = 10;
% Poisson equation matrix, m x m mesh
A = gm_mat_diffu(1,10);
n = size(A,1);

c = eye(n,1);
d = ones(n,1);


entry = d' * (A \ c);

eigA = eig(full(A));
lmin = 0.99 * min(eigA);
lmax = 1.01 * max(eigA);

kmax = 20;

[bg,bgrl,bgru,bgl] = gm_bounds_bgauss_rec_dtx(A,d,c,kmax,lmin,lmax);

figure

semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('BGauss','BGauss-Radau l','BGauss-Radau u','BGauss-Lobatto')
title(['BGauss: Error for the bilinear form'])
hold off


[bg,bgrl,bgru,bgl] = gm_bounds_gaussns_dtx(A,d,c,kmax,lmin,lmax);

figure
semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss ns','Gauss-Radau ns lower','Gauss-Radau ns upper','Gauss-Lobatto ns')
title(['Gauss ns: Error for the bilinear form'])
hold off
