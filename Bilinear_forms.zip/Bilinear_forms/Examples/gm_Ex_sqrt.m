
% gm_Ex_sqrt

% Examples of estimates of entries of the square root

m = 10;
% Poisson equation matrix, m x m mesh
A = gm_mat_diffu(1,10);
n = size(A,1);

% sqrt(A)_(j,j)

j = 50;
sA = sqrtm(full(A));
entry = sA(j,j);

eigA = eig(full(A));
lmin = 0.99 * min(eigA);
lmax = 1.01 * max(eigA);

kmax = 40;

[bg,bgrl,bgru,bgl] = gm_bounds_gauss_sqrt(A,j,kmax,lmin,lmax);

semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss','Gauss-Radau lower','Gauss-Radau upper','Gauss-Lobatto')
title(['Gauss: Error for the entry (' num2str(j) ',' num2str(j) ') of the square root'])
hold off

% sqrt(A)_(j,l)

l = 1;
entry = sA(j,l);

[bg,bgrl,bgru,bgl] = gm_bounds_bgauss_sqrt(A,j,l,kmax,lmin,lmax);

figure

bbg = zeros(1,kmax);
bbgrl = bbg;
bbgru = bbg;
bbgl = bbg;
for k = 1:kmax
 bbg(k) = bg(1,2,k);
 bbgrl(k) = bgrl(1,2,k);
 bbgru(k) = bgru(1,2,k);
 bbgl(k) = bgl(1,2,k);
end
semilogy(abs(entry - bbg))
hold on
semilogy(abs(entry - bbgrl),'r')
semilogy(abs(entry - bbgru),'g')
semilogy(abs(entry - bbgl),'m')
legend('BGauss','BGauss-Radau l','BGauss-Radau u','BGauss-Lobatto')
title(['BGauss: Error for the entry (' num2str(j) ',' num2str(l) ') of the square root'])
hold off

% sqrt(A)_(j,j) + sqrt(A)_(j,l)

entry = sA(j,j) + sA(j,l);

[bg,bgrl,bgru,bgl] = gm_bounds_gaussns_sqrt(A,j,l,kmax,lmin,lmax,1);

figure
semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss ns','Gauss-Radau ns lower','Gauss-Radau ns upper','Gauss-Lobatto ns')
title(['Gauss ns: Error for the sums of entries j=' num2str(j) ', l=' num2str(l) ' of the square root'])
hold off


