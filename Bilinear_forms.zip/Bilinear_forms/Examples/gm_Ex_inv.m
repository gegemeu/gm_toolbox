
% gm_Ex_inv

% Examples of estimates of entries of the inverse

m = 10;
% Poisson equation matrix, m x m mesh
A = gm_mat_diffu(1,10);
n = size(A,1);

% inv(A)_(j,j)

j = 50;
ej = zeros(n,1);
ej(j) = 1;
x = A \ ej;
entry = x(j);

eigA = eig(full(A));
lmin = 0.99 * min(eigA);
lmax = 1.01 * max(eigA);

kmax = 40;

[bg,bgrl,bgru,bgl] = gm_bounds_gauss_inv(A,j,kmax,lmin,lmax);

semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss','Gauss-Radau lower','Gauss-Radau upper','Gauss-Lobatto')
title(['Gauss: Error for the entry (' num2str(j) ',' num2str(j) ') of the inverse'])
hold off

% inv(A)_(j,l)

l = 1;
entry = x(l);

[bg,bgrl,bgru,bgl] = gm_bounds_bgauss_inv(A,j,l,kmax,lmin,lmax);

figure

bbg = zeros(1,kmax);
bbgrl = bbg;
bbgru = bbg;
bbgl = bbg;
for k = 1:kmax
 bbg(k) = bg(1,2,k);
 bbgrl(k) = bgrl(1,2,k);
 bbgru(k) = bgru(1,2,k);
 bbgl(k) = bgl(1,2,k);
end
semilogy(abs(entry - bbg))
hold on
semilogy(abs(entry - bbgrl),'r')
semilogy(abs(entry - bbgru),'g')
semilogy(abs(entry - bbgl),'m')
legend('BGauss','BGauss-Radau l','BGauss-Radau u','BGauss-Lobatto')
title(['BGauss: Error for the entry (' num2str(j) ',' num2str(l) ') of the inverse'])
hold off

% inv(A)_(j,j) + inv(A)_(j,l)

entry = x(j) + x(l);

[bg,bgrl,bgru,bgl] = gm_bounds_gaussns_inv(A,j,l,kmax,lmin,lmax,1);

figure
semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss ns','Gauss-Radau ns lower','Gauss-Radau ns upper','Gauss-Lobatto ns')
title(['Gauss ns: Error for the sums of entries j=' num2str(j) ', l=' num2str(l) ' of the inverse'])
hold off
