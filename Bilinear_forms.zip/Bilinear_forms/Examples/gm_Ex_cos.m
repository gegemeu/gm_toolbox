
% gm_Ex_cos

% Examples of estimates of entries of the cosine

m = 10;
% Poisson equation matrix, m x m mesh
A = gm_mat_diffu(1,10);
n = size(A,1);

fonc = @cos;

% cos(A)_(j,j)

j = 50;
cA = gm_cosm(full(A));
entry = cA(j,j);

eigA = eig(full(A));
lmin = 0.99 * min(eigA);
lmax = 1.01 * max(eigA);

kmax = 20;

[bg,bgrl,bgru,bgl] = gm_bounds_gauss_f(fonc,A,j,kmax,lmin,lmax);

semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss','Gauss-Radau lower','Gauss-Radau upper','Gauss-Lobatto')
title(['Gauss: Error for the entry (' num2str(j) ',' num2str(j) ') of the cosine'])
hold off

l = 1;

% cos(A)_(j,j) + cos(A)_(j,l)

entry = cA(j,j) + cA(j,l);

[bg,bgrl,bgru,bgl] = gm_bounds_gaussns_f(fonc,A,j,l,kmax,lmin,lmax,1);

figure
semilogy(abs(entry - bg))
hold on
semilogy(abs(entry - bgrl),'r')
semilogy(abs(entry - bgru),'g')
semilogy(abs(entry - bgl),'m')
legend('Gauss ns','Gauss-Radau ns lower','Gauss-Radau ns upper','Gauss-Lobatto ns')
title(['Gauss ns: Error for the sums of entries j=' num2str(j) ', l=' num2str(l) ' of the cosine'])
hold off


