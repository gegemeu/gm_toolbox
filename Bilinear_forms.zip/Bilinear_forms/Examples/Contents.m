
% Examples of bounds for bilinear forms
% entries of matrix functions

%  gm_Ex_cos  -cosine function
%  gm_Ex_dtx  - d^T inv(A) c
%  gm_Ex_exp  -exponential function
%  gm_Ex_inv  -inverse function
%  gm_Ex_sqrt -square root function
%  gm_Ex_ufu  - u^T f(A) u

