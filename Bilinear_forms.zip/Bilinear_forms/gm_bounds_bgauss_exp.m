function [bg,bgrl,bgru,bgl] = gm_bounds_bgauss_exp(A,j,l,kmax,lmin,lmax);
%GM_BOUNDS_BGAUSS_EXP Gauss block quadrature rules estimates for the entry (j,l) of the exponential of a symmetric matrix 

% the computation of the exponential of the block tridiagonal matrix may be too
% costly

% Input:
% A = symmetric matrix
% j, l = indices of the entry (j ne l)
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

% bg(:,:,k) is 2 x 2 and contains the Gauss estimates of the entries
% (j,j) (j,l)
% (j,l) (l,l)
% of the exponential
% Same thing for the other arrays

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

if j == l
 error('gm_bounds_bgauss_exp: j must be different from l')
end

s = RandStream('mt19937ar','Seed', 5489);
RandStream.setGlobalStream(s);

bg = zeros(2,2,kmax);
bgrl = zeros(2,2,kmax);
bgru = zeros(2,2,kmax);
bgl = zeros(2,2,kmax);

n = size(A,1);
JJ = eye(2 * kmax);
ej = zeros(n,1);
ej(j) = 1;
el = zeros(n,1);
el(l) = 1;
x1 = zeros(n,2);
x = [ej el];
gam = zeros(2,2);
om = x' * A * x;
JJ(1:2,1:2) = om;

% block Lanczos iterations
if kmax > 1
 for k = 2:kmax
  r = A * x - x * om - x1 * gam';
  x1 = x;
  [xa,gama] = qr(r);
  x = [xa(:,1) xa(:,2)];
  gam = gama(1:2,1:2);
  dgam = det(gam);
  if abs(dgam) < 1.e-6
   fprintf('\n gm_bounds_bgauss_exp: Warning, breakdown, the results may be wrong \n\n')
   nr = sqrt(r(:,1)' * r(:,1));
   if nr == 0
    break
   end % if nr
   r1 = r(:,1) / nr;
   y = [x1 r1];
   z = (eye(n) - y * y') * rand(n,1);
   x = [r1 z / sqrt(z' * z)];
  end % if abs
  om = x' * A * x;
  JJ(2*k-1:2*k,2*k-1:2*k) = om;
  JJ(2*k-1:2*k,2*k-3:2*k-2) = gam;
  JJ(2*k-3:2*k-2,2*k-1:2*k) = gam';
  r = A * x - x * om - x1 * gam';
  [xa,gama] = qr(r);
  gamm = gama(1:2,1:2);
  
  % Gauss
  invJJ = expm(JJ(1:2*k,1:2*k));
  bg(:,:,k) = invJJ(1:2,1:2);
  
  % Gauss-Radau
  b = zeros(2*k,2);
  b(2*k-1:2*k,1:2) = gamm';
  dmax = inv(JJ(1:2*k,1:2*k) - lmin * eye(2*k)) * b;
  omm = lmin * eye(2) + dmax(2*k-1:2*k,1:2)' * gamm';
  del = zeros(2,2*k);
  del(1:2,2*k-1:2*k) = gamm;
  JT =[JJ(1:2*k,1:2*k) del';del omm];
  invJJ = expm(JT);
  bgru(:,:,k) = invJJ(1:2,1:2);
  dmin = inv(JJ(1:2*k,1:2*k) - lmax * eye(2*k)) * b;
  omm = lmax * eye(2) + dmin(2*k-1:2*k,1:2)' * gamm';
  JT = [JJ(1:2*k,1:2*k) del';del omm];
  invJJ = expm(JT);
  bgrl(:,:,k) = invJJ(1:2,1:2);
  
  % Gauss-Lobatto
  b = zeros(2*k,2);
  i2 = eye(2);
  b(2*k-1:2*k,1:2) = i2;
  dmax = inv(JJ(1:2*k,1:2*k) - lmin * eye(2*k)) * b;
  dn = dmax(2*k-1:2*k,1:2)';
  dmin = inv(JJ(1:2*k,1:2*k) - lmax * eye(2*k)) * b;
  mn = dmin(2*k-1:2*k,1:2)';
  y = (lmax - lmin) * inv(dn-mn);
  vpy = eig(y);
  if min(vpy) > 0
   gamm = chol(y);
  else
   gamm = 0;
  end % if min
  omm = lmin * i2 + gamm * dn * gamm';
  del = zeros(2,2*k);
  del(1:2,2*k-1:2*k) = gamm;
  JT = [JJ(1:2*k,1:2*k) del';del omm];
  invJJ = expm(JT);
  bgl(:,:,k) = invJJ(1:2,1:2);
  if min(vpy) <= 0
   bgl(:,:,k) = zeros(2,2);
  end % if min
  
 end % for k
end % if kmax


