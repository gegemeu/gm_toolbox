function [bg,bgrl,bgru,bgl]=gm_bounds_gauss_inv(A,i,kmax,lmin,lmax);
%GM_BOUNDS_GAUSS_INV computation of lower and upper bounds of the element (i,i)
% of the inverse of a symmetric matrix A using the Lanczos algorithm

% Input:
% A = symmetric matrix
% i = index of the entry
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

n = size(A,1);
if i > n
 error('gm_bounds_gauss_inv: i must be smaller than size(A,1)')
end
ei = zeros(n,1);
ei(i) = 1;
x = ei;
Ax = A * x;
om = x' * Ax;
b1 = 1 / om;
bg(1) = b1;
d = om;
dbar = om - lmax;
dhat = om - lmin;
c = 1;
r = Ax - om * x;
gam2 = r' * r;
gam = sqrt(gam2);
x1 = x;
x = r / gam;

% Lanczos iterations
if kmax > 1
 for k = 2:kmax
  gam1 = gam;
  gam21 = gam2;
  Ax = A * x;
  om = x' * Ax;
  r = Ax - om * x - gam * x1;
  gam2 = r' * r;
  gam = sqrt(gam2);
  x1 = x;
  if gam == 0
   error('gm_bounds_gauss_inv: Breakdown')
  end % if gam
  x = r / gam;
  b1 = b1 + (gam21 * c^2) / (d * (om * d - gam21));
  c = c * gam1 / d;
  d = om - gam21 / d;
  dbar = om - lmax - gam21 / dbar;
  dhat = om - lmin - gam21 / dhat;
  ombar = lmax + gam2 / dbar;
  omhat = lmin + gam2 / dhat;
  bbar = b1 + (gam2 * c^2) / (d * (ombar * d - gam2));
  bhat = b1 + (gam2 * c^2) / (d * (omhat * d - gam2));
  dd = dhat * dbar / (dbar - dhat);
  omt = dd * (lmax / dhat - lmin / dbar);
  gamt2 = dd * (lmax - lmin);
  btch = b1 + (gamt2 * c^2) / (d * (omt * d - gamt2));
  bg(k) = b1;
  bgrl(k) = bbar;
  bgru(k) = bhat;
  bgl(k) = btch;
 end % for k
end % kmax


