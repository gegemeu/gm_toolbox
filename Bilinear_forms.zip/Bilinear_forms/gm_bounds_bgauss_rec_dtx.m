function [bg,bgrl,bgru,bgl] = gm_bounds_bgauss_rec_dtx(A,d,c,kmax,lmin,lmax);
%GM_BOUNDS_BGAUSS_REC_DTX estimates of d^T inv(A) c for a symmetric matrix A with the block Lanczos algorithm

% Using block recurrences for the block tridiagonal matrix
% this is more efficient than computing the inverse of the block matrix

% Input:
% A = symmetric matrix
% d, c = vectors
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default')

n = size(A,1);
JJ = sparse(2*kmax,2*kmax);
x1 = zeros(n,2);
nd = norm(d);

% d and c must be orthonormal
% orthogonalization
cdnd = (c' * d) / nd^2;
cd = c - cdnd * d;
ncd = norm(cd);
if ncd < eps
 error('gm_bounds_bgauss_rec_dtx: Cannot orthogonalize d and c')
end % if ncd
x = [d / nd, cd / ncd];

gam = zeros(2,2);
Ck = eye(2,2);

om = x' * A * x;
JJ(1:2,1:2) = om;
invJJ = inv(om);
iom = invJJ;
Jk1 = iom;
delta = invJJ(1,1);
gamma = invJJ(1,2);
bg(1) = cdnd * delta * nd^2 + gamma * ncd * nd;

% block Lanczos iterations
if kmax > 1
 for k = 2:kmax
  r = A * x - x * om - x1 * gam';
  x1 = x;
  [xa,gama] = qr(r);
  x = [xa(:,1) xa(:,2)];
  gam = gama(1:2,1:2);
  dgam = det(gam);
  if abs(dgam) < 1e-6
   nr = sqrt(r(:,1)' * r(:,1));
   if nr == 0
    error('gm_bounds_bgauss_rec_dtx: Breakdown')
   end % if nr
   r1 = r(:,1) / nr;
   y = [x1 r1];
   z = (eye(n) - y * y') * rand(n,1);
   x = [r1, z / sqrt(z' * z)];
  end % if abs
  om = x' * A * x;
  JJ(2*k-1:2*k,2*k-1:2*k) = om;
  JJ(2*k-1:2*k,2*k-3:2*k-2) = gam;
  JJ(2*k-3:2*k-2,2*k-1:2*k) = gam';
  
  % Gauss
  % block recurrences 
  Ck = Ck * iom * gam';
  Dk = om - gam * iom * gam';
  iom = inv(Dk);
  Jk1 = Jk1 + Ck * iom * Ck';
  delta = Jk1(1,1);
  gamma = Jk1(1,2);
  bg(k) = cdnd * delta * nd^2 + gamma * ncd * nd;
  
  % Gauss-Radau
  r = A * x - x * om - x1 * gam';
  [xa,gama] = qr(r);
  gamm = gama(1:2,1:2);
  b = zeros(2*k,2);
  b(2*k-1:2*k,1:2) = gamm';
  dmax = (JJ(1:2*k,1:2*k) - lmin * eye(2*k)) \ b;
  omm = lmin * eye(2) + dmax(2*k-1:2*k,1:2)' * gamm';
  % block recurrences
  Ckr = Ck * iom * gamm';
  Dkr = omm - gamm * iom * gamm';
  Jk1r = Jk1 + Ckr * inv(Dkr) * Ckr';
  delta = Jk1r(1,1);
  gamma = Jk1r(1,2);
  bgru(k) = cdnd * delta * nd^2 + gamma * ncd * nd;
  
  dmin = (JJ(1:2*k,1:2*k) - lmax * eye(2*k)) \ b;
  omm = lmax * eye(2) + dmin(2*k-1:2*k,1:2)' * gamm';
  % block recurrences
  Dkr = omm - gamm * iom * gamm';
  Jk1r = Jk1 + Ckr * inv(Dkr) * Ckr';
  delta = Jk1r(1,1);
  gamma = Jk1r(1,2);
  bgrl(k) = cdnd * delta * nd^2 + gamma * ncd * nd;
  
  % Gauss-Lobatto
  b = zeros(2*k,2);
  i2 = eye(2);
  b(2*k-1:2*k,1:2) = i2;
  dmax = (JJ(1:2*k,1:2*k) - lmin * eye(2*k)) \ b;
  dn = dmax(2*k-1:2*k,1:2)';
  dmin = (JJ(1:2*k,1:2*k) - lmax * eye(2*k)) \ b;
  mn = dmin(2*k-1:2*k,1:2)';
  y = (lmax - lmin) * inv(dn - mn);
  vpy = eig(y);
  if min(vpy) > 0
   gamm = chol(y);
  else
   gamm = zeros(2,2);
  end % if min
  omm = lmin * i2 + gamm * dn * gamm';
  if min(vpy) <= 0
   omm = i2;
  end % if min
  % block recurrences
  Ckl = Ck * iom * gamm';
  Dkl = omm - gamm * iom * gamm';
  Jk1l = Jk1 + Ckl * inv(Dkl) * Ckl';
  delta = Jk1l(1,1);
  gamma = Jk1l(1,2);
  bgl(k) = cdnd * delta * nd^2 + gamma * ncd * nd;
  
 end % for k
end % if kmax

