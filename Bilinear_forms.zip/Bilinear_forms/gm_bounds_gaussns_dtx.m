function [bg,bgrl,bgru,bgl]=gm_bounds_gaussns_dtx(A,d,c,kmax,lmin,lmax);
%GM_BOUNDS_GAUSSNS_DTX computation of bounds for (d,x) = d^T x
% with A x = c that is, d^T inv(A) c using the nonsymmetric Lanczos algorithm

% we do not solve Ax = c

% Input:
% A = symmetric matrix
% d, c = vectors
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

utv = d' * c;
sutv = sqrt(abs(utv));
if utv == 0
 error('gm_bounds_gaussns_dtx: utv = 0')
end % if utv
x = d / sutv;
xt = c / sutv;
if utv < 0
 xt = -xt;
end % if utv
Ax = A * x;
Axt = A * xt;
om = xt' * Ax;
b1 = 1 / om;
bg(1) = utv * b1;
dd = om;
dbar = om - lmax;
dhat = om - lmin;
cc = 1;
e = 1;
r = Ax - om * x;
rt = Axt - om * xt;
gamb = rt' * r;
gabet = sqrt(abs(gamb));
gam = gabet;
bet = gabet;
if gamb < 0
 bet = -gabet;
end % if gamb
x1 = x;
xt1 = xt;
x = r / gam;
xt = rt / bet;

% Non symmetric Lanczos iterations
if kmax > 1
 for k = 2:kmax
  gam1 = gam;
  bet1 = bet;
  gamb1 = gamb;
  Ax= A * x;
  Axt= A * xt;
  om = xt' * Ax;
  r = Ax - om * x - bet * x1;
  rt = Axt - om * xt - gam * xt1;
  gamb = rt' * r;
  gabet = sqrt(abs(gamb));
  gam = gabet;
  bet = gabet;
  if gamb < 0
   bet = -gabet;
  end % if gamb
  x1 = x;
  xt1 = xt;
  if gabet == 0
   error('gm_bounds_gaussns_dtx: Breakdown')
  end % if gabet
  x = r / gam;
  xt = rt / bet;
  b1 = b1 + (gamb1 * cc * e) / (dd * (om * dd - gamb1));
  if dd == 0
   error('gm_bounds_dtx_gaussns: Breakdown')
  end % if dd
  cc = cc * gam1 / dd;
  e = e * bet1 / dd;
  dd = om - gamb1 / dd;
  dbar = om - lmax - gamb1 / dbar;
  dhat = om - lmin - gamb1 / dhat;
  ombar = lmax + gamb / dbar;
  omhat = lmin + gamb / dhat;
  bbar = b1 + (gamb * cc * e) / (dd * (ombar * dd - gamb));
  bhat = b1 + (gamb * cc * e) / (dd * (omhat * dd - gamb));
  ddd= dhat * dbar / (dbar - dhat);
  omt = ddd * (lmax / dhat - lmin / dbar);
  gamt2 = ddd * (lmax - lmin);
  btch = b1 + (gamt2 * cc * e) / (dd * (omt * dd - gamt2));
  bg(k) = utv * b1;
  bgru(k) = utv * bhat;
  bgrl(k) = utv * bbar;
  bgl(k) = utv * btch;
  
 end % for k
end % if kmax







