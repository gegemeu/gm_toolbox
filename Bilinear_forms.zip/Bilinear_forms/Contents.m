% BILINEAR_FORMS
%
% functions for computing bounds or estimates of bilinear forms
%
% Files
%   gm_bounds_bgauss_dtx      - estimates of d^T inv(A) c for a symmetric matrix A with the block Lanczos algorithm
%   gm_bounds_bgauss_exp      - Gauss block quadrature rules estimates for the entry (j,l) of the exponential of a symmetric matrix 
%   gm_bounds_bgauss_inv      - Gauss block quadrature rules estimates for the entry (j,l) of the inverse of a symmetric matrix 
%   gm_bounds_bgauss_rec_dtx  - estimates of d^T inv(A) c for a symmetric matrix A with the block Lanczos algorithm
%   gm_bounds_bgauss_sqrt     - Gauss block quadrature rules estimates for the entry (j,l) of the square root of a symmetric matrix 
%   gm_bounds_gauss_exp       - lower and upper bounds of the entry (i,i) of the exponential of a symmetric matrix A with the Lanczos algorithm
%   gm_bounds_gauss_f         - lower and upper bounds of the element (i,i) of the function fonc(A) of a symmetric matrix A with the Lanczos algorithm
%   gm_bounds_gauss_fu        - lower and upper bounds of u^T fonc(A) u with the Lanczos algorithm
%   gm_bounds_gauss_fu_reorth - lower and upper bounds of u^T fonc(A) u with the Lanczos algorithm with reorthogonalization
%   gm_bounds_gauss_inv       - lower and upper bounds of the entry (i,i) of the inverse of a symmetric matrix A with the Lanczos algorithm
%   gm_bounds_gauss_sqrt      - lower and upper bounds of the entry (i,i) of the square root of a symmetric matrix A with the Lanczos algorithm
%   gm_bounds_gaussns_dtx     - bounds for (d,x) = d^T x with A x = c that is, d^T inv(A) c with the nonsymmetric Lanczos algorithm
%   gm_bounds_gaussns_exp     - bounds for the entry (i,l) of the exponential with the nonsymmetric Lanczos algorithm
%   gm_bounds_gaussns_f       - bounds for the entry (i,l) of fonc(A) using the nonsymmetric Lanczos algorithm
%   gm_bounds_gaussns_inv     - bounds for the entry (i,l) of the inverse of a symmetric matrix A with the nonsymmetric Lanczos algorithm
%   gm_bounds_gaussns_sqrt    - bounds for the entry (i,l) of the square root of a symmetric matrix A with the nonsymmetric Lanczos algorithm
