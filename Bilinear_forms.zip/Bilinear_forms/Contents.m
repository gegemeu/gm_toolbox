
% BOUNDS FOR BILINEAR FORMS
%
% Files
%   gm_bounds_bgauss_dtx      - computation of d^T inv(A) c for a symmetric matrix A
%   gm_bounds_bgauss_exp      - computation of estimates using Gauss block quadrature rules for the exponential
%   gm_bounds_bgauss_inv      - computation of estimates using Gauss block quadrature rules for the inverse
%   gm_bounds_bgauss_rec_dtx  - computation of d^T inv(A) c for a symmetric matrix A
%   gm_bounds_bgauss_sqrt     - computation of estimates using Gauss block quadrature rules for the square root
%   gm_bounds_gauss_exp       - computation of lower and upper bounds of the element (i,i) of the exponential
%   gm_bounds_gauss_f         - computation of lower and upper bounds of the element (i,i) of fonc(A)
%   gm_bounds_gauss_fu        - computation of lower and upper bounds of u^T fonc(A) u
%   gm_bounds_gauss_fu_reorth - computation of lower and upper bounds of with reorthogonalization
%   gm_bounds_gauss_inv       - computation of lower and upper bounds of the element (i,i) of the inverse
%   gm_bounds_gauss_sqrt      - computation of lower and upper bounds of the element (i,i) of the square root
%   gm_bounds_gaussns_dtx     - computation of bounds for (d,x) = d^T inv(A) c
%   gm_bounds_gaussns_exp     - computation of bounds for the element (i,l) of the exponential 
%   gm_bounds_gaussns_f       - computation of bounds for the element (i,l) of fonc(A) 
%   gm_bounds_gaussns_inv     - computation of bounds for the element (i,l) of the inverse
%   gm_bounds_gaussns_sqrt    - computation of bounds for the element (i,l) of the square root
