function [bg,bgrl,bgru,bgl]=gm_bounds_gauss_fu(fonc,A,u,kmax,lmin,lmax);
%GM_BOUNDS_GAUSS_FU lower and upper bounds of u^T fonc(A) u with the Lanczos algorithm

% we compute the nodes and weights using the Golub and Welsch algorithm

% Input:
% fonc = function
% A = symmetric matrix
% u = vector in the quadratic form
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

JJ = sparse(kmax,kmax);
nu = norm(u);
nu2 = nu^2;
x = u / nu;
Ax = A * x;
om = x' * Ax;
JJ(1,1) = om;
bg(1) = feval(fonc,om);
% bgrl, bgru and bgl are not computed for k = 1
r = Ax - om * x;
gam2 = r' * r;
gam = sqrt(gam2);
x1 = x;
x = r / gam;

% Lanczos iterations
if kmax > 1
 for k = 2:kmax
  Ax = A * x;
  r = Ax - gam * x1;
  om = x' * r;
  % Jacobi matrix
  JJ(k,k) = om;
  JJ(k,k-1) = gam;
  JJ(k-1,k) = gam;
  r = r - om * x;
  gam2 = r' * r;
  gam = sqrt(gam2);
  x1 = x;
  if gam == 0
   error('gm_bounds_gauss_fu: gamma = 0')
  end
  x = r / gam;
  
  % Gauss
  dijj = diag(JJ(1:k,1:k));
  sdijj = diag(JJ(1:k,1:k),-1);
  
  [tjj,wjj] = gm_gaussquadrule(dijj,sdijj,0,1,0);
  
  ftjj = feval(fonc,tjj);
  bg(k) = nu2 * sum(ftjj .* wjj);
  
  % Gauss-Radau
  b = zeros(k,1);
  b(k) = gam * gam;
  dmax = (JJ(1:k,1:k) - lmin * eye(k)) \ b;
  omm = lmin + dmax(k);
  del = zeros(1,k);
  del(k) = gam;
  JT = [JJ(1:k,1:k) del';del omm];
  dijt = diag(JT(1:k+1,1:k+1));
  sdijt = diag(JT(1:k+1,1:k+1),-1);
  
  [tjj,wjj] = gm_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj = feval(fonc,tjj);
  bgru(k) = nu2 * sum(ftjj .* wjj);
  dmin = (JJ(1:k,1:k) - lmax * eye(k)) \ b;
  omm = lmax + dmin(k);
  JT(k+1,k+1) = omm;
  dijt = diag(JT(1:k+1,1:k+1));
  sdijt = diag(JT(1:k+1,1:k+1),-1);
  
  [tjj,wjj] = gm_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj = feval(fonc,tjj);
  bgrl(k) = nu2 * sum(ftjj .* wjj);
  
  % Gauss-Lobatto
  bbb = zeros(k,1);
  bbb(k) = 1;
  dmin = (JJ(1:k,1:k) - lmin * eye(k)) \ bbb;
  ga = dmin(k);
  dmax = (JJ(1:k,1:k) - lmax * eye(k)) \ bbb;
  gb = dmax(k);
  pol = [1 -ga; 1 -gb];
  yy = pol \ [lmin ; lmax];
  omm = yy(1);
  gamm = sqrt(yy(2));
  del = zeros(1,k);
  del(k) = gamm;
  JJ1 = JJ(1:k,1:k);
  JT = [JJ1 del';del omm];
  dijt = diag(JT(1:k+1,1:k+1));
  sdijt = diag(JT(1:k+1,1:k+1),-1);
  
  [tjj,wjj] = gm_gaussquadrule(dijt,sdijt,0,1,0);
  
  ftjj = feval(fonc,tjj);
  bgl(k) = nu2 * sum(ftjj .* wjj);
  
 end % for k
end % if kmax


