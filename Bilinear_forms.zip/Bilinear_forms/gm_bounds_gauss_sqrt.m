function [bg,bgrl,bgru,bgl]=gm_bounds_gauss_sqrt(A,i,kmax,lmin,lmax);
%GM_BOUNDS_GAUSS_SQRT computation of lower and upper bounds of the element (i,i)
% of the square root of a symmetric matrix A using the Lanczos algorithm

% Input:
% A = symmetric matrix
% i = index of the entry
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

JJ = sparse(kmax,kmax);
n = size(A,1);
if i > n
 error('gm_bounds_gauss_sqrt: i must be smaller than size(A,1)')
end
ei = zeros(n,1);
ei(i) = 1;
x = ei;
Ax = A * x;
om = x' * Ax;
JJ(1,1) = om;
bg(1) = exp(om);
r = Ax - om * x;
gam2 = r' * r;
gam = sqrt(gam2);
x1 = x;
x = r / gam;

% Lanczos iterations
if kmax > 1
 for k = 2:kmax
  Ax = A * x;
  om = x' * Ax;
  % Jacobi matrix
  JJ(k,k) = om;
  JJ(k,k-1) = gam;
  JJ(k-1,k) = gam;
  r = Ax - om * x - gam * x1;
  gam2 = r' * r;
  gam = sqrt(gam2);
  x1 = x;
  if gam == 0
   break
  end % if gam
  x = r / gam;
  
  % Gauss
  EJJ = sqrtm(full(JJ(1:k,1:k)));
  bg(k) = EJJ(1,1);
  
  % Gauss-Radau
  b = zeros(k,1);
  b(k) = gam * gam;
  dmax = (JJ(1:k,1:k) - lmin * eye(k)) \ b;
  omm = lmin + dmax(k);
  del = zeros(1,k);
  del(k) = gam;
  JT = [JJ(1:k,1:k) del';del omm];
  EJJ = sqrtm(full(JT));
  bgrl(k) = EJJ(1,1);
  dmin = (JJ(1:k,1:k) - lmax * eye(k)) \ b;
  omm = lmax + dmin(k);
  JT(k+1,k+1) = omm;
  EJJ = sqrtm(full(JT));
  bgru(k) = EJJ(1,1);
  
  % Gauss-Lobatto
  bbb = zeros(k,1);
  bbb(k) = 1;
  dmin = (JJ(1:k,1:k) - lmin * eye(k)) \ bbb;
  ga = dmin(k);
  dmax = (JJ(1:k,1:k) - lmax * eye(k)) \ bbb;
  gb = dmax(k);
  pol = [1 -ga; 1 -gb];
  yy = pol \ [lmin ; lmax];
  omm = yy(1);
  gamm = sqrt(yy(2));
  del = zeros(1,k);
  del(k) = gamm;
  JJ1 = JJ(1:k,1:k);
  JT = [JJ1 del';del omm];
  EJJ = sqrtm(full(JT));
  bgl(k) = EJJ(1,1);
  
 end % for k
end % if kmax


