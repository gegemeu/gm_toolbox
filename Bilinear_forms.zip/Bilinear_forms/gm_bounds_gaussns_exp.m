function [bg,bgrl,bgru,bgl]=gm_bounds_gaussns_exp(A,i,l,kmax,lmin,lmax,del);
%GM_BOUNDS_GAUSSNS_EXP bounds for the entry (i,l) of the exponential with the nonsymmetric Lanczos algorithm

% estimate of exp(A)_(i,i) + exp(A)_(i,l) / del

% Input:
% A = symmetric matrix
% i, l = indices of the entry
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
% del = parameter for estimate
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

if i == l
 % we return estimates of exp(A)_(i,i)
 [bg,bgrl,bgru,bgl] = gm_bounds_gauss_exp(A,i,kmax,lmin,lmax);
 return
end % if i

if del <= eps || nargin < 8
 del = 1;
end % if del

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

JJ = sparse(kmax,kmax);
n = size(A,1);
ei = zeros(n,1);
ei(i) = 1;
el = zeros(n,1);
el(l) = 1;
x = ei / del;
xt = el + del * ei;
Ax = A * x;
Axt = A * xt;
om = xt' * Ax;
JJ(1,1) = om;
bg(1) = exp(om);
r = Ax - om * x;
rt = Axt - om * xt;
gamb = rt' * r;
gabet = sqrt(abs(gamb));
gam = gabet;
bet = gabet;
if gamb < 0
 bet = -gabet;
end % if gamb
x1 = x;
xt1 = xt;
x = r / gam;
xt = rt / bet;

% non symmetric Lanczos iterations
if kmax > 1
 for k = 2:kmax
  gam1 = gam;
  bet1 = bet;
  Ax = A * x;
  Axt = A * xt;
  om = xt' * Ax;
  r = Ax - om * x - bet * x1;
  rt = Axt - om * xt - gam * xt1;
  gamb = rt' * r;
  gabet = sqrt(abs(gamb));
  gam = gabet;
  bet = gabet;
  if gamb < 0
   bet = -gabet;
  end
  x1 = x;
  xt1 = xt;
  if gabet == 0
   error('gm_bounds_gaussns_exp: Breakdown')
  end % if gabet
  x = r / gam;
  xt = rt / bet;
  % Jacobi matrix
  JJ(k,k) = om;
  JJ(k,k-1) = bet1;
  JJ(k-1,k) = gam1;
  
  % Gauss
  EJJ = expm(full(JJ(1:k,1:k)));
  bg(k) = EJJ(1,1);
  
  % Gauss-Radau
  r = (A - om * eye(n)) * x - bet * x1;
  rt = (A - om * eye(n)) * xt - gam * xt1;
  gabet = sqrt(abs(rt' * r));
  gamm = gabet;
  bett = gabet;
  if rt' * r <= 0
   bett = -gabet;
  end % if rt'
  if gabet == 0
   error('gm_bounds_gaussns_exp: Breakdown')
  end % if gabet
  b = zeros(k,1);
  b(k) = 1;
  dmax = (JJ(1:k,1:k) - lmin * eye(k)) \ b;
  omm = lmin + dmax(k);
  delk = zeros(1,k);
  delk(k) = gamm;
  dell = zeros(1,k);
  dell(k) = bett;
  JT = [JJ(1:k,1:k) delk';dell omm];
  EJJ = expm(JT);
  bgru(k) = EJJ(1,1);
  
  dmin = (JJ(1:k,1:k) - lmax * eye(k)) \ b;
  omm = lmax + dmin(k);
  JT = [JJ(1:k,1:k) delk';dell omm];
  EJJ = expm(JT);
  bgrl(k) = EJJ(1,1);
  
  % Gauss-Lobatto
  b = zeros(k,1);
  b(k) = 1;
  dmin = (JJ(1:k,1:k) - lmin * eye(k)) \ b;
  ga = dmin(k);
  dmax = (JJ(1:k,1:k) - lmax * eye(k)) \ b;
  gb = dmax(k);
  pol = [1 -ga; 1 -gb];
  yy = pol \ [lmin ; lmax];
  omm = yy(1);
  gabet = sqrt(abs(yy(2)));
  gamm = gabet;
  bett = gabet;
  if yy(2) <= 0
   bett = -gabet;
  end % if yy
  dell = zeros(1,k);
  dell(k) = gamm;
  delk = zeros(1,k);
  delk(k) = bett;
  JT = [JJ(1:k,1:k) dell';delk omm];
  EJJ = expm(JT);
  bgl(k) = EJJ(1,1);
  
 end % for k
end % if kmax


