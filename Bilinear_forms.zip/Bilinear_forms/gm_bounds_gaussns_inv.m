function [bg,bgrl,bgru,bgl]=gm_bounds_gaussns_inv(A,i,l,kmax,lmin,lmax,del);
%GM_BOUNDS_GAUSSNS_INV computation of bounds for the element (i,l) 
% of the inverse of a symmetric matrix A using the nonsymmetric
% Lanczos algorithm

% estimate of inv(A)_(i,i) + inv(A)_(i,l) / del

% Input:
% fonc = function
% A = symmetric matrix
% i, l = indices of the entry
% kmax = number of iterations
% lmin, lmax = estimates of the smallest and largest eigenvalues of A
% del = parameter for estimate
%
% Output:
% bg = Gauss estimate
% bgrl, bgru = Gauss-Radau estimates
% bgl = Gauss_Lobatto estimate

%
% Author G. Meurant
% March 2008
% Updated July 2015
%

if i == l
 [bg,bgrl,bgru,bgl] = gm_bounds_gauss_inv(A,i,kmax,lmin,lmax);
 return
end % if i

bg = zeros(kmax,1);
bgrl = zeros(kmax,1);
bgru = zeros(kmax,1);
bgl = zeros(kmax,1);

if del == 0 || nargin < 7
 del = 1;
end % if del

n = size(A,1);
ei = zeros(n,1);
ei(i) = 1;
el = zeros(n,1);
el(l) = 1;
x = ei / del;
xt = el + del * ei;
Ax = A * x;
Axt = A * xt;
om = xt' * Ax;
b1 = 1 / om;
bg(1) = b1;
d = om;
dbar = om - lmax;
dhat = om - lmin;
c = 1;
e = 1;
r = Ax - om * x;
rt = Axt - om * xt;
gamb = rt' * r;
gabet = sqrt(abs(gamb));
gam = gabet;
bet = gabet;
if gamb < 0
 bet = -gabet;
end % if gamb
x1 = x;
xt1 = xt;
x = r / gam;
xt = rt / bet;

% non symmetric Lanczos iterations
if kmax > 1
 for k = 2:kmax
  gam1 = gam;
  bet1 = bet;
  gamb1 = gamb;
  Ax = A * x;
  Axt = A * xt;
  om = xt' * Ax;
  r = Ax - om * x - bet * x1;
  rt = Axt - om * xt - gam * xt1;
  gamb = rt' * r;
  gabet = sqrt(abs(gamb));
  gam = gabet;
  bet = gabet;
  if gamb < 0
   bet = -gabet;
  end % if gamb
  x1 = x;
  xt1 = xt;
  if gabet == 0
   error('gm_bounds_gaussns_inv: Breakdown')
  end % if gabet
  x = r / gam;
  xt = rt / bet;
  
  % Gauss
  b1 = b1 + (gamb1 * c * e) / (d * (om * d - gamb1));
  c = c * gam1 / d;
  e = e * bet1 / d;
  d = om - gamb1 / d;
  
  % Gauss-Radau
  dbar = om - lmax - gamb1 / dbar;
  dhat = om - lmin - gamb1 / dhat;
  ombar = lmax + gamb / dbar;
  omhat = lmin + gamb / dhat;
  bbar = b1 + (gamb * c * e) / (d * (ombar * d - gamb));
  bhat = b1 + (gamb * c * e) / (d * (omhat * d - gamb));
  
  % Gauss-Lobatto
  dd = dhat * dbar / (dbar - dhat);
  omt = dd * (lmax / dhat - lmin / dbar);
  gamt2 = dd * (lmax - lmin);
  btch = b1 + (gamt2 * c * e) / (d * (omt * d - gamt2));
  
  bg(k) = b1;
  bgru(k) = bhat;
  bgrl(k) = bbar;
  bgl(k) = btch;
  
 end % for k
end % if kmax


