function [flag,c,om]=gm_find_v_gen_real_lambda(lambda,theta);
%GM_FIND_V_GEN_REAL_LAMBDA finds is there is a vector v s.t. theta are Ritz values for A
% with Arnoldi started from v

% A is assumed to be real normal
% Caution! so far, the Ritz values must be different from the eigenvalues

% Input:
% lambda = eigenvalues of A
% theta = given Ritz values
%
% Output:
% flag = 1, theta is feasible
% c = the solution. Then v = X c (X eigenvectors of A)
% om = CR \ rhsR

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%


% this is for gm_check_ineq
% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setDefaultStream(s);

c = [];
flag = 0;
om = [];

n = length(lambda);
k = length(theta);

% build the matrix CR and the rhs for the given theta

[CR,rhsR,p] = gm_C_matrix_gen_real_lambda(lambda,theta);

k = size(CR,1);
np = size(CR,2);

if k >= np
 % we have an overdetermined (or square) system
 % check if the system is consistent and the solution > 0
 % this can be done in a better way!!!!!
 flag = 0;
 om = CR \ rhsR;
 res = norm(rhsR - CR * om) / norm (om);
 
 if k == np
  epsi = 1e-14;
 else
  % *********************this test is very sensitive!!!
  epsi = 5e-5;
 end % if k ==
 
 % we got a solution
 if res < epsi
  flag = 1;
  for jj = 1:length(om)
   if (om(jj) < 0)
    flag = 0;
   end % if om
  end % for jj
 end % if res
 omm = zeros(n,1);
 % expand the solution
 for jj = 1:p
  omm(2*jj-1) = om(jj);
  omm(2*jj) = om(jj);
 end % for jj
 for jj = p+1:n-p
  omm(p+jj) = om(jj);
 end % for jj
 c = sqrt(omm);
 return
end % if k >

% case of an underdetermined system

% SVD of CR

[U,S,V] = svd(CR);

r = rankCC(S);

if r < size(CR,1)
 % this does not happen often
 fprintf('\n gm_find_v_gen_real_lambda: Small rank \n\n')
 flag = 0;
 return
end % if r

% construct the system to get a positive solution (if any)

D = S(1:r,1:r);
V1 = V(:,1:r);
V2 = V(:,r+1:end);

% partial solution for CR

yy = D \ (U' * rhsR);

V1y = V1 * yy;

% inequality for the solution to be positive

[flag,zz] = gm_check_ineq(-V2,V1y);

% return a solution?

if flag == 1
 om = V * [yy; zz];
 omm = zeros(n,1);
 I = find(abs(om)<1e-15);
 om(I) = 0;
 for jj = 1:p
  omm(2*jj-1) = om(jj);
  omm(2*jj) = om(jj);
 end % for jj
 for jj = p+1:n-p
  omm(p+jj) = om(jj);
 end % for jj
 c = sqrt(omm);
end % if flag

end % function

function r=rankCC(S);
% rank of the matrix arising from SVD

D = diag(S);

normS = max(D);
epss = eps * max(size(S)) * normS;
I = find(D > epss);
r = length(I);

end



