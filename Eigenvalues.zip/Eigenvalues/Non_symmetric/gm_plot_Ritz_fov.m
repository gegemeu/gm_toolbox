function gm_plot_Ritz_fov(A,v,dit,bnd);
%GM_PLOT_RITZ_FOV plot of the Arnoldi Ritz values at each iteration and of the field of values

% Input:
% A = matrix
% v = starting vector
% dit = step size in the iterations
% bnd = 'bndry' plots the boundary for k = 2, useful if A is real normal

%
% Author G. Meurant
% Oct 2013
%

n = size(A,1);

if nargin < 3
 dit = 1;
end

if nargin < 4
 bnd = '    ';
end

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,n,'noreorth','noprint');

figure

for k = 1:dit:n
 Hk = H(1:k,1:k);
 % field of values
 gm_fvmod(A,1,32,1);
 if strcmpi(bnd,'bndry') == 1 && n <= 10
  gm_plot_boundary_real_k2b(A);
 end % if strcmpi
 hold on
 eigH = eig(full(Hk));
 plot(real(eigH),imag(eigH),'kd')
 title(['Iteration ' num2str(k)])
 pause
 hold off
end % for k

hold off

