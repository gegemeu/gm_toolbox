function gm_plot_Ritz_fov(A,v,dit);
%GM_PLOT_RITZ_FOV plot of the Arnoldi Ritz values at each iteration and of the field of values

% Input:
% A = matrix
% v = starting vector
% dit = step size in the iterations

%
% Author G. Meurant
% October 2013
%

n = size(A,1);

if nargin < 3
 dit = 1;
end

if nargin < 4
 bnd = '    ';
end

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,n,'noreorth','noprint');

figure

for k = 1:dit:n
 % field of values
 gm_fvmod(A,1,32,0);
 hold on
 Hk = H(1:k,1:k);
 eigH = eig(full(Hk));
 plot(real(eigH),imag(eigH),'kd')
 title(['Iteration ' num2str(k)])
 hold on
 pause
 hold off
end % for k

hold off

