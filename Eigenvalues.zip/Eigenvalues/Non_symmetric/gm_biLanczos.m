function [V,W,T,VTs,Rvals,Rvec,res,time_mat] = gm_biLanczos(A,u,nitmax,prints);
%GM_BILANCZOS bi-Lanczos iteration for a matrix A

%
% Input:
% A =  matrix
% u = starting vector
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V, W = bi-Lanczos vectors
% T = tridiagonal matrix
% VTs = eigenvectors of T
% Rvals = eigenvalues of T
% Rvec = Ritz vectors
% res = residual norms || (A-theta I)x ||
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products
%  otherwise same without the first two items

%
% Author G. Meurant
% July 2015
%

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end
if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 iprint = 0;
 tic
end

u = u / norm(u);
v = u;
w = v;

v1 = zeros(n,1);
w1 = v1;

dotprod = 0;
matvec = 0;
T = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
W = zeros(n,nitmax);
At = A';
beta = 0;
rho = 1;
zeta = 1;

wv = w' * v;

if timing == 1
 tinit = toc;
 if iprint == 1
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 1:nitmax
 
 V(:,k) = v;
 W(:,k) = w;

 Av = A * v;
 Aw = At * w;
 matvec = matvec + 2;
 
 % check the breakdown
 if abs(wv) < 1e-3 && iprint == 1
  fprintf('\n gm_biLanczos: Near breakdown wv = %12.5e, iteration %d \n',wv,k)
 end
 
 alpha = (w' * Av) / wv;
 dotprod = dotprod + 1;
 
 p = Av - alpha * v - beta * v1;
 s = Aw - alpha * w - (beta * rho  / zeta) * w1;
 
 rho = norm(p);
 zeta = norm(s);
 dotprod = dotprod + 2;
 
 v1 = v;
 w1 = w;
 v = p / rho;
 w = s / zeta;
 
 wv_new = w' * v;
 dotprod = dotprod + 1;
 
 % check the breakdown
 if abs(wv_new) < 1e-3 && iprint == 1
  fprintf('\n gm_biLanczos: Near breakdown wv new = %12.5e, iteration %d \n',wv_new,k)
 end
 
 beta = zeta * wv_new / wv;
 wv = wv_new;
 
 T(k,k) = alpha;
 T(k,k+1) = beta;
 T(k+1,k) = rho;
 
end % for k

% eigenvalues and eigenvectors of T

[vt,dt] = eig(full(T(1:nitmax,1:nitmax)));

% Eigenvalues
Rvals = diag(dt);

% Eigenvectors
VTs = vt;

% approx of eigenvectors
Rvec = V(:,1:nitmax) * VTs;

T = T(1:nitmax,1:nitmax);
V = V(:,1:nitmax);
W = W(:,1:nitmax);

if timing == 1
 titer = toc;
 fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end % if timing

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n',dotprod,dotprod/nitmax)
end % if iprint

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end % for k

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end % if iprint




