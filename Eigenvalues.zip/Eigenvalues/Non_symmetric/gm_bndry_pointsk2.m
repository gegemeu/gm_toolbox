function [flag,xb]=gm_bndry_pointsk2(varargin);
%GM_BNDRY_POINTSK2 computation of boundary points for k = 2
% of the region containing the Arnoldi Ritz values for real normal matrices

% check if the point xb is on the boundary (flag = 1)

% Output:
% flag = 1 if the points are on the boundary
% xb = boundary points

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

flag = 0;
xb = [];

[cax,args,nargs] = axescheck(varargin{:});
f = args{1};
args = args(2:end);

[f,fx0,varx] = gm_myezfcnchk(f);

x0 = args{1};
A = args{2};
Xmin = args{3};
Xmax = args{4};
Ymin = args{5};
Ymax = args{6};
yb = args{7};

% compute a point on the curve

options = optimset('Display','off');

[xb,val,exitflag] = fzero(f,x0,options);

if exitflag ~= 1
 return
end

% is the point feasible?

[flag1,c,om] = gm_find_v_gen_real_lambda(A,[xb+yb*i,xb-yb*i]);
if flag1 == 0
 return
end

% find 4 surrounding points
% on a regular cartesian mesh over the FOV
% defined by xmin, xmax, ymin, ymax

np = 500;
hx = (Xmax - Xmin) / np;
hy = (Ymax - Ymin) / np;

indx = fix((xb - Xmin) / hx);
indy = fix((yb - Ymin) / hy);

xmi = Xmin + indx * hx;
xma = xmi + hx;
ymi = Ymin + indy * hy;
yma = ymi + hy;

% check the feasibility of the four points

[flag1,c,om] = gm_find_v_gen_real_lambda(A,[xmi+ymi*i,xmi-ymi*i]);
[flag2,c,om] = gm_find_v_gen_real_lambda(A,[xma+ymi*i,xma-ymi*i]);
[flag3,c,om] = gm_find_v_gen_real_lambda(A,[xma+yma*i,xma-yma*i]);
[flag4,c,om] = gm_find_v_gen_real_lambda(A,[xmi+yma*i,xmi-yma*i]);

if (flag1 + flag2 + flag3 + flag4) == 4
 % the point is inside the region
 flag = 0;
else
 flag = 1;
end







