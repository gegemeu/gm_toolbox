function [lambda,X] = gm_harm_Ritz_valvec(H);
%GM_HARM_RITZ_VALVEC computes the harmonic Ritz values and eigenvectors of the Hessenberg matrix H

% Input:
% H = upper Hessenberg matrix n x (n-1)
%
% Output:
% lambda = harmonic Ritz values of the matrix H
% X = eigenvectors

%
% Author G. Meurant
% August 2016
%

n = size(H,1);
k = n - 1;

Hk = H(1:k,1:k);
ek = zeros(k,1);
ek(k) = 1;
Hki = Hk' \ ek;
HHk = Hk;
% HHk = Hk + H(k+1,k)^2 * [zeros(k,k-1) Hki];
HHk(:,k) = HHk(:,k) + H(k+1,k)^2 * Hki;
Hnan = HHk(:);
if any(isnan(Hnan))
 fprintf('\n gm_harm_Ritz_val_H: H_k is (almost) singular, we do not compute the harmonic Ritz values \n')
 lambda = [];
 X = 0;
 return
 %  Hk
end
[Z,D] = eig(full(HHk));
lam = diag(D);
[lamb,I] = sort(abs(lam));
lambda = lam(I);
X = Z(:,I);





