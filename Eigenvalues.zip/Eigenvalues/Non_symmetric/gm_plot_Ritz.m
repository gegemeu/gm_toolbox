function [eigH,Ritzval] = gm_plot_Ritz(H,dit);
%GM_PLOT_RITZ plot of the eigenvalues and Ritz values at each iteration

% H is upper Hessenberg from Arnoldi

% Input:
% H = square upper Hessenberg matrix
% dit = stepsize for the iterations
%
% Output:
% eigH = eigenvalues of H
% Ritzval = Ritz values for the iterations we plot

%
% Author G. Meurant
% December 2011
% Updated September 2015
%

H = full(H);

eigH = eig(H);

n = size(H,1);

Ritzval = zeros(n,n);

for k = 1:dit:n
 plot(real(eigH),imag(eigH),'ro')
 title(['Iteration ' num2str(k)])
 hold on
 muu = eig(H(1:k,1:k));
 Ritzval(1:k,k) = muu;
 plot(real(muu),imag(muu),'kd')
 hold off
 pause
end % for k

