function [A,lambda,X,img,p,II,IR,lamb,XXX]=gm_put_imag_first(AA);
%GM_PUT_IMAG_FIRST put the complex conjugate eigenvalues first in the computation of the eigenvalues

% Input:
% AA = real matrix
%
% Output:
% A = permuted matrix from the eigenvalues and eigenvectors
% lambda = ordered eigenvalues
% X = reordered eigenvectors
% img = 1 if all eigenvalues are complex
% p = number of complex conjugate pairs
% II = complex eigenvalues
% IR = real eigenvalues
% lamb, XXX = eigenvalues and eigenvectors sorted so that XXX = [X1 X1' XR]

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

[XX,DD] = eig(full(AA));
lambda = transpose(diag(DD));

% put the complex conjugate eigenvalues first
% we assume that in DD the eigenvalues in the pair are consecutive

IR = find(abs(imag(lambda)) <= 1e-14);
lambda(IR) = real(lambda(IR));
II = find(imag(lambda) ~= 0);

lambR = lambda(IR);

lambda = [lambda(II) lambR];

X = [XX(:,II) XX(:,IR)];

A = (X * diag(lambda)) / X;
if isreal(AA)
 A = real(A);
end

j = 0;
lamb = [];
XXX = [];
lII2 = length(II) / 2;

for k = 1:2:length(II)
 j = j + 1;
 lamb(j) = lambda(k);
 XXX(:,j) = X(:,k);
 j2 = j + lII2;
 lamb(j2) = lambda(k+1);
 XXX(:,j2) = X(:,k+1);
end % for k
lamb = [lamb lambR];
XXX = [XXX XX(:,IR)];

img = 0;
if isempty(IR)
 % all the eigenvalues are complex
 img = 1;
end % if isempty

% number of complex conjugate pairs

p = length(II) / 2;

% indices of real and complex eigenvalues

IR = find(imag(lambda) == 0);
II = find(imag(lambda) ~= 0);



