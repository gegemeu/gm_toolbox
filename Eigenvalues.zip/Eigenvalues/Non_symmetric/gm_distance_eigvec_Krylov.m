function [Dist,D,X] = gm_distance_eigvec_Krylov(A,V);
%GM_DISTANCE_EIGVEC_KRYLOV distances of the eigenvectors of A to Krylov subspaces

% Input:
% A = matrix
% V = orthonormal basis from Arnoldi
%
% Output:
% Dist = distances
% D = matrix of eigenvalues
% X = matrix of eigenvectors

%
% Author G. Meurant
% January 2015
% Updated September 2015
%

[n,m] = size(V);

Dist = zeros(n,m);

% eigenvectors of A
[X,D] = eig(full(A));

for k = 1:m
 Vk = V(:,1:k);
 % projection matrix
 Pk = Vk * Vk';
 for j = 1:n
  x = X(:,j);
  Dist (j,k) = norm(x - Pk * x);
 end % for j
end % for k




