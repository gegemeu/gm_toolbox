function P=gm_coeff_pol_Ritz_harm(A,v,k);
%GM_COEFF_POL_RITZ_HARM coefficients of the characteristic polynomial of the Hessenberg matrix for the harmonic Ritz values

% from the eigenvalues and eigenvectors of a normal matrix A

% See: G. Meurant, The coefficients of the FOM and GMRES residual polynomials,
%                  SIAM J. Matrix Anal. Appl., v 38 n 1 (2017), pp. 96-117

% H upper Hessenberg matrix from Arnoldi
% Caution: this is slow, A has to be small! and k too!

% Input:
% A = real normal matrix
% v = starting vector
% k = iteration number
%
% Output:
% P = polynomial in Matlab format

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(A,1);

if k >= n
 error('gm_coeff_pol_Ritz_harm: k must be smaller than order(A)')
end

% moment matrix
[M,X,D] = gm_moment(A,v);

% inverse of M_k
Mkinv = gm_Mkinv(A,v,k,X,D);

% coefficients of the polynomial for the Ritz values

alp = -Mkinv * M(1:k,k+1);

% We need U_(k+1,k+1)^2

lamb = diag(D);
c = X' * v;
om = abs(c).^2;

Ik = all_combi(n,k);
sIk = size(Ik,1);
Ikp1 = gm_all_combi(n,k+1);
sIkp1 = size(Ikp1,1);

% determinant of M_k
pom = zeros(sIk,1);
diff = zeros(sIk,1);
for j = 1:sIk
 pom(j) = prod(om(Ik(j,:)));
 diff(j) = gm_cumprod_diffs2(lamb(Ik(j,:)));
end % for j

dk = sum(pom .* diff);

% determinant of M_(k+1)
pom = zeros(sIkp1,1);
diff = zeros(sIkp1,1);
for j = 1:sIkp1
 pom(j) = prod(om(Ikp1(j,:)));
 diff(j) = gm_cumprod_diffs2(lamb(Ikp1(j,:)));
end % for j

dkp1 = sum(pom .* diff);

Ukp1 = dkp1 / dk;

beta = alp + (Ukp1 / conj(alp(1))) * Mkinv(:,1);

% change the order and add the coefficient of x^k

P = [1; beta(k:-1:1)];





