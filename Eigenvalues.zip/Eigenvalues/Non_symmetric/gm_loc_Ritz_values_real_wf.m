function gm_loc_Ritz_values_real_wf(A,nptx,npty);
%GM_LOC_RITZ_VALUES_REAL_WF location of the Ritz values for k = 2

% This is done by discretization of the FOV and thus not very reliable
%
% So far, this works only for the pairs of complex conjugate Ritz values
%
% without the call to figure

% Input:
% A = real normal matrix
% nptx, npty = number of points used for the discretization

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

% check that A is real
if ~isreal(A)
 error('gm_loc_Ritz_values_real_wf: A is not real')
end

warning off

n = size(A,1);

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

x = linspace(xmin,xmax,nptx);
y = linspace(0,ymax,npty);

for ii = 1:length(x)
 for jj = 1:length(y)
  theta = [x(ii) + y(jj) * 1i, x(ii) - y(jj) * 1i];
  
  [flag,v] = gm_find_v_gen_real(A,theta);
  
  if flag == 1
   plot(x(ii),y(jj),'b+')
   plot(x(ii),-y(jj),'r+')
  end
  
 end % for jj
end % for ii

hold off

warning on



