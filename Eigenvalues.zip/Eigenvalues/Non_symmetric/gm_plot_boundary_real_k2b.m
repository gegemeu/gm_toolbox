function gm_plot_boundary_real_k2b(A);
%GM_PLOT_BOUNDARY_REAL_K2B boundaries of the region containing Ritz values for Arnoldi second iteration

% Improved version of gm_plot_boundary_real_k2
% not perfect though!

% A is a normal matrix that must be real as well as the Arnoldi starting vector
% for the Ritz values to be in this region of the complex plane

% See the paper:
% G. Meurant, On the location of the Ritz values in the Arnoldi process,
% ETNA, v 43 (2014-2015), pp. 188-212

% Input:
% A = real normal matrix

%
% Author G. Meurant
% February 2013
%

fac = 0.95;
npts = 15;
nplim = 4;

% check that A is real
if ~isreal(A)
 error('gm_plot_boundary_real_k2b: A is not real')
end

n = size(A,1);

if n <= 2
 error('gm_plot_boundary_real_k2b: the order of A has to be larger than 2')
end

% get the eigenvalues with complex conjugate pairs first

[AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);

% plot the field of values

[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

% case n = 3 **************

if n == 3
 
 warning off
 
 gm_myezplot_simpler(@(x,y)func_theta_n3(x,y,lambda(1),lambda(3)),[xmin,xmax,ymin,ymax])
 
 title('          ')
 xlabel('   ')
 ylabel('   ')
 
 hold off
 
 warning on
 
 return
end % if n = 3

% case n = 4 *************************

if n == 4
 
 warning off
 
 if img == 1
  
  % case n = 4 with only complex eigenvalues
  
  % complex conjugate Ritz values
  
  gm_myezplot_simpler(@(x,y)func_theta_n4(x,y,lambda(1),lambda(3)),[xmin,xmax,ymin,ymax])
  
  title('          ')
  xlabel('   ')
  ylabel('   ')
  
  % compute values on the curve plotted by gm_myezplot_simpler
  
  a = linspace(xmin,xmax,30);
  
  for jj = 1:length(a)
   b = func_imag_n4(a(jj),lambda(1),lambda(3));
   if ~isempty(b)
%     plot(a(jj),b,'b*')
%     plot(a(jj),-b,'b*')
   end % if isempty
  end % for jj
  
  % real eigenvalues (this seems to be wrong!)
  
  for ii = 1:4
   for j = ii+1:4
    delta(ii,j) = lambda(ii) * conj(lambda(j)) + lambda(j) * conj(lambda(ii)) ...
     - (abs(lambda(j))^2 + abs(lambda(ii))^2);
   end % for j
  end % for ii
  
  x = linspace(xmin,xmax,70);
  
  for k = 1:length(x);
   
   for ii = 1:4
    for j = ii+1:4
     alpha(ii,j) = (x(k) - lambda(ii)) * (lambda(j) - x(k)) * delta(ii,j);
    end % for j
   end % for ii
   
   s = real(alpha(1,3) + alpha(1,4) + alpha(2,3) + alpha(2,4));
   ca = real(alpha(1,2) + alpha(3,4) - s);
   cb = real(-(alpha(3,4) - s / 2));
   cc = real(alpha(3,4) / 4 + s / 2);
   
   Delta = cb^2 - 4 * ca * cc;
   
   if Delta > 0
    omm1 = [];
    % check if there is a positive solution
    omp = (-cb + sqrt(Delta)) / (2 * ca);
    omm = (-cb - sqrt(Delta)) / (2 * ca);
    if (omp >= 0) & (omp <= 1/2)
     omm1 = omp;
    elseif (omm >= 0) & (omm <= 1/2)
     omm1 = omm;
    else
     omm1 = [];
    end % if omp
    
    if ~isempty(omm1)
     omm3 = 1/2 - omm1;
     omega = [omm1; omm1; omm3; omm3];
     c = sqrt(omega);
     tt = x(k) - lambda;
     rootn3 = sum(omega' .* lambda .* tt) / sum(omega' .* tt);
%      if isreal(rootn3)
%       plot(x(k),0,'b+')
%       plot(rootn3,0,'g+')
%      end % if isreal
    end % if isempty
   end % if Delta
  end % for k
  
  hold off
  
  warning on
  
  return
 end % if img == 1
end % if n == 4

warning off

% general case **************************************

% n=4 with two real eigenvalues and general case n>4

% plot the boundaries

% boundary for n = 4 *****************

if n == 4
 
 % boundary of the feasible region
 
 % we have a 3 x 3 matrix only if p = 1
 % the case 3 x 2 with p = 2 was handled above
 
 % corresponds to 2, 1, 1
 % 1 pair - 1, 2 real - 3,4
 
 gm_myezplot_simpler(@(x,y)func_theta_n4_bndry2(x,y,lambda(1),lambda(3),lambda(4)),[xmin,xmax,ymin,ymax])
 gm_myezplot_simpler(@(x,y)func_theta_n4_bndry3(x,y,lambda(1),lambda(3),lambda(4)),[xmin,xmax,ymin,ymax])
 
 title('    ')
 xlabel('   ')
 ylabel('   ')
 
 hold off
 
 warning on
 
 return
 
end % if n == 4

% end n = 4 ************************

% boundary n = 5 ***********************

if (n == 5) && (p <= 2)
 
 % boundary of the feasible region
 
 if p == 2
  % corresponds to 2, 2, 1
  % 2 pairs - 1,3, 1 real - 5
  gm_myezplot_simpler(@(x,y)func_theta_n5_bndry1(x,y,lambda(1),lambda(3),lambda(5)),[xmin,xmax,ymin,ymax])
  gm_myezplot_simpler(@(x,y)func_theta_n5_bndry2(x,y,lambda(1),lambda(3),lambda(5)),[xmin,xmax,ymin,ymax])
  gm_myezplot_simpler(@(x,y)func_theta_n5_bndry3(x,y,lambda(1),lambda(3),lambda(5)),[xmin,xmax,ymin,ymax])
 end % if p
 
 if p == 1
  % corresponds to 2, 1, 1
  % 1 pair - 1, 2 real - in 3, 4, 5
  % consider all (ordered) combinations, some curves are redundant, the
  % real- real yield nothing
    
  gm_myezplot_simpler(@(x,y)func_theta_n4_bndry2(x,y,lambda(1),lambda(3),lambda(4)),[xmin,xmax,ymin,ymax]) % la1 - la4
  gm_myezplot_simpler(@(x,y)func_theta_n4_bndry3(x,y,lambda(1),lambda(3),lambda(4)),[xmin,xmax,ymin,ymax]) % la1 - la3  
  gm_myezplot_simpler(@(x,y)func_theta_n4_bndry2(x,y,lambda(1),lambda(3),lambda(5)),[xmin,xmax,ymin,ymax]) % la1 - la5
  
 end % if p
 
 title('    ')
 xlabel('   ')
 ylabel('   ')
 
 hold off
 
 warning on
 
 return
 
end % if n == 5

% end n = 5 ************************

% boundary general case ************

% general case
% consider all triples of eigenvalues
% a pair counts for one
% then call (2, 1, 1) or (2, 2, 1) or (2, 2, 2)
% this corresponds to the first row of the matrix C_C
% the functions define the curves f(x,y) = 0 for each row
% of the 3 x 3 matrix

% p is the number of pairs, total to consider n - p

% keep only one eigenvalue in a pair, with positive imaginary part
III = [];
for j = 1:p
 if imag(lambda(2*j-1)) > 0
  III = [III 2*j-1];
 else
  III = [III 2*j];
 end % if imag
end % for j

% eigenvalues to consider
ind = [III IR];
lamb = lambda(ind);
% must be equal to n - p
np = length(lamb);

% the tests eliminate some of the redundancy
% but there are still redundant curves!!!!

ncurves = 0;

warning off

for ii = 1:np
 for jj = ii+1:np
  for kk = jj+1:np
   
   %---------------------------------------------------------
   if (~isreal(lamb(ii))) && (~isreal(lamb(jj))) && (~isreal(lamb(kk)))
    % (2, 2, 2), only 3 complex conjugate pairs
    
    % --------------depends only on jj, kk
    if ii == 1    
     % consider the boundary as "horizontal" between jj and kk
     ym = min(imag(lamb(jj)),imag(lamb(kk))) * fac;
     yM = max(imag(lamb(jj)),imag(lamb(kk))) * fac;
     y = linspace(ym,yM,npts);
     nbd3 = 0;
     fbd = 0;
     % starting point for fzero (in bdnry_pointsk2)
     start = real(lamb(jj));
     %      start = (real(lamb(jj)) + real(lamb(kk))) / 2;
     for kkk = 1:length(y)
      % compute x for y(kkk)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry1(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       start,lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd3 = nbd3 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     % this is a real horizontal boundary of the FOV
     if abs(yM-ym) < 1e-3
      fbd = 1;
     end % if abs
     
     % consider the boundary as "vertical"
     % remember that the figure is symmetric (x-axis)
     ym = 0;
     yM = max(imag(lamb(jj)),imag(lamb(kk))) * fac;
     y = linspace(ym,yM,npts);
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry1(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(jj)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd3 = nbd3 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     for kkk = 1:length(y)
      % start with the other point
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry1(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(kk)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd3 = nbd3 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd3 >= nplim)
      % passes through lamb(jj), lamb(kk) (and/or their conjugates)
      gm_myezplot_simpler(@(x,y)func_theta_n6_bndry1(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if ii == 1
    
    % -----------------depends only on ii, kk
    if jj == ii+1
     % consider the boundary as "horizontal" between ii and kk
     ym = min(imag(lamb(ii)),imag(lamb(kk))) * fac;
     yM = max(imag(lamb(ii)),imag(lamb(kk))) * fac;
     y = linspace(ym,yM,npts);
     nbd2 = 0;
     fbd = 0;
     start = real(lamb(ii));
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry2(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       start,lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd2 = nbd2 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     % this is a real horizontal boundary of the FOV
     if abs(yM-ym) < 1e-3
      fbd = 1;
     end % if abs
     
     % consider the boundary as "vertical" between ii and kk
     ym = 0;
     yM = max(imag(lamb(ii)),imag(lamb(kk))) * fac;
     y = linspace(ym,yM,npts);
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry2(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd2 = nbd2 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     for kkk = 1:length(y)
      % start with the other point
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry2(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(kk)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd2 = nbd2 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd2 >= nplim)
      % passes through lamb(ii), lamb(kk) (and their conjugates)
      gm_myezplot_simpler(@(x,y)func_theta_n6_bndry2(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if jj == ii + 1
    
    % --------------------depends only on ii, jj
    if kk == jj+1
     % consider the boundary as "horizontal" between ii and jj
     ym = min(imag(lamb(jj)),imag(lamb(ii))) * fac;
     yM = max(imag(lamb(jj)),imag(lamb(ii))) * fac;
     y = linspace(ym,yM,npts);
     fbd = 0;
     nbd1 = 0;
     start = real(lamb(ii));
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       start,lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     % this is a real horizontal boundary of the FOV
     if abs(yM-ym) < 1e-3
      fbd = 1;
     end % if abs
     
     % consider the boundary as "vertical" between ii and jj
     ym = 0;
     yM = max(imag(lamb(jj)),imag(lamb(ii))) * fac;
     y = linspace(ym,yM,npts);
     fbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     for kkk = 1:length(y)
      % start with the other point
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n6_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(jj)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd1 >= nplim)
      % passes through lamb(ii), lamb(jj) (and their conjugates)
      gm_myezplot_simpler(@(x,y)func_theta_n6_bndry3(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if kk == jj + 1
    
    %--------------------------------------------------------------------
   elseif (~isreal(lamb(ii))) && (~isreal(lamb(jj))) && (isreal(lamb(kk)))
    % (2, 2, 1), two complex conjugate pairs, one real
    
    % ----------------depends only on jj, kk
    if ii == 1  
     ym = imag(lamb(jj)) * fac;
     y = linspace(0,ym,npts);
     fbd = 0;
     nbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n5_bndry1(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(jj)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd = nbd + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd >= nplim)
      gm_myezplot_simpler(@(x,y)func_theta_n5_bndry1(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if ii == 1
    
    % ------------------depends only on ii, kk
    if jj == ii+1   
     ym = imag(lamb(ii)) * fac;
     y = linspace(0,ym,npts);
     fbd = 0;
     nbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n5_bndry2(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd = nbd + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd >= nplim)
      gm_myezplot_simpler(@(x,y)func_theta_n5_bndry2(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if jj == ii + 1
    
    % -----------------depends only on ii, jj
    if kk == jj+1   
     % consider the boundary as "horizontal" between ii and jj
     ym = min(imag(lamb(jj)),imag(lamb(ii))) * fac;
     yM = max(imag(lamb(jj)),imag(lamb(ii))) * fac;
     y = linspace(ym,yM,npts);
     fbd = 0;
     nbd1 = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n5_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     % this is a real horizontal boundary of the FOV
     if abs(yM-ym) < 1e-3
      fbd = 1;
     end % if abs
     
     % consider the boundary as "vertical" between ii and jj
     ym = 0;
     yM = max(imag(lamb(jj)),imag(lamb(ii))) * fac;
     y = linspace(ym,yM,npts);
     fbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n5_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     for kkk = 1:length(y)
      % start with the other point
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n5_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(jj)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd1 = nbd1 + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd1 >= nplim)
      gm_myezplot_simpler(@(x,y)func_theta_n5_bndry3(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if kk == jj + 1
    
    %---------------------------------------------------------
   elseif (~isreal(lamb(ii))) && (isreal(lamb(jj))) && (isreal(lamb(kk)))
    % (2, 1, 1) one complex conjugate pair, two real
    
    % ---------------depends only on ii, kk
    if jj == ii+1
     
     ym = imag(lamb(ii)) * fac;
     y = linspace(0,ym,npts);
     fbd = 0;
     nbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n4_bndry2(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd = nbd + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd >= nplim)
      gm_myezplot_simpler(@(x,y)func_theta_n4_bndry2(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if jj == ii + 1
    
    % ---------------------depends only on ii, jj
    if kk == jj+1  
     ym = imag(lamb(ii)) * fac;
     y = linspace(0,ym,npts);
     fbd = 0;
     nbd = 0;
     for kkk = 1:length(y)
      [flag_bnd,xb] = gm_bndry_pointsk2(@(x)func_theta_n4_bndry3(x,y(kkk),lamb(ii),lamb(jj),lamb(kk)), ...
       real(lamb(ii)),lambda,xmin,xmax,ymin,ymax,y(kkk));
      if flag_bnd == 1
       nbd = nbd + 1;
       fbd = 1;
%        plot(xb,y(kkk),'b*')
%        plot(xb,-y(kkk),'b*')
      end % if flag
     end % for kkk
     
     if (fbd == 1) && (nbd >= nplim)
      gm_myezplot_simpler(@(x,y)func_theta_n4_bndry3(x,y,lamb(ii),lamb(jj),lamb(kk)),[xmin,xmax,ymin,ymax],'b')
      ncurves = ncurves + 1;
     end % if fbd
     
    end % if kk == jj + 1
    
   else
    % (1, 1, 1) is not useful. it's only real eigenvalues

   end % if isreal
   
  end % for kk
 end % for jj
end % for ii

% fprintf('\n There are %d curves \n',ncurves)

title('    ')
xlabel('   ')
ylabel('   ')

hold off

warning on

% end general case *****************************

end

% auxiliary functions

function val=func_theta_n3(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values

r1 = real(lamb1);

D1 = - 4 * x * r1 + 4 * x * lamb3 + 2 * real(lamb1^2) - 2 * lamb3^2;
N1 = 2 * x * lamb3 - lamb3^2 - x.^2 - y.^2;

D2 = 4 * x * abs(lamb1)^2 - 4 * x * lamb3^2 - 2 * abs(lamb1)^2 * r1 + 2 * lamb3^3 ...
 - 2 * (x.^2 + y.^2) * r1 + 2 * (x.^2 + y.^2) * lamb3;
N2 = - 2 * x * lamb3^2 + lamb3^3 + (x.^2 + y.^2) * lamb3;

val = N1 .* D2 - N2 .* D1;

end


function val=func_theta_n4(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values for n = 4

r1 = real(lamb1);
r3 = real(lamb3);

D1 = - 4 * x * r1 + 4 * x * r3 + 2 * real(lamb1^2) - 2 * real(lamb3^2);
N1 = 2 * x * lamb3 - real(lamb3^2) - x.^2 - y.^2;

D2 = 4 * x * abs(lamb1)^2 - 4 * x * abs(lamb3^2) - 2 * abs(lamb1)^2 * r1 + 2 * abs(lamb3^2) * r3 ...
 - 2 * (x.^2 + y.^2) * r1 + 2 * (x.^2 + y.^2) * r3;
N2 = - 2 * x * abs(lamb3)^2 + abs(lamb3)^2 * r3 + (x.^2 + y.^2) * r3;

val = N1 .* D2 - N2 .* D1;

end

function b=func_imag_n4(a,lamb1,lamb3);
% gives the imaginary part or [] for n = 4

b = [];

r1 = real(lamb1);
r3 = real(lamb3);

alp = 2 * a * r3 - real(lamb3^2) - a.^2;
bet = 4 * a * (abs(lamb1)^2 - abs(lamb3)^2) - 2 * abs(lamb1)^2 * r1 ...
 + 2 * abs(lamb3)^2 * r3 - 2 * a.^2 * (r1 - r3);
gam = - 2 * a * abs(lamb3)^2 + a.^2 * r3 + abs(lamb3)^2 * r3;
del =  4 * a * (r3 - r1) + 2 * real(lamb1^2) - 2 * real(lamb3^2);

% coefficient of the quadratic equation in b^2

ca = 2 * (r1 - r3);
cb = - (bet + 2 * alp * (r1 - r3) + del * r3);
cc = alp * bet - gam * del;

Delta = cb.^2 - 4 * ca .* cc;

if Delta < 0
 return
else
 D = sqrt(Delta);
 b2p = (-cb + D) / ( 2 * ca);
 b2m = (-cb - D) / ( 2 * ca);
 if (b2p < 0) && (b2m < 0)
  return
 else
  b2 = max(b2p,b2m);
  b = sqrt(b2);
  D1 = - 4 * a * r1 + 4 * a * r3 + 2 * real(lamb1^2) - 2 * real(lamb3^2);
  N1 = 2 * a * lamb3 - real(lamb3^2) - a.^2 - b.^2;
  om1 = N1 / D1;
  if (om1 > 0) && (om1 < 1/2)
   return
  else
   b = [];
   return
  end
 end
end

end


function val = func_theta_n4_bndry2(x,y,lamb1,lamb3,lamb4);
% boundary for n = 4
% corresponds to (2, 1, 1)

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
e = s * lamb4 - lamb4^2;
f = s * lamb4^2 - lamb4^3 - p * lamb4;

val = e * b - a * f + (2 * f - b) *  p;

end

function val = func_theta_n4_bndry3(x,y,lamb1,lamb3,lamb4);
% boundary for n = 4
% corresponds to (2, 1, 1)

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
c = s * lamb3 - lamb3^2;
d = s * lamb3^2 - lamb3^3 - p * lamb3;

val = a * d - c * b + (b - 2 * d) * p;

end

function val = func_theta_n5_bndry1(x,y,lamb1,lamb3,lamb5);
% boundary for n = 5
% corresponds to (2, 2, 1)

s = 2 * x;
p = x.^2 + y.^2;

r3 = real(lamb3);

c = 2 * s * r3 - 2 * real(lamb3^2);
d = 2 * s * abs(lamb3)^2 - 2 * abs(lamb3)^2 * r3 - 2 * p * r3;
e = s * lamb5 - lamb5^2;
f = s * lamb5^2 - lamb5^3 - p * lamb5;

val = c * f - e * d + (d - 2 * f) * p;

end

function val = func_theta_n5_bndry2(x,y,lamb1,lamb3,lamb5);
% boundary for n = 5
% corresponds to (2, 2, 1)

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
e = s * lamb5 - lamb5^2;
f = s * lamb5^2 - lamb5^3 - p * lamb5;

val = e * b - a * f + (2 * f - b) * p;

end

function val = func_theta_n5_bndry3(x,y,lamb1,lamb3,lamb5);
% boundary for n = 5
% corresponds to (2, 2, 1)

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);
r3 = real(lamb3);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
c = 2 * s * r3 - 2 * real(lamb3^2);
d = 2 * s * abs(lamb3)^2 - 2 * abs(lamb3)^2 * r3 - 2 * p * r3;

val = a * d - c * b + 2 * (b - d) * p;

end

function val = func_theta_n6_bndry1(x,y,lamb1,lamb3,lamb5);
% boundary for n = 6 and beyond
% corresponds to (2, 2, 2)

s = 2 * x;
p = x.^2 + y.^2;

r3 = real(lamb3);
r5 = real(lamb5);

c = 2 * s * r3 - 2 * real(lamb3^2);
d = 2 * s * abs(lamb3)^2 - 2 * abs(lamb3)^2 * r3 - 2 * p * r3;
e = 2 * s * r5 - 2 * real(lamb5^2);
f =  2 * s * abs(lamb5)^2 - 2 * abs(lamb5)^2 * r5 - 2 * p * r5;

val = (c * f - e * d) / 2 + (d - f) * p;

end

function val = func_theta_n6_bndry2(x,y,lamb1,lamb3,lamb5);
% boundary for n = 6 and beyond
% corresponds to (2, 2, 2)

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);
r5 = real(lamb5);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
e = 2 * s * r5 - 2 * real(lamb5^2);;
f = 2 * s * abs(lamb5)^2 - 2 * abs(lamb5)^2 * r5 - 2 * p * r5;

val = (e * b - a * f) / 2 + (f - b) *p;

end

function val = func_theta_n6_bndry3(x,y,lamb1,lamb3,lamb5);
% boundary for n = 6 and beyond

s = 2 * x;
p = x.^2 + y.^2;

r1 = real(lamb1);
r3 = real(lamb3);

a = 2 * s * r1 - 2 * real(lamb1^2);
b = 2 * s * abs(lamb1)^2 - 2 * abs(lamb1)^2 * r1 - 2 * p * r1;
c = 2 * s * r3 - 2 * real(lamb3^2);
d = 2 * s * abs(lamb3)^2 - 2 * abs(lamb3)^2 * r3 - 2 * p * r3;

val = (a * d - c * b) / 2 + (b - d) * p;

end







