function gm_random_Ritzval_harminv_allk(A,nsamp);
%GM_RANDOM_RITZVAL_HARMINV_ALLK harmonic Ritz values at all Arnoldi iterations for random rhs

% Arnoldi started with real random vectors

% plot of the inverses of the eigenvalues

% Input:
% A = matrix
% nsamp = number of random rhs

%
% Author G. Meurant
% January 2013
%

warning('off')

n = size(A,1);

iA = inv(A);

figure

% field of values of the inverse
gm_fvmod(iA,1,32,0);
hold on

for ii = 1:n-1
 
 for k = 1:nsamp
  v = randn(n,1);
  v = v / norm(v);
  
 % Arnoldi 
 [VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,ii+1,'noreorth','noprint');
  
  Hii = H(1:ii,1:ii);
  bet = H(ii+1,ii);
  eii = zeros(ii,1); eii(ii) = 1;
  y = (Hii') \ eii;
  Hii(:,ii) = Hii(:,ii) + bet^2 * y;
  eigHii = eig(full(Hii));
  
  for j = 1:ii
   if isreal(eigHii(j))
    plot(1/eigHii(j),0,'g+')
   else
    if imag(eigHii(j)) > 0
     plot(real(1/eigHii(j)),imag(1/eigHii(j)),'b+')
    else
     plot(real(1/eigHii(j)),imag(1/eigHii(j)),'r+')
    end % if imag
   end % if isreal
  end % for j
  
 end % for k
 
end % for ii

hold off

warning('on')

