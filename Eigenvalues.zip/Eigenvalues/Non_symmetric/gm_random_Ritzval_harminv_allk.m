function gm_random_Ritzval_harminv_allk(A,nsamp,bnd);
%GM_RANDOM_RITZVAL_HARMINV_ALLK Harmonic Ritz values at all Arnoldi iterations for random rhs

% Arnoldi started with real random vectors

% plot of the inverses of the eigenvalues

% We compute the inverse of A which must be small

% Input:
% A = matrix
% nsamp = number of random rhs
% bnd = 'bndry' with the boundary of the Ritz values of inv(A)

%
% Author G. Meurant
% January 2013
%

warning off

n = size(A,1);

figure

iA = inv(A);

% field of values of the inverse
gm_fvmod(iA,1,32,1);
hold on

for ii = 1:n-1
 
 for k = 1:nsamp
  v = randn(n,1);
  v = v / norm(v);
  
 % Arnoldi 
 [VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,ii+1,'noreorth','noprint');
  
  Hii = H(1:ii,1:ii);
  bet = H(ii+1,ii);
  eii = zeros(ii,1); eii(ii) = 1;
  y = (Hii') \ eii;
  Hii(:,ii) = Hii(:,ii) + bet^2 * y;
  eigHii = eig(full(Hii));
  
  for j = 1:ii
   if isreal(eigHii(j))
    plot(1/eigHii(j),0,'g+')
   else
    if imag(eigHii(j)) > 0
     plot(real(1/eigHii(j)),imag(1/eigHii(j)),'b+')
    else
     plot(real(1/eigHii(j)),imag(1/eigHii(j)),'r+')
    end % if imag
   end % if isreal
  end % for j
  
 end % for k
 
end % for ii

if nargin <= 2
 hold off
 return
end

if strcmpi(bnd,'bndry') == 1
 % boundary curves for the inverse
 gm_plot_boundary_real_k2b(iA);
end

hold off

warning on

