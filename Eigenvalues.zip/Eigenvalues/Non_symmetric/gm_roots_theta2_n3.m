function [rootn3,c]=gm_roots_theta2_n3(A,theta1);
%GM_ROOTS_THETA2_N3 computation of theta2 with theta1 given, k = 2

% the argument can be the eigenvalues (3x1) or A

% Input:
% A = 3x3 matrix
% theta1 = given Ritz value
%
% Output:
% rootn3 = second Ritz value
% c = starting vector

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

delta = zeros(3,3);
alpha = delta;
rootn3 = [];
c = [];

if size(A,1) == 1
 iA = 0;
 lambda = A;
elseif size(A,2) == 1
 iA = 0;
 lambda = transpose(A);
else
 lambda = transpose(eig(A));
 II = find_imag(lambda);
 IR = find_real(lambda);
 lambda = [lambda(II) lambda(IR)];
 iA = 0;
 if isreal(A)
  iA = 1;
  % if A is real, the answer is conj(theta1) or nothing
  theta = [theta1, conj(theta1)];
  [flag,c] = gm_find_v_gen_real(A,theta);
  if flag == 0
   return
  else
   rootn3 = conj(theta1);
   return
  end % if flag
 end % if isreal
end % if size

II = find_imag(lambda);
if isempty(II)
 disp('gm_roots_theta2_n3: This case is not handled')
 return
end % if isempty

for i = 1:3
 for j = i+1:3
  delta(i,j) = lambda(i) * conj(lambda(j)) + lambda(j) * conj(lambda(i)) ...
   - (abs(lambda(j))^2 + abs(lambda(i))^2);
  alpha(i,j) = (theta1 - lambda(i)) * (lambda(j) - theta1) * delta(i,j);
 end % for j
end % for i

if iA == 1 && isreal(theta1)
 omm1 = -(alpha(1,3) + alpha(2,3)) / (alpha(1,2) - 2 * (alpha(1,3)+alpha(2,3)));
 omm3 = 1 - 2 * omm1;
 omega = [omm1; omm1; omm3];
 c = sqrt(omega);
 tt = theta1 - lambda;
 rootn3 = sum(omega' .* lambda .* tt) / sum(omega' .* tt);
 return
end % if iA

alphaR = real(alpha);
alphaI = imag(alpha);

% intersection of the two hyperbolas

a1 = -alphaR(1,3);
b1 = alphaR(1,2) - alphaR(1,3) - alphaR(2,3);
c1 = -alphaR(2,3);
d1 = alphaR(1,3);
e1 = alphaR(2,3);

a2 = -alphaI(1,3);
b2 = alphaI(1,2) - alphaI(1,3) - alphaI(2,3);
c2 = -alphaI(2,3);
d2 = alphaI(1,3);
e2 = alphaI(2,3);

if abs(c2) > 1e-13
 cc = c1 / c2;
 alp = a1 - cc * a2;
 bet = b1 - cc * b2;
 del = d1 - d2 * cc;
else
 alp = a2;
 bet = b2;
 del = d2;
end % if abs

om1 = (c1 * alp * (alp - bet)) / (a1 * bet^2 - b1 * alp * bet + c1 * alp^2);
om2 = (-alp * om1 - del) / bet;
om3 = 1 - om1 - om2;

omega = [om1; om2; om3];

tt = theta1 - lambda;

rootn3 = sum(omega' .* lambda .* tt) / sum(omega' .* tt);

c = sqrt(omega);

end % function

function II=find_imag(x);
% find the imaginary components

n = length(x);
II = [];
for j = 1:n
 if ~isreal(x(j))
  II = [II j];
 end % if isreal
end % for j

end
 
function II=find_real(x);
% find the real components

n = length(x);
II = [];
for j = 1:n
 if isreal(x(j))
  II = [II j];
 end % if isreal
end % for j

end
