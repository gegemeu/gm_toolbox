function theta = gm_Ritz_harm(H,k);
%GM_RITZ_HARM harmonic Ritz values at iteration k

% Input:
% H = upper Hessenberg matrix from Arnoldi
% k = iteration number
%
% Output:
% theta = harmonic Ritz value

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(H,1);
if k > n
 error('gm_Ritz_harm: k must be smaller than size(H,1)')
end

if k == n
 theta = eig(full(H));
 return
end

Hk = H(1:k,1:k);
bet = H(k+1,k);
eii = zeros(k,1);
eii(k) = 1;
y = (Hk') \ eii;
Hk(:,k) = Hk(:,k) + bet^2 * y;

theta = eig(full(Hk));



