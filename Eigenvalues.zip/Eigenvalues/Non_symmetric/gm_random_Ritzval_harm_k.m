function gm_random_Ritzval_harm_k(A,nsamp,k);
%GM_RANDOM_RITZVAL_HARM_K Harmonic Ritz values at iteration k for random rhs

% Arnoldi started with real random vectors

% Input:
% A = matrix
% nsamp = number of random rhs
% k = iteration number

%
% Author G. Meurant
% October 2013
% Updated Sept 2015
%

n = size(A,1);

figure

% field of values
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

dx = abs(xmax - xmin);
dy = abs(ymax - ymin);
xmi = xmin - 2 * dx;
xma = xmax + 2 * dx;
ymi = ymin - 2 * dy;
yma = ymax + 2 * dy;

axis([xmi,xma,ymi,yma]);

ii = k;

for k = 1:nsamp
 v = randn(n,1);
 v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,ii+1,'noreorth','noprint');
 
 Hii = H(1:ii,1:ii);
 bet = H(ii+1,ii);
 eii = zeros(ii,1); eii(ii) = 1;
 y = (Hii') \ eii;
 Hii(:,ii) = Hii(:,ii) + bet^2 * y;
 eigHii = eig(full(Hii));
 
 for j = 1:ii
  if isreal(eigHii(j))
   plot(eigHii(j),0,'g+')
  else
   if imag(eigHii(j)) > 0
    plot(real(eigHii(j)),imag(eigHii(j)),'b+')
   else
    plot(real(eigHii(j)),imag(eigHii(j)),'r+')
   end % if imag
  end % if isreal
 end % for j
 
end % for k

hold off


