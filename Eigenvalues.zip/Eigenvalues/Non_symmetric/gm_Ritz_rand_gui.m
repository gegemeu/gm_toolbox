function gm_Ritz_rand_gui
%GM_RITZ_RAND_GUI location of the second Ritz value

% This shows an example of the region where the second Ritz value is
% for the second Arnoldi iteration when the first Ritz value is fixed

% One can give the location of the first Ritz value either by its
% coordinates or by clicking on First Ritz... and then using the mouse
% When the first Ritz value is given, click on 2nd Ritz...
% To exit click exit

% random normal matrix

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

% normal random matrix
n = 6;
A = gm_gen_Anormal_gen(n);

% fixed Ritz default value
theta1 = 0;

fig = figure( ...
 'Name', 'Ritz values, random normal matrix', ...
 'NumberTitle', 'off');

% axes for drawing
ax = axes('Parent', fig, ...
 'Units', 'normalized', ...
 'OuterPosition', [0.2 0 0.8 1], ...
 'DrawMode','fast', ...
 'XLimMode', 'manual', ...
 'YLimMode', 'manual', ...
 'ZLimMode', 'manual');

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

plot(real(theta1),imag(theta1),'bd')

% number of discretization points
nptx = 60;
npty = 60;

x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

fRitz = uicontrol('Style','pushButton','String','1st Ritz val.',...
 'Position',[50,150,70,25],...
 'Callback',@fRitz_callback);
Compute = uicontrol('Style','pushButton','String','2nd Ritz val.',...
 'Position',[50,100,70,25],...
 'Callback',@Compute_callback);
Stop = uicontrol('Style','pushButton','String','Exit',...
 'Position',[50,50,70,25],...
 'Callback',@Stop_callback);

tetR = uicontrol('Style','edit','String',num2str(real(theta1)),...
 'Position',[50,300,70,25],...
 'Callback',@edittextR_callback);
textR = uicontrol('Style','text','String','R',...
 'Position',[30,300,10,25]);
tetI = uicontrol('Style','edit','String',num2str(imag(theta1)),...
 'Position',[50,250,70,25],...
 'Callback',@edittextI_callback);
textI = uicontrol('Style','text','String','I',...
 'Position',[30,250,10,25]);
status = uicontrol('Style','edit','String','Waiting',...
 'Position',[50,200,70,25]);

 function fRitz_callback(hObject,eventdata)

  hold off

  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on

  % value of the fixed Ritz value

  [x1,y1,button] = ginput(1);

  theta1 = x1 + 1i * y1;

  plot(real(theta1),imag(theta1),'bd')

 end

 function Compute_callback(hObject,eventdata)

  % compute and plot the locations of the second Ritz value

  set(status,'String','Busy');
  drawnow

  for ii = 1:length(x)
   for jj = 1:length(y)
    % second Ritz value
    theta2 = x(ii) + y(jj) * 1i;
    % build the matrix CR and the rhs
    [CC,CR,rhsC,rhsR] = gm_C_matrix_gen(A,[theta1,theta2]);
    % SVD of CR
    [U,S,V] = svd(CR);
    V1 = V(:,1:5);
    V2 = V(:,6);
    % partial solution
    yy = S(:,1:5) \ (U' * rhsR);
    % check the feasibility of having a positive solution
    [flag,z] = gm_check_ineq(-V2,V1*yy);
    if flag == 1
     plot(x(ii),y(jj),'b+')
    end
   end % for jj
  end % for ii

  plot(real(theta1),imag(theta1),'bd')

  set(tetR,'String',num2str(real(theta1)));
  set(tetI,'String',num2str(imag(theta1)));

  set(status,'String','Waiting');
  drawnow

 end

 function edittextR_callback(hObject,eventdata)

  tetaR = get(hObject,'String');
  tetaR = str2double(tetaR);
  set(tetR,'String',num2str(tetaR));

  old_theta = theta1;
  theta1 = tetaR + 1i * imag(old_theta);

  hold off

  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on

  plot(real(theta1),imag(theta1),'bd')

 end

 function edittextI_callback(hObject,eventdata)

  tetaI = get(hObject,'String');
  tetaI = str2double(tetaI);
  set(tetI,'String',num2str(tetaI));

  old_theta = theta1;
  theta1 = real(old_theta) + 1i * tetaI;

  hold off

  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on

  plot(real(theta1),imag(theta1),'bd')

 end

 function Stop_callback(hObject,eventdata)

  % delete all figures
  set(0,'ShowHiddenHandles','on')
  delete(get(0,'Children'))
  return
 end

end
