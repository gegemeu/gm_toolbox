function gm_Ex_Bujanovic_a(nptx,npty);
%GM_EX_BUJANOVIC_A location of Arnoldi Ritz values for complex normal matrices

% Example of a 12 x 12 matrix, two Riz values, one fixed
% We look at the possible locations of the other Ritz value

%See:  Z. Bujanovic, On the permissible arrangements of Ritz values for normal matrices in the complex plane
%                    Linear Algebra Appl., v 438 (2013), pp. 4606-4624

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

% eigenvalues of the matrix
lambda = exp(1i * [0:5] * 2 * pi / 6);
% lambda = exp(i*[0:7]*2*pi/8);
A = diag(lambda);

% fixed Ritz value
% theta1 = -0.8;
% theta1 = 0 - 0.4 * 1i;
% theta1 = 0;
% theta1 = -0.7 - 0.4 * 1i;
% theta1 = - 0.5 * 1i;
theta1 = -0.5 - 0.8 * 1i;

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

% discretization of the box
x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

for ii = 1:length(x)
 for jj = 1:length(y)
  % second Ritz value
  theta2 = x(ii) + y(jj) * 1i;
  % build the matrix CR and the rhs
  [CC,CR,rhsC,rhsR] = gm_C_matrix_gen(A,[theta1,theta2]);
  % SVD of CR
  [U,S,V] = svd(CR);
  V1 = V(:,1:5);
  V2 = V(:,6:end);
  
  % partial solution
  yy = S(:,1:5) \ (U' * rhsR);
  
  % check the feasibility of having a positive solution
  [flag,X] = gm_check_ineq(-V2,V1*yy);
  if flag == 1
   plot(x(ii),y(jj),'b+')
  end % if flag
 end % for jj
end % for ii


plot(real(theta1),imag(theta1),'kd')

hold off






