function gm_Ex_Arnoldi(dit);
%GM_EX_ARNOLDI Example of Arnoldi iteration

% Matrix from the SUPG method

% Input:
% dit = integer stepsize for the vizualization of the Ritz values

%
% Author G. Meurant
% Sept 2015
%

load gm_supg001_225

A = full(A);

v = randn(225,1);
v = v /norm(v);

% the maximum number of iterations is 225, the order of A

gm_plot_Ritz_fov(A,v,dit,'bndry');

