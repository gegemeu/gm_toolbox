function gm_Ex_biLanczos(dit,itmax);
%GM_EX_BILANCZOS Example of nonsymmetric Lanczos iteration

% Matrix from the SUPG method

% Input:
% dit = stepsize for the vizualization of the Ritz values
% itmax = maximum number of Arnoldi iterations <= 100

%
% Author G. Meurant
% September 2015
%

load gm_supg001_1600

v = randn(1600,1);
v = v /norm(v);
itmax = min(itmax,100);

% biLanczos 
[V,W,T] = gm_biLanczos(A,v,itmax,'noprint');

gm_plot_Ritz(T,dit);




