function gm_Ex_Arnoldi_b(dit,itmax);
%GM_EX_ARNOLDI_B Example of Arnoldi iteration

% Matrix from the SUPG method

% Input:
% dit = stepsize for the vizualization of the Ritz values
% itmax = maximum number of Arnoldi iterations

%
% Author G. Meurant
% September 2015
%

load gm_supg001_1600

v = randn(1600,1);
v = v /norm(v);

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,itmax,'noreorth','noprint');

gm_plot_Ritz(H,dit);




