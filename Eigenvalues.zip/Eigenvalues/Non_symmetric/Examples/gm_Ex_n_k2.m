function gm_Ex_n_k2(n,nptx,npty);
%GM_EX_N_K2 Example of a n x n normal matrix, Arnoldi second (and 3rd) iteration

% location of the complex Ritz values and boundary

% Caution: n has to be small!!

%
% Author G. Meurant
% Sept 2015
%

A = gm_gen_Anormal_real(n);

gm_loc_Ritz_values_real_k2(A,nptx,npty,'bndry');
title('Location of the Ritz values, k = 2')

figure

gm_random_Ritzval_k(A,700,2,'bndry');
title('Location of the Ritz values, k = 2, random starting vectors')

if n <= 7
 
 gm_loc_Ritz_values_direct(A,nptx,2,'bndry');
 title('Location of the Ritz values, k = 2, direct method')
 
 gm_loc_Ritz_values_direct(A,nptx,3,'bndry');
 title('Location of the Ritz values, k = 3, direct method')
 
end % if n