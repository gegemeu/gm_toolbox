function gm_Ex_n6_k2(nptx,npty);
%GM_EX_N6_K2 Example of a 6 x 6 normal matrix, Arnoldi second iteration

% location of the complex Ritz values and boundary

% 
% Author G. Meurant
% Sept 2015
%

A = [-0.401151 0.0951597 0.336817 -0.0155421 0.342989 0.059462; ...
 0.0435544 -0.711607 -0.0851345 -0.100931 0.19691 -0.0848016; ...
 -0.3473 0.0330741 -0.458265 0.338473 0.161655 -0.163792; ...
 0.0903354 0.144387 0.0427703 -0.167152 0.14634 -0.661259; ...
 -0.309586 -0.118264 0.148041 -0.196687 -0.517635 -0.205145; ...
 0.131915 -0.142526 0.380522 0.570822 -0.0924846 -0.165907];

gm_loc_Ritz_values_real_k2(A,nptx,npty,'bndry');
title('Location of the Ritz values, k = 2')

figure

gm_random_Ritzval_k(A,700,2,'bndry');
title('Location of the Ritz values, k = 2, random starting vectors')

gm_loc_Ritz_values_direct(A,nptx,2,'bndry');
title('Location of the Ritz values, k = 2, direct method')

% gm_loc_Ritz_values_direct(A,nptx,3,'bndry');
% title('Location of the Ritz values, k = 3, direct method')

