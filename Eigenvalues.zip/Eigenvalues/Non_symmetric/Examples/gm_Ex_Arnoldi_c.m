function gm_Ex_Arnoldi_c(dit,itmax);
%GM_EX_ARNOLDI_C Example of Arnoldi iteration

% Matrix from the SUPG method

% Input:
% dit = stepsize for the vizualization of the Ritz values
% itmax = maximum number of Arnoldi iterations

%
% Author G. Meurant
% September 2015
%

% load gm_supg01_1600
% load gm_supg001_1600
load gm_supg0001_1600

v = randn(1600,1);
v = v /norm(v);

% Arnoldi 
tic
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,itmax,'noreorth','noprint');
t = toc;
fprintf(' Arnoldi, %d iterations, time = %g \n',itmax,t)

for k = 1:dit:size(H,1)
 muu = eig(full(H(1:k,1:k)));
 plot(real(muu),imag(muu),'kd')
 title(['Iteration ' num2str(k)])
 pause
end




