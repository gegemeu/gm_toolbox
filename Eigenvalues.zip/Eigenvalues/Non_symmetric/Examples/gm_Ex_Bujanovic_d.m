function gm_Ex_Bujanovic_d(nptx,npty);
%GM_EX_BUJANOVIC_D location of Arnoldi Ritz values for complex normal matrices

% Example of a 8 x 8 matrix, three Riz values, two fixed
% We look at the possible locations of the other Ritz value

% See: Z. Bujanovic, On the permissible arrangements of Ritz values for normal matrices in the complex plane
%                    Linear Algebra Appl., v 438 (2013), pp. 4606-4624

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

% eigenvalues of the matrix
lambda = exp(1i * [0:7] * 2 * pi / 8);
A = diag(lambda);

% fixed Ritz value
% theta1 = -0.5;
theta1 = -0.6 - 0.2 * 1i;
% theta2 = 0.5;
theta2 = 0.6 + 0.6 * 1i;


% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
axis([-1 1 -1 1]);
axis square;
hold on

% discretization of the box
x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

for ii = 1:length(x)
 for jj = 1:length(y)
  % second Ritz value
  theta3 = x(ii) + y(jj) * 1i;
  % build the matrix CR and the rhs
  [CC,CR,rhsC,rhsR] = gm_C_matrix_gen(A,[theta1,theta2,theta3]);
  % SVD of CR
  [U,S,V] = svd(CR);
  V1 = V(:,1:7);
  V2 = V(:,8);
  % partial solution
  yy = S(:,1:7) \ (U' * rhsR);
  
  % check the feasibility of having a positive solution

  [flag,z] = gm_check_ineq(-V2,V1*yy);

  if flag == 1
   plot(x(ii),y(jj),'b+')
  end % if flag
 end % for jj
end % for ii

plot(real(theta1),imag(theta1),'kd')
plot(real(theta2),imag(theta2),'ko')

hold off


