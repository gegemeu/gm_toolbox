function gm_Ex_Arnoldi_d(dit,itmax);
%GM_EX_ARNOLDI_D Example of Arnoldi iteration

% Matrix from the SUPG method

% Input:
% dit = stepsize for the vizualization of the Ritz values
% itmax = maximum number of Arnoldi iterations

%
% Author G. Meurant
% September 2015
%

load gm_supg001_1600

v = randn(1600,1);
v = v /norm(v);

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi_Hous(A,v,itmax,'noreorth','noprint');
nh = size(H,2);
H = H(1:nh,1:nh);

lambda = gm_harm_Ritz_values_H(H);

for k = 1:dit:size(lambda,2)
 for i = 1:k
  plot(real(lambda(i,k)),imag(lambda(i,k)),'b*')
  hold on
 end % for i
 title(['iteration ' num2str(k)])
 pause
 hold off
end % for k






