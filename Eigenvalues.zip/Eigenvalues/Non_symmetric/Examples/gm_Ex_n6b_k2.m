function gm_Ex_n6b_k2(nptx,npty);
%GM_EX_N6B_K2 Example of a 6 x 6 normal matrix, Arnoldi second iteration

% location of the complex Ritz values and boundary

% 
% Author G. Meurant
% Sept 2015
%

A = [0.0433091 1.59759 -0.318964 -0.787924 -1.5765 0.538701; ...
 0.222478 -0.276959 0.775185 1.54146 1.8561 0.818277; ...
 0.348846 -0.0614769 1.02246 -0.677541 -0.498161 0.193331; ...
 1.05979 -1.7532 -0.176368 0.214925 -0.563343 -0.580403; ...
 2.01859 -0.900034 0.21777 -1.05788 -0.388673 -1.0512; ...
 0.825456 -0.837442 0.298154 -0.554189 0.812614 0.77613];

gm_loc_Ritz_values_real_k2(A,nptx,npty,'bndry');
title('Location of the Ritz values, k = 2')

figure

gm_random_Ritzval_k(A,700,2,'bndry');
title('Location of the Ritz values, k = 2, random starting vectors')

gm_loc_Ritz_values_direct(A,nptx,2,'bndry');
title('Location of the Ritz values, k = 2, direct method')

% gm_loc_Ritz_values_direct(A,nptx,3,'bndry');
% title('Location of the Ritz values, k = 3, direct method')

