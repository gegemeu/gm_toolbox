function gm_Ex_Bujanovic_b(nptx,npty);
%GM_EX_BUJANOVIC_B location of Arnoldi Ritz values for complex normal matrices

% Example of a 6 x 6 matrix, two Riz values, one fixed
% We look at the possible locations of the other Ritz value

% See: Z. Bujanovic, On the permissible arrangements of Ritz values for normal matrices in the complex plane
%                    Linear Algebra Appl., v 438 (2013), pp. 4606-4624

%
% Author G. Meurant
% November 2012
% Updated Sept 2015
%

% eigenvalues of the matrix
lambda = [-5 -3+2*1i -3-2*1i 4+1i 4-1i 6];
A= diag(lambda);

% fixed Ritz value
theta1 = -4;

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

% discretization of the box
x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

for ii = 1:length(x)
 for jj = 1:length(y)
  % second Ritz value
  theta2 = x(ii) + y(jj) * 1i;
  
  % build the matrix CR and the rhs
  [CC,CR,rhsC,rhsR] = gm_C_matrix_gen(A,[theta1,theta2]);
  % SVD of CR
  [U,S,V] = svd(CR);
  V1 = V(:,1:5);
  V2 = V(:,6);
  
  % partial solution
  yy = S(:,1:5) \ (U' * rhsR);
  
  % check the feasibility of having a positive solution
  [flag,z] = gm_check_ineq(-V2,V1*yy);
  
  if flag == 1
   % there exists a starting vector for this point
   plot(x(ii),y(jj),'b+')
  end % i flag
 end % for jj
end % for ii

% for this example add some points on the x-axis

% x = linspace(xmin,xmax,50);
% for ii = 1:length(x)
%  % second Ritz value
%  theta2 = x(ii);
%  % build the matrix CR and the rhs
%  [CC,CR,rhsC,rhsR] = gm_C_matrix_gen(A,[theta1,theta2]);
%  % SVD of CR
%  [U,S,V] = svd(CR);
%  V1 = V(:,1:5);
%  V2 = V(:,6);
%  % partial solution
%  yy = S(:,1:5) \ (U' * rhsR);
%  % check the feasibility of having a positive solution
%   [flag,z] = gm_check_ineq(-V2,V1*yy);
%  if flag == 1
%   plot(x(ii),0,'b+')
%  end
% end % for ii

plot(real(theta1),imag(theta1),'kd')

hold off






