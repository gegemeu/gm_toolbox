
% EXAMPLES WITH NONSYMMETRIC MATRICES
%
% Files
%   gm_Ex_Arnoldi     - Example of Arnoldi iteration, SUPG matrix n = 225
%   gm_Ex_Arnoldi_b   - Example of Arnoldi iteration, SUPG matrix n = 1600
%   gm_Ex_Arnoldi_c   - Example of Arnoldi iteration, SUPG matrices
%   gm_Ex_Bujanovic_a - location of Arnoldi Ritz values for complex normal matrices
%   gm_Ex_Bujanovic_b - location of Arnoldi Ritz values for complex normal matrices
%   gm_Ex_Bujanovic_c - location of Arnoldi Ritz values for complex normal matrices
%   gm_Ex_Bujanovic_d - location of Arnoldi Ritz values for complex normal matrices
%   gm_Ex_n6_k2       - Example of a 6 x 6 normal matrix, Arnoldi second iteration
%   gm_Ex_n6b_k2      - Example of a 6 x 6 normal matrix, Arnoldi second iteration
%   gm_Ex_n6c_k2      - Example of a 6 x 6 normal matrix, Arnoldi second iteration
%   gm_Ex_n8_k2       - Example of a 8 x 8 matrix, Arnoldi second iteration
%   gm_Ex_n_k2        - Example of a n x n normal matrix, Arnoldi second (and 3rd) iteration
