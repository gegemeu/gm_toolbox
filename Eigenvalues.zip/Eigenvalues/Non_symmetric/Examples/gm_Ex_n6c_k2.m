function gm_Ex_n6c_k2(nptx,npty);
%GM_EX_N6C_K2 Example of a 6 x 6 normal matrix, Arnoldi second iteration

% location of the complex Ritz values and boundary

% 
% Author G. Meurant
% Sept 2015
%

lambda = [-5 -3+2*1i -3-2*1i 4+1i 4-1i 6];
A = gm_gen_Anormal_real_lambda(lambda);

gm_loc_Ritz_values_real_k2(A,nptx,npty,'bndry');
title('Location of the Ritz values, k = 2')

figure

gm_random_Ritzval_k(A,700,2,'bndry');
title('Location of the Ritz values, k = 2, random starting vectors')

gm_loc_Ritz_values_direct(A,nptx,2,'bndry');
title('Location of the Ritz values, k = 2, direct method')

% gm_loc_Ritz_values_direct(A,nptx,3,'bndry');
% title('Location of the Ritz values, k = 3, direct method')