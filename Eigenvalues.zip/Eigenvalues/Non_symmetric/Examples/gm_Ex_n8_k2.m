function gm_Ex_n8_k2(nptx,npty);
%GM_EX_N8_K2 Example of a 8 x 8 matrix, Arnoldi second iteration

% location of the complex Ritz values and boundary

% 
% Author G. Meurant
% Sept 2015
%

A = gm_gen_Anormal_real(8);

gm_loc_Ritz_values_real_k2(A,nptx,npty,'bndry');
title('Location of the Ritz values, k = 2')

figure

gm_random_Ritzval_k(A,700,2,'bndry');
title('Location of the Ritz values, k = 2, random starting vectors')

