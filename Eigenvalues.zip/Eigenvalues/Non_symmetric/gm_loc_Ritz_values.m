function thet=gm_loc_Ritz_values(A,thetaf,nptx,npty);
%GM_LOC_RITZ_VALUES location of one Ritz value when all the other ones are fixed for the Arnoldi iteration

% This is done by discretization of the FOV and thus not completely reliable

% Input:
% A = normal matrix
% thetaf = fixed Ritz values
% nptx, npty = number of the discretizations points in the x and y
%              directions
%
% Output:
% thet = feasible last Ritz values

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

warning off

thet = [];

lambda = transpose(eig(A));
DL = diag(lambda);

n = size(A,1);
k = length(thetaf);
if k > n-2
 error('gm_loc_Ritz_values: There are too many Ritz values, max: n-2')
end

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

for ii = 1:length(x)
 for jj = 1:length(y)
  % last Ritz value
  theta = [thetaf, x(ii) + y(jj) * i];
  
  % check feasibility
  [flag,v] = gm_find_v_gen(DL,theta);
  
  if flag == 1
   thet = [thet, x(ii) + y(jj) * i];
   plot(x(ii),y(jj),'b+')
  end % if flag
  
 end % for jj
end % for ii


plot(real(thetaf),imag(thetaf),'bd')

hold off

warning on



