function [V,H,VHs,Rvals,Rvec,res,time_mat]=gm_Arnoldi(A,u,nitmax,reorths,prints);
%GM_ARNOLDI Arnoldi iteration for a matrix A, modified Gram-Schmidt

%
% Input:
% A =  matrix
% u = starting vector
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% reorths = 'reorth' double reorthogonalization
%         = 'sorth' selective reorthogonalization
%         = anything else, no reorthogonalization
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V = Arnoldi vectors
% H = upper Hessenberg matrix
% VHs = eigenvectors of H
% Rvals = eigenvalues of H (Ritz values)
% Rvec = Ritz vectors
% res = final residual norms || (A-theta I)x ||, theta = Ritz value
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products
%  otherwise same without the first two items

%
% Author G. Meurant
% July 2015
%

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if strcmpi(reorths,'reorth') == 1
 reorth = 1;
else
 reorth = 0;
end

if strcmpi(reorths,'sorth') == 1
 sorth = 1;
else
 sorth = 0;
end

if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 iprint = 0;
 tic
end

u = u / norm(u);
v = u;

dotprod = 1;
matvec = 0;
nreo = 0;
H = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
V(:,1) = v;
lorth = 0.8;

if timing == 1
 tinit = toc;
 if iprint == 1
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 1:nitmax
 % matrix vector product
 w = A * V(:,k);
 matvec = matvec + 1;
 
 if sorth == 1
  % for selective reorthogonalization
  gin = norm(w);
  dotprod = dotprod + 1;
 end % if sorth
 
 % construction of the basis vectors (modified Gram-Schmidt)
 % and entries of H (into the last column of H)
 for l = 1:k
  gl = V(:,l)' * w;
  H(l,k) = gl;
  w = w - gl * V(:,l);
 end % for l
 dotprod = dotprod + k;
 dk = w;
 
 % reorthogonalization (twice is enough)
 if reorth == 1
  nreo = nreo + 1;
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  dk = w;
 end % if reorth
 
 % selective reorthogonalization
 if (sorth == 1) && (norm(w) < lorth * gin)
  nreo = nreo + 1;
  % reorthogonalization
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  % twice
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  dk = w;
 end % if selective reorth
 
 % normalization of the new vector
 gk = norm(dk);
 dotprod = dotprod + 1;
 dk1 = dk / gk;
 H(k+1,k) = gk;
 % next basis vector
 V(:,k+1) = dk1;
 
end % for k

% eigenvalues and eigenvectors of H

[vh,dh] = eig(full(H(1:nitmax,1:nitmax)));

% Eigenvalues
Rvals = diag(dh);

% Eigenvectors
VHs = vh;

% approximations of eigenvectors
Rvec = V(:,1:nitmax) * VHs;

H = H(1:nitmax,1:nitmax);
V = V(:,1:nitmax);

if timing == 1
 titer = toc;
 if iprint == 1
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end % if timing

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nitmax)
 fprintf(' Number of reorthogonalizations = %d \n',nreo)
end % if iprint

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end % for k

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end % if iprint


