function [XXX,YYY]=gm_find_roots_n4(a1,b1,c1,d1,e1,f1,alp,bet,gam,del,zet,fig);
%GM_FIND_ROOTS_N4 computes points on the projection of the intersection of two hyperboloids
% get the contours of the projection on the (x,y) plane

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

xmin = 0;
xmax = 1; 
ymin = 0;
ymax = 1;
npts = 250;

XX = [];
YY = [];

X = linspace(xmin,xmax,npts);
Y = linspace(ymin,ymax,npts);
[X,Y] = meshgrid(X,Y);

% compute points on the projection of the intersection

u = func_theta2_n4z(X,Y,a1,b1,c1,d1,e1,f1,alp,bet,gam,del,zet);

% Determine u scale so that "most" of the u values
% are in range, but singularities are off scale.

u = real(u);
uu = sort(u(isfinite(u)));
N = length(uu);
if N > 16
   dell = uu(fix(15*N/16)) - uu(fix(N/16));
   umin = max(uu(1)-dell/16,uu(fix(N/16))-dell);
   umax = min(uu(N)+dell/16,uu(fix(15*N/16))+dell);
elseif N > 0
   umin = uu(1);
   umax = uu(N);
else
   umin = 0;
   umax = 0;
end % if N
if umin == umax
 umin = umin-1;
 umax = umax+1;
end % if umin

% Eliminate vertical lines at discontinuities.

ud = (0.5)*(umax - umin);
umean = (umax + umin)/2;
[nr,nc] = size(u);
% First, search along the rows . . .
for j = 1:nr
   k = 2:nc;
   kc = find( abs(u(j,k) - u(j,k-1)) > ud );
   ki = find( max( abs(u(j,k(kc)) - umean), abs(u(j,k(kc)-1) - umean) ) );
   if any(ki)
    u(j,k(kc(ki))) = NaN;
   end % if any
end % for j
%  then search along the columns.
for j = 1:nc
   k = 2:nr;
   kr = find( abs(u(k,j) - u(k-1,j)) > ud );
   kj = find( max( abs(u(k(kr),j) - umean), abs(u(k(kr)-1,j) - umean) ) );
   if any(kj)
    u(k(kr(kj)),j) = NaN;
   end % if any
end % for j

if fig == 1

 figure

 cax = gca;
 [c,hp] = contour(cax,X(1,:),Y(:,1),u,[0,0],'-');

 limit = size(c,2);
 i = 1;
 h = [];
 color_h = [];

 while(i < limit)

  z_level = c(1,i);
  npoints = c(2,i);
  nexti = i+npoints+1;

  XX = [XX c(1,i+1:i+npoints)];
  YY = [YY c(2,i+1:i+npoints)];

  i = nexti;

 end % while

end % if fig

X = linspace(xmin,xmax,150);
XXX = [];
YYY = [];

for j = 1:length(X)

 yy = func_theta2_sol(X(j),a1,b1,c1,d1,e1,f1,alp,bet,gam,del,zet);
 for jj = 1:length(yy)
  if (yy(jj) > 0) && (yy(jj) < 1)
   XXX = [XXX X(j)];
   YYY = [YYY yy(jj)];
  end % if yy
 end % for jj

end % for j

if fig == 1

 hold on

 plot(XXX,YYY,'g*')

 hold off

end % if fig


end % function

function val=func_theta2_n4z(x,y,a1,b1,c1,d1,e1,f1,alp,bet,gam,del,zet);
% projection on the (x,y) plane by elimination of z

zN = -(alp * x.^2 + bet * x .* y + gam * y.^2 - alp * x - gam * y);
zD = del * x + zet * y;

val = (a1 * x.^2 + b1 * x .* y + c1 * y.^2 - a1 * x - c1 * y) .* zD.^2 + d1 * zN.^2 ...
 + (e1 * x + f1 * y - d1) .* zN .* zD;

end

function sol=func_theta2_sol(x,a,b,c,d,e,f,alp,bet,gam,del,zet);
% y function of x  to compute
% explicitly the values of y for a given x

% coefficient of y^4

c4 = c * zet^2 + d * gam^2 - f * gam * zet;

% coefficient of y^3 (in 3 pieces)

c31 = (b * x - c) * zet^2 + 2 * c * del * zet * x;
c32 = 2 * d * gam * ( bet * x - gam);
c33 = e * gam * zet * x + f * (bet * zet + gam * del) * x ...
 - gam * zet * (f + d);
c3 = c31 + c32 - c33;

% coefficient of y^2

c21 = a * zet^2 * x^2 + 2 * b * del * zet * x^2 + c * del^2 * x^2 ...
  - a * zet^2 * x - 2 * c * del * zet * x;
% c21 = x^2 * (zet * (a * zet + 2 * b * del) + c * del^2) ...
%   - zet * x * (a * zet + 2 * c * del);
 
c22 = d * (2 * alp * gam * x^2 + bet^2 * x^2 - 2 * bet * gam * x - 2 * alp * gam * x + gam^2);
% c22 = d * (x^2 * (2 * alp * gam + bet^2) - 2 * gam * x * (bet + alp) + gam^2);

c23 = e * bet * zet * x^2 + e * gam * del * x^2 - e * gam * zet * x + f * alp * zet * x^2 ...
 + f * bet * del * x^2  - f * alp * zet * x - f * gam * del * x - d * bet * zet * x ...
 - d * gam * del * x + d * gam * zet;
% c23 = x^2 * (e * (bet * zet + gam * del) + f * (alp * zet + bet * del)) ...
%   + x * (- e * gam * zet - f * (alp * zet + gam * del) - d * (bet * zet + gam * del)) ...
%   + d * gam * zet;

c2 = c21 + c22 - c23;

% coefficient of y

c11 = 2 * a * del * zet * x^3 + b * del^2 * x^3 - 2 * a * del * zet * x^2 - c * del^2 * x^2;
% c11 = x^2 * del * (x * (2 * alp * zet + b * del) - (2 * a * zet + c * del));
% c11 = x^2 * del * (2 * zet * (alp * x - a) + del * (b * x -c));

c12 = d * (2 * alp * bet * x^3 - 2 * alp * gam * x^2 - 2 * alp * bet * x^2 + 2 * alp * gam * x);
% c12 = d * 2 * alp * x * (bet * x^2 - gam * x - bet * x +  gam);

c13 = e * alp * zet * x^3 +  e * bet * del * x^3 - e * alp * zet * x^2 - e * gam * del * x^2 ...
 + f * alp * del * x^3 - f * alp * del * x^2 - d * alp * zet * x^2 - d * bet * del * x^2 ...
 + d * alp * zet * x + d * gam * del * x;
% c13 = x^3 * (e * alp * zet +  e * bet * del + f * alp * del) + x^2 * (- e * (alp * zet + gam * del) ...
%   - f * alp * del - d * (alp * zet + bet * del)) ...
%  + d * x * (alp * zet + gam * del);

c1 = c11 + c12 - c13;

% constant coefficient

c01 = a * del^2 * x^4 - a * del^2 * x^3;
% c01 = a * del^2 * x^3 * (x - 1);

c02 = d * (alp^2 * x^4 - 2 * alp^2 * x^3 + alp^2 * x^2);
% c02 = d * alp^2 * x^2 * (x^2 - 2 * x + 1);

c03 = e * alp * del * x^4 - e * alp * del * x^3 - d * alp * del * x^3 + d * alp * del * x^2;
% c03 = alp * del * x^2 * (e * x^2 - x * (e + d) + d );

c0 = c01 + c02 - c03;

% compute the roots for y

cc = [c4; c3; c2; c1; c0];

yy = roots(cc);

yy = yy(find(abs(imag(yy))<1e-14));

% check if the real roots are such that 0 <= y <= 1

sol = zeros(4,1);
val = [];
jj = 1;
for j = 1:length(yy)
 if (yy(j) >= 0) & (yy(j) <= 1)
  sol(jj) = yy(j);
  val(jj) = func_theta2_n4z(x,yy(j),a,b,c,d,e,f,alp,bet,gam,del,zet);
  jj = jj + 1;
 end % if yy
end % for j

end




