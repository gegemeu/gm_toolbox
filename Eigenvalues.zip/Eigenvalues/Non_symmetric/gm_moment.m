function [M,X,D] = gm_moment(A,v);
%GM_MOMENT moment matrix for A normal

% Input:
% A = real normal matrix
% v = starting vector
%
% Output:
% M = moment matrix
% X = eigenvectors
% D = diagonal matrix of eigenvalues

%
% Author G. Meurant
% October 2013
% Updated September 2015
%

A = full(A);

[X,D] = eig(A);

v = v / norm(v);
c = X' * v;
om = abs(c).^2;

M = gm_momat(om,diag(D));

