function [lambda,g]=gm_A_valvec(H);
%GM_A_VALVEC computes the eigenvalues and eigenvectors

% sorts the eigenvalues by modulus

%
% Input:
% H = upper Hessenberg matrix n x n
%
% Output:
% lambda = Ritz values of the matrix H
% g = eigenvectors

%
% Author G. Meurant
% August 2016
%

n = size(H,1);
k = n;

Hk = H(1:k,1:k);
[X,D] = eig(full(Hk));
lam = diag(D);
[lamb,I] = sort(abs(lam));
lambda = lam(I);
g = X(:,I);





  