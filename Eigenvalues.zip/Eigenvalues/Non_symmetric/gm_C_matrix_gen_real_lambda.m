function [CR,rhsR,p]=gm_C_matrix_gen_real_lambda(lambda,theta);
%GM_C_MATRIX_GEN_REAL_LAMBDA builds the matrix and rhs for omega for k Ritz values

% A must be a real normal matrix

% Input:
% lambda = eigenvalues of A
% theta = the k Ritz values
%
% Output:
% CR = the real (rectangular) matrix (k+1)x(nb of pairs + nb of real
%      eigenvalues)
% rhsR = right-hand side
% p = number of pairs of complex conjugate eigenvalues

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

CR= [];
rhsR = [];

n = length(lambda);

if size(lambda) > 1
 lambda = transpose(lambda);
end

% put the complex conjugate eigenvalues first
% we assume that the eigenvalues in the pair are consecutive
IR = find(imag(lambda) == 0);
II = find(imag(lambda) ~= 0);
lambda = [lambda(II) lambda(IR)];
% number of pairs
p = length(II) / 2;
% number of real eigenvalues
pR = n - 2 * p;

k = length(theta);

CR = zeros(k+1,n-p);
rhsR = zeros(k+1,1);

% get the coefficients of the characteristic polynomial
% from the given Ritz values
% bet contains beta_0, beta_1,...,beta_{k-1}

bet = poly(theta);
bet = bet(k+1:-1:2);

% first row

CR(1,1:p) = 2 * ones(1,p);
CR(1,p+1:n-p) = ones(1,pR);

% second row

ind = [1:k-1];
for m = 1:p
 CR(2,m) = 2 * sum(bet(2:k) .* real(lambda(2*m-1).^ind)) + 2 * real(lambda(2*m-1)^k);
end % for m
for m = p+1:n-p
 CR(2,m) = sum(bet(2:k) .* lambda(p+m).^ind) + lambda(p+m)^k;
end % for m

% all other rows

for l = 3:k+1
 for m = 1:p
  CR(l,m) = 2 * (bet(1) * real(conj(lambda(2*m-1))^(l-2)) + sum(bet(2:k) .* real(conj(lambda(2*m-1))^(l-2) ...
   * lambda(2*m-1).^ind)) +  real(conj(lambda(2*m-1))^(l-2) * lambda(2*m-1)^k));
 end % for m
 for m = p+1:n-p
  CR(l,m) = lambda(p+m)^(l-2) * (bet(1) + sum(bet(2:k) .* lambda(p+m).^ind) + lambda(p+m)^k);
 end % for m
end % for l

% right hand side

rhsR(1) = 1;
rhsR(2) = -bet(1);






