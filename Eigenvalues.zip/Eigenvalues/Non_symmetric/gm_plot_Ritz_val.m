function gm_plot_Ritz_val(A,v,nitmax);
%GM_PLOT_RITZ_VAL plot of the eigenvalues and Arnoldi Ritz values at each iteration

% Input:
% A = matrix
% v = starting vector
% nitmax = maximum number of iterations

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(A,1);

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,nitmax,'noreorth','noprint');

H = full(H);

figure

% field of values
gm_fvmod(A,1,32,0);
hold on

for k = 1:nitmax
 muu = eig(H(1:k,1:k));
 switch mod(k,6)
  case 1
   color = 'bd';
  case 2
   color = 'rd';
  case 3
   color = 'gd';
  case 4
   color = 'md';
  case 5
   color = 'cd';
  otherwise
   color = 'kd';
 end % switch
 plot(real(muu),imag(muu),color)
 title(['Iteration ' num2str(k)])
 pause
end % for k

hold off

