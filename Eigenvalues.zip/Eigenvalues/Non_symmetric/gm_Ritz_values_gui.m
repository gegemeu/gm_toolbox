function gm_Ritz_values_gui(A,nptx,npty)
%GM_RITZ_VALUES_GUI location of the second Ritz value with the first one fixed

% Caution: If the matrix is real we forget about the given Ritz value and we show 
% all the possible locations of Ritz values for the second Arnoldi
% iteration

% Input:
% A = normal matrix
% nptx, npty = number of discretization points in x, y directions

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

realA = 0;
if isreal(A)
 realA = 1;
end

n = size(A,1);

% we just need the eigenvalues of A

if n == 3
 [AA,lambda,X] = gm_put_imag_first(A);
else
 lambda = transpose(eig(full(A)));
end

DL = diag(lambda);
n = length(lambda);
if isreal(DL)
 fprintf('\n gm_Ritz_values_gui: All the eigenvalues of A are real, stop \n\n')
 return
end

% fixed Ritz default value
theta1 = 0;
% this can be redefined through the GUI

fig = figure( ...
 'Name', 'Ritz values location', ...
 'NumberTitle', 'off');

% axes for drawing
ax = axes('Parent', fig, ...
 'Units', 'normalized', ...
 'OuterPosition', [0.2 0 0.8 1], ...
 'DrawMode','fast', ...
 'XLimMode', 'manual', ...
 'YLimMode', 'manual', ...
 'ZLimMode', 'manual');

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(DL,1,32,1);
hold on

plot(real(theta1),imag(theta1),'bd')

x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

fRitz = uicontrol('Style','pushButton','String','1st Ritz val.',...
 'Position',[50,150,70,25],...
 'Callback',@fRitz_callback);
Compute = uicontrol('Style','pushButton','String','2nd Ritz val.',...
 'Position',[50,100,70,25],...
 'Callback',@Compute_callback);
Stop = uicontrol('Style','pushButton','String','Exit',...
 'Position',[50,50,70,25],...
 'Callback',@Stop_callback);

tetR = uicontrol('Style','edit','String',num2str(real(theta1)),...
 'Position',[50,300,70,25],...
 'Callback',@edittextR_callback);
textR = uicontrol('Style','text','String','R',...
 'Position',[30,300,10,25]);
tetI = uicontrol('Style','edit','String',num2str(imag(theta1)),...
 'Position',[50,250,70,25],...
 'Callback',@edittextI_callback);
textI = uicontrol('Style','text','String','I',...
 'Position',[30,250,10,25]);
status = uicontrol('Style','edit','String','Waiting',...
 'Position',[50,200,70,25]);

 function fRitz_callback(hObject,eventdata)
  
  hold off
  
  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on
  
  % value of the fixed Ritz value
  
  [x1,y1,button] = ginput(1);
  
  theta1 = x1 + 1i * y1;
  
  plot(real(theta1),imag(theta1),'bd')
  
  set(tetR,'String',num2str(real(theta1)));
  set(tetI,'String',num2str(imag(theta1)));
  
 end

 function Compute_callback(hObject,eventdata)
  
  % compute and plot the locations of the second Ritz value
  
  set(status,'String','Busy');
  drawnow
  
  if realA == 0
   % complex matrices
   
   switch n
    
    case {1,2}
     error('gm_Ritz_values_gui: The order of A must be > 2')
     
    case 3
     [rootn3,c] = gm_roots_theta2_n3(lambda,theta1);
     % plot the field of values and get the box
     [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
     hold on
     plot(real(rootn3),imag(rootn3),'b+')
     hold off
     
    case 4
     [rootn4,c] = gm_roots_theta2_n4(lambda,theta1);
     % plot the field of values and get the box
     [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
     hold on
     plot(real(rootn4),imag(rootn4),'b+')
     hold off
     
    otherwise
     tet = gm_loc_Ritz_values(DL,theta1,nptx,npty);
     hold on
     gm_plot_boundary_complex_k2b(A,theta1);
     hold off
     
   end % switch
   
   hold on
   plot(real(theta1),imag(theta1),'bd')
   hold off
   
  else
   % real matrices
   hold off
   [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
   hold on
   
   switch n
    
    case {1,2}
     error('gm_Ritz_values_gui: The order of A must be > 2')
     
    case 3
     if isreal(theta1)
      [rootn3,c] = gm_roots_theta2_n3(A,theta1);
      % there is only one solution
      plot(real(rootn3),imag(rootn3),'b+')
     else
      plot(real(theta1),-imag(theta1),'b+')
      % plot the location of the complex conjugate pairs
%       gm_myezplot_simpler(@(x,y)func_theta_n3(x,y,lambda(1),lambda(3)))
      title('          ')
      xlabel('   ')
      ylabel('   ')
     end % if isreal
     
    otherwise
     gm_loc_Ritz_values_real_wf(A,nptx,npty);
     hold on
     gm_plot_boundary_real_k2b(A);
     hold on
     
   end % switch
   
%    if realA ~= 0
%     plot(real(theta1),imag(theta1),'bd')
%    end
   
   hold off
   
  end % if real
  
  hold on
  
  set(tetR,'String',num2str(real(theta1)));
  set(tetI,'String',num2str(imag(theta1)));
  
  set(status,'String','Waiting');
  drawnow
  
  hold off
  
 end

 function edittextR_callback(hObject,eventdata)
  
  tetaR = get(hObject,'String');
  tetaR = str2double(tetaR);
  set(tetR,'String',num2str(tetaR));
  
  old_theta = theta1;
  theta1 = tetaR + 1i * imag(old_theta);
  
  hold off
  
  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on
  
  plot(real(theta1),imag(theta1),'bd')
  
 end

 function edittextI_callback(hObject,eventdata)
  
  tetaI = get(hObject,'String');
  tetaI = str2double(tetaI);
  set(tetI,'String',num2str(tetaI));
  
  old_theta = theta1;
  theta1 = real(old_theta) + 1i * tetaI;
  
  hold off
  
  % plot the field of values and get the box
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on
  
  plot(real(theta1),imag(theta1),'bd')
  
 end

 function Stop_callback(hObject,eventdata)
  
  % delete all figures
  set(0,'ShowHiddenHandles','on')
  delete(get(0,'Children'))
  return
 end

end

function val=func_theta_n3(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values

r1 = real(lamb1);

D1 = - 4 * x * r1 + 4 * x * lamb3 + 2 * real(lamb1^2) - 2 * lamb3^2;
N1 = 2 * x * lamb3 - lamb3^2 - x.^2 - y.^2;

D2 = 4 * x * abs(lamb1)^2 - 4 * x * lamb3^2 - 2 * abs(lamb1)^2 * r1 + 2 * lamb3^3 ...
 - 2 * (x.^2 + y.^2) * r1 + 2 * (x.^2 + y.^2) * lamb3;
N2 = - 2 * x * lamb3^2 + lamb3^3 + (x.^2 + y.^2) * lamb3;

val = N1 .* D2 - N2 .* D1;

end

