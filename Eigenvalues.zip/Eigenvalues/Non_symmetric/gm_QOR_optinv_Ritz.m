function [V,H,VHs,Rvals,Rvec,res,time_mat] = gm_QOR_optinv_Ritz(A,u,nitmax,prints);
%GM_QOR_OPTINV_RITZ basis vectors and Ritz values from the Q-OR optimal iteration

% uses the inverses of the Cholesky factors of V_k^T V_k

%
% Input:
% A =  matrix
% u = starting vector
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V = basis vectors
% H = upper Hessenberg matrix
% VHs = eigenvectors of H
% Rvals = eigenvalues of H
% Rvec = Ritz vectors
% res = residual norms || (A-theta I)x ||, theta = Ritz values
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products
%  otherwise same without the first two items

%
% Author G. Meurant
% May 2016
%

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 tic
end

u = u / norm(u);
v = u;

dotprod = 1;
matvec = 0;
H = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
V(:,1) = v;
Av = A * v;

% array L is the inverse of the matrix L
L = zeros(nitmax+1,nitmax+1);
nuu = zeros(1,nitmax);

L(1,1) = 1;
nuu(1) = 1;

if timing == 1
 tinit = toc;
 if iprint == 1
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 1:nitmax
 
 % construction of the basis vectors
 % and entries of H (in the last column of H)
 
 if k == 1
  % choose the optimal value for the first column of H
  v = V(:,1);
  vAv = v' * Av;
  vAAv = Av' * Av;
  dotprod = dotprod + 2;
  if abs(vAv) <= 1-14
   % breakdown
   fprintf('\n gm_QORm_optinv_Ritz: Initialization breakdown, v^T A v = %g \n',vAv)
   H(1,1) = 0;
  else
   H(1,1) = vAAv / vAv;
  end % if abs
  vt = Av - H(1,1) * V(:,1);
  H(2,1) = norm(vt);
  dotprod = dotprod + 1;
  V(:,2) = vt / H(2,1);
  nuu(2) = - nuu(1) * H(1,1) / H(2,1);
  
  % matrix vector product
  Av = A * V(:,2);
  matvec = matvec + 1;
  
 else % k ~= 1
  
  AvAv = Av' * Av;
  dotprod = dotprod + 1;
  
  % 2 independant dense matrix - vector products
  vkv = V(:,1:k-1)' * V(:,k);
  vktA = V(:,1:k)' * Av;
  dotprod = dotprod + 2 * k - 1;
  
  % inverse of L_k
  lk = L(1:k-1,1:k-1) * vkv;
  ykt = lk' * L(1:k-1,1:k-1);
  lkt = lk' * lk;
  if lkt >=1
   pknu = V(:,1:k-1) * ykt';
   lkk = norm(V(:,k) - pknu);
   dotprod = dotprod + 1;
  else
   lkk = sqrt(1 - lkt);
  end % if lkt
  % what to do if lkk is small?
  if lkk < 1e-10
   fprintf('\n gm_QOR_optinv_Ritz: The diagonal entry of L is small = %g at iteration %d \n',lkk,k)
   bkd = 1;
  end % if lkk
  L(k,1:k) = [-ykt / lkk, 1 / lkk];
  
  lA = L(1:k,1:k) * vktA;
  s = L(1:k,1:k)' * lA;
  
  alp = AvAv - lA' * lA;
  
  % new column of H
  if abs(vktA(k)) <= 0
   fprintf('\n gm_QOR_optinv_Ritz: Breakdown iteration %d, value = %g \n',ni,vktA(k))
   return
  else
   beta = alp / vktA(k);
   H(1:k,k) = s;
   H(k,k) = H(k,k) + beta;
  end % if abs
  
  gswitch = 0;
  % recovery for some near breakdowns
  if gswitch == 1
   % this threshold may be too large (1e-6)
   if abs(vktA(k)) < 1e-6 || bkd == 1
    if iprint == 1
     fprintf('\n gm_QOR_optinv_Ritz: Small vktA = %g at iteration %d \n',vktA(k),k)
    end
    % perturb nu to avoid the breakdown
    lnu = L(1:k,1:k) * (1 - rand(k,1)) .* nuu(1:k)';
    om = lA' * lnu;
    dotprodk = dotprodk + 1;
    H(1:k,k) = L(1:k,1:k)' * (lA + (alp / om) * lnu);
    %      H(1:k,k) = s;
    matveck = matveck + 2;
    bkd = 0;
   end % if abs
  end % if gswitch
  
  % new basis vector
  vt = Av - V(:,1:k) * H(1:k,k);
  h = norm(vt);
  dotprod = dotprod + 1;
  % the inverse of nu gives the norm of the residual
  nuu(k+1) = -nuu(1:k) * H(1:k,k) / h;
  
  if isinf(nuu(k+1))
   fprintf('\n gm_QOR_optinv_Ritz: Infinite nu at iteration %d, preceding nu = %12.5e \n',k,nuu(k))
   nitmax = k;
   break
  end % if isinf
  
  % subdiagonal entry of H
  H(k+1,k) = h;
  
  if k < nitmax
   % new basis vector
   V(:,k+1) = vt / h;   
   % matrix-vector product (n x n)
   Av = A * V(:,k+1);
   matvec = matvec + 1;
   
  end % if k < nitmax
 end % if k == 1
 
end % for k

% eigenvalues and eigenvectors of H

[vh,dh] = eig(full(H(1:nitmax,1:nitmax)));

% eigenvalues
Rvals = diag(dh);

% eigenvectors
VHs = vh;

% approx of eigenvectors
Rvec = V(:,1:nitmax) * VHs;

H = H(1:nitmax,1:nitmax);
V = V(:,1:nitmax);

if timing == 1
 titer = toc;
 if iprint == 1
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end % if timing

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nitmax)
end % if iprint

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end % for k

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end % if iprint


