function [lambda,X] = gm_Ritz_valvec(H);
%GM_RITZ_VALVEC computes the Ritz values and vectors of the Hessenberg matrix H 

% Input:
% H = upper Hessenberg matrix n x (n-1)
%
% Output:
% lambda = Ritz values of the matrix H
% X = eigenvectors

%
% Author G. Meurant
% August 2016
%

n = size(H,2);
k = n;

Hk = H(1:k,1:k);
[Z,D] = eig(full(Hk));
lam = diag(D);
[lamb,I] = sort(abs(lam));
lambda = lam(I);
X = Z(:,I);





  