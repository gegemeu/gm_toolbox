function gm_random_Ritzval_harminv_k(A,nsamp,k);
%GM_RANDOM_RITZVAL_HARMINV_K inverses of harmonic Ritz values at Arnoldi iteration k for random rhs

% Arnoldi started from a random real vector

% plot of the inverses of the eigenvalues

% Input:
% A = matrix
% nsamp = number of random rhs
% k = iteration number
% bnd = 'bndry' with the boundary of the Ritz values of inv(A)

%
% Author G. Meurant
% October 2013
% Updated September 2015
%

n = size(A,1);

if k > n
 error('gm_random_Ritzval_harminv_k: We must have k<n')
end

iA = inv(A);

figure

% field of values of the inverse
gm_fvmod(iA,1,32,0);
hold on

for kk = 1:nsamp
 v = randn(n,1);
 v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,k+1,'noreorth','noprint');
 
 Hk = H(1:k,1:k);
 bet = H(k+1,k);
 eii = zeros(k,1); eii(k) = 1;
 y = (Hk') \ eii;
 Hk(:,k) = Hk(:,k) + bet^2 * y;
 
 eigHk = eig(full(Hk));
 
 for j = 1:k
  if isreal(eigHk(j))
   plot(1/eigHk(j),0,'g+')
  else
   if imag(eigHk(j)) > 0
    plot(real(1/eigHk(j)),imag(1/eigHk(j)),'b+')
   else
    plot(real(1/eigHk(j)),imag(1/eigHk(j)),'r+')
   end % if imag
  end % if isreal
 end % for j
 
end % for kk

hold off


