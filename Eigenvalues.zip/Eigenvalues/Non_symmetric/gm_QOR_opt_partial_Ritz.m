function [V,H,VHs,Rvals,Rvec,res,time_mat] = gm_QOR_opt_partial_Ritz(A,u,pp,qq,nitmax,prints);
%GM_QOR_OPT_PARTIAL_RITZ vector basis and Ritz values from the Q-OR optimal truncated iteration

% The Ritz values may not be accurate, use gm_QOR_optinv_Ritz

%
% Input:
% A =  matrix
% u = starting vector
% pp, qq = numbers of vectors for the construction of the basis
%  pp corresponds to vectors Av_j and qq to vectors v_j
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V = basis vectors
% H = upper Hessenberg matrix
% VHs = eigenvectors of H
% Rvals = eigenvalues of H
% Rvec = Ritz vectors
% res = residual norms || (A-theta I)x ||, theta =  Ritz values
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products
%  otherwise same without the first two items

%
% Author G. Meurant
% May 2016
%

warning('off')

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 tic
end

u = u / norm(u);
v = u;

dotprod = 1;
matvec = 0;
H = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
AV = zeros(n,nitmax);
V(:,1) = v;

L = zeros(nitmax+1,nitmax+1);
R = eye(nitmax,nitmax);
nuu = zeros(1,nitmax);

L(1,1) = 1;
nuu(1) = 1;

if timing == 1
 tinit = toc;
 if iprint == 1
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 2:nitmax+1
 
 % construction of the basis vectors
 % and entries of H (in the last column of H)
 
 % matrix vector product
 Av = A * v;
 matvec = matvec + 1;
 
 % store the matrix-vector products
 AV(:,k-1) = Av;
 
 % we use vectors in AV and V
 
 % kp is the starting index in AV
 kp = max(1,k-pp);
 % lp is the number of vectors in AV
 lp = min(pp,k-1);
 % kq is the starting index in V
 kq = max(1,k-qq);
 % lq is the number of vectors in V
 lq = min(qq,k-1);
 % we do not need more than k vectors
 while lp + lq > k
  % we reduce the number of vectors
  % we start with V
  if lq > 1
   kq = kq + 1;
   lq = lq - 1;
  elseif lp > 1
   % we reduce the number of vectors in AV
   kp = kp + 1;
   lp = lp - 1;
  else
   % there is no more solution (this must not happen!)
   error(' gm_QORm_opt_partial_Ritz: We cannot reduce the number of vectors any longer')
  end % if lq
 end % while
 
 if k == 2
  vAv = v' * Av;
  alpha = Av' * Av - vAv^2;
  dotprod = dotprod + 2;
  omega = vAv;
  if abs(vAv) <= 1-14
   % breakdown
   fprintf('\n gm_QORm_opt_partial_Ritz: Initialization breakdown, v^T A v = %g \n',vAv)
   % switch to Arnoldi
   [V,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,u,nitmax,'noreorth',prints);
   return
  else
   z = vAv + alpha / omega;
   v = Av - z * v;
   L(1,1) = z;
  end % if abs
  
 else % k ~= 2
  Ck = [AV(:,kp:k-2) V(:,kq:k-1)];
  sk = size(Ck,2);
  rsk = max(sk-lq,0);
  nut = [zeros(rsk,1); nuu(k-lq:k-1)'];
  % matrix-matrix product
  CCk = Ck' * Ck;
  % matrix-vector product
  CAv = Ck' * Av;
  % linear solve
  yy = CCk \ CAv;
  alpha = Av' * Av - CAv' * yy;
  dotprod = dotprod + 1;
  % linear solve
  yyy = CCk \ nut;
  omega = Av' * Ck * yyy;
  
  if abs(omega) <= 1e-14
   fprintf('\n gm_QOR_opt_partial_Ritz: Breakdown iteration %d, value = %g, switch to Arnoldi \n',k,omega)
   % switch to Arnoldi
   [V,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,u,nitmax,'noreorth',prints);
   return
  end % if abs
  
  z = yy + (alpha / omega) * yyy;
  
  gswitch = 0;
  % recovery for some breakdowns
  if gswitch == 1
   % this threshold may be too large (1e-6)
   if abs(omega) < 1e-6
    fprintf('\n gm_QORm_opt_partial_Ritz: Small omega = %g at iteration %d \n',omega,k)
    % perturb nu to avoid the breakdown
    nnut = size(nut,1);
    yyy = CCk \ (1 - rand(nnut,1)) .* nut;
    omega = Av' * Ck * yyy;
    z = yy + (alpha / omega) * yyy;
   end % if abs
  end % if gswitch
  
  % next basis vector
  v = Av - Ck * z;
  
  L(1:k-1,k-1) = [zeros(k-1-lq,1); z(sk-lq+1:end)];
  R(k-2-lp+2:k-2,k-1) = -z(1:lp-1);
  
 end % if k == 2
 
 nk = norm(v);
 dotprod = dotprod + 1;
 v = v / nk;
 V(:,k) = v;
 % subdiagonal entry
 L(k,k-1) = nk;
 nuu(k) = -(nuu(1:k-1) * L(1:k-1,k-1)) / L(k,k-1);
 
end % for k

L = L(1:nitmax,1:nitmax);
H = L / R;

% eigenvalues and eigenvectors of H
[vh,dh] = eig(full(H(1:nitmax,1:nitmax)));

% eigenvalues
Rvals = diag(dh);

% eigenvectors
VHs = vh;

% approx of eigenvectors
Rvec = V(:,1:nitmax) * VHs;

H = H(1:nitmax,1:nitmax);
V = V(:,1:nitmax);

if timing == 1
 titer = toc;
 if iprint == 1
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end % if timing

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nitmax)
end % if iprint

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end % for k

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end % if iprint


warning('on')



