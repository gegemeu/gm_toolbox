function SP=gm_spectral_proj(k,X,XX,lamb);
%GM_SPECTRAL_PROJ spectral projector associated with lamb(k)

% Input:
% k = index of the eigenvalues
% X = eigenvectors of A (real matrix)
% XX = eigenvectors of A'
% lamb = eigenvalues of A
%
% Output:
% SP = spectral projector

%
% Author G. Meurant
% Jan 2015
% Updated Sept 2015
%

lambk = lamb(k);
clambk = conj(lambk);
n = size(X,1);
if k > n || k > length(lamb)
 error('gm_spectral_proj: k is too large')
end
x = X(:,k);

% lambk real
if isreal(lambk)
 y = XX(:,k);
else
 % lambk complex, look for the complex conjugate in the list
 for j = 1:n
  if j ~= k
   dif = abs(clambk - lamb(j));
   if dif <= 1e-15
    y = XX(:,j);
    break
   end % if dif
  end % if j
 end % for j
end % if isreal

ps = y' * x;
if abs(ps) <= 1e-10
 SP = eye(n,n);
else
 SP = (1 / ps) * x * y';
end % if abs



