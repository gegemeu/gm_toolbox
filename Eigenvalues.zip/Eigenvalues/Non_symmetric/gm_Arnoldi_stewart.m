function [Q,H] = gm_Arnoldi_stewart(A,b,s,nitmax);
%GM_ARNOLDI_STEWART Arnoldi factorization using Stewart's block GS

% monomial basis

% Input:
% A = matrix
% b = initial vector
% s = block size
% nitmax = maximum number of iterations
%
% Output:
% Q = orthonormal matrix
% H = upper Hessenberg matrix
%  A Q_k = Q_{k+1} * H_{(k+1) x k}

%
% Author G. Meurant
% August 2019
%

[n,ncol] = size(A);
Q = zeros(n,nitmax+1);
R = zeros(s+1,s+1);
H = zeros(nitmax+1,nitmax);
if s > nitmax
 fprintf('\n The block size is too large \n')
 s = nitmax;
end % if
nb = fix(nitmax / s); % number of blocks
nrem = nitmax - nb * s;
if nrem > 0
 nb = nb + 1;
end % if

% first block
K = gm_Krylovnn(A,b,s+1);
nK = norm(K(:,1));
[Y,R12,R22] = gm_bgssro(K(:,1)/nK,K(:,2:s+1));
Y = [K(:,1)/nK Y];
nr = size(R12,1) + size(R22,1);
Q(:,1:s+1) = Y(:,1:s+1);
R(1,1) = nK;
Rb = [R12; R22];
R(1:nr,2:s+1) = Rb;
H(1:s+1,1:s) = R(1:s+1,2:s+1) / R(1:s,1:s);

% other blocks
for k = 2:nb
 reorth = false;
 cd = (k - 1) * s + 1;
 cf = k * s;
 ss =s;
 if (nrem > 0) && (k == nb)
  cf = nitmax;
  ss = nitmax - s * (k - 1);
 end % if
 nu = zeros(1,ss);
 Bs = zeros(ss+1,ss);
 for j = 2:ss+1
  Bs(j,j-1) = 1;
 end % for j
 sk1 = s * (k - 1);
 sk = sk1 + ss;
 K = gm_Krylovnn(A,Q(:,sk1+1),ss+1);
 Vbp = K(:,2:ss+1);
 for j = 1:ss
  nu(j) = norm(Vbp(:,j));
 end % for j
 Xb = Q(:,1:cd)' * Vbp;
 X = Xb(:,1:ss-1);
 Vbp = Vbp - Q(:,1:cd) * Xb;
 [Qt,R2b] = gm_signqr(Vbp);
 R2 = R2b(1:ss-1,1:ss-1);
 Q(:,cd+1:cf+1) = Qt;
 Zb = [zeros(sk1,1) Xb(1:sk1,:)];
 Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
 XR = -X / R2;
 R2i = inv(R2);
 Z = [zeros(sk1,1) XR(1:sk1,:)];
 W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
 for j = 1:ss
  if R2b(j,j) <= (0.5 * nu(j))
   reorth = true;
%    fprintf('\n reorth needed k = %d, j = %d, R2b = %12.5e, bound = %12.5e \n',k,j,R2b(j,j),(0.5*nu(j)))
  end % if
 end % for j
%  reorth = false;
 if reorth && (ss > 1)
  % reorthogonalization
  ZZb = Q(:,1:cd)' * Qt;
  ZZ = ZZb(:,1:ss-1);
  Qt = Qt - Q(:,1:cd) * ZZb;
  [QQt,R2bh] = gm_signqr(Qt);
  Q(:,cd+1:cf+1) = QQt;
  Xb = ZZb * R2b + Xb;
  X = ZZ * R2 + X;
  R2b = R2bh * R2b;
  R2 = R2b(1:ss-1,1:ss-1);
  Zb = [zeros(sk1,1) Xb(1:sk1,:)];
  Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
  XR = -X / R2;
  R2i = inv(R2);
  Z = [zeros(sk1,1) XR(1:sk1,:)];
  W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
 end % if
 H(1:sk1,sk1+1:sk) = H(1:sk1,1:sk1) * Z + Zb(:,2:ss+1) * W; % true only for monommial basis
 % = H(1:sk1,1:sk1) * Z + Zb(:,2:ss+1) * W
 h0 = H(sk1+1,1:sk1) * Z;
 WW = Wb(:,2:ss+1) * W;
 WW(1,:) = WW(1,:) + h0;
 % bottom part = WW
 H(sk1+1:sk+1,sk1+1:sk) = WW;
end % for k






  
  
  
 
 
