function [z,zmin,z1,z1min]=gm_refined_Ritz_vect(A,H,V,k,theta);
%GM_REFINED_RITZ_VECT computes a refined Ritz vector for theta

% Input:
% A = matrix
% H = upper Hessenberg matrix from Arnoldi
% V = unitary matrix from Arnoldi
% k = iteration number
% theta = Ritz or harmonic Ritz value
%
% Output:
% z = refined Ritz vector using the svd of A
% zmin = corresponding singular value
% z1 = refined Ritz vector from the eigenvectors of H
% z1min = corresponding harmonic Ritz value

%
% Author G. Meurant
% Jan 2015
% Updated Sept 2015
%

% compute from A

Vk = V(:,1:k);
n = size(A,1);
Am = (A - theta * eye(n)) * Vk;
[UU,S,VV] = svd(Am,0);

zmin = S(k,k);
z = Vk * VV(:,k);

% compute from H

Hk = H(1:k,1:k);
Hku = H(1:k+1,1:k);
HH = Hku' * Hku;
HH = HH - theta * Hk' - conj(theta) * Hk + abs(theta)^2 * eye(k);

[X,D] = eig(full(HH));
D = real(D);

[y,j] = min(diag(D));

z1min = sqrt(D(j,j));
z1 = Vk * X(:,j);


