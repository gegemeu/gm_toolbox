function gm_random_Ritzval_k(A,nsamp,k,bnd);
%GM_RANDOM_RITZVAL_K Ritz values at Arnoldi iteration k for random rhs

% Arnoldi started from a random real vector

% Input:
% A = matrix
% nsamp = number of random rhs
% k = iteration number
% bnd = 'bndry' plots the boundary for k = 2

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

n = size(A,1);

if k > n
 error('gm_random_Ritzval_k: We must have k < n')
end

% field of values
gm_fvmod(A,1,32,1);
hold on

for kk = 1:nsamp
 v = randn(n,1);
 v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,v,k,'noreorth','noprint');
 
 Hk=H(1:k,1:k);
 eigHk = eig(full(Hk));
 
 for j = 1:k
  if isreal(eigHk(j))
   plot(eigHk(j),0,'g+')
  else
   if imag(eigHk(j)) > 0
    plot(real(eigHk(j)),imag(eigHk(j)),'b+')
   else
    plot(real(eigHk(j)),imag(eigHk(j)),'r+')
   end % if imag
  end % if isreal
 end % for j
 
end % for kk

if nargin <= 3
 hold off
 return
end

if strcmpi(bnd,'bndry') == 1
 gm_plot_boundary_real_k2b(A);
end

hold off


