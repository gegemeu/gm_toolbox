function gm_loc_Ritz_values_real_k2(A,nptx,npty,bnd);
%GM_LOC_RITZ_VALUES_REAL_K2 locations of the Ritz values for Arnoldi second iteration

% A must be a real normal matrix with a real starting vector
% for the Ritz values to be in this region of the complex plane

% This is done partly by discretization of the FOV and thus not completely reliable
% So far, this works only for pairs of complex conjugate Ritz values

% We solve the inverse problem: Given a point in the complex plane can we
% find a starting vector v such that the second iteration of Arnoldi yields
% this point as a Ritz value?

% Input:
% A = real normal matrix
% nptx, npty = number of discretization points in the x and y directions
% bnd = if 'bndry' plot of the boundary of the feasible region

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%


% check that A is real
if ~isreal(A)
 error('gm_loc_Ritz_values_real_k2: A is not real')
end

n = size(A,1);

if strcmpi(bnd,'bndry') == 1
%  gm_plot_boundary_real_k2b(A);
 gm_plot_boundary_real_k2c(A);
end % if
hold on

if n == 3
 
 warning off
 
 % get the eigenvalues with complex conj first
 
 [AA,lambda,X] = gm_put_imag_first(A);
 
%  figure
 
 % field of values
 [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
 hold on
 
 gm_myezplot_simpler(@(x,y)func_theta_n3b(x,y,lambda(1),lambda(3)),[xmin,xmax,ymin,ymax])
  
 title('          ')
 xlabel('   ')
 ylabel('   ')
 
 % compute values on the curve plotted by gm_myezplot_simpler
 
 a = linspace(xmin,xmax,50);
 
 for jj = 1:length(a)
  b = func_imag_n3b(a(jj),lambda(1),lambda(3));
  if ~isempty(b)
   plot(a(jj),b,'b*')
   plot(a(jj),-b,'r*')
  end % if
 end % for jj
 
 % real eigenvalues
 
 x = linspace(xmin,xmax,50);
 
 for ii = 1:3
  for j = ii+1:3
   delta(ii,j) = lambda(ii) * conj(lambda(j)) + lambda(j) * conj(lambda(ii)) ...
    - (abs(lambda(j))^2 + abs(lambda(ii))^2);
  end % for j
 end % for ii
 
 for k = 1:length(x);
  
  for ii = 1:3
   for j = ii+1:3
    alpha(ii,j) = (x(k) - lambda(ii)) * (lambda(j) - x(k)) * delta(ii,j);
   end % for j
  end % for ii
  
  omm1 = -(alpha(1,3) + alpha(2,3)) / (alpha(1,2) - 2 * (alpha(1,3)+alpha(2,3)));
  omm3 = 1 - 2 * omm1;
  omega = [omm1; omm1; omm3];
  c = sqrt(omega);
  tt = x(k) - lambda;
  rootn3 = sum(omega' .* lambda .* tt) / sum(omega' .* tt);
  if isreal(rootn3)
   plot(x(k),0,'b+')
   plot(rootn3,0,'r+')
  end % if
 end % for k
 
 if nargout <= 3
  hold off
  warning on
  return
 end % if
 
 hold off
 
 warning on
 
 return
 
end % if n = 3

if n == 4
 
 warning off
 
 % get the eigenvalues with complex conj first
 
 [AA,lambda,X,img] = gm_put_imag_first(A);
 
 if img == 1
  
  % case n = 4 with only complex eigenvalues 
  
%   figure
  
  % complex conjugate Ritz values
  
  % field of values
  [xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
  hold on
  
  gm_myezplot_simpler(@(x,y)func_theta_n4p(x,y,lambda(1),lambda(3)),[xmin,xmax,ymin,ymax])
  gm_myezplot_simpler(@(x,y)func_theta_n4m(x,y,lambda(1),lambda(3)),[xmin,xmax,ymin,ymax])
  
  title('          ')
  xlabel('   ')
  ylabel('   ')
  
  % compute values on the curve plotted by gm_myezplot_simpler
  
  a = linspace(xmin,xmax,30);
  
  for jj = 1:length(a)
   b = func_imag_n4(a(jj),lambda(1),lambda(3));
   if ~isempty(b)
    plot(a(jj),b,'b*')
    plot(a(jj),-b,'r*')
   end % if
  end % for jj
  
  % real eigenvalues
  
  for ii = 1:4
   for j = ii+1:4
    delta(ii,j) = lambda(ii) * conj(lambda(j)) + lambda(j) * conj(lambda(ii)) ...
     - (abs(lambda(j))^2 + abs(lambda(ii))^2);
   end % for j
  end % for ii
  
  x = linspace(xmin,xmax,70);
  
  for k = 1:length(x);
   
   for ii = 1:4
    for j = ii+1:4
     alpha(ii,j) = (x(k) - lambda(ii)) * (lambda(j) - x(k)) * delta(ii,j);
    end % for j
   end % for ii
   
   s = real(alpha(1,3) + alpha(1,4) + alpha(2,3) + alpha(2,4));
   ca = real(alpha(1,2) + alpha(3,4) - s);
   cb = real(-(alpha(3,4) - s / 2));
   cc = real(alpha(3,4) / 4 + s / 2);
   
   Delta = cb^2 - 4 * ca * cc;
   
   if Delta > 0
    omm1 = [];
    % check if there is a positive solution
    omp = (-cb + sqrt(Delta)) / (2 * ca);
    omm = (-cb - sqrt(Delta)) / (2 * ca);
    if (omp >= 0) && (omp <= 1/2)
     omm1 = omp;
    elseif (omm >= 0) && (omm <= 1/2)
     omm1 = omm;
    else
     omm1 = [];
    end % if omp
    
    if ~isempty(omm1)
     omm3 = 1/2 - omm1;
     omega = [omm1; omm1; omm3; omm3];
     c = sqrt(omega);
     tt = x(k) - lambda;
     rootn3 = sum(omega' .* lambda .* tt) / sum(omega' .* tt);
     if isreal(rootn3) && rootn3 > xmin && rootn3 < xmax
%       plot(x(k),0,'b+')
%       plot(rootn3,0,'r+')
     end % if isreal
    end % if isempty
   end % if Delta
  end % for k
  
  if nargout <= 3
   hold off
   warning on
   return
  end % if
  
%   if strcmpi(bnd,'bndry') == 1
%    gm_plot_boundary_real_k2b(A);
%   end
  
  hold off
  
  warning on
  
  return
  
 end % if img
end % if n == 4

warning off

% n = 4 with two real eigenvalues and general case n > 4

% figure

[AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

% plot feasible points

gm_find_v_gen_realb(lambda,nptx,npty,xmin,xmax,ymin,ymax);

% plot the boundaries of the feasible region (already done above)

if nargin <= 3
 hold off
 warning on
 return
end

% if strcmpi(bnd,'bndry') == 1
%  gm_plot_boundary_real_k2b(A);
% end

hold off

warning on

end % function

function val=func_theta_n3(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values

r1 = real(lamb1);

D1 = - 4 * x * r1 + 4 * x * lamb3 + 2 * real(lamb1^2) - 2 * lamb3^2;
N1 = 2 * x * lamb3 - lamb3^2 - x.^2 - y.^2;

D2 = 4 * x * abs(lamb1)^2 - 4 * x * lamb3^2 - 2 * abs(lamb1)^2 * r1 + 2 * lamb3^3 ...
 - 2 * (x.^2 + y.^2) * r1 + 2 * (x.^2 + y.^2) * lamb3;
N2 = - 2 * x * lamb3^2 + lamb3^3 + (x.^2 + y.^2) * lamb3;

val = N1 .* D2 - N2 .* D1;

end

function val=func_theta_n3b(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values

r1 = real(lamb1);
d12 = abs(lamb1 - conj(lamb1))^2;
d13 = abs(lamb1 - lamb3)^2;

om1 = (-2 * d13 * x + d13 * (r1 + lamb3)) ./ ((d12 - 4 * d13) * x - d12 * r1 + 2 * d13 * (r1 + lamb3));
om3 = 1 - 2 * om1;
d2 = om1 * d12 + 2 * om3 * d13;
d1 = -2 * (om1 * d12 * r1 + om3 * d13 * (r1 + lamb3));
d0 = om1 * d12 * abs(lamb1)^2 + 2 * om3 * d13 * r1 * lamb3;
val = 4 * d2.^2 .* y.^2 + d1.^2 - 4 * d2 .* d0;

end

function b=func_imag_n3(a,lamb1,lamb3);
% gives the imaginary part or []

b = [];
r1 = real(lamb1);

alp = lamb3 * (2 * a - lamb3) - a.^2;
bet = 4 * a * (abs(lamb1)^2 - lamb3^2) - 2 * abs(lamb1)^2 * real(lamb1) ...
 + 2 * lamb3^3 - 2 * a.^2 * (real(lamb1) - lamb3);
gam = - 2 * a * lamb3^2 + a.^2 * lamb3 + lamb3^3;
del =  4 * a * (lamb3 - real(lamb1)) + 2 * real(lamb1^2) - 2 * lamb3^2;

% coefficient of the quadratic equation in b^2

ca = 2 * (real(lamb1) - lamb3);
cb = - (bet + 2 * alp * (real(lamb1) - lamb3) + del * lamb3);
cc = alp * bet - gam * del;

Delta = cb.^2 - 4 * ca .* cc;

if Delta < 0
 return
else
 D = sqrt(Delta);
 b2p = (-cb + D) / ( 2 * ca);
 b2m = (-cb - D) / ( 2 * ca);
 if (b2p < 0) & (b2m < 0)
  return
 else
  b2 = max(b2p,b2m);
  b = sqrt(b2);
  D1 = - 4 * a * r1 + 4 * a * lamb3 + 2 * real(lamb1^2) - 2 * lamb3^2;
  N1 = 2 * a * lamb3 - lamb3^2 - a.^2 - b.^2;
  om1 = N1 / D1;
  if (om1 > 0) & (om1 < 1/2)
   return
  else
   b = [];
   return
  end
 end
end

end

function b=func_imag_n3b(a,lamb1,lamb3);
% gives the imaginary part or []

b = [];
r1 = real(lamb1);
d12 = abs(lamb1 - conj(lamb1))^2;
d13 = abs(lamb1 - lamb3)^2;

om1 = (-2 * d13 * a + d13 * (r1 + lamb3)) ./ ((d12 - 4 * d13) * a - d12 * r1 + 2 * d13 * (r1 + lamb3));
if (om1 < 0) || (om1 > 1/2)
 return
end
om3 = 1 - 2 * om1;
d2 = om1 * d12 + 2 * om3 * d13;
d1 = -2 * (om1 * d12 * r1 + om3 * d13 * (r1 + lamb3));
d0 = om1 * d12 * abs(lamb1)^2 + 2 * om3 * d13 * r1 * lamb3;
Del = d1.^2 - 4 * d2 .* d0;
if Del >= 0
 return
else
 b = sqrt(-Del) / (2 * d2);
end

end

function val=func_theta_n4(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values for n = 4

r1 = real(lamb1);
r3 = real(lamb3);

D1 = - 4 * x * r1 + 4 * x * r3 + 2 * real(lamb1^2) - 2 * real(lamb3^2);
N1 = 2 * x * lamb3 - real(lamb3^2) - x.^2 - y.^2;

D2 = 4 * x * abs(lamb1)^2 - 4 * x * abs(lamb3^2) - 2 * abs(lamb1)^2 * r1 + 2 * abs(lamb3^2) * r3 ...
 - 2 * (x.^2 + y.^2) * r1 + 2 * (x.^2 + y.^2) * r3;
N2 = - 2 * x * abs(lamb3)^2 + abs(lamb3)^2 * r3 + (x.^2 + y.^2) * r3;

val = N1 .* D2 - N2 .* D1;

end

function val=func_theta_n4m(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values for n = 4

r1 = real(lamb1);
r3 = real(lamb3);
d12 = abs(lamb1 - conj(lamb1))^2;
d13 = abs(lamb1 - lamb3)^2;
d14 = abs(lamb1 - conj(lamb3))^2;
d34 = abs(lamb3 - conj(lamb3))^2;

c2 = x * (d12 - 2 * (d13 + d14) + d34) - d12 * r1 + (d13 + d14) * (r1 + r3) - d34 * r3;
c1 = x * (d13 + d14 - d34) - (1/2) * (d13 + d14) * (r1 + r3) + d34 * r3;
c0 = x * d34 / 4 - d34 * r3 / 4;
del = c1^2 - 4 * c2 * c0;
if del > 0
 om1 = (-c1 - sqrt(del)) / (2 * c2);
else
 val = 0;
 return
end

om3 = 1 / 2 - om1;
d2 = om1^2 * d12 + 2 * om1 * om3 * (d13 + d14) + om3^2 * d34;
d1 = -2 * ( om1^2 * d12 * r1 + om1 * om3 * (d13 + d14) * (r1 + r3) + om3^2 * d34 * r3);
d0 = om1^2 * d12 * abs(lamb1)^2 + 2 * om1 * om3 * (d13 * real(lamb1 * lamb3) + d14 * real(lamb1 * conj(lamb3))) + om3^2 * d34 * abs(lamb3)^2;
val = 4 * d2.^2 .* y.^2 + d1.^2 - 4 * d2 .* d0;

end

function val=func_theta_n4p(x,y,lamb1,lamb3)
% gives the location of the complex conjugate Ritz values for n = 4

r1 = real(lamb1);
r3 = real(lamb3);
d12 = abs(lamb1 - conj(lamb1))^2;
d13 = abs(lamb1 - lamb3)^2;
d14 = abs(lamb1 - conj(lamb3))^2;
d34 = abs(lamb3 - conj(lamb3))^2;

c2 = x * (d12 - 2 * (d13 + d14) + d34) - d12 * r1 + (d13 + d14) * (r1 + r3) - d34 * r3;
c1 = x * (d13 + d14 - d34) - (1/2) * (d13 + d14) * (r1 + r3) + d34 * r3;
c0 = x * d34 / 4 - d34 * r3 / 4;
del = c1^2 - 4 * c2 * c0;
if del > 0
 om1 = (-c1 + sqrt(del)) / (2 * c2);
else
 val = 0;
 return
end

om3 = 1 / 2 - om1;
d2 = om1^2 * d12 + 2 * om1 * om3 * (d13 + d14) + om3^2 * d34;
d1 = -2 * ( om1^2 * d12 * r1 + om1 * om3 * (d13 + d14) * (r1 + r3) + om3^2 * d34 * r3);
d0 = om1^2 * d12 * abs(lamb1)^2 + 2 * om1 * om3 * (d13 * real(lamb1 * lamb3) + d14 * real(lamb1 * conj(lamb3))) + om3^2 * d34 * abs(lamb3)^2;
val = 4 * d2.^2 .* y.^2 + d1.^2 - 4 * d2 .* d0;

end

function b=func_imag_n4(a,lamb1,lamb3);
% gives the imaginary part or [] for n = 4

b = [];

r1 = real(lamb1);
r3 = real(lamb3);

alp = 2 * a * r3 - real(lamb3^2) - a.^2;
bet = 4 * a * (abs(lamb1)^2 - abs(lamb3)^2) - 2 * abs(lamb1)^2 * r1 ...
 + 2 * abs(lamb3)^2 * r3 - 2 * a.^2 * (r1 - r3);
gam = - 2 * a * abs(lamb3)^2 + a.^2 * r3 + abs(lamb3)^2 * r3;
del =  4 * a * (r3 - r1) + 2 * real(lamb1^2) - 2 * real(lamb3^2);

% coefficient of the quadratic equation in b^2

ca = 2 * (r1 - r3);
cb = - (bet + 2 * alp * (r1 - r3) + del * r3);
cc = alp * bet - gam * del;

Delta = cb.^2 - 4 * ca .* cc;

if Delta < 0
 return
else
 D = sqrt(Delta);
 b2p = (-cb + D) / ( 2 * ca);
 b2m = (-cb - D) / ( 2 * ca);
 if (b2p < 0) & (b2m < 0)
  return
 else
  b2 = max(b2p,b2m);
  b = sqrt(b2);
  D1 = - 4 * a * r1 + 4 * a * r3 + 2 * real(lamb1^2) - 2 * real(lamb3^2);
  N1 = 2 * a * lamb3 - real(lamb3^2) - a.^2 - b.^2;
  om1 = N1 / D1;
  if (om1 > 0) & (om1 < 1/2)
   return
  else
   b = [];
   return
  end
 end
end

end







