function [V,H,VHs,Rvals,Rvec,res,time_mat]=gm_Arnoldi_Hous(A,u,nitmax,reorths,prints);
%GM_ARNOLDI_HOUS Arnoldi iteration for a matrix A with Householder reflections

% this code is much too slow

%
% Input:
% A =  matrix
% u = starting vector
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% reorths = 'reorth' double reorthogonalization
%         = anything else, no reorthogonalization
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V = Arnoldi vectors
% H = tridiagonal matrix
% VHs = eigenvectors of H
% Rvals = eigenvalues of H
% Rvec = Ritz vectors
% res = residual norms || (A-theta I)x ||
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products
%  otherwise same without the first two items

%
% Author G. Meurant
% July 2015
%

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n - 1;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

nitmax = min(nitmax,n-1);

if strcmpi(reorths,'reorth') == 1
 reorth = 1;
else
 reorth = 0;
end

if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 iprint = 0;
 tic
end

u = u / norm(u);

dotprod = 0;
matvec = 0;
nreo = 0;
H = sparse(nitmax,nitmax);
V = zeros(n,nitmax);
W = zeros(n,nitmax);
ww = zeros(1,nitmax);

mi = norm(u);
w = zeros(n,1);
w(1) = 1;
sir = sign(u(1));
if sir == 0
 sir = 1;
end
if mi ~= 0
 beta = u(1) + sir * mi;
 w(2:n) = u(2:n) ./ beta;
end % if mi
W(:,1) = w;
wtw = w' * w;
ww(1) = wtw;
e1 = eye(n,1);
vv = e1 - 2 * (w(1) / wtw) * w;
dotprod = dotprod + 1;

V(:,1) = vv;

if timing == 1
 tinit = toc;
 if iprint == 1
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 1:nitmax
 Av = A * V (:,k);
 w = Av;
 matvec = matvec + 1;
 
 % apply the Householder reflections to A v
 rAv = Av;
 for kk = 1:k
  wx = W(:,kk);
  wtAv = wx' * rAv;
  rAv = rAv - 2 * (wtAv / ww(kk)) * wx;
 end % for kk
 rr = rAv;
 dotprod = dotprod + k;
 
 if k < n
  mn = norm(rr(k+1:n));
  dotprod =dotprod + 1;
 else
  mn = 0;
 end % if k
 if mn ~= 0
  if k+1 <= n
   w(1:k) = zeros(k,1);
   w(k+1:n) = rr(k+1:n);
   mi = norm(w);
   dotprod = dotprod + 1;
   if mi ~=0 && k+1 < n
    beta = w(k+1) + sign(w(k+1)) * mi;
    if abs(beta) <= eps
     beta = w(k+1) - sign(w(k+1)) * mi;
    end % if abs
    if abs(beta) <= eps
     % sign(0) = 0 in Matlab
     beta = -mi;
    end % if abs
    w(k+2:n) = w(k+2:n) ./ beta;
   end % if mi
   w(k+1) = 1;
   wtr = w' * rr;
   rr = rr - 2 * (wtr / (w' * w)) * w;
   dotprod = dotprod + 1;
  end % if k+1
 else
  w = zeros(n,1);
 end % if mn
 W(:,k+1) = w;
 ww(k+1) = w' * w;
 dotprod = dotprod + 1;
 if k <= n-1
  H(1:k+1,k) = rr(1:k+1);
 else
  H(1:n,n) = rr(1:n);
 end % if k
 if k < n
  if ww(k+1) > 0
   ek1 = zeros(n,1);
   ek1(k+1) = 1;
   we = ek1 - 2 * (w(k+1) / ww(k+1)) * w;
   % apply the preceding Householder reflections
   for kk = k:-1:1
    wx = W(:,kk);
    wte = wx' * we;
    we = we - 2 * (wte / ww(kk)) * wx;
   end % for kk
   dotprod = dotprod + k;
  else
   if iprint == 1
    fprintf('\n ww = 0, k = %d, %g \n',k+1,ww(k+1))
   end
  end % if ww
  V(:,k+1) = we;
 end % if k
 
 % reorthogonalization (twice is enough)
 if reorth == 1
  nreo = nreo + 1;
  w = V(:,k+1);
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  for j = 1:k
   alpha = V(:,j)' * w;
   w = w - alpha * V(:,j);
   H(j,k) = H(j,k) + alpha;
  end % for j
  dotprod = dotprod + k;
  dk = w;
  gk = norm(dk);
  dotprod = dotprod + 1;
  dk1 = dk / gk;
  % next basis vector
  V(:,k+1) = dk1;
 end % if reorth
 
end % for k

H = H(1:nitmax,1:nitmax);

% eigenvalues and eigenvectors of H

[vh,dh] = eig(full(H(1:nitmax,1:nitmax)));

% Eigenvalues
Rvals = diag(dh);

% Eigenvectors
VHs = vh;

% approx of eigenvectors
Rvec = V(:,1:nitmax) * VHs;

H = H(1:nitmax,1:nitmax);
V = V(:,1:nitmax);

if timing == 1
 titer = toc;
 if iprint == 1
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nitmax)
 fprintf(' Number of reorthogonalizations = %d \n',nreo)
end

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end


