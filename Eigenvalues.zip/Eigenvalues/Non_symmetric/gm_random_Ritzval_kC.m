function gm_random_Ritzval_kC(A,nsamp,k);
%GM_RANDOM_RITZVAL_KC Ritz values at Arnoldi iteration k for random rhs
% from Arnoldi with complex starting vectors

% this gives different localization than with only real vectors

% Input:
% A = matrix
% nsamp = number of random rhs
% k = iteration number

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

n = size(A,1);

if k > n
 error('gm_random_Ritzval_kC: We must have k < n')
end

figure

% field of values
gm_fvmod(A,1,32,1);
hold on

for kk = 1:nsamp
 v = randn(n,1) + randn(n,1) * 1i;
 v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,v,k,'noreorth','noprint');
 
 H2=H(1:2,1:2);
 eigH2 = eig(full(H2));
 
 theta1 = eigH2(1);
 theta2 = eigH2(2);
 if imag(eigH2(2)) > 0
  theta1 = eigH2(2);
  theta2 = eigH2(1);
 end % if imag
 
 plot(real(theta1),imag(theta1),'b+')
 plot(real(theta2),imag(theta2),'r+')
 
end % for kk

hold off


