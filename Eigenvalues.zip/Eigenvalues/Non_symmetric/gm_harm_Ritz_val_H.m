function lambda=gm_harm_Ritz_val_H(H);
%GM_HARM_RITZ_VAL_H computes the harmonic Ritz values of the Hessenberg matrix H

% Input:
% H = upper Hessenberg matrix
%
% Output:
% lambda = harmonic Ritz values of the matrices H_k (in columns)

%
% Author G. Meurant
% June 2011
% Updated Sept 2015
%

n = size(H,1);
lambda = zeros(n,n-1);

for k = 1:n-1
  Hk = H(1:k,1:k);
  Hki = inv(Hk)';
  HHk = Hk + H(k+1,k)^2 * [zeros(k,k-1) Hki(:,k)];
  lambda(1:k,k) = sort(eig(full(HHk)));
end % for k






  