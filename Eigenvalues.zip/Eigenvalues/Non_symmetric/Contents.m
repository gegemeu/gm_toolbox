% NON_SYMMETRIC
%
% functions for nonsymmetric eigenvalue problems
%
% Files
%   gm_A_valvec                    - computes the eigenvalues and eigenvectors
%   gm_Arnoldi                     - Arnoldi algorithm for a matrix A, modified Gram-Schmidt
%   gm_Arnoldi_CGS                 - Arnoldi iteration for a matrix A, classical Gram-Schmidt
%   gm_Arnoldi_hoemmen             - Arnoldi factorization using Hoemmen's block GS
%   gm_Arnoldi_Hous                - Arnoldi iteration for a matrix A with Householder reflections
%   gm_Arnoldi_stewart             - Arnoldi factorization using Stewart's block GS
%   gm_biLanczos                   - bi-Lanczos iteration for a matrix A
%   gm_dist_Ritzval                - distance of Ritz values to lambda
%   gm_distance_eigvec_Krylov      - distances of the eigenvectors of A to Krylov subspaces
%   gm_eigbiLanczos                - bi-Lanczos iteration for a matrix A
%   gm_harm_Ritz_val_H             - computes the harmonic Ritz values of the Hessenberg matrix H
%   gm_harm_Ritz_values_H          - computes the harmonic Ritz values of the Hessenberg matrix H
%   gm_harm_Ritz_valvec            - computes the harmonic Ritz values and eigenvectors of the Hessenberg matrix H
%   gm_Mkinv                       - formula for the inverse of the moment matrix M_k for a normal matrix A
%   gm_momat                       - moment matrix M(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j-1) for a normal matrix
%   gm_moment                      - moment matrix for A normal
%   gm_plot_Ritz                   - plot of the eigenvalues and Ritz values at each iteration
%   gm_plot_Ritz_fov               - plot of the Arnoldi Ritz values at each iteration and of the field of values
%   gm_plot_Ritz_harm_fov          - plot of the Arnoldi harmonic Ritz values at each iteration
%   gm_plot_Ritz_val               - plot of the eigenvalues and Arnoldi Ritz values at each iteration
%   gm_plot_Ritzval                - plot of the Ritz values every it iterations
%   gm_put_imag_first              - puts the complex conjugate eigenvalues first in the computation of the eigenvalues
%   gm_QOR_opt_partial_Ritz        - vector basis and Ritz values from the Q-OR optimal truncated iteration
%   gm_QOR_optinv_Ritz             - basis vectors and Ritz values from the Q-OR optimal iteration
%   gm_random_Ritzval_allk         - Ritz values at all Arnoldi iterations for random rhs
%   gm_random_Ritzval_allkC        - Ritz values at all Arnoldi iterations for random rhs
%   gm_random_Ritzval_harm_allk    - Harmonic Ritz values at all iterations for random rhs
%   gm_random_Ritzval_harm_k       - harmonic Ritz values at iteration k for random rhs
%   gm_random_Ritzval_harminv_allk - harmonic Ritz values at all Arnoldi iterations for random rhs
%   gm_random_Ritzval_harminv_k    - inverses of harmonic Ritz values at Arnoldi iteration k for random rhs
%   gm_random_Ritzval_k            - Ritz values at Arnoldi iteration k for random rhs
%   gm_random_Ritzval_kC           - Ritz values at Arnoldi iteration k for random rhs
%   gm_refined_Ritz_vect           - computes a refined Ritz vector
%   gm_Ritz_H                      - Ritz values of the Hessenberg matrix H
%   gm_Ritz_harm                   - harmonic Ritz values at iteration k
%   gm_Ritz_valvec                 - computes the Ritz values and vectors of the Hessenberg matrix H 
%   gm_spectral_proj               - spectral projector associated with lamb(k)
