
% NON_SYMMETRIC EIGENVALUE PROBLEMS
%
% Files
%   gm_A_valvec                    - computes the eigenvalues computes the eigenvalues and eigenvectors of upper Hessenberg H
%   gm_Arnoldi                     - Arnoldi iteration for a matrix A, modified Gram-Schmidt
%   gm_Arnoldi_CGS                 - Arnoldi iteration for a matrix A, classical Gram-Schmidt
%   gm_Arnoldi_hoemmen             - Arnoldi factorization using Hoemmen's block Gram-Schmidt
%   gm_Arnoldi_Hous                - Arnoldi iteration for a matrix A with Householder
%   gm_Arnoldi_stewart             -  Arnoldi factorization using Stewart's block Gram-Schmidt
%   gm_biLanczos                   - Bi-Lanczos iteration for a matrix A, Ritz values and vectors
%   gm_bndry_points_complex_k2     - utility function, computation of boundary points for k = 2 (complex case)
%   gm_bndry_pointsk2              - utility function, computation of boundary points for k = 2
%   gm_C_matrix_gen                - utility function, builds the matrix and rhs for omega for k Ritz values
%   gm_C_matrix_gen_real           - utility function, builds the matrix and rhs for omega for k Ritz values
%   gm_C_matrix_gen_real_lambda    - utility function, builds the matrix and rhs for omega for k Ritz values
%   gm_C_matrix_gen_realb          - utility function, builds the matrix and rhs for omega for k Ritz values
%   gm_coeff_pol_Ritz              - coefficients of the characteristic polynomial of the Hessenberg matrix for the Ritz values
%   gm_coeff_pol_Ritz_harm         - coefficients of the characteristic polynomial of the Hessenberg matrix for the harmonic Ritz values
%   gm_distance_eigvec_Krylov      - distances of the eigenvectors of A to Krylov subspaces
%   gm_eigbiLanczos                - Bi-Lanczos iteration for a matrix A, Ritz values
%   gm_find_roots_n4               - utility function, computes points on the projection of the intersection of two hyperboloids
%   gm_find_v_gen                  - finds if there is a vector v s.t. theta are Ritz values for A
%   gm_find_v_gen_real             - finds if there is a vector v s.t. theta are Ritz values for real A
%   gm_find_v_gen_real_lambda      - finds is there is a vector v s.t. theta are Ritz values for A
%   gm_find_v_gen_realb            - locations of Ritz values for k = 2
%   gm_harm_Ritz_val_H             - computes the harmonic Ritz values of the Hessenberg matrix H
%   gm_harm_Ritz_values_H          - computes the harmonic Ritz values of the Hessenberg matrix H
%   gm_harm_Ritz_valvec            - computes the harmonic Ritz values and eigenvectors of the Hessenberg matrix H
%   gm_loc_Ritz_values             - location of one Ritz value when all the other ones are fixed for the Arnoldi iteration
%   gm_loc_Ritz_values_direct      - location of the Arnoldi Ritz values for k = 2, 3 or 4
%   gm_loc_Ritz_values_gen_k2      - location of one Ritz value when the other one is fixed as real for the Arnoldi second iteration
%   gm_loc_Ritz_values_real_k2     - locations of the Ritz values for Arnoldi second iteration
%   gm_loc_Ritz_values_real_k3     - locations of the complex Ritz values  of the Arnoldi third iteration
%   gm_loc_Ritz_values_real_wf     - location of the Ritz values for k = 2 without a call to "figure"
%   gm_Mkinv                       - formula for the inverse of the moment matrix M_k for any n for a normal matrix A
%   gm_momat                       - moment matrix M(i,j) = sum om(k)conj(lamb(k))^(i-1) lamb(k)^(j-1) for a normal matrix
%   gm_moment                      - moment matrix for A normal real
%   gm_plot_boundary_complex_k2b   - boundaries of the locations of the last Ritz value
%   gm_plot_boundary_real_k2       - boundaries of the region containing Ritz values for Arnoldi second iteration
%   gm_plot_boundary_real_k2b      - boundaries of the region containing Ritz values for Arnoldi second iteration
%   gm_plot_Ritz                   - plot of the eigenvalues and Ritz values at each iteration
%   gm_plot_Ritz_fov               - plot of the Arnoldi Ritz values at each iteration and of the field of values
%   gm_plot_Ritz_harm_fov          - plot of the Arnoldi harmonic Ritz values at each iteration and of the field of values
%   gm_plot_Ritz_val               - plot of the eigenvalues and Arnoldi Ritz values at each iteration
%   gm_put_imag_first              - put the complex conjugate eigenvalues first in the computation of the eigenvalues
%   gm_QOR_opt_partial_Ritz        - vector basis and Ritz values from the Q-OR optimal truncated iteration
%   gm_QOR_optinv_Ritz             - vector basis and Ritz values from the Q-OR optimal iteration
%   gm_random_Ritzval_allk         - Ritz values at all Arnoldi iterations for random rhs (real vectors)
%   gm_random_Ritzval_allkC        - Ritz values at all Arnoldi iterations for random rhs (complex vectors)
%   gm_random_Ritzval_harm_allk    - harmonic Ritz values at all iterations for random rhs (real vectors)
%   gm_random_Ritzval_harm_k       - harmonic Ritz values at iteration k for random rhs (real vectors)
%   gm_random_Ritzval_harminv_allk - inverses of harmonic Ritz values at all Arnoldi iterations (real vectors)
%   gm_random_Ritzval_harminv_k    - inverses of harmonic Ritz values at Arnoldi iteration k
%   gm_random_Ritzval_k            - Ritz values at Arnoldi iteration k for random rhs (real vectors)
%   gm_random_Ritzval_kC           - Ritz values at Arnoldi iteration k for random rhs (complex vectors)
%   gm_refined_Ritz_vect           - computes a refined Ritz vector for a given theta
%   gm_Ritz_gui                    - interactive interface for the location of the second Ritz value
%   gm_Ritz_H                      - computes the Ritz values of the Hessenberg matrix H
%   gm_Ritz_harm                   - harmonic Ritz values at iteration k
%   gm_Ritz_rand_gui               - interactive interface for the location of the second Ritz value, random matrices
%   gm_Ritz_values_bndry_gui       - interactive interface for the boundary of the region for the second Ritz value
%   gm_Ritz_values_gui             - interactive interface for the location of the second Ritz value with the first one fixed
%   gm_Ritz_valvec                 - computes the Ritz values and vectors of the Hessenberg matrix H
%   gm_roots_theta2_n3             - computation of theta2 with theta1 given, k = 2
%   gm_roots_theta2_n4             - projections of the intersection on three planes
%   gm_spectral_proj               - spectral projector associated with lamb(k)



