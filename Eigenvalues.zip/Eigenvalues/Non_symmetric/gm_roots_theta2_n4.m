function [rootn4,c]=gm_roots_theta2_n4(lambda,theta1);
%GM_ROOTS_THETA2_N4 projections of the intersection on three planes
% computation of the intersection in [0, 1]^3

% Input:
% lambda = the four eigenvalues
% theta1 = fixed Ritz value
%
% Output:
% rootn4 = solutions
% c = starting vectors

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

delta = zeros(4,4);
alpha = delta;
rootn4 = [];
c = [];

for i = 1:4
 for j = i+1:4
  delta(i,j) = lambda(i) * conj(lambda(j)) + lambda(j) * conj(lambda(i)) ...
   - (abs(lambda(j))^2 + abs(lambda(i))^2);
  alpha(i,j) = (theta1 - lambda(i)) * (lambda(j) - theta1) * delta(i,j);
 end % for j
end % for i

alphaR = real(alpha);
alphaI = imag(alpha);

% intersection of the two hyperboloids

a1 = -alphaR(1,4);
b1 = alphaR(1,2) - alphaR(1,4) - alphaR(2,4);
c1 = -alphaR(2,4);
d1 = -alphaR(3,4);
e1 = alphaR(1,3) - alphaR(1,4) - alphaR(3,4);
f1 = alphaR(2,3) - alphaR(2,4) - alphaR(3,4);

a2 = -alphaI(1,4);
b2 = alphaI(1,2) - alphaI(1,4) - alphaI(2,4);
c2 = -alphaI(2,4);
d2 = -alphaI(3,4);
e2 = alphaI(1,3) - alphaI(1,4) - alphaI(3,4);
f2 = alphaI(2,3) - alphaI(2,4) - alphaI(3,4);

% elimination of z

if abs(d2) > 1e-13
 dd = d1 / d2;
 alp = a1 - dd * a2;
 bet = b1 - dd * b2;
 gam = c1 - dd * c2;
 del = e1 - dd * e2;
 zet = f1 - dd * f2;
else
 alp = a2;
 bet = b2;
 gam = c2;
 del = e2;
 zet = f2;
end % if abs

% projection on the (x,y) plane

[XX,YY] = gm_find_roots_n4(a1,b1,c1,d1,e1,f1,alp,bet,gam,del,zet,0);

% compute the z on the two hyperboloids

[ZZ1p,ZZ1m] = func_theta2_hyp(XX,YY,a1,b1,c1,d1,e1,f1);

[ZZ2p,ZZ2m] = func_theta2_hyp(XX,YY,a2,b2,c2,d2,e2,f2);

% check if we really have intersections

epsi = 1e-6;

ZZ = zeros(size(ZZ1p));

warning off
 
Ipp = find(abs(ZZ1p-ZZ2p)./abs(ZZ1p)<epsi);
ZZ(Ipp) = (ZZ1p(Ipp) + ZZ2p(Ipp)) / 2;
Ipm = find(abs(ZZ1p-ZZ2m)./abs(ZZ1p)<epsi);
Imp = find(abs(ZZ1m-ZZ2p)./abs(ZZ1m)<epsi);
ZZ(Imp) = (ZZ1m(Imp) + ZZ2p(Imp)) / 2;
Imm = find(abs(ZZ1m-ZZ2m)./abs(ZZ1m)<epsi);
ZZ(Imm) = (ZZ1m(Imm) + ZZ2m(Imm)) / 2;

warning on

II = [Ipp Ipm Imp Imm];

II = sort(unique(II));

X = XX(II);
Y = YY(II);
Z = ZZ(II);

% look for feasible points satisfying the constraints

II = find(Z>0);
X = X(II);
Y = Y(II);
Z = Z(II);

II = find(Z<1);
X = X(II);
Y = Y(II);
Z = Z(II);

S = X + Y + Z;
II = find(S <= 1);
X = X(II);
Y = Y(II);
Z = Z(II);

om1 = X;
om2 = Y;
om3 = Z;
npb = 0;

om4 = 1 - X - Y - Z;

rootn4 = (lambda(1) * (theta1 - lambda(1)) * om1 + lambda(2) * (theta1 - lambda(2))* om2 ...
 + lambda(3) * (theta1 - lambda(3))* om3 + lambda(4) * (theta1 - lambda(4))* om4) ./ ...
 ((theta1 - lambda(1)) * om1 + (theta1 - lambda(2))* om2 ...
 + (theta1 - lambda(3))* om3 + (theta1 - lambda(4))* om4);

om = [om1; om2; om3; om4];
c = sqrt(om);

end % function


function [val1,val2]=func_theta2_hyp(x,y,a,b,c,d,e,f);
% get the z values on one of the hyperboloids

warning off

A = d;
B = - d + e * x + f * y;
C = a * x.^2 + b * x .* y + c * y.^2 - a * x - c * y;

DD = B.^2 - 4 * A * C;
D = sqrt(DD);

val1 = (-B + D) ./ (2 * A);
val2 = (-B - D) ./ (2 * A);

warning on

end



