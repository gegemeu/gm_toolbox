function Theta=gm_Ritz_H(H);
%GM_RITZ_H computes the Ritz values of the Hessenberg matrix H

% Input:
% H = upper Hessenberg matrix from Arnoldi
%
% Output:
% Theta = the column k contains the Ritz values at iteration k

%
% Author G. Meurant
% June 2011
% Updated Sept 2015
%

n = size(H,1);
Theta = zeros(n,n);

for k = 1:n
  Hk = full(H(1:k,1:k));
  Theta(1:k,k) = sort(eig(Hk));
end






  