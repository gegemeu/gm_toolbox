function gm_plot_boundary_complex_k2b(A,theta1);
%GM_PLOT_BOUNDARY_COMPLEX_K2B boundaries of the locations of the last Ritz value

% Input:
% A = complex normal matrix
%     Results are not correct if A is real since we just use the eigenvalues
% theta1 = prescribed Ritz values
%          this corresponds to Arnoldi iteration length(theta1) + 1

%
% Author G. Meurant
% February 2013
% Updated Sept 2015
%

fac = 0.95;
npts = 15;
nplim = 4;

n = size(A,1);
kt = length(theta1) + 1;
kt2 = 2 * kt + 1;

if n <= 4
 error('gm_plot_boundary_complex_k2b: The order of A has to be larger than 4')
end

lambda = eig(full(A));

% plot the field of values

[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

% consider the eigenvalues kt2 by kt2

ncurves = 0;

warning off

% all combinations of 5 elements we need

P = all_combi(n,kt2);
nP = size(P,1);

for kk = 1:nP
 % columns to consider
 Pk = P(kk,:);

 for k = 1:kt2

  ym = xmin * fac;
  yM = xmax * fac;
  y = linspace(ym,yM,npts);
  nbd = 0;
  fbd = 0;
%   start = y(1);
  start = (y(1) + y(npts)) /2;
  for kkk = 1:npts
   % compute x for y(kkk)
   [flag_bnd,xb] = gm_bndry_points_complex_k2(@(x)func_theta_bndry(x,y(kkk),lambda,theta1,Pk,k), ...
    start,A,xmin,xmax,ymin,ymax,y(kkk),theta1);
   if flag_bnd == 1
    nbd = nbd + 1;
    fbd = 1;
    plot(xb,y(kkk),'b*')
   end % if
  end % for kkk
  % this is a real horizontal boundary of the FOV
  if abs(yM-ym) < 1e-3
   fbd = 1;
  end % if abs

  ym = ymin * fac;
  yM = ymax * fac;
  y = linspace(ym,yM,npts);
  start = (y(1) + y(npts)) / 2;
%   start = ym;
  for kkk = 1:length(y)
   [flag_bnd,xb] = gm_bndry_points_complex_k2(@(x)func_theta_bndry(x,y(kkk),lambda,theta1,Pk,k), ...
    start,A,xmin,xmax,ymin,ymax,y(kkk),theta1);
   if flag_bnd == 1
    nbd = nbd + 1;
    fbd = 1;
    plot(xb,y(kkk),'b*')
   end % if flag
  end % for kkk

  if (fbd == 1) && (nbd >= nplim)
   gm_myezplot_simpler(@(x,y)func_theta_bndry(x,y,lambda,theta1,Pk,k),[xmin,xmax,ymin,ymax],'b')
   ncurves = ncurves + 1;
  end % if
 end % for k

%  drawnow

end % for kk

hold off

end % main function

function val = func_theta_bndry(x,y,lambda,theta1,Pk,kc);
% basic solution for columns in Pk, component kc

theta2 = x + 1i * y;
theta = [theta1 theta2];

[CC,CR,rhsC,rhsR] = C_matrix_gen_lambda(lambda,theta);

CRc = CR(:,Pk);

bsol = det(CRc) * (CRc \ rhsR);

val = bsol(kc);

end

