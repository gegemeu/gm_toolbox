function [flag,xb]=gm_bndry_points_complex_k2(varargin);
%GM_BNDRY_POINTS_COMPLEX_K2 computation of boundary points for k = 2
% of the region containing the Arnoldi Ritz values for complex normal matrices

% check if the point xb is on the boundary (flag = 1)

%
% Author G. Meurant
% February 2013
% Updated Sept 2015
%

flag = 0;
xb = [];

[cax,args,nargs] = axescheck(varargin{:});
f = args{1};
args = args(2:end);

[f,fx0,varx] = gm_myezfcnchk(f);

x0 = args{1};
A = args{2};
Xmin = args{3};
Xmax = args{4};
Ymin = args{5};
Ymax = args{6};
yb = args{7};
theta1 = args{8};

% compute a point on the curve

options = optimset('Display','off');

[xb,val,exitflag] = fzero(f,x0,options);

if exitflag ~= 1
 return
end

% is the point feasible?

[flag1,c] = gm_find_v_gen(A,[xb+yb*1i, theta1]);
if flag1 == 0 
 return
end
 
% find 4 surrounding points
% on a regular cartesian mesh over the FOV
% defined by xmin, xmax, ymin, ymax

np = 500;
hx = (Xmax - Xmin) / np;
hy = (Ymax - Ymin) / np;

indx = fix((xb - Xmin) / hx);
indy = fix((yb - Ymin) / hy);

xmi = Xmin + indx * hx;
xma = xmi + hx;
ymi = Ymin + indy * hy;
yma = ymi + hy;

% check the feasibility of the four points

[flag1,c] = gm_find_v_gen(A,[xmi+ymi*1i,theta1]);
[flag2,c] = gm_find_v_gen(A,[xma+ymi*1i,theta1]);
[flag3,c] = gm_find_v_gen(A,[xma+yma*1i,theta1]);
[flag4,c] = gm_find_v_gen(A,[xmi+yma*1i,theta1]);

if (flag1 + flag2 + flag3 + flag4) == 4
 % the point is inside the region
 flag = 0;
else
 flag = 1;
end







