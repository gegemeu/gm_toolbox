function M=gm_momat(om,lamb);
%GM_MOMAT moment matrix M(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j-1) for a normal matrix

% Input:
% om = coefficients ( moduli squared of X^* b, X eigenvectors, b right-hand side)
% lamb = eigenvalues of A (normal)
%
% Output:
% M = moment matrix

%
% Author G. Meurant
% October 2011
% Updated Sept 2015
%

n = length(om);
M = zeros(n,n);
[mo no] = size(om);
[ml nl] = size(lamb);
if mo ~= ml
 lamb = transpose(lamb);
end % if


for i=1:n
  for j=1:n
    M(i,j) = sum(om .* conj(lamb).^(i-1) .* lamb.^(j-1));
    if i == j
      M(i,i) = real(M(i,i));
    end % if
  end % for j
end % for i

