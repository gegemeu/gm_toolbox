function [flag,c]=gm_find_v_gen(A,theta);
%GM_FIND_V_GEN finds if there is a vector v s.t. theta are Ritz values for A
% with Arnoldi started from a vector v

% this works only for small matrices

% Input:
% A = normal matrix
% theta = Ritz values
%
% Output:
% flag = 1 if there is a solution
% c = solution

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

c = [];
flag = 0;

lambda = transpose(eig(A));
DL = diag(lambda);

n = size(A,1);
k = length(theta);
if k > n-1
 error('gm_find_v_gen: There are too many Ritz values, max: n-1')
end

% build the matrix CC and the rhs from the eigenvalues

[CC,CR,rhsC,rhsR] = gm_C_matrix_gen(DL,theta);

% case n <= k+1

if n <= k+1
 error('gm_find_v_gen: n<= k+1 does not work yet')
end

% case where n > k+1
% overdetermined system

% SVD of CC

[U,S,V] = svd(CC);

r = rankCC(S);
if r < (k+1)
 error('gm_find_v_gen: CC is not of full rank')
end

% construct the systems to zero the imaginary part
% and to get a positive real part

D = S(1:r,1:r);
V1 = V(:,1:r);
V2 = V(:,r+1:end);
V2R = real(V2);
V2I = imag(V2);
% the matrix VVI (as well as VVR) is n x 2(n-k-1)
VVI = [V2I V2R];
% sI is 2(n-k-1)
sI = size(VVI,2);
VVR = [V2R -V2I];

% partial solution for CC

yy = D \ (U' * rhsC);

V1y = V1 * yy;
bR = real(V1y);
bI = imag(V1y);

if sI < n
 % case n < 2(k+1) i.e. sI < n
 % we must solve VVI [zR; zI] = - bI
 % this system is overdetermined
 % check if we have a consistent solution
 
 zz = -VVI \ bI;
 % check the residual norm
 rzI = VVI * zz + bI;
 
 % ************CAUTION!!! this test is very critical***********
 epsi = 1e-4;
 if max(abs(rzI)) > epsi
  % no solution
  flag = 0;
  return
 end % if max
 
 % there is a consistent solution
 % we must check that the real part is >= 0
 
 rzR = VVR * zz + bR;
 % Caution! we may have small negative components
 % we must get rid of them
 Ismall = find(abs(rzR) <= 1e-13);
 rzR(Ismall) = 0;
 I = find(rzR < 0);
 if ~isempty(I)
  % the real part is not positive
  flag = 0;
  return
 end % if isempty
 
 % otherwise we have a solution
 om = max(rzR,0);
 c = sqrt(om);
 v = c;
 flag = 1;
 return
end % if sI

% case sI >= n

% equality for the imaginary part to be zero
% we must solve VVI [zR; zI] = - bI

[UI,SI,W] = svd(VVI);

ssI = size(SI,1);
rS = rankCC(SI);
UIb = UI' * bI;
DI = SI(1:rS,1:rS);

% check consistency

for j = ssI:-1:rS+1
 if abs(UIb(j)) > 1e-14
  % there is no solution
  flag = 0;
  return
 end % if abs
end % for j

yyI = -DI \ UIb(1:rS);

% inequality for the real part to be positive

% right-hand side

rhR = VVR * W(:,1:rS) * yyI + bR;

% matrix

VW = -VVR * W(:,rS+1:end);

% solution of the inequality

[flag_ineq,zz] = gm_check_ineq(VW,rhR);

if flag_ineq == 1
 zz = W * [yyI; zz];
 om = max(VVR * zz + bR,0);
 c = sqrt(om);
 v = c;
 flag = 1;
end % if flag

end % function

function r=rankCC(S);
% rank of the matrix arising from SVD
% to avoid recomputing the SVD

D = diag(S);

normS = max(D);
epss = eps * max(size(S)) * normS;
I = find(D > epss);
r = length(I);

end



