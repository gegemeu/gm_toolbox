function P=gm_coeff_pol_Ritz(A,v,k);
%GM_COEFF_POL_RITZ coefficients of the characteristic polynomial of the Hessenberg matrix for the Ritz values

% from the eigenvalues and eigenvectors of a normal matrix A

% See: G. Meurant, The coefficients of the FOM and GMRES residual polynomials,
%                  SIAM J. Matrix Anal. Appl., v 38 n 1 (2017), pp. 96-117

% H upper Hessenberg matrix from Arnoldi
% Of course these coefficients can be computed much faster with poly(H_k), H from gm_Arnoldi
% Caution: this is slow, A has to be small! and k too!

% Input:
% A = real normal matrix
% v = starting vector
% k = iteration number
%
% Output:
% P = polynomial in Matlab format

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(A,1);

if k >= n
 error('gm_coeff_pol_Ritz: k must be smaller than order(A)')
end

% moment matrix
[M,X,D] = gm_moment(A,v);

% inverse of M_k
Mkinv = gm_Mkinv(A,v,k,X,D);

% coefficients of the polynomial

alp = -Mkinv * M(1:k,k+1);

% change the order and add the coefficient of x^k

P = [1; alp(k:-1:1)];



