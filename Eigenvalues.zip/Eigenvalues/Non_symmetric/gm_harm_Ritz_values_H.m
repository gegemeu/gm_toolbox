function lambda=gm_harm_Ritz_values_H(H);
%GM_HARM_RITZ_VALUES_H computes the harmonic Ritz values of the Hessenberg matrix H

% Input:
% H = upper Hessenberg matrix (n+1) x n
%
% Output:
% lambda = harmonic Ritz values of the matrices H_k (in columns)

%
% Author G. Meurant
% June 2011
% Updated Sept 2015
%

n = size(H,1);
lambda = zeros(n,n);

for k = 1:n-1
  Hk = H(1:k,1:k);
  Hki = inv(Hk)';
  HHk = Hk + H(k+1,k)^2 * [zeros(k,k-1) Hki(:,k)];
  lambda(1:k,k) = sort(eig(full(HHk)));
end % for k

lambda(:,n) = sort(eig(full(H)));



  