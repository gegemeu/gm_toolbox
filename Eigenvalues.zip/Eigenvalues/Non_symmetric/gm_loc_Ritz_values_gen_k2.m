function gm_loc_Ritz_values_gen_k2(A,nptx,npty,nptr);
%GM_LOC_RITZ_VALUES_GEN_K2 location of one Ritz value when the other one is fixed as real for the Arnoldi second iteration

% The fixed Ritz values are chosen on the real axis
% This is done by discretization of the FOV and thus not completely reliable

% Input:
% A = normal matrix
% nptx, npty = number of the discretizations points in the x and y
%              directions
% nptr = number of discretization points for the real axis (fixed values)

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

warning off

lambda = transpose(eig(full(A)));
DL = diag(lambda);

% plot the field of values and get the box
[xmin,xmax,ymin,ymax] = gm_fvmod(A,1,32,1);
hold on

x = linspace(xmin,xmax,nptx);
y = linspace(ymin,ymax,npty);

thetaf = linspace(xmin+1e-6,xmax-1e-6,nptr);

if ~isreal(A)
 
 for kk = 1:nptr
  for ii = 1:nptx
   for jj = 1:npty
    % last Ritz value
    theta = [thetaf(kk), x(ii) + y(jj) * i];
    
    [flag,v] = gm_find_v_gen(DL,theta);
    
    if flag == 1
     plot(x(ii),y(jj),'b+')
    end
    
   end % for jj
  end % for ii
 end % for kk
 
else
 
 for kk = 1:nptr
  for ii = 1:nptx
   % last Ritz value
   theta = [thetaf(kk), x(ii)];
   
   [flag,v] = gm_find_v_gen(DL,theta);
   
   if flag == 1
    plot(x(ii),0,'b+')
   end
   
  end % for ii
 end % for kk
 
end % if isreal


hold off

warning on



