function gm_plot_Ritz_harm_fov(A,v,dit);
%GM_PLOT_RITZ_HARM_FOV plot of the Arnoldi harmonic Ritz values at each iteration

% Input:
% A = matrix
% v = starting vector
% dit = step size in the iterations

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(A,1);

if nargin < 3
 dit = 1;
end

% Arnoldi 
[VV,H,VHs,~,Rvec,res,time_mat] = gm_Arnoldi(A,v,n+1,'noreorth','noprint');

figure

for k = 1:dit:n
 Hk = H(1:k,1:k);
 bet = H(k+1,k);
 ek = zeros(k,1); 
 ek(k) = 1;
 y = (Hk') \ ek;
 Hk(:,k) = Hk(:,k) + bet^2 * y;
 % field of values
 gm_fvmod_noax(A);
 hold on
 eigH = eig(full(Hk));
 plot(real(eigH),imag(eigH),'kd')
 title(['Iteration ' num2str(k)])
 pause
 hold off
end % for k

hold off

