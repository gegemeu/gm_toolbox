function gm_loc_Ritz_values_direct(A,npt,kk,bnd);
%GM_LOC_RITZ_VALUES_DIRECT location of the Arnoldi Ritz values for k = 2, 3 or 4
% direct method

% A has to be real normal of order 4 <= n <= 7
% Up to the discretization we consider all possible starting vectors
% for Arnoldi

% There can be a few misclassifications

% Input:
% A = real normal matrix
% npt = number of discretization points
% kk = integer, description of the iterations to consider
%      could be 2, 3, 4, 23, 24, 34, 234
% bnd = 'bndry' plots the boundary of the feasible region for k = 2

% 
% Author G. Meurant
% Sept 2015
%

n = size(A,1);

if n > 7
 error('gm_loc_Ritz_values_direct: The order of A has to be <= 7');
end

if n < 4
 error('gm_loc_Ritz_values_direct: The order of A has to be >= 4')
end

warning('off','all');

if strcmpi(bnd,'bndry') == 1
 gm_plot_boundary_real_k2c(A);
end
hold on

switch n
 
 case 4
  
  % n = 4
  
  [AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);
  
  if length(II) == 0
   fprintf('\n gm_loc_Ritz_values_direct: All the eigenvalues are real \n\n')
   return
  end
  
%   figure
  
  % field of values
  gm_fvmod(A,1,32,1);
  hold on
  
  ii = sqrt(-1);
  u1 = 1;
  u2 = (-1 + ii * sqrt(3)) / 2;
  u3 = (-1 - ii * sqrt(3)) / 2;
  
  if img == 1
   
   % no real eigenvalues
   
   om1 = linspace(0,1/2,npt);
   om3 = (1 - 2 * om1) / 2;
   
   if kk == 2 || kk == 23 || kk == 234
    
    % 2nd iteration
    
    for k = 1:npt
     
     % moment matrix
     M = gm_momat([om1(k), om1(k), om3(k), om3(k)],lambda);
     M2 = M(1:2,1:2);
     % coefficients of the characteristic polynomial of H_2
     if rcond(M2) > 1e-16
      alpha = -M2 \ M(1:2,3);
      % roots of the quadratic polynomial
      Del = alpha(2)^2 - 4 * alpha(1);
      if Del < 0
       teta = (-alpha(2) + sqrt(Del)) / 2;
       plot(real(teta),imag(teta),'b+')
       plot(real(teta),-imag(teta),'b+')
      end % if
     end % if
     
    end % for k
    
   end % if kk
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 234
    
    % 3rd iteration
    
    for k = 1:npt
     
     % moment matrix
     M = gm_momat([om1(k), om1(k), om3(k), om3(k)],lambda);
     M3 = M(1:3,1:3);
     % coefficients of the characteristic polynomial of H_3
     if rcond(M3) > 1e-16
      alpha = -M3 \ M(1:3,4);
      a = 1;
      b = alpha(3);
      c = alpha(2);
      d = alpha(1);
      % roots of the cubic polynomial
      Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
      if Del < 0
       D0 = b^2 - 3 * a * c;
       D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
       C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
       x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
       x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
       x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
       if imag(x1) ~= 0
        plot(real(x1),imag(x1),'m+')
       end
       if imag(x2) ~= 0
        plot(real(x2),imag(x2),'m+')
       end
       if imag(x3) ~= 0
        plot(real(x3),imag(x3),'m+')
       end
      end % if Del
     end % if
     
    end % for k
    
   end % if kk
   
  else % if img
   
   % 2 real eigenvalues
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1,npt);
   
   if kk == 2 || kk == 23 || kk == 234
    
    % 2nd iteration
    
    for k = 1:npt
     for j = 1:npt
      
      om4 = 1 - 2 * om1(k) - om3(j);
      if om4 < 0
       break
      end
      % moment matrix
      M = gm_momat([om1(k), om1(k), om3(j), om4],lambda);
      M2 = M(1:2,1:2);
      % coefficients of the characteristic polynomial of H_2
      if rcond(M2) > 1e-16
       alpha = -M2 \ M(1:2,3);
       % roots of the quadratic polynomial
       Del = alpha(2)^2 - 4 * alpha(1);
       teta = (-alpha(2) + sqrt(Del)) / 2;
       if Del < 0
        % complex Ritz values
        plot(real(teta),imag(teta),'b+')
        plot(real(teta),-imag(teta),'b+')
       else
        % real Ritz values
%         plot(teta,0,'c+')
%         teta2 = (-alpha(2) - sqrt(Del)) / 2;
%         plot(teta2,0,'c+')
       end % if
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      
      om4 = 1 - 2 * om1(k) - om3(j);
      if om4 < 0
       break
      end
      
      % moment matrix
      M = gm_momat([om1(k), om1(k), om3(j), om4],lambda);
      om = [om1(k), om1(k), om3(j), om4];
      omm = 1;
      M3 = M(1:3,1:3);
      % coefficients of the characteristic polynomial of H_3
      if rcond(M3) > 1e-16
       alpha = -M3 \ M(1:3,4);
       a = 1;
       b = alpha(3);
       c = alpha(2);
       d = alpha(1);
       % roots of the cubic polynomial
       Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
       if Del < 0
        D0 = b^2 - 3 * a * c;
        D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
        C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
        x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
        x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
        x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'g+')
%         else
%          plot(real(x1),0,'k+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'g+')
%         else
%          plot(real(x1),0,'k+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'g+')
%         else
%          plot(real(x1),0,'k+')
        end
       end % if Del
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
  end % if img
  
  hold off
  
  warning on
  
 case 5
  
  % n = 5
  
  [AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);
  
  if length(II) == 0
   fprintf('\n gm_loc_Ritz_values_direct: All the eigenvalues are real \n\n')
   return
  end
  
%   figure
  
  % field of values
  gm_fvmod(A,1,32,1);
  hold on
  
  ii = sqrt(-1);
  u1 = 1;
  u2 = (-1 + ii * sqrt(3)) / 2;
  u3 = (-1 - ii * sqrt(3)) / 2;
  
  if p == 2
   
   % 2 pairs of complex eigenvalues, 1 real
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1/2,npt);
   
   % second iteration
   
   if kk == 2 || kk == 23 || kk == 24 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = 1 - 2 * om1(k) - 2 * om3(j);
      if om5 < 0
       break
      end
      % moment matrix
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5],lambda);
      M2 = M(1:2,1:2);
      % coefficients of the characteristic polynomial of H_2
      if rcond(M2) > 1e-16
       alpha = -M2 \ M(1:2,3);
       % roots of the quadratic polynomial
       Del = alpha(2)^2 - 4 * alpha(1);
       if Del < 0
        teta = (-alpha(2) + sqrt(Del)) / 2;
        plot(real(teta),imag(teta),'b+')
        plot(real(teta),-imag(teta),'b+')
       end % if
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = 1 - 2 * om1(k) - 2 * om3(j);
      if om5 < 0
       break
      end
      
      % moment matrix
      om = [om1(k), om1(k), om3(j), om3(j), om5];
%       omm = all(om) & all(om ~= 1);
      omm = 1;
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5],lambda);
      M3 = M(1:3,1:3);
      % coefficients of the characteristic polynomial of H_3
      if rcond(M3) > 1e-16
       alpha = -M3 \ M(1:3,4);
       a = 1;
       b = alpha(3);
       c = alpha(2);
       d = alpha(1);
       % roots of the cubic polynomial
       Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
       if Del < 0
        D0 = b^2 - 3 * a * c;
        D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
        C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
        x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
        x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
        x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
%         if (abs(imag(x1)) > 1e-10) && (om5 ~= 1)
        if (abs(imag(x1)) > 1e-10) 
         plot(real(x1),imag(x1),'g+')
        end
        if (abs(imag(x2)) > 1e-10) && omm == 1
         plot(real(x2),imag(x2),'g+')
        end
        if (abs(imag(x3)) > 1e-10) && omm == 1
         plot(real(x3),imag(x3),'g+')
        end
       end % if Del
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
   % 4th iteration
   
   if kk == 4 || kk == 24 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = 1 - 2 * om1(k) - 2 * om3(j);
      if om5 < 0
       break
      end
      
      % moment matrix
      om = [om1(k), om1(k), om3(j), om3(j), om5];
      omm = all(om) & all(om ~= 1);
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5],lambda);
      M4 = M(1:4,1:4);
      % coefficients of the characteristic polynomial of H_4
      if rcond(M4) > 1e-16
       alpha = -M4 \ M(1:4,5);
       % roots of the quartic polynomial
       x = quartique([1 alpha(4) alpha(3) alpha(2) alpha(1)]);
       x1 = x(1);
       x2 = x(2);
       x3 = x(3);
       x4 = x(4);
%        if (abs(imag(x1)) > 1e-10) && omm
%         plot(real(x1),imag(x1),'m+')
%        end
%        if (abs(imag(x2)) > 1e-10) && omm
%         plot(real(x2),imag(x2),'m+')
%        end
%        if (abs(imag(x3)) > 1e-10) && omm
%         plot(real(x3),imag(x3),'m+')
%        end
%        if (abs(imag(x4)) > 1e-10) && omm
%         plot(real(x4),imag(x4),'m+')
%        end
       if (abs(imag(x1)) > 1e-10) && omm
        plot(real(x1),imag(x1),'b+')
       end
       if (abs(imag(x2)) > 1e-10) && omm
        plot(real(x2),imag(x2),'b+')
       end
       if (abs(imag(x3)) > 1e-10) && omm
        plot(real(x3),imag(x3),'b+')
       end
       if (abs(imag(x4)) > 1e-10) && omm
        plot(real(x4),imag(x4),'b+')
       end
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
  end % if p
  
  if p == 1
   
   % 1 pair of complex eigenvalues, 3 real
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1,npt);
   om4 = om3;
   
   % 2nd iteration
   
   if kk == 2 || kk == 23 || kk == 24 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om5 = 1 - 2 * om1(k) - om3(j) - om4(m);
       if om5 < 0
        break
       end
       % moment matrix
       M = gm_momat([om1(k), om1(k), om3(j), om4(m), om5],lambda);
       M2 = M(1:2,1:2);
       % coefficients of the characteristic polynomial of H_2
       if rcond(M2) > 1e-16
        alpha = -M2 \ M(1:2,3);
        % roots of the quadratic polynomial
        Del = alpha(2)^2 - 4 * alpha(1);
        if Del < 0
         teta = (-alpha(2) + sqrt(Del)) / 2;
         plot(real(teta),imag(teta),'b+')
         plot(real(teta),-imag(teta),'b+')
        end % if
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om5 = 1 - 2 * om1(k) - om3(j) - om4(m);
       if om5 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om4(m), om5];
%        omm = all(om) & all(om ~= 1);
       omm = 1;
       M = gm_momat([om1(k), om1(k), om3(j), om4(m), om5],lambda);
       M3 = M(1:3,1:3);
       % coefficients of the characteristic polynomial of H_3
       if rcond(M3) > 1e-16
        alpha = -M3 \ M(1:3,4);
        a = 1;
        b = alpha(3);
        c = alpha(2);
        d = alpha(1);
        % roots of the cubic polynomial
        Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
        if Del < 0
         D0 = b^2 - 3 * a * c;
         D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
         C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
         x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
         x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
         x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
         if (abs(imag(x1)) > 1e-10) && omm
          plot(real(x1),imag(x1),'g+')
         end
         if (abs(imag(x2)) > 1e-10) && omm
          plot(real(x2),imag(x2),'g+')
         end
         if (abs(imag(x3)) > 1e-10) && omm
          plot(real(x3),imag(x3),'g+')
         end
        end % if Del
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 4th iteration
   
   if kk == 4 || kk == 24 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om5 = 1 - 2 * om1(k) - om3(j) - om4(m);
       if om5 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om4(m), om5];
       omm = all(om) & all(om ~= 1);
       M = gm_momat([om1(k), om1(k), om3(j), om4(m), om5],lambda);
       M4 = M(1:4,1:4);
       % coefficients of the characteristic polynomial of H_4
       if rcond(M4) > 1e-16
        alpha = -M4 \ M(1:4,5);
        % roots of the quartic polynomial
        x = gm_quartique([1 alpha(4) alpha(3) alpha(2) alpha(1)]);
        x1 = x(1);
        x2 = x(2);
        x3 = x(3);
        x4 = x(4);
%         if (abs(imag(x1)) > 1e-10) && omm
%          plot(real(x1),imag(x1),'m+')
%         end
%         if (abs(imag(x2)) > 1e-10) && omm
%          plot(real(x2),imag(x2),'m+')
%         end
%         if (abs(imag(x3)) > 1e-10) && omm
%          plot(real(x3),imag(x3),'m+')
%         end
%         if (abs(imag(x4)) > 1e-10) && omm
%          plot(real(x4),imag(x4),'m+')
%         end
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'b+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'b+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'b+')
        end
        if (abs(imag(x4)) > 1e-10) && omm
         plot(real(x4),imag(x4),'b+')
        end
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
  end % if p
  
 case 6
  
  % n = 6
  
  [AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);
  
  if length(II) == 0
   fprintf('\n gm_loc_Ritz_values_direct: All the eigenvalues are real \n\n')
   return
  end
  
%   figure
  
  % field of values
  %gm_fvmod(A,1,32,1);
  hold on
  
  ii = sqrt(-1);
  u1 = 1;
  u2 = (-1 + ii * sqrt(3)) / 2;
  u3 = (-1 - ii * sqrt(3)) / 2;
  
  if p == 3
   
   % 3 pairs of complex eigenvalues
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1/2,npt);
   
   % 2nd iteration
   
   if kk == 2 || kk == 23 || kk == 24 || kk == 25 || kk == 234 || kk == 235 || kk == 245 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = (1 - 2 * om1(k) - 2 * om3(j)) / 2;
      if om5 < 0
       break
      end
      % moment matrix
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5, om5],lambda);
      M2 = M(1:2,1:2);
      % coefficients of the characteristic polynomial of H_2
      if rcond(M2) > 1e-16
       alpha = -M2 \ M(1:2,3);
       % roots of the quadratic polynomial
       Del = alpha(2)^2 - 4 * alpha(1);
       if Del < 0
        teta = (-alpha(2) + sqrt(Del)) / 2;
        if imag(teta) > 0
        plot(real(teta),imag(teta),'b+')
        plot(real(teta),-imag(teta),'r+')
        else
         plot(real(teta),imag(teta),'r+')
         plot(real(teta),-imag(teta),'b+')
        end % if
       end % if
      end % if
      
      %    end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 35 || kk == 234 || kk == 245 || kk == 345 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = (1 - 2 * om1(k) - 2 * om3(j)) / 2;
      if om5 < 0
       break
      end
      
      % moment matrix
      om = [om1(k), om1(k), om3(j), om3(j), om5, om5];
%       omm = all(om) & all(om ~= 1);
      omm = 1;
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5, om5],lambda);
      M3 = M(1:3,1:3);
      % coefficients of the characteristic polynomial of H_3
      if rcond(M3) > 1e-16
       alpha = -M3 \ M(1:3,4);
       a = 1;
       b = alpha(3);
       c = alpha(2);
       d = alpha(1);
       % roots of the cubic polynomial
       Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
       if Del < 0
        D0 = b^2 - 3 * a * c;
        D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
        C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
        x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
        x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
        x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
        %         if (abs(imag(x1)) > 1e-10) && omm
        %          plot(real(x1),imag(x1),'g+')
        %         end
        %         if (abs(imag(x2)) > 1e-10) && omm
        %          plot(real(x2),imag(x2),'g+')
        %         end
        %         if (abs(imag(x3)) > 1e-10) && omm
        %          plot(real(x3),imag(x3),'g+')
        %         end
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'b+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'b+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'b+')
        end
       end % if Del
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
   % 4th iteration
   
   if kk == 4 || kk == 24 || kk == 34 || kk == 45 || kk == 234 || kk == 245 || kk == 345 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = (1 - 2 * om1(k) - 2 * om3(j)) / 2;
      if om5 < 0
       break
      end
      
      % moment matrix
      om = [om1(k), om1(k), om3(j), om3(j), om5, om5];
      omm = all(om) & all(om ~= 1);
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5, om5],lambda);
      M4 = M(1:4,1:4);
      % coefficients of the characteristic polynomial of H_4
      if rcond(M4) > 1e-16
       alpha = -M4 \ M(1:4,5);
       % roots of the quartic polynomial
       x = gm_quartique([1 alpha(4) alpha(3) alpha(2) alpha(1)]);
       x1 = x(1);
       x2 = x(2);
       x3 = x(3);
       x4 = x(4);
%        if (abs(imag(x1)) > 1e-10) && omm
%         plot(real(x1),imag(x1),'m+')
%        end
%        if (abs(imag(x2)) > 1e-10) && omm
%         plot(real(x2),imag(x2),'m+')
%        end
%        if (abs(imag(x3)) > 1e-10) && omm
%         plot(real(x3),imag(x3),'m+')
%        end
%        if (abs(imag(x4)) > 1e-10) && omm
%         plot(real(x4),imag(x4),'m+')
%        end
       if (abs(imag(x1)) > 1e-10) && omm
        plot(real(x1),imag(x1),'b+')
       end
       if (abs(imag(x2)) > 1e-10) && omm
        plot(real(x2),imag(x2),'b+')
       end
       if (abs(imag(x3)) > 1e-10) && omm
        plot(real(x3),imag(x3),'b+')
       end
       if (abs(imag(x4)) > 1e-10) && omm
        plot(real(x4),imag(x4),'b+')
       end
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
    % 5th iteration
   
   if kk == 5 || kk == 25 || kk == 35 || kk == 45 || kk == 235 || kk == 245 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      
      om5 = (1 - 2 * om1(k) - 2 * om3(j)) / 2;
      if om5 < 0
       break
      end
      
      % moment matrix
      om = [om1(k), om1(k), om3(j), om3(j), om5, om5];
      omm = all(om) & all(om ~= 1);
      M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5, om5],lambda);
      M5 = M(1:5,1:5);
      % coefficients of the characteristic polynomial of H_5
      if rcond(M5) > 1e-16
       alpha = -M5 \ M(1:5,6);
       % roots of the quartic polynomial
       pol = [1; alpha(5:-1:1)];
       x = roots(pol);
       x1 = x(1);
       x2 = x(2);
       x3 = x(3);
       x4 = x(4);
       x5 = x(5);
%        if (abs(imag(x1)) > 1e-10) && omm
%         plot(real(x1),imag(x1),'c+')
%        end
%        if (abs(imag(x2)) > 1e-10) && omm
%         plot(real(x2),imag(x2),'c+')
%        end
%        if (abs(imag(x3)) > 1e-10) && omm
%         plot(real(x3),imag(x3),'c+')
%        end
%        if (abs(imag(x4)) > 1e-10) && omm
%         plot(real(x4),imag(x4),'c+')
%        end
%        if (abs(imag(x5)) > 1e-10) && omm
%         plot(real(x5),imag(x4),'c+')
%        end
       if (abs(imag(x1)) > 1e-10) && omm
        plot(real(x1),imag(x1),'b+')
       end
       if (abs(imag(x2)) > 1e-10) && omm
        plot(real(x2),imag(x2),'b+')
       end
       if (abs(imag(x3)) > 1e-10) && omm
        plot(real(x3),imag(x3),'b+')
       end
       if (abs(imag(x4)) > 1e-10) && omm
        plot(real(x4),imag(x4),'b+')
       end
       if (abs(imag(x5)) > 1e-10) && omm
        plot(real(x5),imag(x5),'b+')
       end
      end % if
      
     end % for j
    end % for k
    
   end % if kk
   
  end % if p
  
  if p == 2
   
   % 2 pairs of complex eigenvalues, 2 real
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1/2,npt);
   om5 = linspace(0,1,npt);
   
   % 2nd iteration
   
   if kk == 2 || kk == 23 || kk == 24 || kk == 25 || kk == 234 || kk == 235 || kk == 245 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om6 = 1 - 2 * om1(k) - 2 * om3(j) - om5(m);
       if om6 < 0
        break
       end
       % moment matrix
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om6],lambda);
       M2 = M(1:2,1:2);
       % coefficients of the characteristic polynomial of H_2
       if rcond(M2) > 1e-16
        alpha = -M2 \ M(1:2,3);
        % roots of the quadratic polynomial
        Del = alpha(2)^2 - 4 * alpha(1);
        if Del < 0
         teta = (-alpha(2) + sqrt(Del)) / 2;
         if imag(teta) > 0
          plot(real(teta),imag(teta),'b+')
          plot(real(teta),-imag(teta),'r+')
         else
          plot(real(teta),imag(teta),'r+')
          plot(real(teta),-imag(teta),'b+')
         end % if
        end % if
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 35 || kk == 234 || kk == 235 || kk == 345 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om6 = 1 - 2 * om1(k) - 2 * om3(j) - om5(m);
       if om6 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om3(j), om5(m), om6];
%        omm = all(om) & all(om ~= 1);
       omm = 1;
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om6],lambda);
       M3 = M(1:3,1:3);
       % coefficients of the characteristic polynomial of H_3
       if rcond(M3) > 1e-16
        alpha = -M3 \ M(1:3,4);
        a = 1;
        b = alpha(3);
        c = alpha(2);
        d = alpha(1);
        % roots of the cubic polynomial
        Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
        if Del < 0
         D0 = b^2 - 3 * a * c;
         D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
         C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
         x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
         x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
         x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
%          if (abs(imag(x1)) > 1e-10) && omm
%           plot(real(x1),imag(x1),'g+')
%          end
%          if (abs(imag(x2)) > 1e-10) && omm
%           plot(real(x2),imag(x2),'g+')
%          end
%          if (abs(imag(x3)) > 1e-10) && omm
%           plot(real(x3),imag(x3),'g+')
%          end
         if (abs(imag(x1)) > 1e-10) && omm
          plot(real(x1),imag(x1),'b+')
         end
         if (abs(imag(x2)) > 1e-10) && omm
          plot(real(x2),imag(x2),'b+')
         end
         if (abs(imag(x3)) > 1e-10) && omm
          plot(real(x3),imag(x3),'b+')
         end
        end % if Del
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 4th iteration
   
   if kk == 4 || kk == 24 || kk == 25 || kk == 34 || kk == 35 || kk == 234 || kk == 235 || kk == 245 || kk == 345 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om6 = 1 - 2 * om1(k) - 2 * om3(j) - om5(m);
       if om6 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om3(j), om5(m), om6];
       omm = all(om) & all(om ~= 1);
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om6],lambda);
       M4 = M(1:4,1:4);
       % coefficients of the characteristic polynomial of H_4
       if rcond(M4) > 1e-16
        alpha = -M4 \ M(1:4,5);
        % roots of the quartic polynomial
        x = gm_quartique([1 alpha(4) alpha(3) alpha(2) alpha(1)]);
        x1 = x(1);
        x2 = x(2);
        x3 = x(3);
        x4 = x(4);
%         if (abs(imag(x1)) > 1e-10) && omm
%          plot(real(x1),imag(x1),'m+')
%         end
%         if (abs(imag(x2)) > 1e-10) && omm
%          plot(real(x2),imag(x2),'m+')
%         end
%         if (abs(imag(x3)) > 1e-10) && omm
%          plot(real(x3),imag(x3),'m+')
%         end
%         if (abs(imag(x4)) > 1e-10) && omm
%          plot(real(x4),imag(x4),'m+')
%         end
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'b+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'b+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'b+')
        end
        if (abs(imag(x4)) > 1e-10) && omm
         plot(real(x4),imag(x4),'b+')
        end
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 5th iteration
   
   if kk == 5 || kk == 25 || kk == 35 || kk == 45 || kk == 235 || kk == 245 || kk == 2345
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om6 = 1 - 2 * om1(k) - 2 * om3(j) - om5(m);
       if om6 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om3(j), om5(m), om6];
       omm = all(om) & all(om ~= 1);
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om6],lambda);
       M5 = M(1:5,1:5);
       % coefficients of the characteristic polynomial of H_5
       if rcond(M5) > 1e-16
        alpha = -M5 \ M(1:5,6);
        % roots of the quartic polynomial
        pol = [1; alpha(5:-1:1)];
        x = roots(pol);
        x1 = x(1);
        x2 = x(2);
        x3 = x(3);
        x4 = x(4);
        x5 = x(5);
        %        if (abs(imag(x1)) > 1e-10) && omm
        %         plot(real(x1),imag(x1),'c+')
        %        end
        %        if (abs(imag(x2)) > 1e-10) && omm
        %         plot(real(x2),imag(x2),'c+')
        %        end
        %        if (abs(imag(x3)) > 1e-10) && omm
        %         plot(real(x3),imag(x3),'c+')
        %        end
        %        if (abs(imag(x4)) > 1e-10) && omm
        %         plot(real(x4),imag(x4),'c+')
        %        end
        %        if (abs(imag(x5)) > 1e-10) && omm
        %         plot(real(x5),imag(x4),'c+')
        %        end
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'b+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'b+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'b+')
        end
        if (abs(imag(x4)) > 1e-10) && omm
         plot(real(x4),imag(x4),'b+')
        end
        if (abs(imag(x5)) > 1e-10) && omm
         plot(real(x5),imag(x5),'b+')
        end
       end % if
       
      end % for m
      
     end % for j
    end % for k
    
   end % if kk
   
  end % if p
  
  if p == 1 || p == 0
   error('gm_loc_Ritz_values_direct: The cases p = 1 and p = 0 are not handled')
  end
  
 case 7
  
  % n = 7
  
  [AA,lambda,X,img,p,II,IR] = gm_put_imag_first(A);
  
  if length(II) == 0
   fprintf('\n gm_loc_Ritz_values_direct: All the eigenvalues are real \n\n')
   return
  end
  
%   figure
  
  % field of values
  %gm_fvmod(A,1,32,1);
  hold on
  
  ii = sqrt(-1);
  u1 = 1;
  u2 = (-1 + ii * sqrt(3)) / 2;
  u3 = (-1 - ii * sqrt(3)) / 2;
  
  if p == 3
   
   % 3 pairs of complex eigenvalues, 1 real
   
   om1 = linspace(0,1/2,npt);
   om3 = linspace(0,1/2,npt);
   om5 = linspace(0,1/2,npt);
   
   % 2nd iteration
   
   if kk == 2 || kk == 23 || kk == 24 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om7 = 1 - 2 * om1(k) - 2 * om3(j) - 2 * om5(m);
       if om7 < 0
        break
       end
       % moment matrix
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om5(m), om7],lambda);
       M2 = M(1:2,1:2);
       % coefficients of the characteristic polynomial of H_2
       if rcond(M2) > 1e-16
        alpha = -M2 \ M(1:2,3);
        % roots of the quadratic polynomial
        Del = alpha(2)^2 - 4 * alpha(1);
        if Del < 0
         teta = (-alpha(2) + sqrt(Del)) / 2;
         plot(real(teta),imag(teta),'b+')
         plot(real(teta),-imag(teta),'b+')
        end % if
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 3rd iteration
   
   if kk == 3 || kk == 23 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om7 = 1 - 2 * om1(k) - 2 * om3(j) - 2 * om5(m);
       if om7 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om3(j), om5(m), om5(m), om7];
%        omm = all(om) & all(om ~= 1);
       omm = 1;
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om5(m), om7],lambda);
       M3 = M(1:3,1:3);
       % coefficients of the characteristic polynomial of H_3
       if rcond(M3) > 1e-16
        alpha = -M3 \ M(1:3,4);
        a = 1;
        b = alpha(3);
        c = alpha(2);
        d = alpha(1);
        % roots of the cubic polynomial
        Del = 18 * a * b * c * d - 4 * b^3 * d + b^2 * c^2 - 4 * a * c^3 - 27 * a^2 * d^2;
        if Del < 0
         D0 = b^2 - 3 * a * c;
         D1 = 2 * b^3 - 9 * a * b * c + 27 * a^2 * d;
         C = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
         x1 = -(b + u1 * C + D0 / (u1 * C)) / (3 * a);
         x2 = -(b + u2 * C + D0 / (u2 * C)) / (3 * a);
         x3 = -(b + u3 * C + D0 / (u3 * C)) / (3 * a);
         if (abs(imag(x1)) > 1e-10) && omm
          plot(real(x1),imag(x1),'g+')
         end
         if (abs(imag(x2)) > 1e-10) && omm
          plot(real(x2),imag(x2),'g+')
         end
         if (abs(imag(x3)) > 1e-10) && omm
          plot(real(x3),imag(x3),'g+')
         end
        end % if Del
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
   % 4th iteration
   
   if kk == 4 || kk == 24 || kk == 34 || kk == 234
    
    for k = 1:npt
     for j = 1:npt
      for m = 1:npt
       
       om7 = 1 - 2 * om1(k) - 2 * om3(j) - 2 * om5(m);
       if om7 < 0
        break
       end
       
       % moment matrix
       om = [om1(k), om1(k), om3(j), om3(j), om5(m), om5(m), om7];
       omm = all(om) & all(om ~= 1);
       M = gm_momat([om1(k), om1(k), om3(j), om3(j), om5(m), om5(m), om7],lambda);
       M4 = M(1:4,1:4);
       % coefficients of the characteristic polynomial of H_4
       if rcond(M4) > 1e-16
        alpha = -M4 \ M(1:4,5);
        % roots of the quartic polynomial
        x = gm_quartique([1 alpha(4) alpha(3) alpha(2) alpha(1)]);
        x1 = x(1);
        x2 = x(2);
        x3 = x(3);
        x4 = x(4);
        if (abs(imag(x1)) > 1e-10) && omm
         plot(real(x1),imag(x1),'m+')
        end
        if (abs(imag(x2)) > 1e-10) && omm
         plot(real(x2),imag(x2),'m+')
        end
        if (abs(imag(x3)) > 1e-10) && omm
         plot(real(x3),imag(x3),'m+')
        end
        if (abs(imag(x4)) > 1e-10) && omm
         plot(real(x4),imag(x4),'m+')
        end
       end % if
       
      end % for m
     end % for j
    end % for k
    
   end % if kk
   
  end % if p
  
  if p == 2 || p == 1 || p == 0
   error('gm_loc_Ritz_values_direct: The cases p = 0, p = 1 and p = 2 are not handled')
  end
  
end % switch n

if nargin <= 2
 hold off
 return
end

% if strcmpi(bnd,'bndry') == 1
%  gm_plot_boundary_real_k2b(A);
% end

hold off

warning on;


