function [CC,CR,rhsC,rhsR]=gm_C_matrix_gen(A,theta);
%GM_C_MATRIX_GEN builds the matrix and rhs for omega for k Ritz values

% Input:
% A = normal matrix
% theta = the Ritz values
%
% Output:
% CC = complex matrix and CR the real equivalent
% rhsC, rhsR = right-hand sides

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

lambda = transpose(eig(A));

n = size(A,1);
k = length(theta);
if k > n-1
 error('gm_C_matrix_gen: There are too many Ritz values, max: n-1')
end

CC = zeros(k+1,n);
rhsC = zeros(k+1,1);
CR = zeros(2*k+1,n);
rhsR = zeros(2*k+1,1);

% get the coefficients of the characteristic polynomial
% from the given Ritz values
% bet contains beta_0, beta_1,...,beta_{k-1}

bet = poly(theta);
bet = bet(k+1:-1:2);

CC(1,:) = ones(1,n);

ind = [1:k-1];
for m = 1:n
 CC(2,m) = sum(bet(2:k) .* lambda(m).^ind) + lambda(m)^k;
end % for m

for l = 3:k+1
 for m = 1:n
  CC(l,m) = conj(lambda(m))^(l-2) * (bet(1) + sum(bet(2:k) .* lambda(m).^ind) + lambda(m)^k);
 end % for m
end % for l

rhsC(1) = 1;
rhsC(2) = -bet(1);

CR(1,:) = ones(1,n);

j = 2;
for l = 2:k+1
 CR(j,:) = real(CC(l,:));
 CR(j+1,:) = imag(CC(l,:));
 j = j + 2;
end % for l

rhsR(1) = 1;
rhsR(2) = -real(bet(1));
rhsR(3) = -imag(bet(1));




