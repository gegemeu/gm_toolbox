function gm_find_v_gen_realb(lambda,nptx,npty,xmin,xmax,ymin,ymax);
%GM_FIND_V_GEN_REALB locations of Ritz values for k = 2

%  We set up a mesh on the FOV and check the feasibility

% Input:
% lambda = eigenvalues of A
% nptx, npty = number of discretization points in the x and y directions
% xmin,xmax,ymin,ymax = bounds of the field of values

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

% rand('state',0)
% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setDefaultStream(s);

n = length(lambda);

x = linspace(xmin,xmax,nptx);
y = linspace(0,ymax,npty);

for kk = 1:2
 % kk = 1 complex pairs, kk = 2 real Ritz values
 
 for ii = 1:length(x)
  for jj = 1:length(y)
   
   flag = 0;
   
   if kk == 1
    theta = [x(ii) + y(jj) * i, x(ii) - y(jj) * i];
   else
    theta = [x(ii), x(jj)];
   end
   
   % build the matrix CR and the rhs
   
   [CR,rhsR] = gm_C_matrix_gen_realb(lambda,theta);
   
   k = size(CR,1);
   np = size(CR,2);
   
   if k >= np
    % we have an overdetermined (or square) system
    % check if the system is consistent and the solution > 0
    flag = 0;
    om = CR \ rhsR;
    res = norm(rhsR - CR * om) / norm (om);
    % ****************************************this test is very sensitive!!!
    if res < 1e-4
     flag = 1;
     for jjj = 1:length(om)
      if (om(jjj) < 0)
       flag = 0;
      end
     end % for jjj
    end % if res
    
   else
    
    % case of an underdetermined system
    
    % SVD of CR
    
    [U,S,V] = svd(CR);
    
    r = size(S,1);
    
    % construct the system to get a positive solution (if any)
    
    D = S(1:r,1:r);
    V1 = V(:,1:r);
    V2 = V(:,r+1:end);
    
    % partial solution for CR
    
    yy = D \ (U' * rhsR);
    
    V1y = V1 * yy;
    
    % inequality for the solution to be positive
    
    [flag,zz] = gm_check_ineq(-V2,V1y);
        
   end % if
   
   if (flag == 1) && (kk == 1)
    plot(x(ii),y(jj),'b+')
    plot(x(ii),-y(jj),'r+')
    if ii == 1 && jj == 1
     hold on
    end % if ii
   end % if flag
   if (flag == 1) && (kk == 2)
    plot(x(ii),0,'b+')
    plot(x(jj),0,'r+')
   end % if flag
   
  end % for jj
 end % for ii
 
end % for kk

hold off







