function gm_random_Ritzval_allk(A,nsamp,bnd);
%GM_RANDOM_RITZVAL_ALLK Ritz values at all Arnoldi iterations for random rhs
% Arnoldi started with real random vectors

% Input:
% A = matrix
% nsamp = number of random rhs
% k = iteration number
% bnd = 'bndry' plots the boundary for k = 2

%
% Author G. Meurant
% January 2013
% Updated Sept 2015
%

n = size(A,1);

figure

% field of values
gm_fvmod(A,1,32,1);
hold on

for ii = 1:n-1
 
 for k = 1:nsamp
  v = randn(n,1);
  v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,v,ii,'noreorth','noprint');
  
  Hii = H(1:ii,1:ii);
  eigHii = eig(full(Hii));
  
  for j = 1:ii
   if isreal(eigHii(j))
    plot(eigHii(j),0,'g+')
   else
    if imag(eigHii(j)) > 0
     plot(real(eigHii(j)),imag(eigHii(j)),'b+')
    else
     plot(real(eigHii(j)),imag(eigHii(j)),'r+')
    end % if imag
   end % if isreal
  end % for j
  
 end % for k
 
end % for ii

if nargin <= 2
 hold off
 return
end

% This is useful only if A is real and normal
if strcmpi(bnd,'bndry') == 1
 gm_plot_boundary_real_k2b(A);
end

hold off


