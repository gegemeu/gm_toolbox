function gm_random_Ritzval_allk(A,nsamp);
%GM_RANDOM_RITZVAL_ALLK Ritz values at all Arnoldi iterations for random rhs

% Arnoldi started with real random vectors

% Input:
% A = matrix
% nsamp = number of random rhs

%
% Author G. Meurant
% January 2013
% Updated September 2015
%

n = size(A,1);

figure

% field of values
gm_fvmod(A,1,32,0);
hold on

for ii = 1:n-1
 
 for k = 1:nsamp
  v = randn(n,1);
  v = v / norm(v);
 
 % Arnoldi 
 [VV,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,v,ii,'noreorth','noprint');
  
  Hii = H(1:ii,1:ii);
  eigHii = eig(full(Hii));
  
  for j = 1:ii
   if isreal(eigHii(j))
    plot(eigHii(j),0,'g+')
   else
    if imag(eigHii(j)) > 0
     plot(real(eigHii(j)),imag(eigHii(j)),'b+')
    else
     plot(real(eigHii(j)),imag(eigHii(j)),'r+')
    end % if imag
   end % if isreal
  end % for j
  
 end % for k
 
end % for ii

if nargin <= 2
 hold off
 return
end

hold off


