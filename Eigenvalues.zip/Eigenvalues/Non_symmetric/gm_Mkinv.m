function Mkinv=gm_Mkinv(A,v,k,X,D);
%GM_MKINV formula for the inverse of the moment matrix M_k for any n for a normal matrix A

% formula from the eigenvalues and the projections of v on eigenvectors

% Caution: This is costly! A hs to be small

% Input:
% A = normal matrix
% v = starting vector
% k = iteration number
% X = eigenvector of A
% D = eigenvalues of A
%
% Output:
% Mkinv = inverse of M_k

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

n = size(A,1);
Ik = gm_all_combi(n,k);
sIk = size(Ik,1);
Ikm1 = gm_all_combi(n,k-1);
sIkm1 = size(Ikm1,1);
v = v / norm(v);

if k == 1
 Mkinv = 1;
 return
end % if 

if nargin < 4
 [X,D] = eig(full(A));
end
lamb = diag(D);
c = X' * v;
om = abs(c).^2;

% determinant of M_k
pom = zeros(sIk,1);
diff = zeros(sIk,1);
for j = 1:sIk
 pom(j) = prod(om(Ik(j,:)));
 diff(j) = gm_cumprod_diffs2(lamb(Ik(j,:)));
end % for j

dk = sum(pom .* diff);

Mkinv = zeros(k,k);

pom = zeros(sIkm1,1);
diff = zeros(sIkm1,1);
em = zeros(sIkm1,1);
el = zeros(sIkm1,1);
for j = 1:sIkm1
 pom(j) = prod(om(Ikm1(j,:)));
 diff(j) = gm_cumprod_diffs2(lamb(Ikm1(j,:)));
end % for j

for l = 1:k
 for m = 1:k
  % elementary symmetric functions
  for j = 1:sIkm1
   em(j) = gm_elem_symm_func(lamb(Ikm1(j,:)),k-m);
   el(j) = gm_elem_symm_func(lamb(Ikm1(j,:)),k-l);
  end % for j
  Mkinv(l,m) = (-1)^(l+m) * sum(pom .* diff .* conj(em) .* el) / dk;
 end % for m
end % for l

if isreal(A)
 Mkinv = real(Mkinv);
end



