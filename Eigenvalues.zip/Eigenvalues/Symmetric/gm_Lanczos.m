function [V,T,VTs,Rvals,Rvec,res,time_mat]=gm_Lanczos(A,u,nitmax,prints);
%GM_LANCZOS Lanczos iteration for a matrix A 
% coded as suggested by C. Paige

%
% Input:
% A = symmetric matrix
% u = starting vector
% nitmax = number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% prints = 'print' prints number of matrix-vector products and dot products
%
% Output:
% V = Lanczos vectors
% T = tridiagonal matrix
% VTs = sorted eigenvectors of T
% Rvals = sorted eigenvalues of T
% Rvec = Ritz vectors
% res = residual norms || (A-theta I)x ||
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products 
%  otherwise same without the first two items

%
% Author G. Meurant
% July 2015
%

n = size(A,1);

timing = 0;
if nargin < 3
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end
if strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 iprint = 2;
 tic
end

u = u / norm(u);
v = u;

dotprod = 0;
matvec = 0;
T = sparse(nitmax+1,nitmax+1);
V = zeros(n,nitmax+2);
V(:,1) = v;
v1 = v;

u = A * v;
matvec = matvec + 1;
om = v' * u;
dotprod = dotprod + 1;
T(1,1) = om;
r = u - om * v;
gam = norm(r);
dotprod = dotprod + 1;

v = r / gam;
V(:,2) = v;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

%-----------------------------------Iterations

for k = 2:nitmax+1
 T(k,k-1) = gam;
 T(k-1,k) = gam;
 
 u = A * v - gam * v1;
 matvec = matvec + 1;
 
 om = v' * u;
 dotprod = dotprod + 1;
 T(k,k) = om;
 
 r = u - om * v;
 
 gam = norm(r);
 dotprod = dotprod + 1;
 if gam == 0
  break
 end % if gam
 
 v1 = v;
 v = r / gam;
 V(:,k+1) = v;
 
end % for k

% eigenvalues and eigenvectors of T
[vt,dt] = eig(full(T(1:nitmax+1,1:nitmax+1)));

% sort the eigenvalues
[Rvals,ii] = sort(diag(dt));

% and the eigenvectors
VTs = vt(:,ii);

% approx of eigenvectors
Rvec = V(:,1:nitmax+1) * VTs;

T = T(1:nitmax+1,1:nitmax+1);
V = V(:,1:nitmax+2);

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod);
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod);
end % if timing

if iprint == 1
 fprintf('\n Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nitmax)
end % if iprint

res = zeros(1,nitmax);
for k = 1:nitmax
 res(k) = norm(A * Rvec(:,k) - Rvals(k) * Rvec(:,k));
end

if iprint == 1
 [minres,I] = min(res);
 [maxres,J] = max(res);
 fprintf('\n Min residual = %g for i = %g \n',minres,I(1))
 fprintf('\n Max residual = %g for i = %g \n\n',maxres,J(1))
end


