function gm_Ex_Lanczos(n,nitmax);
%GM_EX_LANCZOS Example of Lanczos iterations

% Input:
% n = order of the Strakos matrix
% nitmax = maximum number of iterations

%
% Author G. Meurant
% Sept 2015
%

aa = 0.1;
bb = 100;
rho = 0.9;
% rho = 0.7;

A = gm_mat_strakos(n,aa,bb,rho);
v = randn(n,1);
v = v / norm(v);

[V,T,VTs,Rvals,Rvec,res,time_mat] = gm_Lanczos(A,v,nitmax,'noprint');

gm_plot_Ritz_Lanczos(A,T,'noprint','eigA');

