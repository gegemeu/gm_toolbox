
% EXAMPLES OF SYMMETRIC EIGENVAUE PROBLEMS
%
% Files
%   gm_Ex_Lanczos - Example of Lanczos iterations (Strakos matrix)
