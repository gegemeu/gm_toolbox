function [Rmin,Rmax]=gm_Rminmax_Lanczos(A,u,nitmax);
%GM_RMINMAX_LANCZOS computes of the minimum and maximum of the Ritz values
%

%
% Author G. Meurant
% July 2015
%

Rmin = zeros(1,nitmax);
Rmax = zeros(1,nitmax);

[V,T,VTs,Rvals,Rvec,res,time_mat] = gm_Lanczdor(A,u,nitmax,'noprint');

for k = 1:nitmax
  vp = eig(full(T(1:k,1:k)));
  Rmin(k) = min(vp);
  Rmax(k) = max(vp);
end % for k



