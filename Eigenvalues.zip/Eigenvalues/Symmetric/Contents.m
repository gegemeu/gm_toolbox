
% SYMMETRIC EIGENVALUE PROBLEMS
%
% Files
%   gm_divide_conquer    - computation of eigenvalues of a symmetric tridiagonal matrix, divide and conquer method
%   gm_eig_dqds          - computation of eigenvalues of a symmetric tridiagonal matrix with dqds
%   gm_eigLanczos        - Lanczos iteration for a matrix A (eigenvalues and tridiagonal matrix)
%   gm_Lanczdor          - Lanczos iteration for a matrix A with double full reorthogonalization
%   gm_Lanczos           - Lanczos iteration for a matrix A 
%   gm_plot_Ritz_Lanczos - plots all the Ritz values arising from the Lanczos process
%   gm_Rminmax_Lanczos   - computes of the minimum and maximum of the Ritz values
