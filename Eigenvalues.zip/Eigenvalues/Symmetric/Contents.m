% SYMMETRIC
%
% functions for computing eigenvalues of symmetric matrices
%
% Files
%   gm_B_Lanczos         - block Lanczos algorithm
%   gm_divide_conquer    - eigenvalues of a symmetric tridiagonal matrix, divide and conquer method
%   gm_eig_dqds          - eigenvalues of a symmetric tridiagonal matrix with dqds
%   gm_eigLanczos        - Lanczos iteration for a matrix A coded as suggested by C. Paige
%   gm_Lanczdor          - Lanczos iteration for a matrix A with double full reorthogonalization
%   gm_Lanczos           - Lanczos iteration for a matrix A 
%   gm_plot_Ritz_Lanczos - plots all the Ritz values arising from the Lanczos process
%   gm_Rminmax_Lanczos   - computes of the minimum and maximum of the Ritz values
