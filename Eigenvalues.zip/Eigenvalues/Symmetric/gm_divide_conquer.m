function [lambda,q1,qn] = gm_divide_conquer(a,b);
%GM_DIVIDE_CONQUER eigenvalues of a symmetric tridiagonal matrix, divide and conquer method

% T = (b, a, b)

% Input:
% a = diagonal of T
% b = subdiagonal of T
% 
% Output:
% lambda = eigenvalues of T
% q1 (resp. qn) = first (resp. last) row of the eigenvectors
%

%
% Author G. Meurant
% May 2012
% Updated September 2015
%

n = length(a);

if n == 1
 lambda = a(1);
 q1 = 1;
 qn = 1;
 return
end % if n

if n == 2
 J = [a(1) b(1); b(1) a(2)];
 [Q,D] = eig(J);
 [lambda,ind] = sort(diag(D));
 Q = Q(:,ind);
 q1 = Q(1,:);
 qn = Q(2,:);
 return
end % if n

if n == 3
 J = [a(1) b(1) 0; b(1) a(2) b(2); 0 b(2) a(3)];
 [Q,D] = eig(J);
 [lambda,ind] = sort(diag(D));
 Q = Q(:,ind);
 q1 = Q(1,:);
 qn = Q(3,:);
 return
end % if n

if n <= 5
 J = diag(a) + diag(b(1:n-1),1) + diag(b(1:n-1),-1);
 [Q,D] = eig(J);
 [lambda,ind] = sort(diag(D));
 Q = Q(:,ind);
 q1 = Q(1,:);
 qn = Q(n,:);
 return
end % if n

% general case, divide T in 2 pieces
m = fix(n / 2);

af = a(1:m);
al = a(m+1:n);
if b(m) > 0
 rho = -b(m);
 sig = -1;
 af(m) = a(m) + b(m);
 al(1) = a(m+1) + b(m);
else
 rho = b(m);
 sig = 1;
 af(m) = a(m) - b(m);
 al(1) = a(m+1) - b(m);
end % if b

% recursive algorithm

[lambdaf,qf1,qfn] = gm_divide_conquer(af,b(1:m-1));

if m+1 > length(b)
 bm = [];
else
 bm = b(m+1:end);
end % if m+1

[lambdal,ql1,qln] = gm_divide_conquer(al,bm);

% solve the secular equation 

d = [lambdaf; lambdal];
D = diag(d);
v = [sig * qfn'; ql1'];

DD = D + rho * (v * v');
[Q,Dlambda] = eig(DD);
[lambda,ind] = sort(diag(Dlambda));
Q = Q(:,ind);
xf = lambda';

[d,ind] = sort(d);
indp(ind) = [1:n];
v = v(ind);
% [xf,iterd] = solve_secul_divconq(d,rho,v);

% compute the eigenvectors

vh = zeros(n,1);
for k = 1:n
 vh(k) = sign(v(k)) * sqrt((prod(d(k) - xf(1:k-1)) * prod(xf(k:n) - d(k))) / ...
  (rho * prod(d(k) - d(1:k-1)) * prod(d(k+1:n) - d(k))));
end % for k
v = vh;

QQ = zeros(n,n);
for k = 1:n
 vv = v ./ (xf(k) - d);
 vv = vv / norm(vv);
 vv = vv(indp);
 QQ(:,k) = vv;
end % for k

lambda = xf';

q1 = qf1 * QQ(1:length(qf1),:);
qn = qln * QQ(n-length(qln)+1:n,:);






