function [V,T] = gm_B_Lanczos(A,V0,nitmax);
%GM_B_LANCZOS block Lanczos algorithm

% Input:
% A = symmetric positive definite matrix 
% V0 = initial block vector n x m
% nitmax = maximum number of iterations
%
% Output:
% V = collection of block vectors
% T = block tridiagonal matrix

%
% Author G. Meurant
% July 2024
%

n = size(A,1);
m = size(V0,2);

if m == 1
 [V,T] = gm_Lanczos(A,V0,nitmax,'noprint');
 return
end % if

mnit = m * nitmax;
V = zeros(n,mnit);
T = zeros(mnit+m,mnit+m);
idiag = [0:nitmax-1] * m + 1; % start of each diagonal block
isub = idiag(2:nitmax); % start row of each subdiagonal block
jsub = idiag(1:nitmax-1); % start column of each subdiagonal block
isup = idiag(1:nitmax-1); % start row of each updiagonal block
jsup = idiag(2:nitmax); % start column of each updiagonal block

Vold = zeros(n,m);
[Vnew,B] = gm_signqr(V0);
V(:,1:m) = Vnew;

for k = 2:nitmax
 W = A * Vnew - Vold * B';
 D = Vnew' * W;
 ind = idiag(k-1):idiag(k-1)+m-1;
 T(ind,ind) = D;
 W = W - Vnew * D;
 Vold = Vnew;
 [Vnew,B] = gm_signqr(W);
 V(:,idiag(k):idiag(k)+m-1) = Vnew;
 T(isub(k-1):isub(k-1)+m-1,jsub(k-1):jsub(k-1)+m-1) = B;
 T(isup(k-1):isup(k-1)+m-1,jsup(k-1):jsup(k-1)+m-1) = B';
end % for k

% last diagonal block
W = A * Vnew - Vold * B';
D = Vnew' * W;
ind = idiag(nitmax):idiag(nitmax)+m-1;
T(ind,ind) = D;

T = T(1:mnit,1:mnit);




 


