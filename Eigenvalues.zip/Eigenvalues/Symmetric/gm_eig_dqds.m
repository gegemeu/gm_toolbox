function [lambda,nit] = gm_eig_dqds(a,b);
%GM_EIG_DQDS eigenvalues of a symmetric tridiagonal matrix with dqds

% T = (b, a, b)

% Input:
% a = diagonal of T (vector)
% b = subdiagonal of T (vector)
% 
% Output:
% lambda = eigenvalues of T
% nit = number of iterations

%
% Author G. Meurant
% May 2012
% Updated September 2015
%

n = length(a);

b = b(:)';
if length(b) ~= n
 b = [b, 0];
end
a = a(:)';

% computation of the max norm
abb = abs(b(1:n-1));
apb = [abs(a(1:n-1)) + abb, abs(a(n))];
apb(2:n) = apb(2:n) + abb;
normJ = max(apb);

t = zeros(1,n);
q = zeros(1,n);

% relative zero tolerance
epss = eps * normJ;
m = n;

% initialize q and e from the Cholesky factorization
% without shift

b2 = b.^2;

q(1) = a(1);
for k = 2:n
 q(k) = a(k) - b2(k-1) / q(k-1);
end
e = b2 ./ q;
e(n) = 0;

inspect = 1;
nit = 0;
sigma = 0;

while inspect == 1 && nit < 20000
 
 nit = nit + 1;
 
 m1 = m-1;
 
 if m1 == 0
  t(1) = q(1) + sigma;
  % we are finished
  % sort the abscissas, compute the weights and return
  [t,ind] = sort(t);
  lambda = t';
  return
 end % if m1
 
 if abs(e(m1)) <= epss
  t(m) = q(m) + sigma;
  m  = m1;
  continue
 else
 end % if abs
 
 % find the shift with the eigenvalues of lower 2x2 block
 b2 = e(m1) * q(m);
 g = q(m1) + e(m1);
 det = sqrt((g-q(m))^2 + 4 * b2);
 aa = g + q(m);
 if aa > 0
  lambda2 = real((aa + det) / 2);
 else
  lambda2 = real((aa - det) / 2);
 end % if aa
 lambda1 = real((g * q(m) - b2) / lambda2);
 mu = max(lambda1,lambda2);
 
 if nit == 1
  mu = 0;
 end % if nloop
 
 sigma = sigma + mu;
 
 % one qd sweep
 
 d = q(1) - mu;
 for k = 1:m-1
  q(k) = d + e(k);
  f = q(k+1) / q(k);
  e(k) = f * e(k);
  d = f * d - mu;
 end % for k
 q(m) = d;
 
end % while

