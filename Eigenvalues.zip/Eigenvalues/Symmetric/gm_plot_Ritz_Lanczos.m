function vpA=gm_plot_Ritz_Lanczos(A,T,prints,eigAs);
%GM_PLOT_RITZ_LANCZOS plots all the Ritz values arising from the Lanczos process

% Input:
% A = matrix (only used if eigAs = 'eigA')
% T = tridiagonal matrix from the Lanczos algorithm
% prints = 'print', printing of convergence results
% eigAs = 'eigA', computation of the eigenvalues of A

% Output:
% if eigAs = 'eigA', vpA = eigenvalues of A
% otherwise vpA = []

%
% Author Gerard Meurant
% July 2015
%

% delete figures

set(0,'ShowHiddenHandles','on')
delete(get(0,'Children'))

if strcmpi(prints,'print') == 1
 iprint = 1;
else 
 iprint = 0;
end % if strcmpi
if strcmpi(eigAs,'eigA') == 1
 eigA = 1;
else 
 eigA = 0;
end % if strcmpi

n = size(T,1) + 1;

vpA = [];
if eigA == 1
 vpA = sort(eig(full(A)));
 vmin = min(vpA);
 vmax = max(vpA);
 dv = 0.1 * (vmax - vmin);
 plot(n,vpA(1),'r*');
 axis([0 n+2 vmin-dv vmax+dv]);
 hold on
 for i = 2:length(vpA)
  plot(n,vpA(i),'r*')
 end % for i
 title('Ritz values (blue) and eigenvalues (red)')
end % if eigA

nT = size(T,1);
lvtc = zeros(1,nT);
difvp = zeros(nT,nT);

for i = 1:nT
 if iprint == 1
  fprintf(' k = %g \n',i);
  fprintf('--------------------\n')
 end % if iprint
 vtc = sort(eig(full(T(1:i,1:i))));
 nvtc = length(vtc);
 lvtc(i) = nvtc;
 for j = 1:nvtc
  plot(i,vtc(j),'b*')
  hold on
  if eigA == 1
   [difvp(j,i),jj] = min(abs(vtc(j) - vpA));
   if difvp(j,i) < sqrt(eps/2)
    if iprint == 1
     fprintf(' conv Ritz value num = %g, diff = %g \n',jj,difvp(j,i));
    end
   end % if difvp
  end % if eigA
 end % for j
end % for i

if eigA == 0
 vmin = min(vtc);
 vmax = max(vtc);
 dv = 0.1 * (vmax - vmin);
 axis([0 n+2 vmin-dv vmax+dv]);
 title('Ritz values')
end % if eigA

hold off

if eigA == 1
 figure
 hold on
 for i = 1:size(T,1)
  for j = 1:lvtc(i)
   plot(i,log10(difvp(j,i)),'b*')
  end % for j
 end % for i
 title('Distances from Ritz values to eigenvalues')
 hold off
end % if eigA




