% SYMMETRIC

% The versions ending with a "T" compute the exact A-norm of the error for comparisons
%
% Files
%   flip_bit_fp64                 - flips a bit of a double precision word, needs the folder f_d_floatp
%   fp642bin                      - decompose a double precision floating point number
%   gm_augCG_prec                 - preconditioned augmented conjugate gradient for a matrix A with preconditioning
%   gm_bitflip_rand               - random bit bitflips in CG
%   gm_CG_3t_prec                 - preconditioned conjugate gradient for a matrix A with preconditioning 3-term recurrence
%   gm_CG_CG_prec                 - preconditioned conjugate gradient for a symmetric matrix A Chronopoulos and Gear parallel variant
%   gm_CG_err_Iceps               - preconditioned conjugate gradient for a matrix A + epss I with IC preconditioning
%   gm_CG_err_prec                - preconditioned conjugate gradient for a symmetric matrix A A-norm bounds (old version)
%   gm_CG_err_precT               - preconditioned conjugate gradient for a symmetric matrix A A-norm bounds (old version), exact error norm
%   gm_CG_err_trid_precT          - preconditioned conjugate gradient for a symmetric matrix A, A-norm estimates, tridiagonal matrix
%   gm_CG_errGR_adapt_prec        - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive Gauss-Radau
%   gm_CG_errGR_adapt_precT       - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive Gauss-Radau, exact erorr norm
%   gm_cg_errGR_adapt_MPT_precT   - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive choice of delay
%   gm_cg_errGR_adapt_MPT_precT   - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive choice of delay
%   gm_CG_errGR_adapt_VDV_prec    - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive Gauss-Radau, Van der Vorst improvement
%   gm_CG_errGR_impacc_prec       - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive Gauss-Radau, G.M. improvement
%   gm_CG_errGR_new2_precT        - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), backward error, exact error norm
%   gm_CG_errGR_new_prec          - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), backward error
%   gm_CG_errGR_new_precT         - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), backward error, exact error norm
%   gm_CG_errGR_newadapt2_precT   - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, adaptive values of mu and eta
%   gm_CG_errGR_newadapt4_precT   - preconditioned conjugate gradient for a matrix A with preconditioning, new A-norm bounds
%   gm_CG_errGR_newadapt_prec     - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), adaptive Gauss-Radau, backward error
%   gm_CG_errGR_newadapt_precT    - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), adaptive Gauss-Radau, backward error, exact error norm
%   gm_CG_errGR_newadapt_precT_BE - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), adaptive Gauss-Radau, backward error
%   gm_CG_errGR_prec              - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version)
%   gm_CG_errGR_precT             - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), exact error norm
%   gm_CG_errGR_precT_reconst     - preconditioned conjugate gradient for a matrix A with preconditioning, A-norm bounds with reconstruction of the estimates with all the values of delay
%   gm_CG_errGR_precT_vp          - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds, variable precision
%   gm_CG_errGR_reorth_precT      - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds with reorthogonalization
%   gm_CG_errGR_T                 - conjugate gradient for a matrix A without preconditioning A-norm bounds (new version), exact error norm
%   gm_CG_errGR_VDV_prec          - preconditioned conjugate gradient for a matrix A with preconditioning A-norm bounds (new version), Van der Vorst improvement
%   gm_CG_errl2_prec              - preconditioned conjugate gradient for a symmetric matrix A l2-norm estimates
%   gm_CG_errl2_precT             - preconditioned conjugate gradient for a symmetric matrix A l2-norm estimates, exact error norm
%   gm_CG_errorl2_bounds          - check of bounds for the l2 error norm
%   gm_CG_Lap                     - conjugate gradient for the Laplacian matrix without preconditioning
%   gm_CG_mflops                  - conjugate gradient without preconditioning, computes the Mflops rate
%   gm_CG_MP_prec                 - preconditioned conjugate gradient for a symmetric matrix A, Meurant's parallel variant
%   gm_CG_PC_prec_flip            - preconditioned conjugate gradient for a symmetric matrix A, predictor-corrector variant with bit flips and recovery
%   gm_CG_PC_prec_flip_detect     - preconditioned conjugate gradient for a symmetric matrix A, predictor-corrector variant with bit flips and recovery
%   gm_CG_PR_MP_prec              - preconditioned conjugate gradient for a symmetric matrix A, Meurant's pipelined parallel variant 
%   gm_CG_prec                    - preconditioned conjugate gradient for a symmetric matrix A 
%   gm_CG_prec_flip               - preconditioned conjugate gradient for a symmetric matrix A with bit flips and recovery
%   gm_CG_prec_flip_detect        - preconditioned conjugate gradient for a symmetric matrix A with bit flips and recovery
%   gm_CG_reorth_prec             - preconditioned conjugate gradient for a matrix A with preconditioning with reorthogonalization
%   gm_CG_reorth_precT            - preconditioned conjugate gradient for a matrix A with preconditioning with reorthogonalization
%   gm_CG_tr_prec                 - preconditioned conjugate gradient for a matrix A with preconditioning, uses the true residual
%   gm_CGstandvpT                 - standard conjugate gradient for a matrix A, variable precision
%   gm_CH_CG_prec                 - preconditioned conjugate gradient for a symmetric matrix A, Tyler Chen's parallel variant
%   gm_comp_gamma_presc_CG        - computes gamma satisfying the sufficient condition
%   gm_comp_res_presc_CG          - prescribed residual norms for CG
%   gm_CR_prec                    - preconditioned conjugate residual for a symmetric matrix A 
%   gm_delay                      - optimal delay to obtain a relative error on the estimates
%   gm_error_delay                - relative error on the estimates
%   gm_g_from_T                   - computes the first row of inv(U) from tridiagonal T
%   gm_g_gamma                    - utility function
%   gm_gamma_from_T               - computes the gamma parameters of the inverses of T_k
%   gm_GV_CG_prec                 - preconditioned conjugate gradient for a symmetric matrix A, Ghysels and Vanroose parallel variant  
%   gm_H_from_T                   - Hessenberg matrix from a tridiagonal matrix
%   gm_invT_from_gamma            - computes the inverse of T_k from G and g
%   gm_Lanczos_prec               - preconditioned Lanczos for a linear system with a symmetric matrix A 
%   gm_minres_prec                - preconditioned Minres for a symmetric matrix A 
%   gm_PC_bitflip_rand            - random bit bitflips in CG predictor corrector variant
%   gm_Pipe_CG_MP_prec            - preconditioned conjugate gradient for a symmetric matrix A, Meurant's pipelined parallel variant 
%   gm_Pipe_CH_CG_prec            - preconditioned conjugate gradient for a symmetric matrix A, Tyler Chen's pipelined parallel variant 
%   gm_Pipe_PR_CH_CG_prec         - preconditioned conjugate gradient for a symmetric matrix A, pipelined parallel variant
%   gm_presc_conv_CG              - matrix with prescribed CG convergence for (T,e1)
%   gm_presc_conv_CG_err          - matrix with prescribed CG residual norms and A-norms for (T,e1)
%   gm_QORm_optinv_Tsym_prec      - QOR(m) for a symmetric matrix A with m directions and preconditioning
%   gm_QORm_optinv_Tsym_precB     - QOR(m) for a symmetric matrix A with m directions and preconditioning, variant
%   gm_ratio_estimate             - comparison of decrease of the error and the estimate
%   gm_stagest                    - computes a quantity for the estimation of the maximum accuracy
%   gm_stagestb                   - computes a quantity for the estimation of the maximum accuracy
%   gm_symmqr_prec                - preconditioned SymmQR for a symmetric matrix A
%   gm_Uhi_from_T                 - computes inv(U hat) from T
