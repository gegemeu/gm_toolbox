% SYMMETRIC
%
% Krylov methods for symmetric matrices
%
% Files
%   gm_augCG_prec             - preconditioned augmented conjugate gradient for a symmetric matrix A 
%   gm_BCG                    - block conjugate gradient, standard algorithm without preconditioning
%   gm_BCG_err_prec           - block conjugate gradient, standard algorithm with preconditioning with error norm estimates
%   GM_BCG_prec               - block conjugate gradient, standard algorithm with preconditioning
%   gm_CG_3t_prec             - preconditioned conjugate gradient for a symmetric matrix A, 3-term recurrence
%   gm_CG_CG_prec             - preconditioned conjugate gradient for a symmetric matrix A, Chronopoulos and Gear parallel variant, s = 1
%   gm_CG_CV_prec             - preconditioned conjugate gradient for a symmetric matrix A, Cools and Vanroose parallel variant 2018
%   gm_CG_err_icsig           - preconditioned conjugate gradient for a matrix A + sig I with IC preconditioning
%   gm_CG_errGR_adapt_prec    - preconditioned conjugate gradient for a symmetric matrix A with adaptive error norm estimates
%   gm_CG_errGR_errl2_prec    - preconditioned conjugate gradient for a symmetric matrix A, with estimates of the ell_2 norm
%   gm_CG_errGR_GM_prec       - preconditioned conjugate gradient for a symmetric matrix A, with improvement of the attainable accuracy 
%   gm_CG_errGR_MP_prec       - preconditioned conjugate gradient for a symmetric matrix A, Meurant's parallel variant with error norm estimates
%   gm_CG_errGR_prec          - preconditioned conjugate gradient for a symmetric matrix A, with estimates of the A-norm  of the error
%   gm_CG_errGR_reconst_prec  - preconditioned conjugate gradient for a symmetric matrix A, reconstruction of the A-norm estimates 
%   gm_CG_errGR_reorth_prec   - preconditioned conjugate gradient for a symmetric matrix A, with reorthogonalization and error norm estimates 
%   gm_CG_errGR_VDV_prec      - preconditioned conjugate gradient for a symmetric matrix A, improvement of the attainable accuracy
%   gm_CG_errGR_vp_prec       - preconditioned conjugate gradient for a symmetric matrix A, variable precision
%   gm_CG_GV_prec             - preconditioned conjugate gradient for a symmetric matrix A, Ghysels and Vanroose parallel variant
%   gm_CG_icsig               - preconditioned conjugate gradient for a matrix A + sig I with IC preconditioning
%   gm_CG_Lap                 - conjugate gradient for the Laplacian matrix without preconditioning
%   gm_CG_mflops              - conjugate gradient without preconditioning, computes the Mflops rate
%   gm_CG_MP_prec             - preconditioned conjugate gradient for a symmetric matrix A, Meurant's parallel variant
%   gm_CG_mu_eta              - computation of mu and eta when not given
%   gm_CG_options             - get the options for CG
%   gm_CG_Pipe_PR_TC_prec     - preconditioned conjugate gradient for a symmetric matrix A, Tyler Chen's pipelined parallel variant
%   gm_CG_Pipe_TC_prec        - preconditioned conjugate gradient for a symmetric matrix A, Tyler Chen's  parallel variant
%   gm_CG_PR_MP_prec          - preconditioned conjugate gradient for a symmetric matrix A, Meurant's pipelined parallel variant 
%   gm_CG_prec                - preconditioned conjugate gradient for a symmetric matrix A 
%   gm_CG_reorth_prec         - preconditioned conjugate gradient with reorthogonalization for a symmetric matrix A 
%   gm_CG_TC_prec             - preconditioned conjugate gradient for a symmetric matrix A, Tyler Chen's parallel variant
%   gm_CG_TR_prec             - preconditioned conjugate gradient for a symmetric matrix A, uses the true residual
%   gm_CGstandvpT             - standard conjugate gradient for a matrix A, variable precision
%   gm_comp_gamma_presc_CG    - computes gamma satisfying the sufficient condition
%   gm_comp_res_presc_CG      - prescribed residual norms for CG
%   gm_CR_prec                - preconditioned conjugate residual for a symmetric matrix A 
%   gm_delay                  - optimal delay to obtain a relative error on the error norm estimates
%   gm_DP_BCG                 - block conjugate gradient, Dubrulle-P algorithm without preconditioning
%   gm_DP_BCG_err_prec        - preconditioned block conjugate gradient, Dubrulle-P algorithm with error norm estimates
%   gm_DP_BCG_prec            - preconditioned block conjugate gradient, Dubrulle-P algorithm 
%   gm_DR_BCG                 - block conjugate gradient, Dubrulle-R algorithm
%   gm_DR_BCG_err_prec_L      - preconditioned block conjugate gradient, Dubrulle-R algorithm with error norm estimates
%   gm_DR_BCG_prec_L          - preconditioned block conjugate gradient, Dubrulle-R algorithm
%   gm_error_delay            - relative error of the error norm estimates
%   gm_F_BCG_prec             - preconditioned block conjugate gradient, similar to Ji and Li algorithm 
%   gm_Lanczos_prec           - preconditioned Lanczos algorithm for a symmetric matrix A 
%   gm_Minres_prec            - preconditioned Minres for a symmetric matrix A 
%   gm_OL_BCG_err_prec        - preconditioned block conjugate gradient, O'Leary's algorithm and error norm estimates
%   gm_OL_BCG_prec            - preconditioned block conjugate gradient, O'Leary's algorithm
%   gm_presc_conv_CG          - matrix with prescribed CG convergence for (T,e1)
%   gm_presc_conv_CG_err      - matrix with prescribed CG residual norms and A-norms for (T,e1)
%   gm_QORm_optinv_Tsym_prec  - QOR(m) for a symmetric matrix A with restart and preconditioning
%   gm_QORm_optinv_Tsym_precB - QOR(m) for a symmetric matrix A with restart and preconditioning, variant
%   gm_SYMMQR_prec            - preconditioned SYMMQR for a symmetric matrix A
