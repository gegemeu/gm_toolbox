function [H,nrT,nrc]=gm_H_from_T(T);
%GM_H_FROM_T Hessenberg matrix from a tridiagonal matrix

% The convergence of FOM on (H,e_1) must be the same as CG on (T,e_1)

% Input:
% T = tridiagonal matrix
%
% Output:
% H = upper Hessenberg matrix
% nrT = relative residual norms obtained from inv(T)
% nrc = relative residual norms obtained from the coefficients of T
%

%
% Author G. Meurant
% Sept 2018
%

rng('default')
n = size(T,1);
Ti = inv(T);
gamma = Ti(:,1);
g = Ti(:,n) / gamma(n);
nrT = 1 ./ g;
alpha = diag(T);
beta = diag(T,-1);
gc = zeros(n,1);
gc(1) = 1;
gc(2) = -alpha(1) / beta(1);
for k = 2:n-1
 d = gc(k) / beta(k);
 gc(k+1) = -d * (alpha(k) + beta(k-1) * gc(k-1) / gc(k));
end
nrc = 1 ./ gc;
 
Hi = zeros(n,n);
Hi(:,1) = gamma;
U = triu(randn(n-1,n-1));
E = gm_tridiag_const(n-1,0,0,1);
UU = U * E * inv(U);
e1 = eye(n-1,1);
Hi(1,2:n) = gamma(1) * g(2:n)' + (e1' - g(2:n)' * U * E) * inv(U);
Hi(2:n,2:n) = gamma(2:n) * g(2:n)' + UU;

H = triu(inv(Hi),-1);

