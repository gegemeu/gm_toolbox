function [x,nit,resn,resnt,errA]=gm_CGstandvpT(A,b,x0,epss,nitmax,dig);
%GM_CGSTANDVPT standard conjugate gradient for a matrix A, variable precision

% without preconditioning 
% b = rhs, x0 = initial vector, 
% nitmax  = max number of iterations

% resn = computed residual
% resnt = true residual
% errA = A-norm of the error

%
% Author G. Meurant
% June 2021
%  

dig_old = digits;
digits(dig)

A = gm_vpc(full(A));
b = gm_vpc(b);
xec = A \ b;
x0 = gm_vpc(x0);
x = x0;
r = b - A * x;
nit = 0;
rtr = r' * r;
r0 = double(rtr);
p = r;
resid = r0;
eps2 = epss^2;

resn = zeros(1,nitmax);
resnt = zeros(1,nitmax);
errA = zeros(1,nitmax);
resn(1) = double(sqrt(rtr));
resnt(1) = resn(1);
errA(1) = double(sqrt((x - xec)' * A * (x - xec)));

while resid >= eps2 * r0 && nit <= nitmax
 nit = nit + 1;
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 rtrz = r' * r;
 
 % "true" residual
 tr = b - A * x;
 resnt(nit+1) = double(sqrt(tr'*tr));
 resid = double(rtrz);
 resn(nit+1) = sqrt(resid);
 errA(nit+1) = double(sqrt((x - xec)' * A * (x - xec)));
 
 bet = rtrz / rtr;
 p = r + bet * p;
 rtr = rtrz;
end % while

resn = resn(1:nit+1);
resnt = resnt(1:nit+1);
errA = errA(1:nit+1);

x = double(x);
digits(dig_old);



