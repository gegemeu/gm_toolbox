function [x,nit,iret,results] = gm_QORm_optinv_Tsym_prec(A,b,x0,m,options,params);
%GM_QORM_OPTINV_TSYM_PREC QOR(m) for a symmetric matrix A with restart and preconditioning

% Optimal Q-OR method (equivalent to MINRES)

% This function uses the tridiagonal matrix for the inverse of V_k^T V_k
% Restart if things are going wrong

% We use Givens rotations to compute the solution

% Generally the restart parameter m must be larger than nitmax because it is useless to restart

% Caution: We do not check the symmetry of A

% Works only with some preconditioners listed below

%
% Input:
% A = symmetric matrix
% b = right-hand side
% x0 = initial vector
% m = restarting parameter, QOR(m)

% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
% epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% scaling = 1, diagonally scales the matrix before preconditioning (0)
% trueres = 1, computes the norm of b - A x_k (0)
% iprint = 1, print, residual norms at every iteration (0)
% Anorm = 1, computes the A-norm of the error (0)
% l2norm = 1, computes the ell_2 norm of the error (0)
% timing = 1, time measurements (0)
% precond = type of preconditioning ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'ss' SSOR with omega=1 (also named 'gs')

% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields 
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh', 'wl'

%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'

%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code, = 0 if convergence

% results is a structure with the following fields:
% resn = ell_2 norm of computed residual
% resnt = ell_2 norm of the true residual (if trueres = 1)
% Anorm = A-norm of the error (if Anorm = 1)
% l2norm = ell_2 norm of the error (if l2norm = 1)
% time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin < 3
 x0 = zeros(size(A,1),1);
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_QORm_optinv_Tsym_prec: error, the dimensions of A and b are not compatible')
end % if
if nb ~= nx
 error('gm_QORm_optinv_Tsym_prec: error, the dimensions of x and b are not compatible')
end % if

if nargin < 5
 options = [];
 params = [];
end % if

if nargin < 6
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,scaling,trueres,iprint,precond,timing,Anorm,l2norm] = gm_CG_options(A,options);

if m > nitmax
 m = nitmax;
end

if m == 0
 m = 10;
end

if timing == 1
 tic
end % if

iret = 0;

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

nb = norm(b);
nb2 = nb^2;

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond(A,precond,iprint,params);
d = cprec{1};
L = cprec{2};
D = spdiags(sqrt(1./d),0,n,n);
LL = L * D;

if strcmpi(precond,'no') == 1
 x = x0;
else
 x = LL' * x0;
end

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end

% init residual vector
if strcmpi(precond,'no') == 1
 r = b - A * x;
else
 r = LL \ (b - A * x0);
end
matvec = matvec + 1;
z = r;
x0 = x;

rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m+1,m);
alpk = zeros(m,1);
betk = zeros(m,1);
resn = zeros(1,nitmax+1);
resnt = zeros(1,nitmax+1);

r0 = r' * r;
r0r = r0;
nrr = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',nrr)
end

if Anorm == 1 || l2norm == 1
 xec = A \ b;
end % if 
if Anorm == 1
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt( (xec - x0)' * A * (xec -x0));
 matvec = matvec + 1;
 dotprod = dotprod + 1;
else
 errA = [];
end % if
if l2norm == 1
 errl2 = zeros(1,nitmax+1);
 errl2(1) = norm(xec - x0);
 dotprod = dotprod + 1;
else
 errl2 = [];
end % if

% number of cycles
nitd = 0;
% number of iterations
nit = 0;
iconv = 0;
resn(1) = nrr;
resnt(1) = nrr;
rhs(1) = nrr;
bet = nrr;
resid = realmax;
epss = epsi^2;
matv(1) = matvec;
irestart = 1;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end % if
 tic
end % if

% ------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 V = zeros(n,m+1);
 nuu = zeros(1,m);
 % init Givens rotations
 rot = zeros(2,m);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;

 % matrix-vector product
 if strcmpi(precond,'no') == 1
  Av = A * v;
 else
  Av = LL \ (A * (LL' \ v));
 end % if strcmpi
 
 nuu(1) = 1;
 
 bkd = 0;

 % start a cycle of QORm(m)
 
 for k = 1:m
  % number of iterations
  nit = nit + 1;

  % construction of the basis vectors
  % and entries of H (in the last column of H)

  if k == 1
   % choose the optimal value for the first column of H
   v = V(:,1);
   vAv = v' * Av;
   vAAv = Av' * Av;
   dotprod = dotprod + 2;
   if abs(vAv) <= 1-14
    % breakdown
    fprintf('\n gm_QORm_optinv_Tsym_prec: Initialization breakdown, v^T A v = %g \n',vAv)
    H(1,1) = 0;
   else
    H(1,1) = vAAv / vAv;
   end % if abs
   vt = Av - H(1,1) * V(:,1);
   H(2,1) = norm(vt);
   dotprod = dotprod + 1;
   V(:,2) = vt / H(2,1);
   nuu(2) = - nuu(1) * H(1,1) / H(2,1);
   
   nu2 = nuu(2)^2;
   
   alpk(1) = nu2 / (nu2 - 1);
   alpk(2) = alpk(1);
   betk(1) = - nuu(2) / (nu2 - 1);

   % matrix-vector product  
   if strcmpi(precond,'no') == 1
    Av = A * V(:,2);
   else
    Av = LL \ (A * (LL' \ V(:,2)));
   end % if strcmpi
   matvec = matvec + 1;

  else % k ~= 1
   
   % dense matrix-vector product
   % the last component is the only nonzero
   vktAk = V(:,k)' * Av;
   dotprod = dotprod + 1;
   
   % product with a tridiagonal matrix
   % only the last two components of s are nonzero
   sk = alpk(k) * vktAk;
   sk1 = betk(k-1) * vktAk;
   
   AVks = Av - sk1 * V(:,k-1) - sk * V(:,k);
   alp = AVks' * AVks;
   dotprod = dotprod + 1;
      
   % new column of H
   if abs(vktAk) <= 0
    fprintf('\n gm_QORm_optinv_Tsym_prec: Breakdown iteration %d, value = %g, switch to MINRES \n',nit,vktAk)
    % switch to MINRES
    [x,nit,iret,results] = gm_Minres_prec(A,b,x0,options,params);
    return
   else
    beta = alp / vktAk;
    % H is tridiagonal
    H(k-1,k) = sk1;
    H(k,k) = sk + beta;
   end % if abs
   
   gswitch = 0;
   % no recovery for some near breakdowns
   if gswitch == 1
    % this threshold may be too large (1e-6)
    if abs(vktAk) < 1e-6 || bkd == 1
     if iprint == 1
      fprintf('\n gm_QOR_optinv_Tsym_prec: Small vktA = %g at iteration %d \n',vktAk,nit)
     end
     return
    end
   end % gswitch
   
   % new basis vector
   vt = AVks - beta * V(:,k);
   h = sqrt(alp + beta^2);
   % the inverse of nu gives the norm of the residual
   nuu(k+1) = -(nuu(k) * H(k,k) + nuu(k-1) * H(k-1,k)) / h;
   
   nuk = nuu(k)^2;
   nukp = nuu(k+1)^2;
   
   betk(k) = -(nuu(k) * nuu(k+1)) / (nukp - nuk);
   alpk(k+1) = nukp / (nukp - nuk);
   
   if abs(nukp - nuk) / abs(nuk) < 1e-10
    fprintf('\n small difference of nu, iteration %d \n',nit)
   end
   
   % subdiagonal entry of H
   H(k+1,k) = h;

   if k < m
    % new basis vector
    V(:,k+1) = vt / h;
            
    % matrix-vector product (n x n)
    if strcmpi(precond,'no') == 1
     Av = A * V(:,k+1);
    else
     Av = LL \ (A * (LL' \ V(:,k+1)));
    end % if strcmpi
    matvec = matvec + 1;
    
   end % if k < m
  end % if k == 1
  
  % end of computation of the basis for the k-th iteration
  
  % We use the QR factorization of the tridiagonal matrix H to compute the
  % solution
  % reduce H to upper triangular form with Givens rotations

  gk1 = H(k+1,k);

  % apply the preceding Givens rotations to the last column just computed

  for kk = max(1,k-2):k-1
   g1 = H(kk,k);
   g2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk
  
  if trueres == 1 || Anorm == 1 || l2norm == 1
   % computation of the true (if left = 0) residual norm
   % we are doing too many operations since H is banded!
   y = triu(H(1:k,1:k)) \ rhs(1:k);
   x = x0 + V(:,1:k) * y;
   if strcmpi(precond,'no') == 1
    xx = x;
   else
    xx = LL' \ x;
   end % if strcmpi
  end % if trueres
  
  if trueres == 1
   % this is also not the true residual norm if there is some scaling
   resnt(nit+1) = norm(b - A * xx);
  end % if
  
  % A-norm of the error
  if Anorm == 1
   errA(nit+1) = sqrt( (xec - xx)' * A * (xec -xx));
   matvec = matvec + 1;
   dotprod = dotprod + 1;
  end % if
  if l2norm == 1
   errl2(nit+1) = norm(xec - xx);
   dotprod = dotprod + 1;
  end % if

  % nresidu is the estimate of the residual norm given by QOR
  yk = rhs(k) / H(k,k);
  nresidu = gk1 * abs(yk);

  if iprint == 1
   fprintf('cycle = % d, nit = %d, 1/nu = %12.5e, residual norm = %12.5e, relative residual norm = %12.5e, diff = %12.5e \n',...
    nitd,nit,abs(1/nuu(k+1)),nresidu,nresidu/sqrt(r0),abs(abs(1/nuu(k+1))-nresidu/sqrt(r0r))/abs(1/nuu(k+1)))
  end
  resn(nit+1) = nresidu;
  matv(nit+1) = matvec;
  
  epsnu = 1e-2;
  if abs(abs(1/nuu(k+1))-nresidu/sqrt(r0r))/abs(1/nuu(k+1)) > epsnu && irestart == 1
  % restart at once
%    fprintf('\n restart iteration %d \n',ni)
   irestart = 0;
   break
  end
  
  % convergence test or too many iterations
  if nresidu < (epsi * sqrt(r0)) || nit >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu
  
  if k < m
   % compute, store and apply a new Givens rotation to zero the last term in kth column
   % except at the end of a cycle
   gk = H(k,k);
   cs = sqrt(abs(gk1)^2 + abs(gk)^2);
   if abs(gk) < abs(gk1)
    mu = gk / gk1;
    tau = conj(mu) / abs(mu);
   else
    mu = gk1 / gk;
    tau = mu / abs(mu);
   end % if
   % keep the rotation for the next columns
   rot(1,k) = abs(gk) / cs; % cosine
   rot(2,k) = abs(gk1) * tau / cs; % sine

   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k
  
 end %  for k - end of one cycle
 
 % computation of the solution at the end of the cycle
 % triangular solve
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 if strcmpi(precond,'no') == 1
  xx = x;
 else
  xx = LL' \ x;
 end % if strcmpi
 x = xx;

 if iconv == 1
  % we have to stop
  resn = resn(1:nit+1);
  results.resn = resn;
  if trueres == 1
   resnt = resnt(1:nit+1);
   results.resnt = resnt;
  end
  if Anorm == 1
   results.Anorm = errA(1,1:nit+1);
  else
   results.Anorm = [];
  end % if
  if l2norm == 1
   results.l2norm = errl2(1,1:nit+1);
  else
   results.l2norm = [];
  end % if
  % return code
  iret= 0;
  if nit == nitmax
   iret = 2;
  end

  if iprint == 1
   if nit == nitmax
    fprintf('\n No convergence after %d iterations \n',nit)
   end
   nr = norm(b - A * x);
   fprintf('\n Final true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nr,nr/norm(b))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
  end % if iprint

  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end

  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  else
   results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  end % if timing

  return
 end % if iconv

 % we have not converged yet, compute the residual and restart

 xx = x;
 if strcmpi(precond,'no') ~= 1
  xx = LL' * xx;
 end % if

 % residual vector
 if strcmpi(precond,'no') == 1
  r = b - A * x;
 else
  r = LL \ (b - A * x);
 end % if strcmpi
 matvec = matvec + 1;
 z = r;

 x0 = xx;
 rk = r' * r;
 r0r = rk;
 irestart = 1;
 nr = rk;
 resid = rk;
 nrr = norm(r);
 bet = nrr;
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;

 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,nrr,nrr/nb)
 end

end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
resn = resn(1:nit);
results.resn = resn;
if trueres == 1
 resnt = resnt(1:nit);
 results.resnt = resnt;
end
if Anorm == 1
 results.Anorm = errA(1,1:nit+1);
else
 results.Anorm = [];
end % if
if l2norm == 1
 results.l2norm = errl2(1,1:nit+1);
else
 results.l2norm = [];
end % if
if nit == nitmax
 iret = 2;
end

xx = x;
if strcmpi(precond,'no') == 1
 x = xx;
else
 x = LL' \ xx;
end % if strcmpi

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
 nr = norm(b - A * x);
 fprintf('\n Final true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nr,nr/norm(b)) 
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
end % if timing

% warning on
