function [ncas,tp,sp,fp,tn,fn,sn,bitfn,convfn,nifn]=gm_bitflip_rand(name,nc,epsi,nitmax);
%GM_BITFLIP_RAND random bit bitflips in CG

%
% Author G. Meurant
% September 2021
%

load(name)

n = size(A,1);
x0 = zeros(n,1);
tp = 0;
fp = 0;
tn = 0;
fn = 0;
sp = 0;
sn = 0;
fsn = 0;
ncas = 0;
mods = [0, 0, 0, 0, 0, 1, 0, 0]; % rk
%mods = [1, 0, 0, 0, 0, 0, 0, 0]; % Ap

prec = 'ci';

for k = 1:nc
 xec = 2 * rand(n,1) - 1;
 b = A * xec;
 
 flip = rand;
 
 if flip <= 0.10
  % no flip
  [x,nit,iret,resn,resnt,diff,diff2,diff3,detect,time_mat] = gm_CG_prec_flip_detect(A,b,x0,epsi,nitmax,'nos','trueres','nop',prec);
  if detect == 1
   fp = fp + 1;
  else
   tn = tn + 1;
  end % if detect
 else % if flip
  [x,nitno,iret,resn,resnt,diff,diff2,diff3,detect,time_mat] = gm_CG_prec_flip_detect(A,b,x0,epsi,nitmax,'nos','trueres','nop',prec);
  ncas = ncas + 1; % number of cases with flips
  bit = randi(64);
  npert = fix(nitno/2);
  [x,nit,iret,resn,resnt,diff,diff2,diff3,detect,time_mat] = gm_CG_prec_flip_detect(A,b,x0,epsi,nitno+npert,'nos','trueres','nop',prec,bit,mods,npert,2*nitmax,0);
  if detect == 1
   if nit < nitmax
    sp = sp + 1;
   else
    tp = tp + 1;
   end % if nit
  else
   fsn = fsn + 1;
   bitfn(fsn) = bit;
%    semilogy(diff)
%    pause
   nifn(fsn) = nit;
   if nit < nitmax
    convfn(fsn) = 1;
    sn = sn + 1;
   else
    convfn(fsn) = 0;
    fn = fn + 1;
   end % if nit
  end % if detect
 end % if flip
 
end % for k

