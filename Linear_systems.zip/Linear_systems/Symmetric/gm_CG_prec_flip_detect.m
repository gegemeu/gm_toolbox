function [x,nit,iret,resn,resnt,diff,diff2,diff3,detect,time_mat]=gm_CG_prec_flip_detect(A,b,x0,epsi,nitmax,scalings,trueress,iprints,precond,bit,mods,startf,freq,recov,varargin);
%GM_CG_PREC_FLIP_DETECT preconditioned conjugate gradient for a symmetric matrix A with bit flips and recovery

%
% Input:
% A = symmetric positive definite matrix
% b = right hand side
% x0 = starting vector
% epsi = threshold for stopping criterion
% (stop if norm(r^k) <= epss norm(r^0) or nit > nitmax
% nitmax = maximum number of iterations
%  if nitmax < 0 we do time measurements
% scalings = 'scaling', diagonally scales the matrix before preconditioning
% trueress = 'trueres' computes the norm of b - A x_k
% iprints = 'print' print residual norms at every iteration
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
% bit = bit to be flipped
% mods = [Ap, pAp, alp, r, z, rk, bet, p]
% startf = iteration to start flipping
% freq = frequency of the bit flips
% recov = 1 with recovery
%
% param = varargin(1) - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv' and 'ei'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = nothing for 'tw'
%  = number of levels for 'ml' and 'dd'
%  = block size for block methods
%
% the other parameters for 'ml' and 'dd' are in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code
% resn = l_2 norm of computed residual
% resnt = l_2 norm of the true residual (if 'trueres')
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items

%
% Author G. Meurant
% March 2001 modified Feb 2009
% May 2015
%

detect = 0;

n = size(A,1);

if nargin < 10
 bit = [];
 mods = [];
 startf = [];
 freq = [];
 recov = [];
end % if

if nargin < 3
 x0 = zeros(n,1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_CG_prec_flip_detect: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_CG_prec_flip_detect: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 6
 % no scaling
 scaling = 0;
end
if nargin < 7
 % do not compute the true residual norm
 trueres = 0;
end
if nargin < 8
 % no printing
 iprint = 0;
end
if nargin < 9
 % no preconditioning
 precond = 'no';
end

if nargin > 5 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 6 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 7 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if isempty(bit)
 bit = 0;
 startf = 2 * nitmax;
 freq = startf;
 recov = 0;
 mods = zeros(1,8);
end

if recov == 1
 eps_recov = 1e-8; % threshold for the recovery procedure
 eps_rap = 1e5; 
 eps3 = 1e-12;
else
 eps_recov = 1e300; % no recovery
 eps_rap = 1e300; % no recovery
 eps3 = 1e300;
end % if
eps_recov = 1e-12;
modif_Ap = mods(1);
modif_pAp = mods(2);
modif_alp = mods(3);
modif_r = mods(4);
modif_z = mods(5);
modif_rk = mods(6);
modif_bet = mods(7);
modif_p = mods(8);

if iprint == 1
 fprintf('\n gm_CG_prec_flip_detect: \n\n')
 fprintf('  precond = %s \n',precond)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
 if bit > 0
  fprintf('  bit = %g \n',bit)
  fprintf('  startf = %g \n',startf)
  fprintf('  freq = %g \n',freq)
  fprintf('  mods = %g, %g, %g, %g, %g, %g, %g, %g \n',mods)
  fprintf('  recov = %g \n',recov)
 end % if bit
end

tb = 1;
if nargin >= 15 && (strcmpi(precond,'bc') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_CG_prec_flip_detect: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 15 && (strcmpi(precond,'ce') == 1)
 % threshold for the Matlab IC preconditioner
 tb = varargin{1};
 if iprint == 1
  fprintf('  ic threshold = %g \n',tb)
 end
end

if nargin >= 15 && (strcmpi(precond,'gm') == 1)
 % number of iterations for CG
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 15 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1) || ...
  strcmpi(precond,'sa') == 1 || strcmpi(precond,'ch') ==  1)
 %  tb = [alp, q] for AINV
 tb = varargin{1};
end

if nargin < 15 && (strcmpi(precond,'ai') == 1)
 tb = [0.1, n];
end

if nargin < 15 && (strcmpi(precond,'sa') == 1)
 tb = [0.1, n];
end

if nargin < 15 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if nargin >= 15 && strcmpi(precond,'lv') == 1
 tb = varargin{1};
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
%  fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && (strcmpi(precond,'sa') == 1)
 fprintf('  alpha = %g \n',tb(1))
%  fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && (strcmpi(precond,'ch') == 1)
 fprintf('  epsi = %g \n',tb(1))
end

if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1)...
  || (strcmpi(precond,'lv') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >=  15 && (strcmpi(precond,'gp') == 1)
 % given preconditioner
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_CG_prec_flip_detect: error, M has to be of the same order as A')
end

if nargin >= 16 && (strcmpi(precond,'ml') == 1 || strcmpi(precond,'mb') == 1)
 % get the input parameters for the multilevel AMG method
 if nargin < 22
  error('gm_CG_prec_flip_detect: some parameters are not defined for ML')
 end
 
 iv = 1;
 if strcmpi(precond,'mb') == 1
  tb = varargin{1};
  iv = iv + 1;
 end
 lmax = varargin{iv};
 nu = varargin{iv+1};
 alpmax = varargin{iv+2};
 alb = varargin{iv+3};
 smooth = varargin{iv+4};
 infl = varargin{iv+5};
 coarse = varargin{iv+6};
 interpo = varargin{iv+7};
 if nargin > 17+iv
  qmin = varargin{iv+8};
 else
  qmin = n;
 end
 gama = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------multilevel parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
  if gama == 1
   fprintf(' V-cycle \n')
  else
   fprintf(' W-cycle \n')
  end
 end
 
end

if nargin < 16 && (strcmpi(precond,'ml') == 1 || strcmpi(precond,'mb') == 1)
 % defaults for AMG
 lmax = 10;
 nu = 1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'gs';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 falp = 1;
 alq = 1;
 normal = 0;
 tb = 2;
 if nargin == 10 && strcmpi(precond,'mb') == 1
  tb = varargin{1};
 end
 gama = 1;
 
 if iprint == 1
  fprintf('\n -----------default multilevel parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
  fprintf(' block size = %d \n',tb)
  fprintf(' V-cycle \n')
 end
 
end

x = [];
nit = 0;
iret = 0;
resn = zeros(1,nitmax);
resnt = zeros(1,nitmax);
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 A_old = A;
 [A,dda] = gm_normaliz(A);
 b_old = b;
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;
matv = zeros(1,nitmax+1);

xin = zeros(n,1);

% init of preconditioners
if strcmpi(precond,'ml') ~= 1  && strcmpi(precond,'mb') ~= 1
 [dd,L,d1,ld,ldd] = gm_initprec(A,precond,iprint,tb);
 if strcmpi(precond,'gp')
  L = M;
 end
 
elseif strcmpi(precond,'ml') == 1
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_CG_prec_flip_detect: Error in gm_amg_init \n')
  iret = 1;
  return
 end
 
elseif strcmpi(precond,'mb') == 1
 % multilevel block preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_initb(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,tb,iprint);
 if err == 1
  error('gm_CG_prec_flip_detect: error in gm_amg_initb')
 end
 
end % if strcmpi

x = x0;
% init residual vector
r = b - A * x;
matvec = matvec + 1;

nr = norm(r);
dotprod = dotprod + 1;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',nr)
end

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = nr;
end

resn = zeros(1,nitmax);
resn(1) = nr;
diff = zeros(1,nitmax+2);
diff2 = zeros(1,nitmax+2);
diff3 = zeros(1,nitmax+2);

resid = realmax;
epss = epsi^2;
matv(1) = matvec;

% solve of M z = r
if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
 z = gm_solveprec(r,A,dd,L,precond,tb);
elseif strcmpi(precond,'mb') == 1
 % multilevel block preconditioner
 z = gm_amgitb(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
elseif strcmpi(precond,'ml') == 1
 % multilevel preconditioner
 z = gm_amgit(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
end % if strcmpi

p = z;
% number of iterations
ni = 0;
r0 = r' * r;
rtr = z' * r;
dotprod = dotprod + 2;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

p_old_old = p;
rtr_old_old = rtr;
x_old_old = x;
r_old_old = r;
z_old_old = z;

bitf = 0;

% -------------------------------------Iterations

while resid >= epss*r0 && ni < nitmax
 
 ni = ni + 1;
 
 p_old = p;
 rtr_old = rtr;
 x_old = x;
 r_old = r;
 z_old = z;
 
 Ap = A * p;
 matvec = matvec + 1;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_Ap == 1 % bit flip
  bitf = 1;
  j = randi(n);
  %fprintf('\n iteration %d, perturbation bit %d of component %d of Ap = %22.15e \n',ni,bit,j,Ap(j))
  [bin,val] = flip_bit_fp64(Ap(j),bit);
  Ap(j) = val;
  %fprintf(' after modification = %22.15e \n',Ap(j))
 end % if ni
 
 pAp = p' * Ap;
 dotprod = dotprod + 1;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_pAp == 1 % bit flip
  bitf = 1;
  %fprintf('\n iteration %d, perturbation bit %d of pAp = %22.15e \n',ni,bit,pAp)
  [bin,val] = flip_bit_fp64(pAp,bit);
  pAp = val;
  %fprintf(' after modification = %22.15e \n',pAp)
 end % if ni
 
 alp = rtr / pAp;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_alp == 1 % bit flip
  bitf = 1;
  %fprintf('\n iteration %d, perturbation bit %d of alp = %22.15e \n',ni,bit,alp)
  [bin,val] = flip_bit_fp64(alp,bit);
  alp = val;
  %fprintf(' after modification = %22.15e \n',alp)
 end % if ni
 
 x = x + alp * p;
 
 % computed residual
 r = r - alp * Ap;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_r == 1 % bit flip
  bitf = 1;
  j = randi(n);
  %fprintf('\n iteration %d, perturbation bit %d of component %d of r = %22.15e \n',ni,bit,j,r(j))
  [bin,val] = flip_bit_fp64(r(j),bit);
  r(j) = val;
  %fprintf(' after modification = %22.15e \n',r(j))
 end % if ni
 
 % solve of M w = Ap
 if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
  w = gm_solveprec(Ap,A,dd,L,precond,tb);
 elseif strcmpi(precond,'mb') == 1
  % multilevel block preconditioner
  w = gm_amgitb(A,Ap,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
 elseif strcmpi(precond,'ml') == 1
  % multilevel preconditioner
  w = gm_amgit(A,Ap,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
 end % if strcmpi
 %z = z - alp * w; % this causes problems for the dot products (r_j, z_k)
 
 % solve of M z = r
 if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
  z = gm_solveprec(r,A,dd,L,precond,tb);
 elseif strcmpi(precond,'mb') == 1
  % multilevel block preconditioner
  z = gm_amgitb(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
 elseif strcmpi(precond,'ml') == 1
  % multilevel preconditioner
  z = gm_amgit(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
 end % if strcmpi
 
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_z == 1 % bit flip
  bitf = 1;
  j = randi(n);
  %fprintf('\n iteration %d, perturbation bit %d of component %d of z = %22.15e \n',ni,bit,j,z(j))
  [bin,val] = flip_bit_fp64(z(j),bit);
  z(j) = val;
  %fprintf(' after modification = %22.15e \n',z(j))
 end % if ni
 
 rtrz = z' * r;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_rk == 1 % bit flip
  bitf = 1;
  %fprintf('\n iteration %d, perturbation bit %d of rtrz = %22.15e \n',ni,bit,rtrz)
  [bin,val] = flip_bit_fp64(rtrz,bit);
  rtrz = val;
  %fprintf(' after modification = %22.15e \n',rtrz)
 end % if ni
 
 rk = r' * r;
 dotprod = dotprod + 2;
 resid = rk;
 % residual l_2 norm
 resn(ni+1) = sqrt(rk);
 
 % "true" residual norm
 if trueres == 1
  resnt(ni+1) = norm(b - A * x);
 end % if trueres
 
 bet = rtrz / rtr;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_bet == 1 % bit flip
  bitf = 1;
  %fprintf('\n iteration %d, perturbation bit %d of bet = %22.15e \n',ni,bit,bet)
  [bin,val] = flip_bit_fp64(bet,bit);
  bet = val;
  %fprintf(' after modification = %22.15e \n',bet)
 end % if ni
 
 p = z + bet * p;
 if ni >= startf && mod(ni-startf,freq) == 0 && modif_p == 1 % bit flip
  bitf = 1;
  j = randi(n);
  %fprintf('\n iteration %d, perturbation bit %d of component %d of p = %22.15e \n',ni,bit,j,p(j))
  [bin,val] = flip_bit_fp64(p(j),bit);
  p(j) = val;
  %fprintf(' after modification = %22.15e \n',p(j))
 end % if ni
 
 % output
 if iprint == 1
  nresidu = sqrt(resid);
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',ni,nresidu,nresidu/sqrt(r0))
 end
 
 matv(ni+1) = matvec;
 
 c1 = alp^2 * (Ap' * w) / rtr;
 
 c2 = 1 + bet;
 
 %c2p = c2 - 2 * (r_old' * r) / rtr; % this is better but more expensive
 
 %diff(ni) = max(1e-17,abs(c1 - c2) / abs(c2));
 %diff(ni) = max(1e-17,abs(c1 - c2));
%  diff(ni) = abs(alp^2 * (Ap' * w) - rtr - rtrz);
%  diff(ni) = diff(ni) / (abs(rtr) + abs(rtrz));
 diff2(ni) = sqrt(abs(alp^2 * (Ap' * w)));
 diff3(ni) = sqrt(abs(rtr) + abs(rtrz));
 diff(ni) = abs(diff2(ni) - diff3(ni)) / diff3(ni);
 
 if bitf == 1
  %fprintf('\n diff = %12.5e, diff2 = %12.5e, diff3 = %12.5e \n',diff(ni),diff2(ni),diff3(ni))
  bitf = 0;
 end % if
 
 rtr = rtrz;
 
 % recovery from silent faults
 if (diff(ni) > eps_recov)
  detect = 1; % bit flip detected
  %return
  %if (diff(ni) > eps_recov) && (diff3(ni) > eps3)
  %if ni >= 2 && ( (diff(ni) / diff(ni-1)) > eps_rap || diff(ni) > eps_recov )
  %if ni >= 2 && ((diff(ni) / diff(ni-1)) > eps_rap && diff(ni) > eps_recov)
  % go back 2 iterations because p might be in error
  % does not work if there will be a fault in the next iteration
  %fprintf('\n recovery at iteration %d, diff = %12.5e, diff2 = %12.5e, diff3 = %12.5e \n',ni,diff(ni),diff2(ni),diff3(ni))
  
  % no recovery
%   p = p_old_old;
%   rtr = rtr_old_old;
%   x = x_old_old;
%   r = r_old_old;
%   z = z_old_old;
 else
  p_old_old = p_old;
  rtr_old_old = rtr_old;
  x_old_old = x_old;
  r_old_old = r_old;
  z_old_old = z_old;
 end % if
 
end % iterations

resn = resn(1,1:ni+1);
matv = matv(1,1:ni+1);
if trueres == 1
 resnt = resnt(1,1:ni+1);
else
 resnt = [];
end

nit = ni;
iret = 0;
if ni == nitmax
 iret = 2;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:ni+1));
end % if timing

if iprint == 1
 if ni == nitmax
  fprintf('\n No convergence after %d iterations \n',ni)
 end
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',ni)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint


% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
 trueresi = norm(b_old - A_old * x);
 
 if iprint >= 1
  fprintf('\n ---We are back to the original scale \n\n')
  fprintf(' norm of true residual for x = %g \n\n',trueresi);
  fprintf(' relative residual = %g \n',sqrt(resid/r0));
 end
end % if scaling





