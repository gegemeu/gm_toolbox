function [rerrA,restim]=gm_ratio_estimate(errA,estim,delay);
%GM_RATIO_ESTIMATE comparison of decrease of the error and the estimate

% we look at errA(k+delay) / errA(k)

% Input:
% errA = A-norm of the error
% estim = upper bound on the upper bound
% delay
%
% Output: 
% rerrA, restim = ratios

%
% Author G. Meurant
% January 2019
%

n = length(estim);
if length(errA) < n
 error(' errA has not enough elements')
end

rerrA = zeros(1,n-delay);
restim = zeros(1,n-delay);

for k = 1:n-delay
 rerrA(k) = errA(k+delay) / errA(k);
 restim(k) = estim(k+delay) / estim(k);
end

% semilogy(rerrA)
% hold on
% semilogy(restim,'r')
% legend('errA','estim')
% hold off

plot(rerrA)
hold on
plot(restim,'r')
legend('errA','estim')
hold off

