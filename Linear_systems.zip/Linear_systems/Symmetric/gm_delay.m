function [dG,dGRu]=gm_delay(eG,eGRu,errA,epss,mu);
%GM_DELAY optimal delay to obtain a relative error on the estimates

% Input:
% eG, eGRu = computed in gm_CG_errGR_precT_reconst
% errA = exact A-norm of the error
% epss = threshold 
% mu = estimate of the smallest eigenvalue
%
% Output:
% dG = degree to obtain the relative error <= epss for Gauss lower bound
% dGRu = degree to obtain the relative error <= epss for Gauss-Radau upper
%  bound

%
% Author G. Meurant
% Jan 2019
%

n = length(errA);
dG = zeros(1,n-1);
dGRu = zeros(1,n-1);

for k = 1:n-1
 errG = eG(k,:);
 ind = min(find(errG==0)) - 1;
 err = errA(k);
 erel = abs(errG(1:ind) - err) ./ err;
 me = min(find(erel <= epss));
 if ~isempty(me)
  dG(k) = me;
 end % if
 errGRu = eGRu(k,:);
 ind = min(find(errGRu==0)) - 1;
 erel = abs(errGRu(1:ind) - err) ./ err;
 me = min(find(erel <= epss));
 if ~isempty(me)
  dGRu(k) = me;
 end % if
end % for k

% plot(dG)
% hold on
% plot(dGRu,'r')
% legend('Gauss',['Gauss-R mu=' num2str(mu)])
% title(['Optimal delay, epss=' num2str(epss)]);
% hold off

