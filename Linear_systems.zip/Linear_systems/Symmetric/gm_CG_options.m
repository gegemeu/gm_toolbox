function [epsi,nitmax,scaling,trueres,iprint,precond,timing,Anorm,l2norm,delay,mu,eta,compeig,adaptmu,adaptdel] = gm_CG_options(A,options);
%GM_CG_OPTIONS get the options for CG

% Input:
% options is a structure containing all or some of the following fields
% epsi = threshold for stopping criterion
%  (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations
% scalings = 1, diagonally scales the matrix before preconditioning
% trueress = 1 computes the norm of b - A x_k
% iprints = 1 print residual norms at every iteration
% timing = 1, time measurements
% Anorm = 1, computes the A-norm of the error 
% l2norm = 1, computes the ell_2 norm of the error 
% compeig = 1, estimation of the smallest and largest eigenvalues of M^{-1}A
% adaptmu = adaptive values of the bounds for smallest and largest eigenvalues
% adaptdel = 1, adaptive different delays for Gauus and Gauss-Radau
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
%  = 'gp' = preconditioner M given by the user

% for bounds of the A-norm:
% delay = integer, we compute the bounds delay iterations before the current one
% mu = lower bound of the smallest eigenvalue of M^{-1}A
% eta = upper bound of the largest eigenvalue of M^{-1}A

%
% Author G. Meurant
% January 2025
%

% Defaults

n = size(A,1);

if isempty(options)
 epsi = 1e-10;
 nitmax = n;
 scaling = 0;
 trueres = 0;
 iprint = 0;
 precond = 'no';
 timing = 0;
 Anorm = 0;
 l2norm = 0;
 delay = 1;
 [mu,eta] = gm_gerschgo(A);
 mu = max(10*eps,mu);
 compeig = 0;
 adaptmu = 0;
 adaptdel = 0;
else
 if isfield(options,'epsi')
  epsi = options.epsi;
 else
  epsi = 1e-10;
 end % if
 if isfield(options,'nitmax')
  nitmax = options.nitmax;
 else
  nitmax = n;
 end % if
 if isfield(options,'scaling')
  scaling = options.scaling;
 else
  scaling = 0;
 end % if
 if isfield(options,'trueres')
  trueres = options.trueres;
 else
  trueres = 0;
 end % if
 if isfield(options,'iprint')
  iprint = options.iprint;
 else
  iprint = 0;
 end % if
 if isfield(options,'precond')
  precond = options.precond;
 else
  precond = 'no';
 end % if
 if isfield(options,'timing')
  timing = options.timing;
 else
  timing = 0;
 end % if
 if isfield(options,'Anorm')
  Anorm = options.Anorm;
 else
  Anorm = 0;
 end % if
 if isfield(options,'l2norm')
  l2norm = options.l2norm;
 else
  l2norm = 0;
 end % if
 if isfield(options,'delay')
  delay = options.delay;
 else
  delay = 1;
 end % if
 if n == size(A,2)
  if isfield(options,'mu')
   mu = options.mu;
  else
   [mu,~] = gm_gerschgo(A);
   mu = max(10*eps,mu);
  end % if
  if isfield(options,'eta')
   eta = options.eta;
  else
   [~,eta] = gm_gerschgo(A);
  end % if
 else
  if isfield(options,'mu')
   mu = options.mu;
  else
   mu = [];
  end % if
  if isfield(options,'eta')
   eta = options.eta;
  else
   eta = [];
  end % if
 end % if
 if isfield(options,'compeig')
  compeig = options.compeig;
 else
  compeig = 0;
 end % if
 if isfield(options,'adaptmu')
  adaptmu = options.adaptmu;
 else
  adaptmu = 0;
 end % if
 if adaptmu == 1
  compeig = 1;
 end % if
 if isfield(options,'adaptdel')
  adaptdel = options.adaptdel;
 else
  adaptdel = 1;
 end % if
end % if isempty

if timing == 1
 % if we measure the time we turn off printing, true residual norms, and error norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end % if
 trueres = 0;
 Anorm = 0;
 l2norm = 0;
end % if

if iprint == 1
 fprintf('\n gm_CG_options: \n\n')
 fprintf('  precond = %s \n',precond)
 fprintf('  epsi =    %12.5e \n',epsi)
 if isfield(options,'scaling')
  fprintf('  scaling = %d \n',scaling)
 end % if
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint  = %d \n',iprint)
 if isfield(options,'timing')
  fprintf('  timing  = %d \n',timing)
 end % if
 if isfield(options,'Anorm')
  fprintf('  Anorm  = %d \n',Anorm)
 end % if
 if isfield(options,'Anorm')
  fprintf('  l2norm  = %d \n',l2norm)
 end % if
 if isfield(options,'delay')
  fprintf('  delay   = %d \n',delay)
 end % if
 if isfield(options,'mu')
  fprintf('  mu      = %g \n',mu)
 end % if
 if isfield(options,'mu')
  fprintf('  eta     = %g \n',eta)
 end % if
 if isfield(options,'compeig')
  fprintf('  compeig = %g \n',compeig)
 end % if
 if isfield(options,'adaptmu')
  fprintf('  adaptmu = %g \n',adaptmu)
 end % if
 if isfield(options,'adaptdel')
  fprintf('  adaptdel= %g \n',adaptdel)
 end % if
 fprintf('-----------------------\n')
end % if

