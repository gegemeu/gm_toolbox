function [errorG,errorGRu]=gm_error_delay(eG,eGRu,errA,mu);
%GM_ERROR_DELAY relative error on the estimates

% Input:
% eG, eGRu = computed in gm_CG_errGR_precT_reconst
% errA = exact A-norm of the error 
% mu = estimate of the smallest eigenvalue
%
% Output:
% errorG = relative error for Gauss lower bound
% errorGRu = relative error for Gauss-Radau upper bound
% a row corresponds to a given iteration
% a column corresponds to a given delay

%
% Author G. Meurant
% Jan 2019
%

n = length(errA);
errorG = zeros(n,n-1);
errorGRu = zeros(n,n-1);

for k = 1:n-1
 errG = eG(k,:);
 ind = min(find(errG==0)) - 1;
 err = errA(k);
 errorG(k,1:ind) = abs(errG(1:ind) - err) ./ err;
 errGRu = eGRu(k,:);
 ind = min(find(errG==0)) - 1;
 errorGRu(k,1:ind) = abs(errGRu(1:ind) - err) ./ err;
end % for k



