function [x,tt,rate,op]=gm_CG_mflops(A,b,x0,nitmax,prints);
%GM_CG_MFLOPS conjugate gradient without preconditioning, computes the Mflops rate

% Input:
% A = symmetric positive definite matrix
% b = right-hand side
% x0 = starting vector
% nitmax = maximum number of iterations
% prints = 'print' printing of the results
% 
% Output:
% x = approximate solution
% tt = computing time
% rate = Mflops rate
% op = number of floating point operations

%
% Author G. Meurant
% May 2015
%  

iprint = 0;
if strcmpi(prints,'print') == 1
 iprint = 1;
end

x = x0;
r = b -A * x;
p = r;
rtr = r' * r;
nnza = nnz(A);
n = size(A,1);

tic

for k = 1:nitmax
 Ap = A * p;
 alp = rtr / (p' * Ap);
 x = x + alp * p;
 r = r - alp * Ap;
 rk = r' * r;
 bet = rk / rtr;
 rtr = rk;
 p = r + bet * p;
end % for k 

tt = toc;
op = nitmax * (2*nnza - n + 10 * n - 2);
rate = op / tt * 1e-6;

if iprint == 1
 fprintf('\n gm_CG_mflops, time = %g s, flops = %g, Mflops = %g \n',tt,op,rate)
end



