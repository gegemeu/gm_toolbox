function [bin,s,bine,binf] = fp642bin(x);
%FP642BIN decompose a double precision floating point number

% returns the sign bit, exponent, and mantissa of an
% IEEE 754 floating point value X, expressed as a binary array of
% length 64

if ~isreal(x) || numel(x) > 1 || ~isa(x,'double')
 error('Real, scalar, double input required.')
end
hex = num2hex(x);        % string of 16 hex digits for x
dec = hex2dec(hex');     % decimal for each digit (1 per row)
bin = dec2bin(dec,4);    % 4 binary digits per row
bitstr = reshape(bin',[1 64]);  % string of 64 bits in order


s = bitstr(1);
e = bitstr(2:12);
f = bitstr(13:64);

% s = bin2dec(s);  
% e = bin2dec(e) - 1023;
% %     f = bin2dec(f);
binf = zeros(1,52);
for k = 1:length(f)
 st = f(k);
 if strcmpi(st,'0') == 1
  binf(k) = 0;
 else
  binf(k) = 1;
 end % if
end % for
bine = zeros(1,11);
for k = 1:length(e)
 st = e(k);
 if strcmpi(st,'0') == 1
  bine(k) = 0;
 else
  bine(k) = 1;
 end % if
end % for
bin = [bine binf];
s = bin2dec(s); 
if s == 0
 bin = [0 bin];
else
 bin = [1 bin];
end % if


 
 
 
 
