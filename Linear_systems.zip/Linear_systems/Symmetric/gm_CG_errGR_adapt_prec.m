function [x,nit,iret,results] = gm_CG_errGR_adapt_prec(A,b,x0,options,params);
%GM_CG_ERRGR_ADAPT_PREC preconditioned conjugate gradient for a symmetric matrix A

% This is an implementation of PCG with bounds of the A-norm of the error

% Adaptive choice of the delay. We use a different delay for Gauss-Radau (delayg) and
%  the other bounds

% Estimates of the minimum and maximum eigenvalues and of the maximum attainable accuracy

% Error norm estimates and eigenvalues approximations based on the papers:

% G. Meurant and P. Tichy, On computing quadrature-based bounds for the A-norm of the error in conjugate gradients,
%                          Numerical Algorithms, v 62 n 2, (2012), pp. 163-191

% G. Meurant and P. Tich�, Approximating the extreme Ritz values and upper bounds for the A-norm of the error in CG,
%                          Numerical Algorithms, v 82 n 3, (2019), pp. 937-968

% G. Meurant, J. Pape� and P. Tich�, Accurate error estimation in CG,
%                                    Numerical Algorithms, v 88 n 3, (2021), pp. 1337-1359

% See also: G. Meurant and P. Tichy, Errot Norm Estimation In The Conjugate Gradient Algorithm,
%  SIAM (2024)

% Input:
% A = symmetric positive definite matrix
% b = right-hand side
% x0 = starting vector

% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
% epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% scaling = 1, diagonally scales the matrix before preconditioning (0)
% trueres = 1, computes the norm of b - A x_k (0)
% iprint = 1, print, residual norms at every iteration (0)
% timing = 1, time measurements (0)
% Anorm = 1, computes the A-norm of the error (0)
% l2norm = 1, computes the ell_2 norm of the error (0)
% compeig = 1, estimation of the smallest and largest eigenvalues of M^{-1}A
% adaptmu = adaptive values of the bounds for smallest and largest eigenvalues
% mu = initial value of the lower bound of the smallest eigenvalue of M^{-1}A (for Gauss-Radau)
% eta = initial value of the upper bound of the largest eigenvalue of M^{-1}A (for Gauss-Radau)
%       if not given, Gerschgorin bounds
% adaptdel = 1, adaptive different delays for Gauus and Gauss-Radau
% delay  = initial value of the delay, fixed if adaptdel = 0 (1)
%          we compute the bounds delay iterations before the current one
% precond = type of preconditioning ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
%  = 'gp' = preconditioner M given by the user

% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh', 'wl'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml' and 'dd'
%  = block size for block methods
%  = matrix M for 'gp'
%
% params.p1 and params.p2
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%  params.tb = block size for 'mb'
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code, = 0 if convergence

% results is a structure with the following fields:
% resn = ell_2 norm of computed residual
% resnt = ell_2 norm of the true residual (if trueres = 1)
% Anorm = A-norm of the error (if Anorm = 1)
% l2norm = ell_2 norm of the error (if l2norm = 1)
% estG  = Gauss lower bound of the A-norm of the error
% estGRl = Gauss-Radau lower bound of the A-norm of the error
% estGRu = Gauss-Radau upper bound of the A-norm of the error
% estAG = anti-Gauss estimate of the A-norm of the error
% estf, estfl, estgam, esty = different bounds of the A-norm obtained without a delay
% estback = estimate of the backward error
% max_acc_low, max_acc_low = estimates of the maximum attainable accuracy
% mineig, maxeig = estimates of the smallest and largest eigenvalues of M^{-1}A
% nitmin, nitmax = iteration numbers at which they were obtained
% timing = structure containing the init and iteration times,
%  the number of matrix-vector products, the number of dot products and the
%  number of matrix-vector products as a function of the iteration number,
%  if timing = 0 in options, same without the first two items

% Warning: Note that A-norm is computed from k=0, and the bounds from k=1
% So, be careful when comparing them

%
% Author G. Meurant
% January 2025
%

n = size(A,1);

if nargin == 1
 error('gm_CG_errGR_adapt_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_CG_errGR_adapt_prec: error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end
nx = length(x0);
if nlb ~= nx
 error('gm_CG_errGR_adapt_prec: error, the dimensions of x0 and b are not compatible')
end

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% ----------------------Initialization

% get the optional parameters and options
[epsi,nitmax,scaling,trueres,iprint,precond,timing,Anorm,l2norm,delay,mu,eta,compeig,adaptmu,adaptdel] = gm_CG_options(A,options);
delayg = delay;

if timing == 1
 tic
end

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 A_old = A;
 [A,dda] = gm_normaliz(A);
 b_old = b;
 b = dda .* b;
else
 dda = ones(n,1);
end

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond(A,precond,iprint,params);

[mu,eta] = gm_CG_mu_eta(A,mu,eta,cprec,options,params);

if iprint == 1  
 fprintf('  final initial values: \n')
 fprintf('  mu      = %12.5e \n',mu)
 fprintf('  eta     = %12.5e \n',eta)
end % if

% number of matrix-vector products and dot products
matvec = 0;
dotprod = 0;
matv = zeros(1,nitmax+1);

x = x0;
% initial residual vector
r = b - A * x;
matvec = matvec + 1;
nr = norm(r);
dotprod = dotprod + 1;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',nr)
end

% solve of M bm = b (for the estimate of the backward error)
bm = gm_solve_precond(A,b,precond,cprec,cprec_amg);
nbm = norm(bm);
dotprod = dotprod + 1;

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = nr;
end
resn = zeros(1,nitmax);
resn(1) = nr;

if Anorm == 1 || l2norm == 1
 xec = A \ b;
end % if
if Anorm == 1
 % A-norm of the error
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt( (xec - x)' * A * (xec -x));
else
 errA = [];
end % if
if l2norm == 1
 % ell_2 norm of the error
 errl2 = zeros(1,nitmax+1);
 errl2(1) = norm(xec - x);
else
 errl2 = [];
end % if

% this is used for the stopping criterion
resid = realmax;
epss = epsi^2;
matv(1) = matvec;

% solve of M z = r
z = gm_solve_precond(A,r,precond,cprec,cprec_amg);

p = z;
% number of iterations
nit = 0;
rtr = z' * r;
dotprod = dotprod + 1;

alp1 = 1;
bet1 = 0;

% init for the estimations of error
g = zeros(1,nitmax+1);
g1 = zeros(1,nitmax+1);
gamu = zeros(1,nitmax+1);
g2 = g1;
g4 = g1;
g1(1) = rtr / mu;
g2(1) = rtr / eta;
gamu(1) = 1 / mu;
estG = zeros(1,nitmax+1);
estGRl = estG;
estGRu = estG;
estAG = estG;
estgam = zeros(1,nitmax+1);
estf = estgam;
estfl = estgam;
esty = estgam;
est_back = estgam;
delai = delay * ones(1,nitmax+1);
delaig = delayg * ones(1,nitmax+1);
phi = zeros(1,nitmax);
phi(1) = 1;
muphi = zeros(1,nitmax);
muphi(1) = mu;
T = sparse(nitmax,nitmax);
Delta_eig = zeros(1,nitmax);
Delta_eigi = zeros(1,nitmax);
Delta = zeros(1,nitmax);
maxnx = realmin;
melem = gm_maxnzpr(A);
kk = 1; % for Gauss
kkr = 1; % for Gauss-Radau

conv_norm = 0;
conv_normi = 0;
keta = 0;
kmu = 0;
min_eigA = 1;
max_eigA = 1;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end % if
 tic
end % if

% -------------------------------------Iterations

while resid >= epss*nb2 && nit < nitmax
 
 nit = nit + 1;
 Ap = A * p;
 matvec = matvec + 1;
 alp = rtr / (p' * Ap);
 dotprod = dotprod + 1;
 
 x = x + alp * p;
 
 % computed residual
 r = r - alp * Ap;
 
 % solve of M z = r
 z = gm_solve_precond(A,r,precond,cprec,cprec_amg);
 
 rtrz = z' * r;
 rk = r' * r;
 dotprod = dotprod + 2;
 resid = rk;
 
 % residual ell_2 norm
 resn(nit+1) = sqrt(rk);
 % "true" residual norm
 if trueres == 1
  resnt(nit+1) = norm(b - A * x);
  matvec = matvec + 1;
  dotprod = dotprod + 1;
 end % if trueres
 % A-norm of the error
 if Anorm == 1
  errA(nit+1) = sqrt( (xec - x)' * A * (xec -x));
  matvec = matvec + 1;
  dotprod = dotprod + 1;
 end % if
 % ell_2 norm of the error
 if l2norm == 1
  errl2(nit+1) = norm(xec - x);
  dotprod = dotprod + 1;
 end % if
 
 bet = rtrz / rtr;
 rtro = rtr;
 rtr = rtrz;
 
 p = z + bet * p;
 
 if compeig == 1
  
  % estimate of max eig of M^{-1}A (Petr Tichy's formulas)
  
  % the following thresholds could be changed for some matrices
  eps_maxA = 1e-8;
  eps_minA = 1e-8;
  
  om = 1 / alp + bet1 / alp1;
  T(nit,nit) = om;
  gam2 = bet / alp^2;
  gam = sqrt(gam2);
  T(nit,nit+1) = gam;
  T(nit+1,nit) = gam;
  
  if conv_norm == 0
   if nit == 1
    c12 = 1;
    Delta_eig(1) = om;
   else
    omega = sqrt((Delta_eig(nit-1) - om)^2 + 4 * T(nit-1,nit)^2 * c12);
    c12 = (1 -((Delta_eig(nit-1) - om) / omega)) / 2;
    omc = omega * c12;
    Delta_eig(nit) = Delta_eig(nit-1) + omc;
    if iprint == 1
     fprintf('\n nit = %d, max eig, estimate = %g, rel diff = %g \n',nit,Delta_eig(nit),abs(omc)/Delta_eig(nit))
    end
    if abs(omc) / Delta_eig(nit) <= eps_maxA
     conv_norm = 1;
     max_eigA = Delta_eig(nit);
     % eventually change eta if adaptmu = 1
     eps_eta = 0.09; % safety factor
     if adaptmu == 1
      eta = max_eigA / (1 - eps_eta);
     end % if
     keta = nit;
     if iprint == 1
      nT = norm(full(T(1:nit,1:nit)));
      reldiff = (nT - max_eigA) / nT;
      fprintf('\n convergence largest eigenvalue, iteration %d, value = %g, rel diff = %g, eta = %g \n\n',nit,max_eigA,reldiff,eta)
     end
    end % if abs (convergence)
   end % if nit
  else
   Delta_eig(nit) = max_eigA;
  end % if conv_norm
  
  % estimate of min eig of M^{-1}A (Tichy's formulas)
  if conv_normi == 0
   if nit == 1
    Delta_eigi(nit) = alp;
    tau = alp;
    sigm = 0;
    si = 0;
    ci = 1;
    xi = 1;
   else
    sigm = -(si * sigm + ci * tau) * sqrt(alp * bet1 / alp1);
    xi = 1 + bet1 * xi;
    tau = alp * xi;
    Delta_eigt = Delta_eigi(nit-1) - tau;
    rh = Delta_eigt^2 + 4 * sigm^2;
    ci2 = (1 - Delta_eigt / sqrt(rh)) / 2;
    sc = sqrt(rh) * ci2;
    Delta_eigi(nit) = Delta_eigi(nit-1) + sc;
    si = sqrt(1 - ci2);
    ci = sign(sigm) * abs(sqrt(ci2));
    if iprint == 1
     fprintf('\n nit = %d, min eig, estimate = %12.5e, rel diff = %g \n\n',nit,1/Delta_eigi(nit),abs(sc)/Delta_eigi(nit))
    end
    if abs(sc) / Delta_eigi(nit) <= eps_minA
     conv_normi = 1;
     min_eigA = 1 / Delta_eigi(nit);
     % eventually change mu, eps_mu safety factor
     %     eps_mu = 0.07;
     eps_mu = 0.02;
     %     eps_mu = 0.09;
     if adaptmu == 1
      mu = min_eigA / (1 + eps_mu);
     end % if
     kmu = nit;
     if iprint == 1
      nT = min(eig(full(T(1:nit,1:nit))));
      reldiff = abs(nT - min_eigA) / nT;
      fprintf('\n convergence smallest eigenvalue, iteration %d, value = %g, rel diff = %g, mu = %g \n\n',nit,min_eigA,reldiff,mu)
     end
    end % if abs (convergence)
   end % if nit
  else
   Delta_eigi(nit) = 1 / min_eigA;
  end % if conv_normi
  
  % estimate of backward error
  nx = norm(x);
  dotprod = dotprod + 1;
  est_back(nit) = sqrt(rtr) / (Delta_eig(nit) * nx + nbm);
  
  % estimates of maximum attainable accuracy
  maxnx = max(maxnx,nx);
  nA = Delta_eig(nit);
  max_acc_low = eps * (nb + nA * maxnx) / 2;
  max_acc = eps * (nb + (melem + 2) * nA * maxnx) / 2;
  
 end % if compeig (computation of the estimates of the eigenvalues)
 
 bet1 = bet;
 alp1 = alp;
 
 % estimates of A-norm of the error
 if nit > 1
  phi(nit) = phi(nit-1) / (phi(nit-1) + bet); % phi function for some bounds
 end
 muphi(nit+1) = mu + muphi(nit) * bet;
 g(nit) = alp * rtro;
 d1 = g1(nit) - g(nit);
 d2 = g2(nit) - g(nit);
 gamu(nit+1) = (gamu(nit) - alp) / (mu * (gamu(nit) - alp) + bet); % for Gauss-Radau upper bound
 if gamu(nit)-alp <= 0
  gamu(nit+1) = gamu(nit);
  if iprint == 1
   fprintf('\n Caution negative difference gamu(nit)-alp, iter = %d \n',nit)
  end % if
 end % if
 % mu is an approximate value of the smallest eigenvalue
 g1(nit+1) = rtr * d1 / (mu * d1 + rtr);                    % Gauss-Radau upper bound (mu)
 g2(nit+1) = rtr * d2 / (eta* d2 + rtr);                    % Gauss-Radau lower bound (eta)
 if nit > 1
  g4(nit+1) = 2 * g(nit) * g(nit-1) / (g(nit-1)-g(nit));
 end
 
 % upper bound independant of the delay
 if g1(nit+1) >= 0
  estgam(nit) = sqrt(g1(nit+1)); % this is the bound with gamma_k^(gamma) (d=0)
 else
  if nit > 1
   estgam(nit) = estgam(nit-1);
  else
   estgam(nit) = 0;
  end % if nit
 end % if g1
 
 % Tichy's upper bound of the GR upper bound with gamma^(phi)
 estf(nit) = sqrt(rtr * phi(nit) / mu);
 estfl(nit) = sqrt(rtr * phi(nit) / eta);
 if nit > delay
  to = estf(nit) / estf(nit-delay); % estimate of the decrease
  to = min(to,0.99);
 else
  to = 0;
 end % if
 
 if adaptdel == 1
  tauS = 0.25; % thhreshold for the changes of delay (could be changed)
  Delta(nit) = alp * rtro;
  curve(nit) = 0;
  curve = curve + Delta(nit);
  
  if nit > 1
   S = findS(curve,Delta,kk);
   num = S * Delta(nit);
   den = sum( Delta(kk:nit-1));
   
   while (delay >= 0) && (num/den <= tauS)
    if kk > 1
     kkk = kk - 1;
     % update the bounds
     delai(kkk) = delay;
     estG(kkk) = sqrt(den);
     esty(kkk) = estG(kkk) / (1 - to);
     if den + g2(nit) > 0
      estGRl(kkk) = sqrt(den + g2(nit));     % Gauss-Radau lower bound
     else
      estGRl(kkk) = estG(kkk);
     end % if den
     if den + g4(nit) > 0
      estAG(kkk) = sqrt(den + g4(nit));      % Anti-Gauss
     else
      estAG(kkk) = estG(kkk);
     end % if den
     if iprint == 1
      delayb = delay + 1;
      if nit > delayb
       if Anorm == 1
        fprintf(' A-norm at it %d = %12.5e \n',kkk,errA(kk))
       end % if
       fprintf('\n Estimates of A-norm at it %d, delay = %d:  \n',kkk,delayb)
       fprintf('           Gauss = %12.5e \n',estG(kkk))
       fprintf('           Gauss-Radau lower = %12.5e \n',estGRl(kkk))
       fprintf('           anti-Gauss = %12.5e \n',estAG(kkk))
       fprintf('           esty upper bound of A-norm = %12.5e\n\n',esty(kkk))
      end % if nit
     end % if iprint
    end % if kk
    kk = kk + 1;
    delay = max(delay - 1,0);
    den = sum( Delta(kk:nit-1) );
   end % while
   delay = delay + 1;
   
   % Gauss-Radau upper bound
   den = sum( Delta(kkr:nit));
   num = rtro * (gamu(nit) - alp);
   ratg = abs(num) / den;
   while (nit > max(1,kkr)) && (ratg <= tauS)
    omu = sum(Delta(kkr:nit-1)) + g1(nit);
    if kkr > 1
     estGRu(kkr-1) = sqrt(abs(omu));
     if iprint == 1
      if Anorm == 1
       fprintf(' A-norm at it %d = %12.5e \n',kkr-1,errA(kkr))
      end % if
      fprintf('\n At iteration %d, Gauss-Radau at iteration = %d, est = %12.5e, delay = %d \n\n',nit,kkr-1,estGRu(kkr-1),nit-kkr+1)
     end % if
    else
     estGRu(kkr) = sqrt(abs(omu));
    end
    delayg = nit - kkr;
    delaig(kkr) = delayg;
    kkr = kkr + 1;
    den = sum( Delta(kkr:nit-1));
    ratg = num / den;
   end % while
   
  end % if nit (end of adaptive delays)
  
 else % if fixed delay, same for Gauss and Gauss-Radau
  % update all the estimates
  if nit > delay
   [estG,estGRu,estGRl,estAG] = update_est(nit,delay,estG,estGRu,estGRl,estAG,g,g1,g2,g4);
   esty(nit-delay) = estG(nit-delay) / (1 - to);
  end % if nit
  
 end % if adaptdel
 
 % output at iteration nit
 if iprint == 1
  nresidu = sqrt(resid);
  
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nit,nresidu,nresidu/nb);
  if trueres == 1
   fprintf('           true residual norm = %12.5e \n',resnt(nit+1))
  end
  if Anorm == 1
   fprintf('\n A-norm at it %d = %g \n',nit,errA(nit+1))
  end % if
  fprintf('           f upper bound of A-norm = %12.5e \n',estf(nit))
  fprintf('           f lower bound of A-norm = %12.5e \n',estfl(nit))
  fprintf('           gam upper bound of A-norm = %12.5e \n',estgam(nit))
  if compeig == 1
   fprintf('           backward error = %12.5e \n',est_back(nit))
   fprintf('           max_acc_low = %12.5e, max acc_up = %12.5e \n',max_acc_low,max_acc)
  end % if
  
  fprintf('--------------------------------------------------------\n') 
 end % if iprint
 
 matv(nit+1) = matvec; % number of matrix-vector products since the beginning
 
end % iterations (while)

% Results in a structure
resn = resn(1,1:nit+1);
results.resn = resn;
estG = estG(1,1:nit+1);
results.estG = estG;
estGRl = estGRl(1,1:nit+1);
results.estGRl = estGRl;
estGRu = estGRu(1,1:nit+1);
results.estGRu = estGRu;
estAG = estAG(1,1:nit+1);
results.estAG = estAG;
if compeig == 1
 results.max_acc_low = max_acc_low;
 results.max_acc = max_acc;
 est_back = est_back(1,1:nit+1);
 results.estback = est_back;
 results.mu = mu;
 results.eta = eta;
 results.maxeig = max_eigA;
 results.nitmax = keta;
 results.mineig = min_eigA;
 results.nitmin = kmu;
end % if
estf = estf(1,1:nit+1);
results.estf = estf;
estfl = estfl(1,1:nit+1);
results.estfl = estfl;
estgam = estgam(1,1:nit+1);
results.estgam = estgam;
esty = esty(1,1:nit+1);
results.esty = esty;
delai = delai(1:nit);
results.delai = delai;
delaig = delaig(1:nit);
results.delaig = delaig;
matv = matv(1,1:nit+1);
if trueres == 1
 results.resnt = resnt(1,1:nit+1);
else
 results.resnt = [];
end % if
if Anorm == 1
 results.Anorm = errA(1,1:nit+1);
else
 results.Anorm = [];
end % if
if l2norm == 1
 results.l2norm = errl2(1,1:nit+1);
else
 results.l2norm = [];
end % if

iret = 0; % return code
if nit == nitmax
 iret = 2;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end % if
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:nit+1));
end % if timing

if iprint == 1
 if nit == nitmax
  fprintf('\n No convergence after %d iterations \n',nit)
 end % if
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',nit)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
 trueresi = norm(b_old - A_old * x);
 if iprint >= 1
  fprintf('\n ---We are back to the original scale \n\n')
  fprintf(' norm of true residual for x = %12.5e \n\n',trueresi);
  fprintf(' relative residual = %12.5e \n',sqrt(resid/nb));
 end % if
end % if scaling

end % function

function [estG,estGRu,estGRl,estAG] = update_est(ni,delay,estG,estGRu,estGRl,estAG,g,g1,g2,g4);
% update the estimates of the A-norm of the error

t = sum(g(ni-delay+1:ni));
estG(ni-delay) = sqrt(t); % ... Gauss
if t + g1(ni+1) > 0
 estGRu(ni-delay) = sqrt(t + g1(ni+1));     % ...   Gauss-Radau upper bound
else
 estGRu(ni-delay) = estG(ni-delay);
end % if t
if t + g2(ni+1) > 0
 estGRl(ni-delay) = sqrt(t + g2(ni+1));     % ...   Gauss-Radau lower bound
else
 estGRl(ni-delay) = estG(ni-delay);
end % if t
if t + g4(ni+1) > 0
 estAG(ni-delay) = sqrt(t + g4(ni+1));      % ...   Anti-Gauss
else
 estAG(ni-delay) = estG(ni-delay);
end % if t

end % function

function [S] = findS(curve,Delta,kk)
% adaptive delay for Gauss lower bound
% ... find the safety factor S using the tolerance 1e-4

ind = find (( curve(kk)./ curve) <= 1e-4, 1, 'last');
if isempty (ind)
 ind = 1;
end % if
endc = length(curve);
S = max( curve(ind:endc -1) ./ Delta(ind :endc -1));

end % function



