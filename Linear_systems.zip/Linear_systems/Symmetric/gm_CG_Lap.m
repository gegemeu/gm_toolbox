function [x,nit,iret,resn,resnt] = gm_CG_Lap(m,b,x0,epsi,nitmax,trueress,iprints);
%GM_CG_LAP conjugate gradient for the Laplacian matrix without preconditioning

% Poisson equation in two dimensions

% The matrix is not stored. This allows to solve very large problems
% When solving -Delta u = f, the right-hand side b has to be such that
% b_i = h^2 f_i where h = 1 / (m + 1) is the mesh size

% Input:
% m = nb of points in one direction. The mesh of the unit square is m x m
% b = right-hand side
% x0 = starting vector
% epsi = convergence threshold
% nitmax = maximum number of iterations
% trueress = 'trueres', computation of the true residual norm
% iprints = 'print', printing of residual norms
%
% Ouput: 
% x = approximate solution
% nit = number of iterations
% iret = return code
% resn = l_2 norm of computed residual
% resnt = l_2 norm of the true residual (if 'trueres')

%
% Author G. Meurant
% June 2015
%

n = m^2;

nb = length(b);
if nb ~= n
 error('gm_CG_Lap: the length of b must be m^2')
end
nx = length(x0);
if nx ~= n
 error('gm_CG_Lap: the length of x0 must be m^2')
end


if nargin < 3
 x0 = zeros(n,1);
end

if nargin < 4
 epsi = 1e-10;
end

if nargin < 5
 nitmax = n;
end

if nargin > 5 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 6 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

x = x0;
resn = zeros(1,nitmax);
if trueres == 1
 resnt = zeros(1,nitmax);
else
 resnt = [];
end

r = 4 * x;
p1 = [x(2:n);0];
p1(m:m:n) = zeros(size(p1(m:m:n),1),1);
pm = [x(m+1:n); zeros(m,1)];
pm1 = [0; x(1:n-1)];
pm1(m+1:m:n) = zeros(size(pm1(m+1:m:n),1),1);
pmm = [zeros(m,1);x(1:n-m)];
r = r - (p1 + pm + pm1 + pmm);
r = b - r;
p = r;

iret = 0;
% number of iterations
nit = 0;
r0 = r' * r;
rtr = r0;
nr0 = sqrt(r0);
resn(1) = nr0;
if trueres == 1
 resnt(1) = nr0;
end
if iprint == 1
 fprintf('\n initial residual= %g \n',nr0);
end
eps2 = epsi * epsi;
resid = 1;
nb = norm(b);
nb2 = nb^2;

while resid >= eps2 * nb2 && nit < nitmax
 nit = nit + 1;
 
 % matrix-vector multiply without additional storage
 Ap = 4 * p;
 p1 = [p(2:n);0];
 p1(m:m:n) = zeros(size(p1(m:m:n),1),1);
 pm = [p(m+1:n); zeros(m,1)];
 pm1 = [0; p(1:n-1)];
 pm1(m+1:m:n) = zeros(size(pm1(m+1:m:n),1),1);
 pmm = [zeros(m,1);p(1:n-m)];
 Ap = Ap - (p1 + pm + pm1 + pmm);
 
 alp = rtr / (p' * Ap);
 
 x = x + alp * p;
 r = r - alp * Ap;
 
 if trueres == 1
  % true residual
  tr = 4 * x;
  p1 = [x(2:n);0];
  p1(m:m:n) = zeros(size(p1(m:m:n),1),1);
  pm = [x(m+1:n); zeros(m,1)];
  pm1 = [0; x(1:n-1)];
  pm1(m+1:m:n) = zeros(size(pm1(m+1:m:n),1),1);
  pmm = [zeros(m,1);x(1:n-m)];
  tr = tr - (p1 + pm + pm1 + pmm);
  tr = b - tr;
  resnt(nit+1) = norm(tr);
 end % if trueres
 
 rk = r' * r;
 resid = rk;
 resn(nit+1) = sqrt(rk);

 bet = rk / rtr;
 rtr = rk;
 
 p = r + bet * p;
 
 if iprint == 1
  nresidu = resn(nit+1);
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nit,nresidu,nresidu/nb)
 end % if iprint
 
end

if nit >= nitmax
 iret = 2;
end

