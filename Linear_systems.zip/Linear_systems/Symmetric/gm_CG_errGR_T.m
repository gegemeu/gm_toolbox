function [x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,time_mat,errA]=gm_CG_errGR_T(A,b,x0,epsi,nitmax,scalings,trueress,iprints,precond,delay,mu,eta,varargin);
%GM_CG_ERRGR_T  conjugate gradient for a matrix A without preconditioning A-norm bounds (new version), exact error norm
% with estimates of the A-norm of the error (Gauss, Gauss-Radau, Gauss-Lobatto, anti-Gauss)
% --------this function is for testing since we compute the A-norm of the error

% This is a reliable implementation of CG with  bounds of the A-norm of the error

% Error norm estimates based on the paper:
% G. Meurant and P. Tichy, On computing quadrature-based bounds for the A-norm of the error in conjugate gradients, 
%                          Numerical Algorithms, v 62 n 2, (2012), pp 163-191

%
% Input:
% A = symmetric positive definite matrix
% b = right hand side
% x0 = starting vector
% epsi = threshold for stopping criterion
% (stop if norm(r^k)<= epss norm(r^0) or nit > nitmax
% nitmax = maximum number of iterations
%  if nitmax < 0 we do time measurements
% scalings = 'scaling', diagonally scales the matrix before preconditioning
% trueress = 'trueres' computes the norm of b - A x_k
% iprints = 'print' print residual norms at every iteration
% precond = type of preconditioning
%  = 'no' M = I
% delay = we look delay iterations back for the error norm bounds
% mu, eta = estimates of the smallest and largest eigenvalues
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code
% resn = l_2 norm of computed residual
% resnt = l_2 norm of the true residual (if 'trueres')
% estG = Gauss lower bound on the A-norm of the error
% estGRl = Gauss-Radau lower bound 
% estGRu = Gauss-Radau upper bound 
% estGL = Gauss-Lobatto bound
% estAG = anti Gauss estimate 
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items
% errA = A-norm of the error

%
% Author G. Meurant (with P. Tichy)
% March 2001, modified Feb 2009
% May 2015
%

n = size(A,1);

if nargin < 3
 x0 = zeros(n,1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_CG_errGR_T: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_CG_errGR_T: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 6
 % no scaling
 scaling = 0;
end
if nargin < 7
 % do not compute the true residual norm
 trueres = 0;
end
if nargin < 8
 % no printing
 iprint = 0;
end
if nargin < 9
 % no preconditioning
 precond = 'no';
end
if nargin < 10
 delay = 1;
end

if nargin < 11
 % use the Gerschgorin bounds for mu and eta
 [mu,eta] = gm_gerschgo(A);
 mu = max(10*eps,mu);
end

if nargin > 5 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 6 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 7 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

precond = 'no';

if iprint == 1
 fprintf('\n gm_CG_errGR_T: \n\n')
 fprintf('  precond = %s \n',precond)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  delay = %d \n',delay)
 fprintf('  mu = %g \n',mu)
 fprintf('  eta = %g \n',eta)
end

x = [];
nit = 0;
iret = 0;
resn = zeros(1,nitmax);
resnt = zeros(1,nitmax);
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 A_old = A;
 [A,dda] = gm_normaliz(A);
 b_old = b;
 b = dda .* b;
else
 dda = ones(n,1);
end

% "exact" solution for testing of the estimates
xec = A \ b;
errA = zeros(1,nitmax);

% ----------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;
matv = zeros(1,nitmax+1);

xin = zeros(n,1);

x = x0;
% init residual vector
r = b - A * x;
matvec = matvec + 1;

nr = norm(r);
dotprod = dotprod + 1;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',nr)
end

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = nr;
end

resn = zeros(1,nitmax);
resn(1) = nr;

resid = realmax;
epss = epsi^2;
matv(1) = matvec;

p = r;
% number of iterations
ni = 0;
r0 = r' * r;
dotprod = dotprod + 1;
rtr = r' * r;

% init for estimation of error
g = zeros(1,nitmax+1);
g1 = zeros(1,nitmax+1);
g2 = g1;
g3 = g1;
g4 = g1;
g1(1) = rtr / mu; 
g2(1) = rtr / eta;
estG = zeros(1,nitmax-delay);
estGRl = estG;
estGRu = estG;
estGL = estG;
estAG = estG;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% -------------------------------------Iterations

while resid >= epss*r0 && ni < nitmax
 
 ni = ni + 1;
 Ap = A * p;
 matvec = matvec + 1;
 alp = rtr / (p' * Ap);
 dotprod = dotprod + 1;

 x = x + alp * p;
 
 % computed residual
 r = r - alp * Ap;
 
 rtrz = r' * r;
 rk = r' * r;
 dotprod = dotprod + 1;
 resid = rk;
 % residual l_2 norm
 resn(ni+1) = sqrt(rk);
 % A-norm of the error
 errA(ni) = sqrt((x - xec)' * A * (x - xec));
 
 % "true" residual norm
 if trueres == 1
  resnt(ni+1) = norm(b - A * x);
 end % if trueres
  
 bet = rtrz / rtr;
 rtro = rtr;
 rtr = rtrz;
 
 p = r + bet * p;
 
 % estimates of A-norm of the error
 g(ni) = alp * rtro;
 d1 = g1(ni) - g(ni);
 d2 = g2(ni) - g(ni);
 g1(ni+1) = rtr * d1 / (mu * d1 + rtr);                    % Gauss-Radau upper bound (mu)
 g2(ni+1) = rtr * d2 / (eta* d2 + rtr);                    % Gauss-Radau lower bound (eta)
 g3(ni+1) = (eta - mu) * d1 * d2 / (eta * d2 - mu * d1);   % Gauss-Lobatto upper
 if ni > 1
  g4(ni+1) = 2 * g(ni) * g(ni-1) / (g(ni-1)-g(ni));
 end
 
 % estG  = Gauss lower bound
 % gestAG = anti-Gauss estimate
 if ni > max([delay 1])
  t = sum(g(ni-delay+1:ni));
  estG(ni-delay) = sqrt(t);
  if t + g1(ni+1) > 0
   estGRu(ni-delay) = sqrt(t + g1(ni+1));     % ...   Upper bound
  else
   estGRu(ni-delay) = estG(ni-delay);
  end % if t
  if t + g2(ni+1) > 0
   estGRl(ni-delay) = sqrt(t + g2(ni+1));     % ...   Lower bound
  else
   estGRl(ni-delay) = estG(ni-delay);
  end % if t
  if t + g3(ni+1) > 0
   estGL(ni-delay) = sqrt(t + g3(ni+1));      % ...   Gauss-Lobbato
  else
   estGL(ni-delay) = estG(ni-delay);
  end % if t
  if t + g4(ni+1) > 0
   estAG(ni-delay) = sqrt(t + g4(ni+1));     % ...   Anti-Gauss
  else
   estAG(ni-delay) = estG(ni-delay);
  end % if t
  
 end % if ni
 
 % output 
 if iprint == 1
  nresidu = sqrt(resid);
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',ni,nresidu,nresidu/sqrt(r0))
  if ni > delay
   fprintf(' Estimates of A norm at it %d:  \n',ni-delay)
   fprintf('  Gauss = %g, anti Gauss = %d \n',estG(ni-delay),estAG(ni-delay))
   fprintf('  Gauss-Radau lower = %g, upper = %g \n',estGRl(ni-delay),estGRu(ni-delay))
   fprintf('  Gauss-Lobatto = %g \n\n',estGL(ni-delay))
   fprintf(' True error norm = %g \n\n',errA(ni-delay))
  end % if ni
 end % if iprint
 
 matv(ni+1) = matvec;
 
end % iterations

resn = resn(1,1:ni+1);
errA= errA(1,1:ni);
if trueres == 1
 resnt = resnt(1,1:ni+1);
else 
 resnt = [];
end

nit = ni;
iret = 0;
if ni == nitmax
 iret = 2;
end

estG = estG(1:ni-delay);
estGRl = estGRl(1:ni-delay);
estGRu = estGRu(1:ni-delay);
estGL = estGL(1:ni-delay);
estAG = estAG(1:ni-delay);

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
end % if timing

if iprint == 1
 if ni == nitmax
  fprintf('\n No convergence after %d iterations \n',ni)
 end
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',ni)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint


% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
 trueresi = norm(b_old - A_old * x);
 
 if iprint >= 1
  fprintf('\n ---We are back to the original scale \n\n')
  fprintf(' norm of true residual for x = %g \n\n',trueresi);
  fprintf(' relative residual = %g \n',sqrt(resid/r0));
 end
end % if scaling


