function gm_Ex_maxacc(idiffu)

% Examples with improvements of the maximum attainable accuracy
% Symmetric matrices

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGolbalStream(s);
rng('default');

switch idiffu
 
 case 1
  
  fprintf('\n 2D diffusion problem \n')
  
  % 2D diffusion problems
  % iex = Pb number, = 1 Poisson
  % 10 <= iex <= 27 non constant diffusion coefficients (see gm_xk, gm_yk)
  % m = mesh m x m
  
  iex = 1;
  m = 30;
  Ex = ['Pb' num2str(iex) ' ' num2str(m)];
  mat = Ex;
  A = gm_mat_diffu(iex,m);
  b = randn(m^2,1);
  b = b / norm(b);
  x0 = zeros(m^2,1);
  
  if iex == 1
   fprintf('\n Poisson problem, %g x %g mesh \n',m,m)
  end
  
 case 2
  
  fprintf('\n Strakos matrix \n')
  
  % Strakos diagonal matrix
  % since the matrix is diagonal, do not use any preconditioner
  
  % n = order of the matrix
  n = 100;
  % lmin = smallest eigenvalue
  lmin = 0.1;
  % lmax = largest eigenvalue
  lmax = 100;
  % rho = exponential factor
  rho = 0.9;
  Ex = ['Strakos' ' ' num2str(n)];
  mat = Ex;
  [A,lamb] = gm_mat_strakos(n,lmin,lmax,rho);
  b = randn(n,1);
  b =b / norm(b);
  x0 = zeros(n,1);
  
 case 0
  
   Lap400 = 'gm_Lap400';
  
  % SuiteSparse problems
  
  bus662 = 'gm_662_bus_662';
  
  bus1138 = 'gm_1138_bus_1138';
  
  bcsstk03 = 'gm_bcsstk03_112';
  
  bcsstk07 = 'gm_bcsstk07_420';
  
  bcsstk22 = 'gm_bcsstk22_138';
  
  mesh2em5 = 'gm_mesh2em5_306';
  
  nos1 = 'gm_nos1_237';
  
  nos2 = 'gm_nos2_957';
  
  nos5 = 'gm_nos5_468';
  
  nos6 = 'gm_nos6_675';
  
  nos7 = 'gm_nos7_729';
  
  plat362 = 'gm_plat362_362';
  
  plat1919 = 'gm_plat1919_1919';
  
  % Choose the file
  
  %   Ex = dubcova;
  %   mat = 'dubcova';
  %    Ex = bus1138;
  %    mat = 'bus1138';
  Ex = Lap400;
  mat = 'Lap400';
  
  % you may have to change the path
  file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Symmetric\' Ex];
  
  load(file)
  
end % switch

n = size(A,1);
nnzA = nnz(A);

% Stopping threshold
epss = 1e-20;
% Preconditioner
precond = 'no';
% Maximum number of iterations
nitmax = 150;
if idiffu == 2
 nitmax = 250;
end % if
% tb (see comments in gm_initprec)
tb = 0.001;
% tb = [0.01,20];
% tb = 2;
% if needed the parameter has to be given in a structure params last argument of the CG codes
% params = struct('p1',tb)

params = struct('p1',tb');
if strcmpi(precond,'ml') == 1
 params = [];
end % if

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'ch') == 1
 fprintf('\n IC threshold = %g \n',tb)
end

if strcmpi(precond,'lv') == 1
 fprintf('\n IC level = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g \n',tb)
end

if strcmpi(precond,'sa') == 1
 fprintf('\n SAINV threshold = %g \n',tb)
end

if strcmpi(precond,'bc') == 1
 fprintf('\n block size = %d \n',tb)
end

muu = 1e-5;
etaa = 2;

% adaptive value of mu, fixed delay (default = 1)

options = struct('epsi',epss,'nitmax',nitmax,'iprint',0,'trueres',1,'Anorm',1,'precond',precond,...
 'adaptmu',1,'mu',muu,'eta',etaa,'adaptdel',0);

[x,nit,iret,results] = gm_CG_errGR_adapt_prec(A,b,x0,options,params);
resn = results.resn;
resnt = results.resnt;
errA  = results.Anorm;
mu = results.mu;
eta = results.eta;

fprintf('\n nit = %g, res norm = %g, true res norm = %g, A-norm err = %g \n',nit,resn(nit+1),resnt(nit+1),errA(nit))

fprintf('\n mu = %g, eta = %g \n',mu,eta)

% Van der Vorst improvement

[x,nit,iret,results] = gm_CG_errGR_VDV_prec(A,b,x0,options,params);
resntV = results.resnt;

semilogy(resn)
hold on
semilogy(resnt,'r')
semilogy(resntV,'g')

% Meurant's improvement

[x,nit,iret,results] = gm_CG_errGR_GM_prec(A,b,x0,options,params);
resntA = results.resnt;

fprintf('\n resnt = %12.5e, resnt VDV = %12.5e, resnt GM = %12.5e \n',resnt(end),resntV(end),resntA(end))

semilogy(resntA,'m')
legend('resn','resnt','resntVDV','resntGM')
title(mat)



