function gm_Ex_timeS(idiffu)

% Examples with time measurements
% Symmetric matrices

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default');

switch idiffu
 
 case 1
  
  fprintf('\n 2D diffusion problem \n')
  
  % 2D diffusion problems
  % iex = Pb number, = 1 Poisson
  % 10 <= iex <= 27 non constant diffusion coefficients (see gm_xk, gm_yk)
  % m = mesh m x m
  
  iex = 1;
  m = 30;
  Ex = ['Pb' num2str(iex) ' ' num2str(m)];
  mat = Ex;
  A = gm_mat_diffu(iex,m);
  b = randn(m^2,1);
  b = b / norm(b);
  x0 = zeros(m^2,1);
  
  if iex == 1
   fprintf('\n Poisson problem, %g x %g mesh \n',m,m)
  end
  
 case 2
  
  fprintf('\n Strakos matrix \n')
  
  % Strakos diagonal matrix
  % since the matrix is diagonal, do not use any preconditioner
  
  % n = order of the matrix
  n = 100;
  % lmin = smallest eigenvalue
  lmin = 0.1;
  % lmax = largest eigenvalue
  lmax = 100;
  % rho = exponential factor
  rho = 0.9;
  Ex = ['Strakos' ' ' num2str(n)];
  mat = Ex;
  [A,lamb] = gm_mat_strakos(n,lmin,lmax,rho);
  b = randn(n,1);
  b =b / norm(b);
  x0 = zeros(n,1);
  
 case 0
  
  Lap400 = 'gm_Lap400';
  
  % SuiteSparse problems
  
  bus662 = 'gm_662_bus_662';
  
  bus1138 = 'gm_1138_bus_1138';
  
  bcsstk03 = 'gm_bcsstk03_112';
  
  bcsstk07 = 'gm_bcsstk07_420';
  
  bcsstk22 = 'gm_bcsstk22_138';
  
  mesh2em5 = 'gm_mesh2em5_306';
  
  nos1 = 'gm_nos1_237';
  
  nos2 = 'gm_nos2_957';
  
  nos5 = 'gm_nos5_468';
  
  nos6 = 'gm_nos6_675';
  
  nos7 = 'gm_nos7_729';
  
  plat362 = 'gm_plat362_362';
  
  plat1919 = 'gm_plat1919_1919';
  
  % Choose the file
  
%   Ex = bus662;
%   mat = 'bus 662';
  %   Ex = dubcova;
  %   mat = 'dubcova';
  %    Ex = bus1138;
  %    mat = 'bus1138';
  Ex = Lap400;
  mat = 'Lap400';
  
  % you have to change the path
  file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Symmetric\' Ex];
  
  load(file)
  
end % switch

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end

xec = A \ b;

% Stopping threshold
epss = 1e-15;
% Preconditioner
precond = 'no';
% Maximum number of iterations
nitmax = 500;
% tb (see comments in gm_init_precond)
tb = 0.001;
% tb = [0.01,20];
% tb = 2;
% if needed the parameter has to be given in a structure params last argument of the CG codes
% params = struct('p1',tb)

met = zeros(15,11);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'ch') == 1
 fprintf('\n IC threshold = %g \n',tb)
end

if strcmpi(precond,'lv') == 1
 fprintf('\n IC level = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'sa') == 1
 fprintf('\n SAINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'bc') == 1
 fprintf('\n block size = %d \n',tb)
end

% CG

met(1,1:2) = 'CG';

options = struct('epsi',epss,'nitmax',nitmax,'trueres',0,'precond',precond);

[x,nit,iret,results] = gm_CG_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xcg,nitcg,iret,results] = gm_CG_prec(A,b,x0,options);
end
resncg = results.resn;

tcg = toc;
tcg = tcg / repeat;
errcg = norm(xcg - xec);

fprintf('\n Meth          It      Res          Err           Time   \n\n')
fprintf(' CG          %4d  %11.4e   %11.4e   %11.4e \n\n',nitcg,resncg(nitcg+1),errcg,tcg)

% CG 3 term recurrence

met(2,1:4) = 'CG3T';

[xcg3,nitcg3,iret,results] = gm_CG_3t_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xcg3,nitcg3,iret,results] = gm_CG_3t_prec(A,b,x0,options);
end
resncg3 = results.resn;

tcg3 = toc;
tcg3 = tcg3 / repeat;
errcg3 = norm(xcg3 - xec);

fprintf(' CG3T        %4d  %11.4e   %11.4e   %11.4e \n\n',nitcg3,resncg3(nitcg3+1),errcg3,tcg3)

% CG true residual

met(3,1:4) = 'CGTR';

[xcgt,nitcgt,iret,results] = gm_CG_TR_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xcgt,nitcgt,iret,results] = gm_CG_TR_prec(A,b,x0,options);
end
resncgt = results.resn;

tcgt = toc;
tcgt = tcgt / repeat;
errcgt = norm(xcgt - xec);

fprintf(' CGTR        %4d  %11.4e   %11.4e   %11.4e \n\n',nitcgt,resncgt(nitcgt+1),errcgt,tcgt)

% CG with reorthogonalization

met(4,1:3) = 'CGR';

[xcgr,nitcgr,iret,results] = gm_CG_reorth_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xcgr,nitcgr,iret,results] = gm_CG_reorth_prec(A,b,x0,options);
end
resncgr = results.resn;

tcgr = toc;
tcgr = tcgr / repeat;
errcgr = norm(xcgr - xec);

fprintf(' CGR         %4d  %11.4e   %11.4e   %11.4e \n\n',nitcgr,resncgr(nitcgr+1),errcgr,tcgr)

% MINRES

met(5,1:6) = 'MINRES';

[xm,nitm,iret,results] = gm_Minres_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xm,nitm,iret,results] = gm_Minres_prec(A,b,x0,options);
end
resnm = results.resn;

tm = toc;
tm = tm / repeat;
errm = norm(xm - xec);

fprintf(' MINRES      %4d  %11.4e   %11.4e   %11.4e \n\n',nitm,resnm(nitm+1),errm,tm)

% Conjugate residual

met(6,1:2) = 'CR';

[xcr,nitcr,iret,results] = gm_CR_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xcr,nitcr,iret,results] = gm_CR_prec(A,b,x0,options);
end
resncr  = results.resn;

tcr = toc;
tcr = tcr / repeat;
errcr = norm(xcr - xec);

fprintf(' CR          %4d  %11.4e   %11.4e   %11.4e \n\n',nitcr,resncr(nitcr+1),errcr,tcr)

% SYMMQR

met(7,1:6) = 'SYMMQR';

[xs,nits,iret,results] = gm_SYMMQR_prec(A,b,x0,options);

tic
for k = 1:repeat
 [xs,nits,iret,results] = gm_SYMMQR_prec(A,b,x0,options);
end
resns = results.resn;

ts = toc;
ts = ts / repeat;
errs = norm(xs - xec);

fprintf(' SYMMQR      %4d  %11.4e   %11.4e   %11.4e \n\n',nits,resns(nits+1),errs,ts)

% figure

% compute the true residual norms for the plot

options = struct('epsi',epss,'nitmax',nitmax,'trueres',1,'precond',precond);

[xcg,nitcg,iret,results] = gm_CG_prec(A,b,x0,options);
resncgt = results.resnt;
time = results.timing;
time_matcg = time.matvec;
[xcg3,nitcg3,iret,results] = gm_CG_3t_prec(A,b,x0,options);
resncg3t = results.resnt;
time = results.timing;
time_matcg3 = time.matvec;
[xcg,nitcg,iret,results] = gm_CG_reorth_prec(A,b,x0,options);
resncgrt = results.resnt;
time = results.timing;
time_matcgrt = time.matvec;
[xcgt,nitcgt,iret,results] = gm_CG_TR_prec(A,b,x0,options);
resncgtt = results.resnt;
time = results.timing;
time_matcgtt = time.matvec;
[xm,nitm,iret,results] = gm_Minres_prec(A,b,x0,options);
resnmt = results.resnt;
time = results.timing;
time_matm = time.matvec;
[xcr,nitcr,iret,results] = gm_CR_prec(A,b,x0,options);
resncrt = results.resnt;
time = results.timing;
time_matcr = time.matvec;
[xs,nits,iret,results] = gm_SYMMQR_prec(A,b,x0,options);
resnst = results.resnt;
time = results.timing;
time_mats = time.matvec;

semilogy(time_matcg,resncgt)
hold on
semilogy(time_matcg3,resncg3t,'b-x')
semilogy(time_matcgtt,resncgtt,'r-+')
semilogy(time_matcgrt,resncgrt,'r-o')
semilogy(time_matm,resnmt,'g-d')
semilogy(time_matcr,resncrt,'m-s')
semilogy(time_mats,resnst,'c-d')

legend('CG','CG3T','CGTR','CGR','MINRES','CR','SYMMQR')
xlabel('matrix-vector products')
ylabel('true residual norms')

title([mat ', precond = ' precond])

hold off

figure

semilogy(resncgt)
hold on
semilogy(resncg3t,'b-x')
semilogy(resncgtt,'r-+')
semilogy(resncgrt,'r-o')
semilogy(resnmt,'g-d')
semilogy(resncrt,'m-s')
semilogy(resnst,'c-d')

legend('CG','CG3T','CGTR','CGR','MINRES','CR','SYMMQR')

title([mat ', precond = ' precond])

xlabel('iterations')
ylabel('true residual norms')

hold off

% time measurements

options = struct('epsi',epss,'nitmax',nitmax,'trueres',0,'precond',precond,'timing',1);

[xcg,nitcg,iret,results] = gm_CG_prec(A,b,x0,options);
time_matcg = results.timing;
[xcg3,nitcg3,iret,results] = gm_CG_3t_prec(A,b,x0,options);
time_matcg3 = results.timing;
[xcg,nitcgrt,iret,results] = gm_CG_reorth_prec(A,b,x0,options);
time_matcgrt = results.timing;
[xcgt,nitcgtt,iret,results] = gm_CG_TR_prec(A,b,x0,options);
time_matcgtt = results.timing;
[xm,nitm,iret,results] = gm_Minres_prec(A,b,x0,options);
time_matm = results.timing;
[xcr,nitcr,iret,results] = gm_CR_prec(A,b,x0,options);
time_matcr = results.timing;
[xs,nits,iret,results] = gm_SYMMQR_prec(A,b,x0,options);
time_mats = results.timing;

fprintf(' CG,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitcg,time_matcg.init_time,...
 time_matcg.iter_time,time_matcg.init_time+time_matcg.iter_time,resncgt(end))
fprintf(' CG3T,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitcg3,time_matcg3.init_time,...
 time_matcg3.iter_time,time_matcg3.init_time+time_matcg3.iter_time,resncg3t(end))
fprintf(' CGTR,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitcgtt,time_matcgtt.init_time,...
 time_matcgtt.iter_time,time_matcgtt.init_time+time_matcgtt.iter_time,resncgtt(end))
fprintf(' CGR,        it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitcgrt,time_matcgrt.init_time,...
 time_matcgrt.iter_time,time_matcgrt.init_time+time_matcgrt.iter_time,resncgrt(end))
fprintf(' MINRES,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitm,time_matm.init_time,...
 time_matm.iter_time,time_matm.init_time+time_matm.iter_time,resnmt(end))
fprintf(' CR,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nitcr,time_matcr.init_time,...
 time_matcr.iter_time,time_matcr.init_time+time_matcr.iter_time,resncrt(end))
fprintf(' SYMMQR,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e \n',nits,time_mats.init_time,...
 time_mats.iter_time,time_mats.init_time+time_mats.iter_time,resnst(end))

res = zeros(1,7); cpu = zeros(1,7);
res(1) = resncgt(end);    cpu(1) = time_matcg.init_time+time_matcg.iter_time;
res(2) = resncg3t(end);   cpu(2) = time_matcg3.init_time+time_matcg3.iter_time;
res(3) = resncgtt(end);   cpu(3) = time_matcgtt.init_time+time_matcgtt.iter_time;
res(4) = resncgrt(end);   cpu(4) = time_matcgrt.init_time+time_matcgrt.iter_time;
res(5) = resnmt(end);     cpu(5) = time_matm.init_time+time_matm.iter_time;
res(6) = resncrt(end);    cpu(6) = time_matcr.init_time+time_matcr.iter_time;
res(7) = resnst(end);     cpu(7) = time_mats.init_time+time_mats.iter_time;

[minr,I] = min(res);
fprintf('\n minimum true residual norm = %11.4e for %s \n',minr,met(I(1),:))
[maxr,I] = max(res);
fprintf('\n maximum true residual norm = %11.4e for %s \n',maxr,met(I(1),:))

[mint,I] = min(cpu);
fprintf('\n minimum total time = %11.4e for %s true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum total time = %11.4e for %s true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))

cpu(1) = time_matcg.iter_time;
cpu(2) = time_matcg3.iter_time;
cpu(3) = time_matcgtt.iter_time;
cpu(4) = time_matcgrt.iter_time;
cpu(5) = time_matm.iter_time;
cpu(6) = time_matcr.iter_time;
cpu(7) = time_mats.iter_time;

[mint,I] = min(cpu);
fprintf('\n minimum iter time = %11.4e for %s true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum iter time = %11.4e for %s true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))
