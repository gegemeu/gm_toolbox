function example_presc_CG2   

% examples with the A-norm of the error prescribed

cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
res = [1 2 1 2 1 2 1 2 1 2 1 2 1 2 1];
errorA = gm_comp_res_presc_CG(15,0.6);
nr0 = 1;
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG_err(res',errorA,nr0);
fprintf('\n Example 1, cond(T) = %12.5e \n',cond(full(T)))
x0 = zeros(15,1);
e1 = eye(15,1);
[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,estgam,estf,estfl,est_back,max_eigA,min_eigA,max_acc_low,max_acc,time_mat,errA,mu,eta,kmu,keta,fdelay]...
 = gm_CG_errGR_newadapt_precT(T,nr0*e1,x0,1e-20,15,'noscal','trueres','nop','no',1,0.,3e7);

set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(res)
hold on
semilogy(resn(1:end-1),'r--')
err2 = errorA(2:15)';
semilogy([2:15],err2,'m.-')
semilogy([2:15],errA(1:14),'g')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('residual and error norms' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('presc res','res','presc err','err','Location','northeastoutside')
title('Example 1')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_1';
% print(sSaveName,'-dpdf');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res-resn(1:15)/nr0)./res)
hold on
err2 = errorA(2:15)';
semilogy([2:15],abs(err2-errA(1:14))./err2,'r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('res','err','Location','northeastoutside')
title('Example 1')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_2';
% print(sSaveName,'-dpdf');

errorA = gm_comp_res_presc_CG(20,0.3);
res = [1; 0.9; 0.8; 0.6; 0.3; 0.1; 0.09; 0.08; 0.06; 0.03; 0.01; 0.009; 0.008; 0.006; 0.003; ...
 0.001; 0.0005; 0.0001; 0.00005; 0.00001];
%errorA = 2 * errorA;
nr0 = 1;
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG_err(res,errorA,nr0);
fprintf('\n Example 2, cond(T) = %12.5e \n',cond(full(T)))
% eigT = eig(full(T));
% %figure
% gm_cbar(eigT);
x0 = zeros(20,1);
e1 = eye(20,1);
[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,estgam,estf,estfl,est_back,max_eigA,min_eigA,max_acc_low,max_acc,time_mat,errA,mu,eta,kmu,keta,fdelay]...
 = gm_CG_errGR_newadapt_precT(T,nr0*e1,x0,1e-20,20,'noscal','trueres','nop','no',1,0.,3e7);

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(res)
hold on
semilogy(resn(1:end-1),'r--')
err2 = errorA(2:20)';
semilogy([2:20],err2,'m.-')
semilogy([2:20],errA(1:19),'g')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('residual and error norms' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('presc res','res','presc err','err','Location','northeastoutside')
title('Example 2')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_3';
% print(sSaveName,'-dpdf');


myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20)/nr0)./res')
hold on
err2 = errorA(2:20)';
semilogy([2:20],abs(err2-errA(1:19))./err2,'r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('res','err','Location','northeastoutside')
title('Example 2')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_4';
% print(sSaveName,'-dpdf');

% errorA = gm_comp_res_presc_CG(20,0.6); % original example 3
%errorA = gm_comp_res_presc_CG(20,0.7);
res = [1; 0.9; 0.8; 0.6; 0.3; 0.1; 0.09; 0.08; 0.06; 0.03; 0.01; 0.009; 0.008; 0.006; 0.003; ...
 0.001; 0.0005; 0.0001; 0.00005; 0.00001];
%errorA = 2 * errorA;
errorA = 100 * res;
nr0 = 1;
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG_err(res,errorA,nr0);
fprintf('\n Example 3, cond(T) = %12.5e \n',cond(full(T)))
% eigT = eig(full(T));
% %figure
% gm_cbar(eigT);
rng('default')
V = gm_qrandn(20);
T = V * T * V';
x0 = zeros(20,1);
% e1 = eye(20,1);
e1 = V(:,1);
[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,estgam,estf,estfl,est_back,max_eigA,min_eigA,max_acc_low,max_acc,time_mat,errA,mu,eta,kmu,keta,fdelay]...
 = gm_CG_errGR_newadapt_precT(T,nr0*e1,x0,1e-20,20,'noscal','trueres','nop','no',1,0.,3e7);

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(res)
hold on
semilogy(resn(1:end-1),'r--')
err2 = errorA(2:20)';
semilogy([2:20],err2,'m.-')
semilogy([2:20],errA(1:19),'g')
legend('presc res','res','presc err','err','Location','northeastoutside')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('residual and error norms' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('presc res','res','presc err','err','Location','northeastoutside')
title('Example 3')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_5';
% print(sSaveName,'-dpdf');


myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20)/nr0)./res')
hold on
err2 = errorA(2:20)';
semilogy([2:20],abs(err2-errA(1:19))./err2,'r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('res','err','Location','northeastoutside')
title('Example 3')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_6';
% print(sSaveName,'-dpdf');

res = gm_comp_res_presc_CG(20,0.8);
gamma = ones(20,1);
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG(res,gamma);
fprintf('\n Example 4, cond(T) = %12.5e \n',cond(full(T)))
% eigT = eig(full(T));
% fprintf('\n            min eig = %12.5e \n',min(eigT))
%figure
% gm_cbar(eigT);
x0 = zeros(20,1);
e1 = eye(20,1);
[x,nit,iret,resn,resnt,time_mat]=gm_CG_prec(T,e1,x0,1e-20,20,'noscal','trueres','noprint','no');
[x,nit,iret,resnr,resnrt,time_mat]=gm_CG_reorth_prec(T,e1,x0,1e-20,20,'noscal','trueres','noprint','no');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(res)
hold on
semilogy(resn(1:end-1),'r--')
semilogy(resnr(1:end-1),'g')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('residual norm' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('presc res','res','res reorth','Location','northeastoutside')
title('Example 4')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_7';
% print(sSaveName,'-dpdf');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20))./res')
hold on
semilogy(abs(res'-resnr(1:20))./res','r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('CG','CG reorth','Location','northeastoutside')
title('Example 4')
sSaveName = 'C:\D\Doc TeX\slides\prescCG2_8';
% print(sSaveName,'-dpdf');

