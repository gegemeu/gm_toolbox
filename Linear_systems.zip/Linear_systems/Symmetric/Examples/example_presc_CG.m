function example_presc_CG

res = gm_comp_res_presc_CG(20,0.8);
gamma = ones(20,1);
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG(res,gamma);
x0 = zeros(20,1);
e1 = eye(20,1);
[x,nit,iret,resn,resnt,time_mat]=gm_CG_prec(T,e1,x0,1e-20,20,'noscal','trueres','noprint','no');
[x,nit,iret,resnr,resnrt,time_mat]=gm_CG_reorth_prec(T,e1,x0,1e-20,20,'noscal','trueres','noprint','no');

cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;
myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20))./res')
hold on
semilogy(abs(res'-resnr(1:20))./res','r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('CG','CG reorth','Location','northeastoutside')
title('Example 1 with (T,e1)')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\convGMRES\prescCG1';
% print(sSaveName,'-dpdf');

V = gm_qrandn(20);
A = V * T * V';
b = V(:,1);
[x,nit,iret,resn,resnt,time_mat]=gm_CG_prec(A,b,x0,1e-20,20,'noscal','trueres','noprint','no');
[x,nit,iret,resnr,resnrt,time_mat]=gm_CG_reorth_prec(A,b,x0,1e-20,20,'noscal','trueres','noprint','no');
myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20))./res')
hold on
semilogy(abs(res'-resnr(1:20))./res','r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('CG','CG reorth','Location','northeastoutside')
title('Example 1 with (A,b)')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\convGMRES\prescCG3';
% print(sSaveName,'-dpdf');

% example with the A-norm of the error prescribed
res = gm_comp_res_presc_CG(20,0.8);
errorA = gm_comp_res_presc_CG(20,0.5);
errorA = 2 * errorA;
nr0 = 1.1;
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG_err(res,errorA,nr0);
x0 = zeros(20,1);
e1 = eye(20,1);
[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,estgam,estf,estfl,est_back,max_eigA,min_eigA,max_acc_low,max_acc,time_mat,errA,mu,eta,kmu,keta,fdelay]...
 = gm_CG_errGR_newadapt_precT(T,nr0*e1,x0,1e-20,20,'noscal','trueres','nop','no',1,0.,3e7);

cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;
myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:20)/nr0)./res')
hold on
err2 = errorA(2:20)';
semilogy([2:20],abs(err2-errA(1:19))./err2,'r--')
hold off
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
legend('res','err','Location','northeastoutside')
title('Example 2')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\convGMRES\prescCG4';
% print(sSaveName,'-dpdf');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
res = [1 2 1 2 1 2 1 2 1 2 1 2 1 2 1];
[gamma,res]=gm_comp_gamma_presc_CG(res);
[alpha,beta,T,delta,L,D] = gm_presc_conv_CG(res,gamma);
x0 = zeros(15,1);
e1 = eye(15,1);
[x,nit,iret,resn,resnt,time_mat]=gm_CG_prec(T,e1,x0,1e-20,15,'noscal','trueres','noprint','no');

set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
semilogy(abs(res'-resn(1:15))./res')
hold on
xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('relative difference' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
title('Example 3')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\convGMRES\prescCG2';
% print(sSaveName,'-dpdf');


