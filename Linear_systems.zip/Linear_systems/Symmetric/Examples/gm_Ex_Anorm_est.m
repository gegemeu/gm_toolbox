
% gm_Ex_Anorm_est

% Examples fo CG with estimates of the A-norm of the error
% adaptive algorithm
% Symmetric matrices

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setDefaultStream(s);
rng('default')

idiffu = 1;

switch idiffu
 
 case 1
  
  fprintf('\n 2D diffusion problem \n')
  
  % 2D diffusion problems
  % iex = Pb number, = 1 Poisson
  % 10 <= iex <= 27 non constant diffusion coefficients (see gm_xk, gm_yk)
  % m = mesh m x m
  
  iex = 1;
  m = 30;
  Ex = ['Pb' num2str(iex) ' ' num2str(m)];
  mat = Ex;
  A = gm_mat_diffu(iex,m);
  b = randn(m^2,1);
  b = b / norm(b);
  x0 = zeros(m^2,1);
  
  if iex == 1
   fprintf('\n Poisson problem, %g x %g mesh \n',m,m)
  end
  
 case 2
  
  fprintf('\n Strakos matrix \n')
  
  % Strakos diagonal matrix
  % since the matrix is diagonal, do not use any preconditioner
  
  % n = order of the matrix
  n = 100;
  % lmin = smallest eigenvalue
  lmin = 0.1;
  % lmax = largest eigenvalue
  lmax = 100;
  % rho = exponential factor
  rho = 0.9;
  Ex = ['Strakos' ' ' num2str(n)];
  mat = Ex;
  [A,lamb]=gm_mat_strakos(n,lmin,lmax,rho);
  b = randn(n,1);
  b =b / norm(b);
  x0 = zeros(n,1);
  
 case 0
  
  % Tim Davis' problems
  
  bus662 = 'gm_662_bus_662';
  
  bus1138 = 'gm_1138_bus_1138';
  
  bcsstk03 = 'gm_bcsstk03_112';
  
  bcsstk07 = 'gm_bcsstk07_420';
  
  bcsstk22 = 'gm_bcsstk22_138';
  
  mesh2em5 = 'gm_mesh2em5_306';
  
  nos1 = 'gm_nos1_237';
  
  nos2 = 'gm_nos2_957';
  
  nos5 = 'gm_nos5_468';
  
  nos6 = 'gm_nos6_675';
  
  nos7 = 'gm_nos7_729';
  
  plat362 = 'gm_plat362_362';
  
  plat1919 = 'gm_plat1919_1919';
  
  dubcova = 'gm_dubcova_16129';
  
  % Choose the file
  
  Ex = dubcova;
  mat = 'dubcova';
  
  % you may have to change the path
  file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Symmetric\' Ex];
  
  load(file)
  
end % switch

n = size(A,1);
nnzA = nnz(A);

% Stopping threshold
epss = 1e-20;
% Preconditioner
precond = 'no';
% Maximum number of iterations
nitmax = 150;
% tb (see comments in gm_initprec)
tb = 0.001;
% tb = [0.01,20];
% tb = 2;

% delay
delay = 1;

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d, delay = %d \n',precond,epss,nitmax,delay)

if strcmpi(precond,'ch') == 1
 fprintf('\n IC threshold = %g \n',tb)
end

if strcmpi(precond,'lv') == 1
 fprintf('\n IC level = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'sa') == 1
 fprintf('\n SAINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'bc') == 1
 fprintf('\n block size = %d \n',tb)
end

muu = 1e-3;
etaa = 8;

[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,time_mat,errA,mu,eta] = ...
 gm_CG_errGR_adapt_precT(A,b,x0,epss,nitmax,'noscaling','trueres','noprint',precond,delay,muu,etaa);

fprintf('\n ------gm_CG_errGR_adapt_precT \n')
fprintf('\n  nit = %g, res norm = %12.5e, true res norm = %12.5e, A-norm err = %12.5e \n',nit,resn(nit+1),resnt(nit+1),errA(nit))

fprintf('\n  final values, mu = %g, eta = %g \n',mu,eta)

semilogy(errA)
hold on
semilogy(estG,'r')
semilogy(estGRl,'g')
semilogy(estGRu,'m')
semilogy(estGL,'c')
semilogy(estAG,'k')
legend('A-norm','Gauss','GR lower','GR upper','GL','Anti-Gauss')
title([mat, ',  precond= ', precond])

figure

[x,nit,iret,resn,resnt,estG,estGRl,estGRu,estGL,estAG,estgam,estf,estfl,est_back,max_eigA,min_eigA,max_acc_low,max_acc,time_mat,errA,mu,eta,kmu,keta,fdelay] = ...
 gm_CG_errGR_newadapt_precT(A,b,x0,epss,nitmax,'noscaling','trueres','noprint',precond,delay,muu,etaa);

fprintf('\n ------gm_CG_errGR_newadapt_precT \n')
fprintf('\n  nit = %g, res norm = %12.5e, true res norm = %12.5e, A-norm err = %12.5e \n',nit,resn(end),resnt(end),errA(end))

fprintf('\n  final values, mu = %g, eta = %g, delay = %g \n',mu,eta,fdelay(nit-1))

semilogy(errA)
hold on
semilogy(estG,'r')
semilogy(estGRl,'g')
semilogy(estGRu,'m')
semilogy(estGL,'c')
semilogy(estAG,'k')
legend('A-norm','Gauss','GR lower','GR upper','GL','Anti-Gauss')
title([mat, ',  precond= ', precond])

figure

semilogy(errA)
hold on
semilogy(estgam,'r')
semilogy(estf,'g')
semilogy(est_back,'m')
legend('A-norm','estgam','estf','backw error')
title([mat, ',  precond= ', precond])



