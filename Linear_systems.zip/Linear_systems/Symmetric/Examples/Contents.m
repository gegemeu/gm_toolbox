% EXAMPLES
%
% Files
%   gm_Ex_Anorm_est   - Examples with bounds and estimates of the A-norm of the error
%   gm_Ex_l2norm_est  - Examples with estimates of the l2-norm of the error
%   gm_Ex_maxacc      - Examples with improvement of the maximum attainable accuracy
%   gm_Ex_Mflops      - Examples with CG Mflops rate measurements
%   gm_Ex_Mflops_diff - Examples with CG Mflops rate measurements as a function of the order of the matrix
%   gm_Ex_presc_CG    - examples with the A-norm of the error prescribed
%   gm_Ex_presc_CG2   - examples with the A-norm of the error prescribed
%   gm_Ex_timeS       - Examples with time measurements
