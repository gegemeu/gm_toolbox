function gm_Ex_Mflops(idiffu)

% Examples with CG Mflops rate measurements
% Symmetric matrices

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setDefaultStream(s);
rng('default');

switch idiffu
 
 case 1
  
  fprintf('\n 2D diffusion problem \n')
  
  % 2D diffusion problems
  % iex = Pb number, = 1 Poisson
  % 10 <= iex <= 27 non constant diffusion coefficients (see gm_xk, gm_yk)
  % m = mesh m x m
  
  iex = 1;
  m = 200;
  Ex = ['Pb' num2str(iex) ' ' num2str(m)];
  mat = Ex;
  A = gm_mat_diffu(iex,m);
  b = randn(m^2,1);
  b = b / norm(b);
  x0 = zeros(m^2,1);
  
  if iex == 1
   fprintf('\n Poisson problem, %g x %g mesh \n',m,m)
  end
  
 case 2
  
  fprintf('\n Strakos matrix \n')
  
  % Strakos diagonal matrix
  % since the matrix is diagonal, do not use any preconditioner
  
  % n = order of the matrix
  n = 100;
  % lmin = smallest eigenvalue
  lmin = 0.1;
  % lmax = largest eigenvalue
  lmax = 100;
  % rho = exponential factor
  rho = 0.9;
  Ex = ['Strakos' ' ' num2str(n)];
  mat = Ex;
  [A,lamb] = gm_mat_strakos(n,lmin,lmax,rho);
  b = randn(n,1);
  b =b / norm(b);
  x0 = zeros(n,1);
  
 case 0
  
  Lap400 = 'gm_Lap400';
  
  % SuiteSparse problems
  
  bus662 = 'gm_662_bus_662';
  
  bus1138 = 'gm_1138_bus_1138';
  
  bcsstk03 = 'gm_bcsstk03_112';
  
  bcsstk07 = 'gm_bcsstk07_420';
  
  bcsstk22 = 'gm_bcsstk22_138';
  
  mesh2em5 = 'gm_mesh2em5_306';
  
  nos1 = 'gm_nos1_237';
  
  nos2 = 'gm_nos2_957';
  
  nos5 = 'gm_nos5_468';
  
  nos6 = 'gm_nos6_675';
  
  nos7 = 'gm_nos7_729';
  
  plat362 = 'gm_plat362_362';
  
  plat1919 = 'gm_plat1919_1919';
  
  % Choose the file
  
  %   Ex = dubcova;
  %   mat = 'dubcova';
  %   Ex = bus1138;
  %   mat = 'bus1138';
%   Ex = Lap400;
%   mat = 'Lap400';
  Ex = plat1919;
  mat = 'plat1919';
  
  % you may have to change the path
  file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Symmetric\' Ex];
  
  load(file)
  
end % switch

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end

% Stopping threshold
epss = 1e-14;
% Preconditioner
precond = 'no';
% Maximum number of iterations
nitmax = 500;

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

sop = 0;
tim = 0;
for k = 1:repeat
 [x,tt,rate,op] = gm_CG_mflops(A,b,x0,nitmax,'noprint');
 sop = sop + op;
 tim = tim + tt;
end

rate = sop / tim * 1e-6;

fprintf('\n CG, time = %g s, flops = %g, Mflops = %g \n',tim,sop,rate)
 
