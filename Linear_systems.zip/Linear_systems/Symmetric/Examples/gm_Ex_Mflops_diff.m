function gm_Ex_Mflops_diff

% Examples with CG Mflops rate measurements as a function of the order
% Symmetric matrices

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default');


fprintf('\n 2D diffusion problem \n')

% 2D diffusion problems
% iex = Pb number, = 1 Poisson
% 10 <= iex <= 27 non constant diffusion coefficients (see gm_xk, gm_yk)
% m = mesh m x m

iex = 1;

if iex == 1
 fprintf('\n Poisson problem \n')
end

% Repeat parameter for time measurements
repeat = 5;

% Stopping threshold
epss = 1e-14;
% Preconditioner
precond = 'no';
% Maximum number of iterations
nitmax = 100;

mmax = 250;
mm = zeros(1,mmax);
oper = zeros(1,mmax);
time = zeros(1,mmax);
rat = zeros(1,mmax);

j = 0;
for m = 10:10:mmax
 j = j + 1;
 mm(j) = m;
 
 A = gm_mat_diffu(iex,m);
 b = randn(m^2,1);
 b = b / norm(b);
 x0 = zeros(m^2,1);
 
 sop = 0;
 tim = 0;
 for k = 1:repeat
  [x,tt,rate,op] = gm_CG_mflops(A,b,x0,nitmax,'noprint');
  sop = sop + op;
  tim = tim + tt;
 end
 
 rate = sop / tim * 1e-6;
 
 fprintf('\n CG, m = %g, n = %g, time = %g s, flops = %g, Mflops = %g \n',m,m^2,tim,sop,rate)
 
 oper(j) = sop;
 tim(j) = tim;
 rat(j) = rate;
 jmax = j;
 
end

plot(mm(1:jmax),rat(1:jmax))
title('Mflops rate vs m')

figure
plot(mm(1:jmax).^2,rat(1:jmax))
title('Mflops rate vs n ')



