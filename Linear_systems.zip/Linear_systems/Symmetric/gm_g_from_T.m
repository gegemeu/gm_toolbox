function g=gm_g_from_T(T);
%GM_G_FROM_T computes the first row of inv(U) from tridiagonal T

% T = U C inv(U)

% U upper triangular, C companion matrix

%
% Author G. Meurant
% Dec 2018
%

n = size(T,1);
g = zeros(n,1);
g(1) = 1;
g(2) = -T(1,1) / T(2,1);
for j = 2:n-1
 g(j+1) = -(T(j,j) * g(j) + T(j,j-1) * g(j-1)) / T(j,j+1);
end % for j

