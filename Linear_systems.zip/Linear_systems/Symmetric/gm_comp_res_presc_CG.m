function res=gm_comp_res_presc_CG(n,alpha);
%GM_COMP_RES_PRESC_CG  prescribed residual norms for CG

%
% Author G. Meurant
% Dec 2018
%

res = zeros(n,1);
res(1) = 1;
for k = 2:n
 res(k) = alpha * res(k-1);
end % for k

