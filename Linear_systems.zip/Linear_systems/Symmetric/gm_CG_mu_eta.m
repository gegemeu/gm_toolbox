function [mu,eta] = gm_CG_mu_eta(A,muu,etaa,cprec,options,params);
%GM_CG_MU_ETA computation of mu and eta when not given

% This is not always an accurate estimation of the extreme eigenvalues

% Input:
% A = matrix
% muu, etaa = values that may have been given in options
% cprec = cell array computed by gm_init_precond
% options = structure giveing CG optional inputs
% params = structure giving parameters for some preconditiners
%
% mu = estimate of the smallest eigenvalue of M^{-1}A
% eta = estimate of the largest eigenvalue of M^{-1}A

%
% Author G. Meurant
% February 2025
%

precond = options.precond;

if ~isfield(options,'mu') || ~isfield(options,'eta')
 Mi = gm_inv_precond(A,precond,cprec,params);
 MiA = Mi * A;
end % if

if ~isfield(options,'mu')
 [mu,~] = gm_gerschgo(MiA);
 mu = max(10*eps,mu);
else
 mu = muu;
end % if

if ~isfield(options,'eta')
 [~,eta] = gm_gerschgo(MiA);
else
 eta = etaa;
end % if

