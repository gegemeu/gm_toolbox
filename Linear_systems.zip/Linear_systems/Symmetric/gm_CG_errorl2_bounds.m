function [errorl2,lboundl2,uboundl2]=gm_CG_errorl2_bounds(nA,resn,resnt,errA,errl2,estG,estAG);
%GM_CG_ERRORL2_BOUNDS check of bounds for the l2 error norm

%
% Author G. Meurant
% July 2019
%

n = length(errA);
errorl2 = 0;
lboundl2 = zeros(1,n);
uboundl2 = zeros(1,n);

ss = sum(1 ./ resn(1:min(nA,n)).^2);
for k = 2:n
 s = sum(1 ./ resn(1:k).^2);
%  bnd = s * errA(k)^4;
 bnd = s * estG(k)^4;
%  bnd = s * estAG(k)^4;
 lboundl2(k) = sqrt(bnd);
 bnd = ss * estG(k)^4;
 uboundl2(k) = sqrt(bnd);
end % for k

