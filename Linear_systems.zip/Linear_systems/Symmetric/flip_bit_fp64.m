function [bin,val]=flip_bit_fp64(x,b);
%FLIP_BIT_FP64 flips a bit of a double precision word

% needs the folder f_d_floatp

%
% Author G. Meurant
% June 2020
%

[bin,s,bine,binf] = fp642bin(x);

if b < 0 || b > 64
 error(' b has to be an integer in [1, 64]')
end % if

bin(64-b+1) = ~bin(64-b+1);

e = bin(2:12);
f = bin(13:64);

e = f_d_bin2dec(e) - 1023;
f = f_d_bin2frac(f);
val = (1 + f) * 2^e;
if s == 1
 val = -val;
end % if
if b == 64
 val = -val;
end % if

