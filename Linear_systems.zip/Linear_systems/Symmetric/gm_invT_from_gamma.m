function Tki=gm_invT_from_gamma(k,G,g);
%GM_INVT_FROM_GAMMA computes the inverse of T_k from G and g

% see gm_gamma_from_T, T tridiagonal
% T_k = principal submatrix of T of order k

% Input:
% G = matrix computed in gm_gamma_from_T
%      the columns contains the parameters gamma
% g = vector computed in gm_gamma_from_T
%
% Output:
% Tki = inverse of T_k

%
% author G. Meurant
% Jan 2019
%

n = size(G,2);
if k > n
 error(' k is too large')
end % if

gamma = G(1:k,k);
Tki = zeros(k,k);
for j = 1:k
 Tki(j:k,j) = g(j) * gamma(j:k);
 Tki(j,j+1:k) = Tki(j+1:k,j)';
end % for j

