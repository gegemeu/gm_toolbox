function [x,nit,iret,resn,resnt,time_mat]=gm_CG_MP_prec(A,b,x0,epsi,nitmax,scalings,trueress,iprints,precond,varargin);
%GM_CG_MP_PREC preconditioned conjugate gradient for a symmetric matrix A, Meurant's parallel variant

% G. Meurant's parallel variant

%
% Input:
% A = symmetric positive definite matrix
% b = right hand side
% x0 = starting vector
% epsi = threshold for stopping criterion
% (stop if norm(r^k) <= epss norm(r^0) or nit > nitmax
% nitmax = maximum number of iterations
%  if nitmax < 0 we do time measurements
% scalings = 'scaling', diagonally scales the matrix before preconditioning
% trueress = 'trueres' computes the norm of b - A x_k
% iprints = 'print' print residual norms at every iteration
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
%
% param = varargin(1) - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv' and 'ei'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = nothing for 'tw'
%  = number of levels for 'ml' and 'dd'
%  = block size for block methods
%
% the other parameters for 'ml' and 'dd' are in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code
% resn = l_2 norm of computed residual
% resnt = l_2 norm of the true residual (if 'trueres')
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items

%
% Author G. Meurant
% March 2001 modified Feb 2009
% May 2015
% May 2019
%

n = size(A,1);

if nargin < 3
 x0 = zeros(n,1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = n;
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
 end
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_CG_MP_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_CG_MP_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 6
 % no scaling
 scaling = 0;
end
if nargin < 7
 % do not compute the true residual norm
 trueres = 0;
end
if nargin < 8
 % no printing
 iprint = 0;
end
if nargin < 9
 % no preconditioning
 precond = 'no';
end

if nargin > 5 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 6 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 7 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if iprint == 1
 fprintf('\n gm_CG_MP_prec: \n\n')
 fprintf('  precond = %s \n',precond)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
end

tb = 1;
if nargin >= 10 && (strcmpi(precond,'bc') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_CG_MP_prec: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 10 && (strcmpi(precond,'ce') == 1)
 % threshold for the Matlab IC preconditioner
 tb = varargin{1};
 if iprint == 1
  fprintf('  ic threshold = %g \n',tb)
 end
end

if nargin >= 10 && (strcmpi(precond,'gm') == 1)
 % number of iterations for CG
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 10 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1) || ...
  strcmpi(precond,'sa') == 1 || strcmpi(precond,'ch') ==  1)
 %  tb = [alp, q] for AINV
 tb = varargin{1};
end

if nargin < 10 && (strcmpi(precond,'ai') == 1)
 tb = [0.1, n];
end

if nargin < 10 && (strcmpi(precond,'sa') == 1)
 tb = [0.1, n];
end

if nargin < 10 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if nargin >= 10 && strcmpi(precond,'lv') == 1
 tb = varargin{1};
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
%  fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && (strcmpi(precond,'sa') == 1)
 fprintf('  alpha = %g \n',tb(1))
%  fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && (strcmpi(precond,'ch') == 1)
 fprintf('  epsi = %g \n',tb(1))
end

if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1)...
  || (strcmpi(precond,'lv') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >=  10 && (strcmpi(precond,'gp') == 1)
 % given preconditioner
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_CG_MP_prec: error, M has to be of the same order as A')
end

if nargin >= 11 && (strcmpi(precond,'ml') == 1 || strcmpi(precond,'mb') == 1)
 % get the input parameters for the multilevel AMG method
 if nargin < 17
  error('gm_CG_MP_prec: some parameters are not defined for ML')
 end
 
 iv = 1;
 if strcmpi(precond,'mb') == 1
  tb = varargin{1};
  iv = iv + 1;
 end
 lmax = varargin{iv};
 nu = varargin{iv+1};
 alpmax = varargin{iv+2};
 alb = varargin{iv+3};
 smooth = varargin{iv+4};
 infl = varargin{iv+5};
 coarse = varargin{iv+6};
 interpo = varargin{iv+7};
 if nargin > 17+iv
  qmin = varargin{iv+8};
 else
  qmin = n;
 end
 gama = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------multilevel parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
  if gama == 1
   fprintf(' V-cycle \n')
  else
   fprintf(' W-cycle \n')
  end
 end
 
end

if nargin < 11 && (strcmpi(precond,'ml') == 1 || strcmpi(precond,'mb') == 1)
 % defaults for AMG
 lmax = 10;
 nu = 1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'gs';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 falp = 1;
 alq = 1;
 normal = 0;
 tb = 2;
 if nargin == 10 && strcmpi(precond,'mb') == 1
  tb = varargin{1};
 end
 gama = 1;
 
 if iprint == 1
  fprintf('\n -----------default multilevel parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
  fprintf(' block size = %d \n',tb)
  fprintf(' V-cycle \n')
 end
 
end

x = [];
nit = 0;
iret = 0;
resn = zeros(1,nitmax);
resnt = zeros(1,nitmax);
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 A_old = A;
 [A,dda] = gm_normaliz(A);
 b_old = b;
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;
matv = zeros(1,nitmax+1);

xin = zeros(n,1);

% init of preconditioners
if strcmpi(precond,'ml') ~= 1  && strcmpi(precond,'mb') ~= 1
 [dd,L,d1,ld,ldd] = gm_initprec(A,precond,iprint,tb);
 if strcmpi(precond,'gp')
  L = M;
 end
 
elseif strcmpi(precond,'ml') == 1
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_CG_MP_prec: Error in gm_amg_init \n')
  iret = 1;
  return
 end
 
elseif strcmpi(precond,'mb') == 1
 % multilevel block preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cdf,cZ,cD,cZb,cDb,cL,cda,lmax,err] = gm_amg_initb(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,tb,iprint);
 if err == 1
  error('gm_CG_MP_prec: error in gm_amg_initb')
 end
 
end % if strcmpi

x = x0;
% init residual vector
r = b - A * x;
matvec = matvec + 1;

nr = norm(r);
dotprod = dotprod + 1;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',nr)
end

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = nr;
end

resn = zeros(1,nitmax);
resn(1) = nr;

resid = realmax;
epss = epsi^2;
matv(1) = matvec;

% solve of M z = r
if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
 z = gm_solveprec(r,A,dd,L,precond,tb);
elseif strcmpi(precond,'mb') == 1
 % multilevel block preconditioner
 z = gm_amgitb(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
elseif strcmpi(precond,'ml') == 1
 % multilevel preconditioner
 z = gm_amgit(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
end % if strcmpi

p = z;
% number of iterations
ni = 0;
r0 = r' * r;
rtz = z' * r;
dotprod = dotprod + 2;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% -------------------------------------Iterations

while resid >= epss*r0 && ni < nitmax
 
 ni = ni + 1;
 Ap = A * p;
 matvec = matvec + 1;
 
  % solve of M v = Ap
 if strcmpi(precond,'ml') ~= 1 && strcmpi(precond,'mb') ~= 1
  v = gm_solveprec(Ap,A,dd,L,precond,tb);
 elseif strcmpi(precond,'mb') == 1
  % multilevel block preconditioner
  v = gm_amgitb(A,Ap,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal,tb);
 elseif strcmpi(precond,'ml') == 1
  % multilevel preconditioner
  v = gm_amgit(A,Ap,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cdf,cZb,cDb,cL,cda,lmax,smooth,gama,normal);
 end % if strcmpi
 
 vAp = v' * Ap;
 pAp = p' * Ap;

 dotprod = dotprod + 2;
 
 alp = rtz / pAp;
 s = alp^2 * vAp - rtz;
 bet = s / rtz;

 x = x + alp * p;
 % computed residual
 r = r - alp * Ap;
 z = z - alp * v;
 p = z + bet * p;
 
 rtz = z' * r;
 dotprod = dotprod + 1;
 
 % residual l_2 norm
 resn(ni+1) = norm(r);
 dotprod = dotprod + 1;
 resid = resn(ni+1)^2;

 % "true" residual norm
 if trueres == 1
  resnt(ni+1) = norm(b - A * x);
 end % if trueres
 
 % output
 if iprint == 1
  nresidu = resn(ni+1);
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',ni,nresidu,nresidu/sqrt(r0))
 end
 
 matv(ni+1) = matvec;
 
end % iterations

resn = resn(1,1:ni+1);
matv = matv(1,1:ni+1);
if trueres == 1
 resnt = resnt(1,1:ni+1);
else
 resnt = [];
end

nit = ni;
iret = 0;
if ni == nitmax
 iret = 2;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:ni+1));
end % if timing

if iprint == 1
 if ni == nitmax
  fprintf('\n No convergence after %d iterations \n',ni)
 end
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',ni)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint


% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
 trueresi = norm(b_old - A_old * x);
 
 if iprint >= 1
  fprintf('\n ---We are back to the original scale \n\n')
  fprintf(' norm of true residual for x = %g \n\n',trueresi);
  fprintf(' relative residual = %g \n',sqrt(resid/r0));
 end
end % if scaling





