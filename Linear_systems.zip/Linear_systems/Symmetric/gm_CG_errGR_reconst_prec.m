function [x,nit,iret,results] = gm_CG_errGR_reconst_prec(A,b,x0,options,params);
%GM_CG_ERRGR_RECONST_PREC preconditioned conjugate gradient for a symmetric matrix A, reconstruction of the A-norm estimates 

% This is an implementation of PCG with bounds of the A-norm of the error

% fixed delay

% Error norm estimates based on the paper:
% G. Meurant and P. Tichy, On computing quadrature-based bounds for the A-norm of the error in conjugate gradients, 
%                          Numerical Algorithms, v 62 n 2, (2012), pp 163-191
%  
% See also: G. Meurant and P. Tichy, Errot Norm Estimation In The Conjugate Gradient Algorithm,
%  SIAM (2024)

% Reconstruction of the A-norm estimates with all the possible values of delay (eG, eGRu)
% after this, use gm_delay to see a plot of the optimal values of the delay

% Input:
% A = symmetric positive definite matrix
% b = right-hand side
% x0 = starting vector

% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
% epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% scaling = 1, diagonally scales the matrix before preconditioning (0)
% trueres = 1, computes the norm of b - A x_k (0)
% iprint = 1, print, residual norms at every iteration (0)
% timing = 1, time measurements (0)
% Anorm = 1, computes the A-norm of the error (0)
% l2norm = 1, computes the ell_2 norm of the error (0)
% eG = Gauss lower bound with all possible values of delay (a row
%   corresponds to a given iteration)
% eGRu = Gauss-Radau upper bound with all possible values of delay
% errA0 = zstimate of the inirial A-norm of the error
% precond = type of preconditioning ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'mb' block AMG
%  = 'gp' = preconditioner M given by the user

% for bounds of the A-norm:
% delay = integer, we compute the bounds delay iterations before the current one (1)
% mu = lower bound of the smallest eigenvalue of M^{-1}A
% eta = upper bound of the largest eigenvalue of M^{-1}A
%       if not given, Gerschgorin bounds

% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh', 'wl'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml' and 'dd'
%  = block size for block methods
%  = matrix M for 'gp'
%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%  params.tb = block size for 'mb'
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code, = 0 if convergence

% results is a structure with the following fields:
% resn = ell_2 norm of computed residual
% resnt = ell_2 norm of the true residual (if trueres = 1)
% Anorm = A-norm of the error (if Anorm = 1)
% l2norm = ell_2 norm of the error (if l2norm = 1)
% estG  = Gauss lower bound of the A-norm of the error
% estGRl = Gauss-Radau lower bound of the A-norm of the error
% estGRu = Gauss-Radau upper bound of the A-norm of the error
% estAG = anti-Gauss estimate of the A-norm of the error
% time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items

% Warning: Note that A-norm is computed from k=0, and the bounds from k=1
% So, be careful when comparing them

%
% Author G. Meurant
% January 2025
%

n = size(A,1);

if nargin == 1
error('gm_CG_errGR_reconst_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_CG_errGR_reconst_prec: error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end
nx = length(x0);
if nlb ~= nx
 error('gm_CG_errGR_reconst_prec: error, the dimensions of x0 and b are not compatible')
end

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% ----------------------Initialization

% get the optional parameters and options
[epsi,nitmax,scaling,trueres,iprint,precond,timing,Anorm,l2norm,delay,mu,eta] = gm_CG_options(A,options);
delayg = delay;

if timing == 1
 tic
end

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 A_old = A;
 [A,dda] = gm_normaliz(A);
 b_old = b;
 b = dda .* b;
else
 dda = ones(n,1);
end

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond(A,precond,iprint,params);

[mu,eta] = gm_CG_mu_eta(A,mu,eta,cprec,options,params);

if iprint == 1  
 fprintf('  final initial values: \n')
 fprintf('  mu      = %12.5e \n',mu)
 fprintf('  eta     = %12.5e \n',eta)
end % if

% number of matrix-vector products and dot products
matvec = 0;
dotprod = 0;
matv = zeros(1,nitmax+1);

x = x0;
% init residual vector
r = b - A * x;
matvec = matvec + 1;

nr = norm(r);
dotprod = dotprod + 1;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',nr)
end

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = nr;
end

resn = zeros(1,nitmax);
resn(1) = nr;

if Anorm == 1 || l2norm == 1
 xec = A \ b;
end % if 
if Anorm == 1
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt( (xec - x)' * A * (xec -x));
 matvec = matvec + 1;
 dotprod = dotprod + 1;
else
 errA = [];
end % if
if l2norm == 1
 errl2 = zeros(1,nitmax+1);
 errl2(1) = norm(xec - x);
 dotprod = dotprod + 1;
else
 errl2 = [];
end % if

resid = realmax;
epss = epsi^2;
matv(1) = matvec;

% solve of M z = r
z = gm_solve_precond(A,r,precond,cprec,cprec_amg);

p = z;
% number of iterations
nit = 0;
rtr = z' * r;
dotprod = dotprod + 2;

% init for estimation of error
g = zeros(1,nitmax+1);
g1 = zeros(1,nitmax+1);
g2 = g1;
g3 = g1;
g4 = g1;
g1(1) = rtr / mu; 
g2(1) = rtr / eta;
estG = zeros(1,nitmax+1);
estGRl = estG;
estGRu = estG;
estAG = estG;
eG = zeros(nitmax,nitmax);
eGRu =zeros(nitmax,nitmax);
errA0 = zeros(1,nitmax+1);

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% -------------------------------------Iterations

while resid >= epss*nb2 && nit < nitmax
 
 nit = nit + 1;
 Ap = A * p;
 matvec = matvec + 1;
 alp = rtr / (p' * Ap);
 dotprod = dotprod + 1;
 
 x = x + alp * p;
 
 % computed residual
 r = r - alp * Ap;
 
 % solve of M z = r
 z = gm_solve_precond(A,r,precond,cprec,cprec_amg);
 
 rtrz = z' * r;
 rk = r' * r;
 dotprod = dotprod + 2;
 resid = rk;
 % residual l_2 norm
 resn(nit+1) = sqrt(rk);
 
 % "true" residual norm
 if trueres == 1
  resnt(nit+1) = norm(b - A * x);
  matvec = matvec + 1;
  dotprod = dotprod + 1;
 end % if trueres
 % A-norm of the error
 if Anorm == 1
  errA(nit+1) = sqrt( (xec - x)' * A * (xec -x));
  matvec = matvec + 1;
  dotprod = dotprod + 1;
 end % if
 if l2norm == 1
  errl2(nit+1) = norm(xec - x);
  dotprod = dotprod + 1;
 end % if
 
 bet = rtrz / rtr;
 rtro = rtr;
 rtr = rtrz;
 
 p = z + bet * p;
 
 % estimates of A-norm of the error
 g(nit) = alp * rtro;
 d1 = g1(nit) - g(nit);
 d2 = g2(nit) - g(nit);
 g1(nit+1) = rtr * d1 / (mu * d1 + rtr);                    % Gauss-Radau upper bound (mu)
 g2(nit+1) = rtr * d2 / (eta* d2 + rtr);                    % Gauss-Radau lower bound (eta)
 g3(nit+1) = (eta - mu) * d1 * d2 / (eta * d2 - mu * d1);   % Gauss-Lobatto upper
 if nit > 1
  g4(nit+1) = 2 * g(nit) * g(nit-1) / (g(nit-1)-g(nit));
 end
 
 % estG  = Gauss lower bound
 % estGRl = Gauss-Radau lower bound
 % estGRu = Gauss-Radau upper bound
 % estAG = anti-Gauss estimate
 if nit > max([delay 1])
  t = sum(g(nit-delay+1:nit));
  estG(nit-delay) = sqrt(t);
  if t + g1(nit+1) > 0
   estGRu(nit-delay) = sqrt(t + g1(nit+1));     % ...   Upper bound
  else
   estGRu(nit-delay) = estG(nit-delay);
  end % if t
  if t + g2(nit+1) > 0
   estGRl(nit-delay) = sqrt(t + g2(nit+1));     % ...   Lower bound
  else
   estGRl(nit-delay) = estG(nit-delay);
  end % if t
  if t + g4(nit+1) > 0
   estAG(nit-delay) = sqrt(t + g4(nit+1));     % ...   Anti-Gauss
  else
   estAG(nit-delay) = estG(nit-delay);
  end % if t
  
 end % if nit
 
 if nit >= 2
  maxdelay = nit - 1;
  for del = 1:maxdelay
   t = sum(g(nit-del+1:nit));
   eG(nit-del,del) = sqrt(t);
   errA0(nit) = sqrt(sum(g(1:nit)));
   if t + g1(nit+1) > 0
    eGRu(nit-del,del) = sqrt(t + g1(nit+1));     % ...   GR upper bound
   end % if t
  end % for del
 end % if nit
 
 % output
 if iprint == 1
  nresidu = sqrt(resid);
  fprintf('--------------------------------------------------------\n')
  fprintf(' nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nit,nresidu,nresidu/nb);
  if nit > delay
   if Anorm == 1 
    fprintf(' A-norm at it %d: %12.5e \n',nit-delay,errA(nit-delay+1))
   end % if
   fprintf(' Estimates of A norm at it %d:  \n',nit-delay)
   fprintf('  Gauss = %12.5e, anti-Gauss = %12.5e \n',estG(nit-delay),estAG(nit-delay))
   fprintf('  Gauss-Radau lower = %12.5e, upper = %12.5e \n',estGRl(nit-delay),estGRu(nit-delay))
  end % if nit
 end % if
 
 matv(nit+1) = matvec;
 
end % iterations (while)

resn = resn(1,1:nit+1);
results.resn = resn;
estG = estG(1,1:nit+1);
results.estG = estG;
estGRl = estGRl(1,1:nit+1);
results.estGRl = estGRl;
estGRu = estGRu(1,1:nit+1);
results.estGRu = estGRu;
estAG = estAG(1,1:nit+1);
results.estAG = estAG;
matv = matv(1,1:nit+1);
if trueres == 1
 results.resnt = resnt(1,1:nit+1);
else
 results.resnt = [];
end % if
if Anorm == 1
 results.Anorm = errA(1,1:nit+1);
else
 results.Anorm = [];
end % if
if l2norm == 1
 results.l2norm = errl2(1,1:nit+1);
else
 results.l2norm = [];
end % if
results.eG = eG;
results.eGRu = eGRu;
results.errA0 = errA0;

iret = 0;
if nit == nitmax
 iret = 2;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf('\n Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1,1:nit+1));
end % if timing

if iprint == 1
 if nit == nitmax
  fprintf('\n No convergence after %d iterations \n',nit)
 end
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',nit)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint


% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
 trueresi = norm(b_old - A_old * x);
 
 if iprint >= 1
  fprintf('\n ---We are back to the original scale \n\n')
  fprintf(' norm of true residual for x = %12.5e \n\n',trueresi);
  fprintf(' relative residual = %12.5e \n',sqrt(resid/nb));
 end
end % if scaling





