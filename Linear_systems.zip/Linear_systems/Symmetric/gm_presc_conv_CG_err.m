function [alpha,beta,T,delta,L,D]=gm_presc_conv_CG_err(res,errA,nr0);
%GM_PRESC_CONV_CG_ERR matrix with prescribed CG residual norms and A-norms for (T,e1)

% Prescribed residual norms and prescribed A-norms of the error

% Input:
% res = relative residual norms (l_2) (>0, res(1) = 1)
% errA = prescribed A-norms of the error, must be decreasing
% nr0 = norm of r_0
%
% Output:
% alpha = diagonal entries
% beta = subdiagonal entries
% T = symmetric tridiagonal matrix
% delta = diagonal entries of the LDL^T factorization of T
% L,D = lower diagonal matrices T = LDL^T
%

%
% Author G. Meurant
% Dec 2018
%

if res(1) ~= 1
 error(' The first relative residual norm must be equal to 1')
end

for k = 1:length(errA)-1
 if errA(k) <= errA(k+1)
  error(' The values of errA must be decreasing')
 end % if
end % for k

resid = res * nr0;

errA = errA.^2;
gamma = errA ./ (nr0 * resid);

g = 1 ./ res;
ng = length(g);
ngam = length(gamma);
if ngam < ng
 error(' There are not enough elements in gamma')
end
alpha = zeros(ng,1);
beta = zeros(ng-1,1);

alpha(1) = -g(2) / (gamma(2) - g(2) * gamma(1));
beta(1) = -alpha(1) / g(2);
for k = 2:ng-1
 d = g(k) * (g(k) * gamma(k+1) - g(k+1) * gamma(k));
 alpha(k) = -g(k+1) / d - beta(k-1) * g(k-1) / g(k);
 beta(k) = g(k) / d;
end % for k
alpha(ng) = 1 / (g(ng) * gamma(ng)) - beta(ng-1) * g(ng-1) / g(ng);

if nargout >= 3
 x = [beta; 0];
 y = alpha;
 z = [0; beta];
 T = spdiags([x y z], -1:1,ng,ng);
 T = full(T);
 delta = zeros(ng,1);
 delta(1) = -g(2) / (gamma(2) - g(2) * gamma(1));
 for k = 2:ng-1
  delta(k) = - g(k+1) / (g(k) * (g(k) * gamma(k+1) - g(k+1) * gamma(k)));
 end % for k
%  delta(ng) = alpha(ng) - beta(ng-1)^2 / delta(ng-1);
 delta(ng) = 1 / (g(ng) * gamma(ng));
 L = tril(T,-1) + diag(delta);
 D = diag(1 ./ delta);
end % if




