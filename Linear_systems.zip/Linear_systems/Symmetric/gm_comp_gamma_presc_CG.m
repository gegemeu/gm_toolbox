function [gamma,res]=gm_comp_gamma_presc_CG(res);
%GM_COMP_GAMMA_PRESC_CG computes gamma satisfying the sufficient condition

%
% Author G. Meurant
% Dec 2018
%

g = 1 ./ res;
g = abs(g(:));
n = length(g);
gamma = zeros(n,1);
gamma(1) = 1;
for k = 2:n
 gamma(k) = 0.99 * gamma(k-1) * g(k) / g(k-1);
end % for
res = 1 ./ g;
