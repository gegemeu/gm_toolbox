function [Uhi,Ritz]=gm_Uhi_from_T(T);
%GM_UHI_FROM_T computes inv(U hat) from T

% Input:
% T = symmetric tridiagonal matrix
%
% Output:
% Uhi = matrix whose column k gives the coefficients of the residual polynomial for T_k
% Ritz = matrix of the Ritz values of T

%
% Author G. Meurant
% Jan 2019
%

% parameters gamma and g from T
% they describe inv(T_k) for all k
[G,g] = gm_gamma_from_T(T);

n = size(T,1);
Uhi = zeros(n+1,n+1);
Ritz = zeros(n,n);
% coefficients of the residual polynomials
Uhi(1,1) = 1;
d = G(1,1) * g(1);
Uhi(1:2,2) = [1; -d];
for k = 2:n
 d = G(1:k,k) .* g(1:k); % diagonal entries of inv(T_k)
 y = Uhi(1:k,1:k) * d;
 Uhi(1:k+1,k+1) = [1; -y];
end % for k

% Ritz values
for k = 2:n+1
 p = Uhi(1:k,k);
 p = p(k:-1:1); % coefficients of the polynomial
 r = roots(p); % eigenvalues
 Ritz(1:size(r,1),k-1) = r;
end % for k

Uhi = Uhi(1:n,1:n);



