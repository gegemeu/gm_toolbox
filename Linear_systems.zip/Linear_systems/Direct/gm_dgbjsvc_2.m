function [x,info] = gm_dgbjsvc_2(A,B,nk);
%GM_DGBJSVC_2 solves Ax = b, block Gauss-Jordan with row swaps

% different coding than in gm_dgbjsvc
% reduction to identity form

% Input:
% A = square matrix
% B = right-hand sides
% nk = block size

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
elseif nk >= max(m,n);
 info = -4;
end
if info ~= 0
 error('gm_dgbjsvr, info ~= 0')
end
nbl = ceil(m / nk); % number of blocks

for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 % permute the rows, Gauss factorization of the panel
 [~,~,info,L,U,row] = gm_dgetf2(A(js:m,js:je));
 row = row + js - 1; % global index
 A(js:m,:) = A(row,:);
 B(js:m,:) = B(row,:);
 % compute the inverse of the permuted block
 nblo = je - js + 1;
 Y = L(1:nblo,1:nblo) \ eye(nblo,nblo);
 IA11 = U \ Y;
 
 A(1:js-1,js:je) = A(1:js-1,js:je) * IA11;
 A(je+1:m,js:je) = A(je+1:m,js:je) * IA11;
 A(1:js-1,je+1:n) = A(1:js-1,je+1:n) - A(1:js-1,js:je) * A(js:je,je+1:n);
 A(je+1:m,je+1:n) = A(je+1:m,je+1:n) - A(je+1:m,js:je) * A(js:je,je+1:n);
 B(1:js-1,:) = B(1:js-1,:) - A(1:js-1,js:je) * B(js:je,:);
 B(je+1:m,:) = B(je+1:m,:) - A(je+1:m,js:je) * B(js:je,:);
 
 A(js:je,js:je) = IA11;
end % for k

x = zeros(m,nb);
for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 IA11 = A(js:je,js:je);
 x(js:je,:) = IA11 * B(js:je,:);
end % for k







