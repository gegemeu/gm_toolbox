function [V,bet] = gm_qr_add_col(V,nv,bet,u);
%GM_QR_ADD_COL computes the QR factorization when adding a column

% The Householder reflections are I - beta v v^T

% Input:
% V = matrix of the previous Householder vectors
% nv = number of non zero columns in V
% bet = vector of the previous Householder reflections
% u = new column added to the right of the matrix
%
% Output:
% V = updated matrix (with one more column)
% bet = updated vector

%
% Author G. Meurant
% October 2016
%

[n,m] = size(V);
bet = bet(:);

if length(u) ~= n
 error('gm_qr_add_col: The length of u is not correct')
end
if length(bet) < m
 error('gm_qr_add_col: The length of bet is too small')
end
if nv+2 > n
 return
end

% we must zero the components of u from nv+2 to n
[v,beta] = gm_household(u,nv+2);

V(:,nv+1) = v;
bet(nv+1) = beta;


