function B = gm_butterfly(n);
%GM_BUTTERFLY random butterfly matrix of depth 1

% n = order of the matrix B

%
% Author G. Meurant
% February 2023
%

n2 = floor(n / 2);
R0 = diag(randn(n2,1));
R1 = diag(randn(n2,1));

B = [R0 R1; R0 -R1];

if mod(n,2) ~= 0
 % n is odd, we cheat
 B = [B randn(n-1,1); randn(1,n-1) randn];
end % if

B = (1 / sqrt(2)) * B;

