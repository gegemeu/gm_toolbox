function [U,L] = gm_UL_np(A);
%GM_UL_NP UL factorization without pivoting

% A = square matrix

% this is an expensive way to compute that factorization

%
% Author G. Meurant
% March 2023
%

n = size(A,1);
P = eye(n);
col = n:-1:1;
P = P(:,col);

B = P * A * P;
[LB,UB] = gm_Gauss_elimination(B);

U = P * LB * P';
L = P * UB * P';

