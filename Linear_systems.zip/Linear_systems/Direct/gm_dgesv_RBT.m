function X = gm_dgesv_RBT(A,B,d,ref);
%GM_DGESV_RBT solve A X = B with Gaussian elimination with RBT randomization

% A = square matrix
% B = right-hand sides
% d = recursion depth for RBT
% ref = 1 with iterative refinement

% (RU)^T A RV = L * U

%
% Author G. Meurant
% February 2023
%

[n,m] = size(A);
if m ~= n
 error('gm_dgesv_RBT: A must be square')
end % if

if nargin < 4
 ref = 0; % without iterative refinement
end % if

[AR,info,RU,RV] = gm_dgetrf_RBT(A,d);
 
% Lover triangular part
L = tril(AR,-1) + eye(n,n);
% Upper triangular part
U = triu(AR);

% Apply the randomization to B
BR = RU' * B;

Y = L \ BR;
XX = U \ Y;
X = RV * XX;

if ref == 1
 % iterative refinement in working precision
 for k = 1:2
  R = B - A * X;
  RR = RU' * R;
  Y = L \ RR;
  XX = U \ Y;
  XR = RV * XX;
  X = X + XR;
 end % for k
end % if


  
  
  

