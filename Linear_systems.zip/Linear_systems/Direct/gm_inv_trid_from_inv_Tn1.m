function [Tni,rho,nu] = gm_inv_trid_from_inv_Tn1(Tn1i,alpha,beta);
%GM_INV_TRID_FROM_INV_TN1 recursive inverse of a symmetric tridiagonal matrix

% inv(T_n) from inv(T_{n-1})

% Input:
% Tn1i = inverse of a symmetric tridiagonal matrix of order n-1
% alpha, beta = entries added at the bottom
%  Tn = ( Tn1, beta*e_{n-1}; beta*e_{n-1}^T, alpha)
% 
% Output:
% Tni = inverse of Tn
% rho, nu = factors of the entries of Tni

% The lower triangular part is tril(rho * transpose(nu))

%
% Author G. Meurant
% March 2024
%

n1 = size(Tn1i,1);
n = n1 + 1;
Tni = zeros(n,n);
rho = zeros(n,1);
nu = zeros(n,1);
rhon1 = Tn1i(:,1);
nun1 = Tn1i(:,n-1) / rhon1(n-1);

nu(1:n-1) = nun1;

rho(n) = -(beta * rhon1(n-1)) / (alpha - beta^2 * Tn1i(n-1,n-1));
rho(1:n-1) = rhon1 - beta * rho(n) * Tn1i(:,n-1);
nu(n) = -1 / (beta * rhon1(n-1));

for i = 2:n
 for j = 1:i-1
  Tni(i,j) = rho(i) * nu(j);
 end % for j
end % for i
Tni = Tni + transpose(Tni);
for i = 1:n
 Tni(i,i) = rho(i) * nu(i);
end % for i



