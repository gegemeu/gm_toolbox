function Q = gm_Q_from_Schur_params(gam);
%GM_Q_FROM_SCHUR_PARAMS constructs a unitary upper Hessenberg matrix from the Schur parameters

% Input:
% gam = Schur parameters
%  abs(gam(n)) must be equal to 1 and abs(gam(1:n-1)) < 1
%
% sig is sqrt( 1 - abs(gam) )
%
% Output:
% Q = unitary upper Hessenberg matrix

%
% Author G. Meurant
% June 2012
% Updated September 2015
%

n = length(gam);

% if abs(gam(n)) ~= 1
%  error('gm_Q_from_Schur_params: abs(gam(n)) must be equal to 1')
% end

I = find(abs(gam(1:n-1)) > 1);
if ~isempty(I)
 error('gm_Q_from_Schur_params: abs(gam(i)) must be < 1')
end

gam = gam(:)';

sig = sqrt(1 - abs(gam(1:n-1)).^2);

% sub diagonal
Q = diag(sig,-1);

% first row
Q(1,1) = -gam(1);
cp = cumprod(sig);
Q(1,2:n) = -cp .* gam(2:n);

for k = 2:n-1
 % row k
 cp = cumprod(sig(k:n-1));
 Q(k,k) = -conj(gam(k-1)) * gam(k);
 Q(k,k+1:n) = -conj(gam(k-1)) * cp .* gam(k+1:n);
end

% last row
Q(n,n) = -conj(gam(n-1)) * gam(n);

