function [A,ipvt,info,L,U,P] = gm_dgetrf_tp(A,nb,p);
%GM_DGETRF_TP LAPACK LU factorization, standard block right-looking version, tournament pivoting

% P * A = L * U

% LAPACK's DGETRF does not compute L, but ony the multipliers needed to solve the system

% Input:
% A = matrix
% nb = block size (width of panels)
% p = number of "processors"
%
% Output:
% A = modified A, its upper triangular part is U, Caution!
% ipvt = indices of pivots
% info = return code
% L, U = lower and upper triangular factors of P A
% P = permutation matrix

% Assume m >= n at the end

%
% Author G. Meurant
% February 2023
%

% Test the input parameters
[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end % if
if info ~= 0
 error('gm_dgetrf tp, info ~= 0')
end % if
ipvt = zeros(n,1);

% Quick return if possible
if m == 0 || n == 0
 ipvt = 0; L = 0; U = 0; P = 0;
 return
end % if

if nb >= n || nb <= 1
 [A,ipvt,info,L,U,P] = gm_dgetf2_tp(A,p);
 return
end % if

% Use blocked code
for j = 1:nb:min(m,n)
 jb = min(min(m, n) - j + 1,nb);
 % Factor diagonal and subdiagonal blocks and test for exact singularity
 [A2,ipiv2,iinfo] = gm_dgetf2_tp(A(j:m,j:j+jb-1),p);
 A(j:m,j:j+jb-1) = A2;
 % Adjust info and the pivot indices
 jj = min(m,j+jb-1);
 ipvt(j:jj) = j - 1 + ipiv2(1:jj-j+1);
 if info == 0 && iinfo > 0
  info = iinfo + j - 1;
 end % if
 % Apply interchanges to column 1:j-1
 for i = j:j+jb-1
  A([i,ipvt(i)],1:j-1) = A([ipvt(i),i],1:j-1); % dlswap
 end % if
 if j+jb <= n
  % Apply interchanges to column j+jb:n
  for i = j:j+jb-1
   A([i,ipvt(i)],j+jb:n) = A([ipvt(i),i],j+jb:n); % dlswap
  end % if
  % Compute block row of U
  LA = tril(A(j:j+jb-1,j:j+jb-1),-1) + eye(jb,jb);
  X = LA \ A(j:j+jb-1,j+jb:n); % dtrsm
  A(j:j+jb-1,j+jb:n)  = X;
  if j+jb <= m
   % Update trailing submatrix
   A(j+jb:m,j+jb:n) = A(j+jb:m,j+jb:n) - A(j+jb:m,j:j+jb-1) * A(j:j+jb-1,j+jb:n); % dgemm
  end % if j+jb <= m
 end % if j+jb <= n
end % for j

if nargout > 3
 % this is not in dgetf2
 % Assume m >= n
 L = zeros(m,n);
 L(1:m,1:n) = tril(A(1:m,1:n),-1) + eye(m,n);
 U = triu(A(1:n,1:n));
 if nargout > 5
  P = eye(m,m);
  for i = 1:n
   P([i,ipvt(i)],:) = P([ipvt(i),i],:);
  end
 end % if
end % if nargout > 3




