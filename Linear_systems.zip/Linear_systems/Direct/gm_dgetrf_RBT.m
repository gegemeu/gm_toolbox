function [A,info,RU,RV,L,U] = gm_dgetrf_RBT(A,d);
%GM_DGETRF_RBT LAPACK LU factorization, random butterfly transformation, no pivoting

% A = square matrix
% d = recursion depth for RBT

% (RU)^T A RV = L * U

% LAPACK's DGETRF does not compute L, but ony the multipliers needed to solve the system

% Assume m >= n at the end

%
% Author G. Meurant
% February 2023
%

% Test the input parameters
[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end % if
if info ~= 0
 error('gm_dgetrf_RBT, info ~= 0')
end % if

% Quick return if possible
if m == 0 || n == 0
 L = 0; U = 0; RU = 0; RV = 0;
 return
end % if

% compute 2 RBTs
rng('default');
RU = gm_RBT(n,d);
RV = gm_RBT(n,d);

% transform A
AR = RU' * A * RV;

% LU factorization without pivoting
[A,info] = gm_dgetf2_np(AR);

if nargout > 4
 % this is not in dgetf2
 % Assume m >= n
 L = zeros(m,n);
 L(1:m,1:n) = tril(A(1:m,1:n),-1) + eye(m,n);
 U = triu(A(1:n,1:n));
end % if nargout > 4




