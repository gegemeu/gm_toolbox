function [x,info] = gm_dghsvr(A,B);
%GM_DGHSVR solves Ax = b, Gauss-Huard with column swaps, pivot found in rows

% reduction to identity form

% Input:
% A = square matrix
% B = right-hand sides
%
% Output:
% x = solutions
% info = return code

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
col = 1:n;
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
end
if info ~= 0
 error('gm_dghsvr, info ~= 0')
end

% find first pivot in row 1, permute the columns and divide
[~,I] = max(abs(A(1,1:n)));
jp = I(1);
if jp ~= 1
 A(:,[1,jp]) = A(:,[jp,1]);
 col(1) = col(jp);
 col(jp) = 1;
end % if
t = 1 / A(1,1);
A(1,:) = t * A(1,:);
B(1,:) = t * B(1,:);

for j = 2:min(m,n)
 % modify row j and the rhs
 A(j,j:n) = A(j,j:n) - A(j,1:j-1) * A(1:j-1,j:n);
 B(j,:) = B(j,:) - A(j,1:j-1) * B(1:j-1,:);
 % Find pivot in row j and test for singularity
 [~,I] = max(abs(A(j,j:n)));
 jp = j - 1 + I(1);
 if A(j,jp) ~= 0
  % Apply the interchange
  if jp ~= j
   A(:,[j,jp]) = A(:,[jp,j]);
   temp = col(j);
   col(j) = col(jp);
   col(jp) = temp;
  end % if jp
 elseif info == 0
  info = j;
 end % if A
 % scale row j and the rhs
 t = 1 / A(j,j);
 A(j,j:n) = t * A(j,j:n);
 B(j,:) = t * B(j,:);
 % rank-1 update of the top right matrix
 jm = 1:j-1;
 jn = j+1:n;
 u = -A(1:j-1,j);
 v = A(j,j+1:n);
 A(jm,jn) = gm_prank1(A(jm,jn),u,v);
 B(jm,:) = B(jm,:) -  A(jm,j) * B(j,:);
end % for j

ip = gm_invperm(col); % inverse permutation
x = B(ip,:);






