function [X,info,nop] = gm_dpurcell_sol(A,B);
%GM_DPURCELL_SOL  Purcell orthogonalization method, AX = B

% Input:
% A = square matrix
% B = right-hand sides
%
% Output:
% X = solutions
% info = return code
% nop = number of operations

%
% Author G. Meurant
% March 2023
%

[U,pivot,info1,nop1] = gm_dpurcell_fact(A);

[X,info2,nop2] = gm_dpurcell_solve(U,pivot,A,B);

info = [info1, info2];
nop = nop1 + nop2;

