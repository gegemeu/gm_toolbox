function [Ti,rho,nu,pee,tau] = gm_inv_trid_ns(T);
%GM_INV_TRID_NS inverse of a nonsymmetric tridiagonal matrix

% Input:
% T = nonsingular nonsymmetric tridiagonal matrix
%
% Output:
% Ti = inverse of T
% rho, nu, pee, tau = factors of the entries of Ti

% The lower triangular part is tril(rho * transpose(nu))
% The upper triangular part is triu(pee * transpose(tau))

%
% Author G. Meurant
% April 2024
%

n = size(T,1);
delta = zeros(n,1);
d = zeros(n,1);
rho = zeros(n,1);
nu = zeros(n,1);
pee = zeros(n,1);
tau = zeros(n,1);

alpha = diag(T);
beta = diag(T,-1);
gamma = diag(T,1);

% diagonals of the LU and UL factorizations
delta(1) = alpha(1);
for i = 2:n
 delta(i) = alpha(i) - (beta(i-1) * gamma(i-1)) / delta(i-1);
end % for i
d(n) = alpha(n);
for i = n-1:-1:1
 d(i) = alpha(i) - (beta(i) * gamma(i)) / d(i+1);
end % for i

% first column and last row
rho(1) = 1 / d(1);
for i = 2:n
 rho(i) = (-1)^(i-1) * prod(beta(1:i-1)) / prod(d(1:i));
end % for i
nu(n) = 1 / (delta(n) * rho(n));
for i = 1:n-2
 nu(n-i) = (-1)^(n-i) * prod(beta(n-i:n-1)) / (prod(delta(n-i:n)) * rho(n));
end % for i
nu(1) = 1;

% first row and last column
pee(1) = 1;
tau(1) = 1 / (d(1) * pee(1));
for i = 2:n
 tau(i) = (-1)^(i-1) * prod(gamma(1:i-1)) / (prod(d(1:i)) * pee(1));
end % for i

pee(n) = 1 / (delta(n) * tau(n));
for i = 1:n-2
 pee(n-i) = (-1)^(n-i) * prod(gamma(n-i:n-1)) / (prod(delta(n-i:n)) * tau(n));
end % for i


Ti = triu(pee * transpose(tau),1);
Ti = Ti + tril(rho * transpose(nu));



