function [X,info,nop] = gm_dpurcell_solve(U,pivot,A,B);
%GM_DPURCELL_SOLVE  Purcell orthogonalization method, AX = B

% A = square matrix
% B = right-hand sides

%U, pivot from gm_purcell_fact

%
% Author G. Meurant
% March 2023
%

info = 0;
[m,n] = size(A);
[mB,nB] = size(B);
if m ~= mB
 info = -10;
 x = 0;
 nop = 0;
 return
end % if

X = zeros(n,nB);
nop = 0;
for k = 1: n
 bet = (B(k,:) - A(k,:) * X) / pivot(k);
 X = X + U(:,k) * bet;
 nop = nop + (1 + 4 * n) * nB;
end % for k