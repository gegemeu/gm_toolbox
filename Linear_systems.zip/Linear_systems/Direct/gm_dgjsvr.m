function [x,info] = gm_dgjsvr(A,B);
%GM_DGJSVR solve Ax = b, Gauss-Jordan with column swaps, pivot found in rows

% reduction to diagonal form

% Input:
% A = square matrix
% B = right-hand sides
%
% Output:
% x = solutions
% info = return code

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
col = 1:m;
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
end
if info ~= 0
 error('gm_dgjsvr, info ~= 0')
end

for j = 1:min(m,n)
 % Find pivot in row j and test for singularity
 [~,I] = max(abs(A(j,j:n)));
 jp = j - 1 + I(1);
 if A(j,jp) ~= 0
  % Apply the column interchange 
  if jp ~= j
   A(:,[j,jp]) = A(:,[jp,j]);
   col([j,jp]) = col([jp,j]);
%    temp = col(j);
%    col(j) = col(jp);
%    col(jp) = temp;
  end % if jp
  % Compute elements 1:m of j-th column
  rowind = [1:j-1, j+1:m];
  t = 1 / A(j,j);
  mult = t * A(rowind,j);
 elseif info == 0
  info = j;
 end % if A
 % Update trailing submatrix and rhs
 jm = rowind;
 jn = j:n;
 u = -mult;
 v = A(j,j:n);
 A(jm,jn) = gm_prank1(A(jm,jn),u,v);
 B(jm,:) = B(jm,:) - mult * B(j,:);
end % for j

d = 1 ./ diag(A);
x = zeros(m,nb);
for j = 1:nb
 x(:,j) = B(:,j) .* d;
end % for j
ip = gm_invperm(col); % inverse permutation
x = x(ip,:);






