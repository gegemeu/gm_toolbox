function [L,U] = gm_fac_PHess(H);
%GM_FAC_PHESS LU factorization of a permutation of an upper Hessenberg matrix

% Input:
% H = real upper Hessenberg matrix
%
% Output:
% L = lower triangular matrix with unit diagonal
% U = upper triangular matrix
% P = permuation matrix, put the first row in last position
%  P H = L U

%
% Author G. Meurant
% October 2024
%

n = size(H,1);
Hh = H(2:n,1:n-1);
ht = H(1,1:n-1);
w = H(2:n,n);

L = eye(n,n);
ell = Hh' \ ht';
alp = H(1,n) - w' * ell;
L(n,1:n-1) = ell';
U = [Hh w; zeros(1,n-1) alp];


