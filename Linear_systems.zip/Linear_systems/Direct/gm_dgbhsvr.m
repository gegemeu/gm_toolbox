function [x,info] = gm_dgbhsvr(A,B,nk);
%GM_DGBHSVR solves Ax = b, block Gauss-Huard with column swaps

% pivot found in rows
% reduction to identity form

% Input:
% A = square matrix
% B = right-hand sides
% nk = block size

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
col = 1:n;
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
elseif nk >= max(m,n);
 info = -4;
end
if info ~= 0
 error('gm_dgbhsvr, info ~= 0')
end
nbl = ceil(m / nk); % number of blocks

% apply Gauss-Huard to block row 1
A1 = A(1:nk,1:n);
B1 = B(1:nk,:);
[~,I] = max(abs(A1(1,1:n))); % look in all columns, not only in the first block
jp = I(1);
if jp ~= 1
 A1(:,[1,jp]) = A1(:,[jp,1]);
 A(:,[1,jp]) = A(:,[jp,1]);
 col(1) = col(jp);
 col(jp) = 1;
end % if
t = 1 / A1(1,1);
A1(1,:) = t * A1(1,:);
B1(1,:) = t * B1(1,:);
for j = 2:nk
 % modify row j and the rhs
 A1(j,j:n) = A1(j,j:n) - A1(j,1:j-1) * A1(1:j-1,j:n);
 B1(j,:) = B1(j,:) - A1(j,1:j-1) * B1(1:j-1,:);
 % Find pivot in row j and test for singularity
 [~,I] = max(abs(A1(j,j:n)));
 jp = j - 1 + I(1);
 if A1(j,jp) ~= 0
  % Apply the column interchange
  if jp ~= j
   A1(:,[j,jp]) = A1(:,[jp,j]);
   A(:,[j,jp]) = A(:,[jp,j]);
   temp = col(j);
   col(j) = col(jp);
   col(jp) = temp;
  end % if jp
 elseif info == 0
  info = j;
 end % if A
 % scale row j and the rhs
 t = 1 / A1(j,j);
 A1(j,j:n) = t * A1(j,j:n);
 B1(j,:) = t * B1(j,:);
 % rank-1 update of the top right matrix
 jm = 1:j-1;
 jn = j+1:n;
 u = -A1(1:j-1,j);
 v = A1(j,j+1:n);
 A1(jm,jn) = gm_prank1(A1(jm,jn),u,v);
 B1(jm,:) = B1(jm,:) -  A1(jm,j) * B1(j,:);
end % for j
A(1:nk,:) = A1(1:nk,:);
B(1:nk,:) = B1(1:nk,:);

for k = 2:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 A(js:je,js:n) = A(js:je,js:n) - A(js:je,1:js-1) * A(1:js-1,js:n);
 B(js:je,:) = B(js:je,:) - A(js:je,1:js-1) * B(1:js-1,:);
 
 % apply Gauss-Huard to block row k
 A1 = A(js:je,js:n);
 [m1,n1] = size(A1);
 B1 = B(js:je,:);
 [~,I] = max(abs(A1(1,:))); % look in all columns, not only in the first block
 jp = I(1);
 jpg = jp + js - 1; % global index
 if jp ~= 1
  A1(:,[1,jp]) = A1(:,[jp,1]);
  A(:,[js,jpg]) = A(:,[jpg,js]);
  temp = col(js);
  col(js) = col(jpg);
  col(jpg) = temp;
 end % if
 t = 1 / A1(1,1);
 A1(1,:) = t * A1(1,:);
 B1(1,:) = t * B1(1,:);
 for j = 2:m1
  % modify row j and the rhs
  A1(j,j:n1) = A1(j,j:n1) - A1(j,1:j-1) * A1(1:j-1,j:n1);
  B1(j,:) = B1(j,:) - A1(j,1:j-1) * B1(1:j-1,:);
  % Find pivot in row j and test for singularity
  [~,I] = max(abs(A1(j,j:n1)));
  jp = j - 1 + I(1);
  jpg = jp + js - 1; % global index
  jcol = j + js - 1;
  if A1(j,jp) ~= 0
   % Apply the column interchange
   if jp ~= j
    A1(:,[j,jp]) = A1(:,[jp,j]);
    A(:,[jcol,jpg]) = A(:,[jpg,jcol]);
    temp = col(jcol);
    col(jcol) = col(jpg);
    col(jpg) = temp;
   end % if jp
  elseif info == 0
   info = j;
  end % if A
  % scale row j and the rhs
  t = 1 / A1(j,j);
  A1(j,j:n1) = t * A1(j,j:n1);
  B1(j,:) = t * B1(j,:);
  % rank-1 update of the top right matrix
  jm = 1:j-1;
  jn = j+1:n1;
  u = -A1(1:j-1,j);
  v = A1(j,j+1:n1);
  A1(jm,jn) = gm_prank1(A1(jm,jn),u,v);
  B1(jm,:) = B1(jm,:) -  A1(jm,j) * B1(j,:);
 end % for j
 A(js:je,js:n) = A1(1:m1,:);
 B(js:je,:) = B1(1:m1,:);

 A(1:js-1,je+1:n) =  A(1:js-1,je+1:n) - A(1:js-1,js:je) * A(js:je,je+1:n);
 B(1:js-1,:) = B(1:js-1,:) - A(1:js-1,js:je) * B(js:je,:);
 
end % for k

ip = gm_invperm(col); % inverse permutation
x = B(ip,:);






