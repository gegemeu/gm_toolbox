function [L,d]=gm_Chol_jik(A);
%GM_CHOL_JIK Cholesky factorization, jik version

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A = symmetric matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(A,1);

d = zeros(n,1);
L = tril(A);

for j = 1:n
 L(j,1:j-1) = L(j,1:j-1) ./ transpose(d(1:j-1));
 d(j) = A(j,j);
 for k = 1:j-1
  d(j) = d(j) - L(j,k)^2 * d(k);
 end % for k
 for i = j+1:n
  for k = 1:j-1
   L(i,j) = L(i,j) - L(i,k) * L(j,k);
  end % for k
 end % for i
 L(j,j) = 1;
end % for j
