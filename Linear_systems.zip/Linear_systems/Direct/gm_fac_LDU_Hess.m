function [L,D,U] = gm_fac_LDU_Hess(H);
%GM_FAC_LDU_HESS L D U factorization of an upper Hessenberg matrix

% Input:
% H = upper Hessenberg matrix
%
% Output:
% L = lower triangular (bidiagonal) matrix with unit diagonal
% D = diagonal matrix
% U = upper triangular matrix with unit diagonal
% H = L D U

%
% Author G. Meurant
% October 2024
%

n = size(H,1);
L = eye(n,n);
U = eye(n,n);
d = zeros(n,1);

d(1) = H(1,1);
U(1,2:n) = H(1,2:n) / d(1);
L(2,1) = H(2,1) / d(1);
for i = 2:n-1
 d(i) = H(i,i) - L(i,i-1) * d(i-1) * U(i-1,i);
 U(i,i+1:n) = (H(i,i+1:n) - L(i,i-1) * d(i-1) * U(i-1,i+1:n)) / d(i);
 L(i+1,i) = H(i+1,i) / d(i);
end % for i
d(n) = H(n,n) - L(n,n-1) * d(n-1) * U(n-1,n);

D = diag(d);

