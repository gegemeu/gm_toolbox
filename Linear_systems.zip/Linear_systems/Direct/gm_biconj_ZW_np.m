function [Z,Wt,p]=gm_biconj_ZW_np(A);
%GM_BICONJ_ZW_NP factorization of inv(A), without pivoting

% A = square nonsingular matrix
% W' A Z = D diagonal
% returns Z, W' and D as a vector of diagonal entries
%

%
% Author G. Meurant
% March 2023
%

n = size(A,1);

Z = eye(n,n);
W = eye(n,n);
p = zeros(n,1);
q = zeros(n,1);

for i = 1:n-1
 % diagonal entries
 p(i:n) = A(i,:) * Z(:,i:n);
 p1 = 1 / p(i);
 pp1 = p1 * p(i+1:n);
 q(i:n) = A(:,i)' * W(:,i:n);
 q1 = 1 / q(i);
 qq1 = q1 * q(i+1:n);
 for j = i+1:n
  Z(:,j) = Z(:,j) - pp1(j-i) * Z(:,i);
  W(:,j) = W(:,j) - qq1(j-i) * W(:,i);
 end % for j
end % for i
% last diagonal entry
p(n) = A(n,:) * Z(:,n);
% q(n) = A(:,n)' * W(:,n);

Wt = W';


