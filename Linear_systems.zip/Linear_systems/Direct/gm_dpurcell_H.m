function [x,info,nop] = gm_dpurcell_H(A,b);
%GM_DPURCELL_H solve Ax = b, Purcell orthogonalization method

% modification of the pivot search, equivalent to Gauss-Huard method?

% A = square matrix
% b = right-hand side

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end
if info ~= 0
 error('gm_dpurcell_H, info ~= 0')
end

A = [A -b];
V = eye(n+1,n+1);
% V = randn(n+1,n+1);
nop = 0;

for i = n:-1:1
 ni = n + 1 - i;
 av = A(ni,:) * V(:,1:i+1); % dot products
 nop = nop + (2 * n + 1) * i;
 [~,I] = sort(abs(av),'descend');
 piv = I(1); %index of largest dot product
 if piv == i+1
  piv = I(2);
 end % if
 m = [1:piv-1, piv+1:i+1];
 alp = -av(m) / av(piv);
 nop = nop + i;
%  V_new = gm_prank1(V_old(:,m),V_old(:,piv),alp);
 V = gm_prank1(V(:,m),V(:,piv),alp);
 nop = nop + 2 * i * (n + 1);
 
end % for i

mult = 1 / V(n+1,1);
x = mult * V(1:n,1);
nop = nop + n;




