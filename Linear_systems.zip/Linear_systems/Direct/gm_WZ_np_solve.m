function X = gm_WZ_np_solve(W,Z,B);
%GM_WZ_NP_SOLVE solution of A X = B for WZ_np factorization

% no pivoting

% B = right-hand sides

% The shapes of W and Z depend on n being odd or even

%
% Author G. Meurant
% March 2023
%

n = size(W,1);
nb = size(B,2);
Y = zeros(n,nb);
X = zeros(n,nb);
if mod(n,2) == 0
 even = 1;
else
 even = 0;
end % if

% solve W Y = B
% we start from the top and bottom
Y(1,:) = B(1,:);
Y(n,:) = B(n,:);
if even == 1
 jlim = n / 2;
else
 jlim = ceil(n / 2);
end % if
for j = 2:jlim
 % top
 s = B(j,:);
 for i = 1:j-1
  s = s - W(j,i) * Y(i,:);
 end % for i
 for i = n-j+2:n
  s = s - W(j,i) * Y(i,:);
 end % for i
 Y(j,:) = s;
 if j == jlim && even ~= 1
  break
 end % if
% bottom
nj = n - j + 1;
 s = B(nj,:);
 for i = nj:n
  s = s - W(nj,i) * Y(i,:);
 end % if
 for i = 1:j-1
  s = s - W(nj,i) * Y(i,:);
 end % for i
 Y(nj,:) = s;
end % for j

% solve of Z X = Y
% we start from the center
if even == 1
 %n even,  we have a 2 x2 system in the center
 n2 = n / 2;
 Z2 = [Z(n2,n2) Z(n2,n2+1); Z(n2+1,n2) Z(n2+1,n2+1)];
 rhs = [Y(n2,:); Y(n2+1,:)];
 X2 = Z2 \ rhs;
 X(n2,:) = X2(1,:);
 X(n2+1,:) = X2(2,:);
 is = n2 - 1; ie = n2 + 2;
 js = n2; je = n2 + 1;
else
 % n odd, we have only one equation in the center
 m = ceil(n / 2);
 dz = 1 / Z(m,m);
 X(m,:) = dz * Y(m,:);
 is = m -1; ie = m +1;
 js = m; je = m;
end % if
while is >= 1
 % we have a 2 x 2 system to solve
 Z2 = [Z(is,is) Z(is,ie); Z(ie,is) Z(ie,ie)];
 s = Y(is,:);
 for j = js:je
  s = s - Z(is,j) * X(j,:);
 end % for j
 rhs(1,:) =  s;
 s = Y(ie,:);
 for j = js:je
  s = s - Z(ie,j) * X(j,:);
 end % for j
 rhs(2,:) = s;
 X2 = Z2 \ rhs;
 X(is,:) = X2(1,:);
 X(ie,:) = X2(2,:);
 is = is -1; ie = ie + 1;
 js = js - 1; je = je + 1;
end % while
 
 


 
