function B = gm_RBT(n,d);
%GM_RBT random butterfly matrix of depth d

% Input:
% n = order of the matrix B
% d = depth of the recursion
% 
% Output:
% B = Butterfly matrix

%
% Author G. Meurant
% February 2023
%

if 2^(d-1) > n
 error('gm_RBT: d is too large')
end % if

B = gm_butterfly(n); % basic butterfly transformation
for k = 1:d-1
 dk = 2^k;
 nk = floor(n / dk);
 B1 = gm_butterfly(nk);
 for i = 2:dk
  [nb1,mb1] = size(B1);
  But = gm_butterfly(nk);
  B1 = [B1 zeros(nb1,nk); zeros(nk,nb1) But];
 end % for i
 [nb,mb] = size(B1);
 if nb < n
  dn = n - nb;
  B1 = [B1 randn(nb,dn); randn(dn,nb) randn(dn,dn)];
 end % if
 B = B1 * B;
end % for k

