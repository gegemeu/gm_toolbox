function tet = gm_theta_from_H(H);
%GM_THETA_FROM_H computes the first row of inv(U), H = U C inv(U)

% Input:
% H = unreduced upper Hessenberg matrix

%
% Author G. Meurant
% January 2024
%

n = size(H,1);
tet = zeros(1,n);
tet(1) = 1;

for k = 1:n-1
 tet(k+1) = -(1 / H(k+1,k)) * (tet(1:k) * H(1:k,k));
end % for k

