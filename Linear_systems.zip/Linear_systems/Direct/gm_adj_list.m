function [adj,iadj,deg] = gm_adj_list(A);
%GM_ADJ_LIST constructs the adjacency list of the matrix A

% The nodes adjacent to node i are in locations iadj(i),iadj(i+1)-1

% Input:
% A = (sparse) matrix
%
% Output:
% adj = adjacency list
% iadj = pointer in the list adj, iadj(i) gives the start of the list for node i
% deg = degrees of the nodes

%
% Author G. Meurant
% Updated September 2015
%

n = size(A,1);

deg = zeros(n,1);
iadj = zeros(n,1);

% initialization of the pointer
j = 1;

for i = 1:n
 % list of nodes for row i
 % non zero entries
 list = find(A(i,:));
 % exclude i from the list
 lne = find(list ~= i);
 list = list(lne); 
 % degree of node i
 d = length(list);
 deg(i) = d;
 % pointer to the list of node i
 iadj(i) = j;
 adj(j:j+d-1) = list;
 % update the pointer
 j = j + d;
end % for i


