function [d,e] = gm_dqd(dj,ej);
%GM_DQD differential QD algorithm

% Input:
% dj = diagonal entries
% ej = squares of the subdiagonal entries
%
% from the Cholesky decomposition T = L L' of tridiagonal T
%
% Output:
% same quantities for the Cholesky factorization of L' L

%
% Author G. Meurant
% April 2024
%

n = length(dj);
d = zeros(n,1);
e = zeros(n-1,1);

s = dj(1);
for i = 1:n-1
 d(i) = s + ej(i);
 f = dj(i+1) / d(i);
 e(i) = f * ej(i);
 s = f * s;
end % for i
d(n) = s;



