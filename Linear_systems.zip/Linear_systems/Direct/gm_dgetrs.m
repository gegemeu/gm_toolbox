function X = gm_dgetrs(A,ipiv,B);
%GM_DGETRS solve LU X = P' B

% A and ipiv from dgetrf or variants
% B = right-hand sides

%
% Author G. Meurant
% February 2023
%

[n,m] = size(A);
if m ~= n
 error('gm_dgetrs: A must be square')
end % if
 
% Lover triangular part
L = tril(A,-1) + eye(n,n);
% Upper triangular part
U = triu(A);

% Apply the permutations to B
for i = 1:n
 B([i,ipiv(i)],:) = B([ipiv(i),i],:);
end % for i

Y = L \ B;
X = U \ Y;

