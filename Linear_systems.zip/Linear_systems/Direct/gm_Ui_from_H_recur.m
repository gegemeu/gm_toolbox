function [Ui,U,alpha,C] = gm_Ui_from_H_recur(H);
%GM_UI_FROM_H_RECUR triangular Hessenberg decomposition, computes Ui

% Input:
% H = unreduced upper Hessenberg matrix H = U C inv(U)
%
% Output:
% Ui = inv(U)
% U = upper triangular matrix
% Ui = inv(U)
% alpha = coefficients of the characteristic polynomials of principal submatrices of H
%         the coefficient on the top is alpha_0 for the constant term
% C = companion matrix

% Uses the recurrence for the rows of Ui
% obtained from inv(U) H = C inv(U)

% This is much simpler and more efficient than gm_Ui_from_Hess

%
% Author G. Meurant
% November 2023
%

n = size(H,1);
Ui = zeros(n,n);

% first row
Ui(1,1) = 1;
for j = 2:n
 Ui(1,j) = -(1 / H(j,j-1)) * (Ui(1,1:j-1) * H(1:j-1,j-1));
end % for j

for i = 2:n-1
 Ui(i,i) = Ui(i-1,i-1) / H(i,i-1);
 for j = i:n-1
  Ui(i,j+1) = (1 / H(j+1,j)) * (Ui(i-1,j) - Ui(i,i:j) * H(i:j,j));
 end % for j
end % for i

Ui(n,n) = Ui(n-1,n-1) / H(n,n-1);

U = inv(Ui);

alpha = [];
if nargout < 3
 return
end

alpha = zeros(n+1,n+1);
d = 1 ./ diag(Ui);

alpha(1:n,1:n) = Ui * diag(d);

% characteristic polynomial of H
fac = 1 / Ui(n,n);
alpha(1,n+1) = -fac * (Ui(1,1:n) * H(1:n,n));
for i = 2:n
 alpha(i,n+1) = fac * (Ui(i-1,n) - Ui(i,i:n) * H(i:n,n));
end % for i

alpha(n+1,n+1) = 1;

C = full(gm_companion(alpha(1:n,n+1)));



