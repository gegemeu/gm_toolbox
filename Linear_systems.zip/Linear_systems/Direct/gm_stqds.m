function [dmu,ellmu,Lmu,Dmu,Umu] = gm_stqds(d,ell,mu);
%GM_STQDS factorization of T - mu I from the factorization of T

% Input:
% the factorization of T is L D L^T with L having a unit diagonal
% d = diag(D)
% ell = subdiagonal of L
%
% Output:
% same quantites for T - mu I
% T - mu I = Lmu Dmu Lmu^T

%
% Author G. Meurant
% March 2024
%

n = length(d);
dmu = zeros(n,1);
ellmu = zeros(n-1,1);
dmu(1) = d(1) - mu;

for j = 1:n-1
 ellmu(j) = (d(j) * ell(j)) / dmu(j);
 dmu(j+1) = d(j+1) - mu + d(j) * ell(j)^2 - d(j) * ell(j) * ellmu(j);
end % for j

if nargout > 2
 Lmu = eye(n,n);
 for j = 2:n
  Lmu(j,j-1) = ellmu(j-1);
 end % for j
 Dmu = diag(dmu);
 Umu = Lmu';
end % if
 
 