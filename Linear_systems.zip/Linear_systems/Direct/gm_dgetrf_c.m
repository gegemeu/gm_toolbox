function [A,ipiv,info,L,U,P] = gm_dgetrf_c(A,nb);
%GM_DGETRF_C LAPACK blocked LU factorization, Crout version

% A = matrix
% nb = block size

% P * A = L * U

% LAPACK's DGETRF does not compute L, but ony the multipliers needed to solve the system

% Assume m >= n at the end

%
% translated by G. Meurant
% February 2023
%

% Test the input parameters
[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end % if
if info ~= 0
 error('gm_dgetrf_c, info ~= 0')
end % if
ipiv = zeros(m,1);

% Quick return if possible
if m == 0 || n == 0
 ipiv = 0; L = 0; U = 0; P = 0;
 return
end % if

if nb >= n || nb <= 1
 [A,ipiv,info,L,U,row,P] = gm_dgetf2(A);
 return
end % if

% Use blocked code
for j = 1:nb:min(m,n)
 jb = min(min(m, n) - j + 1,nb);
 % Update current block
 if j > 1
  A(j:m,j:j+jb-1) = A(j:m,j:j+jb-1) - A(j:m,1:j-1) * A(1:j-1,j:j+jb-1); % dgemm
 end % if
 % Factor diagonal and subdiagonal blocks and test for exact singularity
 [A2,ipiv2,iinfo] = gm_dgetf2(A(j:m,j:j+jb-1));
% [A2,ipiv2,iinfo] = gm_dgetrf(A(j:m,j:j+jb-1),fix(nb/2)); % this is faster, but not in LAPACK
 A(j:m,j:j+jb-1) = A2;
 % Adjust info and the pivot indices
 jj = min(m,j+jb-1);
 ipiv(j:jj) = j - 1 + ipiv2(1:jj-j+1);
 if info == 0 && iinfo > 0
  info = iinfo + j - 1;
 end % if
 % Apply interchanges to column 1:j-1
 for i = j:j+jb-1
  A([i,ipiv(i)],1:j-1) = A([ipiv(i),i],1:j-1); % dlswap
 end % if
 if j+jb <= n
  % Apply interchanges to column j+jb:n
  for i = j:j+jb-1
   A([i,ipiv(i)],j+jb:n) = A([ipiv(i),i],j+jb:n); % dlswap
  end % if
  if j > 1
   A(j:j+jb-1,j+jb:n) = A(j:j+jb-1,j+jb:n) - A(j:j+jb-1,1:j-1) * A(1:j-1,j+jb:n); % dgemm
  end % if
  LA = tril(A(j:j+jb-1,j:j+jb-1),-1) + eye(jb,jb);
  X = LA \ A(j:j+jb-1,j+jb:n); % dtrsm
  A(j:j+jb-1,j+jb:n)  = X;
 end % if j+jb
 
end % for j

if nargout > 3
 % this is not in dgetf2
 % Assume m >= n
 L = zeros(m,n);
 L(1:m,1:n) = tril(A(1:m,1:n),-1) + eye(m,n);
 U = triu(A(1:n,1:n));
 if nargout > 5
  P = eye(m,m);
  for i = 1:n
   P([i,ipiv(i)],:) = P([ipiv(i),i],:);
  end
 end % if
end % if nargout > 3





