function u = gm_U_first_row_unitary(c,eigH);
%GM_U_FIRST_ROW_UNITARY first row of U for a unitary upper Hessenberg matrix

% H = U C U^{-1}
% u is the first row of U and M = U^* U

% Input:
% c = X^* e_1, X = eigenvectors of H
% eigH = eigenvalues of H (of unit modulus)

%
% Author G. Meurant
% December 2023
%

c2 = abs(c).^2; % sum(c2) must be equal to 1
c2 = c2(:);
eigH = eigH(:);

n = size(c,1);
u = zeros(1,n);
u(1) = 1;

for k = 2:n
 u(k) = c2' * eigH.^(k-1);
end % for k

