function [L,d]=gm_Cholesky(A);
%GM_CHOLESKY L D^(-1) L^T factorization of an SPD matrix

% Input:
% A = symmetric positive definite matrix
%
% Output:
% L = lower triangular matrix
% d = vector such that A = L * diag(1./d) * L'

%
% Author G. Meurant
% Updated Sept 2015
%

% get the upper Cholesky factor
R = chol(A);

d = diag(R);
d = 1 ./ d;
L = diag(d) * R;

d = d .* d;
L = L';


