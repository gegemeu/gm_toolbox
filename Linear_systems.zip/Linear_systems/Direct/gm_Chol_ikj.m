function [L,d]=gm_Chol_ikj(A);
%GM_CHOL_IKJ Cholesky factorization, ikj version

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A = symmetric matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(A,1);

d = zeros(n,1);
temp = zeros(n,1);

L = tril(A);
d(1) = A(1,1);
L(1,1) = 1;

for i = 2:n
 temp(1:i) = A(i,1:i);
 for k = 1:i
  for j = 1:k-1
   temp(k) = temp(k) - temp(j) * L(k,j);
  end % for j 
  if k~= i
   L(i,k) = temp(k) / d(k);
  else
   d(i) = temp(i);
   L(i,i) = 1;
  end % if
 end % for k
end % for i  



