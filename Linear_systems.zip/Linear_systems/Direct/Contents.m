% DIRECT
%
% Files
%   gm_adj_list          - constructs the adjacency list of the matrix A
%   gm_biconj_ZW         - factorization of inv(A), with row and column pivoting pivoting
%   gm_biconj_ZW_np      - factorization of inv(A), without pivoting
%   gm_biconj_ZW_np_2    - factorization of inv(A), without pivoting
%   gm_biconj_ZW_solve   - solves A x = b with biconjugate factorization
%   gm_butterfly         - random butterfly matrix of depth 1
%   gm_Chol_ijk          - Cholesky factorization, ijk version
%   gm_Chol_ikj          - Cholesky factorization, ikj version
%   gm_Chol_ikj_bis      - Cholesky factorization, variant of ikj version
%   gm_Chol_jik          - Cholesky factorization, jik version
%   gm_Chol_jik_bis      - Cholesky factorization, variant of jik version
%   gm_Cholesky          - L D^(-1) L^T factorization of an SPD matrix
%   gm_dgbhsvr           - solve Ax = b, block Gauss-Huard with column swaps
%   gm_dgbjsvc           - solve Ax = b, block Gauss-Jordan with row swaps
%   gm_dgbjsvc_2         - solve Ax = b, block Gauss-Jordan with row swaps
%   gm_dgbjsvr           - solve Ax = b, block Gauss-Jordan with column swaps
%   gm_dgefa             - translation of LINPACK DGEFA, LU factorization with partial pivoting
%   gm_dgesv             - solve A X = B with Gaussian elimination with partial pivoting
%   gm_dgesv_RBT         - solve A X = B with Gaussian elimination with RBT randomization
%   gm_dgetf2            - LAPACK LU factorization with partial pivoting
%   gm_dgetf2_np         - LAPACK LU factorization without pivoting
%   gm_dgetrf_RBT        - LAPACK LU factorization, random butterfly transformation, no pivoting
%   gm_dgetrf_c          - LAPACK blocked LU factorization, Crout version
%   gm_dgetrf_r          - LAPACK LU factorization, iterative version of Sivan Toledo's recursive LU algorithm
%   gm_dgetrf_tp         - LAPACK LU factorization, standard block right-looking version, tournament pivoting
%   gm_dgetrs            - solve LU X = P' B
%   gm_dghsvr            - solve Ax = b, Gauss-Huard with column swaps
%   gm_dgjsv             - solve Ax = b, Gauss-Jordan with row swaps
%   gm_dgjsvr            - solve Ax = b, Gauss-Jordan with column swaps
%   gm_fac_trid          - factorization of a symmetric tridiagonal matrix
%   gm_fac_trid_ns       - factorization of a nonsymmetric tridiagonal matrix
%   gm_find_piv_tp       - find pivots with tournament pivoting
%   gm_gauss_el          - Gaussian elimination without pivoting
%   gm_Gauss_elim        - Gaussian elimination without pivoting of the m-by-n matrix A with m >= n
%   gm_Gauss_elimination -Gaussian elimination without pivoting
%   gm_H_UL              - UL factorization of an unreduced upper Hessenberg matrix
%   gm_LLt               - L L^T Cholesky factorization of a (complex) tridiagonal matrix
%   gm_LU                - factorization of a (complex) tridiagonal matrix
%   gm_dpurcell          - solve Ax = b, Purcell orthogonalization method
%   gm_dpurcell_2        - solve Ax = b, Purcell orthogonalization method
%   gm_dpurcell_H        - solve Ax = b, Purcell orthogonalization method
%   gm_dpurcell_b        - solve Ax = b, Purcell orthogonalization method
%   gm_dpurcell_fact     - Purcell orthogonalization method, matrices for solving several systems
%   gm_dpurcell_np       - solve Ax = b, Purcell orthogonalization method without pivoting
%   gm_dpurcell_sol      - Purcell orthogonalization method, AX = B
%   gm_dpurcell_solve    - Purcell orthogonalization method, AX = B
%   gm_RBT               - random butterfly matrix of depth d
%   gm_strid             - solve of a symmetric tridiagonal system 
%   gm_UL_np             - UL factorization without pivoting
%   gm_WZ                - solution of A X = B, WZ factorization with row swaps
%   gm_WZ_np             - WZ factorization without pivoting
%   gm_WZ_np_solve       - solution of A X = B for WZ_np factorization
%   gm_WZ_solve          - solution of A X = B, WZ factorization with row swaps



