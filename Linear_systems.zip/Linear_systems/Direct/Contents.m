% DIRECT
%
% Direct methods for linear systems and factorizations
%
% Files
%   gm_adj_list              - constructs the adjacency list of the matrix A
%   gm_biconj_ZW             - factorization of inv(A), with row and column pivoting 
%   gm_biconj_ZW_np          - factorization of inv(A) without pivoting
%   gm_biconj_ZW_np_2        - factorization of inv(A) without pivoting (variant)
%   gm_biconj_ZW_solve       - solves A x = b with biconjugate factorization
%   gm_butterfly             - random butterfly matrix of depth 1
%   gm_Chol_ijk              - Cholesky factorization, ijk version
%   gm_Chol_ikj              - Cholesky factorization, ikj version
%   gm_Chol_ikj_bis          - Cholesky factorization, variant of ikj version
%   gm_Chol_incremental      - computes the Cholesky factorization incrementally
%   gm_Chol_jik              - Cholesky factorization, jik version
%   gm_Chol_jik_bis          - Cholesky factorization, variant of jik version
%   gm_Chol_trid             - Cholesky factorization of a symmetric tridiagonal matrix
%   gm_Cholesky              - L D^(-1) L^T factorization of an SPD matrix
%   gm_cholQR                - factorization of a tall and skinny matrix V = Q R
%   gm_cholQR2               - iterated factorization of a tall and skinny matrix V = Q R
%   gm_comp_Frob             - computes the Frobenius factorization of an Hessenberg matrix H
%   gm_dgbhsvr               - solves Ax = b, block Gauss-Huard with column swaps
%   gm_dgbjsvc               - solves Ax = b, block Gauss-Jordan with row swaps
%   gm_dgbjsvc_2             - solves Ax = b, block Gauss-Jordan with row swaps
%   gm_dgbjsvr               - solves Ax = b, block Gauss-Jordan with column swaps
%   gm_dgefa                 - translation of LINPACK DGEFA, LU factorization with partial pivoting
%   gm_dgesl                 - translation of LINPACK DGESL, solves Ax = b
%   gm_dgesv                 - solves A X = B with Gaussian elimination with partial pivoting
%   gm_dgesv_RBT             - solves A X = B with Gaussian elimination with RBT randomization
%   gm_dgetf2                - LAPACK LU factorization with partial pivoting
%   gm_dgetf2_np             - LAPACK LU factorization without pivoting
%   gm_dgetrf_c              - LAPACK blocked LU factorization, Crout version
%   gm_dgetrf_r              - LAPACK LU factorization, iterative version of S. Toledo's recursive LU algorithm
%   gm_dgetrf_RBT            - LAPACK LU factorization, random butterfly transformation, no pivoting
%   gm_dgetrf_tp             - LAPACK LU factorization, standard block right-looking version, tournament pivoting
%   gm_dgetrs                - solves LU X = P' B
%   gm_dghsvr                - solves Ax = b, Gauss-Huard with column swaps, pivot found in rows
%   gm_dgjsv                 - solves Ax = b, Gauss-Jordan with row swaps, pivot found in columns
%   gm_dgjsvr                - solve Ax = b, Gauss-Jordan with column swaps, pivot found in rows
%   gm_dpurcell              - solves Ax = b, Purcell orthogonalization method
%   gm_dpurcell_2            - solves Ax = b, Purcell orthogonalization method
%   gm_dpurcell_b            - solves Ax = b, Purcell orthogonalization method
%   gm_dpurcell_fact         - Purcell orthogonalization method, matrices for solving several systems
%   gm_dpurcell_H            - solves Ax = b, Purcell orthogonalization method
%   gm_dpurcell_np           - solves Ax = b, Purcell orthogonalization method without pivoting
%   gm_dpurcell_sol          - Purcell orthogonalization method, AX = B
%   gm_dpurcell_solve        - Purcell orthogonalization method, AX = B
%   gm_dqd                   - differential QD algorithm
%   gm_dstqds                - factorization of T - mu I from the factorization of tridiagonal T
%   gm_fac_LDU_Hess          - L D U factorization of an upper Hessenberg matrix
%   gm_fac_LDU_shifted_Hess  - L D U factorization of an= shifted upper Hessenberg matrix
%   gm_fac_PHess             - LU factorization of a permutation of an upper Hessenberg matrix
%   gm_fac_trid              - factorization of a symmetric tridiagonal matrix
%   gm_fac_trid_ns           - factorization of a nonsymmetric tridiagonal matrix
%   gm_fact_trid             - GM_FAC_TRID factorization of a symmetric tridiagonal matrix
%   gm_fact_trid_d_ell       - factorization of a symmetric tridiagonal matrix
%   gm_find_piv_tp           - find pivots with tournament pivoting
%   gm_g_from_T              - computes the first row of inv(U) from tridiagonal T
%   gm_gamma_from_T          - computes the gamma parameters of the inverses of T_k
%   gm_gauss_el              - Gaussian elimination without pivoting
%   gm_Gauss_elim            - Gaussian elimination without pivoting of the m-by-n matrix A with m >= n
%   gm_Gauss_elimination     - Gaussian elimination without pivoting, different coding
%   gm_H_from_T              - Hessenberg matrix from a tridiagonal matrix
%   gm_H_inv                 - inverse of an unreduced upper Hessenberg matrix
%   gm_H_QR                  - QR factorization of an upper Hessenberg matrix
%   gm_H_UL                  - UL factorization of an unreduced upper Hessenberg matrix
%   gm_inv_trid              - inverse of a symmetric tridiagonal matrix
%   gm_inv_trid_from_inv_Tn1 - recursive inverse of a symmetric tridiagonal matrix
%   gm_inv_trid_from_Tn1     - recursive inverse of a symmetric tridiagonal matrix
%   gm_inv_trid_ns           - inverse of a nonsymmetric tridiagonal matrix
%   gm_ldlt_symm             - block L D L^T factorization for a symmetric indefinite matrix
%   gm_LQ                    - LQ factorization of A
%   gm_Q_from_Schur_params   - constructs a unitary upper Hessenberg matrix from the Schur parameters
%   gm_qd                    - QD algorithm
%   gm_qr_add                - QR factorization of an augmented symmetric matrix
%   gm_qr_add_col            - computes the QR factorization when adding a column
%   gm_qr_fact               - QR factorization of A
%   gm_qr_stewart            - QR factorization using Stewart's block Gram-Schmidt
%   gm_qr_sym                - QR factorization of a symmetric matrix
%   gm_RBT                   - random butterfly matrix of depth d
%   gm_remove_column_QR      - updates QR when a column is removed
%   gm_remove_row_QR         - updates the QR decomposition when a row is removed
%   gm_Schur_params          - Schur parameters of a unitary upper Hessenberg matrix with a real positive subdiagonal
%   gm_solve_Hessenberg      - solves H x = b with UC factorization
%   gm_solve_PHess           - solve H x = b
%   gm_solve_triangle        - solves a lower triangular system with correction of the rounding errors 
%   gm_stqds                 - factorization of T - mu I from the factorization of T
%   gm_strid                 - solve of a symmetric tridiagonal system 
%   gm_SVQB                  - factorization of a tall and skinny matrix V = Q B
%   gm_theta_from_H          - computes the first row of inv(U), H = U C inv(U)
%   gm_triang_Hess           - reduction to triangular form of an upper Hessenberg matrix
%   gm_trid_LLt              - L L^T Cholesky factorization of a (complex) tridiagonal matrix
%   gm_trid_LU               - factorization of a (complex) tridiagonal matrix
%   gm_tridiag_from_inv      - symmetric tridiagonal matrix from its inverse
%   gm_tridiag_from_inv2     - symmetric tridiagonal matrix from its inverse (variant)
%   gm_tridiag_inv           - inverse of a real symmetric tridiagonal matrix
%   gm_twisted_fac           - twisted factorization of a symmetric tridiagonal matrix
%   gm_U_first_row_unitary   - first row of U for a unitary upper Hessenberg matrix
%   gm_U_from_H_recur        - triangular Hessenberg decomposition
%   gm_U_from_Hess           - U factor of a triangular Hessenberg decomposition
%   gm_U_from_Schur_params   - constructs U of the triangular Hessenberg decomposition from the Schur parameters
%   gm_UC                    - factorization of an unreduced upper Hessenberg matrix
%   gm_Uhi_from_T            - computes inv(U hat) from T
%   gm_Ui_from_H_recur       - triangular Hessenberg decomposition, computes Ui
%   gm_Ui_from_Hess          - U^(-1) factors of the triangular Hessenberg decomposition
%   gm_UL_np                 - UL factorization without pivoting
%   gm_WZ                    - solution of A X = B, WZ factorization with row swaps
%   gm_WZ_np                 - WZ factorization without pivoting
%   gm_WZ_np_solve           - solution of A X = B for WZ_np factorization
%   gm_WZ_solve              - solution of A X = B, WZ factorization with row swaps
