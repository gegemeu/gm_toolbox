% DIRECT
%
% Files
%   gm_adj_list          - constructs the adjacency list of the matrix A
%   gm_Chol_ijk          - Cholesky factorization, ijk version
%   gm_Chol_ikj          - Cholesky factorization, ikj version
%   gm_Chol_ikj_bis      - Cholesky factorization, variant of ikj version
%   gm_Chol_jik          - Cholesky factorization, jik version
%   gm_Chol_jik_bis      - Cholesky factorization, variant of jik version
%   gm_Cholesky          - L D^(-1) L^T factorization of an SPD matrix
%   gm_fac_trid          - factorization of a symmetric tridiagonal matrix
%   gm_fac_trid_ns       - factorization of a nonsymmetric tridiagonal matrix
%   gm_gauss_el          - Gaussian elimination without pivoting
%   gm_Gauss_elim        - Gaussian elimination without pivoting of the m-by-n matrix A with m >= n
%   gm_Gauss_elimination -Gaussian elimination without pivoting
%   gm_H_UL              - UL factorization of an unreduced upper Hessenberg matrix
%   gm_LLt               - L L^T Cholesky factorization of a (complex) tridiagonal matrix
%   gm_LU                - factorization of a (complex) tridiagonal matrix
%   gm_strid             - solve of a symmetric tridiagonal system 
