function [A,ipvt,info,L,U,P] = gm_dgetrf_r(A);
%GM_DGETRF_R LAPACK LU factorization, iterative version of S. Toledo's recursive LU algorithm

% P * A = L * U

% Input:
% A = matrix
%
% Output:
% A = modified A, its upper triangular part is U, Caution!
% ipvt = indices of pivots
% info = return code
% L, U = lower and upper triangular factors of P A
% P = permutation matrix

% LAPACK's DGETRF does not compute L, but ony the multipliers needed to solve the system

% Assume m >= n at the end

%
% translated by G. Meurant
% February 2023
%

% Test the input parameters
[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end % if
if info ~= 0
 error('gm_dgetrf_r, info ~= 0')
end % if
ipvt = zeros(m,1);

% Quick return if possible
if m == 0 || n == 0
 ipvt = 0; L = 0; U = 0; P = 0;
 return
end % if

% Compute machine safe minimum
sfmin = realmin;
small = 1 / realmax;
if small >= sfmin
 sfmin = small * (1 + eps );
end % if

nstep = min(m,n);
for j = 1:nstep
 kahead = bitand(int64(j),int64(-j));
 kstart = j + 1 - kahead;
 kcols = min(kahead,m-j);
 
 % Find pivot
 [~,I] = max(abs(A(j:m,j)));
 jp = j - 1 + I(1);
 ipvt(j) = jp;
 
 % Permute just this column
 if j ~= jp
  A([j,jp],j) = A([jp,j],j);
 end % if
 
 % Apply pending permutations to L
 ntopiv = 1;
 ipivstart = j;
 jpivstart = j - ntopiv;
 while ntopiv < kahead
  for i = ipivstart:j
   A([i,ipvt(i)],jpivstart:jpivstart+ntopiv-1) = A([ipvt(i),i],jpivstart:jpivstart+ntopiv-1); % dlaswp
  end % for i
  ipivstart = ipivstart - ntopiv;
  ntopiv = ntopiv * 2;
  jpivstart = jpivstart - ntopiv;
 end % while
 %  Permute U block to match L
 for i = kstart:j
  A([i,ipvt(i)],j+1:j+kcols) = A([ipvt(i),i],j+1:j+kcols); % dlaswp
 end % for i
 
 % Factor the current column
 if A(j,j) ~= 0 && isnan(A(j,j)) == 0
  if abs(A(j,j)) >= sfmin
   t = 1 / A(j,j);
   A(j+1:m,j) = t * A(j+1:m,j); % dscal
  else
   for i = 1:m-j
    A(j+i,j) = A(j+i,j) / A(j,j);
   end % for i
  end % if abs
 elseif A(j,j) == 0 && info == 0
  info = j;
 end % if A(j,j)
 
 % Solve for U block
 LA = tril(A(kstart:kstart+kahead-1,kstart:kstart+kahead-1),-1) + eye(kahead,kahead);
 X = LA \ A(kstart:kstart+kahead-1,j+1:j+kcols); % dtrsm
 A(kstart:kstart+kahead-1,j+1:j+kcols) = X;
 
 % Schur complement
 jk = min(j+kahead,n);
 A(j+1:m,j+1:jk) = A(j+1:m,j+1:jk) - A(j+1:m,kstart:kstart+kahead-1) * A(kstart:kstart+kahead-1,j+1:jk); % dgemm
 
end % for j

% Handle pivot permutations on the way out of the recursion
npived = bitand(int64(nstep),int64(-nstep));
j = nstep - npived;
while j > 0
 ntopiv = bitand(int64(j),int64(-j));
 for i = j+1:nstep
  A([i,ipvt(i)],j-ntopiv+1:j) = A([ipvt(i),i],j-ntopiv+1:j); % dlaswp
 end % for i
 j = j - ntopiv;
end % while

%     If short and wide, handle the rest of the columns (not done yet)
% if m < n
%  CALL dlaswp( n-m, a( 1, m+kcols+1 ), lda, 1, m, ipiv, 1 )
%  CALL dtrsm( 'Left', 'Lower', 'No transpose', 'Unit', m, n-m, one, a, lda, a( 1,m+kcols+1 ), lda )
% end % if

if nargout > 3
 % this is not in dgetf2
 % Assume m >= n
 L = zeros(m,n);
 L(1:m,1:n) = tril(A(1:m,1:n),-1) + eye(m,n);
 U = triu(A(1:n,1:n));
 if nargout > 5
  P = eye(m,m);
  for i = 1:n
   P([i,ipvt(i)],:) = P([ipvt(i),i],:);
  end
 end % if
end % if nargout > 3


