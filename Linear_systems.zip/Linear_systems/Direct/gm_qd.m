function [d,e] = gm_qd(dj,ej);
%GM_QD QD algorithm

% Input:
% dj = diagonal entries
% ej = squares of the subdiagonal entries

% from the Cholesky decomposition T = L L'

% Output:
% same quantities for the Cholesky factorization of L' L

% Iterating this gives Rutishauser's LR method for computing the
% eigenvalues of a symmetric tridiagonal matrix

%
% Author G. Meurant
% April 2024
%

n = length(dj);
d = zeros(n,1);
e = zeros(n-1,1);

ee = 0;
for i = 1:n-1
 d(i) = (dj(i) - ee) + ej(i);
 ee = ej(i) * dj(i+1) / d(i);
 e(i) = ee;
end % for i
d(n) = dj(n) - ee;



