function [dmu,ellmu,Lmu,Dmu,Umu] = gm_dstqds(d,ell,mu);
%GM_DSTQDS factorization of T - mu I from the factorization of tridiagonal T

% Input:
% the factorization of T is L D L^T with L having a unit diagonal
% d = diag(D)
% ell = subdiagonal of L
%
% Output:
% same quantites for T - mu I

%
% Author G. Meurant
% March 2024
%

n = length(d);
dmu = zeros(n,1);
ellmu = zeros(n-1,1);
smu = zeros(n,1);
smu(1) = mu;

for j = 1:n-1
 dmu(j) = d(j) - smu(j);
 ellmu(j) = (d(j) * ell(j)) / dmu(j);
 smu(j+1) = mu + ell(j) * ellmu(j) * smu(j);
end % for j
dmu(n) = d(n) - smu(n);

if nargout > 2
 Lmu = eye(n,n);
 for j = 2:n
  Lmu(j,j-1) = ellmu(j-1);
 end % for j
 Dmu = diag(dmu);
 Umu = Lmu';
end % if
 
 