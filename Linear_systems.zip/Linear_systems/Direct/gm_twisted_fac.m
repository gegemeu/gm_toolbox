function [L,D,U] = gm_twisted_fac(T,j);
%GM_TWISTED_FAC twisted factorization of a symmetric tridiagonal matrix

% Input:
% T = tridiagonal matrix, T = L D U
% j = index of the meeting row
%
% Output:
% L = matrix which is lower bidiagonal and then upper bidiagonal
% U = matrix which is upper bidiagonal and then lower bidiagonal
% D = diagonal matrix

%
% Author G. Meurant
% February 2024
%

n = size(T,1);

if j < 1 || j > n
 error('gm_twisted_fac: j must be in [1, n]')
end % if

d = zeros(j-1,1);
d(1) = T(1,1);

for i = 2:j-1
 d(i) = T(i,i) - T(i,i-1)^2 / d(i-1);
end % for 

dh = zeros(n,1);
dh(n) = T(n,n);
for i = n-1:-1:j+1
 dh(i) = T(i,i) - T(i,i+1)^2 / dh(i+1);
end % for i

dd = T(j,j) - T(j,j-1)^2 / d(j-1) - T(j,j+1)^2 / dh(j+1);

dia = [d(1:j-1); dd; dh(j+1:n)];
L = diag(dia);
for i = 2:j
 L(i,i-1) = T(i,i-1);
end % for i
for i = j:n-1
 L(i,i+1) = T(i,i+1);
end % for i

U = L';
D = diag(1 ./ dia);

