function [A,L,zt,beta] = gm_Chol_incremental(AA,LL,x,alpha);
%GM_CHOL_INCREMENTAL computes the Cholesky factorization incrementally

% The matrix to be factorized is
%      | AA    x   |
%      | x'  alpha | 
% using the factorization of AA = LL LL', LL lower triangular

% returns the bordered matrix A and the lower triangular factor L
%      | LL   0   |
%      | zt  beta |

%
% Author G. Meurant
% March 2015
%

n = size(AA,1);

A = [AA x; x' alpha];

z = LL \ x;

az = alpha - z' * z;

if az <= 0
 error('gm_chol_incremental: The augmented  matrix is not positive definite')
end

beta = sqrt(az);

L = [LL zeros(n,1); z' beta];

zt = z';

