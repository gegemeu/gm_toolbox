function [L,d]=gm_Chol_ikj_bis(A);
%GM_CHOL_IKJ_BIS Cholesky factorization, variant of ikj version

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A = symmetric matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(A,1);

d = zeros(n,1);

L = tril(A);
d(1) = A(1,1);
L(1,1) = 1;

for i = 2:n
 L(i,1:i-1) = A(i,1:i-1);
 for k = 1:i-1
  for j = 1:k-1
   L(i,k) = L(i,k) - L(i,j) * L(k,j);
  end % for j 
 end % for k
 L(i,1:i-1) = L(i,1:i-1) ./ transpose(d(1:i-1));
 d(i) = A(i,i);
 for j = 1:i-1
  d(i) = d(i) - d(j) * L(i,j)^2;
 end % for j
 L(i,i) = 1;
end % for i   
