function [U,L] = gm_H_UL(H);
%GM_H_UL UL factorization of an unreduced upper Hessenberg matrix

% Input:
% H = upper Hessenberg matrix
%
% Output:
% U = upper triangular matrix with unit diagonal
% L = lower bidiagonal matrix
%   such that H = U L 

%
% Author G. Meurant
% September 2018
%

n = size(H,1);
U = eye(n,n);
L = zeros(n,n);

% last column
L(n,n) = H(n,n);
U(1:n-1,n) = H(1:n-1,n) / L(n,n);

for i = n-1:-1:1
 L(i+1,i) = H(i+1,i);
 L(i,i) = H(i,i) - U(i,i+1) * L(i+1,i);
 U(1:i-1,i) = (H(1:i-1,i) - U(1:i-1,i+1) * L(i+1,i)) / L(i,i);
end % for i


