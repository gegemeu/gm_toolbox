function [x,info] = gm_dgjsv(A,B);
%GM_DGJSV solves Ax = b, Gauss-Jordan with row swaps, pivot found in columns

% reduction to diagonal form

% Input:
% A = square matrix
% B = right-hand sides
%
% Output:
% x = solutions
% info = return code

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
end
if info ~= 0
 error('gm_dgjsv, info ~= 0')
end

for j = 1:min(m,n)
 % Find pivot and test for singularity
 [~,I] = max(abs(A(j:m,j)));
 jp = j - 1 + I(1);
 if A(jp,j) ~= 0
  % Apply the row interchange to columns j:n and rhs
  if jp ~= j
   A([j,jp],j:n) = A([jp,j],j:n); % dswap
   B([j,jp],:) = B([jp,j],:);
%    temp = B(j,:);
%    B(j,:) = B(jp,:);
%    B(jp,:) = temp;
  end % if
  % Compute elements 1:m of j-th column
  rowind = [1:j-1, j+1:m];
  t = 1 / A(j,j);
  mult = t * A(rowind,j);
 elseif info == 0
  info = j;
 end % if jp
 % Update trailing submatrix
 jm = rowind;
 jn = j:n;
 u = -mult;
 v = A(j,j:n);
 A(jm,jn) = gm_prank1(A(jm,jn),u,v);
 B(jm,:) = B(jm,:) - mult * B(j,:);
end % for j

d = 1 ./ diag(A);
x = zeros(m,nb);
for j = 1:nb
 x(:,j) = B(:,j) .* d;
end % for j








