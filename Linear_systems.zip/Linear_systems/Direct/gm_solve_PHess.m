function x = gm_solve_PHess(L,U,b);
%GM_SOLVE_PHESS solve H x = b

% Input:
% L, U = factors from gm_fac_PHess
% b = right-hand side
%
% Output:
% x = solution of H x = b

%
% Author G. Meurant
% October 2024
%

n = size(L,1);
ellt = L(n,1:n-1);
y = zeros(n,1);
y(1:n-1) = b(2:n);
y(n) = b(1) - ellt * y(1:n-1);

x = zeros(n,1);
Hh = U(1:n-1,1:n-1);
w = U(1:n-1,n);
alp = U(n,n);
x(n) = y(n) / alp;
x(1:n-1) = Hh \ (y(1:n-1) - x(n) * w);

