function [x,info] = gm_dgbjsvc(A,B,nk);
%GM_DGBJSVC solves Ax = b, block Gauss-Jordan with row swaps

% reduction to identity form

% Input:
% A = square matrix
% B = right-hand sides
% nk = block size

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
elseif nk >= max(m,n);
 info = -4;
end
if info ~= 0
 error('gm_dgbjsvr, info ~= 0')
end
nbl = ceil(m / nk); % number of blocks

for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 % permute the rows, Gauss factorization of the panel
 [~,~,info,L,U,row] = gm_dgetf2(A(js:m,js:je));
 row = row + js - 1; % global index
 A(js:m,:) = A(row,:);
 B(js:m,:) = B(row,:);
 % compute the inverse of the permuted block
 nblo = je - js + 1;
 Y = L(1:nblo,1:nblo) \ eye(nblo,nblo);
 IA11 = U \ Y;
 
 A01 = A(1:js-1,js:je);
 A21 = A(je+1:m,js:je);
 A02 = A(1:js-1,je+1:n);
 A12 = A(js:je,je+1:n);
 A22 = A(je+1:m,je+1:n);
 B0 = B(1:js-1,:);
 B1 = B(js:je,:);
 B2 = B(je+1:m,:);
 A01 = A01 * IA11;
%  A01 = A01 / A11;
 A21 = A21 * IA11;
%  A21 = A21 / A11;
 A02 = A02 - A01 * A12;
 A22 = A22 - A21 * A12;
 B0 = B0 - A01 * B1;
 B2 = B2 - A21 * B1;
 
 A(js:je,js:je) = IA11;
 A(1:js-1,js:je) = A01;
 A(je+1:m,js:je) = A21;
 A(1:js-1,je+1:n) = A02;
 A(js:je,je+1:n) = A12;
 A(je+1:m,je+1:n) = A22;
 B(1:js-1,:) = B0;
 B(js:je,:) = B1;
 B(je+1:m,:) = B2;
end % for k

x = zeros(m,nb);
for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 IA11 = A(js:je,js:je);
 x(js:je,:) = IA11 * B(js:je,:);
end % for k







