function ipiv = gm_find_piv_tp(A,p);
%GM_FIND_PIV_TP find pivots with tournament pivoting

% Input:
% A = panel n x nb
% p = number of blocks (processors)
%  ideally, a power of 2
%
% Output:
% ipiv = pivot indices

%
% Author G. Meurant
% February 2023
%

[n,nb] = size(A);
ipiv = zeros(nb,1);
np = floor(n / p); % initial number of rows in a block except maybe the last one
% if p == 1 || np < nb
if p == 1 
 [~,ipiv] = gm_dgetf2(A);
 return
end % if p
% partition the panel
nbl = p; % number of blocks
istart1 = (0:nbl-1)' * np + 1;
iend1 = istart1(:) + np - 1;
iend1(nbl) = max(iend1(nbl),n);
temp1 = A;
rowind1 = [1:n]';
% Is there enough rows in the last block?
nlast = iend1(nbl) - istart1(nbl) + 1;
if nlast < nb
 % append the last block to the next to last one
 iend1(nbl-1) = iend1(nbl);
 nbl = nbl - 1;
end % if

% nnb = max(1,floor(nb / 4)); % used in dgetrf

st = 0;
while nbl >= 1
 st = st + 1; % stage number
 if mod(st,2) == 1 % odd dteps
  % factorize the blocks
  for k = 1:nbl
   [~,ipivl,info] = gm_dgetf2(temp1(istart1(k):iend1(k),:));
%    [~,ipivl,info] = gm_dgetrf(temp1(istart1(k):iend1(k),:),nnb);
   % ipivl contains local row numbers
   s = iend1(k) - istart1(k) + 1;
   ipivl = ipivl(1:min(nb,s));
   ipiv = ipivl + istart1(k) - 1;
   % permute the rows of temp1 and rowind
   for i = 1:length(ipiv)
    temp1([i+istart1(k)-1,ipiv(i)],:) = temp1([ipiv(i),i+istart1(k)-1],:);
    rowind1([i+istart1(k)-1,ipiv(i)]) = rowind1([ipiv(i),i+istart1(k)-1]);
   end % for i
  end % for k
  if nbl == 1
   ipiv = rowind1(1:nb);
   return
  end % if nbl
  % concatenate the nb first rows of the blocks 2 by 2
  nblo = 0;
  start = 1;
  for k = 1:2:nbl-1
   kk = k + 1;
   nblo = nblo + 1;
   lk = min(iend1(k) - istart1(k) + 1,nb);
   lkk = min(iend1(kk) - istart1(kk) + 1,nb);
   istart2(nblo) = start;
   iend2(nblo) = istart2(nblo) + lk + lkk - 1;
   temp2(istart2(nblo):istart2(nblo) + lk - 1,:) = temp1(istart1(k):istart1(k) + lk - 1,:);
   temp2(istart2(nblo) + lk: iend2(nblo),:) = temp1(istart1(kk):istart1(kk) + lkk - 1,:);
   rowind2(istart2(nblo):istart2(nblo) + lk - 1,1) = rowind1(istart1(k):istart1(k) + lk - 1,1);
   rowind2(istart2(nblo) + lk: iend2(nblo),1) = rowind1(istart1(kk):istart1(kk) + lkk - 1,1);
   start = iend2(nblo) + 1;
  end % for k
  % is there a block left?
  if kk ~= nbl
   lnbl = iend1(nbl) - istart1(nbl) + 1; % length of last block
   if lnbl >= nb
    lnbl = min(lnbl,nb);
    % keep it as a block
    nblo = nblo + 1;
    istart2(nblo) = iend2(nblo-1) + 1;
    iend2(nblo) = istart2(nblo) + lnbl - 1;
    temp2(istart2(nblo):iend2(nblo),:) = temp1(istart1(nbl):istart1(nbl) + lnbl - 1,:);
    rowind2(istart2(nblo):iend2(nblo),1) = rowind1(istart1(nbl):istart1(nbl) + lnbl - 1,1);
   else
    % the block is too small, append it to the last block
    s = iend1(kk+1) - istart1(kk+1) + 1;
    temp2(iend2(nblo) + 1:iend2(nblo) + s,:) = temp1(istart1(kk+1):istart1(kk+1) + s - 1,:);
    rowind2(iend2(nblo) + 1:iend2(nblo) + s,1) = rowind1(istart1(kk+1):istart1(kk+1) + s - 1,1);
    iend2(nblo) = iend2(nblo) + s;
   end % if lnbl
  end % if kk
  nbl = nblo;

 else % if mod, even steps
  % factorize the blocks
  for k = 1:nbl
   [~,ipivl,info] = gm_dgetf2(temp2(istart2(k):iend2(k),:));
%    [~,ipivl,info] = gm_dgetrf(temp2(istart2(k):iend2(k),:),nnb);
   % ipivl contains local row numbers
   s = iend2(k) - istart2(k) + 1;
   ipivl = ipivl(1:min(nb,s));
   ipiv = ipivl + istart2(k) - 1;
   % permute the rows of temp1 and rowind
   for i = 1:length(ipiv)
    temp2([i+istart2(k)-1,ipiv(i)],:) = temp2([ipiv(i),i+istart2(k)-1],:);
    rowind2([i+istart2(k)-1,ipiv(i)]) = rowind2([ipiv(i),i+istart2(k)-1]);
   end % for i
  end % for k
  if nbl == 1
   ipiv = rowind2(1:nb);
   return
  end % if nbl
  % concatenate the nb first rows of the blocks 2 by 2
  nblo = 0;
  start = 1;
  for k = 1:2:nbl-1
   kk = k + 1;
   nblo = nblo + 1;
   lk = min(iend2(k) - istart2(k) + 1,nb);
   lkk = min(iend2(kk) - istart2(kk) + 1,nb);
   istart1(nblo) = start;
   iend1(nblo) = istart1(nblo) + lk + lkk - 1;
   temp1(istart1(nblo):istart1(nblo) + lk - 1,:) = temp2(istart2(k):istart2(k) + lk - 1,:);
   temp1(istart1(nblo) + lk: iend1(nblo),:) = temp2(istart2(kk):istart2(kk) + lkk - 1,:);
   rowind1(istart1(nblo):istart1(nblo) + lk - 1,1) = rowind2(istart2(k):istart2(k) + lk - 1,1);
   rowind1(istart1(nblo) + lk: iend1(nblo),1) = rowind2(istart2(kk):istart2(kk) + lkk - 1,1);
   start = iend1(nblo) + 1;
  end % for k
  % is there a block left?
  if kk ~= nbl
   lnbl = iend2(nbl) - istart2(nbl) + 1; % length of last block
   if lnbl >= nb
    lnbl = min(lnbl,nb);
    % keep it as a block
    nblo = nblo + 1;
    istart1(nblo) = iend1(nblo-1) + 1;
    iend1(nblo) = istart1(nblo) + lnbl - 1;
    temp1(istart1(nblo):iend1(nblo),:) = temp2(istart2(nbl):istart2(nbl) + lnbl - 1,:);
    rowind1(istart1(nblo):iend1(nblo),1) = rowind2(istart2(nbl):istart2(nbl) + lnbl - 1,1);
   else
    % the block is too small, append it to the last block
    s = iend2(kk+1) - istart2(kk+1) + 1;
    temp1(iend1(nblo) + 1:iend1(nblo) + s) = temp2(istart2(kk+1):istart2(kk+1) + s - 1);
    rowind1(iend1(nblo) + 1:iend1(nblo) + s,1) = rowind2(istart2(kk+1):istart2(kk+1) + s - 1,1);
    iend1(nblo) = iend1(nblo) + s;
   end % if lnbl
  end % if kk
  nbl = nblo;
  
 end % if mod
 
end % while


