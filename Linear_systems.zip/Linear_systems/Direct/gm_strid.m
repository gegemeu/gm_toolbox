function x = gm_strid(T,d,b);
%GM_STRID solve of a symmetric tridiagonal system 

% factorization by gm_fac_trid

% Input:
% T = symmetric tridiagonal matrix
% d = vector computed by gm_fac_trid
% b = right-hand side
%
% Output:
% x = solution

%
% Author G. Meurant
% Updated March 2016
%

n = size(T,1);

y = zeros(n,1);
x = y;

y(1) = d(1) * b(1);
for i = 2:n
 y(i) = d(i) * (b(i) - T(i,i-1) * y(i-1));
end % for i

x(n) = y(n);
for i = n-1:-1:1
 x(i) = y(i) - T(i,i+1) * d(i) * x(i+1);
end % for i
