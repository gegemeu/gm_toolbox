function [U,Ui] = gm_U_from_H_recur(H);
%GM_U_FROM_H_RECUR triangular Hessenberg decomposition

% Input:
% H = unreduced upper Hessenberg matrix, H = U C inv(U)
%  U = upper triangular matrix, C = companion matrix
% 
% Output:
% U = upper triangular matrix with U(1,1) = 1
% Ui = inv(U)

% Uses the recurrence for the columns of U obtained from H U = U C

%
% Author G. Meurant
% November 2023
%

n = size(H,1);
U = zeros(n,n);

U(1,1) = 1;
U(1,2) = H(1,1);
U(2,2) = H(2,1);

for j = 2:n-1
 for i = 1:2
  U(i,j+1) = H(i,1:j) * U(1:j,j);
 end % for i
 for i = 3:j+1
  U(i,j+1) = H(i,i-1:j) * U(i-1:j,j);
 end % for i
end % for j

Ui = [];
if nargout == 2
 Ui = inv(U);
end

