function L = gm_Chol_trid(T);
%GM_CHOL_TRID Cholesky factorization of a symmetric tridiagonal matrix

% Input
% T = symmetric positive definite tridiagonal matrix
%
% Ouput 
% L = lower bidiagonal matrix, T = L L'

%
% Author G. Meurant
% April 2024

[d,ell,e,L,D] = gm_fact_trid_d_ell(T);

if any(d <= 0)
 error('gm_Chol_trid: The matrix T is not positive definite')
end % if 

L = L * diag(sqrt(d));

