function [G,g,GG] = gm_gamma_from_T(T);
%GM_GAMMA_FROM_T computes the gamma parameters of the inverses of T_k

% Input:
% T = symmetric tridiagonal matrix
%
% Output:
% G = matrix whose column k gives the parameters gamma for T_k
% g = + or - inverses of relative residual norms
% GG = G computed differently

%
% Author G. Meurant
% January 2019
%

n = size(T,1);
G = zeros(n,n);
GG = zeros(n,n);
e1 = eye(n,1);
% first column of inv(T)
gam = T \ e1;
% last column of inv(T)
en = zeros(n,1);
en(n) = 1;
g = (T \ en) / gam(n);
G(:,n) = gam;
% GG(:,n) = gam;
for k = n-1:-1:1
G(1:k,k) = gam(1:k) - gam(k+1) * g(1:k) / g(k+1);
% j = min(n,k+2);
% GG(1:k,k) = GG(1:k,j) - GG(k+1,j) * g(1:k) / g(k+1);
end % for k

