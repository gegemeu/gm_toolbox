function [L,U] = gm_Gauss_elimination(A);
%GM_GAUSS_ELIMINATION Gaussian elimination without pivoting, different coding

% coded with elementary matrices

% A = square matrix, A = L U

%
% Author G. Meurant
% Dec 2019
%

n = size(A,1);
U = A;
L = eye(n,n);

for k = 1:n-1
 Lk = eye(n,n);
 u = U(k+1:n,k) / U(k,k);
 Lk(k+1:n,k) = u;
 L = L * Lk;
 Lk(k+1:n,k) = -u;
 U = Lk * U;
end % for k

