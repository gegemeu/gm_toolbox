function Hi = gm_H_inv(H);
%GM_H_INV inverse of an unreduced upper Hessenberg matrix

% Input:
% H = unreduced upper Hessenberg matrix
%
% Output: 
% Hi = inverse of H

%
% Author G. Meurant
% March 2024
%

n = size(H,1);
Hi = zeros(n,n);

h = transpose(H(1,1:n-1));
h1n = H(1,n);
Ht = H(2:n,1:n-1);
Hti = inv(Ht);
w = H(2:n,n);

ell = Ht' \ h;
alpha = h1n - w' * ell;
alpha1 = 1 / alpha;
Hw = Ht \ w;

Hi(:,1) = alpha1 * [-Hw; 1];
for k = 2:n
 Hi(1:n-1,k) = Hti(:,k-1) + alpha1 * ell(k-1) * Hw;
 Hi(n,k) = -alpha1 * ell(k-1);
end % for k

