function [L,d]=gm_Chol_jik_bis(A);
%GM_CHOL_JIK_BIS Cholesky factorization, variant of jik version

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A = symmetric matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(A,1);

d = zeros(n,1);
temp = zeros(n,1);
L = tril(A);

for j = 1:n
 temp(j+1:n) = A(j+1:n,j);
 for i = j:n
  for k = 1:j-1
   L(i,j) = L(i,j) - L(i,k) * L(j,k) * d(k);
  end % for k
  if i ~= j
   L(i,j) = L(i,j) / d(j);
  else
   d(j) = L(j,j);
   L(j,j) = 1;
  end % if
 end % for i
end % for j
