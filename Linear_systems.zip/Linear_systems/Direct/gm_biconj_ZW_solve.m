function [x,nop] = gm_biconj_ZW_solve(A,b,ir);
%GM_BICONJ_ZW_SOLVE solves A x = b with biconjugate factorization

% A = square matrix
% b = right-hand side
% ir = 1 iterative refinement 

%
% Author G. Meurant
% March 2023
%

if nargin == 2
 ir = 0;
end % if

n = size(A,1);

[Z,Wt,p,row,col,nop] = gm_biconj_ZW(A);

Di = diag(1 ./ p);
nop = nop + n;

y = Z * Di * Wt * b(row);
x = y(gm_invperm(col));
nop = nop + 2 * n^2 + 5 * n;

if ir == 1
 digits(32);
 itmax = 1;
 bA = vpa(A);
 bb = vpa(b);
 bx = vpa(x);
 for k = 1:itmax
  % residual
  rx = bb - bA * bx; 
  nop = nop + n * (2 * n + 1) + n;
  r = double(rx);
  y = Z * Di * Wt * r(row);
  x = x + y(gm_invperm(col));
  bx = vpa(x);
  nop = nop + 2 * n^2 + 5 * n;
 end % for k
end % if ir

% if ir == 1
%  itmax = 1;
%  f_d_init_bits_expo(0);
%  f_d_init_round(1); % initialize the rounding mode
%  nbits = 112;
%  bA = f_d_dec2floatp(A,nbits);
%  bb = f_d_dec2floatp(b,nbits);
%  bx = f_d_dec2floatp(x,nbits);
%  for k = 1:itmax
%   % residual
%   bAx = f_d_mat_prod_b(A,bA,bx);
%   rx = f_d_minusm(bb,bAx); 
%   r = f_d_floatp2dec(rx);
%   y = Z * Di * Wt * r(row);
%   x = x + y(gm_invperm(col));
%   bx = f_d_dec2floatp(x,nbits);
%   nop = nop + 2 * n^2 + 5 * n;
%  end % for k
% end % if ir



