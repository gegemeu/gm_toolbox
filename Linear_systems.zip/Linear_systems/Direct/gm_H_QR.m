function [R,rot,Q] = gm_H_QR(H,iter);
%GM_H_QR QR factorization of an upper Hessenberg matrix

% Input:
% H = unreduced upper Hessenberg matrix
% iter = 1, one step of refinement
%
% Output:
% R = upper triangular matrix, H = QR
% rot = Givens rotations defining Q
% Q = (almost) unitary matrix

%
% Author G. Meurant
% March 2024
%

if nargin == 1
 iter = 0;
end % if

n = size(H,1);
rot = zeros(2,n-1);
if nargout == 3
 H_old = H;
end % if

for k = 1:n-1
 gk1 = H(k+1,k);
 % apply the preceding Givens rotations to the last column just computed
 for kk = 1:k-1
  g1 = H(kk,k);
  g2 = H(kk+1,k);
  H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
  H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
 end % for kk
 % compute, store and apply a new rotation to zero the last term in kth column
 gk = H(k,k);
 if gk == 0
  rot(1,k) = 0;
  rot(2,k) = 1;
 elseif gk1 == 0
  rot(1,k) = 1;
  rot(2,k) = 0;
 else
  cs = sqrt(abs(gk1)^2 + abs(gk)^2);
  if abs(gk) < abs(gk1)
   mu = gk / gk1;
   tau = conj(mu) / abs(mu);
  else
   mu = gk1 / gk;
   tau = mu / abs(mu);
  end % if
  % store the rotation for the next columns
  rot(1,k) = abs(gk) / cs; % cosine
  rot(2,k) = abs(gk1) * tau / cs; % sine
 end % if gk
 % modify the diagonal entry
 H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
 H(k+1,k) = 0;
end % for k
% modify the last column
for kk = 1:n-1
 g1 = H(kk,n);
 g2 = H(kk+1,n);
 H(kk+1,n) = -rot(2,kk) * g1 + rot(1,kk) * g2;
 H(kk,n) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
end % for kk
R = H;
if nargout == 3
 Q = H_old / R;
 if iter == 1
  % iterate as in CholQR2
  S = Q' * Q;
  % Cholesky factor
  [R2,msg] = chol(S);
  if msg > 0
   return
  end
  R = R2 * R;
  Q = H_old / R;
 end
end % if




