function [Ls,Ds,Us] = gm_fac_LDU_shifted_Hess(L,D,U,mu);
%GM_FAC_LDU_SHIFTED_HESS L D U factorization of an= shifted upper Hessenberg matrix

% Input:
% L = lower triangular (bidiagonal) matrix with unit diagonal
% D = diagonal matrix
% U = upper triangular matrix with unit diagonal
%   from gm_fac_LDU_Hess
% H = L D U, upper Hessenberg matrix
% mu = shift
%
% Output:
% Ls = lower triangular (bidiagonal) matrix with unit diagonal
% Ds = diagonal matrix
% Us = upper triangular matrix with unit diagonal
% H - mu I = Ls Ds Us

%
% Author G. Meurant
% October 2024
%

n = size(L,1);
Ls = eye(n,n);
Us = eye(n,n);
ds = zeros(n,1);
d = diag(D);

ds(1) = d(1) - mu;
Ls(2,1) = (L(2,1) * d(1)) / ds(1);
Us(1,2:n) = (d(1) * U(1,2:n)) / ds(1);
for i = 2:n-1
 ds(i) = d(i) - mu + L(i,i-1) * d(i-1) * (U(i-1,i) - Us(i-1,i));
 Us(i,i+1:n) = (d(i) * U(i,i+1:n) + L(i,i-1) * d(i-1) * (U(i-1,i+1:n) - Us(i-1,i+1:n))) / ds(i);
 Ls(i+1,i) = (L(i+1,i) * d(i)) / ds(i);
end % for i
ds(n) = d(n) - mu + L(n,n-1) * d(n-1) * (U(n-1,n) - Us(n-1,n));

Ds = diag(ds);





