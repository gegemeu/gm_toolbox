function [Z,Wt,p,row,col,nop,A] = gm_biconj_ZW(A);
%GM_BICONJ_ZW factorization of inv(A), with row and column pivoting 

% Input:
% A = square nonsingular matrix
%
% Output:
% W' (P A Q) Z = D diagonal
% returns Z, W' and D as a vector of diagonal entries
% row = row permutations, P = eye(n), P = P(row,:)
% col = column permutations, Q = eye(n), Q = Q(:,col)
% nop = number of floating point operations
% A = pivoted A
%

% see Bollhofer and Saad, SIMAX 2002

%
% Author G. Meurant
% March 2023
%

n = size(A,1);

EY = eye(n,n);
Z = eye(n,n);
W = eye(n,n);
p = zeros(n,1);
q = zeros(n,1);
row = 1:n;
col = 1:n;
tol = 0.1;
tol = 0.15;
npiv = 20;
nop = 0;

for i = 1:n
 piv = 0;
 satp = 0;
 satq = 0;
 % pivoting
 k = 0;
 while satp == 0 && k < npiv
  k = k + 1;
  p(i:n) = W(:,i:n)' * (A * Z(:,i));
  nop = nop + (2 * n - i + 1) * (2 * n + 1);
  [val,I] = max(abs(p(i:n)));
  if abs(p(i)) < tol * val
   satq = 0;
   ip = i + I(1) - 1; % global index
   if ip ~= i
    piv = 1;
    A(:,[i,ip]) = A(:,[ip,i]);
    ZI = Z - EY;
    ZI(:,[i,ip]) = ZI(:,[ip,i]);
    Z = ZI + EY;
    nop = nop + 2 * n;
    p([i,ip]) = p([ip,i]);
    col([i,ip]) = col([ip,i]);
   end % if ip
  end % if abs
  satp = 1;
  % pivoting
  if satq == 0
   q(i:n) = (W(:,i)' * A) * Z(:,i:n);
   nop = nop + (2 * n - i + 1) * (2 * n + 1);
  end % if
  [val,I] = max(abs(q(i:n)));
  if abs(q(i)) < tol * val
   satp = 0;
   ip = i + I(1) - 1; % global index
   if ip ~= i
    piv = 1;
    A([i,ip],:) = A([ip,i],:);
    WI = W - EY;
    WI(:,[i,ip]) = WI(:,[ip,i]);
    W = WI + EY;
    nop = nop + 2 * n;
    q([i,ip]) = q([ip,i]);
    row([i,ip]) = row([ip,i]);
   end % if ip
  end % if abs
  satq = 1;
 end % while
 
 if piv == 1
  % must recompute p and q with the new A, Z, W
  p(i:n) = W(:,i:n)' * (A * Z(:,i));
  q(i:n) = (W(:,i)' * A) * Z(:,i:n);
  nop = nop + 2 * (2 * n - i + 1) * (2 * n + 1);
 end % if
 p1 = 1 / p(i);
 pp1 = p1 * p(i+1:n);
 qq1 = p1 * q(i+1:n);
 nop = nop + 2 * (n - i);
 for j = i+1:n
  Z(:,j) = Z(:,j) - qq1(j-i) * Z(:,i);
  W(:,j) = W(:,j) - pp1(j-i) * W(:,i);
  nop  = nop + 4 * n;
 end % for j
end % for i

Wt = W';


