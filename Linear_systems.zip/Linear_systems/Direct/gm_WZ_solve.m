function X = gm_WZ_solve(W,Z,ipiva,ipivb,B);
 %GM_WZ_SOLVE solution of A X = B, WZ factorization with row swaps
 
 % Input:
 % A = square matrix
 % B = right-hand sides
 % W, Z, ipiva, ipivb = data from gm_WZ
 %
 % Ouput:
 % X = solutions
 
 %
 % Author G. Meurant
 % March 2023
 %
 
 n = size(W,1);
 nb = size(B,2);
 
 kstart = 1;
 kend = n;
 sA = n;
 while sA > 2
  ipa = ipiva(kstart); % global index
  %  ipa = kstart; % no pivoting
  if ipa ~= kstart
   % swap rows and the right-hand side
   B([kstart,ipa],:) = B([ipa,kstart],:);
  end % if ipa
  ipb = ipivb(kend); % global index
  %  ipb = kend; % no pivoting
  if ipb ~= kend
   % swap rows and the right-hand side
   B([kend,ipb],:) = B([ipb,kend],:);
  end % if ipa
  sA2 = sA - 2;
  ws = -W(kstart+1:kend-1,kstart);
  we = -W(kstart+1:kend-1,kend);
  for j = 1:nb
   B(kstart+1:kend-1,j) = (B(kstart+1:kend-1,j) + B(kstart,j) * ws) + B(kend,j) * we;
  end % for j
  sA = sA2;
  kstart = kstart + 1;
  kend = kend - 1;
 end % while
 
 % mmW = max(max(abs(W)))
 
 if mod(n,2) == 0
  even = 1;
 else
  even = 0;
 end % if
 % solve of Z X = B
 % we start from the center
 if even == 1
  %n even,  we have a 2 x 2 system in the center
  n2 = n / 2;
  Z2 = [Z(n2,n2) Z(n2,n2+1); Z(n2+1,n2) Z(n2+1,n2+1)];
  rhs = [B(n2,:); B(n2+1,:)];
  X2 = Z2 \ rhs;
  X(n2,:) = X2(1,:);
  X(n2+1,:) = X2(2,:);
  is = n2 - 1; ie = n2 + 2;
  js = n2; je = n2 + 1;
 else
  % n odd, we have only one equation in the center
  m = ceil(n / 2);
  dz = 1 / Z(m,m);
  X(m,:) = dz * B(m,:);
  is = m -1; ie = m +1;
  js = m; je = m;
 end % if
 while is >= 1
  % we have a 2 x 2 system to solve
  Z2 = [Z(is,is) Z(is,ie); Z(ie,is) Z(ie,ie)];
  s = B(is,:);
  for j = js:je
   s = s - Z(is,j) * X(j,:);
  end % for j
  rhs(1,:) =  s;
  s = B(ie,:);
  for j = js:je
   s = s - Z(ie,j) * X(j,:);
  end % for j
  rhs(2,:) = s;
  X2 = Z2 \ rhs;
  X(is,:) = X2(1,:);
  X(ie,:) = X2(2,:);
  is = is -1; ie = ie + 1;
  js = js - 1; je = je + 1;
 end % while
 
 
 
 
 
