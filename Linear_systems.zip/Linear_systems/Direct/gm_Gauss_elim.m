function [L,U] = gm_Gauss_elim(A);
%GM_GAUSS_ELIM Gaussian elimination without pivoting of the m-by-n matrix A with m >= n

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A  = matrix
%
% Output:
% L = lower trapezoidal m x n matrix with 1's on the diagonal
% U = upper triangular n x n matrix

%
% Author G. Meurant
% Oct 2015
%

[m, n] = size(A);
if m < n,
 error('gm_gauss_elim: Matrix must be m-by-n with m >= n')
end

for k = 1:min(m-1,n)
 
 i = k+1:m;
 if A(k,k) ~= 0
  A(i,k) = A(i,k) / A(k,k);
 end % if
 
 if k+1 <= n
  % Elimination
  j = k+1:n;
  A(i,j) = A(i,j) - A(i,k) * A(k,j);
 end % if
 
end % for k

L = tril(A,-1) + eye(m,n);
U = triu(A);
U = U(1:n,:);


