function [Z,Wt,p]=gm_biconj_ZW_np_2(A);
%GM_BICONJ_ZW_NP_2 factorization of inv(A), without pivoting

% A = square nonsingular matrix
% W' A Z = D diagonal
% returns Z, W' and D as a vector of diagonal entries
%

% see Bollhofer and Saad, SIMAX 2002

%
% Author G. Meurant
% March 2023
%

n = size(A,1);

Z = eye(n,n);
W = eye(n,n);
p = zeros(n,1);
q = zeros(n,1);

for i = 1:n
 % diagonal entries
 AZ = A * Z;
 p(i:n) = W(:,i:n)' * AZ(:,i);
 p1 = 1 / p(i);
 pp1 = p1 * p(i+1:n);
 q(i:n) = W(:,i)' * AZ(:,i:n);
 qq1 = p1 * q(i+1:n);
 for j = i+1:n
  Z(:,j) = Z(:,j) - qq1(j-i) * Z(:,i);
  W(:,j) = W(:,j) - pp1(j-i) * W(:,i);
 end % for j
end % for i

Wt = W';


