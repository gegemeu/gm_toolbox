function X = gm_dgesv(A,B,meth);
%GM_DGESV solve A X = B with Gaussian elimination with partial pivoting

% A = square matrix
% B = right-hand sides
% meth = method number, 1, 2 , ..., 5

% LAPACK-like functions

%
% Author G. Meurant
% February 2023
%

nb = 40; % block size

switch meth
 case 1
  % unblocked method
  [A,ipiv,info] = gm_dgetf2(A);
  
 case 2
  % blocked Crout version
  [A,ipiv,info] = gm_dgetrf_c(A,nb);
  
 case 3
  % blocked left-looking version
  [A,ipiv,info] = gm_dgetrf_lk(A,nb);
  
 case 4
  % lrecursive version
  [A,ipiv,info] = gm_dgetrf_r(A);
  
 case 5
  % blocked standard version
  [A,ipiv,info] = gm_dgetrf(A,nb);
  
 case 6 
  % unblocked method, no pivoting
  [A,info] = gm_dgetf2_np(A);
  ipiv = 1:size(A,1);
  
 otherwise
  error('meth must be 1,2,3,4,5 or 6')
end % switch

% triangular solves
X = gm_dgetrs(A,ipiv,B);

