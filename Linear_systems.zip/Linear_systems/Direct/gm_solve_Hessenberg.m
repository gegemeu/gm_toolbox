function x = gm_solve_Hessenberg(H,b);
%GM_SOLVE_HESSENBERG solves H x = b with UC factorization

% Input:
% H = unreduced upper Hessenberg matrix
% b = right-hand side
%
% Output:
% x = solution

%
% Author
% G. Meurant
% March 2025
%

n = size(H,1);
U = zeros(n,n);
U(1,1) = 1;
U(:,2:n) = H(:,1:n-1);

alp = -U \ H(:,n);
Ci = zeros(n,n);
Ci(1:n-1,2:n) = eye(n-1,n-1);

Ci(1:n-1,1) = -alp(2:n) / alp(1);
Ci(n,1) = -1 / alp(1);

x = Ci * (U \ b);

