function [x,info,nop,L,U] = gm_dpurcell_np(A,b);
%GM_DPURCELL_NP solves Ax = b, Purcell orthogonalization method without pivoting

% Input:
% A = square matrix
% b = right-hand side
%
% Output:
% x = solution
% info = return code
% nop = number of operations
% A = L * U

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end
if info ~= 0
 error('gm_dpurcell_np, info ~= 0')
end
Z = zeros(n,n);

A = [A -b];
V = eye(n+1,n+1);
Z(:,1) = V(1:n,1);
nop = 0;
k = 1;

for i = n:-1:1
 ni = n + 1 - i;
 av = A(ni,:) * V(:,1:i+1); % dot products
 nop = nop + (2 * n + 1) * (i + 1);
 piv = 1; % no pivoting
 m = [1:piv-1, piv+1:i+1];
 alp = -av(m) / av(piv);
 nop = nop + i;
%  V_new = gm_prank1(V_old(:,m),V_old(:,piv),alp);
 V = gm_prank1(V(:,m),V(:,piv),alp);
 nop = nop + 2 * i * (n + 1);
%  V = V_new;
 k = k + 1;
 Z(:,k) = V(1:n,1);
end % for i

Z = Z(:,1:n);
U = inv(Z);
L = A(:,1:n) * Z;

mult = 1 / V(n+1,1);
x = mult * V(1:n,1);
nop = nop + n;




