function [x,info,nop] = gm_dpurcell_b(A,b);
%GM_DPURCELL_B solve Ax = b, Purcell orthogonalization method

% A = square matrix
% b = right-hand side

%
% Author G. Meurant
% March 2023
%

[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end
if info ~= 0
 error('gm_dpurcell_b, info ~= 0')
end

V = eye(n,n);
U = zeros(n,n);
pivot = zeros(n,1);
nop = 0;
k = 0;

for i = n:-1:1
 ni = n - i + 1;
 av = A(ni,:) * V(:,1:i); % dot products
 nop = nop + (2 * n + 1) * i;
 [~,I] = max(abs(av));
 piv = I(1); %index of largest dot product
 m = [1:piv-1, piv+1:i];
 alp = -av(m) / av(piv);
 nop = nop + i - 1;
 k = k + 1;
 U(:,k) = V(:,piv); % store the pivot column
 pivot(k) = av(piv); % store the pivot
 V = gm_prank1(V(:,m),V(:,piv),alp);
 nop = nop + 2 * (i - 1) * n;
end % for i

x = zeros(n,1);
for k = 1: n
 bet = (b(k) - A(k,:) * x) / pivot(k);
 x = x + bet * U(:,k);
 nop = nop + 1 + 4 * n;
end % for k







