function [L,D,U] = gm_fact_trid(T);
%GM_FAC_TRID factorization of a symmetric tridiagonal matrix

% Input:
% T = tridiagonal matrix
%
% Output:
% T = L D U
% L = lower bidiagonal matrix
% D = diagonal matrix
% U = upper bidiagonal matrix

%
% Author G. Meurant
% March 2024
%

n = size(T,1);

d = zeros(n,1);

d(1) = T(1,1);

for i = 2:n
 d(i) = T(i,i) - T(i,i-1)^2 / d(i-1);
end % for i

L = diag(d);
for i = 2:n
 L(i,i-1) = T(i,i-1);
end % for i

d = 1 ./ d;
D = diag(d);

U = L';




