function x = gm_solve_triangle(L,b);
%GM_SOLVE_TRIANGLE solves a lower triangular system with correction of the rounding errors 

% gives a better result for badly conditioned matrices

% Input:
% L = lower triangular matrix
% b = right-hand side
%
% Output:
% x = solution of A x = b

%
% April 2014
% Updated August 2015
%

n = size(L,1);

x = zeros(n,1);
Del = zeros(n,1);

for i = 1:n
 s = b(i);
 u = 0;
 for j = 1:i-1
  [p,pij] = gm_TwoProd(L(i,j),x(j));
  [s,sig] = gm_TwoSum(s,-p);
  u = u - (L(i,j) * Del(j) + pij - sig);
 end % for j
 
 [x(i),del] = gm_ApproxTwoDiv(s,L(i,i));
 Del(i) = u / L(i,i) + del;
end % for i

% correction due to rounding errors

x(2:n) = x(2:n) + Del(2:n);

