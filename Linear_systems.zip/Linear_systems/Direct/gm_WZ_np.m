function [W,Z] = gm_WZ_np(A);
%GM_WZ_NP WZ factorization without pivoting

% A = square matrix 

%
% Author G. Meurant
% March 2023
%

n = size(A,1);

W = eye(n,n);
Z = zeros(n,n);

kstart = 1;
kend = n;
sA = n;
while sA > 2
 % first and last rows
 W(kstart,kstart:kend) = eye(1,sA);
 W(kend,kstart:kend) = [zeros(1,sA-1) 1];
 Z(kstart,kstart:kend) = A(kstart,kstart:kend);
 Z(kend,kstart:kend) = A(kend,kstart:kend);
 A2 = [A(kstart,kstart) A(kend,kstart); A(kstart,kend) A(kend,kend)]; % 2 x 2 matrix
 if abs(det(A2)) < 1e-14
  fprintf('\n WZ_np: small determinant \n')
  %error('gm_WZ_np: too small determinant of A2')
 end % if
 rhs = [A(kstart+1:kend-1,kstart)'; A(kstart+1:kend-1,kend)']; % right-hand sides
 X2 = A2 \ rhs; % solve all the 2 x 2 systems
 W(kstart+1:kend-1,kstart) = X2(1,:); 
 W(kstart+1:kend-1,kend) = X2(2,:);
 % reduced matrix
 % this is be the best coding
%  A(kstart+1:kend-1,kstart+1:kend-1) = A(kstart+1:kend-1,kstart+1:kend-1)...
%   + Wi(kstart+1:kend-1,kstart) * Z(kstart,kstart+1:kend-1)...
%   + Wi(kstart+1:kend-1,kend) * Z(kend,kstart+1:kend-1); % rank-2 update
% this is a better coding
 sA2 = sA - 2;
 UP = zeros(sA2,sA2);
 ws = -W(kstart+1:kend-1,kstart);
 we = -W(kstart+1:kend-1,kend);
 zs = Z(kstart,kstart+1:kend-1);
 ze = Z(kend,kstart+1:kend-1);
 for j = 1:sA2
% %   UP(:,j) = A(kstart+1:kend-1,kstart+j) + Z(kstart,kstart+j) * ws + Z(kend,kstart+j) * we;
  UP(:,j) = A(kstart+1:kend-1,kstart+j) + zs(j) * ws + ze(j) * we; % rank-2 update
 end % for j
 A(kstart+1:kend-1,kstart+1:kend-1) = UP;
 sA = sA2;
 kstart = kstart + 1;
 kend = kend -1;
end % while
Z(kstart:kend,kstart:kend) = A(kstart:kend,kstart:kend);

