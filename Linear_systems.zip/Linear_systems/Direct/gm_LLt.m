function L=gm_LLt(T);
%GM_LLT L L^T Cholesky factorization of a (complex) tridiagonal matrix

% Input:
% T = tridiagonal matrix
%
% Output:
% L = lower triangular (bidiagonal) matrix, T = L L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(T,1);

L = zeros(n,n);
d = zeros(n,1);

d(1) = T(1,1);

% diagonal entries
for i = 2:n
 d(i) = T(i,i) - (T(i,i-1)^2) / d(i-1);
end % for i

L(1,1) = sqrt(d(1));
for i = 2:n
 s = sqrt(d(i-1));
 L(i,i) = sqrt(d(i));
 L(i,i-1) = T(i,i-1) / s;
end % for i

