function [gam,sig] = gm_Schur_params(H);
%GM_SCHUR_PARAMS Schur parameters of a unitary upper Hessenberg matrix with a real positive subdiagonal

% Input:
% H = unitary upper Hessenberg matrix with a real positive subdiagonal
%
% Output:
% gam = Schur parameters
% sigma = complementary Schur parameters

%
% Author G. Meurant
% June 2012
% December 2023
%

n = size(H,1);

gam = zeros(n,1);

sig = diag(H,-1);

s = cumprod(sig);

gam(1) = -H(1,1);

gam(2:n) = -H(1,2:n) ./ s';

