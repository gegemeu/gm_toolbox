function [A,ipvt,info,L,U,P] = gm_dgefa(A);
%GM_DGEFA translation of LINPACK DGEFA, LU factorization with partial pivoting

% A = matrix

% P * A = L * U

% LINPACK's DGEFA does not compute L, but ony the multipliers needed to solve the system
% A square matrix

%
% translated by G. Meurant
% February 2023
%

[n,m] = size(A);
ipvt = zeros(n,1);
pp = 1:n;
info = 0;
nm1 = n - 1;
if nm1 < 1
 ipvt(n) = n;
 if A(n,n) == 0
  info = n;
 end % if
 L = 1;
 U = A(n,n);
 return
end % if
L = eye(n,n);
for k = 1:nm1
 kp1 = k + 1;
 [~,I] = max(abs(A(k:n,k)));
 l = I(1) + k - 1; % pivot index, BLAS1 idamax
 ipvt(k) = l;
 pp( [k, l] ) = pp( [l, k] );
 if A(l,k) == 0 % zero pivot implies this column is already triangularized
  info = k;
  continue
 end
 if l ~= k % interchange if necessary
  t = A(l,k);
  A(l,k) = A(k,k);
  A(k,k) = t;
 end
 t = -1 / A(k,k); % compute multipliers
 A(k+1:n,k) = t * A(k+1:n,k); % BLAS1 dscal
 L(k+1:n,k) = -A(k+1:n,k); % this is not in LINPACK DGEFA
 % row elimination with column indexing
 for j = kp1:n
  t = A(l,j);
  if l ~= k % interchange if necessary
   A(l,j) = A(k,j);
   A(k,j) = t;
  end % if
  A(k+1:n,j) = t * A(k+1:n,k) +  A(k+1:n,j); % BLAS1 daxpy
 end % for j
 % apply the permutation to the previous columns (this is not in dgefa)
 % this is to obtain L
 L([l,k],1:k-1) = L([k,l],1:k-1);
end % for k
ipvt(n) = n;
if A(n,n) == 0
 info = n;
end

if nargout > 3
 U = triu(A);
 P = eye(n);
 P = P(pp,:);
end % if


