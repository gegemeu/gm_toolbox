function d = gm_fac_trid(T);
%GM_FAC_TRID factorization of a symmetric tridiagonal matrix

% Input:
% T = tridiagonal matrix
%
% Output:
% d = vector of the inverses of the diagonal entries of the bidiagonal factor

%
% Author G. Meurant
% Updated March 2016
%

n = size(T,1);

d = zeros(n,1);

d(1) = T(1,1);

for i = 2:n
 d(i) = T(i,i) - T(i,i-1)^2 / d(i-1);
end % for i

d = 1 ./ d;
