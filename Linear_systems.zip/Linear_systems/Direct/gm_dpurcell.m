function [x,info,nop] = gm_dpurcell(A,b);
%GM_DPURCELL solve Ax = b, Purcell orthogonalization method

% A = square matrix
% b = right-hand side

% this coding is too slow, see gm_dpurcell_2

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end
if info ~= 0
 error('gm_dpurcell, info ~= 0')
end

A = [A -b];
V_old = eye(n+1,n+1);
% V_old = randn(n+1,n+1);
nop = 0;

for i = n:-1:1
 ni = n + 1 - i;
 av = A(ni,:) * V_old(:,1:i+1); % dot products
 nop = nop + (2 * n + 1) * (i + 1);
 [~,I] = max(abs(av));
 piv = I(1); %index of largest dot product
 m = [1:piv-1, piv+1:i+1];
 for k = 1:i
  if av(piv) ~= 0
   alk = -av(m(k)) / av(piv);
   nop = nop + 1;
  else
   info = -i;
   x = 0;
   return
  end % if av
  V_new(:,k) = alk * V_old(:,piv) + V_old(:,m(k));
  nop = nop + 2 * (n + 1);
 end % for k
 V_new = V_new(:,1:k);
 V_old = V_new;
 
end % for i

x = V_old(1:n,1) / V_old(n+1,1);
nop = nop + n;




