function [x,info] = gm_dgbjsvr(A,B,nk);
%GM_DGBJSVR solve Ax = b, block Gauss-Jordan with column swaps

% does not work so well because of the lack of good pivoting

% A = square matrix
% B = right-hand sides
% nk = block size

% reduction to identity form

%
% Author G. Meurant
% February 2023
%

[m,n] = size(A);
[mb,nb] = size(B);
col = 1:m;
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
elseif m ~= mb
 info = -3;
elseif nk >= max(m,n);
 info = -4;
end
if info ~= 0
 error('gm_dgbjsvr, info ~= 0')
end
nbl = ceil(m / nk); % number of blocks

% % compute 2 RBTs
% rng('default');
% d = 2;
% RU = gm_RBT(n,d);
% RV = gm_RBT(n,d);
% % transform A
% A = RU' * A * RV;
% B = RU' * B;

for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 % permute the columns (this is not enough to obtain a good stability)
 for j = js:je
  [~,I] = max(abs(A(j,js:n))); % look in all columns, not only in the first block
  jp = I(1);
  jpg = jp + js - 1; % global index
  if jpg ~= j
   A(:,[j,jpg]) = A(:,[jpg,j]);
   temp = col(j);
   col(j) = col(jpg);
   col(jpg) = temp;
  end % if
 end % for j
 A11 = A(js:je,js:je);
 IA11 = inv(A11);
 A01 = A(1:js-1,js:je);
 A21 = A(je+1:m,js:je);
 A02 = A(1:js-1,je+1:n);
 A12 = A(js:je,je+1:n);
 A22 = A(je+1:m,je+1:n);
 B0 = B(1:js-1,:);
 B1 = B(js:je,:);
 B2 = B(je+1:m,:);
%  A01 = A01 * IA11;
 A01 = A01 / A11;
%  A21 = A21 * IA11;
 A21 = A21 / A11;
 A02 = A02 - A01 * A12;
 A22 = A22 - A21 * A12;
 B0 = B0 - A01 * B1;
 B2 = B2 - A21 * B1;
 A01 = A01 - A01 * A11;
 A21 = A21 - A21 * A11;
 
 A(js:je,js:je) = IA11;
 A(1:js-1,js:je) = A01;
 A(je+1:m,js:je) = A21;
 A(1:js-1,je+1:n) = A02;
 A(js:je,je+1:n) = A12;
 A(je+1:m,je+1:n) = A22;
 B(1:js-1,:) = B0;
 B(js:je,:) = B1;
 B(je+1:m,:) = B2;
end % for k

x = zeros(m,nb);
for k = 1:nbl
 % block k
 js = (k - 1) * nk + 1; % start of the block
 je = min(js + nk - 1,m); % end of the block
 IA11 = A(js:je,js:je);
 x(js:je,:) = IA11 * B(js:je,:);
end % for k

ip = gm_invperm(col);
x = x(ip,:);

% x = RV * x;




