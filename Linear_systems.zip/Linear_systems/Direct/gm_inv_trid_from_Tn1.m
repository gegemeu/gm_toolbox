function [Tni,rho,nu] = gm_inv_trid_from_Tn1(Tn1,alpha,beta);
%GM_INV_TRID_FROM_TN1 recursive inverse of a symmetric tridiagonal matrix

% inv(T_n) from T_{n-1}

% Input:
% Tn1 = a symmetric tridiagonal matrix of order n-1
% alpha, beta = entries added at the bottom
%  Tn = ( Tn1, beta*e_{n-1}; beta*e_{n-1}^T, alpha)
% 
% Output:
% Tni = inverse of Tn
% rho, nu = factors of the entries of Tni

% The lower triangular part is tril(rho * transpose(nu))

%
% Author G. Meurant
% March 2024
%

Tn1i = inv(Tn1); % this can be computed recursively starting from T(1,1)

[Tni,rho,nu] = gm_inv_trid_from_inv_Tn1(Tn1i,alpha,beta);



