function [U,nop] = gm_U_from_Schur_params(gam);
%GM_U_FROM_SCHUR_PARAMS constructs U of the triangular Hessenberg decomposition from the Schur parameters

% H is a unitary upper Hessenberg matrix H = U C inv(U)

% Input:
% gam = Schur parameters of H
%
% Output:
% U = upper triangular matrix
% nop = number of floating point operations

%
% Author G. Meurant
% December 2023
%

n = length(gam);
I = find(abs(gam(1:n-1)) > 1);
if ~isempty(I)
 error('gm_U_from_Schur_params: abs(gam(i)) must be < 1')
end

gam = gam(:)';

sig = sqrt(1 - abs(gam(1:n-1)).^2);

U = zeros(n,n);
U(1,1) = 1;
U(1:2,2) = [-gam(1); sig(1)];
y = U(:,2);
nop = 0;

for k = 3:n
 % apply elementary matrices G_{k-1} to G_1
 for j = k-1:-1:1
  yj = -gam(j) * y(j) + sig(j) * y(j+1);
  yj1 = sig(j) * y(j) + conj(gam(j)) * y(j+1);
  y(j:j+1,1) = [yj; yj1];
  nop = nop + 6;
 end % for j
 U(:,k) = y;
end % for k

