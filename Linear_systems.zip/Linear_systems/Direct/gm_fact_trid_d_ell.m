function [d,ell,e,L,D] = gm_fact_trid_d_ell(T);
%GM_FACT_TRID_D_ELL factorization of a symmetric tridiagonal matrix

% Input:
% T = tridiagonal matrix = L D L'
%
% Output:
% d = vector of the diagonal entries of the bidiagonal factor
% ell = subdiagonal, 1s on the diagonal
% e = squares of the bidiagonal entries of Cholesky (for QD algorithm)
% L = lower bidiagonal matrix
% D = diagonal matrix = diag(d)

% The Cholesky factorization is obtained as L * sqrt(D)

%
% Author G. Meurant
% Updated March 2016
% Updated April 2024
%

n = size(T,1);
L = [];
D = [];

d = zeros(n,1);
ell = zeros(n-1,1);
e = zeros(n-1,1);

d(1) = T(1,1);

for i = 2:n
 d(i) = T(i,i) - T(i,i-1)^2 / d(i-1);
 ell(i-1) = T(i,i-1) / d(i-1);
 e(i-1) = T(i,i-1)^2 / d(i-1);
end % for i

if nargout > 3
 D = diag(d);
 L = eye(n,n);
 for i = 2:n
  L(i,i-1) = ell(i-1);
 end % for i
end % if


 
 
