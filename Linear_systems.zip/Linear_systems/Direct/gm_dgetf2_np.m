function [A,info,L,U] = gm_dgetf2_np(A);
% GM_DGETF2_NP LAPACK LU factorization without pivoting

% A = matrix

% this is useful for the tournament pivoting implementation

% A = L * U

% LAPACK's DGETF2 does not compute L, but ony the multipliers needed to solve the system

% Assume m >= n at the end

%
% translated by G. Meurant
% February 2023
%

[m,n] = size(A);
info = 0;
if m < 0
 info = -1;
elseif n < 0
 info = -2;
end
if info ~= 0
 error('gm_dgetf2_np, info ~= 0')
end
% Compute machine safe minimum
sfmin = realmin;
small = 1 / realmax;
if small >= sfmin
 sfmin = small * (1 + eps );
end % if
for j = 1:min(m,n)
 % Find pivot and test for singularity
%  [~,I] = max(abs(A(j:m,j)));
 jp = j; % no pivoting
 if A(jp,j) ~= 0
  % Compute elements j+1:m of j-th column
  if j < m
   if abs(A(j,j)) >= sfmin
    t = 1 / A(j,j);
    A(j+1:m,j) = t * A(j+1:m,j); % dscal
   else
    A(j+1:m,j) = A(j+1:m,j) / A(j,j);
   end % if abs
  end % if j < m
 elseif info == 0
  info = j;
 end % if jp
 if j < min(m,n)
  % Update trailing submatrix
  jm = j+1:m;
  jn = j+1:n;
  u = -A(j+1:m,j);
  v = A(j,j+1:n);
  A(jm,jn) = gm_prank1(A(jm,jn),u,v);
%   A(j+1:m,j+1:n) = A(j+1:m,j+1:n) - A(j+1:m,j) * A(j,j+1:n); % rank-1 update dger
 end % if
end % for j

if nargout > 3
 % this is not in dgetf2
 % Assume m >= n
 L = zeros(m,n);
 L(1:m,1:n) = tril(A(1:m,1:n),-1) + eye(m,n);
 U = triu(A(1:n,1:n));
end % if nargout > 3






