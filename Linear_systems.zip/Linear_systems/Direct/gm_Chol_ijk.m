function [L,d]=gm_Chol_ijk(A);
%GM_CHOL_IJK Cholesky factorization, ijk version

% this is a slow code just for demonstration
% use it only for small matrices

% Input:
% A = symmetric matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% Updated March 2016
%

n = size(A,1);

d = zeros(n,1);
temp = zeros(n,1);

L = tril(A);

d(1) = A(1,1);
L(1,1) = 1;

for i = 2:n
 temp(1:i) = A(i,1:i);
 for j = 1:i
  if j ~= i
   L(i,j) = temp(j) / d(j);
  end % if
  for k = j+1:i
   temp(k) = temp(k) - temp(j) * L(k,j);
  end % for k
 end   % for j
 d(i) = temp(i);
 L(i,i) = 1;
end % for i 
