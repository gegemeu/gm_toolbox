function [x,A,b]=gm_gauss_el(A,b);
%GM_GAUSS_EL Gaussian elimination without pivoting

% Input:
% A, b = matrix and right-hand side
%
% Output:
% x = solution
% A, b = modified matrix and right-hand side

%
% Author G. Meurant
% March 2006
% Updated March 2016
%

n = size(A,1);

x = zeros(n,1);

for k = 1:n-1
 temp = A(:,k);
 % we assume that there is no zero pivot
 mult = 1 / A(k,k);
 for i = k+1:n
  multi = mult * temp(i);
  b(i) = b(i) - multi * b(k);
  for j = k+1:n
   A(i,j) = A(i,j) - multi * A(k,j);
  end
 end
end

% solve the triangular system
x(n) = b(n) / A(n,n);
for k = n-1:-1:1
 s = 0;
 for j = k+1:n
  s = s + A(k,j) * x(j);
 end
 x(k) = (b(k) - s) / A(k,k);
end

A = triu(A);



 