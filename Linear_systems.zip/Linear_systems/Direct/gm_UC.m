function [U,C] = gm_UC(H);
%GM_UC factorization of an unreduced upper Hessenberg matrix

% H = U C

% Input: 
% H = unreduced upper Hessenberg matrix
%
% Output:
% U = upper triangular matrix with u_{1,1}=1
% C = companion matrix (not that of H)

%
% Author G. Meurant
% March 2024
%

n = size(H,1);
U = zeros(n,n);
U(1,1) = 1;
U(:,2:n) = H(:,1:n-1);

alp = U \ H(:,n);
C = gm_companion(-alp);

