function b = gm_dgesl(A,b,ipvt);
%GM_DGESL solve Ax = b

% A and ipvt from gm_dgefa

%
% translated by G. Meurant
% February 2023
%

[n,m] = size(A);

for k = 1:n-1
 l = ipvt(k);
 t = b(l);
 if l ~= k
  b(l) = b(k);
  b(k) = t;
 end % if
 b(k+1:n) = t * A(k+1:n,k) + b(k+1:n);
end % for k

for k = n:-1:1
 b(k) = b(k) / A(k,k);
 t = -b(k);
 b(1:k-1) = t * A(1:k-1,k) + b(1:k-1);
end % for k
