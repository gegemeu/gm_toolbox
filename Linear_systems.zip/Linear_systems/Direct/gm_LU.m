function [L,U]=gm_LU(T);
%GM_LU factorization of a (complex) tridiagonal matrix

% Input:
% T = tridiagonal matrix
%
% Output:
% L, U = lower and upper triangular (bidiagonal) matrices

%
% Author G. Meurant
% Updated March 2016
%

n = size(T,1);

L = eye(n,n);
U = zeros(n,n);

U(1,1) = T(1,1);

for i = 2:n
 U(i,i) = T(i,i) - (T(i,i-1) * T(i-1,i)) / U(i-1,i-1);
 L(i,i-1) = T(i,i-1) / U(i-1,i-1);
 U(i-1,i) = T(i-1,i);
end % for i


