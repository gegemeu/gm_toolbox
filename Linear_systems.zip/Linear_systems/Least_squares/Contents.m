% LEAST_SQUARES
%
% Functions for solving least squares problems with Krylov methods
%
% Files
%   gm_BCGLS               - block conjugate gradient, standard algorithm for least squares
%   gm_BCGLS_err_prec      - preconditioned block conjugate gradient, standard algorithm for least squares with error norm estimates
%   gm_BCGLS_prec          - preconditioned block conjugate gradient, standard algorithm for least squares
%   gm_CGLS                - conjugate gradient for least squares
%   gm_CGLS_prec           - preconditioned conjugate gradient fpr least squares
%   gm_DP_BCGLS            - block conjugate gradient, Dubrulle-P algorithm for least squares
%   gm_DP_BCGLS_err_prec   - preconditioned block conjugate gradient, Dubrulle-P algorithm for least squares with error norm estimates
%   gm_DP_BCGLS_prec       - preconditioned block conjugate gradient, Dubrulle-P algorithm for least squares
%   gm_DPL_BCG_err_prec    - preconditioned block conjugate gradient, Dubrulle-P algorithm (LU) with error norm estimates
%   gm_DR_BCGLS            - block conjugate gradient, Dubrulle-R algorithm for least squares
%   gm_DR_BCGLS_err_prec_L - preconditioned block conjugate gradient, Dubrulle-R algorithm for least squares with error norm estimates
%   gm_DR_BCGLS_prec_L     - preconditioned block conjugate gradient, Dubrulle-R algorithm for least squares
%   gm_LSQR                - least squares QR method without preconditioning
%   gm_LSQR_reorth         - least squares QR method without preconditioning with reorthogonalization
%   gm_MLSQR_prec          - preconditioned least squares QR method
