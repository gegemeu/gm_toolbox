
% LEAST_SQUARES
%
% Files
%   gm_CGLS        - Conjugate Gradient Least Squares
%   gm_LSQR        - Least squares QR method without preconditioning
%   gm_LSQR_reorth - Least squares QR method without preconditioning, with reorthogonalization
