function [X,nit,results] = gm_BCGLS_prec(A,B,X0,options,params);
%GM_BCGLS_PREC preconditioned block conjugate gradient, standard algorithm for least squares

% standard BCG for least squares

% Solves least squares problem A X = B, with preconditioning
% using BCG on A^T A X = A^T B

% Input:
% A = symmetric positive definite matrix
% B = right-hand side, matrix n x m
% X0 = iniitial block vector
% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
%  epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
%  nitmax = maximum number of iterations (order of A)
%  iprint = 1, print, residual norms at every iteration (0)
%  trueres = 1, computes the norm of B - A X_k (0)
%  Anorm = 1, computes the A-norm of the error (0)
%  l2norm = 1, computes the ell_2 norm of the error (0)
% precond = type of preconditioning for A^T A ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'gp' = preconditioner M given by the user

% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll''
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml'
%  = matrix M for 'gp'
%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%
% Output:
% X = approximate solutions of A X = B
% nit = nmber of iterations
% results is a structure with the following fields:
%  resn = ell_2 norm of computed residual nit x m
%  resnt = ell_2 norm of the true residual (if trueres = 1) nit x m
%  Anorm = (A' A)-norm of the error (if Anorm = 1) nit x m
%  l2norm = ell_2 norm of the error (if l2norm = 1) nit x m
%  trnorm = square root of trace of (X - X_k)' * A' A (X - X_k)

%
% Author G. Meurant
% February 2025
%

[n,nA] = size(A);

if nargin == 1
error('gm_BCGLS_prec: There is no right-hand side')
end % if
[nlb,mlb] = size(B);
m = mlb;

if nlb ~= n
 error('gm_BCGLS_prec: Error, the dimensions of A and B are not compatible')
end % if

if nargin < 3
 X0 = zeros(nA,mlb);
 params = [];
 options = [];
end % if
[nx,mx] = size(X0);
if nA ~= nx
 error('gm_BCGLS_prec: Error, the dimensions of X0 and A are not compatible')
end % if
if mlb ~= mx
 error('gm_BCGLS_prec: Error, the dimensions of X0 and B are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,~,trueres,iprint,precond,~,Anorm,l2norm] = gm_CG_options(A,options);

% ----------------------Initialization

AT = A';

% In principle, we must not compute A^T A
if strcmpi(precond,'no') ~= 1 || Anorm == 1
 ATA = AT * A;
 % init of preconditioners
 [cprec,cprec_amg] = gm_init_precond(ATA,precond,iprint,params);
end % if

X = X0;
R = B - A * X;
Rt = AT * R;
% solve of M Z = R
Zt = zeros(nx,m);
if strcmpi(precond,'ml') == 1
 for i = 1:m
  Zt(:,i) = gm_solve_precond(ATA,Rt(:,i),precond,cprec,cprec_amg);
 end % for i
else
 if strcmpi(precond,'no') ~= 1
  Zt = gm_solve_precond(ATA,Rt,precond,cprec,cprec_amg);
 else
  Zt = Rt;
 end % if
end % if
P = Zt;
RTR = Zt' * Rt;
m = size(B,2);
% rR = zeros(1,nitmax);
Resn = zeros(nitmax+1,m);
normcol = gm_normcol(R);
Resn(1,:) = normcol;
if trueres == 1
 Resnt = zeros(nitmax+1,m);
 Resnt(1,:) = normcol;
end % if
if Anorm == 1 || l2norm == 1
 Xec = A \ B; % "exact" solution
 if Anorm == 1
  errA = zeros(nitmax+1,m);
  AX = A * (Xec - X);
  errA(1,:) = sqrt(diag(AX' * AX))';
%   trXAX = sqrt(trace(Xec' * A' * A * Xec));
  trXAX = 1;
  errtr = zeros(1,nitmax+1);
  errtr(1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2 = zeros(nitmax+1,m);
  errl2(1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
end % if
nb = gm_normcol(B);
r0 = max(nb);
resid = realmax;
nit = 0;

% ---------------------Iterations

while resid >= epsi*r0 && nit < nitmax
 
 nit = nit + 1;
 
 AP = A * P;
 PAP = AP' * AP;
 Gamma = PAP \ RTR;
 
 X = X + P * Gamma;
 R = R - AP * Gamma;
 Rt = AT * R;
 
 % solve of M Z = R
 if strcmpi(precond,'ml') == 1
  for i = 1:m
   Zt(:,i) = gm_solve_precond(ATA,Rt(:,i),precond,cprec,cprec_amg);
  end % for i
 else
  if strcmpi(precond,'no') ~= 1
   Zt = gm_solve_precond(ATA,Rt,precond,cprec,cprec_amg);
  else
   Zt = Rt;
  end % if
 end % if
 
 if Anorm == 1
  AX = A * (Xec - X);
  errA(nit+1,:) = sqrt(diag(AX' * AX))';
  errtr(nit+1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2(nit+1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
 
 RTRn = Zt' * Rt;
 Del = RTR \ RTRn;
 RTR = RTRn;
 P = Zt + P * Del;
 
 %  rR(nit) = rank(R);
 
 normcol = gm_normcol(R);
 Resn(nit+1,:) = normcol;
 resid = max(normcol);
 if trueres == 1
  normcol = gm_normcol(B - A * X);
  Resnt(nit+1,:) = normcol;
 end % if
 
 if iprint == 1
  fprintf(' nit = %d, min(Resn) = %12.5e, max(Resn) = %12.5e \n',nit,min(Resn(nit+1,:)),max(Resn(nit+1,:)))
  if trueres == 1
   fprintf('       min(Resnt) = %12.5e, max(Resnt) = %12.5e \n',min(Resnt(nit+1,:)),max(Resnt(nit+1,:)))
  end % if
  if Anorm == 1
   fprintf('       min(Anorm) = %12.5e, max(Anorm) = %12.5e \n',min(errA(nit+1,:)),max(errA(nit+1,:)))
  end % if
  if l2norm == 1
   fprintf('       min(l2norm) = %12.5e, max(l2norm) = %12.5e \n',min(errl2(nit+1,:)),max(errl2(nit+1,:)))
  end % if
  fprintf('-------------------------------------------\n\n')
 end % if
 
end % while

results.Resn = Resn(1:nit,:);
if trueres == 1
 results.Resnt = Resnt(1:nit,:);
end % if
% rR = rR(1,1:nit);
if Anorm == 1
 results.Anorm = errA(1:nit,:);
 results.trnorm = errtr(1:nit);
end % if
if l2norm == 1
 results.l2norm = errl2(1:nit,:);
end % if







