function [x,nit,results] = gm_LSQR_reorth(A,b,x0,options);
%GM_LSQR_REORTH Least squares QR method without preconditioning with reorthogonalization

% Input:
% A = matrix m by n
% b = right-hand side
% x0 = initial vector
% options is a structure with the following fields:
%  epsi = threshold for stopping criterion (1e-10)
%  nitmax = maximum number of iterations (size(A,2))
%  trueres = 1, computes the norm of b - A x_k (0)
%  iprint = 1, print, residual norms at every iteration (0)
%  Anorm = 1, computes the A^AA-norm of the error (0)
%
% Ouput:
% x = approximate solution
% nit = number of iterations
% iret = return code
%     = 1, gm_CGLS converged to the desired tolerance epsi within nitmax
%       iterations
%     = 2, gm_CGLS iterated nitmax times but did not converge
%     = 3, matrix A'*A  seems to be singular or indefinite
% results is a structure with the followong fields:
%  resr = final relative residual norm
%  resn = residual norm
%  resnt = true residual norm
%  Anorm = A^T A-norm of the error

%
% Author G. Meurant
% from a code by B. Fischer
% Updated February 2025
%

if nargin < 2
 error('gm_LSQR_reorth: Not enough arguments \n')
end % if

[m,n] = size(A);

if nargin < 3
 x0 = zeros(n,1);
 epsi = 1e-10;
 nitmax = m;
 trueres = 0;
 Anorm = 0;
end % if

if nargin < 4
 epsi = 1e-10;
 nitmax = m;
 trueres = 0;
 Anorm = 0;
else
 [epsi,nitmax,~,trueres,iprint,~,~,Anorm] = gm_CG_options(A,options);
end % if

x = x0;

if Anorm == 1
 % assumed the the solution is unque
 xec = A \ b;
 ATA = A' * A;
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt((xec -x)' * ATA * (xec -x));
end % if

resn = zeros(nitmax+1,1);

% Initialization

matvec = 0;
dotprod = 0;

v = zeros(size(A,2),1);
u = b - A * x;
matvec = matvec + 1;
if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(u);
end % if
beta = norm(u);
dotprod = dotprod + 1;
resn(1) = beta;
u = u / beta;
c = 1;
s = 0;
w = zeros(size(A,2),1);
eta = beta;
nr = beta;
r0 = nr;
resr = zeros(1,nitmax+1);
resr(1) = 1;
resid = realmax;
U = zeros(size(b,1),nitmax+1);
U(:,1) = u;
V = zeros(size(A,2),nitmax);
nit = 0;

if iprint == 1
 fprintf(' Initial residual norm = %12.5e \n',beta)
 if trueres == 1
  fprintf(' Initial true residual norm = %12.5e \n',resnt(1))
 end % if
 if Anorm == 1
  fprintf(' Initial A^T A error norm = %12.5e \n',errA(1))
 end % if
end % if

% Iterations

while nit < nitmax && resid > epsi
 nit = nit + 1;
 
 Au = A' * u;
 matvec = matvec + 1;
 
 v = Au - beta * v;
 alpha = norm(v);
 dotprod = dotprod + 1;
 v = v / alpha;
 
 % reorthogonalization (twice)
 for j = 1:nit-1
  alp = V(:,j)' * v;
  v = v - alp * V(:,j);
  v = v / norm(v);
 end % for j
 for j = 1:nit-1
  alp = V(:,j)' * v;
  v = v - alp * V(:,j);
  v = v / norm(v);
 end % for j
 dotprod = dotprod + 4 * (nit - 1);
 
 V(:,nit) = v;
 
 Av = A * v;
 matvec = matvec + 1;
 
 u = Av - alpha * u;
 beta = norm(u);
 dotprod = dotprod + 1;
 u = u / beta;
 
 % reorthogonalization (twice)
 for j = 1:nit
  alp = U(:,j)' * u;
  u = u - alp * U(:,j);
  u = u / norm(u);
 end % for j
 for j = 1:nit
  alp = U(:,j)' * u;
  u = u - alp * U(:,j);
  u = u / norm(u);
 end % for j
 dotprod = dotprod + 4 * nit;
 U(:,nit+1) = u;
 
 % Rotation
 r1_hat = c * alpha;
 r1 = sqrt(r1_hat^2 + beta^2);
 r2 = s * alpha;
 c = r1_hat / r1;
 s = beta / r1;
 w = (v - r2 * w) / r1;
 
 x = x + c * eta * w;
 
 nr = nr * abs(s);
 eta = -s * eta;
 resn(nit+1) = nr;
 resr = nr / r0;
 resid = resr;
 
  if Anorm == 1
  errA(nit+1) = sqrt((xec -x)' * ATA * (xec -x));
 end % if
 if trueres == 1
  resnt(nit+1) = norm(b - A * x);
 end % if
 
if iprint == 1
 fprintf('nit = %d, residual norm = %12.5e, resr = %12.5e \n',nit,nr,resr)
 if trueres == 1
  fprintf('            true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf('            A^T A error norm = %12.5e \n',errA(nit+1))
 end % if
 fprintf('----------------------------\n\n')
end % if
 
end % while

if nit < nitmax && iprint == 1
 fprintf('\n Convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 fprintf(' final residual norm = %12.5e \n',resn(nit+1))
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
else
 fprintf('\n Non convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
end % if

results.resr = resr;
resn = resn(1:nit+1);
results.resn = resn;
if trueres == 1
 resnt = resnt(1:nit+1);
 results.resnt = resnt;
end % if
if Anorm == 1
 errA = errA(1:nit+1);
 results.Anorm = errA;
end % if






 