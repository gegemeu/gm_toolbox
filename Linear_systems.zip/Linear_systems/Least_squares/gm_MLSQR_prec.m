function [x,nit,results] = gm_MLSQR_prec(A,b,x0,options,params);
%GM_MLSQR_PREC Least squares QR method with preconditioning

% Input:
% A = matrix m by n
% b = right-hand side
% x0 = initial vector
% options is a structure with the following fields:
%  epsi = threshold for stopping criterion (1e-10)
%  nitmax = maximum number of iterations (size(A,2))
%  trueres = 1, computes the norm of b - A x_k (0)
%  iprint = 1, print, residual norms at every iteration (0)
%  Anorm = 1, computes the A^AA-norm of the error (0)
% precond = type of preconditioning for A^T A ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'gp' = preconditioner M given by the user

% Warning: Some preconditioners may not work, depending on the properties of A^T A
% or you may have to change the default parameters

%
% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll''
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml'
%  = matrix M for 'gp'
%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%
% Ouput:
% x = approximate solution
% nit = number of iterations
% iret = return code
%     = 1, gm_CGLS converged to the desired tolerance epsi within nitmax
%       iterations
%     = 2, gm_CGLS iterated nitmax times but did not converge
%     = 3, matrix A'*A  seems to be singular or indefinite
% results is a structure with the followong fields:
%  resr = final relative residual norm
%  resn = residual norm
%  resnt = true residual norm
%  Anorm = A^T A-norm of the error

%
% Author G. Meurant
% February 2025
%

if nargin < 2
 error('gm_LSQR: Not enough arguments \n')
end % if

[m,n] = size(A);

if nargin < 3
 x0 = zeros(n,1);
 epsi = 1e-10;
 nitmax = m;
 trueres = 0;
 Anorm = 0;
 params = [];
end % if

if nargin < 4
 epsi = 1e-10;
 nitmax = m;
 trueres = 0;
 Anorm = 0;
 params = [];
else
 [epsi,nitmax,~,trueres,iprint,precond,~,Anorm] = gm_CG_options(A,options);
end % if

if nargin < 5
 params = [];
end % if

x = x0;

if Anorm == 1
 % assumed the the solution is unque
 xec = A \ b;
 ATA = A' * A;
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt((xec -x)' * ATA * (xec -x));
end % if

resn = zeros(nitmax+1,1);

% --------------------Initialization

matvec = 0;
dotprod = 0;

% In principle, we must not compute A^T A
if strcmpi(precond,'no') ~= 1 || Anorm == 1
 ATA = A' * A;
 matvec = matvec + n;
 % init of preconditioners
 [cprec,cprec_amg] = gm_init_precond(ATA,precond,iprint,params);
end % if

matvec = 0;
dotprod = 0;

u = b - A * x;
matvec = matvec + 2;
if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(u);
end % if
beta = norm(u);
dotprod = dotprod + 1;
resn(1) = beta;
u = u / beta;
p = A' * u;
if strcmpi(precond,'no') ~= 1
 z = gm_solve_precond(ATA,p,precond,cprec,cprec_amg);
else
 z = p;
end % if
alpha = sqrt(z' * p);
vt = z / alpha;
p = p / alpha;
w = vt;
ft = beta;
rt = alpha;
nr = beta;
r0 = nr;
resr = zeros(1,nitmax+1);
resr(1) = 1;
resid = realmax;
nit = 0;

if iprint == 1
 fprintf(' Initial residual norm = %12.5e \n',beta)
 if trueres == 1
  fprintf(' Initial true residual norm = %12.5e \n',resnt(1))
 end % if
 if Anorm == 1
  fprintf(' Initial A^T A error norm = %12.5e \n',errA(1))
 end % if
end % if

% ------------------------Iterations

while nit < nitmax && resid > epsi
 nit = nit + 1;
 
 Av = A * vt;
 matvec = matvec + 1;
 
 u = Av - alpha * u;
 beta = norm(u);
 dotprod = dotprod + 1;
 u = u / beta;
 
 Atu = A' * u;
 matvec = matvec + 1;
 
 p = Atu - beta * p;
 if strcmpi(precond,'no') ~= 1
  z = gm_solve_precond(ATA,p,precond,cprec,cprec_amg);
 else
  z = p;
end % if
%  alpha = norm(v);
 alpha = sqrt(z' * p);
 dotprod = dotprod + 1;
 p = p / alpha;
 vt = z / alpha;
 
 % Rotation
 ri = sqrt(rt^2 + beta^2);
 c = rt / ri;
 s = beta / ri;
 t = s * alpha;
 rt = -c * alpha;
 f = c * ft;
 ft = s * ft;
 
 x = x + (f / ri) * w;
 w = vt - (t / ri) * w;
 
 nr = nr * abs(s);
 resn(nit+1) = nr;
 resr = nr / r0;
 resid = resr;
 
 if Anorm == 1
  errA(nit+1) = sqrt((xec -x)' * ATA * (xec -x));
 end % if
 if trueres == 1
  resnt(nit+1) = norm(b - A * x);
 end % if
 
if iprint == 1
 fprintf('nit = %d, residual norm = %12.5e, resr = %12.5e \n',nit,nr,resr)
 if trueres == 1
  fprintf('            true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf('            A^T A error norm = %12.5e \n',errA(nit+1))
 end % if
 fprintf('----------------------------\n\n')
end % if
 
end % while

if nit < nitmax && iprint == 1
 fprintf('\n Convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 fprintf(' final residual norm = %12.5e \n',resn(nit+1))
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
else
 fprintf('\n Non convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
end % if

results.resr = resr;
resn = resn(1:nit+1);
results.resn = resn;
if trueres == 1
 resnt = resnt(1:nit+1);
 results.resnt = resnt;
end % if
if Anorm == 1
 errA = errA(1:nit+1);
 results.Anorm = errA;
end % if






 