function [X,nit,results] = gm_DR_BCGLS_err_prec_L(A,B,X0,options,params);
%GM_DR_BCGLS_ERR_PREC_L preconditioned block conjugate gradient, Dubrulle-R algorithm for least squares with error norm estimates

% Solves least squares problem A X = B, with preconditioning and estimates
% of the A^T A error norm using DR-BCG on A^T A X = A^T B

% Input:
% A = symmetric positive definite matrix
% B = right-hand side, matrix n x m
% X0 = iniitial block vector
% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
%  epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
%  nitmax = maximum number of iterations (order of A)
%  iprint = 1, print, residual norms at every iteration (0)
%  trueres = 1, computes the norm of B - A X_k (0)
%  Anorm = 1, computes the A-norm of the error (0)
%  l2norm = 1, computes the ell_2 norm of the error (0)
%  precond - type of preconditioner for A^T A
%   = 'no' M = I
%   = 'sc' diagonal (scaling)
%   = 'ic' IC(0)
%   = 'ch' IC(epsilon)
%   = 'lv' IC(level)
%   = 'sh' shifted alg of Manteuffel using levels
%   = 'ci' Matlab incomplete Cholesky IC(0)
%   = 'ce' Matlab incomplete Cholesky IC(epsilon)
%   = 'ss' SSOR with omega=1
%   = 'ai' AINV
%   = 'a2' AINV with a bound on the number of nonzero entries in a column
%   = 'sa' SAINV
%
% params is a structure containing the parameters of some preconditioners
%  if params is empty, default values are used
%  one or two fields
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll', 'sh'
%  = tau for 'ai'
%
% params.p1 and params.p2
%  = droptol, diagcomp for 'ce'
%
% Output:
% X = approximate solutions of A X = B
% nit = nmber of iterations
% results is a structure with the following fields:
%  resn = ell_2 norm of computed residual nit x m
%  resnt = ell_2 norm of the true residual (if trueres = 1) nit x m
%  Anorm = A-norm of the error (if Anorm = 1) nit x m
%  l2norm = ell_2 norm of the error (if l2norm = 1) nit x m
%  trnorm = square root of trace of (X - X_k)' * A' A (X - X_k)
%  estG  = Gauss lower bound of the (A' A)-norm of the error
%  estGR = Gauss-Radau upper bound of the (A' A)-norm of the error
%  esttrG  = Gauss lower bound of the square root of the trace
%  esttrGR = Gauss-Radau upper bound of the square root of the trace

%
% Author G. Meurant
% February 2025
%

[n,nA] = size(A);

if nargin == 1
error('gm_DR_BCGLS_err_prec_L: There is no right-hand side')
end % if
[nlb,mlb] = size(B);
m = mlb;

if nlb ~= n
 error('gm_DR_BCGLS_err_prec_L: Error, the dimensions of A and B are not compatible')
end % if

if nargin < 3
 X0 = zeros(nA,mlb);
 params = [];
 options = [];
end % if
[nx,mx] = size(X0);
if nA ~= nx
 error('gm_DR_BCGLS_err_prec_L: Error, the dimensions of X0 and A are not compatible')
end % if
if mlb ~= mx
 error('gm_DR_BCGLS_err_prec_L: Error, the dimensions of X0 and B are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,~,trueres,iprint,precond,~,Anorm,l2norm,delay,mu] = gm_CG_options(A,options);

% ----------------------Initialization

AT = A';
% In principle, we must not compute A^T A
ATA = AT * A;
% init of preconditioners
cprec = gm_init_precond(ATA,precond,iprint,params);

[mu,~] = gm_CG_mu_eta(ATA,mu,1,cprec,options,params);

X = X0;
R = B - A * X;
% solve of L Y = R
Y = gm_solve_precond_L(AT * R,1,precond,cprec);
[Q, Sig] = gm_signqr(Y); % QR factorization with positive diagonal entries in Y
% solve of L' S = Q
S = gm_solve_precond_L(Q,2,precond,cprec);
Cmuold = (1 / mu) * (Sig' * Sig);

W = A * S;
m = size(B,2);
% rR = zeros(1,nitmax);
Resn = zeros(nitmax+1,m);
normcol = gm_normcol(R);
Resn(1,:) = normcol;
if trueres == 1
 Resnt = zeros(nitmax+1,m);
 Resnt(1,:) = normcol;
end % if
if Anorm == 1 || l2norm == 1
 Xec = A \ B; % "exact" solution
 if Anorm == 1
  errA = zeros(nitmax+1,m);
  AX = A * (Xec - X);
  errA(1,:) = sqrt(diag(AX' * AX))';
%   trXAX = sqrt(trace(Xec' * A' * A * Xec));
  trXAX = 1;
  errtr = zeros(1,nitmax+1);
  errtr(1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2 = zeros(nitmax+1,m);
  errl2(1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
end % if
EstG = zeros(nitmax,m);
EstGR = zeros(nitmax,m);
EsttrG = zeros(1,nitmax);
EsttrGR = zeros(1,nitmax);
CC = zeros(m,m,nitmax);
nb = gm_normcol(B);
r0 = max(nb);
resid = realmax;
nit = 0;

% ---------------------Iterations

while resid >= epsi*r0 && nit < nitmax
 
 nit = nit + 1;
 
 Pik = inv(W' * W);
 
 X = X + S * Pik * Sig;
 
 if Anorm == 1
  AX = A * (Xec - X);
  errA(nit+1,:) = sqrt(diag(AX' * AX))';
  errtr(nit+1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2(nit+1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
 
 %  [Q,Psi] = gm_signqr(Q - AT * W * Pik);
 
 AST = AT * W * Pik;
 % solve of L Y = AST
 Y = gm_solve_precond_L(AST,1,precond,cprec);
 [Q, Psi] = gm_signqr(Q - Y); % QR factorization with positive diagonal entries
 % solve of L' Y = Q
 Y = gm_solve_precond_L(Q,2,precond,cprec);
 
 S = Y + S * Psi';
 
 Cold = Sig' * Pik * Sig;
 if nit > 1
  CC(:,:,nit-1) = Cold;
 end % if
 
 W = A * S;
 Sig = Psi * Sig;
 R = Q * Sig;
 
 ell = nit - delay;
 if ell > 0
  CS = zeros(m,m);
  for j = ell:nit-1
   CS = CS + CC(:,:,j);
  end % for j
  for k = 1:m
   err = sqrt(CS(k,k));
   % this a lower bound of the A-norms at iteration ell
   EstG(ell,k) = err;
  end % for k
  EsttrG(ell) = sqrt(trace(CS));
  %  Cmu = (Sig' * Sig) * inv(mu * (Cmuold - Cold) + Sig' * Sig) * (Cmuold -Cold);
  C = mu * (Cmuold - Cold) + Sig' * Sig;
  Cmu = (Sig' * Sig) * (C \ (Cmuold - Cold));
  Cmuold = Cmu;
  for k = 1:m
   err = sqrt(CS(k,k) + Cmu(k,k));
   % this an upper bound of the A-norms at iteration ell
   EstGR(ell,k) = err;
  end % for k
  CSCmu = CS + Cmu;
  EsttrGR(ell) = sqrt(trace(CSCmu));
 end % if ell
 
 %  rR(nit) = rank(R);
 
 normcol = gm_normcol(R);
 Resn(nit+1,:) = normcol;
 resid = max(normcol);
 if trueres == 1
  normcol = gm_normcol(B - A * X);
  Resnt(nit+1,:) = normcol;
 end % if
 
 if iprint == 1
  fprintf(' nit = %d, min(Resn) = %12.5e, max(Resn) = %12.5e \n',nit,min(Resn(nit+1,:)),max(Resn(nit+1,:)))
  if trueres == 1
   fprintf('       min(Resnt) = %12.5e, max(Resnt) = %12.5e \n',min(Resnt(nit+1,:)),max(Resnt(nit+1,:)))
  end % if
  if Anorm == 1
   fprintf('       min(Anorm) = %12.5e, max(Anorm) = %12.5e \n',min(errA(nit+1,:)),max(errA(nit+1,:)))
  end % if
  if l2norm == 1
   fprintf('       min(l2norm) = %12.5e, max(l2norm) = %12.5e \n',min(errl2(nit+1,:)),max(errl2(nit+1,:)))
  end % if
  fprintf('-------------------------------------------\n\n')
 end % if
 
end % while

results.Resn = Resn(1:nit,:);
if trueres == 1
 results.Resnt = Resnt(1:nit,:);
end % if
% rR = rR(1,1:nit);
if Anorm == 1
 results.Anorm = errA(1:nit,:);
 results.trnorm = errtr(1:nit);
end % if
if l2norm == 1
 results.l2norm = errl2(1:nit,:);
end % if
results.EstG = real(EstG(1:nit,:));
results.EstGR = real(EstGR(1:nit,:));
results.EsttrG = real(EsttrG(1:nit));
results.EsttrGR = real(EsttrGR(1:nit));







