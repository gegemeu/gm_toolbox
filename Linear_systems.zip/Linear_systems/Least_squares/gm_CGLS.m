function [x,nit,iret,results] = gm_CGLS(A,b,x0,options);
%GM_CGLS conjugate gradient for least squares

% Input:
% A = matrix m by n
% b = right-hand side
% x0 = initial vector
% options is a structure with the following fields:
%  epsi = threshold for stopping criterion (1e-10)
%  nitmax = maximum number of iterations (size(A,2))
%  trueres = 1, computes the norm of b - A x_k (0)
%  iprint = 1, print, residual norms at every iteration (0)
%  Anorm = 1, computes the A^AA-norm of the error (0)
%
% Ouput:
% x = approximate solution
% nit = number of iterations
% iret = return code
%     = 1, gm_CGLS converged to the desired tolerance epsi within nitmax
%       iterations
%     = 2, gm_CGLS iterated nitmax times but did not converge
%     = 3, matrix A'*A  seems to be singular or indefinite
% results is a structure with the followong fields:
%  resr = final relative residual norm
%  resn = residual norm
%  resnt = true residual norm
%  Anorm = A^T A-norm of the error

%
% written from a code by Per Christian Hansen and Michael Saunders 
%
% G. Meurant
% February 2025
%

if nargin < 2
 error('gm_CGLS: Not enough arguments \n')
end % if

[m,n] = size(A);

if nargin < 3
 x0 = zeros(n,1);
 options = [];
end % if

if nargin < 4
 options = [];
else
 [epsi,nitmax,~,trueres,iprint,~,~,Anorm,l2norm] = gm_CG_options(A,options);
end % if

x = x0;

if Anorm == 1
 % assumed the the solution is unque
 xec = A \ b;
 ATA = A' * A;
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt((xec -x)' * ATA * (xec -x));
end % if
if l2norm == 1
 xec = A \b;
 errl2 = zeros(1,nitmax+1);
 errl2(1) = norm(xec - x);
end % if

r = b - A * x;
s = A' * r; % 1 dp

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end % if


% ---------------------Initialization

matvec = 0;
dotprod = 0;
matvec = matvec + 2;

p = s;
norms0 = norm(s);
nb = norm(b);
gamma = norms0^2;
normx = norm(x);
xmax  = normx; % 2dp
dotprod = dotprod + 3;
k = 0;
iret = 0;
resn = zeros(nitmax+1,1);
resn(1) = norms0;

if iprint == 1
 fprintf(' Initial norm of s = %12.5e \n',norms0)
 if trueres == 1
  fprintf(' Initial true residual norm = %12.5e \n',resnt(1))
 end % if
 if Anorm == 1
  fprintf(' Initial A^T A error norm = %12.5e \n',errA(1))
 end % if
end % if

indef = 0;

% --------------------Iterations

while (k < nitmax) && (iret == 0)

 k = k + 1;

 q = A * p;
 matvec = matvec + 1;

 delta = norm(q)^2;
 dotprod = dotprod + 1;
 if delta <= 0
  indef = 1;
 end
 if delta == 0
  delta  = eps;
 end
 alpha = gamma / delta;

 x = x + alpha * p;
 r = r - alpha * q;

 s = A' * r;
 matvec = matvec + 1;
 
 if Anorm == 1
  errA(k+1) = sqrt((xec -x)' * ATA * (xec -x));
 end % if
 if l2norm == 1
  errl2(k+1) = norm(xec - x);
 end % if
 if trueres == 1
  resnt(k+1) = norm(r);
 end % if

 norms = norm(s);
 dotprod = dotprod + 1;
 gamma1 = gamma;
 gamma = norms^2;
 beta  = gamma / gamma1;
 
 p = s + beta * p;

 % Convergence?
 normx = norm(x);
 xmax = max(xmax,normx);
 iret = (norms <= nb * epsi) || (normx * epsi >= 1);

 % Output
 resn(k+1) = norms;
 resr = norms / norms0;
if iprint == 1
 fprintf('nit = %d, norm of s = %12.5e \n',k,norms)
 if trueres == 1
  fprintf('            true residual norm = %12.5e \n',resnt(k+1))
 end % if
 if Anorm == 1
  fprintf('            A^T A error norm = %12.5e \n',errA(k+1))
 end % if
 fprintf('----------------------------\n\n')
end % if
 
end % while

nit = k;

if nit < nitmax && iprint == 1
 fprintf('\n Convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 fprintf(' final residual norm = %12.5e \n',resn(nit+1))
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
elseif iprint == 1
 fprintf('\n Non convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
end % if

results.resr = resr;
resn = resn(1:nit+1);
results.resn = resn;
if trueres == 1
 resnt = resnt(1:nit+1);
 results.resnt = resnt;
end % if
if Anorm == 1
 errA = errA(1:nit+1);
 results.Anorm = errA;
end % if
if l2norm == 1
 errl2 = errl2(1:nit+1);
 results.l2norm = errl2(1:nit);
end % if
shrink = normx/xmax;
if k == nitmax
 iret = 2;
end
if indef
 iret = 3;
end
if shrink <= sqrt(epsi)
 iret = 4;
end



