function [x,iret,resr,resn,nit] = gm_CGLS(A,b,epsi,nitmax,prints,x0);
%GM_CGLS Conjugate Gradient Least Squares

% Input:
% A = matrix m by n
% b = right-hand side
% epsi = threshold
% nitmax = maximum number of iterations
% prints = output is generated if =  'print'
% x0 = initial vector
%
% Ouput:
% x = approximate solution
% iret = return code
%     = 1, gm_CGLS converged to the desired tolerance epsi within nitmax
%       iterations
%     = 2, gm_CGLS iterated nitmax times but did not converge
%     = 3, matrix A'*A  seems to be singular or indefinite
% resr = final relative residual norm
% resn = residual norms
% nit = number of iterations

%
% written from a code by Per Christian Hansen and Michael Saunders 
%
% G. Meurant
% Feb 2015
%

if nargin >= 5 && strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

% Default values
if nargin < 3 || isempty(epsi)
 epsi = 1e-6;
end
if nargin < 4
 nitmax = [];
end
if nargin < 5 
 iprint = 0;
end
if nargin < 6 
 x0 = [];
end

[m,n] = size(A);

if ~isempty(x0)
 x = x0;
else
 x = zeros(n,1);
end

r = b - A * x;
s = A' * r; % 1 dp

% Default for nitmax
if isempty(nitmax)
 nitmax = min([m,n,20]);
end

% ---------------------Initialization

p = s;
norms0 = norm(s);
gamma = norms0^2;
normx = norm(x);
xmax  = normx; % 2dp
k = 0;
iret = 0;
resn = zeros(nitmax+1,1);
resn(1) = norms0;

if iprint == 1
 fprintf('\n    k       x(1)             x(n)           normx        resr \n')
 fprintf('%5.0f %16.10g %16.10g %9.2g %12.5g\n',k,x(1),x(n),normx,1);
end

indef = 0;

% --------------------Iterations

while (k < nitmax) && (iret == 0)

 k = k + 1;

 q = A * p;

 delta = norm(q)^2;
 if delta <= 0
  indef = 1;
 end
 if delta == 0
  delta  = eps;
 end
 alpha = gamma / delta;

 x = x + alpha * p;
 r = r - alpha * q;

 s = A' * r;

 norms = norm(s);
 gamma1 = gamma;
 gamma = norms^2;
 beta  = gamma / gamma1;
 
 p = s + beta * p;

 % Convergence?
 normx = norm(x);
 xmax = max(xmax,normx);
 iret = (norms <= norms0 * epsi) || (normx * epsi >= 1);

 % Output
 resn(k+1) = norms;
 resr = norms / norms0;
 if iprint == 1
  fprintf('%5.0f %16.10g %16.10g %9.2g   %12.5e\n',k,x(1),x(n),normx,resr);
 end
 
end % while

nit = k;

resn = resn(1:nit+1);
shrink = normx/xmax;
if k == nitmax
 iret = 2;
end
if indef
 iret = 3;
end
if shrink <= sqrt(epsi)
 iret = 4;
end



