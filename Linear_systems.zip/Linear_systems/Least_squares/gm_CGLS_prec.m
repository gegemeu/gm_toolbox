function [x,nit,iret,results] = gm_CGLS_prec(A,b,x0,options,params);
%GM_CGLS_PREC preconditioned conjugate gradient fpr least squares

% Caution: Even if A^T A is positive definite, it may not have an
% incomplete Cholesky factorization without fill-in

% Input:
% A = matrix m by n
% b = right-hand side
% x0 = initial vector
% epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% trueres = 1, computes the norm of b - A x_k (0)
% iprint = 1, print, residual norms at every iteration (0)
% Anorm = 1, computes the A^I A-norm of the error (0)
% precond = type of preconditioning for A^T A ('no')
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'ss' SSOR with omega=1 (also named 'gs')
%  = 'po' least squares polynomial
%  = 'ai' AINV
%  = 'a2' AINV with a bound on the number of nonzero entries in a column
%  = 'sa' SAINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'fs' factorized sparse approximate inverse FSAI
%  = 'ml' multilevel (AMG)
%  = 'gp' = preconditioner M given by the user

% params is a structure containing the parameters of some preconditioners
% if params is empty, default values are used
% one or two fields if the preconditioner is not 'ml' or 'mb'
%
% params.p1 for
%  = empty for 'no', 'ss', 'ci', and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv', 'll''
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = number of levels for 'ml'
%  = matrix M for 'gp'
%
% params.p1 and params.p2 
%  = droptol, diagcomp for 'ce'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' and 'mb' are in params as
%  params.lmax = max number of levels
%  params.nu = number of smoothing steps
%  params.almax = parameter alpha
%  params.alb = parameter alpha for the generation of grids with AINV
%  params.smooth = type of smoothing operator
%  params.influ = type of influence matrix
%  params.coarse = type of coarsening algorithm
%  params.interpo = type of interpolation algorithm
%
% Ouput:
% x = approximate least squares solution
% nit = number of iterations
% iret = return code
%     = 1, gm_CGLS converged to the desired tolerance epsi within nitmax
%       iterations
%     = 2, gm_CGLS iterated nitmax times but did not converge
%     = 3, matrix A'*A  seems to be singular or indefinite
% results is a structure with the followong fields:
%  resr = final relative residual norm
%  resn = residual norm
%  resnt = norm of b - A x
%  errA = A^T A-norm of the error

%
% written from a code by Shaked Regev and Michael Saunders 
%
% G. Meurant
% February 2025
%

if nargin < 2
 error('gm_CGLS: Not enough arguments \n')
end % if

[m,n] = size(A);

if nargin < 3
 x0 = zeros(n,1);
 options = [];
 params = [];
end % if

if nargin < 4
 options = [];
 params = [];
else
 [epsi,nitmax,~,trueres,iprint,precond,~,Anorm,l2norm] = gm_CG_options(A,options);
end % if

if nargin < 5
 params = [];
end % if

x = x0;

% ---------------------Initialization

matvec = 0;
dotprod = 0;
matvec = matvec + 2;

% In principle, we must not compute A^T A
if strcmpi(precond,'no') ~= 1 || Anorm == 1
 ATA = A' * A;
 matvec = matvec + n;
 % init of preconditioners
 [cprec,cprec_amg] = gm_init_precond(ATA,precond,iprint,params);
end % if

if Anorm == 1
 % assumed the solution is unique
 xec = A \ b;
 errA = zeros(1,nitmax+1);
 errA(1) = sqrt((xec -x)' * ATA * (xec -x));
end % if
if l2norm == 1
 xec = A \b;
 errl2 = zeros(1,nitmax+1);
 errl2(1) = norm(xec - x);
end % if

r = b - A * x;
t = A' * r; % 1 dp
matvec = matvec + 2;

if strcmpi(precond,'no') ~= 1
 w = gm_solve_precond(ATA,t,precond,cprec,cprec_amg);
 u = w;
else
 w = t;
 u = t;
end % if
 

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end % if

norms0 = norm(b);
gamma = t' * w;
normx = norm(x);
xmax  = normx; % 2dp
dotprod = dotprod + 3;
k = 0;
iret = 0;
resn = zeros(nitmax+1,1);
resn(1) = norms0;

if iprint == 1
 fprintf(' Initial sqrt(gamma) = %12.5e \n',sqrt(gamma))
 if trueres == 1
  fprintf(' Initial true residual norm = %12.5e \n',resnt(1))
 end % if
 if Anorm == 1
  fprintf(' Initial A^T A error norm = %12.5e \n',errA(1))
 end % if
end % if

indef = 0;

% --------------------Iterations

while (k < nitmax) && (iret == 0)

 k = k + 1;

 q = A * u;
 matvec = matvec + 1;

 delta = norm(q)^2;
 dotprod = dotprod + 1;
 if delta <= 0
  indef = 1;
 end
 if delta == 0
  delta  = eps;
 end
 alpha = gamma / delta;

 x = x + alpha * u;
 r = r - alpha * q;

 t = A' * r;
 matvec = matvec + 1;
 
 if Anorm == 1
  errA(k+1) = sqrt((xec -x)' * ATA * (xec -x));
 end % if
 if l2norm == 1
  errl2(k+1) = norm(xec - x);
 end % if
if trueres == 1
 resnt(k+1) = norm(r);
end % if

if strcmpi(precond,'no') ~= 1
 w = gm_solve_precond(ATA,t,precond,cprec,cprec_amg);
else
 w = t;
end % if

 norms = norm(t);
 dotprod = dotprod + 1;
 gamma1 = gamma;
 gamma = t' * w;
 beta  = gamma / gamma1;
 
 u = w + beta * u;

 % Convergence?
 normx = norm(x);
 dotprod = dotprod + 1;
 xmax = max(xmax,normx);
 iret = (norms <= norms0 * epsi) || (normx * epsi >= 1);

 % Output
 resn(k+1) = norms;
 resr = norms / norms0;
if iprint == 1
 fprintf('nit = %d, sqrt(gamma) = %12.5e \n',k,sqrt(gamma))
 if trueres == 1
  fprintf('            true residual norm = %12.5e \n',resnt(k+1))
 end % if
 if Anorm == 1
  fprintf('            A^T A error norm = %12.5e \n',errA(k+1))
 end % if
 fprintf('----------------------------\n\n')
end % if
 
end % while

nit = k;

if nit < nitmax && iprint == 1
 fprintf('\n Convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 fprintf(' final residual norm = %12.5e \n',resn(nit+1))
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
elseif iprint == 1
 fprintf('\n Non convergence, nit = %d \n',nit)
 fprintf(' matvec  = %d, dotprod = % d \n',matvec,dotprod)
 if trueres == 1
  fprintf(' final true residual norm = %12.5e \n',resnt(nit+1))
 end % if
 if Anorm == 1
  fprintf(' final A-norm of the error = %12.5e \n',errA(nit+1))
 end % if
end % if

results.resr = resr;
resn = resn(1:nit+1);
results.resn = resn;
if trueres == 1
 resnt = resnt(1:nit+1);
 results.resnt = resnt;
end % if
if Anorm == 1
 errA = errA(1:nit+1);
 results.Anorm = errA;
end % if
if l2norm == 1
 errl2 = errl2(1:nit+1);
 results.l2norm = errl2(1:nit);
end % if
shrink = normx/xmax;
if k == nitmax
 iret = 2;
end
if indef
 iret = 3;
end
if shrink <= sqrt(epsi)
 iret = 4;
end



