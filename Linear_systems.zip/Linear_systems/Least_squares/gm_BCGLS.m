function [X,nit,results] = gm_BCGLS(A,B,X0,options);
%GM_BCGLS block conjugate gradient, standard algorithm for least squares

% standard BCG

% Solves least squares problem A X = B, without preconditioning
% using BCG on A^T A X = A^T B

% Input:
% A = symmetric positive definite matrix
% B = right-hand side, matrix n x m
% X0 = iniitial block vector
% options is a structure containing all or some of the following fields
% if options is empty, default values are used (within parenthesis)
%  epsi = threshold for stopping criterion (1e-10)
%    (stop if norm(r^k) <= epss norm(b) or nit > nitmax
%  nitmax = maximum number of iterations (order of A)
%  iprint = 1, print, residual norms at every iteration (0)
%  trueres = 1, computes the norm of B - A X_k (0)
%  Anorm = 1, computes the A-norm of the error (0)
%  l2norm = 1, computes the ell_2 norm of the error (0)
%
% Output:
% X = approximate solutions of A X = B
% nit = nmber of iterations
% results is a structure with the following fields:
%  resn = ell_2 norm of computed residual nit x m
%  resnt = ell_2 norm of the true residual (if trueres = 1) nit x m
%  Anorm = (A' A)-norm of the error (if Anorm = 1) nit x m
%  l2norm = ell_2 norm of the error (if l2norm = 1) nit x m
%  trnorm = square root of trace of (X - X_k)' * A' A (X - X_k)

%
% Author G. Meurant
% February 2025
%

n = size(A,1);

if nargin == 1
error('gm_BCGLS: There is no right-hand side')
end % if
[nlb,mlb] = size(B);

if nlb ~= n
 error('gm_BCGLS: Error, the dimensions of A and B are not compatible')
end % if

if nargin < 3
 X0 = zeros(n,mlb);
 options = [];
end % if
[nx,mx] = size(X0);
if mlb ~= mx
 error('gm_BCGLS: Error, the dimensions of X0 and B are not compatible')
end % if

if nargin < 4
 options = [];
end % if

% get the optional parameters and options
[epsi,nitmax,~,trueres,iprint,~,~,Anorm,l2norm] = gm_CG_options(A,options);

% ----------------------Initialization

AT = A';
X = X0;
R = B - A * X;
Rt = AT * R;
P = Rt;
RTR = Rt' * Rt;
m = size(B,2);
% rR = zeros(1,nitmax);
Resn = zeros(nitmax+1,m);
normcol = gm_normcol(R);
Resn(1,:) = normcol;
if trueres == 1
 Resnt = zeros(nitmax+1,m);
 Resnt(1,:) = normcol;
end % if
if Anorm == 1 || l2norm == 1
 Xec = A \ B; % "exact" solution
 if Anorm == 1
  errA = zeros(nitmax+1,m);
  AX = A * (Xec - X);
  errA(1,:) = sqrt(diag(AX' * AX))';
%   trXAX = sqrt(trace(Xec' * A' * A * Xec));
  trXAX = 1;
  errtr = zeros(1,nitmax+1);
  errtr(1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2 = zeros(nitmax+1,m);
  errl2(1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
end % if
nb = gm_normcol(B);
r0 = max(nb);
resid = realmax;
nit = 0;

% ---------------------Iterations

while resid >= epsi*r0 && nit < nitmax
 
 nit = nit + 1;
 
 AP = A * P;
 PAP = AP' * AP;
 Gamma = PAP \ RTR;
 
 X = X + P * Gamma;
 R = R - AP * Gamma;
 Rt = AT * R;
 
 if Anorm == 1
  AX = A * (Xec - X);
  errA(nit+1,:) = sqrt(diag(AX' * AX))';
  errtr(nit+1) = sqrt(trace(AX' * AX)) / trXAX;
 end % if
 if l2norm == 1
  errl2(nit+1,:) = sqrt(diag((Xec - X)' * (Xec - X)))';
 end % if
 
 RTRn = Rt' * Rt;
 Del = RTR \ RTRn;
 RTR = RTRn;
 P = Rt + P * Del;
 
 %  rR(nit) = rank(R);
 
 normcol = gm_normcol(R);
 Resn(nit+1,:) = normcol;
 resid = max(normcol);
 if trueres == 1
  normcol = gm_normcol(B - A * X);
  Resnt(nit+1,:) = normcol;
 end % if
 
 if iprint == 1
  fprintf(' nit = %d, min(Resn) = %12.5e, max(Resn) = %12.5e \n',nit,min(Resn(nit+1,:)),max(Resn(nit+1,:)))
  if trueres == 1
   fprintf('       min(Resnt) = %12.5e, max(Resnt) = %12.5e \n',min(Resnt(nit+1,:)),max(Resnt(nit+1,:)))
  end % if
  if Anorm == 1
   fprintf('       min(Anorm) = %12.5e, max(Anorm) = %12.5e \n',min(errA(nit+1,:)),max(errA(nit+1,:)))
  end % if
  if l2norm == 1
   fprintf('       min(l2norm) = %12.5e, max(l2norm) = %12.5e \n',min(errl2(nit+1,:)),max(errl2(nit+1,:)))
  end % if
  fprintf('-------------------------------------------\n\n')
 end % if
 
end % while

results.Resn = Resn(1:nit,:);
if trueres == 1
 results.Resnt = Resnt(1:nit,:);
end % if
% rR = rR(1,1:nit);
if Anorm == 1
 results.Anorm = errA(1:nit,:);
 results.trnorm = errtr(1:nit);
end % if
if l2norm == 1
 results.l2norm = errl2(1:nit,:);
end % if







