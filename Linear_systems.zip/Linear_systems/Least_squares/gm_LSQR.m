function [x,resr,resn,nit]=gm_LSQR(A,b,epss,nitmax,prints,x0);
%GM_LSQR Least squares QR method without preconditioning

% Input:
% A = matrix m by n
% b = right-hand side
% epss = threshold
% nitmax = maximum number of iterations
% prints = output is generated if = 'print'
% x0 = initial vector
%
% Ouput:
% x = approximate solution
% resr = final relative residual norm
% resn = residual norms
% nit = number of iterations

%
% Author G. Meurant
% from a code by B. Fischer
% Updated Sept 2015
%

if nargin >= 5 && strcmpi(prints,'print') == 1
 iprint = 1;
else
 iprint = 0;
end

% Default values
if nargin < 3 || isempty(epss)
 epss = 1e-6;
end
if nargin < 4
 nitmax = [];
end
if nargin < 5 
 iprint = 0;
end
if nargin < 6 
 x0 = [];
end

[m,n] = size(A);

if ~isempty(x0)
 x = x0;
else
 x = zeros(n,1);
end

% Default for nitmax
if isempty(nitmax)
 nitmax = min([m,n,20]);
end

resn = zeros(nitmax+1,1);

% Initialization

v = zeros(size(A,2),1);
u = b - A * x;
beta = norm(u);
resn(1) = beta;
u = u / beta;
c = 1;
s = 0;
w = zeros(size(A,2),1);
eta = beta;
nr = beta;
r0 = nr;
resr = zeros(1,nitmax+1);
resr(1) = 1;
resid = realmax;
nit = 0;

% Iterations

while nit < nitmax && resid > epss
 nit = nit + 1;
 
 Au = A' * u;
 
 v = Au - beta * v;
 alpha = norm(v);
 v = v / alpha;
 
 Av = A * v;
 
 u = Av - alpha * u;
 beta = norm(u);
 u = u / beta;
 
 % Rotation
 r1_hat = c * alpha;
 r1 = sqrt(r1_hat^2 + beta^2);
 r2 = s * alpha;
 c = r1_hat / r1;
 s = beta / r1;
 w = (v - r2 * w) / r1;
 
 x = x + c * eta * w;
 
 nr = nr * abs(s);
 eta = -s * eta;
 resn(nit+1) = nr;
 resr = nr / r0;
 resid = resr;
 
 if iprint == 1
  fprintf('nit = %d, resr = %g \n',nit,resr);
 end
 
end % while

resn = resn(1:nit+1);






 