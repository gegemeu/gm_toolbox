function f=gm_f_bsigmin_basis(x);
%GM_F_BSIGMIN_BASIS function for the maximization of a bound of the smallest singular value
%value of V_k

%
% Author G. Meurant
% Feb 2016
%

global B VV VTTV msing msing_new;

v = B * transpose(x);
v = v / norm(v);

% solution of the least squares problem
x = VTTV \ ( VV' * v);
nx = norm(x);

% residual
r = VV * x - v;

% norm of the residual of the least squares problem
% || A x - v ||
rho = norm(r);

if rho == 0
 msing_new = msing;
elseif norm(x) == 0
 msing_new = min(msing,rho);
else
 nx2 = nx^2;
 BB = nx2 + rho^2 / msing^2 - 1;
 E = 1 + (BB - sqrt(BB^2 + 4 * nx2)) / 2;
 msing_new = msing * sqrt(E);
end

f = 1 / msing_new;

