function rG=gm_FOM_to_GMRES(rF);
%GM_FOM_TO_GMRES GMRES residual norms from FOM norms

% Input:
% rF = FOM residual norms
%
% Output:
% rG = GMRES residual norms

%
% Author G. Meurant
% Sept 2018
%

n = length(rF);
rG = zeros(n,1);
rG(1) = rF(1);
for k = 2:n
 rgi2 = 1 / rF(k)^2 + 1 / rG(k-1)^2;
 rG(k) = sqrt(1 / rgi2);
end% for k

