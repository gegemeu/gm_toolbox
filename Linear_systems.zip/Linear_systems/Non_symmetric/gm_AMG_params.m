function params_amg = gm_AMG_params(A,params);
%GM_AMG_PARAMS Parameters for the AMG solver

% Input!
% params = structure giving the parameter(s) needed by some preconditioners
% if params is empty, default values are used
%
% Cautin: Some combinations of parameters may not be allowed
%
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)
%
% Output;
% cell arrays needed for AMG

%
% Author G. Meurant
% January 2025
%

n = size(A,1);

if isempty(params)
 % defaults for AMG
 lmax = 10;
 nu = 1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'gs';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 falp = 1;
 alq = 1;
 normal = 0;
 gama = 1;
 xin = zeros(n,1);
 
else
 % get the input parameters for the multilevel AMG method
 if isfield(params,'lmax')
  lmax = params.lmax;
 else
  lmax = 10;
 end % if
 if isfield(params,'nu')
  nu = params.nu;
 else
  nu = 1;
 end % if
 if isfield(params,'alpmax')
  alpmax = params.alpmax;
 else
  alpmax = 0.1;
 end % if
 if isfield(params,'alb')
  alb = params.alb;
 else
  alb = 2;
 end % if
 if isfield(params,'smooth')
  smooth = params.smooth;
 else
  smooth = 'gs';
 end % if
 if isfield(params,'infl')
  infl = params.infl;
 else
  infl = 'b';
 end % if
 if isfield(params,'coarse')
  coarse = params.coarse;
 else
  coarse = 'st';
 end % if
 if isfield(params,'interpo')
  interpo = params.interpo;
 else
  interpo = 'st';
 end % if
 if isfield(params,'qmin')
  qmin = params.qmin;
 else
  qmin = n;
 end % if
 gama = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 xin = zeros(n,1);
 
end % if

params_amg  = {xin, nu, alpmax, alb, lmax, falp, qmin, alq, smooth, infl, coarse, interpo, normal, gama};




