function Ritz = gm_Ritz_rand(n);
%GM_RITZ_RAND generates a matrix of random complex conjugate Ritz values
% for gm_presc_convGMRES 

% Ritz is upper triangular of order n

%
% Author G. Meurant
% July 2015
%

Ritz = zeros(n,n);

Ritz(1,1) = randn;
for k = 2:n
  % generate complex conjugate eigenvalues
 m = fix(k / 2);
 lamb1 = randn(m,1) + 1i * randn(m,1);
 if 2 * m == k
  lamb = [lamb1; conj(lamb1)];
 else
  % a real Ritz value if m is odd
  lamb = [lamb1; conj(lamb1); randn];
 end
 Ritz(1:k,k) = lamb;
end

