function shft=gm_compress_R(d)
%GM_COMPRESS_R compresses complex d into array shft 
% negative imaginary part

% code from L. Reichel

n = max(size(d));
shft = [] ;

for k = 1:n
 if imag(d(k)) == 0
  shft = [shft; [d(k),0]];
 elseif imag(d(k)) > 0
  shft = [shft; [real(d(k)),imag(d(k))]];
 end
end
