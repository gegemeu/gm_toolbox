function shft=gm_compress_R(d)
%GM_COMPRESS_R Compresses complex d into array shift by skipping all the complex values with
% negative imaginary part

% code from L. Reichel

n = max(size(d));
shft = [] ;

for k = 1:n
 if imag(d(k)) == 0
  shft = [shft; [d(k),0]];
 elseif imag(d(k)) > 0
  shft = [shft; [real(d(k)),imag(d(k))]];
 end
end
