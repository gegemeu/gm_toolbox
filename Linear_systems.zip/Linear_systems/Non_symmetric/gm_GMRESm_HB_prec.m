function [x,nit,iret,results] = gm_GMRESm_HB_prec(A,b,x0,options,params);
%GM_GMRESM_HB_PREC preconditioned restarted GMRES(m) for a matrix A, heavy ball restart

% Heavy Ball restarting method of Imakura, Li and Zhang

% See: A. Imakura, R-C. Li and S-L. Zhang, Locally optimal and heavy ball GMRES methods,
%           Japan Journal of Industrial and Applied Mathematics, v 33 n 2 (2016), pp. 471-499

% uses Modified Gram-Schmidt

% does not work with right preconditioning (left = 0)

%
% Input:
% A = matrix
% b = right-hand side
% x0 = initial vector
%
% options is a structure which can contain the following fields:
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% m = restarting parameter, GMRES(m)
% left = 1 left preconditioning, otherwise right preconditioning
% reorth = 1 with full reorthogonalization, = 2 selective reorthogonalization
% scaling = 1, scales the matrix before preconditioning
% iprint = 1, prints residual norms
% timing = 1, with time measurements
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'gs' Gauss-Seidel
%  = 'ss' SSOR like with omega=1
%  = 'lu' Incomplete LU(0)
%  = 'lm' Matlab ILU(0)
%  = 'ld' Matlab ILU with drop threshold
%  = 'lb' block ILU
%  = 'ai' approximate inverse AINV
%  = 'tw' Tang and Wang approximate inverse
%  = 'sp' SPAI approximate inverse (Huckle and Grote)
%  = 'sh' or 'wl' ILU factorizations from V. Eijkhout
%  = 'gp' given preconditioner
%  = 'gm' GMRES iterations
%  = 'ml' multilevel (AMG)
% lorth = threshold for selective reorthogonalization

% params = structure giving the parameter(s) needed by some preconditioners
%  if params is empty, default values are used
%  one or two fields if the preconditioner is not 'ml'
%
% params.p1
%  = empty for 'no', 'sc', 'gs', 'ss', 'lu', and 'lm'
%  = epsilon for 'ld'
%  = level for 'sh', 'wl'
%  = block size for 'lb'
%  = nb of GMRES iterations for 'gm'
%  = matrix M for 'gp'

% params.p1 and params.p2
%  = threshold and number of nonzero entries  in a column for 'ai'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' are in params as (default)
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)

% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv after nitmax iterations
% results is a structure with some of the following fields:
%  resn = (preconditioned) residual norms
%  resnt = true residual norms
%  norml2 = ell2-norm of the error if option l2norm = 1
%  time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%   times, the number of matrix-vector products, the number of inner products and the
%   number of matrix-vector products as a function of the iteration number,
%   otherwise same without the first two items
%

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin == 1
 error('gm_GMRESm_HB_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_GMRESm_HB_prec: Error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end % if
nx = length(x0);
if nlb ~= nx
 error('gm_GMRESm_HB_prec: Error, the dimensions of x0 and b are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,m,scaling,trueres,iprint,precond,left,reorth,lorth,timing,l2norm,delay] = gm_Krylov_ns_options(A,options);

if m > nitmax
 m = nitmax;
end

if iprint == 1
 fprintf('\n gm_GMRESm_HB_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 if reorth == 2
  fprintf('  threshold = %g \n',lorth)
 end % if
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  l2norm = %d \n',l2norm)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  timing = %g \n',timing)
end % if

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% -----------------------Initialization

if timing == 1
 tic;
end % if

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond_ns(A,precond,iprint,params);

x = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end
% this is useless
% if left == 0
%  x = gm_solve_precond_ns(A,x0,precond,cprec,cprec_amg);
% end % if left

% init residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end
if l2norm == 1
 norml2 = zeros(1,nitmax+1);
 xec = A \ b;
 norml2(1) = norm(xec -x);
end % if

resn = zeros(1,nitmax+1);

bb = b;
if left == 1
 % generalized residual M z = r
 z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 bb = gm_solve_precond_ns(A,b,precond,cprec,cprec_amg);
else
 z = r;
end % if left
nb = norm(bb);
nb2 = nb^2;

r = z;
rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m,m);
r0 = r' * r;
nr = r0;
bet = norm(r);
dotprod = dotprod + 2;

maxcycles = fix(nitmax / m) + 1;
xs = zeros(n,maxcycles);

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

% number of cycles
nitd = 0;
% number of iterations
nit = 0;
iconv = 0;
resn(1) = bet;
rhs(1) = bet;
resid = realmax;
epss = epsi^2;
% number of reorthogonalizations
nreo = 0;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 V = zeros(n,m+1);
 % init Givens rotations
 rot = zeros(2,m);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;
 
 % keep the starting vector of the cycle
 xs(:,nitd) = x;
 
 % start a cycle of GMRES(m)
 
 for k = 1:m
  % number of iterations
  nit = nit + 1;
  
  % matrix-vector product
  if left == 1
   % left preconditioner
   Av = A * v;
   % solve of M z = Av
   z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
   Av = z;
  else % if left (right preconditioner)
   z = gm_solve_precond_ns(A,v,precond,cprec,cprec_amg);
   Av = A * z;
  end % if left
  matvec = matvec + 1;
  w = Av;
  
  if reorth == 2
   % for selective reorthogonalization
   gin = norm(w);
   dotprod = dotprod + 1;
  end
  
  % construction of the basis vectors (modified Gram-Schmidt)
  % and entries of H (in the last column of H)
  for l = 1:k
   vl = V(:,l);
   gl = vl' * w;
   H(l,k) = gl;
   w = w - gl * vl;
  end % for l
  dotprod = dotprod + k;
  dk = w;
  
  % reorthogonalization (twice is enough)
  if reorth == 1
   nreo = nreo + 1;
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end % for j
   dotprod = dotprod + k;
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end % for j
   dotprod = dotprod + k;
   dk = w;
  end % if reorth
  
  % selective reorthogonalization
  if (reorth == 2) && (norm(w) < lorth * gin)
   nreo = nreo + 1;
   % reorthogonalization
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end
   dotprod = dotprod + k;
   % twice
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end
   dotprod = dotprod + k;
   dk = w;
  end % if selective reorth
  
  % normalization of the result
  gk = norm(dk);
  dotprod = dotprod + 1;
  v = dk / gk;
  H(k+1,k) = gk;
  % next basis vector
  V(:,k+1) = v;
  gk1 = gk;
  
  % apply the preceding Givens rotations to the last column just computed
  for kk = 1:k-1
   g1 = H(kk,k);
   g2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk
  
  % compute, store and apply a new Givens rotation to zero the last term in kth column
  gk = H(k,k);
  if gk == 0
   rot(1,k) = 0;
   rot(2,k) = 1;
  elseif gk1 == 0
   rot(1,k) = 1;
   rot(2,k) = 0;
  else
   cs = sqrt(abs(gk1)^2 + abs(gk)^2);
   if abs(gk) < abs(gk1)
    mu = gk / gk1;
    tau = conj(mu) / abs(mu);
   else
    mu = gk1 / gk;
    tau = mu / abs(mu);
   end % if
   % store the rotation for the next columns
   rot(1,k) = abs(gk) / cs; % cosine
   rot(2,k) = abs(gk1) * tau / cs; % sine
  end % if gk
  
  % modify the diagonal entry and the right-hand side
  H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
  
  if trueres == 1 || l2norm == 1
   % computation of the true (if left = 0) residual norm
   % triangular solve
   y = triu(H(1:k,1:k)) \ rhs(1:k);
   xx = x0 + V(:,1:k) * y;
   if left == 0
    % right preconditioner
    xx = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
   end % if left
   % this is also not the true residual norm if there is some scaling
   if trueres == 1
    resnt(nit+1) = norm(b - A * xx);
   end % if
   if l2norm == 1
    norml2(nit+1) = norm(xec -xx);
   end % if
  end
  
  % nresidu is the estimate of the residual norm given by GMRES
  nresidu = abs(rhs(k+1));
  resid = nresidu^2;
  
  if iprint == 1
   fprintf('cycle = % d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,nit,nresidu,nresidu/nb)
  end
  
  resn(nit+1) = nresidu;
  matv(nit+1) = matvec;
  
  % convergence test or too many iterations
  if nresidu < (epsi * nb) || nit >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu
  
 end %  for k - end of one cycle
 
 % computation of the solution at the end of the cycle
 % triangular solve
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 
 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
  end % if left
  % ------ exit
  resn = resn(1:nit+1);
  
  if trueres == 1
   resnt = resnt(1:nit+1);
  end
  if l2norm == 1
   norml2 = norml2(1:nit+1);
  end % if
  % return code
  iret= 0;
  if nit == nitmax
   iret = 2;
  end
  
  if iprint == 1
   if nit == nitmax
    fprintf('\n No convergence after %d iterations \n',nit)
   end
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
   if  reorth > 0
    fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   end
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
  end % if iprint
  
  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  else
   results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  end % if timing
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end
  
  results.resn = resn;
  if trueres == 1
   results.resnt = resnt;
  end % if
  if l2norm == 1
   results.norml2 = norml2;
  end % if
  
  return
  
 end % if iconv
 
 % we have not converged yet, compute the residual and restart
 
 if nitd == 1
  xx = x;
  if left == 0
   % right preconditioner
   xx = gm_solve_precond_ns(A,x,precond,cprec,cprec_amg);
  end % if left
  
  % residual vector
  r = b - A * xx;
  matvec = matvec + 1;
  
  if left == 1
   % left preconditioner
   % generalized residual M z = r
   z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
  else
   z = r;
  end % if left
  
  r = z;
  
  x0 = x;
  rk = r' * r;
  nr = rk;
  resid = rk;
  bet = norm(r);
  dotprod = dotprod + 2;
  H = zeros(m+1,m);
  rhs = zeros(m+1,1);
  rhs(1) = bet;
  
  if iprint == 1
   fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,bet,bet/nb)
  end % if
  
 else % nitd > 1
  
  % HB restarting
  
  dx = xs(:,nitd) - xs(:,nitd-1);
  
  % orthogonalize dx against V_k
  dxo = V(:,1:k)' * dx;
  g = dx - V(:,1:k) * dxo;
  
  ng = norm(g);
  if ng <= 1e-10 * norm(dx)
   % do the usual restart
   xx = x;
   if left == 0
    % right preconditioner
    xx = gm_solve_precond_ns(A,x,precond,cprec,cprec_amg);
   end % if left
   
   % residual vector at the end of the cycle
   r = b - A * xx;
   matvec = matvec + 1;
   
   if left == 1
    % left preconditioner
    % generalized residual M z = r
    z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
   else
    z = r;
   end % if left
   
   r = z;
   x0 = x;
   resid = r' * r;
   bet = norm(r);
   dotprod = dotprod + 2;
   H = zeros(m+1,m);
   rhs = zeros(m+1,1);
   rhs(1) = bet;
   
   if iprint == 1
    fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,bet,bet/nb)
   end % if
   
  else % if ng

   vt = g / ng;
   Vt = [V(:,1:k) vt];
   
   % product A vt
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * vt;
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
%     z = gm_solve_precond_ns(A,V(:,k),precond,cprec,cprec_amg);
    z = gm_solve_precond_ns(A,vt,precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   av = Av;
   
   % orthogonalize A vt against V_{k+1}
   ah = V(:,1:k+1)' * av;
   ha = av - V(:,1:k+1) * ah;
   
   % solve the least squares problem
   H(1:k+2,k+1) = [ah; norm(ha)];
   
   % apply the preceding Givens rotations to the last column just computed
   for kk = 1:k
    g1 = H(kk,k+1);
    g2 = H(kk+1,k+1);
    H(kk+1,k+1) = -rot(2,kk) * g1 + rot(1,kk) * g2;
    H(kk,k+1) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
   end % for kk
   
   % compute, store and apply a new rotation to zero the last term in k+1st column
   gk = H(k+1,k+1);
   gk1 = H(k+2,k+1);
   
   if gk == 0
    rot(1,k+1) = 0;
    rot(2,k+1) = 1;
   elseif gk1 == 0
    rot(1,k+1) = 1;
    rot(2,k+1) = 0;
   else
    cs = sqrt(abs(gk1)^2 + abs(gk)^2);
    if abs(gk) < abs(gk1)
     mu = gk / gk1;
     tau = conj(mu) / abs(mu);
    else
     mu = gk1 / gk;
     tau = mu / abs(mu);
    end % if
    % store the rotation for the next columns
    rot(1,k+1) = abs(gk) / cs; % cosine
    rot(2,k+1) = abs(gk1) * tau / cs; % sine
   end % if gk
   
   % modify the diagonal entry and the right-hand side
   H(k+1,k+1) = rot(1,k+1) * gk + conj(rot(2,k+1)) * gk1;
   c = rhs(k+1);
   rhs(k+1) = rot(1,k+1) * c;
   
   % triangular solve
   y = triu(H(1:k+1,1:k+1)) \ rhs(1:k+1);
   
   xnew = x0 + Vt * y;
   
   xx = xnew;
%    if left == 0
%     % right preconditioner
%     if strcmpi(precond,'ml') == 0
%      xx = gm_solveprecns(x,A,DD,LL,UU,precond);
%     else
%      xx = gm_amg_ns_it(A,x,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
%     end % if strcmpi
%    end % if left
   
   if left == 0
    % right preconditioner
    xx = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);  % ?????? xx or x?
   end % if left
   
   % residual vector at the end of the cycle
   r = b - A * xx;
   matvec = matvec + 1;

   if left == 1
    % left preconditioner
    % generalized residual M z = r
    z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
   else
    z = r;
   end % if left
   
   r = z;
   x0 = xnew;
   resid = r' * r;
   bet = norm(r);
   dotprod = dotprod + 2;
   rhs = zeros(m+1,1);
   rhs(1) = bet;
   
  end % if ng
  
 end % if nitd
 
 if iprint == 1
  fprintf('\n end of restart for cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,bet,bet/nb)
 end
 
end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
resn = resn(1:nit);

if trueres == 1
 resnt = resnt(1:nit);
end % if
if l2norm == 1
 norml2 = norml2(1:nit);
end % if
if nit == nitmax
 iret = 2;
end % if

xx = x;
if left == 0
 % right preconditioner
 x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
end % if left

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
 if reorth > 0
  fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 end % if
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end % if
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
end % if timing

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end % if

results.resn = resn;
if trueres == 1
 results.resnt = resnt;
end % if
if l2norm == 1
 results.norml2 = norml2;
end % if

% warning on
