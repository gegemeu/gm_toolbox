function [A,b,U,lamb,V]=gm_presc_convFOM(f,lamb,V);
%GM_PRESC_CONVFOM Computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms when
% the full FOM method is applied to (A,b)

% See: J. Duintjer Tebbens and G. Meurant,
%        Any Ritz value behavior is possible for Arnoldi and for GMRES,
%        SIAM J. of Matrix Anal. and Appl., v 33 n 3, (2012), pp 958-978

% Input:
% f = the n prescribed FOM residual norms  (different from zero)
% lamb = the n nonzero eigenvalues of A
% V = a given unitary matrix

% Output:
% A,b = the matrix and the right-hand side
% U = the matrix A satisfies A = V * U^(-1) * Cn * U * V^*
%        where Cn is the companion matrix for the prescribed eigenvalues
% lamb = eigenvalues of A
% V = unitary matrix
%
% if lamb and V are not given they are chosen randomly
%

%
% Author G. Meurant
% July 2015
%

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default');

n = length(f);

if nargin == 1
 % the eigenvalues are not prescribed
 % generate complex conjugate eigenvalues
 m = fix(n / 2);
 lamb1 = randn(m,1) + i * randn(m,1);
 if 2 * m == n
  lamb = [lamb1; conj(lamb1)];
 else
  lamb = [lamb1; conj(lamb1); randn];
 end
end

if nargin <= 2
 % V is not prescribed
 V = gm_qrandn(n,n);
end

nV = size(V,1);
if nV ~= n
 error('gm_presc_convFOM: The size of V has to be compatible with the size of f')
end

if norm(V' * V - eye(n)) > 1e-12
 error('gm_presc_convFOM: The matrix V is not unitary')
end

 % The Ritz values are not prescribed
 U = triu(randn(n,n));
 % first row of U
 rF = zeros(1,n);
 rF(1) = 1 / f(1);
 for j = 2:n
  rF(j) = 1 / f(j);
  % the diagonal entries of U must be > 0
  U(j,j) = abs(U(j,j));
 end
 U(1,:) = rF;
 % companion matrix of the eigenvalues of A
 Cn = gm_companionmat(lamb);
 
 Y = (U \ Cn) * U;
 
 %  A = (V * Y) * V';
 A = (V * Y) * inv(V);
 b = f(1) * V(:,1);
 

