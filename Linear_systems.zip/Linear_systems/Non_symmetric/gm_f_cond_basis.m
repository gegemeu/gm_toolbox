function f=gm_f_cond_basis(x);
%GM_F_COND_BASIS function for the minimization of the condition number of V_k

%
% Author G. Meurant
% Feb 2016
%

global B VV;

v = B * transpose(x);
v = v / norm(v);

V = [VV v];

f = cond(V);

