function f=gm_f_sigmin_basis(x);
%GM_F_SIGMIN_BASIS function for the maximization of the smallest singular value
%value of V_k

%
% Author G. Meurant
% Feb 2016
%

global B VV VTTV;

v = B * transpose(x);
v = v / norm(v);

V = [VV v];

f = 1 / min(svd((V)));



