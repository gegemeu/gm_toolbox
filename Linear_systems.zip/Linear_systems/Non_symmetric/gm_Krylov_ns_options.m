function [epsi,nitmax,m,scaling,trueres,iprint,precond,left,reorth,lorth,timing,l2norm,delay,var] = gm_Krylov_ns_options(A,options);
%GM_KRYLOV_NS_OPTIONS get the options for the nonsymmetric Krylov solvers

% Input:
% options is a structure containing all or some of the following fields with defaults ():
% epsi = threshold for stopping criterion (1e-10)
%  (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% m = restart parameter
% scaling = 1, diagonally scales the matrix before preconditioning (0)
% trueres = 1 computes the norm of b - A x_k (0)
% iprint = 1 print residual norms at every iteration (0)
% timing = 1, time measurements (0)
% l2norm = 1, computes the ell_2 norm of the error (0)
% left = 1, left preconditioning, else right preconditioning (1)
% reorth = 1, with full reorthogonalization, = 2 with selective reorthogonalization (0)
% lorth = threshold for selective reorthogonalization (sqrt(eps))
% var = (field name 'var') number of Harmonic Ritz vectors used in GMRES with deflated restarting
%    = number of GMRES iterations for Newton bases
%    = number of GMRES iterations for GCRO
%    = number of previous vectors in IGMRES
 
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'ic' IC(0)
%  = 'ch' IC(epsilon)
%  = 'lv' IC(level)
%  = 'll' IC(level)
%  = 'ci' Matlab incomplete Cholesky IC(0)
%  = 'ce' Matlab incomplete Cholesky IC(epsilon)
%  = 'sh' shifted alg of Manteuffel using levels
%  = 'wl' Eijkhout's algorithm
%  = 'bc' block Cholesky
%  = 'ss' SSOR with omega=1 
%  = 'ai' AINV
%  = 'tw' Tang and Wan approximate inverse
%  = 'sp' sparse approximate inverse SPAI (Huckle and Grote)
%  = 'ml' multilevel (AMG)
%  = 'gp' = preconditioner M given by the user

% for estimate of the ell2-norm:
% delay = integer, we compute the estimates delay iterations before the current one

%
% Author G. Meurant
% January 2025
%

% Defaults

n = size(A,1);

if isempty(options)
 epsi = 1e-10;
 nitmax = n;
 m = 100 * n;
 scaling = 0;
 trueres = 0;
 iprint = 0;
 precond = 'no';
 left = 1;
 timing = 0;
 l2norm = 0;
 reorth = 0;
 lorth = sqrt(eps);
 var = 5;
else
 if isfield(options,'epsi')
  epsi = options.epsi;
 else
  epsi = 1e-10;
 end % if
 if isfield(options,'nitmax')
  nitmax = options.nitmax;
 else
  nitmax = n;
 end % if
 if isfield(options,'m')
  m = options.m;
  if m == 0
   m = 10;
  end % if
 else
  m = 100 * n;
 end % if
  if isfield(options,'left')
  left = options.left;
 else
  left = 1;
 end % if
 if isfield(options,'scaling')
  scaling = options.scaling;
 else
  scaling = 0;
 end % if
 if isfield(options,'trueres')
  trueres = options.trueres;
 else
  trueres = 0;
 end % if
 if isfield(options,'iprint')
  iprint = options.iprint;
 else
  iprint = 0;
 end % if
 if isfield(options,'precond')
  precond = options.precond;
 else
  precond = 'no';
 end % if
 if isfield(options,'timing')
  timing = options.timing;
 else
  timing = 0;
 end % if
 if isfield(options,'l2norm')
  l2norm = options.l2norm;
 else
  l2norm = 0;
 end % if
 if isfield(options,'delay')
  delay = options.delay;
 else
  delay = 1;
 end % if
 if isfield(options,'reorth')
  reorth = options.reorth;
 else 
  reorth = 0;
 end % if
 if isfield(options,'lorth')
  lorth = options.lorth;
 else
  lorth = sqrt(eps);
 end % if
 if isfield(options,'var')
  var = options.var;
 else
  var = 5;
 end % if
end % if isempty

if timing == 1
 % if we measure the time we turn off printing, true residual norms, and error norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end % if
 trueres = 0;
 l2norm = 0;
end % if

% if iprint == 1
%  fprintf('\n gm_Krylov_ns_options: \n\n')
%  fprintf('  precond = %s \n',precond)
%  fprintf('  epsi =    %12.5e \n',epsi)
%  fprintf('  scaling = %d \n',scaling)
%  fprintf('  reorth  = %d \n',reorth)
%  if reorth == 2
%   fprintf('  lorth  = %12.5e \n',lorth)
%  end % if
%  fprintf('  trueres = %d \n',trueres)
%  fprintf('  iprint  = %d \n',iprint)
%  fprintf('  timing  = %d \n',timing)
%  if isfield(options,'delay')
%   fprintf('  delay   = %d \n',delay)
%  end % if
% end % if

