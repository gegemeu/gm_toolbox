
% gm_Ex_restart_TeX

% Examples with different restart parameters
% Non symmetric matrices

% produces rows to be directly put in a LaTeX table

warning off

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

tsopf = 'gm_TSOPF_14538';

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

% Choose the file

Ex = fs_680_1c;

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-20;
% Preconditioner
% ------Caution, preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Maximum number of iterations
nitmax = 150;
% threshold for selective reorthogonalization (not used here)
lorth = 0;
% tb (see comments in gm_initprecns)
tb = 0.001;
% tb = [0.01,20];
% tb = 2;
% min value of m (restart parameter)
mmin = 10;
% max value of m
mmax = 100;
% increment for m
dm = 10;

met = zeros(15,20);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'lm') == 1
 fprintf('\n ILU threshold = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'lb') == 1
 fprintf('\n block size = %d \n',tb)
end

fprintf('\n Meth, m, iter, true res, err, dp,  mv,  time   \n\n')
ndec = 4;
bslash = '\\';
hline = '\hline';
hline2 = '\hline\hline';

% GMRES with reorthogonalization

[x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,10,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' GMRES R   & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% GMRES without reorthogonalization

[x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,10,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' GMRES     & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% QOR optimal

[x,nit,iret,resn,resnt,time_mat]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nit,iret,resn,resnt,time_mat]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' QOR-I      & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% QOR optimal inv

[x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' QOR-II     & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% QOR optimal inv tridiagonal

[x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' QOR-III    & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% LCD

[x,nit,iret,resn,resnt,time_mat]=gm_LCDm_B_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_LCDm_B_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nit,iret,resn,resnt,time_mat]=gm_LCDm_B_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' LCD        & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end


% GMRES DR

% number of Ritz values
kh = 4;

[x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' GMRES DR   & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% GMRES DEF

% number of Ritz values
kh = 4;

[x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' GMRES DEF  & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% GMRES HB

[x,nit,iret,resn,resnt,time_mat]=gm_GMRESHBm_prec(A,b,x0,epss,nitmax,10,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_GMRESHBm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_GMRESHBm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' GMRES HB   & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% QOR optinv DEF

% number of Ritz values
kh = 4;

[x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' QOR-II DEF & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

% QOR optinv T DEF

% number of Ritz values
kh = 4;

[x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [x,nit,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 t = toc;
 time(mm) = t / repeat;
 err(mm) = norm(x - xec);
 it(mm) = nit;
 vm(mm) = m;
 
 [x,nitgr,iret,resn,resnt,time_mat]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);
 
 resntt(mm) = resnt(end);
 dp(mm) = time_mat.ndotp;
 mv(mm) = time_mat.matvec(end);
 
end

fprintf(' QOR-III DEF & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 vm(1),it(1),gm_num2tex(resntt(1),ndec),gm_num2tex(err(1),ndec),dp(1),mv(1),time(1),bslash,hline)
for k = 2:mm
 if k < mm
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline)
 else
  fprintf('          & %d &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
  vm(k),it(k),gm_num2tex(resntt(k),ndec),gm_num2tex(err(k),ndec),dp(k),mv(k),time(k),bslash,hline2)
 end
end

warning on




