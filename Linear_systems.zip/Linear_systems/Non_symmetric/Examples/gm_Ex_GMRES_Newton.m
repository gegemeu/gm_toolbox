
% gm_Ex_GMRES_Newton

% Examples with GMRESm_and Newton bases

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

toep_ns = 'toep_ns';

block_d = 'block_d';

rand_f = 'rand_f';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

% Choose the file

% Ex = fs_680_1c;
% mat = 'fs 680 1c';

Ex = Supg1;
mat = 'gm_supg001_225';

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

xec = A \ b;

% number of GMRES iterations to compute the shifts before Newton
pit = 10;
% Restart parameter
m = 20;
% Stopping threshold
epss = 1e-14;
% Preconditioner
% ------Caution, some preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Maximum number of iterations
nitmax = 150;
% threshold for selective reorthogonalization (not used here)
lorth = 0;
% tb (see comments in gm_initprecns)
tb = 0.01;
% tb = [0.01,20];
% tb = 2;
% Parameters for 'lm'
tb = 10;
nu = 1;
alpmax = 0.1;
alb = 0.1;
smooth = 'lu';
infl = 'b';
coarse = 'st';
interpo = 'st';

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'lm') == 1
 fprintf('\n ILU threshold = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'lb') == 1
 fprintf('\n block size = %d \n',tb)
end

% GMRES with reorthogonalization

[xgr,nitgr,iret,resngr,resngrt,time_matgr] = gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errgr = norm(xec - xgr);

fprintf('\n GMRESR, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitgr,errgr,resngrt(end))

% GMRES-Newton without reorthogonalization

[xn,nitn,iret,resnn,resnnt,time_matn] = gm_GMRESm_Newton_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errn = norm(xec - xn);

fprintf('\n GMRESN, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitn,errn,resnnt(end))

% GMRES-Newton PR

[xnpr,nitnpr,iret,resnnpr,resnnprt,time_matnpr] = gm_GMRESm_NewtonPR_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errnpr = norm(xec - xnpr);

fprintf('\n GMRESN PR, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitnpr,errnpr,resnnprt(end))

% GMRES-Newton R

[xnr,nitnr,iret,resnnr,resnnrt,time_matnr] = gm_GMRESm_NewtonR_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errnr = norm(xec - xnr);

fprintf('\n GMRESN R, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitnr,errnr,resnnrt(end))

% GMRES-Newton RS

[xnrs,nitnrs,iret,resnnrs,resnnrst,time_matnrs] = gm_GMRESm_NewtonRS_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errnrs = norm(xec - xnrs);

fprintf('\n GMRESN RS, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitnrs,errnrs,resnnrst(end))

% GMRES-Newton S

[xns,nitns,iret,resnns,resnnst,time_matns] = gm_GMRESm_NewtonS_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errns = norm(xec - xns);

fprintf('\n GMRESN S, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitns,errns,resnnst(end))

% GMRES-Newton C

[xnc,nitnc,iret,resnnc,resnnct,time_matnc] = gm_GMRESm_NewtonC_prec(A,b,x0,epss,nitmax,m,pit,'left','noreorth'...
 ,'noscaling','trueres','noprint',precond,lorth,tb,nu,alpmax,alb,smooth,infl,coarse,interpo);

errnc = norm(xec - xnc);

fprintf('\n GMRESN C, m = %d, nit = %d, error norm = %11.4e, true residual norm = %11.4e \n',m,nitnc,errnc,resnnct(end))

figure

plot(log10(resngrt))
hold on
plot([1:length(resnnt)],log10(resnnt),'r-*')
plot([1:length(resnnprt)],log10(resnnprt),'g-+')
plot([1:length(resnnrt)],log10(resnnrt),'m-x')
plot([1:length(resnnrst)],log10(resnnrst),'c-s')
plot([1:length(resnnst)],log10(resnnst),'k-d')
plot([1:length(resnnct)],log10(resnnct),'b-->')
legend('GMRES','GMRESN','GMRES PR','GMRES R','GMRES RS','GMRES S','GMRES C')
title(['True residual   ' mat ',  ' precond])
hold off

figure

plot(log10(resngr/resngr(1)))
hold on
plot([1:length(resnn)],log10(resnn/resngr(1)),'r-*')
plot([1:length(resnnpr)],log10(resnnpr/resngr(1)),'g-+')
plot([1:length(resnnr)],log10(resnnr/resngr(1)),'m-x')
plot([1:length(resnnrs)],log10(resnnrs/resngr(1)),'c-s')
plot([1:length(resnns)],log10(resnns/resngr(1)),'k-d')
plot([1:length(resnnc)],log10(resnnc/resngr(1)),'b-->')
legend('GMRES','GMRESN','GMRES PR','GMRES R','GMRES RS','GMRES S','GMRES C')
title(['Relative residual   ' mat ',  ' precond])
hold off


