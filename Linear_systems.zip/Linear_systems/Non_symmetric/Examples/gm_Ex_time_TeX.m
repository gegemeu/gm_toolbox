
% gm_Ex_time_TeX

% Examples with time measurements
% Non symmetric matrices

% produces rows to be directly put in a LaTeX table

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

toep_ns = 'toep_ns';

block_d = 'block_d';

rand_f = 'rand_f';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose the file

Ex = fs_680_1c;

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-20;
% Preconditioner
% ------Caution, some preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Restarting parameter, GMRES(m),...
m = 7000;
% Maximum number of iterations
nitmax = 150;

% The following parameters may not be well adapted for all preconditioners
if strcmpi(precond,'ld') == 1
 params = struct('p1',0.01);
elseif strcmpi(precond,'sp') == 1
 params = struct('p1',0.01,'p2',20);
elseif strcmpi(precond,'ai') == 1
 params = struct('p1',0.01,'p2',20);
else
 params = [];
end % if

met = zeros(17,11);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d, m = %d \n',precond,epss,nitmax,m)


fprintf('\n Meth, iter, true res, err, dp,  mv,  time   \n\n')
ndec = 4;
bslash = '\\';
hline = '\hline';

% Full GMRES with reorthogonalization

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' GMRES R   &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% Full GMRES without reorthogonalization

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' GMRES     &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)


% Full FOM with reorthogonalization

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' FOM R     &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% Full FOM without reorthogonalization

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' FOM       &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% CMRH

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' CMRH      &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% BiCG

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCG_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_BiCG_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_BiCG_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCG_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' BICG      &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% CGS

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_CGS_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_CGS_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_CGS_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_CGS_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' CGS       &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% BiCGStab

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' BICGSTAB  &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% BiCGStab2

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' BICGSTAB2 &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% BiCGStab(3) 

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[3, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[3, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[3, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' BICGSTAB3 &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% BiCGStab(4)

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[4, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[4, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[4, 0.7]);
[x,nit,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' BICGSTAB4 &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% IDR(2)

options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' IDR(2)    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% IDR(3)

options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' IDR(3)    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% IDR(4)

options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mat = results.timing;


dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' IDR(4)    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% QOR optimal

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' QOR-I     &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% QOR optimal using the inverses of Cholesky factors

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' QOR-II    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% QOR optimal using the tridiagonal inverse

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' QOR-III   &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% QOR optimal truncated

pp = 30;
qq = pp;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[pp, qq]);
[x,nit,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[pp, qq]);
[x,nit,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[pp, qq]);
[x,nit,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' QOR pq    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% TFQMR

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' TFQMR     &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% Adaptive simpler GMRES, delta = 0.9

delta = 0.9;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',delta);
[x,nit,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',delta);
[x,nit,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',delta);
[x,nit,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' ASGMRES   &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% GCR

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GCRm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' GCR       &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',....
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% GCRO

itint = 2;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',itint);
[x,nit,iret,results] = gm_GCROm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',itint);
[x,nit,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',itint);
[x,nit,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' GCRO      &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',....
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% LCD

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_LCDm_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' LCDm      &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)

% QOR optimal using the inverses of Cholesky factors + RCD

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);

tic
for k = 1:repeat
 [x,nit,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
end

t = toc;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[x,nit,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
resnt = results.resnt;

t = t / repeat;
err = norm(x - xec);
resntt = resnt(length(resnt));

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[x,nit,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
time_mat = results.timing;

dp = time_mat.ndotp;
mv = time_mat.matvec(end);

fprintf(' QORRCD    &  %4d & $%s$  & $%s$ & %d & %d & $%10.5f$ %s \n %s \n',...
 nit,gm_num2tex(resntt,ndec),gm_num2tex(err,ndec),dp,mv,t,bslash,hline)



