
% gm_Ex_restart

% Examples with different restart parameters
% Non symmetric matrices

% Caution!!!!!!
clear

warning('off')

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

% tsopf = 'gm_TSOPF_14538';

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

% Choose the file

Ex = fs_680_1c;
mat = 'fs 680 1c';

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-14;
% Preconditioner
% ------Caution, preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Maximum number of iterations
nitmax = 250;
% min value of m
mmin = 10;
% max value of m
mmax = 100;
% increment for m
dm = 10;

% The following parameters may not be well adapted for all preconditioners
if strcmpi(precond,'ld') == 1
 params = struct('p1',0.01);
elseif strcmpi(precond,'sp') == 1
 params = struct('p1',0.01,'p2',20);
elseif strcmpi(precond,'ai') == 1
 params = struct('p1',0.01,'p2',20);
else
 params = [];
end % if

met = zeros(15,20);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'lm') == 1
 fprintf('\n ILU threshold = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'lb') == 1
 fprintf('\n block size = %d \n',tb)
end

% GMRES with reorthogonalization

met(1,1:6) = 'GMRESR';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 end
 
 tgr = toc;
 timegr(mm) = tgr / repeat;
 errgr(mm) = norm(xgr - xec);
 itgr(mm) = nitgr;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
 [x,nit,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 resngrt = results.resnt;
 time_matgr = results.timing;
 
 resgr(mm) = resngrt(end);
 dpgr(mm) = time_matgr.ndotp;
 mvgr(mm) = time_matgr.matvec(end);
 
end

fprintf('\n GMRESR \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itgr(k),resgr(k),errgr(k),dpgr(k),mvgr(k),timegr(k))
end

[mine,I] = min(errgr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itgr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% GMRES without reorthogonalization

met(2,1:5) = 'GMRES';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 end
 
 tg = toc;
 timeg(mm) = tg / repeat;
 errg(mm) = norm(xg - xec);
 itg(mm) = nitg;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 resngt = results.resnt;
 time_matg = results.timing;
 
 resg(mm) = resngt(end);
 dpg(mm) = time_matg.ndotp;
 mvg(mm) = time_matg.matvec(end);
 
end

fprintf('\n GMRES \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itg(k),resg(k),errg(k),dpg(k),mvg(k),timeg(k))
end

[mine,I] = min(errg);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itg);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% FOM with reorthogonalization

met(3,1:4) = 'FOMR';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 end
 
 tfr = toc;
 timefr(mm) = tfr / repeat;
 errfr(mm) = norm(xfr - xec);
 itfr(mm) = nitfr;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
 [xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 resnfrt = results.resnt;
 time_matfr = results.timing;
 
 resfr(mm) = resnfrt(end);
 dpfr(mm) = time_matfr.ndotp;
 mvfr(mm) = time_matfr.matvec(end);
end

fprintf('\n FOMR \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itfr(k),resfr(k),errfr(k),dpfr(k),mvfr(k),timefr(k))
end

[mine,I] = min(errfr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itfr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% FOM without reorthogonalization

met(4,1:3) = 'FOM';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 end
 
 tf = toc;
 timef(mm) = tf / repeat;
 errf(mm) = norm(xf - xec);
 itf(mm) = nitf;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 resnft = results.resnt;
 time_matf = results.timing;

 resf(mm) = resnft(end);
 dpf(mm) = time_matf.ndotp;
 mvf(mm) = time_matf.matvec(end);
 
end

fprintf('\n FOM \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itf(k),resf(k),errf(k),dpf(k),mvf(k),timef(k))
end

[mine,I] = min(errf);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itf);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% CMRH

met(5,1:4) = 'CMRH';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
 end
 
 tc = toc;
 timec(mm) = tc / repeat;
 errc(mm) = norm(xc - xec);
 itc(mm) = nitc;
 vm(mm) = m;
 
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
 resnct = results.resnt;
 time_matc = results.timing;

 resc(mm) = resnct(end);
 dpc(mm) = time_matc.ndotp;
 mvc(mm) = time_matc.matvec(end);
 
end

fprintf('\n CMRH \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itc(k),resc(k),errc(k),dpc(k),mvc(k),timec(k))
end

[mine,I] = min(errc);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itc);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optimal

met(6,1:5) = 'QOR-I';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
 end
 
 tq = toc;
 timeq(mm) = tq / repeat;
 errq(mm) = norm(xq - xec);
 itq(mm) = nitq;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
resnqt = results.resnt;
time_matq = results.timing;

 resq(mm) = resnqt(end);
 dpq(mm) = time_matq.ndotp;
 mvq(mm) = time_matq.matvec(end);
 
end

fprintf('\n QOR-I \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itq(k),resq(k),errq(k),dpq(k),mvq(k),timeq(k))
end

[mine,I] = min(errq);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itq);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% QOR optimal inv

met(6,1:6) = 'QOR-II';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xqi,nitqi,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xqi,nitqi,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
 end
 
 tqi = toc;
 timeqi(mm) = tqi / repeat;
 errqi(mm) = norm(xqi - xec);
 itqi(mm) = nitqi;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xqi,nitqi,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
 resnqit = results.resnt;
 time_matqi = results.timing;

 resqi(mm) = resnqit(end);
 dpqi(mm) = time_matqi.ndotp;
 mvqi(mm) = time_matqi.matvec(end);
 
end

fprintf('\n QOR-II \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itqi(k),resqi(k),errqi(k),dpqi(k),mvqi(k),timeqi(k))
end

[mine,I] = min(errqi);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itqi);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% Truncated GMRES

met(7,1:6) = 'GMREST';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xtg,nittg,iret,results] = gm_GMRESm_trunc_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xtg,nittg,iret,results] = gm_GMRESm_trunc_prec(A,b,x0,options,params);
 end
 
 ttg = toc;
 timetg(mm) = ttg / repeat;
 errtg(mm) = norm(xtg - xec);
 ittg(mm) = nittg;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xtg,nittg,iret,results] = gm_GMRESm_trunc_prec(A,b,x0,options,params);
 resntgt = results.resnt;
 time_mattg = results.timing;

 restg(mm) = resntgt(end);
 dptg(mm) = time_mattg.ndotp;
 mvtg(mm) = time_mattg.matvec(end);
 
end

fprintf('\n Truncated GMRES \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),ittg(k),restg(k),errtg(k),dptg(k),mvtg(k),timetg(k))
end

[mine,I] = min(errtg);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(ittg);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR opt partial

met(8,1:6) = 'QOR pq';

options = struct('epsi',epss,'nitmax',nitmax,'m',30,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',[2,2]);
[xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 qq = fix(m / 2);
 if mod(m,2) == 0
  pp = qq;
 else
  pp = qq + 1;
 end
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',[pp, qq]);
 tic
 for k = 1:repeat
  [xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
 end
 
 tp = toc;
 timep(mm) = tp / repeat;
 errp(mm) = norm(xp - xec);
 itp(mm) = nitp;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',[pp, qq]);
[xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
resnpt = results.resnt;
time_matp = results.timing;

 resp(mm) = resnpt(end);
 dpp(mm) = time_matp.ndotp;
 mvp(mm) = time_matp.matvec(end);
 
end

fprintf('\n QOR pq \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itp(k),resp(k),errp(k),dpp(k),mvp(k),timep(k))
end

[mine,I] = min(errp);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itp);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optimal inv T

met(9,1:7) = 'QOR-III';

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xqit,nitqit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
 tic
 for k = 1:repeat
  [xqit,nitqit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
 end
 
 tqit = toc;
 timeqit(mm) = tqit / repeat;
 errqit(mm) = norm(xqit - xec);
 itqit(mm) = nitqit;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xqit,nitqit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
 resnqitt = results.resnt;
 time_matqit = results.timing;

 resqit(mm) = resnqitt(end);
 dpqit(mm) = time_matqit.ndotp;
 mvqit(mm) = time_matqit.matvec(end);
 
end

fprintf('\n QOR-III \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itqit(k),resqit(k),errqit(k),dpqit(k),mvqit(k),timeqit(k))
end

[mine,I] = min(errqit);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itqit);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% GMRES DR

met(10,1:8) = 'GMRES DR';
% number of Ritz values
kh = 4;

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
[xdr,nitdr,iret,results] = gm_GMRESm_DR_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
 tic
 for k = 1:repeat
  [xdr,nitdr,iret,results] = gm_GMRESm_DR_prec(A,b,x0,options,params);
 end
 
 tdr = toc;
 timedr(mm) = tdr / repeat;
 errdr(mm) = norm(xdr - xec);
 itdr(mm) = nitdr;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
[xdr,nitdr,iret,results] = gm_GMRESm_DR_prec(A,b,x0,options,params);
resndrt = results.resnt;
time_matdr = results.timing;

 resdr(mm) = resndrt(end);
 dpdr(mm) = time_matdr.ndotp;
 mvdr(mm) = time_matdr.matvec(end);
 
end

fprintf('\n GMRES DR, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdr(k),resdr(k),errdr(k),dpdr(k),mvdr(k),timedr(k))
end

[mine,I] = min(errdr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% GMRES DEF

met(11,1:9) = 'GMRES DEF';
% number of Ritz values
kh = 4;

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
[xdf,nitdf,iret,results] = gm_GMRESm_DEF_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
 tic
 for k = 1:repeat
  [xdf,nitdf,iret,results] = gm_GMRESm_DEF_prec(A,b,x0,options,params);
 end
 
 tdf = toc;
 timedf(mm) = tdf / repeat;
 errdf(mm) = norm(xdf - xec);
 itdf(mm) = nitdf;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
 [xdf,nitdf,iret,results] = gm_GMRESm_DEF_prec(A,b,x0,options,params);
 resndft = results.resnt;
 time_matdf = results.timing;

 resdf(mm) = resndft(end);
 dpdf(mm) = time_matdf.ndotp;
 mvdf(mm) = time_matdf.matvec(end);
 
end

fprintf('\n GMRES DEF, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdf(k),resdf(k),errdf(k),dpdf(k),mvdf(k),timedf(k))
end

[mine,I] = min(errdf);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdf);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optinv DEF

met(12,1:10) = 'QOR-II DEF';
% number of Ritz values
kh = 4;

options = struct('epsi',epss,'nitmax',nitmax,'m',10,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
[xdo,nitdo,iret,results] = gm_QORm_optinv_DEF_prec(A,b,x0,options,params);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',kh);
 tic
 for k = 1:repeat
  [xdo,nitdo,iret,results] = gm_QORm_optinv_DEF_prec(A,b,x0,options,params);
 end
 
 tdo = toc;
 timedo(mm) = tdo / repeat;
 errdo(mm) = norm(xdo - xec);
 itdo(mm) = nitdo;
 vm(mm) = m;
 
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
 [xdo,nitdo,iret,results] = gm_QORm_optinv_DEF_prec(A,b,x0,options,params);
 resndot = results.resnt;
 time_matdo = results.timing;

 resdo(mm) = resndot(end);
 dpdo(mm) = time_matdo.ndotp;
 mvdo(mm) = time_matdo.matvec(end);
 
end

fprintf('\n QOR-II DEF, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdo(k),resdo(k),errdo(k),dpdo(k),mvdo(k),timedo(k))
end

[mine,I] = min(errdo);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdo);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% figure

plot(vm,itgr);
hold on
plot(vm,itg,'r-*')
plot(vm,itfr,'g-+')
plot(vm,itf,'m->')
plot(vm,itc,'c-<')
plot(vm,itq,'k-o')
plot(vm,itqi,'k-+')
plot(vm,ittg,'b-d')
plot(vm,itp,'r-p')
plot(vm,itqit,'g-h')
plot(vm,itdr,'m-s')
plot(vm,itdf,'c-v')
plot(vm,itdo,'k-^')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF')
title('number of iterations vs m')
xlabel('restart parameter m')
ylabel('nb. iter.')
hold off

figure

semilogy(vm,errgr);
hold on
semilogy(vm,errg,'r-*')
semilogy(vm,errfr,'g-+')
semilogy(vm,errf,'m->')
semilogy(vm,errc,'c-<')
semilogy(vm,errq,'k-o')
semilogy(vm,errqi,'k-+')
semilogy(vm,errtg,'b-d')
semilogy(vm,errp,'r-p')
semilogy(vm,errqit,'g-h')
semilogy(vm,errdr,'m-s')
semilogy(vm,errdf,'c-v')
semilogy(vm,errdo,'k-^')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF')
title('Final error norm vs m')
xlabel('restart parameter m')
ylabel('final error')
hold off

figure

plot(vm,dpgr);
hold on
plot(vm,dpg,'r-*')
plot(vm,dpfr,'g-+')
plot(vm,dpf,'m->')
plot(vm,dpc,'c-<')
plot(vm,dpq,'k-o')
plot(vm,dpqi,'k-+')
plot(vm,dptg,'b-d')
plot(vm,dpp,'r-p')
plot(vm,dpqit,'g-h')
plot(vm,dpdr,'m-s')
plot(vm,dpdf,'c-v')
plot(vm,dpdo,'k-^')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF')
title('Dot products vs m')
xlabel('restart parameter m')
ylabel('dotps')
hold off

figure

plot(vm,mvgr);
hold on
plot(vm,mvg,'r-*')
plot(vm,mvfr,'g-+')
plot(vm,mvf,'m->')
plot(vm,mvc,'c-<')
plot(vm,mvq,'k-o')
plot(vm,mvqi,'k-+')
plot(vm,mvtg,'b-d')
plot(vm,mvp,'r-p')
plot(vm,mvqit,'g-h')
plot(vm,mvdr,'m-s')
plot(vm,mvdf,'c-v')
plot(vm,mvdo,'k-^')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF')
title('Matrix-vector products vs m')
xlabel('restart parameter m')
ylabel('matvecs')
hold off

% GMRESR

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
 [xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 resngrt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resngrt,'r--')
 else
  semilogy(resngrt,'b')
 end
 hold on
end
title('GMRESR, true residual norms')
hold off

% GMRES

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 resngt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resngt,'r--')
 else
  semilogy(resngt,'b')
 end
 hold on
end
title('GMRES, true residual norms')
hold off

% FOMR

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
 [xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 resnfrt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnfrt,'r--')
 else
  semilogy(resnfrt,'b')
 end
 hold on
end
title('FOMR, true residual norms')
hold off

% FOM

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
 resnft = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnft,'r--')
 else
  semilogy(resnft,'b')
 end
 hold on
end
title('FOM, true residual norms')
hold off

% CMRH

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
 resnct = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnct,'r--')
 else
  semilogy(resnct,'b')
 end
 hold on
end
title('CMRH, true residual norms')
hold off

% QOR-I

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
resnqt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnqt,'r--')
 else
  semilogy(resnqt,'b')
 end
 hold on
end
title('QOR-I, true residual norms')
hold off

% QOR-II

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xqi,nitqi,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
resnqit = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnqit,'r--')
 else
  semilogy(resnqit,'b')
 end
 hold on
end
title('QOR-II, true residual norms')
hold off

% Truncated GMRES

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xtg,nittg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
 resntgt = results.resnt;

 if rem(mm,2) == 0
  semilogy(resntgt,'r--')
 else
  semilogy(resntgt,'b')
 end
 hold on
end
title('Truncated GMRES, true residual norms')
hold off

% QOR pq

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 qq = fix(m / 2);
 if mod(m,2) == 0
  pp = qq;
 else
  pp = qq + 1;
 end
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',[pp, qq]);
 [xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
 resnpt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnpt,'r--')
 else
  semilogy(resnpt,'b')
 end
 hold on
end
title('QOR pq, true residual norms')
hold off

% QOR-III

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
 [xqit,nitqit,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
 resnqitt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resnqitt,'r--')
 else
  semilogy(resnqitt,'b')
 end
 hold on
end
title('QOR-III, true residual norms')
hold off

% GMRES DR

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
[xdr,nitdr,iret,results] = gm_GMRESm_DR_prec(A,b,x0,options,params);
resndrt = results.resnt;
 if rem(mm,2) == 0
  semilogy(resndrt,'r--')
 else
  semilogy(resndrt,'b')
 end
 hold on
end
title('GMRES DR, true residual norms')
hold off

% GMRES DEF

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
 [xdf,nitdf,iret,results] = gm_GMRESm_DEF_prec(A,b,x0,options,params);
 resndft = results.resnt;
 if rem(mm,2) == 0
  semilogy(resndft,'r--')
 else
  semilogy(resndft,'b')
 end
 hold on
end
title('GMRES DEF, true residual norms')
hold off

% QOR-II DEF

figure
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1,'var',kh);
 [xdo,nitdo,iret,results] = gm_QORm_optinv_DEF_prec(A,b,x0,options,params);
 resndot = results.resnt;
 if rem(mm,2) == 0
  semilogy(resndot,'r--')
 else
  semilogy(resndot,'b')
 end
 hold on
end
title('QOR-II DEF, true residual norms')
hold off


warning('on')



