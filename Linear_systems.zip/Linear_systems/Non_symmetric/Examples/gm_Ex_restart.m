
% gm_Ex_restart

% Examples with different restart parameters
% Non symmetric matrices

% Caution!!!!!!
clear

warning off

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

% tsopf = 'gm_TSOPF_14538';

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

% Choose the file

Ex = fs_680_1c;
mat = 'fs 680 1c';

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-20;
% Preconditioner
% ------Caution, preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Maximum number of iterations
nitmax = 150;
% threshold for selective reorthogonalization (not used here)
lorth = 0;
% tb (see comments in gm_initprecns)
tb = 0.001;
% tb = [0.01,20];
% tb = 2;
% min value of m
mmin = 10;
% max value of m
mmax = 100;
% increment for m
dm = 10;

met = zeros(15,20);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d \n',precond,epss,nitmax)

if strcmpi(precond,'lm') == 1
 fprintf('\n ILU threshold = %g \n',tb)
end

if strcmpi(precond,'ai') == 1
 fprintf('\n AINV threshold = %g, q = %d \n',tb(1),tb(2))
end

if strcmpi(precond,'lb') == 1
 fprintf('\n block size = %d \n',tb)
end

% GMRES with reorthogonalization

met(1,1:6) = 'GMRESR';

[xgr,nitgr,iret,resngr,resngrt,time_matgr]=gm_GMRESm_prec(A,b,x0,epss,nitmax,10,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xgr,nitgr,iret,resngr,resngrt,time_matgr]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tgr = toc;
 timegr(mm) = tgr / repeat;
 errgr(mm) = norm(xgr - xec);
 itgr(mm) = nitgr;
 vm(mm) = m;
 
 [xgr,nitgr,iret,resngr,resngrt,time_matgr]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resgr(mm) = resngrt(end);
 dpgr(mm) = time_matgr.ndotp;
 mvgr(mm) = time_matgr.matvec(end);
 
end

fprintf('\n GMRESR \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itgr(k),resgr(k),errgr(k),dpgr(k),mvgr(k),timegr(k))
end

[mine,I] = min(errgr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itgr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% GMRES without reorthogonalization

met(2,1:5) = 'GMRES';

[xg,nitg,iret,resng,resngt,time_matg]=gm_GMRESm_prec(A,b,x0,epss,nitmax,10,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xg,nitg,iret,resng,resngt,time_matg]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tg = toc;
 timeg(mm) = tg / repeat;
 errg(mm) = norm(xg - xec);
 itg(mm) = nitg;
 vm(mm) = m;
 
 [xg,nitg,iret,resngr,resngt,time_matg]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resg(mm) = resngt(end);
 dpg(mm) = time_matg.ndotp;
 mvg(mm) = time_matg.matvec(end);
 
end

fprintf('\n GMRES \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itg(k),resg(k),errg(k),dpg(k),mvg(k),timeg(k))
end

[mine,I] = min(errg);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itg);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% FOM with reorthogonalization

met(3,1:4) = 'FOMR';

[xfr,nitfr,iret,resnfr,resnfrt,time_matfr]=gm_FOMm_prec(A,b,x0,epss,nitmax,10,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xfr,nitfr,iret,resnfr,resnfrt,time_matfr]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tfr = toc;
 timefr(mm) = tfr / repeat;
 errfr(mm) = norm(xfr - xec);
 itfr(mm) = nitfr;
 vm(mm) = m;
 
 [xfr,nitfr,iret,resnfr,resnfrt,time_matfr]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);
 
 resfr(mm) = resnfrt(end);
 dpfr(mm) = time_matfr.ndotp;
 mvfr(mm) = time_matfr.matvec(end);
end

fprintf('\n FOMR \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itfr(k),resfr(k),errfr(k),dpfr(k),mvfr(k),timefr(k))
end

[mine,I] = min(errfr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itfr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% FOM without reorthogonalization

met(4,1:3) = 'FOM';

[xf,nitf,iret,resnf,resnft,time_matf]=gm_FOMm_prec(A,b,x0,epss,nitmax,10,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xf,nitf,iret,resnf,resnft,time_matf]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tf = toc;
 timef(mm) = tf / repeat;
 errf(mm) = norm(xf - xec);
 itf(mm) = nitf;
 vm(mm) = m;
 
 [xf,nitf,iret,resnf,resnft,time_matf]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);

 resf(mm) = resnft(end);
 dpf(mm) = time_matf.ndotp;
 mvf(mm) = time_matf.matvec(end);
 
end

fprintf('\n FOM \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itf(k),resf(k),errf(k),dpf(k),mvf(k),timef(k))
end

[mine,I] = min(errf);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itf);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% CMRH

met(5,1:4) = 'CMRH';

[xc,nitc,iret,resnc,resnct,time_matc]=gm_CMRHm_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xc,nitc,iret,resnc,resnct,time_matc]=gm_CMRHm_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tc = toc;
 timec(mm) = tc / repeat;
 errc(mm) = norm(xc - xec);
 itc(mm) = nitc;
 vm(mm) = m;
 
[xc,nitc,iret,resnc,resnct,time_matc]=gm_CMRHm_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);

 resc(mm) = resnct(end);
 dpc(mm) = time_matc.ndotp;
 mvc(mm) = time_matc.matvec(end);
 
end

fprintf('\n CMRH \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itc(k),resc(k),errc(k),dpc(k),mvc(k),timec(k))
end

[mine,I] = min(errc);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itc);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optimal

met(6,1:5) = 'QOR-I';

[xq,nitq,iret,resnq,resnqt,time_matq]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xq,nitq,iret,resnq,resnqt,time_matq]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tq = toc;
 timeq(mm) = tq / repeat;
 errq(mm) = norm(xq - xec);
 itq(mm) = nitq;
 vm(mm) = m;
 
 [xq,nitq,iret,resnq,resnqt,time_matq]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);

 resq(mm) = resnqt(end);
 dpq(mm) = time_matq.ndotp;
 mvq(mm) = time_matq.matvec(end);
 
end

fprintf('\n QOR-I \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itq(k),resq(k),errq(k),dpq(k),mvq(k),timeq(k))
end

[mine,I] = min(errq);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itq);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% QOR optimal inv

met(6,1:6) = 'QOR-II';

[xqi,nitqi,iret,resnqi,resnqit,time_matqi]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xqi,nitqi,iret,resnqi,resnqit,time_matqi]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tqi = toc;
 timeqi(mm) = tqi / repeat;
 errqi(mm) = norm(xqi - xec);
 itqi(mm) = nitqi;
 vm(mm) = m;
 
 [xqi,nitqi,iret,resnqi,resnqit,time_matqi]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);

 resqi(mm) = resnqit(end);
 dpqi(mm) = time_matqi.ndotp;
 mvqi(mm) = time_matqi.matvec(end);
 
end

fprintf('\n QOR-II \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itqi(k),resqi(k),errqi(k),dpqi(k),mvqi(k),timeqi(k))
end

[mine,I] = min(errqi);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itqi);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))


% Truncated GMRES

met(7,1:6) = 'GMREST';

[xtg,nittg,iret,resntg,resntgt,time_mattg]=gm_GMRES_trunc_prec(A,b,x0,epss,nitmax,10,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xtg,nittg,iret,resntg,resntgt,time_mattg]=gm_GMRES_trunc_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 ttg = toc;
 timetg(mm) = ttg / repeat;
 errtg(mm) = norm(xtg - xec);
 ittg(mm) = nittg;
 vm(mm) = m;
 
 [xtg,nittg,iret,resntg,resntgt,time_mattg]=gm_GMRES_trunc_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);

 restg(mm) = resntgt(end);
 dptg(mm) = time_mattg.ndotp;
 mvtg(mm) = time_mattg.matvec(end);
 
end

fprintf('\n Truncated GMRES \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),ittg(k),restg(k),errtg(k),dptg(k),mvtg(k),timetg(k))
end

[mine,I] = min(errtg);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(ittg);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR opt partial

met(8,1:6) = 'QOR pq';

[xp,nitp,iret,resnp,resnpt,time_matp]=gm_QORm_opt_partial_prec(A,b,x0,epss,nitmax,10,5,5,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 qq = fix(m / 2);
 if mod(m,2) == 0
  pp = qq;
 else
  pp = qq + 1;
 end
 tic
 for k = 1:repeat
  [xp,nitp,iret,resnp,resnpt,time_matp]=gm_QORm_opt_partial_prec(A,b,x0,epss,nitmax,m,pp,qq,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tp = toc;
 timep(mm) = tp / repeat;
 errp(mm) = norm(xp - xec);
 itp(mm) = nitp;
 vm(mm) = m;
 
 [xp,nitp,iret,resnp,resnpt,time_matp]=gm_QORm_opt_partial_prec(A,b,x0,epss,nitmax,m,pp,qq,'left','noscaling','trueres','noprint',precond,tb);

 resp(mm) = resnpt(end);
 dpp(mm) = time_matp.ndotp;
 mvp(mm) = time_matp.matvec(end);
 
end

fprintf('\n QOR pq \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itp(k),resp(k),errp(k),dpp(k),mvp(k),timep(k))
end

[mine,I] = min(errp);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itp);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optimal inv T

met(9,1:7) = 'QOR-III';

[xqit,nitqit,iret,resnqit,resnqitt,time_matqit]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,10,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xqit,nitqit,iret,resnqit,resnqitt,time_matqit]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,m,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tqit = toc;
 timeqit(mm) = tqit / repeat;
 errqit(mm) = norm(xqit - xec);
 itqit(mm) = nitqit;
 vm(mm) = m;
 
 [xqit,nitqit,iret,resnqit,resnqitt,time_matqit]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);

 resqit(mm) = resnqitt(end);
 dpqit(mm) = time_matqit.ndotp;
 mvqit(mm) = time_matqit.matvec(end);
 
end

fprintf('\n QOR-III \n\n')
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itqit(k),resqit(k),errqit(k),dpqit(k),mvqit(k),timeqit(k))
end

[mine,I] = min(errqit);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itqit);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% GMRES DR

met(10,1:8) = 'GMRES DR';
% number of Ritz values
kh = 4;

[xdr,nitdr,iret,resndr,resndrt,time_matdr]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xdr,nitdr,iret,resndr,resndrt,time_matdr]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tdr = toc;
 timedr(mm) = tdr / repeat;
 errdr(mm) = norm(xdr - xec);
 itdr(mm) = nitdr;
 vm(mm) = m;
 
 [xdr,nitdr,iret,resndr,resndrt,time_matdr]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);

 resdr(mm) = resndrt(end);
 dpdr(mm) = time_matdr.ndotp;
 mvdr(mm) = time_matdr.matvec(end);
 
end

fprintf('\n GMRES DR, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdr(k),resdr(k),errdr(k),dpdr(k),mvdr(k),timedr(k))
end

[mine,I] = min(errdr);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdr);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% GMRES DEF

met(11,1:9) = 'GMRES DEF';
% number of Ritz values
kh = 4;

[xdf,nitdf,iret,resndf,resndft,time_matdf]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xdf,nitdf,iret,resndf,resndft,time_matdf]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','notrueres','noprint',precond,lorth,tb);
 end
 
 tdf = toc;
 timedf(mm) = tdf / repeat;
 errdf(mm) = norm(xdf - xec);
 itdf(mm) = nitdf;
 vm(mm) = m;
 
 [xdf,nitdf,iret,resndf,resndft,time_matdf]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);

 resdf(mm) = resndft(end);
 dpdf(mm) = time_matdf.ndotp;
 mvdf(mm) = time_matdf.matvec(end);
 
end

fprintf('\n GMRES DEF, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdf(k),resdf(k),errdf(k),dpdf(k),mvdf(k),timedf(k))
end

[mine,I] = min(errdf);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdf);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optinv DEF

met(12,1:10) = 'QOR-II DEF';
% number of Ritz values
kh = 4;

[xdo,nitdo,iret,resndo,resndot,time_matdo]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xdo,nitdo,iret,resndo,resndot,time_matdo]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tdo = toc;
 timedo(mm) = tdo / repeat;
 errdo(mm) = norm(xdo - xec);
 itdo(mm) = nitdo;
 vm(mm) = m;
 
 [xdo,nitdo,iret,resndo,resndot,time_matdo]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);

 resdo(mm) = resndot(end);
 dpdo(mm) = time_matdo.ndotp;
 mvdo(mm) = time_matdo.matvec(end);
 
end

fprintf('\n QOR-II DEF, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdo(k),resdo(k),errdo(k),dpdo(k),mvdo(k),timedo(k))
end

[mine,I] = min(errdo);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdo);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% QOR optinv T DEF

met(13,1:11) = 'QOR-III DEF';
% number of Ritz values
kh = 4;

[xdoot,nitdoot,iret,resndoot,resndoott,time_matdot]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,10+kh*i,'left','noscaling','notrueres','noprint',precond,tb);

mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 tic
 for k = 1:repeat
  [xdoot,nitdoot,iret,resndoot,resndoott,time_matdot]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','notrueres','noprint',precond,tb);
 end
 
 tdoot = toc;
 timedoot(mm) = tdoot / repeat;
 errdoot(mm) = norm(xdoot - xec);
 itdoot(mm) = nitdoot;
 vm(mm) = m;
 
 [xdoot,nitdoot,iret,resndoot,resndoott,time_matdoot]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);

 resdoot(mm) = resndoott(end);
 dpdoot(mm) = time_matdoot.ndotp;
 mvdoot(mm) = time_matdoot.matvec(end);
 
end

fprintf('\n QOR-III DEF, %d eigenvalues\n\n',kh)
for k = 1:mm
 fprintf(' m = %d, nit = %d, true residual = %g, error = %11.4e, dp = %d, mv = %d, cpu = %11.4e \n',vm(k),itdoot(k),resdoot(k),errdoot(k),dpdoot(k),mvdoot(k),timedoot(k))
end

[mine,I] = min(errdoot);
fprintf('\n minimum error = %11.4e for m = %d \n',mine,vm(I(1)))
[minit,I] = min(itdoot);
fprintf('\n minimum nb of iter = %d for m = %d \n',minit,vm(I(1)))

% figure

plot(vm,itgr);
hold on
plot(vm,itg,'r-*')
plot(vm,itfr,'g-+')
plot(vm,itf,'m->')
plot(vm,itc,'c-<')
plot(vm,itq,'k-o')
plot(vm,itqi,'k-+')
plot(vm,ittg,'b-d')
plot(vm,itp,'r-p')
plot(vm,itqit,'g-h')
plot(vm,itdr,'m-s')
plot(vm,itdf,'c-v')
plot(vm,itdo,'k-^')
plot(vm,itdoot,'k-*')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF','QOR-III DEF')
title('number of iterations vs m')
hold off

figure

plot(vm,errgr);
hold on
plot(vm,errg,'r-*')
plot(vm,errfr,'g-+')
plot(vm,errf,'m->')
plot(vm,errc,'c-<')
plot(vm,errq,'k-o')
plot(vm,errqi,'k-+')
plot(vm,errtg,'b-d')
plot(vm,errp,'r-p')
plot(vm,errqit,'g-h')
plot(vm,errdr,'m-s')
plot(vm,errdf,'c-v')
plot(vm,errdo,'k-^')
plot(vm,errdoot,'k-*')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF','QOR-III DEF')
title('Final error vs m')
hold off

figure

plot(vm,dpgr);
hold on
plot(vm,dpg,'r-*')
plot(vm,dpfr,'g-+')
plot(vm,dpf,'m->')
plot(vm,dpc,'c-<')
plot(vm,dpq,'k-o')
plot(vm,dpqi,'k-+')
plot(vm,dptg,'b-d')
plot(vm,dpp,'r-p')
plot(vm,dpqit,'g-h')
plot(vm,dpdr,'m-s')
plot(vm,dpdf,'c-v')
plot(vm,dpdo,'k-^')
plot(vm,dpdoot,'k-*')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF','QOR-III DEF')
title('Dot products vs m')
hold off

figure

plot(vm,mvgr);
hold on
plot(vm,mvg,'r-*')
plot(vm,mvfr,'g-+')
plot(vm,mvf,'m->')
plot(vm,mvc,'c-<')
plot(vm,mvq,'k-o')
plot(vm,mvqi,'k-+')
plot(vm,mvtg,'b-d')
plot(vm,mvp,'r-p')
plot(vm,mvqit,'g-h')
plot(vm,mvdr,'m-s')
plot(vm,mvdf,'c-v')
plot(vm,mvdo,'k-^')
plot(vm,mvdoot,'k-*')
legend('GMRESR','GMRES','FOMR','FOM','CMRH','QOR-I','QOR-II','GMREST','QOR pq','QOR-III','GMRES DR','GMRES DEF',...
 'QOR-II DEF','QOR-III DEF')
title('Matrix-vector products vs m')
hold off

% GMRESR

figure
title('GMRESR, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xgr,nitgr,iret,resngr,resngrt,time_matgr]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);
 if rem(mm,2) == 0
  plot(log10(resngrt),'r--')
 else
  plot(log10(resngrt))
 end
end
hold off

% GMRES

figure
title('GMRES, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xg,nitg,iret,resng,resngt,time_matg]=gm_GMRESm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 if rem(mm,2) == 0
  plot(log10(resngt),'r--')
 else
  plot(log10(resngt))
 end
end
hold off

% FOMR

figure
title('FOMR, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xfr,nitfr,iret,resnfr,resnfrt,time_matfr]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);
 if rem(mm,2) == 0
  plot(log10(resnfrt),'r--')
 else
  plot(log10(resnfrt))
 end
end
hold off

% FOM

figure
title('FOM, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xf,nitf,iret,resnf,resnft,time_matf]=gm_FOMm_prec(A,b,x0,epss,nitmax,m,'left','noreorth','noscaling','trueres','noprint',precond,lorth,tb);
 if rem(mm,2) == 0
  plot(log10(resnft),'r--')
 else
  plot(log10(resnft))
 end
end
hold off

% CMRH

figure
title('CMRH, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xc,nitc,iret,resnc,resnct,time_matc]=gm_CMRHm_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resnct),'r--')
 else
  plot(log10(resnct))
 end
end
hold off

% QOR-I

figure
title('QOR-I, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xq,nitq,iret,resnq,resnqt,time_matq]=gm_QORm_opt_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resnqt),'r--')
 else
  plot(log10(resnqt))
 end
end
hold off

% QOR-II

figure
title('QOR-II, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xqi,nitqi,iret,resnqi,resnqit,time_matqi]=gm_QORm_optinv_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resnqit),'r--')
 else
  plot(log10(resnqit))
 end
end
hold off

% Truncated GMRES

figure
title('Truncated GMRES, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xtg,nittg,iret,resntg,resntgt,time_mattg]=gm_GMRES_trunc_prec(A,b,x0,epss,nitmax,m,'left','reorth','noscaling','trueres','noprint',precond,lorth,tb);

 if rem(mm,2) == 0
  plot(log10(resntgt),'r--')
 else
  plot(log10(resntgt))
 end
end
hold off

% QOR pq

figure
title('QOR pq, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xp,nitp,iret,resnp,resnpt,time_matp]=gm_QORm_opt_partial_prec(A,b,x0,epss,nitmax,m,pp,qq,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resnpt),'r--')
 else
  plot(log10(resnpt))
 end
end
hold off

% QOR-III

figure
title('QOR-III, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xqit,nitqit,iret,resnqit,resnqitt,time_matqit]=gm_QORm_optinv_T_prec(A,b,x0,epss,nitmax,m,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resnqitt),'r--')
 else
  plot(log10(resnqitt))
 end
end
hold off

% GMRES DR

figure
title('GMRES DR, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xdr,nitdr,iret,resndr,resndrt,time_matdr]=gm_GMRESm_DR_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resndrt),'r--')
 else
  plot(log10(resndrt))
 end
end
hold off

% GMRES DEF

figure
title('GMRES DEF, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xdf,nitdf,iret,resndf,resndft,time_matdf]=gm_GMRESm_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noreorth','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resndft),'r--')
 else
  plot(log10(resndft))
 end
end
hold off

% QOR-II DEF

figure
title('QOR-II DEF, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xdo,nitdo,iret,resndo,resndot,time_matdo]=gm_QORm_optinv_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resndot),'r--')
 else
  plot(log10(resndot))
 end
end
hold off

% QOR-III DEF

figure
title('QOR-III DEF, true residual norms')
hold on
mm = 0;
for m = mmin:dm:mmax
 mm = mm + 1;
 [xdoot,nitdoot,iret,resndoot,resndoott,time_matdot]=gm_QORm_optinv_T_DEF_prec(A,b,x0,epss,nitmax,m+kh*i,'left','noscaling','trueres','noprint',precond,tb);
 if rem(mm,2) == 0
  plot(log10(resndoott),'r--')
 else
  plot(log10(resndoott))
 end
end
hold off

warning on



