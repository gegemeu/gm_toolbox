
% gm_Ex_time

% Examples with time measurements
% Non symmetric matrices

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

toep_ns = 'toep_ns';

block_d = 'block_d';

rand_f = 'rand_f';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

tsopf = 'gm_TSOPF_14538';

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose the file

Ex = fs_680_1c;
mat = 'fs 680 1c';

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-20;
% Preconditioner
% ------Caution, preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Restarting parameter, GMRES(m),...
m = 7000;
% Maximum number of iterations
nitmax = 150;

% The following parameters may not be well adapted for all preconditioners
if strcmpi(precond,'ld') == 1
 params = struct('p1',0.01);
elseif strcmpi(precond,'sp') == 1
 params = struct('p1',0.01,'p2',20);
elseif strcmpi(precond,'ai') == 1
 params = struct('p1',0.01,'p2',20);
else
 params = [];
end % if

met = zeros(17,11);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d, m = %d \n',precond,epss,nitmax,m)


% Full GMRES with reorthogonalization

met(1,1:6) = 'GMRESR';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngr = results.resn;

tic
for k = 1:repeat
 [xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

tgr = toc;
tgr = tgr / repeat;
errgr = norm(xgr - xec);

fprintf('\n Meth          It      Res            Err           Time   \n\n')
fprintf(' GMRES R       %4d  %11.4e   %11.4e   %11.4e \n\n',nitgr,resngr(length(resngr)),errgr,tgr)


% Full GMRES without reorthogonalization

met(2,1:5) = 'GMRES';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resng = results.resn;

tic
for k = 1:repeat
 [xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

tg = toc;
tg = tg / repeat;
errg = norm(xg - xec);

fprintf(' GMRES         %4d  %11.4e   %11.4e   %11.4e \n\n',nitg,resng(length(resng)),errg,tg)


% Full FOM with reorthogonalization

met(3,1:4) = 'FOMR';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnfr = results.resn;

tic
for k = 1:repeat
 [xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
end

tfr = toc;
tfr = tfr / repeat;
errfr = norm(xfr - xec);

fprintf(' FOM R         %4d  %11.4e   %11.4e   %11.4e \n\n',nitfr,resnfr(length(resnfr)),errfr,tfr)


% Full FOM without reorthogonalization

met(4,1:3) = 'FOM';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnf = results.resn;

tic
for k = 1:repeat
 [xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
end

tf = toc;
tf = tf / repeat;
errf = norm(xf - xec);

fprintf(' FOM           %4d  %11.4e   %11.4e   %11.4e \n\n',nitf,resnf(length(resnf)),errf,tf)

% CMRH

met(5,1:4) = 'CMRH';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
resnc = results.resn;

tic
for k = 1:repeat
 [xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
end

tc = toc;
tc = tc / repeat;
errc = norm(xc - xec);

fprintf(' CMRH          %4d  %11.4e   %11.4e   %11.4e \n\n',nitc,resnc(length(resnc)),errc,tc)

% CGS

met(6,1:3) = 'CGS';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xcg,nitcg,iret,results] = gm_CGS_prec(A,b,x0,options,params);
resncg = results.resn;

tic
for k = 1:repeat
 [xcg,nitcg,iret,results] = gm_CGS_prec(A,b,x0,options,params);
end

tcg = toc;
tcg = tcg / repeat;
errcg = norm(xcg - xec);

fprintf(' CGS           %4d  %11.4e   %11.4e   %11.4e \n\n',nitcg,resncg(length(resncg)),errcg,tcg)

% BiCGStab

met(7,1:8) = 'BiCGStab';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xb,nitb,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
resnb = results.resn;

tic
for k = 1:repeat
 [xb,nitb,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
end

tbb = toc;
tbb = tbb / repeat;
errb = norm(xb - xec);

fprintf(' BICGSTAB      %4d  %11.4e   %11.4e   %11.4e \n\n',nitb,resnb(length(resnb)),errb,tbb)


% BiCGStab2

met(8,1:9) = 'BiCGStab2';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xb2,nitb2,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
resnb2 = results.resn;

tic
for k = 1:repeat
 [xb2,nitb2,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
end

tb2 = toc;
tb2 = tb2 / repeat;
errb2 = norm(xb2 - xec);

fprintf(' BICGSTAB2     %4d  %11.4e   %11.4e   %11.4e \n\n',nitb2,resnb2(length(resnb2)),errb2,tb2)


% BiCGStab(3)

met(9,1:11) = 'BiCGStab(3)';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',3);
[xb3,nitb3,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnb3 = results.resn;

tic
for k = 1:repeat
 [xb3,nitb3,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
end

tb3 = toc;
tb3 = tb3 / repeat;
errb3 = norm(xb3 - xec);

fprintf(' BICGSTAB3     %4d  %11.4e   %11.4e   %11.4e \n\n',nitb3,resnb3(length(resnb3)),errb3,tb3)


% BiCGStab(4)

met(10,1:11) = 'BiCGStab(4)';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',4);
[xb4,nitb4,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnb4 = results.resn;

tic
for k = 1:repeat
 [xb4,nitb4,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
end

tb4 = toc;
tb4 = tb4 / repeat;
errb4 = norm(xb4 - xec);

fprintf(' BICGSTAB4     %4d  %11.4e   %11.4e   %11.4e \n\n',nitb4,resnb4(length(resnb4)),errb4,tb4)


% IDR(2)

met(11,1:6) = 'IDR(2)';

options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',0,'var',0.7);
[xs2,nits2,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns2 = results.resn;

tic
for k = 1:repeat
 [xs2,nits2,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

ts2 = toc;
ts2 = ts2 / repeat;
errs2 = norm(xs2 - xec);

fprintf(' IDR(2)        %4d  %11.4e   %11.4e   %11.4e \n\n',nits2,resns2(length(resns2)),errs2,ts2)


% IDR(3)

met(12,1:6) = 'IDR(3)';

options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',0,'var',0.7);
[xs3,nits3,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns3 = results.resn;

tic
for k = 1:repeat
 [xs3,nits3,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

ts3 = toc;
ts3 = ts3 / repeat;
errs3 = norm(xs3 - xec);

fprintf(' IDR(3)        %4d  %11.4e   %11.4e   %11.4e \n\n',nits3,resns3(length(resns3)),errs3,ts3)


% IDR(4)

met(13,1:6) = 'IDR(4)';

options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',0,'var',0.7);
[xs4,nits4,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns4 = results.resn;

tic
for k = 1:repeat
 [xs4,nits4,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
end

ts4 = toc;
ts4 = ts4 / repeat;
errs4 = norm(xs4 - xec);

fprintf(' IDR(4)        %4d  %11.4e   %11.4e   %11.4e \n\n',nits4,resns4(length(resns4)),errs4,ts4)


% QOR optimal

met(14,1:5) = 'QOR-I';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
resnq = results.resn;

tic
for k = 1:repeat
 [xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
end

tq = toc;
tq = tq / repeat;
errq = norm(xq - xec);

fprintf(' QOR-I         %4d  %11.4e   %11.4e   %11.4e \n\n',nitq,resnq(length(resnq)),errq,tq)

% QOR optimal using the inverses of Cholesky factors

met(15,1:6) = 'QOR-II';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xqq,nitqq,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
resnqq = results.resn;

tic
for k = 1:repeat
 [xqq,nitqq,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
end

tqq = toc;
tqq = tqq / repeat;
errqq = norm(xqq - xec);

fprintf(' QOR-II        %4d  %11.4e   %11.4e   %11.4e \n\n',nitqq,resnqq(length(resnq)),errqq,tqq)

% TFQMR

met(16,1:5) = 'TFQMR';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0);
[xt,nitt,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
resnt = results.resn;

tic
for k = 1:repeat
 [xt,nitt,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
end

tt = toc;
tt = tt / repeat;
errt = norm(xt - xec);

fprintf(' TFQMR         %4d  %11.4e   %11.4e   %11.4e \n\n',nitt,resnt(length(resnt)),errt,tt)

% QOR optimal truncated

met(17,1:6) = 'QOR-pq';

pp = 30;
qq = pp;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[pp, qq]);
[xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
resnp = results.resn;

tic
for k = 1:repeat
 [xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
end

tp = toc;
tp = tp / repeat;
errp = norm(xp - xec);

fprintf(' QOR-pq        %4d  %11.4e   %11.4e   %11.4e \n\n',nitp,resnp(length(resnp)),errp,tp)

% figures

% compute the true residual norms for the plot

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngrt = results.resnt;
time_matgr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngt = results.resnt;
time_matg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
[xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnfrt = results.resnt;
time_matfr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
resnft = results.resnt;
time_matf = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
resnct = results.resnt;
time_matc = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xcg,nitcg,iret,results] = gm_CGS_prec(A,b,x0,options,params);
resncgt = results.resnt;
time_matcg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xb,nitb,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
resnbt = results.resnt;
time_matb = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xb2,nitb2,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
resnb2t = results.resnt;
time_matb2 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[3, 0.7]);
[xb3,nitb3,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnb3t = results.resnt;
time_matb3 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[4, 0.7]);
[xb4,nitb4,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
resnb4t = results.resnt;
time_matb4 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',1,'var',0.7);
[xs2,nits2,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns2t = results.resnt;
time_mats2 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',1,'var',0.7);
[xs3,nits3,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns3t = results.resnt;
time_mats3 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',1,'var',0.7);
[xs4,nits4,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
resns4t = results.resnt;
time_mats4 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
resnqt = results.resnt;
time_matq = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xqq,nitqq,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
resnqqt = results.resnt;
time_matqq = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xt,nitt,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
resntt = results.resnt;
time_matt = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',[30, 30]);
[xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
resnpt = results.resnt;
resnpt = resnpt(1:nitp);
time_matp = results.timing;


semilogy(time_matgr.matvec,resngrt)
hold on
semilogy(time_matg.matvec,resngt,'b-x')
semilogy(time_matfr.matvec,resnfrt,'r-o')
semilogy(time_matf.matvec,resnft,'r-+')
semilogy(time_matc.matvec,resnct,'g-d')
semilogy(time_matcg.matvec,resncgt,'m-s')
semilogy(time_matb.matvec,resnbt,'c-d')
semilogy(time_matb2.matvec,resnb2t,'k-v')
semilogy(time_matb3.matvec,resnb3t,'b-^')
semilogy(time_matb4.matvec,resnb4t,'r->')
semilogy(time_mats2.matvec,resns2t,'g-p')
semilogy(time_mats3.matvec,resns3t,'m-h')
semilogy(time_mats4.matvec,resns4t,'c-*')
semilogy(time_matq.matvec,resnqt,'k--o')
semilogy(time_matqq.matvec,resnqqt,'k--*')
semilogy(time_matt.matvec,resntt,'r--*')
semilogy(time_matp.matvec,resnpt,'m-*')

% legend('GMRES R','GMRES','FOM R','FOM','CMRH','CGS','BiCGStab','BiCGStab2','BiCGStab(3)', ...
%  'BiCGStab(4)','IDR(2)','IDR(3)','IDR(4)','QOR-I','QOR-II','TFQMR','QOR pq')

legend('GMRES R','GMRES','FOM R','FOM','CMRH','CGS','BiCGStab','BiCGStab2','BiCGStab(3)', ...
 'BiCGStab(4)','IDR(2)','IDR(3)','IDR(4)','QOR-I','QOR-II','TFQMR')

title([mat ', precond = ' precond ', residual norms vs matrix-vector products'])

hold off

figure

semilogy(resngrt)
hold on
semilogy(resngt,'b-x')
semilogy(resnfrt,'r-o')
semilogy(resnft,'r-+')
semilogy(resnct,'g-d')
semilogy(resncgt,'m-s')
semilogy(resnbt,'c-d')
semilogy(resnb2t,'k-v')
semilogy(resnb3t,'b-^')
semilogy(resnb4t,'r->')
semilogy(resns2t,'g-p')
semilogy(resns3t,'m-h')
semilogy(resns4t,'c-*')
semilogy(resnqt,'k--o')
semilogy(resnqqt,'k--*')
semilogy(resntt,'r--*')
semilogy(resnpt,'m-*')

% legend('GMRES R','GMRES','FOM R','FOM','CMRH','CGS','BiCGStab','BiCGStab2','BiCGStab(3)', ...
%  'BiCGStab(4)','IDR(2)','IDR(3)','IDR(4)','QOR-I','QOR-II','TFQMR','QOR pq')

legend('GMRES R','GMRES','FOM R','FOM','CMRH','CGS','BiCGStab','BiCGStab2','BiCGStab(3)', ...
 'BiCGStab(4)','IDR(2)','IDR(3)','IDR(4)','QOR-I','QOR-II','TFQMR')

title([mat ', precond = ' precond ', residual norms vs iterations'])

hold off

% time measurement

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_matgr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_matg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xfr,nitfr,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
time_matfr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xf,nitf,iret,results] = gm_FOMm_prec(A,b,x0,options,params);
time_matf = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xc,nitc,iret,results] = gm_CMRHm_prec(A,b,x0,options,params);
time_matc = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xcg,nitcg,iret,results] = gm_CGS_prec(A,b,x0,options,params);
time_matcg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xb,nitb,iret,results] = gm_BiCGStab_prec(A,b,x0,options,params);
time_matb = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xb2,nitb2,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
time_matb2 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[3, 0.7],'timing',1);
[xb3,nitb3,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
time_matb3 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[4, 0.7],'timing',1);
[xb4,nitb4,iret,results] = gm_BiCGStabl_prec(A,b,x0,options,params);
time_matb4 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',2,'precond',precond,'l2norm',0,'trueres',1,'var',0.7,'timing',1);
[xs2,nits2,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mats2 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',3,'precond',precond,'l2norm',0,'trueres',0,'var',0.7,'timing',1);
[xs3,nits3,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mats3 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',4,'precond',precond,'l2norm',0,'trueres',0,'var',0.7,'timing',1);
[xs4,nits4,iret,results] = gm_IDRs_prec(A,b,x0,options,params);
time_mats4 = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xq,nitq,iret,results] = gm_QORm_opt_prec(A,b,x0,options,params);
time_matq = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xqq,nitqq,iret,results] = gm_QORm_optinv_prec(A,b,x0,options,params);
time_matqq = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xt,nitt,iret,results] = gm_TFQMR_prec(A,b,x0,options,params);
time_matt = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',[30, 30],'timing',1);
[xp,nitp,iret,results] = gm_QORm_opt_partial_prec(A,b,x0,options,params);
time_matp = results.timing;


fprintf(' GMRES R,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitgr,time_matgr.init_time,time_matgr.iter_time,time_matgr.init_time+time_matgr.iter_time,resngrt(end),time_matgr.ndotp,time_matgr.matvec(end))
fprintf(' GMRES,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitg,time_matg.init_time,time_matg.iter_time,time_matg.init_time+time_matg.iter_time,resngt(end),time_matg.ndotp,time_matg.matvec(end))
fprintf(' FOM R,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitfr,time_matfr.init_time,time_matfr.iter_time,time_matfr.init_time+time_matfr.iter_time,resnfrt(end),time_matfr.ndotp,time_matfr.matvec(end))
fprintf(' FOM,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitf,time_matf.init_time,time_matf.iter_time,time_matf.init_time+time_matf.iter_time,resnft(end),time_matf.ndotp,time_matf.matvec(end))
fprintf(' CMRH,        it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitc,time_matc.init_time,time_matc.iter_time,time_matc.init_time+time_matc.iter_time,resnct(end),time_matc.ndotp,time_matc.matvec(end))
fprintf(' CGS,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitcg,time_matcg.init_time,time_matcg.iter_time,time_matcg.init_time+time_matcg.iter_time,resncgt(end),time_matcg.ndotp,time_matcg.matvec(end))
fprintf(' BiCGStab,    it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitb,time_matb.init_time,time_matb.iter_time,time_matb.init_time+time_matb.iter_time,resnbt(end),time_matb.ndotp,time_matb.matvec(end))
fprintf(' BiCGStab2,   it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitb2,time_matb2.init_time,time_matb2.iter_time,time_matb2.init_time+time_matb2.iter_time,resnb2t(end),time_matb2.ndotp,time_matb2.matvec(end))
fprintf(' BiCGStab(3), it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitb3,time_matb3.init_time,time_matb3.iter_time,time_matb3.init_time+time_matb3.iter_time,resnb3t(end),time_matb3.ndotp,time_matb3.matvec(end))
fprintf(' BiCGStab(4), it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitb4,time_matb4.init_time,time_matb4.iter_time,time_matb4.init_time+time_matb4.iter_time,resnb4t(end),time_matb4.ndotp,time_matb4.matvec(end))
fprintf(' IDR(2),      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nits2,time_mats2.init_time,time_mats2.iter_time,time_mats2.init_time+time_mats2.iter_time,resns2t(end),time_mats2.ndotp,time_mats2.matvec(end))
fprintf(' IDR(3),      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nits3,time_mats3.init_time,time_mats3.iter_time,time_mats3.init_time+time_mats3.iter_time,resns3t(end),time_mats3.ndotp,time_mats3.matvec(end))
fprintf(' IDR(4),      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nits4,time_mats4.init_time,time_mats4.iter_time,time_mats4.init_time+time_mats4.iter_time,resns4t(end),time_mats4.ndotp,time_mats4.matvec(end))
fprintf(' QOR-I,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitq,time_matq.init_time,time_matq.iter_time,time_matq.init_time+time_matq.iter_time,resnqt(end),time_matq.ndotp,time_matq.matvec(end))
fprintf(' QOR-II,      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitqq,time_matqq.init_time,time_matqq.iter_time,time_matqq.init_time+time_matqq.iter_time,resnqqt(end),time_matqq.ndotp,time_matqq.matvec(end))
fprintf(' TFQMR,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitt,time_matt.init_time,time_matt.iter_time,time_matt.init_time+time_matt.iter_time,resntt(end),time_matt.ndotp,time_matt.matvec(end))
fprintf(' QOR pq,      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitp,time_matp.init_time,time_matp.iter_time,time_matp.init_time+time_matp.iter_time,resnpt(end),time_matp.ndotp,time_matp.matvec(end))

res = zeros(1,17); cpu = zeros(1,17);
res(1) = resngrt(end);  cpu(1) = time_matgr.init_time+time_matgr.iter_time;
res(2) = resngt(end);   cpu(2) = time_matg.init_time+time_matg.iter_time;
res(3) = resnfrt(end);  cpu(3) = time_matfr.init_time+time_matfr.iter_time;
res(4) = resnft(end);   cpu(4) = time_matf.init_time+time_matf.iter_time;
res(5) = resnct(end);   cpu(5) = time_matc.init_time+time_matc.iter_time;
res(6) = resncgt(end);  cpu(6) = time_matcg.init_time+time_matcg.iter_time;
res(7) = resnbt(end);   cpu(7) = time_matb.init_time+time_matb.iter_time;
res(8) = resnb2t(end);  cpu(8) = time_matb2.init_time+time_matb2.iter_time;
res(9) = resnb3t(end);  cpu(9) = time_matb3.init_time+time_matb3.iter_time;
res(10) = resnb4t(end); cpu(10) = time_matb4.init_time+time_matb4.iter_time;
res(11) = resns2t(end); cpu(11) = time_mats2.init_time+time_mats2.iter_time;
res(12) = resns3t(end); cpu(12) = time_mats3.init_time+time_mats3.iter_time;
res(13) = resns4t(end); cpu(13) = time_mats4.init_time+time_mats4.iter_time;
res(14) = resnqt(end);  cpu(14) = time_matq.init_time+time_matq.iter_time;
res(15) = resnqqt(end); cpu(15) = time_matqq.init_time+time_matqq.iter_time;
res(16) = resntt(end);  cpu(16) = time_matt.init_time+time_matt.iter_time;
res(17) = resnpt(end);  cpu(17) = time_matp.init_time+time_matp.iter_time;
[minr,I] = min(res);
fprintf('\n minimum true residual norm = %11.4e for %s \n',minr,met(I(1),:))
[maxr,I] = max(res);
fprintf('\n maximum true residual norm = %11.4e for %s \n',maxr,met(I(1),:))

[mint,I] = min(cpu);
fprintf('\n minimum total time = %11.4e for %s, true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum total time = %11.4e for %s, true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))

cpu(1) = time_matgr.iter_time;
cpu(2) = time_matg.iter_time;
cpu(3) = time_matfr.iter_time;
cpu(4) = time_matf.iter_time;
cpu(5) = time_matc.iter_time;
cpu(6) = time_matcg.iter_time;
cpu(7) = time_matb.iter_time;
cpu(8) = time_matb2.iter_time;
cpu(9) = time_matb3.iter_time;
cpu(10) = time_matb4.iter_time;
cpu(11) = time_mats2.iter_time;
cpu(12) = time_mats3.iter_time;
cpu(13) = time_mats4.iter_time;
cpu(14) = time_matq.iter_time;
cpu(15) = time_matqq.iter_time;
cpu(16) = time_matt.iter_time;
cpu(17) = time_matp.iter_time;

[mint,I] = min(cpu);
fprintf('\n minimum iter time = %11.4e for %s, true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum iter time = %11.4e for %s, true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))
