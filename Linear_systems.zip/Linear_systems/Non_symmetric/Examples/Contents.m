% EXAMPLES
%
% Files
%   gm_Ex_err_est           - 
%   gm_Ex_GMRES_Newton      - 
%   gm_Ex_GMRESHB           - 
%   gm_Ex_restart           - 
%   gm_Ex_restart_TeX       - 
%   gm_Ex_restart_TeX_light - 
%   gm_Ex_time              - 
%   gm_Ex_time_2            - 
%   gm_Ex_time_F            - 
%   gm_Ex_time_QOR          - 
%   gm_Ex_time_TeX          - 
%   gm_Ex_time_TeX_light    - 
%   gm_Ex_time_TeX_QOR      - 
%   gm_init_fs_680_1c       - init script for testing
