% EXAMPLES
%
% Krylov methods for nonsymmetric matrices
%
% Files
%   gm_Ex_err_est           - Examples with the error estimates
%   gm_Ex_GMRES_Newton      - Examples with GMRESm_and Newton bases
%   gm_Ex_GMRESHB           - Examples with GMRES HB (Heavy Ball restart)
%   gm_Ex_restart           - Examples with different restart parameters
%   gm_Ex_restart_TeX       - Examples with different restart parameters, produces rows to be directly put in a LaTeX table
%   gm_Ex_restart_TeX_light - 
%   gm_Ex_time              - Examples with time measurements
%   gm_Ex_time_2            - Examples with time measurements (other methods)
%   gm_Ex_time_F            - Comparison of GMRES and the QOR variants
%   gm_Ex_time_QOR          - Examples with time measurements for QOR variants
%   gm_Ex_time_TeX          - Examples with time measurements, produces rows to be directly put in a LaTeX table
%   gm_Ex_time_TeX_light    - 
%   gm_Ex_time_TeX_QOR      - Examples with QOR variants, produces rows to be directly put in a LaTeX table

