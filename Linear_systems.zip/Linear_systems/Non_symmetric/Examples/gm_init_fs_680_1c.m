
% init script for testing

load gm_fs_680_1c
epsi = 1e-20;
nitmax = 150;
m = 1000;
lefts = 'left';
reorths = 'noreorth';
scalings = 'noscaling';
iprints = 'print';
precond = 'no';
trueress = 'trueres';
lorth = 0.1;