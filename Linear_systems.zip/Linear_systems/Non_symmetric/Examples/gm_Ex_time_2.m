
% gm_Ex_time_2

% Examples with time measurements II
% Another set of methods
% Non symmetric matrices

% SUPG

Supg1 = 'gm_supg001_225';
Supg2a = 'gm_supg01_1600';
Supg2b = 'gm_supg005_1600';
Supg2c = 'gm_supg001_1600';
Supg2d = 'gm_supg0001_1600';
Supg2e = 'gm_supg00001_1600';

% Pb26ns
Pb26ns0 = 'gm_Pb26ns18-01-0_1600';
Pb26ns1 = 'gm_Pb26ns18-01-1_1600';
Pb26ns2 = 'gm_Pb26ns18-01-10_1600';
Pb26ns3 = 'gm_Pb26ns18-01-100_1600';
Pb26ns4 = 'gm_Pb26ns18-01-1000_1600';
Pb26ns5 = 'gm_Pb26ns18-008-0_1600';
Pb26ns6 = 'gm_Pb26ns18-008-1_1600';
Pb26ns7 = 'gm_Pb26ns18-008-10_1600';
Pb26ns8 = 'gm_Pb26ns18-008-100_1600';
Pb26ns9 = 'gm_Pb26ns18-008-1000_1600';

% Convection_diffusion problem, mesh 30 x 30
ansd5 = 'gm_ansd5_900';

% Matrix Market or Tim Davis' problems

bcsstk14 = 'gm_bcsstk14_1806';

bcsstk20 = 'gm_bcsstk20_485';

% there are zeros on the diagonal of this matrix
cavity05 = 'gm_cavity05_1182';

% there are zeros on the diagonal of this matrix
cavity10 = 'gm_cavity10_2597';

comsol = 'gm_comsol_1500';

% there are zeros on the diagonal of this matrix
e05r0500 = 'gm_e05r0500_236';

% there are zeros on the diagonal of this matrix
erdos = 'gm_Erdos971_472';

% there are zeros on the diagonal of this matrix
fpga_trans_02 = 'gm_fpga_trans_02_1220';

fs_3 = 'gm_fs_3_760';

fs_4 = 'gm_fs_4_541';

fs_6 = 'gm_fs_6_183';

fs_680_1c = 'gm_fs_680_1c';

% there are zeros on the diagonal of this matrix
gre = 'gm_gre_512';

jagmesh = 'gm_jagmesh9_1349';

jpwh = 'gm_jpwh_991';

% there are zeros on the diagonal of this matrix
lnsp = 'gm_lnsp_511';

mcfe = 'gm_mcfe_765';

% there are zeros on the diagonal of this matrix
nnc = 'gm_nnc_261';

orsirr = 'gm_orsirr2_886';

pde225 = 'gm_pde225_225';

raefsky1 = 'gm_raefsky1_3242';

raefsky2 = 'gm_raefsky2_3242';

sherman1 = 'gm_sherman1_1000';

steam1 = 'gm_steam1_240';

steam2 = 'gm_steam2_600';

% there are zeros on the diagonal of this matrix
str_600 = 'gm_str_600_363';

tomography = 'gm_tomography_500';

trefethen = 'gm_Trefethen_500';

watt1 = 'gm_watt1_1856';

% there are zeros on the diagonal of this matrix
west0 = 'gm_west0_167';

bus1138 = 'gm_1138bus_1138';

gre1107 = 'gm_gre_1107';

toep_ns = 'toep_ns';

block_d = 'block_d';

rand_f = 'rand_f';

ansd = 'gm_ansd_22500'; % iex=16, iexc=5

ansd2 = 'gm_ansd_10000'; % iex=16, iexc=5

nrta = 'gm_NRTa_1000';

fv2 = 'gm_fv2';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose the file

Ex = fs_680_1c;
mat = 'fs 680 1c';

if strcmpi(Ex,'toep_ns') == 1
 nn = 1000;
 A = gm_Ex_nonsym(nn);
%  xe = ones(nn,1);
%  b = A * xe;
 b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'block_d') == 1
 nn = 200;
 A = gm_Ex_nonsym_2(nn);
 xe = ones(nn,1);
 b = A * xe;
 %  b = randn(nn,1);
 x0 = zeros(nn,1);
 
elseif strcmpi(Ex,'rand_f') == 1
 nn = 200;
 A = gm_rand_dd(nn);
 xe = ones(nn,1);
%  b = A * xe;
  b = randn(nn,1);
 x0 = zeros(nn,1);
 
else

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

end

n = size(A,1);
nnzA = nnz(A);

% Repeat parameter for time measurements
repeat = 10;
if n > 1000
 repeat = 5;
end
if n > 10000
 repeat = 2;
end

xec = A \ b;

% Stopping threshold
epss = 1e-12;
% Preconditioner
% ------Caution, preconditioners must not be used with matrices having zeros on
% the diagonal!
precond = 'no';
% Restarting parameter, GMRES(m),...
m = 7000;
% Maximum number of iterations
nitmax = 150;

% The following parameters may not be well adapted for all preconditioners
if strcmpi(precond,'ld') == 1
 params = struct('p1',0.01);
elseif strcmpi(precond,'sp') == 1
 params = struct('p1',0.01,'p2',20);
elseif strcmpi(precond,'ai') == 1
 params = struct('p1',0.01,'p2',20);
else
 params = [];
end % if

met = zeros(17,11);

fprintf(['\n ' Ex ' \n'])

fprintf('\n Order of A = %5d, number of non zeros = %6d, norm of b = %11.4e \n',n,nnzA,norm(b))

fprintf('\n x0 = zero, precond = %s, epsilon = %11.4e, it max = %d, m = %d \n',precond,epss,nitmax,m)


% Full GMRES with reorthogonalization

met(1,1:6) = 'GMRESR';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngr = results.resn;

tic
for k = 1:repeat
 [xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

tgr = toc;
tgr = tgr / repeat;
errgr = norm(xgr - xec);

fprintf('\n Meth          It      Res            Err           Time   \n\n')
fprintf(' GMRES R       %4d  %11.4e   %11.4e   %11.4e \n\n',nitgr,resngr(length(resngr)),errgr,tgr)


% Full GMRES without reorthogonalization

met(2,1:5) = 'GMRES';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resng = results.resn;

tic
for k = 1:repeat
 [xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
end

tg = toc;
tg = tg / repeat;
errg = norm(xg - xec);

fprintf(' GMRES         %4d  %11.4e   %11.4e   %11.4e \n\n',nitg,resng(length(resng)),errg,tg)


% Adaptive simpler GMRES, delta = 0.9

met(3,1:7) = 'ASGMRES';
delta = 0.9;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xfr,nitfr,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
resnfr = results.resn;

tic
for k = 1:repeat
 [xfr,nitfr,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
end

tfr = toc;
tfr = tfr / repeat;
errfr = norm(xfr - xec);

fprintf(' ASGMRES       %4d  %11.4e   %11.4e   %11.4e \n\n',nitfr,resnfr(length(resnfr)),errfr,tfr)


% GCR

met(4,1:3) = 'GCR';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xf,nitf,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
resnf = results.resn;

tic
for k = 1:repeat
 [xf,nitf,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
end

tf = toc;
tf = tf / repeat;
errf = norm(xf - xec);

fprintf(' GCR           %4d  %11.4e   %11.4e   %11.4e \n\n',nitf,resnf(length(resnf)),errf,tf)


% GCRO

met(5,1:4) = 'GCRO';
itint = 2;

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'var',itint);
[xc,nitc,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
resnc = results.resn;

tic
for k = 1:repeat
 [xc,nitc,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
end

tc = toc;
tc = tc / repeat;
errc = norm(xc - xec);

fprintf(' GCRO          %4d  %11.4e   %11.4e   %11.4e \n\n',nitc,resnc(length(resnc)),errc,tc)


% QOR-III tridiagonal

met(6,1:7) = 'QOR-III';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xcg,nitcg,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
resncg = results.resn;

tic
for k = 1:repeat
 [xcg,nitcg,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
end

tcg = toc;
tcg = tcg / repeat;
errcg = norm(xcg - xec);

fprintf(' QOR-III       %4d  %11.4e   %11.4e   %11.4e \n\n',nitcg,resncg(length(resncg)),errcg,tcg)


% QOR-II + RCD

met(7,1:6) = 'QORRCD';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xr,nitr,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
resnr = results.resn;

tic
for k = 1:repeat
 [xr,nitr,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
end

tr = toc;
tr = tr / repeat;
errr = norm(xr - xec);

fprintf(' QORRCD        %4d  %11.4e   %11.4e   %11.4e \n\n',nitcg,resncg(length(resncg)),errcg,tcg)


% LCD

met(8,1:3) = 'LCD';

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0);
[xd,nitd,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
resnd = results.resn;

tic
for k = 1:repeat
 [xd,nitd,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
end

td = toc;
td = td / repeat;
errd = norm(xd - xec);

fprintf(' LCD           %4d  %11.4e   %11.4e   %11.4e \n\n',nitd,resnd(length(resnd)),errd,td)

% figures

% compute the true residual norms for the plot

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',1);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngrt = results.resnt;
time_matgr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',1);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
resngt = results.resnt;
time_matg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xfr,nitfr,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
resnfrt = results.resnt;
time_matfr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xf,nitf,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
resnft = results.resnt;
time_matf = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1,'var',itint);
[xc,nitc,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
resnct = results.resnt;
time_matc = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xcg,nitcg,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
resncgt = results.resnt;
time_matcg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xr,nitr,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
resnrt = results.resnt;
time_matr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',1);
[xd,nitd,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
resndt = results.resnt;
time_matd = results.timing;


nr = min(length(time_matgr.matvec),length(resngrt));
ng = min(length(time_matg.matvec),length(resngt));
nfr = min(length(time_matfr.matvec),length(resnfrt));
nf = min(length(time_matf.matvec),length(resnft));
nc = min(length(time_matc.matvec),length(resnct));
ncg = min(length(time_matcg.matvec),length(resncgt));
nrr = min(length(time_matr.matvec),length(resnrt));
nd = min(length(time_matd.matvec),length(resndt));

semilogy(time_matgr.matvec(1:nr),resngrt(1:nr))
hold on
semilogy(time_matg.matvec(1:ng),resngt(1:ng),'b-x')
semilogy(time_matfr.matvec(1:nfr),resnfrt(1:nfr),'r-o')
semilogy(time_matf.matvec(1:nf),resnft(1:nf),'r-+')
semilogy(time_matc.matvec(1:nc),resnct(1:nc),'g-d')
semilogy(time_matcg.matvec(1:ncg),resncgt(1:ncg),'m-s')
semilogy(time_matr.matvec(1:nrr),resnrt(1:nrr),'c-d')
semilogy(time_matd.matvec(1:nd),resndt(1:nd),'k->')

legend('GMRES R','GMRES','ASGMRES','GCR','GCRO','QOR-III','QORRCD','LCD')

title([mat ', precond = ' precond ', residual norms vs matrix-vector products'])

hold off

figure

semilogy(resngrt)
hold on
semilogy(resngt,'b-x')
semilogy(resnfrt,'r-o')
semilogy(resnft,'r-+')
semilogy(resnct,'g-d')
semilogy(resncgt,'m-s')
semilogy(resnrt,'c-d')
semilogy(resndt,'k->')

legend('GMRES R','GMRES','ASGMRES','GCR','GCRO','QOR-III','QORRCD','LCD')

title([mat ', precond = ' precond ', residual norms vs iterations'])

hold off

% time measurement

options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',1,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xgr,nitgr,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_matgr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'reorth',0,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xg,nitg,iret,results] = gm_GMRESm_prec(A,b,x0,options,params);
time_matg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xfr,nitfr,iret,results] = gm_ASGMRESm_prec(A,b,x0,options,params);
time_matfr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xf,nitf,iret,results] = gm_GCRm_prec(A,b,x0,options,params);
time_matf = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'var',itint,'timing',1);
[xc,nitc,iret,results] = gm_GCROm_prec(A,b,x0,options,params);
time_matc = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xcg,nitcg,iret,results] = gm_QORm_optinv_T_prec(A,b,x0,options,params);
time_matcg = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xr,nitr,iret,results] = gm_QORm_optinv_RCD_prec(A,b,x0,options,params);
time_matr = results.timing;
options = struct('epsi',epss,'nitmax',nitmax,'m',m,'precond',precond,'l2norm',0,'trueres',0,'timing',1);
[xd,nitd,iret,results] = gm_LCDm_prec(A,b,x0,options,params);
time_matd = results.timing;

fprintf(' GMRES R,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitgr,time_matgr.init_time,time_matgr.iter_time,time_matgr.init_time+time_matgr.iter_time,resngrt(end),time_matgr.ndotp,time_matgr.matvec(end))
fprintf(' GMRES,       it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitg,time_matg.init_time,time_matg.iter_time,time_matg.init_time+time_matg.iter_time,resngt(end),time_matg.ndotp,time_matg.matvec(end))
fprintf(' ASGMRES,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitfr,time_matfr.init_time,time_matfr.iter_time,time_matfr.init_time+time_matfr.iter_time,resnfrt(end),time_matfr.ndotp,time_matfr.matvec(end))
fprintf(' GCR,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitf,time_matf.init_time,time_matf.iter_time,time_matf.init_time+time_matf.iter_time,resnft(end),time_matf.ndotp,time_matf.matvec(end))
fprintf(' GCRO,        it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitc,time_matc.init_time,time_matc.iter_time,time_matc.init_time+time_matc.iter_time,resnct(end),time_matc.ndotp,time_matc.matvec(end))
fprintf(' QOR-III,     it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitcg,time_matcg.init_time,time_matcg.iter_time,time_matcg.init_time+time_matcg.iter_time,resncgt(end),time_matcg.ndotp,time_matcg.matvec(end))
fprintf(' QORRCD,      it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitr,time_matr.init_time,time_matr.iter_time,time_matr.init_time+time_matr.iter_time,resnrt(end),time_matr.ndotp,time_matr.matvec(end))
fprintf(' LCD,         it = %4d, t init = %10.3e, t iter = %10.3e, total = %10.3e, trueres = %11.4e, dotprod = %d, matvec = %d \n',...
 nitd,time_matd.init_time,time_matd.iter_time,time_matd.init_time+time_matd.iter_time,resndt(end),time_matd.ndotp,time_matd.matvec(end))

res = zeros(1,8); cpu = zeros(1,8);
res(1) = resngrt(end);  cpu(1) = time_matgr.init_time+time_matgr.iter_time;
res(2) = resngt(end);   cpu(2) = time_matg.init_time+time_matg.iter_time;
res(3) = resnfrt(end);  cpu(3) = time_matfr.init_time+time_matfr.iter_time;
res(4) = resnft(end);   cpu(4) = time_matf.init_time+time_matf.iter_time;
res(5) = resnct(end);   cpu(5) = time_matc.init_time+time_matc.iter_time;
res(6) = resncgt(end);  cpu(6) = time_matcg.init_time+time_matcg.iter_time;
res(7) = resnrt(end);   cpu(7) = time_matr.init_time+time_matr.iter_time;
res(8) = resndt(end);   cpu(8) = time_matd.init_time+time_matd.iter_time;

[minr,I] = min(res);
fprintf('\n minimum true residual norm = %11.4e for %s \n',minr,met(I(1),:))
[maxr,I] = max(res);
fprintf('\n maximum true residual norm = %11.4e for %s \n',maxr,met(I(1),:))

[mint,I] = min(cpu);
fprintf('\n minimum total time = %11.4e for %s, true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum total time = %11.4e for %s, true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))

cpu(1) = time_matgr.iter_time;
cpu(2) = time_matg.iter_time;
cpu(3) = time_matfr.iter_time;
cpu(4) = time_matf.iter_time;
cpu(5) = time_matc.iter_time;
cpu(6) = time_matcg.iter_time;
cpu(7) = time_matr.iter_time;
cpu(8) = time_matd.iter_time;

[mint,I] = min(cpu);
fprintf('\n minimum iter time = %11.4e for %s, true residual norm = %11.4e \n',mint,met(I(1),:),res(I(1)))
[maxt,I] = max(cpu);
fprintf('\n maximum iter time = %11.4e for %s, true residual norm = %11.4e \n',maxt,met(I(1),:),res(I(1)))


