function [x,nit,iret,resn,time_mat]=gm_AMG(A,b,x0,epsi,nitmax,scalings,iprints,varargin);
%GM_AMG algebraic MultiGrid for a matrix A as an iterative method
%
% Input:
% b = right-hand side, x0 = initial vector
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% scalings = 'scaling', scales the matrix before preconditioning
% iprints = 'print' print residual norms
%
%  parameters for multigrid in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
%  q = number of entries kept in a column for smoother AINV (default =
%  size(A,1))
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code, 0 if convergence, otherwise 1
% resn = true residual norms

%
% Author G. Meurant
% April 2015
%

% warning off

if nargin < 3
 x0 = zeros(size(A,1),1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = size(A,1);
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
  iprints = 'noprint';
 end
end

n = size(A,1);

if timing == 1
 iprint = 0;
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_AMG_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_AMG_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 6
 % no scaling
 scaling = 0;
end
if nargin < 7
 % no printing
 iprint = 0;
end

if nargin > 5 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 6 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if iprint == 1
 fprintf('\n gm_AMG_prec: \n\n')
 fprintf('  scaling = %d \n',scaling)
 fprintf('  iprint = %g \n',iprint)
end

if nargin >= 8
 % get the input parameters for the multilevel method
 if nargin < 15
  error('gm_AMG_prec_ns: some parameters are not defined for AMG')
 end

 lmax = varargin{1};
 nu = varargin{2};
 alpmax = varargin{3};
 alb = varargin{4};
 smooth = varargin{5};
 infl = varargin{6};
 coarse = varargin{7};
 interpo = varargin{8};
 if nargin > 15
  qmin = varargin{9};
 else
  qmin = n;
 end

else
 % defaults
 lmax = 10;
 nu =1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'lu';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;

end

gam = 1;
falp = 1;
alq = 1;
normal = 0;
if iprint == 1
 fprintf('\n -----------AMG parameters \n')
 fprintf(' lmax = %d \n',lmax)
 fprintf(' nu = %d \n',nu)
 fprintf(' alpmax = %g \n',alpmax)
 fprintf(' alb = %g \n',alb)
 fprintf(' smooth = %s \n',smooth)
 fprintf(' infl = %s \n',infl)
 fprintf(' coarse = %s \n',coarse)
 fprintf(' interpo = %s \n',interpo)
end


x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ------------------------Initialization

xin = zeros(n,1);

 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_AMG_prec: Error in gm_amg_ns_init \n')
  iret = 1;
  return
 end

 x = x0;
 if iprint == 1
  fprintf('\n Initial true residual norm = %12.5e \n\n',norm(b - A * x))
 end


 % residual vector
 r = b - A * x;

 resn = zeros(1,nitmax);
 r0 = r' * r;
 bet = norm(r);
 resn(1) = bet;
 resid = realmax;
 iconv = 0;
 epss = epsi^2;
 ni = 0;
 
 if timing == 1
  tinit = toc;
  fprintf('\n Initialization time = %g \n\n',tinit)
  tic
 end

 % -------------------Iterations

 while resid > (epss * r0) & (ni < nitmax)
  ni = ni + 1;
  
  % ------one cycle of multigrid
  
  z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  
  x = x + z;

  % residual vector
  r = b - A * x;

  nresidu = norm(r);
  resn(ni+1) = nresidu;
  if iprint == 1
   bet = nresidu;
   fprintf('end of iter = % d, true residual norm = %12.5e, relative residual norm = %12.5e \n',ni,bet,bet/sqrt(r0))
  end

  % convergence test or too many iterations
  if nresidu < (epsi * sqrt(r0)) || ni >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu
  
 end %  while - end of one iteration

 if iconv == 1
  % number of total iterations
  nit = ni;
  % return code
  iret= 0;
  if iprint == 1
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
  end
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end
  
  if timing == 1
   titer = toc;
   fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   time_mat = struct('init_time',tinit,'iter_time',titer);
  else
   time_mat = [];
  end % if timing
  
  return
 end

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
nit = ni;
resn = resn(1:ni);
if ni == nitmax
 iret = 1;
end

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

if timing == 1
 titer = toc;
 fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 time_mat = struct('init_time',tinit,'iter_time',titer);
else
 time_mat = [];
end

% warning on
