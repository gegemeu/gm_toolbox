function [x,nit,iret,results] = gm_AMG(A,b,x0,options,params);
%GM_AMG algebraic MultiGrid for a matrix A as an iterative method

% Input:
% A = nonsingular matrix
% b = right-hand side
% x0 = initial vector
%
% options is a structure which can contain the following fields:
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% scaling = 1, scales the matrix before preconditioning
% iprint = 1, prints residual norms
% timing = 1, with time measurements
%
% params = structure giving the parameters
%   if params is empty, or if fields are not provided, default values are used
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code, 0 if convergence, otherwise 1
% resnt = true residual norms

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin == 1
 error('gm_QORm_optinv_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_QORm_optinv_prec: Error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end % if
nx = length(x0);
if nlb ~= nx
 error('gm_QORm_optinv_prec: Error, the dimensions of x0 and b are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,scaling,trueres,iprint,timing,l2norm] = gm_AMG_options(A,options);

% get the AMG parameters
params_amg = gm_AMG_params(A,params);
% params_amg  = {xin, nu, alpmax, alb, lmax, falp, qmin, alq, smooth, infl, coarse, interpo, normal, gama};
xin = params_amg{1};
nu = params_amg{2};
alpmax = params_amg{3};
alb = params_amg{4};
lmax = params_amg{5};
falp = params_amg{6};
qmin = params_amg{7};
alq = params_amg{8};
smooth = params_amg{9};
infl = params_amg{10};
coarse = params_amg{11};
interpo = params_amg{12};
normal = params_amg{13};
gam = params_amg{14};

if l2norm == 1
 norml2 = zeros(1,nitmax+1);
 xec = A \ b;
 norml2(1) = norm(xec - x0);
end % if
trueres = 1;

if iprint == 1
 fprintf('\n gm_AMG_prec: \n\n')
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  l2norm = %d \n',l2norm)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  timing = %g \n',timing)
 fprintf('\n -----------AMG parameters \n')
 fprintf(' lmax = %d \n',lmax)
 fprintf(' nu = %d \n',nu)
 fprintf(' alpmax = %g \n',alpmax)
 fprintf(' alb = %g \n',alb)
 fprintf(' smooth = %s \n',smooth)
 fprintf(' infl = %s \n',infl)
 fprintf(' coarse = %s \n',coarse)
 fprintf(' interpo = %s \n',interpo)
end

x = [];
nit = 0;
iret = 0;
resnt = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ------------------------Initialization

if timing == 1
 tic
end % if

% multilevel preconditioner
if timing == 0
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
else
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,0);
end % if
if err == 1
 fprintf('\n gm_AMG_prec: Error in gm_amg_ns_init \n')
 iret = 1;
 return
end

x = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n\n',norm(b - A * x))
end

% residual vector
r = b - A * x;

resnt = zeros(1,nitmax);
r0 = r' * r;
bet = norm(r);
resnt(1) = bet;
resid = realmax;
iconv = 0;
epss = epsi^2;
nit = 0;

if timing == 1
 tinit = toc;
 fprintf('\n Initialization time = %g \n\n',tinit)
 tic
end

% -------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 nit = nit + 1;
 
 % ------one cycle of multigrid
 
 z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 
 x = x + z;
 
 % residual vector
 r = b - A * x;
 
 nresidu = norm(r);
 resid = nresidu^2;
 resnt(nit+1) = nresidu;
 if l2norm == 1
  norml2(nit+1) = norm(xec -x);
 end % if
 if iprint == 1
  bet = nresidu;
  fprintf('end of iter = % d, true residual norm = %12.5e, relative residual norm = %12.5e \n',nit,bet,bet/nb)
 end
 
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || nit >= nitmax
  % convergence
  iconv = 1;
  break
 end % if nresidu
 
end %  while - end of one iteration

if iconv == 1
 if nit == nitmax
  fprintf('\n No convergence after %d iterations \n',nit)
 else
  fprintf('\n Convergence after %d iterations \n',nit)
 end % if
 % return code
 iret= 0;
 if iprint == 1
  fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 end
 resnt = resnt(1:nit+1);
 if l2norm == 1
  norml2 = norml2(1:nit+1);
 end % if
 
 % if scaling go back to the solution of the original system
 if scaling == 1
  x = dda .* x;
 end
 
 if timing == 1
  titer = toc;
  if iprint > 0
   fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
  end
  results.timing = struct('init_time',tinit,'iter_time',titer);
 end % if timing
 
 if trueres == 1
  results.resnt = resnt;
 end % if
 if l2norm == 1
  results.norml2 = norml2;
 end % if
 
 return
end

% if we get here we have done the max number of cycles may be without convergence
if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
end % if
iret = 0;
resnt = resnt(1:nit);
if l2norm == 1
 norml2 = norml2(1:nit+1);
end % if
if nit == nitmax
 iret = 1;
end

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 results.timing = struct('init_time',tinit,'iter_time',titer);
end % if timing

if trueres == 1
 results.resnt = resnt;
end % if
if l2norm == 1
 results.norml2 = norml2;
end % if

% warning on
