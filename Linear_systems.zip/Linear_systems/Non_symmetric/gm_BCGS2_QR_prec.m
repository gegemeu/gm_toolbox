function [x,nit,iret,resn,resnt,time_mat,nreo]=gm_BCGS2_QR_prec(A,b,x0,epsi,nitmax,mm,lefts,reorths,scalings,trueress,iprints,precond,lorth,varargin);
%GM_BCGS2_QR_PREC restarted GMRES(m) for a matrix A with m directions and preconditioning with block GS
% uses block classical Gram-Schmidt with selective reorthogonalization

% see: Y. Saad and M.H. Schultz, GMRES: a generalized minimal residual algorithm for solving nonsymmetric linear systems, 
%                                SIAM J. Sci. Statist. Comput., v 7 n 3 (1986), pp. 856-869.

% uses iterated block classical Gram-Schmidt + QR
% the computation of the basis is not mixed with the solution of the least squares problem

%
% Input:
% A = matrix, b = right-hand side, x0 = initial vector
% epsi = convergence threshold for the residual norm
% nitmax  = maximum number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% mm = [m, s, tyb], m restarting parameter, GMRES(m), s <= m, block size, tyb = type of local basis
%        tyb = 0 monomial, 1 Newton (spoke sets), 2 Chebyshev, 3 QOR opt, 4 = Arnoldi
% lefts = 'left' left preconditioning, otherwise right preconditioning
% reorths = 'reorth' with full reorthogonalization, 
%         = 'sorth' selective  reorthogonalization
% scalings = 'scaling', diagonally scales the matrix before preconditioning
% trueress = 'trueres' computes the norm of b - A x_k
% iprints = 'print' print residual norms at every iteration
% precond = type of preconditioning
%  = 'no' without preconditioning M = I
%  = 'sc' diagonal
%  = 'ss' SSOR omega = 1
%  = 'gs' Gauss-Seidel
%  = 'lu' ILU(0) Incomplete LU without pivoting
%  = 'lb' Incomplete block LU
%  = 'ai' Approximate inverse AINV of Benzi
%  = 'gp' given preconditioning matrix M in varargin
%         inv(M)A x = inv(M)b or A inv(M) x = b
%  = 'ml' multilevel AMG preconditioner
% lorth = threshold for selective reorthogonalization
%
% varargin = block size if precond = 'lb'
%          = M if precond = 'gp'
%          = [alpha, q] for AINV, alpha = threshold, q = max number of non
%          zero entries in one row
%
%  parameters for preconditioner 'ml' in varargin
%   lmax = max number of levels
%   nu = number of smoothing steps
%   almax = parameter alpha for the influence matrix
%   alb = parameter alpha for the generation of grids with AINV
%   smooth = type of smoothing operator (any of the above preconditioners)
%   influ = type of influence matrix
%   coarse = type of coarsening algorithm
%   interpo = type of interpolation algorithm
%   q = number of entries kept in a column for smoother AINV (default =
%       size(A,1))
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no
%        convergence after nitmax iterations
% resn = (preconditioned) residual norms
% resnt = true residual norms if 'trueres'
% time_mat = if nitmax < 0, time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items
% nreo = number of block reorthogonalizations
%

%
% Author G. Meurant
% Dec 2001, july 2006, may 2007
% October 2009: modification to handle complex matrices
% March 2015
%

% warning off

if nargin < 3
 x0 = zeros(size(A,1),1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = size(A,1);
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
  prints = 'noprint';
 end
end

n = size(A,1);

if nargin < 6
 m = n;
 sb = 1;
 tyb = 0;
else
 m = mm(1);
 sb = mm(2);
 tyb = mm(3);
end

if timing == 1
 % if timing = 1 print the computing time
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_GMRESm_BCGS2_QR_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_GMRESm_BCGS2_QR_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 7
 % left preconditioning
 left = 1;
 lefts = 'left';
end
if nargin < 8
 % no reorthogonalization
 reorth = 0;
 reorths = 'noreorth';
 sorth = 0;
end
if nargin < 9
 % no scaling
 scaling = 0;
 scalings = 'noscaling';
end
if nargin < 10
 % do not compute the true residual norm
 trueres = 0;
 trueress = 'notrueres';
end
if nargin < 11
 % no printing
 iprint = 0;
 prints = 'noprint';
end
if nargin < 12
 % no preconditioning
 precond = 'no';
end
if nargin < 13 && (strcmpi(reorths,'sorth') == 1)
 lorth = sqrt(eps);
end
if nargin < 13 && (strcmpi(reorths,'sorth') == 0)
 lorth = 0;
end

if nargin > 7 && (strcmpi(lefts,'left') == 1)
 left = 1;
else
 left = 0;
end
if nargin > 8 && (strcmpi(reorths,'reorth') == 1)
 reorth = 1;
 sorth = 0;
else
 reorth = 0;
end
if nargin > 8 && (strcmpi(reorths,'sorth') == 1)
 sorth = 1;
 reorth = 0;
else
 sorth = 0;
end
if nargin > 9 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 10 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 11 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if m > nitmax
 m = nitmax;
end

if m == 0
 m = 10;
end

if iprint == 1
 nbb = fix(m / sb); % number of blocks
 nrem = m - nbb * sb;
 if nrem > 0
  nbb = nbb + 1;
 end % if
 fprintf('\n gm_GMRESm_BCGS2_QR_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  block size = %d \n',sb)
 fprintf('  number of blocks per cycle = %d \n',nbb)
 switch tyb
  case 0
   fprintf('  type of basis = monomial \n')
  case 1
   fprintf('  type of basis = Newton \n')
  case 2
   fprintf('  type of basis = Chebyshev \n')
  case 3
   fprintf('  type of basis = QOR \n')
  case 4
   fprintf('  type of basis = Arnoldi CGS \n')
  otherwise
   fprintf('  type of basis = monomial \n')
 end % switch
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 fprintf('  sorth = %d, threshold = %g \n',sorth,lorth)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
end

tb = 1;
if nargin >= 14 && (strcmpi(precond,'lb') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_GMRESm_BCGS2_QR_prec: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'lm') == 1)
 % threshold for the Matlab ILU preconditioner 
 tb = varargin{1};
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin < 14 && (strcmpi(precond,'lm') == 1)
 tb = 0.05 * abs(max(max(A)));
 tb = full(tb);
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'ld') == 1)
 % threshold for the Matlab ILU preconditioner 
 tb = varargin{1};
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin < 14 && (strcmpi(precond,'ld') == 1)
 tb = 0.05 * abs(max(max(A)));
 tb = full(tb);
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'gm') == 1)
 % number of iterations for GMRES 
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 14 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 %  tb = [alp, q] for AINV
 tb = varargin{1};
 if  strcmpi(precond,'ai') == 1 && length(tb) == 1
  tb = [tb n];
 end
end

if nargin < 14 && (strcmpi(precond,'ai') == 1)
 % default
 tb = [0.1, n];
end

if nargin < 14 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
 fprintf('  q = %g \n',tb(2))
end
if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >= 14 && (strcmpi(precond,'gp') == 1)
 % given preconditioning matrix
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_GMRESm_BCGS2_QR_prec: error, M has to be of the same order as A')
end

if nargin >= 14 && strcmpi(precond,'ml') == 1
 % get the input parameters for the multilevel AMG method
 if nargin < 21
  error('gm_GMRESm_BCGS2_QR_prec: some parameters are not defined for ML')
 end

 lmax = varargin{1};
 nu = varargin{2};
 alpmax = varargin{3};
 alb = varargin{4};
 smooth = varargin{5};
 infl = varargin{6};
 coarse = varargin{7};
 interpo = varargin{8};
 if nargin > 21
  qmin = varargin{9};
 else
  qmin = n;
 end
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
 
end

if nargin < 14 && strcmpi(precond,'ml') == 1
 % defaults for AMG
 lmax = 10;
 nu =1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'lu';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------default ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
 
end

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
% array containing the number of matrix-vector products as a function of
% the iteration number
matv = zeros(1,nitmax+1);
dotprod = 0;

% init vector for 'ml'
xin = zeros(n,1);

% init of preconditioners
if ~strcmpi(precond,'ml')
 [DD,LL,UU] = gm_initprecns(A,precond,tb);
 if strcmpi(precond,'gp')
  LL = M;
 end
else
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_GMRESm_BCGS2_QR_prec: Error in gm_amg_ns_init \n')
  iret = 1;
  return
 end
end % if strcmpi

x = x0;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end

if left == 0
 % A inv(M) x_0
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(x0,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,x0,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
end

% initial residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 % init true residual norm
 resnt = zeros(1,nitmax);
 resnt(1) = norm(r);
end

if left == 1
 % generalized residual M z = r
 if strcmpi(precond,'ml') == 0
  z = gm_solveprecns(r,A,DD,LL,UU,precond);
 else
  z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
else
 z = r;
end % if left

r = z;
rhs = zeros(m+1,1);
% H contains the upper Hessenberg matrix
H = zeros(m+1,m);
resn = zeros(1,nitmax);
r0 = r' * r;
bet = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

% number of cycles
nitd = 0;
% number of iterations
ni = 0;
iconv = 0;
resn(1) = bet;
rhs(1) = bet;
resid = realmax;
epss = epsi^2;
% number of reorthogonalizations
nreo = 0;
matv(1) = matvec;

if timing == 1 
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% -----------------Iterations

while resid > (epss * r0) && (ni < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
%  fprintf('\n ---------------cycle = %d \n',nitd)
 % number of iterations in the cycle
 nic = 0;
 % init basis vectors
 V = zeros(n,m+1);
 % upper Hessenberg matrix
 H = zeros(m+1,m);
 R = zeros(sb+1,sb+1);
 % first row of inv(U)
 nuu = zeros(1,m+1);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;
 nuu(1) = 1;
 snuu = 1;
 nr0 = bet;
 zp = [];

 % start a cycle of GMRES(m)
  nb = fix(m / sb); % number of blocks
  nrem = m - nb * sb;    
  if nrem > 0
   nb = nb + 1;
  end % if
  
  % computation of the basis vectors
  
  ddc = [0, 0, 0];
  if tyb == 0
   % first block (monomial basis)
   K = compute_basis(A,V(:,1),sb+1,0,zp);
   nK = norm(K(:,1));
   [Y,R12,R22,northog] = gm_bgssro(K(:,1)/nK,K(:,2:sb+1));
   dotprod = dotprod + sb;
   if northog > 0
    dotprod = dotprod + sb;
   end % if
   Y = [K(:,1)/nK Y];
   nr = size(R12,1) + size(R22,1);
   V(:,1:sb+1) = Y(:,1:sb+1);
   R(1,1) = nK;
   Rb = [R12; R22];
   R(1:nr,2:sb+1) = Rb;
   H(1:sb+1,1:sb) = R(1:sb+1,2:sb+1) / R(1:sb,1:sb);
   
  elseif (tyb == 1) || (tyb == 2)
   [K,H] = gm_Arnoldi(A,V(:,1),sb+1,'noreorth','noprint');
  end % if tyb
  
  if tyb == 1
   % compute the Newton shifts
   zp = Newton_points(H(1:sb,1:sb),sb+1);
  elseif tyb == 2
   % compute the Chebyshev coefficients
   [zp,dd,dc,cc] = Cheby_coef(H(1:sb,1:sb),sb+1);
   ddc = [dd, dc, cc];
  end % if
  iconv = 0;
  
  % other blocks
  if iconv ~= 1
   for k = 1:nb
%     fprintf('\n start block %d \n',k)
    reorth = false;
    cd = (k - 1) * sb + 1;
    cf = k * sb;
    ss = sb;
    if (nrem > 0) && (k == nb)
     cf = m;
     ss = m - sb * (k - 1);
    end % if
    nu = zeros(1,ss);
    Bs = zeros(ss+1,ss);
    for j = 2:ss+1
     Bs(j,j-1) = 1;
    end % for j
    sk1 = sb * (k - 1);
    sk = sk1 + ss; 
%     if k == 1
%      vstart = V(:,sk1+1);
%     else
%       vstart = sum(V(:,sb*(k-2)+1:sk1+1),2);
%       vstart = vstart / norm(vstart);
%     end % if k
    vstart = V(:,sk1+1);
%     [K,B] = compute_basis(A,V(:,sk1+1),ss+1,tyb,zp,ddc);
    [K,B] = compute_basis(A,vstart,ss+1,tyb,zp,ddc);
    Vbp = K(:,2:ss+1);
    for j = 1:ss
     nu(j) = norm(Vbp(:,j));
    end % for j
    Xb = V(:,1:cd)' * Vbp;
    dotprod = dotprod + cd * ss;
    X = Xb(:,1:ss-1);
    Vbp = Vbp - V(:,1:cd) * Xb;
    [Qt,R2b] = gm_signqr(Vbp);
    R2 = R2b(1:ss-1,1:ss-1);

    V(:,cd+1:cf+1) = Qt;
    Zb = [zeros(sk1,1) Xb(1:sk1,:)];
    Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
    XR = -X / R2;
    R2i = inv(R2); % R2 may be close to singular
    Z = [zeros(sk1,1) XR(1:sk1,:)];
    W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
    for j = 1:ss
%      if normcol(j) <= (0.5 * nu(j)) % this may be asking for too much!!!!!!!!
     if R2b(j,j) <= (0.5 * nu(j))
      reorth = true;
      %    fprintf('\n reorth needed k = %d, j = %d, R2b = %12.5e, bound = %12.5e \n',k,j,R2b(j,j),(0.5*nu(j)))
     end % if
    end % for j
%      reorth = false;
    %  reorth = true;
    if reorth && (ss > 1)
     % reorthogonalization
     nreo = nreo + 1;
     ZZb = V(:,1:cd)' * Qt;
     dotprod = dotprod + cd * size(Qt,2);
     ZZ = ZZb(:,1:ss-1);
     Qt = Qt - V(:,1:cd) * ZZb;
     [QQt,R2bh] = gm_signqr(Qt);
     V(:,cd+1:cf+1) = QQt;
     Xb = ZZb * R2b + Xb;
     X = ZZ * R2 + X;
     R2b = R2bh * R2b;
     R2 = R2b(1:ss-1,1:ss-1);
     Zb = [zeros(sk1,1) Xb(1:sk1,:)];
     Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
     XR = -X / R2;
     R2i = inv(R2);
     Z = [zeros(sk1,1) XR(1:sk1,:)];
     W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
    end % if
%     rV = rank(V(:,1:cf+1));
%     sV = min(svd(V(:,1:cf+1)));
%     fprintf('\n nb basis vectors = %d, rank = %d, min svd = %12.5e \n',cf+1,rV,sV)
    if tyb == 0
     % top part
     H(1:sk1,sk1+1:sk) = H(1:sk1,1:sk1) * Z + Zb(:,2:ss+1) * W; % true only for monomial basis
     h0 = H(sk1+1,1:sk1) * Z;
     WW = Wb(:,2:ss+1) * W;
     WW(1,:) = WW(1,:) + h0;
     % bottom part = WW
     H(sk1+1:sk+1,sk1+1:sk) = WW;
    else
     % Newton and others
     sZb = size(Zb);
     sW = size(W);
     H(1:sk1,sk1+1:sk) = H(1:sk1,1:sk1) * Z + Zb * B(1:sZb(2),1:sW(1)) * W;
     h0 = H(sk1+1,1:sk1) * Z;
     sWb = size(Wb);
     WW = Wb * B(1:sWb(2),1:sW(1)) * W;
     WW(1,:) = WW(1,:) + h0;
     H(sk1+1:sk+1,sk1+1:sk) = WW;
    end % if tyb
    
    % compute nu and test convergence
    for kk = sk1+1:sk
     ni = ni + 1;
     nic = nic + 1;
     nuu(kk+1) = -nuu(1:kk) * H(1:kk,kk) / H(kk+1,kk);
     snuu = snuu + abs(nuu(kk+1))^2;
     nresidu = nr0 / sqrt(snuu);
     resn(ni+1) = nresidu;
     resid = nresidu^2;
     matvec = matvec + 1;
     % dotprod ????
     matv(ni+1) = matvec;
     
     if iprint == 1
      fprintf('cycle = % d, block = %d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,k,ni,nresidu,nresidu/sqrt(r0))
     end
     
     if trueres == 1
      % computation of the true (if left = 0) residual norm
      % triangular solve
      [QQ,RQ] = qr(H(1:kk+1,1:kk),0); % this is too costly, us QR update?
      %    [QQ,RQ,flag] = gm_cholQR2(H(1:kk+1,1:kk));
      y = RQ(1:kk,1:kk) \ (QQ' * rhs(1:kk+1));
      xx = x0 + V(:,1:kk) * y;
      if left == 0
       % right preconditioner
       if strcmpi(precond,'ml') == 0
        xx = gm_solveprecns(xx,A,DD,LL,UU,precond);
       else
        xx = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
       end
      end % if left
      % this is also not the true residual norm if there is some scaling
      resnt(ni+1) = norm(b - A * xx);
     end % if trueres
     
     % convergence test or too many iterations
     if nresidu < (epsi * sqrt(r0)) || ni >= nitmax
      % convergence
      iconv = 1;
%       fprintf('\n convergence or stop iteration %d \n',ni)
      break
     end % if
    end % for kk
    
    if iconv == 1
     break
    end %if
%     fprintf('\n end of block %d, res = %12.5e ',k,norm(b - A * xx))
   
   end % for k
   
  end % if iconv

 % computation of the solution at the end of the cycle
 % triangular solve
 [QQ,RQ] = qr(H(1:nic+1,1:nic),0);
%  [QQ,RQ] = gm_cholQR2(H(1:nic+1,1:nic));
 y = RQ(1:nic,1:nic) \ (QQ' * rhs(1:nic+1));
 x = x0 + V(:,1:nic) * y;

 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   if strcmpi(precond,'ml') == 0
    x = gm_solveprecns(xx,A,DD,LL,UU,precond);
   else
    x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end
  end
  % ------ exit
  resn = resn(1:ni+1);
  if trueres == 1
   resnt = resnt(1:ni+1);
  end
  % number of total iterations
  nit = ni;
  % return code
  iret= 0;
  if ni == nitmax
   iret = 2;
  end
  
  if iprint == 1
   if ni == nitmax
    fprintf('\n No convergence after %d iterations \n',ni)
   end
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
   fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
  end % if iprint
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end

  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  else
   time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  end

  return
 end % if iconv

 % we have not converged yet, compute the residual and restart

 xx = x;
 if left == 0
  % right preconditioner
  if strcmpi(precond,'ml') == 0
   xx = gm_solveprecns(x,A,DD,LL,UU,precond);
  else
   xx = gm_amg_ns_it(A,x,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 end % if left

 % residual vector at the end of the cycle
 r = b - A * xx;
 matvec = matvec + 1;

 if left == 1
  % left preconditioner
  % generalized residual M z = r
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(r,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 else
  z = r;
 end % if left

 r = z;
 x0 = x;
 resid = r' * r;
 bet = norm(r);
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 
 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,ni,bet,bet/sqrt(r0))
 end
 
end % while, loop on cycles

% if we get here we have done the max number of cycles, may be without convergence
iret = 0;
nit = ni;
resn = resn(1:ni);
if trueres == 1
 resnt = resnt(1:ni);
end
if ni == nitmax
 iret = 2;
end

xx = x;
if left == 0
 % right preconditioner
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(xx,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
end

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',ni)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
 fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end

if timing == 1 
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
end

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

% warning on
return

function [K,T] = compute_basis(A,v,bls,tyb,zp,ddc);
% Local basis vectors

T = [];
switch tyb
 case 0
  K = monom(A,v,bls); 
 case 1
  [K,T] = Newton(A,v,bls,zp);
   T = T(1:bls+1,1:bls);
 case 2
  dd = ddc(1);
  dc = ddc(2);
  cc = ddc(3);
   [K,T] = Cheby(A,v,bls,zp,dd,dc,cc);
   T = T(1:bls+1,1:bls);
 case 3
  [K,T] = QOR_basis(A,v,bls);
  T = T(1:bls+1,1:bls);
 case 4
  [K,T] = gm_Arnoldi_CGS(A,v,bls+1,'noreo','noprint');
  T = T(1:bls+1,1:bls);
 otherwise
  K = monom(A,v,bls);
end % switch
K = K(:,1:bls);
% rK = rank(K);
% sv = min(svd(K));
% fprintf('\n nb of vectors = % d, rank = %d, min svd = %12.5e \n',bls,rK,sv)

end % function compute_basis

 function K = monom(A,v,bls);
  % computes  the (not normalized) Krylov vectors for matrix A and vector v
  
  K = zeros(size(A,1),bls);
  K(:,1) = v;
  
  for kkk = 2:bls
   if left == 1
    % left preconditioner
    Av = A * K(:,kkk-1);
    % solve of M z = Av
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(Av,A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = z;
   else % if left (right preconditioner)
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(K(:,kkk-1),A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,K(:,kkk-1),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   K(:,kkk) = Av;
  end % for kkk
  
 end % function monom

 function zp = Newton_points(HH,bls)
  
  % Ritz values
  eigH = eig(full(HH));
  
  % pit?????
  pit = size(HH,1);
  sensitivity = 0;
  
  % get rid of the sensitive Ritz values
  if sensitivity == 1
   [XRR,eH] = eig(full(HH));
   eH = diag(eH);
   [XL,eHT] = eig(full(HH'));
   eHT = diag(eHT);
   sens_eig = zeros(1,pit);
   for j = 1:pit
    la = eH(j);
    xR = XRR(:,j);
    % find the complex conjugate for HH'
    for jj = 1:pit
     if abs(la' - eHT(jj)) < 1e-5
      cjj = jj;
      xL = XL(:,jj);
      break
     end % if
    end % for jj
    sens_eig(j) = 1 / abs(xR' * xL);
   end %for j
   [sens,I] = sort(sens_eig,'ascend');
   msens = fix(pit / 2);
   I = I(1:msens);
   eigm = eH(I);
   j = 0;
   for jj = 1:msens
    if isreal(eigm(jj))
     j = j + 1;
     eigH(j) = eigm(jj);
    else
     j = j + 1;
     eigH(j) = eigm(jj);
     j = j + 1;
     eigH(j) = conj(eigm(jj));
    end
   end % for jj
   eigH = eigH(1:j);
   eigH = gm_unique(eigH);
  end % for sensitivity
  
  %-----------------test if the eigenvalues are real
  
  if isreal(eigH)
   
   % get fast Leja points on the interval
   zp = gm_leja_shift(min(eigH),max(eigH),bls+1);
   
   xp = zp;
   yp = imag(zp);
   
  else
   
   % Fast Leja points on spoke sets
   ds = gm_compress_R(eigH);
   % first point
   [leja,cpts,scalefactor] = gm_lejashifts_R(ds);
   % add p-1 points
   [leja,cpts] = gm_lejashifts_R([],bls-1,leja,cpts,scalefactor);
   if nargin > 1
    leja = sort(leja);
   end
   shift = gm_expand_R(leja,bls);
   xp = real(shift);
   yp = imag(shift);
   zp = shift;
   if size(zp,1) > bls
    if imag(zp(1)) == 0
     zp = zp(2:end);
    end % if imag
   end % if size
   
  end % if isreal
  
 end % function Newton_points

 function [K,T] = Newton(A,v,bls,zp)
  
  K = zeros(size(A,1),bls);
  K(:,1) = v;
  kkk = 1;
  
  while kkk <= bls
   
   compl = ~isreal(zp(kkk));
   s = real(zp(kkk));
   
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * K(:,kkk);
    % solve of M z = Av
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(Av,A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = z;
   else % if left (right preconditioner)
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(K(:,kkk),A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,K(:,kkk),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   w = Av;
   
   vv = w - s * K(:,kkk);
   nvv = norm(vv);
   dotprod = dotprod + 1;
   K(:,kkk+1) = vv / nvv;
   T(kkk,kkk) = s;
   T(kkk+1,kkk) = nvv;
   kkk = kkk + 1;
   
   if compl && kkk <= bls
    
    % matrix-vector product
    if left == 1
     % left preconditioner
     Av = A * K(:,kkk);
     % solve of M z = Av
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(Av,A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = z;
    else % if left (right preconditioner)
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(K(:,kkk),A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,K(:,kkk),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = A * z;
    end % if left
    matvec = matvec + 1;
    w = Av;
    
    si2 = imag(zp(kkk))^2 ;
    vv = w - s * K(:,kkk) + (si2 / nvv) * K(:,kkk-1);
    nvv_old = nvv;
    nvv = norm(vv);
    dotprod = dotprod + 1;
    K(:,kkk+1) = vv / nvv;
    T(kkk,kkk) = s;
    T(kkk+1,kkk) = nvv;
    T(kkk-1,kkk) = -si2 / nvv_old;
    kkk = kkk + 1;
    
   end % if compl
   
  end % while kkk
  
  return
  
 end % function Newton

 function [alpC,dd,dc,cc] = Cheby_coef(HH,bls)
  
  pit = size(HH,1);
  pseudo = 0;
  if pseudo == 0
   % Ritz values
   eigH = eig(full(HH));
  else
   pslevel = 1;
   [ps_pts,eigHH] = gm_pseudo_points(HH,20,pslevel);
   eigH = ps_pts(:,1) + 1i * ps_pts(:,2);
   eigH = [eigH; eigHH];
  end % if pseudo
  
  sensitivity = 0;
  % get rid of the sensitive Ritz values
  if sensitivity == 1
   [XRR,eH] = eig(full(HH));
   eH = diag(eH);
   [XL,eHT] = eig(full(HH'));
   eHT = diag(eHT);
   sens_eig = zeros(1,pit);
   for j = 1:pit
    la = eH(j);
    xR = XRR(:,j);
    % find the complex conjugate for HH'
    for jj = 1:pit
     if abs(la' - eHT(jj)) < 1e-5
      cjj = jj;
      xL = XL(:,jj);
      break
     end % if
    end % for jj
    sens_eig(j) = 1 / abs(xR' * xL);
   end %for j
   [sens,I] = sort(sens_eig,'ascend');
   if pseudo == 0
    msens = fix(pit / 2);
    I = I(1:msens);
    eigm = eH(I);
    j = 0;
    for jj = 1:msens
     if isreal(eigm(jj))
      j = j + 1;
      eigH(j) = eigm(jj);
     else
      j = j + 1;
      eigH(j) = eigm(jj);
      j = j + 1;
      eigH(j) = conj(eigm(jj));
     end
    end % for jj
    eigH = eigH(1:j);
    eigH = gm_unique(eigH);
   end % if pseudo
  end % for sensitivity
   
  %-----------------test if the eigenvalues are real 
  if isreal(eigH)
   
   cx = (min(eigH) + max(eigH)) / 2;
   cy = 0;
   aa = max(eigH) - min(eigH);
   bb = 0;
   % center
   dd = cx;
   cc = aa / 2;
   % foci
   f1 = dd - cc;
   f2 = dd + cc;
   
%    if iprint == 1
%     fprintf('\n center of the interval = (%g, %g), cc = %g \n',cx,cy,cc)
%    end
   
  else
   
   % get the enclosing ellipse
   [cx,cy,aa,bb,count] = gm_best_ellipse(real(eigH),imag(eigH),1e-3);
   
   %  fprintf('\n Ellipse, number of iterations = %d \n\n',count)
   
   % correction of the center if H is real
   if isreal(H)
    cy = 0;
   end
   
   cc = sqrt(aa^2 - bb^2);
   % center
   dd = cx + 1i * cy;
   % foci
   f1 = dd - cc;
   f2 = dd + cc;
   
   if isreal(cc) && cc == 0
    error(' Cheby_coef, the ellipse is a circle')
   end
   
  end % if isreal(eigH)
  
  % computation of the coefficients of the Chebyshev recurrence
  dc = dd / (cc + 1e-20);
  alpC = zeros(bls+2,1);
  alpC(1) = 1;
  alpC(2) = dc;
  for j = 3:bls+2
   alpC(j) = 2 * dc * alpC(j-1) - alpC(j-2);
  end % for j
  
 end % function Cheby_coef

 function [K,T] = Cheby(A,v,bls,alpC,dd,dc,cc)
  
  K = zeros(size(A,1),bls);
  K(:,1) = v / norm(v);
  
  for kkk = 1:bls
  
  % matrix-vector product
  if left == 1
   % left preconditioner
   Av = A * K(:,kkk);
   % solve of M z = Av
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(Av,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
   Av = z;
  else % if left (right preconditioner)
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(K(:,kkk),A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,K(:,kkk),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
   end % if ~
   Av = A * z;
  end % if left
  matvec = matvec + 1;
  w = Av;
  
  % Chebyshev polynomial
  
  if kkk == 1
   vv = v - (1 / dd) * w;
   nvv = norm(vv);
   nvv_old = 1;
   dotprod = dotprod + 1;
   K(:,kkk+1) = vv / nvv;
   T(1,1) = dd;
   T(2,1) = -dd * nvv;
  else
   chi = 1 / (2 * dc - alpC(kkk) / alpC(kkk+1));
   xi = 1 / ( 2 * dc * (alpC(kkk+1) / alpC(kkk))- 1);
   vv = (2 * dc * chi * K(:,kkk) - 2 * (chi / cc) * w) * nvv - xi * K(:,kkk-1) * nvv_old;
   nvv_new = norm(vv);
   dotprod = dotprod + 1;
   K(:,kkk+1) = vv / nvv_new;
   T(kkk,kkk) = dd;
   cchi = cc / (2 * chi);
   T(kkk-1,kkk) = -cchi * xi * nvv_old / nvv;
   T(kkk+1,kkk) = -cchi * nvv_new / nvv;
   nvv_old = nvv;
   nvv = nvv_new;
  end % if kkk
 end % for kkk
  
 end % function Cheby
   
   

 function [K,B] = QOR_basis(A,v,bls);
  
  % init basis vectors
  K = zeros(n,bls+1);
  % array L is the inverse of the matrix L (Cholesky factor of V^T V)
  L = zeros(bls+1,bls+1);
  % init B
  B = zeros(bls+1,bls);
  % the first vector is the last residual normalized
  v = v / norm(v);
  K(:,1) = v;
  
  % matrix-vector product A v
  if left == 1
   % left preconditioner
   Av = A * v;
   % solve of M z = Av
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(Av,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
   Av = z;
  else % if left (right preconditioner)
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(v,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,v,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
   Av = A * z;
  end % if left
  % we do not count this one because there is a matvec at the end of the
  % iterations
  %  matvec = matvec + 1;
  
  L(1,1) = 1;
  
  % start QORm(bls)
  
  for kkk = 1:bls
   
   % construction of the basis vectors
   % and entries of H (in the last column of H)
   
   if kkk == 1
    % first iteration
    % choose the optimal value for the first column of H
    v = K(:,1);
    vAv = v' * Av;
    vAAv = Av' * Av;
    dotprod = dotprod + 2;
    
    if abs(vAv) <= 1e-14
     % breakdown
     fprintf('\n QORmc: Initialization breakdown, v^T A v = %g \n',vAv)
     B(1,1) = 0;
    else
     B(1,1) = vAAv / vAv;
    end % if abs
    
    % new basis vector (to be normalized)
    vt = Av - B(1,1) * K(:,1);
    B(2,1) = norm(vt);
    dotprod = dotprod + 1;
    % new basis vector
    K(:,2) = vt / B(2,1);
    Vko = K(:,1);
    Vk = K(:,1:2);
    v = K(:,2);
    
    % matrix-vector product
    if left == 1
     % left preconditioner
     Av = A * K(:,2);
     % solve of M z = Av
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(Av,A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = z;
    else % if left (right preconditioner)
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(K(:,2),A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,K(:,2),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = A * z;
    end % if left
    matvec = matvec + 1;
    
   else % kkk ~= 1
    
    % other iterations
    AvAv = Av' * Av;
    
    % 2 independant dense matrix-vector products
    vkv = (v' * Vko)'; % this is to avoid the transpositions of Vko and Vk
%     vktA = (Av' * Vk)';
    vktA = Vk' * Av;
    vktA(kkk) = v' * Av;
    dotprod = dotprod + 2 * kkk;
    
    % inverse of L_k
    lk = L(1:kkk-1,1:kkk-1) * vkv;
    matvec = matvec + 2;
    ykt = lk' * L(1:kkk-1,1:kkk-1);
    lkt = lk' * lk;
    dotprod = dotprod + 1;
    % diagonal entry
    if lkt >=1
     pknu = Vko * ykt';
     dotprod = dotprod + n;
     lkk = norm(K(:,kkk) - pknu);
     dotprod = dotprod + 1;
    else
     lkk = sqrt(1 - lkt);
    end % if lkt
    
    % what to do if lkk is small?
    if lkk < 1e-10
     if iprint == 1
      fprintf('\n QORm: The diagonal entry of L is small = %g at step %d \n',lkk,kkk)
     end
    end
    % new row of the inverse of the Cholesky factor
    L(kkk,1:kkk) = [-ykt / lkk, 1 / lkk];
    
    lA = L(1:kkk,1:kkk) * vktA;
    s = L(1:kkk,1:kkk)' * lA;
    
    alp = AvAv - lA' * lA;
    dotprod = dotprod + 1;
    
    % new column of H
    if abs(vktA(kkk)) <= 0
     %     if iprint == 1
     fprintf('\n QORm: Breakdown step %d, value = %g \n',kkk,vktA(kkk))
     %     end
     return
    else
     beta = alp / vktA(kkk);
     B(1:kkk,kkk) = s;
     B(kkk,kkk) = B(kkk,kkk) + beta;
    end % if vktA
    
    % new basis vector (to be normalized)
    vt = Av - Vk * B(1:kkk,kkk);
    h = norm(vt);
    dotprod = dotprod + 1;
    
    % subdiagonal entry of B
    B(kkk+1,kkk) = h;
    
    if kkk < bls
     % new basis vector
     v = vt / h;
     K(:,kkk+1) = v;
     Vko = Vk;
     Vk = [Vk v];
     
     % matrix-vector product (n x n)
     if left == 1
      % left preconditioner
      Av = A * v;
      % solve of M z = Av
      if strcmpi(precond,'ml') == 0
       z = gm_solveprecns(Av,A,DD,LL,UU,precond);
      else
       z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
      end % if strcmpi
      Av = z;
     else % if left (right preconditioner)
      if strcmpi(precond,'ml') == 0
       z = gm_solveprecns(v,A,DD,LL,UU,precond);
      else
       z = gm_amg_ns_it(A,v,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
      end % if strcmpi
      Av = A * z;
     end % if left
     matvec = matvec + 1;
     
    end % if kkk < bls
   end % if kkk == 1
   
  end % for kk
  
 end % function QOR_basis

end % function
