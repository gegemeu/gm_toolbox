function [x,nit,iret,results] = gm_BCGS2_QR_prec(A,b,x0,options,params);
%GM_BCGS2_QR_PREC preconditioned block Gram-Schmidt + QR for a matrix A

% uses iterated block classical Gram-Schmidt + QR
% the computation of the basis is not mixed with the solution of the least squares problem

% Can use different local bases (within a block): monomial, Newton, Chebyshev, QOR opt, orthonormal

%
% Input:
% A = matrix
% b = right-hand side
% x0 = initial vector
%
% options is a structure which can contain the following fields:
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% m = restarting parameter, GMRES(m)
% left = 1 left preconditioning, otherwise right preconditioning
% reorth = 1 with full reorthogonalization, = 2 selective reorthogonalization
% scaling = 1, scales the matrix before preconditioning
% iprint = 1, prints residual norms
% timing = 1, with time measurements
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'gs' Gauss-Seidel
%  = 'ss' SSOR like with omega=1
%  = 'lu' Incomplete LU(0)
%  = 'lm' Matlab ILU(0)
%  = 'ld' Matlab ILU with drop threshold
%  = 'lb' block ILU
%  = 'ai' approximate inverse AINV
%  = 'tw' Tang and Wang approximate inverse
%  = 'sp' SPAI approximate inverse (Huckle and Grote)
%  = 'sh' or 'wl' ILU factorizations from V. Eijkhout
%  = 'gp' given preconditioner
%  = 'gm' GMRES iterations
%  = 'ml' multilevel (AMG)
% lorth = threshold for selective reorthogonalization
% var = [s, tyb], s <= m, block size, tyb = type of local basis
%        tyb = 0 monomial, 1 Newton (spoke sets), 2 Chebyshev, 3 QOR opt, 4 = Arnoldi

% params = structure giving the parameter(s) needed by some preconditioners
%  if params is empty, default values are used
%  one or two fields if the preconditioner is not 'ml'
%
% params.p1
%  = empty for 'no', 'sc', 'gs', 'ss', 'lu', and 'lm'
%  = epsilon for 'ld'
%  = level for 'sh', 'wl'
%  = block size for 'lb'
%  = nb of GMRES iterations for 'gm'
%  = matrix M for 'gp'

% params.p1 and params.p2
%  = threshold and number of nonzero entries  in a column for 'ai'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' are in params as (default)
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)

% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv after nitmax iterations
% results is a structure with some of the following fields:
%  resn = (preconditioned) residual norms
%  resnt = true residual norms
%  norml2 = ell2-norm of the error if option l2norm = 1
%  time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%   times, the number of matrix-vector products, the number of inner products and the
%   number of matrix-vector products as a function of the iteration number,
%   otherwise same without the first two items
%

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin == 1
 error('gm_BCGS2_QR_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_BCGS2_QR_prec: Error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end % if
nx = length(x0);
if nlb ~= nx
 error('gm_BCGS2_QR_prec: Error, the dimensions of x0 and b are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,m,scaling,trueres,iprint,precond,left,reorth,lorth,timing,l2norm,~,var] = gm_Krylov_ns_options(A,options);

if m > nitmax
 m = nitmax;
end

if isempty(var)
 sb = 1;
 tyb = 0;
else
 if length(var) == 1
  sb = var;
  tyb = 0;
 else
  sb = var(1);
  tyb = var(2);
 end % if
end % if
if tyb > 4
 tyb = 0;
end % if
nbb = fix(m / sb); % number of blocks
nrem = m - nbb * sb;
if nrem > 0
 nbb = nbb + 1;
end % if

if iprint == 1
 fprintf('\n gm_BCGS2_QR_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  block size = %d \n',sb)
 fprintf('  number of blocks per cycle = %d \n',nbb)
 switch tyb
  case 0
   fprintf('  type of basis = monomial \n')
  case 1
   fprintf('  type of basis = Newton \n')
  case 2
   fprintf('  type of basis = Chebyshev \n')
  case 3
   fprintf('  type of basis = QOR \n')
  case 4
   fprintf('  type of basis = Arnoldi CGS \n')
  otherwise
   fprintf('  type of basis = monomial \n')
 end % switch
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 if reorth == 2
  fprintf('  threshold = %g \n',lorth)
 end % if
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  l2norm = %d \n',l2norm)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  timing = %g \n',timing)
end % if

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% -----------------------Initialization

if timing == 1
 tic;
end % if

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond_ns(A,precond,iprint,params);

x = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end
% this is useless
% if left == 0
%  x = gm_solve_precond_ns(A,x0,precond,cprec,cprec_amg);
% end % if left

% init residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end
if l2norm == 1
 norml2 = zeros(1,nitmax+1);
 xec = A \ b;
 norml2(1) = norm(xec -x);
end % if

resn = zeros(1,nitmax+1);

bb = b;
if left == 1
 % generalized residual M z = r
 z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 bb = gm_solve_precond_ns(A,b,precond,cprec,cprec_amg);
else
 z = r;
end % if left
nb = norm(bb);
nb2 = nb^2;

r = z;
rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m+1,m);
r0 = r' * r;
nr = r0;
bet = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

% number of cycles
nitd = 0;
% number of iterations
nit = 0;
iconv = 0;
resn(1) = bet;
rhs(1) = bet;
resid = realmax;
epss = epsi^2;
% number of reorthogonalizations
nreo = 0;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 % number of iterations in the cycle
 nic = 0;
 % init basis vectors
 V = zeros(n,m+1);
 % upper Hessenberg matrix
 H = zeros(m+1,m);
 R = zeros(sb+1,sb+1);
 % first row of inv(U)
 nuu = zeros(1,m+1);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;
 nuu(1) = 1;
 snuu = 1;
 nr0 = bet;
 zp = [];
 
 % start a cycle
 
 nb = fix(m / sb); % number of blocks
 nrem = m - nb * sb;
 if nrem > 0
  nb = nb + 1;
 end % if
 
 % computation of the basis vectors
 
 ddc = [0, 0, 0];
 if tyb == 0
  % first block (monomial basis)
  K = compute_basis(A,V(:,1),sb+1,0,zp);
  nK = norm(K(:,1));
  [Y,R12,R22,northog] = gm_bgssro(K(:,1)/nK,K(:,2:sb+1));
  dotprod = dotprod + sb;
  if northog > 0
   dotprod = dotprod + sb;
  end % if
  Y = [K(:,1)/nK Y];
  nr = size(R12,1) + size(R22,1);
  V(:,1:sb+1) = Y(:,1:sb+1);
  R(1,1) = nK;
  Rb = [R12; R22];
  R(1:nr,2:sb+1) = Rb;
  H(1:sb+1,1:sb) = R(1:sb+1,2:sb+1) / R(1:sb,1:sb);
  
 elseif (tyb == 1) || (tyb == 2)
%   [K,H] = gm_Arnoldi(A,V(:,1),sb+1,'noreorth','noprint');
  [K,H] = Arnoldi_CGS(A,V(:,1),sb+1,'reorth','noprint');
 end % if tyb
 
 if tyb == 1
  % compute the Newton shifts
  zp = Newton_points(H(1:sb,1:sb),sb+1);
 elseif tyb == 2
  % compute the Chebyshev coefficients
  [zp,dd,dc,cc] = Cheby_coef(H(1:sb,1:sb),sb+1);
  ddc = [dd, dc, cc];
 end % if
 iconv = 0;
 
 % other blocks
 if iconv ~= 1
  for k = 1:nb
   reorth = false; % ?????
   cd = (k - 1) * sb + 1;
   cf = k * sb;
   ss = sb;
   if (nrem > 0) && (k == nb)
    cf = m;
    ss = m - sb * (k - 1);
   end % if
   nu = zeros(1,ss);
   Bs = zeros(ss+1,ss);
   for j = 2:ss+1
    Bs(j,j-1) = 1;
   end % for j
   sk1 = sb * (k - 1);
   sk = sk1 + ss;
   %     if k == 1
   %      vstart = V(:,sk1+1);
   %     else
   %       vstart = sum(V(:,sb*(k-2)+1:sk1+1),2);
   %       vstart = vstart / norm(vstart);
   %     end % if k
   vstart = V(:,sk1+1);
   %     [K,B] = compute_basis(A,V(:,sk1+1),ss+1,tyb,zp,ddc);
   [K,B] = compute_basis(A,vstart,ss+1,tyb,zp,ddc);
   Vbp = K(:,2:ss+1);
   for j = 1:ss
    nu(j) = norm(Vbp(:,j));
   end % for j
   Xb = V(:,1:cd)' * Vbp;
   dotprod = dotprod + cd * ss;
   X = Xb(:,1:ss-1);
   Vbp = Vbp - V(:,1:cd) * Xb;
   [Qt,R2b] = gm_signqr(Vbp);
   R2 = R2b(1:ss-1,1:ss-1);
   
   V(:,cd+1:cf+1) = Qt;
   Zb = [zeros(sk1,1) Xb(1:sk1,:)];
   Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
   XR = -X / R2;
   R2i = inv(R2); % R2 may be close to singular
   Z = [zeros(sk1,1) XR(1:sk1,:)];
   W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
   for j = 1:ss
    % the following test may not be needed, could somtimes set reorth = false
    % reorthogonalization is costly
    if R2b(j,j) <= (0.5 * nu(j))
     reorth = true;
     if iprint == 1
      fprintf('\n reorth needed k = %d, j = %d, R2b = %12.5e, bound = %12.5e \n',k,j,R2b(j,j),(0.5*nu(j)))
     end % if
    end % if
   end % for j
   if reorth && (ss > 1)
    % reorthogonalization
    nreo = nreo + 1;
    ZZb = V(:,1:cd)' * Qt;
    dotprod = dotprod + cd * size(Qt,2);
    ZZ = ZZb(:,1:ss-1);
    Qt = Qt - V(:,1:cd) * ZZb;
    [QQt,R2bh] = gm_signqr(Qt);
    V(:,cd+1:cf+1) = QQt;
    Xb = ZZb * R2b + Xb;
    X = ZZ * R2 + X;
    R2b = R2bh * R2b;
    R2 = R2b(1:ss-1,1:ss-1);
    Zb = [zeros(sk1,1) Xb(1:sk1,:)];
    Wb = [1 Xb(sk1+1,:); zeros(ss,1) R2b];
    XR = -X / R2;
    R2i = inv(R2);
    Z = [zeros(sk1,1) XR(1:sk1,:)];
    W = [1 XR(sk1+1,:); zeros(ss-1,1) R2i];
   end % if
   if tyb == 0
    % top part
    H(1:sk1,sk1+1:sk) = H(1:sk1,1:sk1) * Z + Zb(:,2:ss+1) * W; % true only for monomial basis
    h0 = H(sk1+1,1:sk1) * Z;
    WW = Wb(:,2:ss+1) * W;
    WW(1,:) = WW(1,:) + h0;
    % bottom part = WW
    H(sk1+1:sk+1,sk1+1:sk) = WW;
   else
    % Newton and others
    sZb = size(Zb);
    sW = size(W);
    H(1:sk1,sk1+1:sk) = H(1:sk1,1:sk1) * Z + Zb * B(1:sZb(2),1:sW(1)) * W;
    h0 = H(sk1+1,1:sk1) * Z;
    sWb = size(Wb);
    WW = Wb * B(1:sWb(2),1:sW(1)) * W;
    WW(1,:) = WW(1,:) + h0;
    H(sk1+1:sk+1,sk1+1:sk) = WW;
   end % if tyb
   
   % compute nu and test convergence
   for kk = sk1+1:sk
    nit = nit + 1;
    nic = nic + 1;
    nuu(kk+1) = -nuu(1:kk) * H(1:kk,kk) / H(kk+1,kk);
    snuu = snuu + abs(nuu(kk+1))^2;
    nresidu = nr0 / sqrt(snuu);
    resn(nit+1) = nresidu;
    resid = nresidu^2;
    matvec = matvec + 1;
    % dotprod ????
    matv(nit+1) = matvec;
    
    if iprint == 1
     fprintf('cycle = % d, block = %d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,k,nit,nresidu,nresidu/sqrt(r0))
    end
    
    if trueres == 1 || l2norm == 1
     % computation of the true (if left = 0) residual norm
     % triangular solve
     [QQ,RQ] = qr(H(1:kk+1,1:kk),0); % this is costly, us QR update?
     %    [QQ,RQ,flag] = gm_cholQR2(H(1:kk+1,1:kk));
     y = RQ(1:kk,1:kk) \ (QQ' * rhs(1:kk+1));
     xx = x0 + V(:,1:kk) * y;
     if left == 0
      % right preconditioner
      xx = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
     end % if left
     % this is also not the true residual norm if there is some scaling
     if trueres == 1
      resnt(nit+1) = norm(b - A * xx);
     end % if
     if l2norm == 1
      norml2(nit+1) = norm(xec -xx);
     end % if
    end % if trueres
    
    % convergence test or too many iterations
    if nresidu < (epsi * sqrt(r0)) || nit >= nitmax
     % convergence
     iconv = 1;
     %       fprintf('\n convergence or stop iteration %d \n',ni)
     break
    end % if
   end % for kk
   
   if iconv == 1
    break
   end %if
   
  end % for k
  
 end % if ~iconv
 
 % computation of the solution at the end of the cycle
 % triangular solve
 [QQ,RQ] = qr(H(1:nic+1,1:nic),0);
 %  [QQ,RQ] = gm_cholQR2(H(1:nic+1,1:nic));
 y = RQ(1:nic,1:nic) \ (QQ' * rhs(1:nic+1));
 x = x0 + V(:,1:nic) * y;
 
 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
  end % if left
  % ------ exit
  resn = resn(1:nit+1);
  
  if trueres == 1
   resnt = resnt(1:nit+1);
  end
  if l2norm == 1
   norml2 = norml2(1:nit+1);
  end % if
  % return code
  iret= 0;
  if nit == nitmax
   iret = 2;
  end
  
  if iprint == 1
   if nit == nitmax
    fprintf('\n No convergence after %d iterations \n',nit)
   else
    fprintf('\n Convergence after %d iterations \n',nit)
   end % if
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
   if  reorth > 0
    fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   end
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
  end % if iprint
  
  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  else
   results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  end % if timing
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end
  
  results.resn = resn;
  if trueres == 1
   results.resnt = resnt;
  end % if
  if l2norm == 1
   results.norml2 = norml2;
  end % if
  
  return
  
 end % if iconv
 
 % we have not converged yet, compute the residual and restart
 
 xx = x;
 if left == 0
  % right preconditioner
  xx = gm_solve_precond_ns(A,x,precond,cprec,cprec_amg);
 end % if left
 
 % residual vector
 r = b - A * xx;
 matvec = matvec + 1;
 
 if left == 1
  % left preconditioner
  % generalized residual M z = r
  z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 else
  z = r;
 end % if left
 
 r = z;
 
 x0 = x;
 rk = r' * r;
 nr = rk;
 resid = rk;
 bet = norm(r);
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 
 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,bet,bet/nb)
 end % if
 
end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
resn = resn(1:nit);

if trueres == 1
 resnt = resnt(1:nit);
end % if
if l2norm == 1
 norml2 = norml2(1:nit);
end % if
if nit == nitmax
 iret = 2;
end % if

xx = x;
if left == 0
 % right preconditioner
 x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
end % if left

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
 if reorth > 0
  fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 end % if
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end % if
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
end % if timing

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end % if

results.resn = resn;
if trueres == 1
 results.resnt = resnt;
end % if
if l2norm == 1
 results.norml2 = norml2;
end % if

% warning on

return

 function [K,T] = compute_basis(A,v,bls,tyb,zp,ddc);
  % Local basis vectors
  
  T = [];
  switch tyb
   case 0
    K = monom(A,v,bls);
   case 1
    [K,T] = Newton(A,v,bls,zp);
    T = T(1:bls+1,1:bls);
   case 2
    dd = ddc(1);
    dc = ddc(2);
    cc = ddc(3);
    [K,T] = Cheby(A,v,bls,zp,dd,dc,cc);
    T = T(1:bls+1,1:bls);
   case 3
    [K,T] = QOR_basis(A,v,bls);
    T = T(1:bls+1,1:bls);
   case 4
    [K,T] = Arnoldi_CGS(A,v,bls+1,'noreo','noprint');
    T = T(1:bls+1,1:bls);
   otherwise
    K = monom(A,v,bls);
  end % switch
  K = K(:,1:bls);
  
 end % function compute_basis

 function K = monom(A,v,bls);
  % computes  the (not normalized) Krylov vectors for matrix A and vector v
  
  K = zeros(size(A,1),bls);
  K(:,1) = v;
  
  for kkk = 2:bls
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * K(:,kkk-1);
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
    z = gm_solve_precond_ns(A,K(:,kkk-1),precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   K(:,kkk) = Av;
  end % for kkk
  
 end % function monom

 function zp = Newton_points(HH,bls)
  
  % Ritz values
  eigH = eig(full(HH));
  
  % pit?????
  pit = size(HH,1);
  sensitivity = 0;
  
  % get rid of the sensitive Ritz values
  if sensitivity == 1
   [XRR,eH] = eig(full(HH));
   eH = diag(eH);
   [XL,eHT] = eig(full(HH'));
   eHT = diag(eHT);
   sens_eig = zeros(1,pit);
   for j = 1:pit
    la = eH(j);
    xR = XRR(:,j);
    % find the complex conjugate for HH'
    for jj = 1:pit
     if abs(la' - eHT(jj)) < 1e-5
      cjj = jj;
      xL = XL(:,jj);
      break
     end % if
    end % for jj
    sens_eig(j) = 1 / abs(xR' * xL);
   end %for j
   [sens,I] = sort(sens_eig,'ascend');
   msens = fix(pit / 2);
   I = I(1:msens);
   eigm = eH(I);
   j = 0;
   for jj = 1:msens
    if isreal(eigm(jj))
     j = j + 1;
     eigH(j) = eigm(jj);
    else
     j = j + 1;
     eigH(j) = eigm(jj);
     j = j + 1;
     eigH(j) = conj(eigm(jj));
    end
   end % for jj
   eigH = eigH(1:j);
   eigH = gm_unique(eigH);
  end % for sensitivity
  
  %-----------------test if the eigenvalues are real
  if isreal(eigH)
   
   % get fast Leja points on the interval
   zp = gm_leja_shift(min(eigH),max(eigH),bls+1);
   
   xp = zp;
   yp = imag(zp);
   
  else
   % Fast Leja points on spoke sets
   ds = gm_compress_R(eigH);
   % first point
   [leja,cpts,scalefactor] = gm_lejashifts_R(ds);
   % add p-1 points
   [leja,cpts] = gm_lejashifts_R([],bls-1,leja,cpts,scalefactor);
   if nargin > 1
    leja = sort(leja);
   end
   shift = gm_expand_R(leja,bls);
   xp = real(shift);
   yp = imag(shift);
   zp = shift;
   if size(zp,1) > bls
    if imag(zp(1)) == 0
     zp = zp(2:end);
    end % if imag
   end % if size
   
  end % if isreal
  
 end % function Newton_points

 function [K,T] = Newton(A,v,bls,zp)
  
  K = zeros(size(A,1),bls);
  K(:,1) = v;
  kkk = 1;
  
  while kkk <= bls
   
   compl = ~isreal(zp(kkk));
   s = real(zp(kkk));
   
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * K(:,kkk);
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
    z = gm_solve_precond_ns(A,K(:,kkk),precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   w = Av;
   
   vv = w - s * K(:,kkk);
   nvv = norm(vv);
   dotprod = dotprod + 1;
   K(:,kkk+1) = vv / nvv;
   T(kkk,kkk) = s;
   T(kkk+1,kkk) = nvv;
   kkk = kkk + 1;
   
   if compl && kkk <= bls
    
    % matrix-vector product
    if left == 1
     % left preconditioner
     Av = A * K(:,kkk);
     % solve of M z = Av
     z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
     Av = z;
    else % if left (right preconditioner)
     z = gm_solve_precond_ns(A,K(:,kkk),precond,cprec,cprec_amg);
     Av = A * z;
    end % if left
    matvec = matvec + 1;
    w = Av;
    
    si2 = imag(zp(kkk))^2 ;
    vv = w - s * K(:,kkk) + (si2 / nvv) * K(:,kkk-1);
    nvv_old = nvv;
    nvv = norm(vv);
    dotprod = dotprod + 1;
    K(:,kkk+1) = vv / nvv;
    T(kkk,kkk) = s;
    T(kkk+1,kkk) = nvv;
    T(kkk-1,kkk) = -si2 / nvv_old;
    kkk = kkk + 1;
    
   end % if compl
   
  end % while kkk
  
  return
  
 end % function Newton

 function [alpC,dd,dc,cc] = Cheby_coef(HH,bls)
  
  pit = size(HH,1);
  pseudo = 0;
  if pseudo == 0
   % Ritz values
   eigH = eig(full(HH));
  else
   pslevel = 1;
   [ps_pts,eigHH] = gm_pseudo_points(HH,20,pslevel);
   eigH = ps_pts(:,1) + 1i * ps_pts(:,2);
   eigH = [eigH; eigHH];
  end % if pseudo
  
  sensitivity = 0;
  % get rid of the sensitive Ritz values
  if sensitivity == 1
   [XRR,eH] = eig(full(HH));
   eH = diag(eH);
   [XL,eHT] = eig(full(HH'));
   eHT = diag(eHT);
   sens_eig = zeros(1,pit);
   for j = 1:pit
    la = eH(j);
    xR = XRR(:,j);
    % find the complex conjugate for HH'
    for jj = 1:pit
     if abs(la' - eHT(jj)) < 1e-5
      cjj = jj;
      xL = XL(:,jj);
      break
     end % if
    end % for jj
    sens_eig(j) = 1 / abs(xR' * xL);
   end %for j
   [sens,I] = sort(sens_eig,'ascend');
   if pseudo == 0
    msens = fix(pit / 2);
    I = I(1:msens);
    eigm = eH(I);
    j = 0;
    for jj = 1:msens
     if isreal(eigm(jj))
      j = j + 1;
      eigH(j) = eigm(jj);
     else
      j = j + 1;
      eigH(j) = eigm(jj);
      j = j + 1;
      eigH(j) = conj(eigm(jj));
     end
    end % for jj
    eigH = eigH(1:j);
    eigH = gm_unique(eigH);
   end % if pseudo
  end % for sensitivity
  
  %-----------------test if the eigenvalues are real
  if isreal(eigH)
   cx = (min(eigH) + max(eigH)) / 2;
   cy = 0;
   aa = max(eigH) - min(eigH);
   bb = 0;
   % center
   dd = cx;
   cc = aa / 2;
   % foci
   f1 = dd - cc;
   f2 = dd + cc;

   
  else
   % get the enclosing ellipse
   [cx,cy,aa,bb,count] = gm_best_ellipse(real(eigH),imag(eigH),1e-3);   
   % correction of the center if H is real
   if isreal(H)
    cy = 0;
   end
   
   cc = sqrt(aa^2 - bb^2);
   % center
   dd = cx + 1i * cy;
   % foci
   f1 = dd - cc;
   f2 = dd + cc;
   
   if isreal(cc) && cc == 0
    error(' Cheby_coef, the ellipse is a circle')
   end
   
  end % if isreal(eigH)
  
  % computation of the coefficients of the Chebyshev recurrence
  dc = dd / (cc + 1e-20);
  alpC = zeros(bls+2,1);
  alpC(1) = 1;
  alpC(2) = dc;
  for j = 3:bls+2
   alpC(j) = 2 * dc * alpC(j-1) - alpC(j-2);
  end % for j
  
 end % function Cheby_coef

 function [K,T] = Cheby(A,v,bls,alpC,dd,dc,cc)
  
  K = zeros(size(A,1),bls);
  K(:,1) = v / norm(v);
  
  for kkk = 1:bls
   
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * K(:,kkk);
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
    z = gm_solve_precond_ns(A,K(:,kkk),precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   w = Av;
   
   % Chebyshev polynomial
   if kkk == 1
    vv = v - (1 / dd) * w;
    nvv = norm(vv);
    nvv_old = 1;
    dotprod = dotprod + 1;
    K(:,kkk+1) = vv / nvv;
    T(1,1) = dd;
    T(2,1) = -dd * nvv;
   else
    chi = 1 / (2 * dc - alpC(kkk) / alpC(kkk+1));
    xi = 1 / ( 2 * dc * (alpC(kkk+1) / alpC(kkk))- 1);
    vv = (2 * dc * chi * K(:,kkk) - 2 * (chi / cc) * w) * nvv - xi * K(:,kkk-1) * nvv_old;
    nvv_new = norm(vv);
    dotprod = dotprod + 1;
    K(:,kkk+1) = vv / nvv_new;
    T(kkk,kkk) = dd;
    cchi = cc / (2 * chi);
    T(kkk-1,kkk) = -cchi * xi * nvv_old / nvv;
    T(kkk+1,kkk) = -cchi * nvv_new / nvv;
    nvv_old = nvv;
    nvv = nvv_new;
   end % if kkk
  end % for kkk
  
 end % function Cheby

 function [K,B] = QOR_basis(A,v,bls);
  
  % init basis vectors
  K = zeros(n,bls+1);
  % array L is the inverse of the matrix L (Cholesky factor of V^T V)
  L = zeros(bls+1,bls+1);
  % init B
  B = zeros(bls+1,bls);
  % the first vector is the last residual normalized
  v = v / norm(v);
  K(:,1) = v;
  
  % matrix-vector product A v 
  if left == 1
   % left preconditioner
   Av = A * v;
   % solve of M z = Av
   z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
   Av = z;
  else % if left (right preconditioner)
   z = gm_solve_precond_ns(A,v,precond,cprec,cprec_amg);
   Av = A * z;
  end % if left
  % we do not count this one because there is a matvec at the end of the
  % iterations
  %  matvec = matvec + 1;
  
  L(1,1) = 1;
  
  % start QORm(bls)
  
  for kkk = 1:bls
   
   % construction of the basis vectors
   % and entries of H (in the last column of H)
   
   if kkk == 1
    % first iteration
    % choose the optimal value for the first column of H
    v = K(:,1);
    vAv = v' * Av;
    vAAv = Av' * Av;
    dotprod = dotprod + 2;
    
    if abs(vAv) <= 1e-14
     % breakdown
     fprintf('\n QORmc: Initialization breakdown, v^T A v = %g \n',vAv)
     B(1,1) = 0;
    else
     B(1,1) = vAAv / vAv;
    end % if abs
    
    % new basis vector (to be normalized)
    vt = Av - B(1,1) * K(:,1);
    B(2,1) = norm(vt);
    dotprod = dotprod + 1;
    % new basis vector
    K(:,2) = vt / B(2,1);
    Vko = K(:,1);
    Vk = K(:,1:2);
    v = K(:,2);
    
    % matrix-vector product
    if left == 1
     % left preconditioner
     Av = A * K(:,2);
     % solve of M z = Av
     z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
     Av = z;
    else % if left (right preconditioner)
     z = gm_solve_precond_ns(A,K(:,2),precond,cprec,cprec_amg);
     Av = A * z;
    end % if left
    matvec = matvec + 1;
    
   else % kkk ~= 1
    
    % other iterations
    AvAv = Av' * Av;
    % 2 independant dense matrix-vector products
    vkv = (v' * Vko)'; % this is to avoid the transpositions of Vko and Vk
    vktA = Vk' * Av;
    vktA(kkk) = v' * Av;
    dotprod = dotprod + 2 * kkk;
    
    % inverse of L_k
    lk = L(1:kkk-1,1:kkk-1) * vkv;
    matvec = matvec + 2;
    ykt = lk' * L(1:kkk-1,1:kkk-1);
    lkt = lk' * lk;
    dotprod = dotprod + 1;
    % diagonal entry
    if lkt >=1
     pknu = Vko * ykt';
     dotprod = dotprod + n;
     lkk = norm(K(:,kkk) - pknu);
     dotprod = dotprod + 1;
    else
     lkk = sqrt(1 - lkt);
    end % if lkt
    
    % what to do if lkk is small?
    if lkk < 1e-10
     if iprint == 1
      fprintf('\n QORm: The diagonal entry of L is small = %g at step %d \n',lkk,kkk)
     end
    end
    % new row of the inverse of the Cholesky factor
    L(kkk,1:kkk) = [-ykt / lkk, 1 / lkk];
    
    lA = L(1:kkk,1:kkk) * vktA;
    s = L(1:kkk,1:kkk)' * lA;
    
    alp = AvAv - lA' * lA;
    dotprod = dotprod + 1;
    
    % new column of H
    if abs(vktA(kkk)) <= 0
     %     if iprint == 1
     fprintf('\n QORm: Breakdown step %d, value = %g \n',kkk,vktA(kkk))
     %     end
     return
    else
     beta = alp / vktA(kkk);
     B(1:kkk,kkk) = s;
     B(kkk,kkk) = B(kkk,kkk) + beta;
    end % if vktA
    
    % new basis vector (to be normalized)
    vt = Av - Vk * B(1:kkk,kkk);
    h = norm(vt);
    dotprod = dotprod + 1;
    
    % subdiagonal entry of B
    B(kkk+1,kkk) = h;
    
    if kkk < bls
     % new basis vector
     v = vt / h;
     K(:,kkk+1) = v;
     Vko = Vk;
     Vk = [Vk v];
     
     % matrix-vector product (n x n)
     if left == 1
      % left preconditioner
      Av = A * v;
      % solve of M z = Av
      z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
      Av = z;
     else % if left (right preconditioner)
      z = gm_solve_precond_ns(A,v,precond,cprec,cprec_amg);
      Av = A * z;
     end % if left
     matvec = matvec + 1;
     
    end % if kkk < bls
   end % if kkk == 1
   
  end % for kk
  
 end % function QOR_basis

 function [V,H] = Arnoldi_CGS(A,u,nitmax,reorths,prints);
  %ARNOLDI_CGS Arnoldi iteration for a matrix A, classical Gram-Schmidt
  
  n = size(A,1);
  
  timing = 0;
  if nargin < 3
   nitmax = n;
  else
   if nitmax < 0
    nitmax = -nitmax;
    timing = 1;
   end
  end
  
  if strcmpi(reorths,'reorth') == 1
   reorth = 1;
  else
   reorth = 0;
  end
  
  if strcmpi(reorths,'sorth') == 1
   sorth = 1;
  else
   sorth = 0;
  end
  
%   if strcmpi(prints,'print') == 1
%    iprint = 1;
%   else
%    iprint = 0;
%   end
  
  u = u / norm(u);
  v = u;
  
  H = sparse(nitmax,nitmax);
  V = zeros(n,nitmax);
  V(:,1) = v;
  lorth = 0.8;
  
  %-----------------------------------Iterations
  
  for ka = 1:nitmax
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * V(:,ka);
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
    z = gm_solve_precond_ns(A,V(:,ka),precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   w = Av;
   
   matvec = matvec + 1;
   
   if sorth == 1
    % for selective reorthogonalization
    gin = norm(w);
    dotprod = dotprod + 1;
   end % if sorth
   
   % construction of the basis vectors (classical Gram-Schmidt)
   % and entries of H (into the last column of H)
   for l = 1:ka
    gl = V(:,l)' * Av;
    H(l,ka) = gl;
    w = w - gl * V(:,l);
   end % for l
   dotprod = dotprod + ka;
   dk = w;
   
   % reorthogonalization (twice is enough)
   if reorth == 1
    ww = w;
    nreo = nreo + 1;
    for j = 1:ka
     alpha = V(:,j)' * ww;
     w = w - alpha * V(:,j);
     H(j,ka) = H(j,ka) + alpha;
    end % for j
    dotprod = dotprod + ka;
    ww = w;
    for j = 1:ka
     alpha = V(:,j)' * ww;
     w = w - alpha * V(:,j);
     H(j,ka) = H(j,ka) + alpha;
    end % for j
    dotprod = dotprod + ka;
    dk = w;
   end % if reorth
   
   % selective reorthogonalization
   if (sorth == 1) && (norm(w) < lorth * gin)
    nreo = nreo + 1;
    ww = w;
    % reorthogonalization
    for j = 1:ka
     alpha = V(:,j)' * ww;
     w = w - alpha * V(:,j);
     H(j,ka) = H(j,ka) + alpha;
    end % for j
    dotprod = dotprod + ka;
    % twice
    ww = w;
    for j = 1:ka
     alpha = V(:,j)' * ww;
     w = w - alpha * V(:,j);
     H(j,ka) = H(j,ka) + alpha;
    end % for j
    dotprod = dotprod + ka;
    dk = w;
   end % if selective reorth
   
   % normalization of the new vector
   gk = norm(dk);
   dotprod = dotprod + 1;
   dk1 = dk / gk;
   H(ka+1,ka) = gk;
   % next basis vector
   V(:,ka+1) = dk1;
   
  end % for ka
  
  
 end % Arboldi_CGS

end % function
