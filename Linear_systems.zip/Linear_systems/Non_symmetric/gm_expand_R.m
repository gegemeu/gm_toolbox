function d=gm_expand_R(shft,np)
%GM_EXPAND_R expands the array shft into complex d 
% conjugate pairs (by assumption, only non negative numbers are in shft)

% code from L. Reichel

n = max(size(shft));
if nargin > 1
 n = np;
end
d = [];
nd = 0;

for k = 1:n
 d = [d; complex(shft(k,1),shft(k,2))] ;
 nd = nd + 1;
 if shft(k,2) > 0
  d = [d; complex(shft(k,1),-shft(k,2))];
  nd = nd + 1;
  if nargin > 1
   if nd >= np
    break
   end % if nd
  end % if nargin
 end
end
