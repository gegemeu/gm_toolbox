function [A,b,Dr,Uh,lamb,V,Cn]=gm_presc_convGMRES_2(f,lamb,V,Ritz);
%GM_PRESC_CONVGMRES_2 computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
% the full GMRES method is applied to (A,b). The Ritz values can also be prescribed

% A simpler construction from 
% G. Meurant, The FOM and GMRES residual polynomials, SIMAX, v 38 n 1 (2017), pp. 96-117

% Input:
% f = the n prescribed GMRES residual norms  (must be decreasing)
% lamb = the n nonzero eigenvalues of A
% V = a given unitary matrix
% Ritz = an upper triangular matrix Ritz of order n-1 containing the prescribed Ritz
%      values. They must be different from zero

% Output:
% A,b = the matrix and the right-hand side
% Dr,Uh = the matrix A satisfies A = V Dr inv(Uh) Cn Uh inv(Dr) V^*
%        where Cn is the companion matrix for the prescribed eigenvalues
% lamb = eigenvalues of A
% V = unitary matrix
% Cn = companion matrix
%
% if lamb and V are not given they are chosen randomly
%

% Note that the Ritz values must not be to sensitive to changes in the 
% coefficients of the polynomial. Otherwise, the results are polluted by 
% rounding errors. That is, we must have
%   roots(poly(coeff)) not too much different from coeff

%
% Author G. Meurant
% August 2016
%

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default');

n = length(f);

if nargin == 1
 % the eigenvalues are not prescribed
 % generate complex conjugate eigenvalues
 m = fix(n / 2);
 lamb1 = randn(m,1) + i * randn(m,1);
 if 2 * m == n
  lamb = [lamb1; conj(lamb1)];
 else
  lamb = [lamb1; conj(lamb1); randn];
 end
end

if nargin <= 2
 % V is not prescribed
 V = gm_qrandn(n,n);
end

nV = size(V,1);
if nV ~= n
 error('gm_presc_convGMRES_2: The size of V has to be compatible with the size of f')
end

if norm(V' * V - eye(n)) > 1e-12
 error('gm_presc_convGMRES_2: The matrix V is not unitary')
end

prescritz = 1;
if nargin < 4
 % No prescribed Ritz values
 prescritz = 0;
end

if prescritz == 0
 % The Ritz values are not prescribed
 Uh = triu(randn(n,n));
 % first row of U
 Uh(1,1:n) = ones(1,n);

 % inverses of FOM residual norms
 rF = zeros(1,n);
 rF(1) = 1 / f(1);
 for j = 2:n
  rF(j) = sqrt(1 / f(j)^2 - 1 / f(j-1)^2);
  % the diagonal entries of U must be > 0
  Uh(j,j) = abs(Uh(j,j));
 end
 
 if any(rF == 0)
 error('gm_presc_convGMRES_2: There must be no stagnation')
 end
 
 Dr = diag(1 ./ rF);
 Dri = diag(rF);
 
 % companion matrix of the eigenvalues of A
 Cn = gm_companionmat(lamb);
 
 Y = (Uh \ Cn) * Uh;
 
 Y = Dr * Y * Dri;
 A = (V * Y) / V;
 b = f(1) * V(:,1);
 
else
 % The Ritz values are prescribed
 
 % Compute the coefficients of the FOM residual polynomials from the
 % Ritz values
 Xi = zeros(n,n-1);
 for j = 1:n-1
  y = transpose(poly(Ritz(1:j,j)));
  if y(j+1) == 0
   error('gm_presc_convGMRES_2: There must be no zero Ritz value')
  end
  y = y / y(j+1);
  Xi(1:j+1,j) = y(j+1:-1:1);
 end
 
 Uh(2:n,2:n) = Xi(2:n,1:n-1);
 % first row of U
 Uh(1,1:n) = ones(1,n);

 % inverses of FOM residual norms
 rF = zeros(1,n);
 rF(1) = 1 / f(1);
 for j = 2:n
  rF(j) = sqrt(1 / f(j)^2 - 1 / f(j-1)^2);
 end
 
 if any(rF == 0)
 error('gm_presc_convGMRES_2: There must be no stagnation')
 end
 
 Dr = diag(1 ./ rF);
 Dri = diag(rF);
 
 % companion matrix of the eigenvalues of A
 Cn = gm_companionmat(lamb);
 
 Y = (Uh \ Cn) * Uh;
 
 Y = Dr * Y * Dri;
 A = (V * Y) / V;
 b = f(1) * V(:,1);

end

