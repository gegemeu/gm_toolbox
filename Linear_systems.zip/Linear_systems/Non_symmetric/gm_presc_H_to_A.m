function [A,b,tH] = gm_presc_H_to_A(H,bnorm,V,m,N);
%GM_PRESC_H_TO_A creates linear system Ax=b with prescribed GMRES residual norms
% norms for N cycles of GMRES(m) where the system is of dimension n and N*m < n

% Input:
% H = square upper Hessenberg of order n
% bnorm = || b ||
% V = unitary matrix of order n
%
% Output:
% A,b = matrix and right-hand side
% tH = upper Hessenberg matrix


%
% Author J. Duintjer Tebbens
% Aug 2014
% and G. Meurant
% July 2015
%

n = size(V,1);
b = zeros(n,1);
b(1) = bnorm;
b = V * b;

chi = zeros(N,m+1);
chi(1,1) = 1 / bnorm;

for k = 1:N
 [chi(k,:),rn] = gm_presc_H_to_chi(H((k-1)*m+1:k*m+1,(k-1)*m+1:k*m),chi(k,1));
 chi(k+1,1) = rn(m+1);
end % for k

Horig = H;

Xold = eye(n);

for k = 2:N
 Chi(:,k-1) = chi(k-1,:)' / chi(k,1);
 Xk = 0 * eye(n);
 Xk(1:m+1,1) = Chi(:,k-1);
 Xk(m+2:n,2:n-m) = eye(n-m-1);
 Xnew = Xold * Xk;
 tkm1 = zeros(n,1);
 if abs(Chi(m+1,k-1)) > 1e-10
  tkm1(1:m+1) = (H((k-1)*m+1,(k-1)*m+1) * Chi(:,k-1) ...
   - Horig((k-2)*m+1:(k-1)*m+1,(k-2)*m+1:(k-1)*m) * Chi(1:m,k-1)) / Chi(m+1,k-1);
  tkm1(m+2) = (H((k-1)*m+2,(k-1)*m+1) / Chi(m+1,k-1));
 end % if
 H(:,(k-1)*m+1) = Xold * tkm1;
 Haux = zeros(n,m-1);
 Haux(1:m+1,:) = Horig((k-1)*m+1:(k)*m+1,(k-1)*m+2:(k)*m);
 H(:,(k-1)*m+2:(k-1)*m+m) = Xnew * Haux;
 Xold = Xnew;
end % for k

% fill remaining columns of H with random entries 
H(:,N*m+1) = randn(n,1);
H(N*m+2:n,N*m+2:n) = triu(randn(n-N*m-1,n-N*m-1));
H(1:N*m+1,N*m+2:n) = randn(N*m+1,n-N*m-1);
aux = zeros(n-1,1);
aux(N*m+1:n-1 )= randn(n-N*m-1,1);

H = H + spdiags(aux,-1,n,n);

A = V * H * V';

tH = H;

