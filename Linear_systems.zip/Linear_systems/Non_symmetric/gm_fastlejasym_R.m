function [cpoints,leja]=gm_fastlejasym_R(cpoints,leja,nmbnlpts,scalefactor)
%GM_FASTLEJASYM_R add Leja points

% add nmbnlpts Leja points on convex hull of point set defined by the
% array cpoints with entries:
%   1st column contain the x-coordinate,
%   2nd column contains the y-coordinate,
%   3th column contains the index (row number) for the previous point on
%     the convex hull traversed clockwise,
%   4th column contains the index (row number) for the next point on
%     the convex hull traversed clockwise,
%   5th column: entry 1 if Leja point; 0 otherwise.
%
% at least one fast Leja point is stored in leja on entry. new Leja points
% are added pairwise if they have nonzero y-coordinate.
%
% compute product with available Leja points

% code from L. Reichel

z = complex(cpoints(:,1),cpoints(:,2));

nmblpts = size(leja,1);
nmbcpts = size(cpoints,1);

prd = ones(nmbcpts,1);
for j = 1:nmblpts
 if leja(j,2) ~= 0
  % complex point
  prd = prd .* (z - complex(leja(j,1),leja(j,2))) / scalefactor;
  prd = prd .* (z - complex(leja(j,1),-leja(j,2))) / scalefactor;
 else
  % real point
  prd = prd .* (z - leja(j,1)) / scalefactor;
 end % if leja
end % for j

for npts = 1:nmbnlpts
 % determine new fast Leja point
 [mxprd,lptidx] = max(abs(prd));
 
 % update matrices leja and cpoints
 leja = [leja; cpoints(lptidx,1) cpoints(lptidx,2)];
 cpoints(lptidx,5) = 1;
 
 % add new cpoint after chosen leja-point location, unless y-coordinate zero.
 if cpoints(lptidx,3) > 0
  preptidx = cpoints(lptidx,3);
  cpoints = [cpoints; zeros(1,5)];
  nmbcpts = nmbcpts + 1;
  cpoints(nmbcpts,1) = 0.5 * (cpoints(lptidx,1) + cpoints(preptidx,1));
  cpoints(nmbcpts,2) = 0.5 * (cpoints(lptidx,2) + cpoints(preptidx,2));
  cpoints(nmbcpts,3) = preptidx;
  cpoints(nmbcpts,4) = lptidx;
  cpoints(preptidx,4) = nmbcpts;
  cpoints(lptidx,3) = nmbcpts;
  
  %   update products
  lastprd = 1;
  lastpt = complex(cpoints(nmbcpts,1),cpoints(nmbcpts,2));
  for j = 1:nmblpts
   lastprd = lastprd * (lastpt - complex(leja(j,1),leja(j,2))) / scalefactor;
   if leja(j,2) ~= 0
    lastprd = lastprd * (lastpt - complex(leja(j,1),-leja(j,2))) / scalefactor;
   end % if leja
  end % for j
  prd = [prd; lastprd];
  z = [z; lastpt];
 end % if cpoints
 
 % add new cpoint before chosen leja-point location, unless y-coordinate zero.
 if cpoints(lptidx,4) > 0
  sucptidx = cpoints(lptidx,4);
  cpoints = [cpoints; zeros(1,5)];
  nmbcpts = nmbcpts + 1;
  cpoints(nmbcpts,1) = 0.5 * (cpoints(lptidx,1) + cpoints(sucptidx,1));
  cpoints(nmbcpts,2) = 0.5 * (cpoints(lptidx,2) + cpoints(sucptidx,2));
  cpoints(nmbcpts,4) = sucptidx;
  cpoints(nmbcpts,3) = lptidx;
  cpoints(sucptidx,3) = nmbcpts;
  cpoints(lptidx,4) = nmbcpts;
  
  % update products
  lastprd = 1;
  lastpt = complex(cpoints(nmbcpts,1),cpoints(nmbcpts,2));
  for j = 1:nmblpts
   lastprd = lastprd * (lastpt - complex(leja(j,1),leja(j,2))) / scalefactor;
   if leja(j,2) ~= 0
    lastprd = lastprd * (lastpt - complex(leja(j,1),-leja(j,2))) / scalefactor;
   end % if leja
  end % for j
  prd = [prd; lastprd];
  z = [z; lastpt];
 end % if cpoints
 
 nmblpts = nmblpts + 1;
 if leja(nmblpts,2) ~= 0
  prd = prd .* (z - complex(leja(nmblpts,1),leja(nmblpts,2))) / scalefactor;
  prd = prd .* (z - complex(leja(nmblpts,1),-leja(nmblpts,2))) / scalefactor;
 else
  prd = prd .* (z - leja(nmblpts,1)) / scalefactor;
 end % if leja
 
end % for npts



