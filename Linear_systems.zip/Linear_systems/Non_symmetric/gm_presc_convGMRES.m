function [A,b,Dc,U,lamb,V,Cn]=gm_presc_convGMRES(f,lamb,V,Ritz);
%GM_PRESC_CONVGMRES Computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms when
% the full GMRES method is applied to (A,b). The Ritz values can also be prescribed

% See: J. Duintjer Tebbens and G. Meurant,
%        Any Ritz value behavior is possible for Arnoldi and for GMRES,
%        SIAM J. of Matrix Anal. and Appl., v 33 n 3, (2012), pp 958-978

% Input:
% f = the n prescribed GMRES residual norms  (must be decreasing)
% lamb = the n nonzero eigenvalues of A
% V = a given unitary matrix
% Ritz = an upper triangular matrix Ritz of order n-1 containing the prescribed Ritz
%      values, a column is allowed to contain a zero entry above the main diagonal only if
%      the corresponding prescribed residual norm coincides with the previous one (stagnation)

% Output:
% A,b = the matrix and the right-hand side
% Dc,U = the matrix A satisfies A = V * diag(f(1),Dc) * U^(-1) * Cn * U * diag(f(1),Dc)^(-1) * V^*
%        where Cn is the companion matrix for the prescribed eigenvalues
% lamb = eigenvalues of A
% V = unitary matrix
% Cn = companion matrix
%
% if lamb and V are not given they are chosen randomly
%

%
% Author J. Duintjer Tebbens
% July 2011
% and G. Meurant
% July 2015
%

% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setGlobalStream(s);
rng('default');

n = length(f);

if nargin == 1
 % the eigenvalues are not prescribed
 % generate complex conjugate eigenvalues
 m = fix(n / 2);
 lamb1 = randn(m,1) + i * randn(m,1);
 if 2 * m == n
  lamb = [lamb1; conj(lamb1)];
 else
  lamb = [lamb1; conj(lamb1); randn];
 end
end

if nargin <= 2
 % V is not prescribed
 V = gm_qrandn(n,n);
end

nV = size(V,1);
if nV ~= n
 error('gm_presc_convGMRES: The size of V has to be compatible with the size of f')
end

if norm(V' * V - eye(n)) > 1e-12
 error('gm_presc_convGMRES: The matrix V is not unitary')
end

prescritz = 1;
if nargin < 4
 % No prescribed Ritz values
 prescritz = 0;
end

if prescritz == 0
 % The Ritz values are not prescribed
 U = triu(randn(n,n));
 % first row of U
 rF = zeros(1,n);
 rF(1) = 1 / f(1);
 for j = 2:n
  rF(j) = sqrt(1 / f(j)^2 - 1 / f(j-1)^2);
  % the diagonal entries of U must be > 0
  U(j,j) = abs(U(j,j));
 end
 U(1,:) = rF;
 % companion matrix of the eigenvalues of A
 Cn = gm_companionmat(lamb);
 
 Y = (U \ Cn) * U;
 
 %  A = (V * Y) * V';
 A = (V * Y) * inv(V);
 b = f(1) * V(:,1);
 Dc = [];
 
else
 % The Ritz values are prescribed
 h = zeros(n,1);
 for j = 1:n-1
  h(j) = sqrt(f(j)^2 - f(j+1)^2);
 end
 h(n) = f(n);
 Ritz2 = zeros(n,n);
 Ritz2(1:n-1,1:n-1) = Ritz;
 % The last column contains the prescribed eigenvalues of A
 Ritz2(:,n) = lamb;
 Ritz = Ritz2;
 [U,Cn] = gm_RitzCompTrans(Ritz);
 hh = h(1:n-1);
 Rh = chol(eye(n-1) - hh * hh' / f(1)^2);
 Rhmhh = (Rh') \ hh;
 J = find(Rhmhh);
 c = U(1,2:n);
 c = c';
 if length(find(c)) ~= length(J)
  error('gm_presc_convGMRES: Prescribed zero Ritz values do not correspond to prescribed stagnation')
 end
 dd = ones(n-1,1);
 dd(J) = -Rhmhh(J) ./ (c(J) * f(1)^2);
 Dc = diag(dd)^(-1);
 b = f(1) * V(:,1);
 D = diag([f(1); 1 ./ dd]);
 DD = diag([1 / f(1); dd]);
 AA = D * (U \ Cn) * (U * DD);
%  A = V * D * (U \ Cn) * U * (D \ V');
 A = (V * AA) * inv(V);
end

