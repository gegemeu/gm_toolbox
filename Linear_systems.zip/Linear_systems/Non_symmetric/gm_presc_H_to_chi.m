function [chi,rn]=gm_presc_H_to_chi(H,rn0);
%GM_PRESC_H_TO_CHI auxiliary function

n = size(H,2);
chi = zeros(1,n);

chi(1) = 1 / rn0;
rn = chi;
rn(1) = rn0;

for i = 2:n
 aux = chi(1:i-1) * H(1:i-1,i-1);
 chi(i) = -aux / H(i,i-1);
 rn(i) = sqrt(1 / (norm(chi)^2));
end
if size(H,1) > n
 i = n + 1;
 aux = chi(1:i-1) * H(1:i-1,i-1);
 chi(i) = -aux / H(i,i-1);
 rn(i) = sqrt(1 / (norm(chi)^2));
end