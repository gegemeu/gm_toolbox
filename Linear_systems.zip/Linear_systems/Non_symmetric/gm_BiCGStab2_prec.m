function [x,nit,iret,results] = gm_BiCGStab2_prec(A,b,x0,options,params);
%GM_BICGSTAB2_PREC preconditioned bi-conjugate gradient stabilized for a matrix A, Gutknecht's method

% see: M.H. Gutknecht, Variants of BICGSTAB for matrices with complex spectrum,
%                      SIAM J. Sci. Comput., v 14 n 5 (1993), pp. 1020-1033.

% Caution: one iteration of BiCGStab2 is like two iterations of BiCGStab

%
% Input:
% A = matrix
% b = right-hand side
% x0 = initial vector
%
% options is a structure which can contain the following fields:
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% left = 1 left preconditioning, otherwise right preconditioning
% scaling = 1, scales the matrix before preconditioning
% iprint = 1, prints residual norms
% timing = 1, with time measurements
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'gs' Gauss-Seidel
%  = 'ss' SSOR like with omega=1
%  = 'lu' Incomplete LU(0)
%  = 'lm' Matlab ILU(0)
%  = 'ld' Matlab ILU with drop threshold
%  = 'lb' block ILU
%  = 'ai' approximate inverse AINV
%  = 'tw' Tang and Wang approximate inverse
%  = 'sp' SPAI approximate inverse (Huckle and Grote)
%  = 'sh' or 'wl' ILU factorizations from V. Eijkhout
%  = 'gp' given preconditioner
%  = 'gm' GMRES iterations
%  = 'ml' multilevel (AMG)

% params = structure giving the parameter(s) needed by some preconditioners
%  if params is empty, default values are used
%  one or two fields if the preconditioner is not 'ml'
%
% params.p1
%  = empty for 'no', 'sc', 'gs', 'ss', 'lu', and 'lm'
%  = epsilon for 'ld'
%  = level for 'sh', 'wl'
%  = block size for 'lb'
%  = nb of GMRES iterations for 'gm'
%  = matrix M for 'gp'

% params.p1 and params.p2
%  = threshold and number of nonzero entries  in a column for 'ai'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' are in params as (default)
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)

% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv after nitmax iterations
% results is a structure with some of the following fields:
%  resn = (preconditioned) residual norms
%  resnt = true residual norms
%  norml2 = ell2-norm of the error if option l2norm = 1
%  time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%   times, the number of matrix-vector products, the number of inner products and the
%   number of matrix-vector products as a function of the iteration number,
%   otherwise same without the first two items
%

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin == 1
 error('gm_BiCGStab2_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_BiCGStab2_prec: Error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end % if
nx = length(x0);
if nlb ~= nx
 error('gm_BiCGStab2_prec: Error, the dimensions of x0 and b are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,~,scaling,trueres,iprint,precond,left,~,~,timing,l2norm] = gm_Krylov_ns_options(A,options);

if iprint == 1
 fprintf('\n gm_BiCGStab2_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  l2norm = %d \n',l2norm)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  timing = %g \n',timing)
end % if

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% -----------------------Initialization

if timing == 1
 tic;
end % if

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond_ns(A,precond,iprint,params);

x = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end
% this is useless
% if left == 0
%  x = gm_solve_precond_ns(A,x0,precond,cprec,cprec_amg);
% end % if left

% init residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end
if l2norm == 1
 norml2 = zeros(1,nitmax+1);
 xec = A \ b;
 norml2(1) = norm(xec -x);
end % if

resn = zeros(1,nitmax+1);

bb = b;
if left == 1
 % generalized residual M z = r
 z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 bb = gm_solve_precond_ns(A,b,precond,cprec,cprec_amg);
else
 z = r;
end % if left
nb = norm(bb);
nb2 = nb^2;

r = z;

r0 = z;
u = zeros(n,1);
alp = 1;
om2 = 1;
rho0 = 1;
r00 = r' * r;
nr = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',nr)
end

% number of iterations
nit = 0;
iconv = 0;
resn(1) = nr;
resid = realmax;
epss = epsi^2;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 
 % ---- Loop on iterations
 
 nit = nit + 1;
 
 % even BiCG step
 rho0 = -om2 * rho0;
 rho1 = r0' * r;
 dotprod = dotprod + 1;
 beta = alp * rho1 / rho0;
 rho0 = rho1;
 u = r - beta * u;
 
 % product A u
 if left == 1
  % left preconditioner
  xx= A * u;
  % solve of M z = xx
  v = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
 else % if left (right preconditioner)
  xx = gm_solve_precond_ns(A,u,precond,cprec,cprec_amg);
  v = A * xx;
 end % if left
 matvec = matvec + 1;
 
 gamma = r0' * v;
 dotprod = dotprod + 1;
 alp = rho0 / gamma;
 r = r - alp * v;
 
 % product A r
 if left == 1
  % left preconditioner
  xx= A * r;
  % solve of M z = xx
  s = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
 else % if left (right preconditioner)
  xx = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
  s = A * xx;
 end % if left
 matvec = matvec + 1;
 
 x = x + alp * u;
 
 % odd BiCG step
 rho1 = r0' * s;
 dotprod = dotprod + 1;
 beta = alp * rho1 / rho0;
 rho0 = rho1;
 v = s - beta * v;
 
 % product A v
 if left == 1
  % left preconditioner
  xx= A * v;
  % solve of M z = xx
  w = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
 else % if left (right preconditioner)
  xx = gm_solve_precond_ns(A,v,precond,cprec,cprec_amg);
  w = A * xx;
 end % if left
 matvec = matvec + 1;
 
 gamma = r0' * w;
 dotprod = dotprod + 1;
 alp = rho0 / gamma;
 u = r - beta * u;
 r = r - alp * v;
 s = s - alp * w;
 
 % product A s
 if left == 1
  % left preconditioner
  xx= A * s;
  % solve of M z = xx
  t = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
 else % if left (right preconditioner)
  xx = gm_solve_precond_ns(A,s,precond,cprec,cprec_amg);
  t = A * xx;
 end % if left
 matvec = matvec + 1;
 
 % GCR(2) step
 om1 = r' * s;
 mu = s' * s;
 nuu = s' * t;
 tau = t' * t;
 om2 = r' * t;
 dotprod = dotprod + 5;
 tau = tau - (nuu^2) / mu;
 om2 = (om2 - nuu * om1 / mu) /tau;
 om1 = (om1 - nuu * om2) / mu;
 x = x + om1 * r + om2 * s + alp * u;
 r = r - om1 * s - om2 * t;
 u = u - om1 * v - om2 * w;
 
 if trueres == 1 || l2norm == 1
  xx = x;
  if left == 0
   % right preconditioner
   xx = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
  end % if left
  % this is also not the true residual norm if there is some scaling
  if trueres == 1
   resnt(nit+1) = norm(b - A * xx);
  end % if
  if l2norm == 1
   norml2(nit+1) = norm(xec -xx);
  end % if
 end % if trueres
 
 % nresidu is the estimate of the residual norm given by BiCG
 nresidu = norm(r);
 if isnan(nresidu)
  nresidu = 1e16;
 end % if
 resid = nresidu^2;
 
 if iprint == 1
  fprintf('nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nit,nresidu,nresidu/nb)
 end
 
 resn(nit+1) = nresidu;
 matv(nit+1) = matvec;
 
 % convergence test or too many iterations
 if nresidu < (epsi * nb) || nit >= nitmax
  % convergence
  iconv = 1;
  break
 end % if nresidu
 
 
 
end % while, loop on iterations

if iconv == 1
 % we have to stop
 xx = x;
 if left == 0
  % right preconditioner
  x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
 end % if left
 % ------ exit
 resn = resn(1:nit+1);
 
 if trueres == 1
  resnt = resnt(1:nit+1);
 end
 if l2norm == 1
  norml2 = norml2(1:nit+1);
 end % if
 % return code
 iret= 0;
 if nit == nitmax
  iret = 2;
 end
 
 if iprint == 1
  if nit == nitmax
   fprintf('\n No convergence after %d iterations \n',nit)
  else
   fprintf('\n Convergence after %d iterations \n',nit)
  end % if
  fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
  fprintf(' Number of iterations = %d \n\n',nit)
  fprintf(' Number of matrix-vector products = %d \n\n',matvec)
  fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
 end % if iprint
 
 if timing == 1
  titer = toc;
  if iprint == 2
   fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
  end
  results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
 else
  results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
 end % if timing
 
 % if scaling go back to the solution of the original system
 if scaling == 1
  x = dda .* x;
 end
 
 results.resn = resn;
 if trueres == 1
  results.resnt = resnt;
 end % if
 if l2norm == 1
  results.norml2 = norml2;
 end % if
 
 return
 
end % if iconv

% if we get here we have done the max number of iterations may be without convergence
iret = 0;
resn = resn(1:nit);

if trueres == 1
 resnt = resnt(1:nit);
end % if
if l2norm == 1
 norml2 = norml2(1:nit);
end % if
if nit == nitmax
 iret = 2;
end % if

xx = x;
if left == 0
 % right preconditioner
 x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
end % if left

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of iterations = %d \n\n',nit)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end % if
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
end % if timing

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end % if

results.resn = resn;
if trueres == 1
 results.resnt = resnt;
end % if
if l2norm == 1
 results.norml2 = norml2;
end % if

% warning on
