function [U,C] = gm_RitzCompTrans(Ritz);
%GM_RITZCOMPTRANS Computes the unique unit upper Hessenberg matrix H
% with prescribed Ritz values based on the Ritz value companion transform U

% H = U^{-1} C U

% Input:
% Ritz = upper triangular matrix of order k whose jth column contains
%        the prescribed Ritz values for the jth Arnoldi iteration

% Output:
% U = the Ritz value companion transform
% C = the companion matrix

% Author J. Duintjer Tebbens

n = length(Ritz(:,1));
U = eye(n,n);

for j = 1:n-1
 p = poly(Ritz(1:j,j));
 U(1:j,j+1) = p(j+1:-1:2);
end

p = poly(Ritz(:,n));

C = zeros(n,n);
C(:,n) = -p(n+1:-1:2);
C(2:n,1:n-1) = eye(n-1);

