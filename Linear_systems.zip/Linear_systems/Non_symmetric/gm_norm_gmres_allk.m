function [nrk,Numer,Denom]=gm_norm_gmres_allk(A,b,x0,nitmax);
%GM_NORM_GMRES_ALLK analytic formula for the GMRES residual norms

% This works only for small diagonalizable matrices
% Otherwise it is too expensive

% Input:
% A = matrix
% b = right-hand side
% x0 = initial vector
%
% Output:
% nrk = residual norm at iteration k
% Numer = squares of the numerator
% Denom = squares of the denominator
% nitmax = max number of iterations

%
% Author G. Meurant
% November 2017
%

n = size(A,1);
nitmax = min(nitmax,n-1);
nrk = zeros(nitmax,1);
Numer = zeros(nitmax,1);
Denom = zeros(nitmax,1);

r0 = b - A * x0;
% eigenvalues and eigenvectors of A
[X,D] = eig(full(A));
c = X \ r0;
eigA = diag(D);

for k = 1:nitmax
 
 Pk = gm_all_combi(n,k);
 Qk = Pk;
 Pk1 = gm_all_combi(n,k+1);
 Qk1 = Pk1;
 
 detM = 0;
 for i = 1:size(Pk1,1)
  Ik1 = Pk1(i,:);
  detF = 0;
  for j = 1:size(Qk1,1)
   Jk1 = Qk1(j,:);
   V = gm_Vandermonde(eigA(Jk1));
   detF = detF + det(X(Ik1,Jk1)) * prod(c(Jk1)) * det(V);
  end % for j
  detM = detM + abs(detF)^2;
 end % for i
 
 detM2 = 0;
 for i = 1:size(Pk,1)
  Ik = Pk(i,:);
  detF = 0;
  for j = 1:size(Qk,1)
   Jk = Qk(j,:);
   V = gm_Vandermonde(eigA(Jk));
   detF = detF + det(X(Ik,Jk)) * prod(c(Jk)) * prod(eigA(Jk)) * det(V);
  end % for j
  detM2 = detM2 + abs(detF)^2;
 end % for i
 
 nrk(k) = sqrt(detM / detM2);
 Numer(k) = detM;
 Denom(k) = detM2;
 
end % for k



