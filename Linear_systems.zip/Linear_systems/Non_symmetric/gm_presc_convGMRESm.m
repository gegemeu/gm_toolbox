function [A,b,tH]=gm_presc_convGMRESm(f,V,R,m,N);
%GM_PRESC_CONVGMRESM creates a linear system Ax=b with prescribed GMRES residual norms for N cycles of GMRES(m) 
% is of dimension n and N * m < n

% Full GMRES generates the same residual norms

% Input:
% f = array of length N*m+1 (includes initial residual norm = norm of right hand
%     side) containing the residual norms
% V = unitary matrix of size n x n 
% R =  upper triangular nonsingular matrix of length n, whose m x m diagonal
%      blocks contain the matrices T_m
% m = restart parameter
% N = number of cycles
%
% Output:
% A,b = matrix and right-hand side
% tH = upper Hessenberg matrix

%
% Author J. Duintjer Tebbens
% August 2014
% and G. Meurant
% July 2015
%

n = length(f);
H = zeros(n,n);

if nargin ~= 5
 error('gm_presc_convGMRESm: Some inputs are missing')
end

if N * m >= n
 error('gm_presc_convGMRESm: Non compatible dimensions')
end

nV = size(V,1);
if nV ~= n
 error('gm_presc_convGMRESm: The size of V has to be compatible with the size of f')
end

if norm(V' * V - eye(n)) > 1e-12
 error('gm_presc_convGMRESm: The matrix V is not unitary')
end

%create Hessenberg matrices giving prescribed cycles 

for k = 1:N
 [Hm,chi2,T] = gm_presc_cycle(f((k-1)*m+1:k*m+1),R((k-1)*m+1:k*m,(k-1)*m+1:k*m));
 H((k-1)*m+1:k*m+1,(k-1)*m+1:k*m) = Hm;
%  chi(k,:) = chi2;
end

[A,b,tH] = gm_presc_H_to_A(H,f(1),V,m,N);

