% NON_SYMMETRIC
%
% Files
%   gm_AMG                    - algebraic MultiGrid for a matrix A as an iterative method
%   gm_ASGMRESm_prec          - restarted Adaptive Simpler GMRES(m) for a matrix A with m directions and preconditioning
%   gm_BCGS2_QR_prec          - restarted GMRES(m) for a matrix A with m directions and preconditioning with block GS
%   gm_BiCG_prec              - bi-conjugate gradient for a matrix A with preconditioning
%   gm_BICGSTAB2_prec         - BiCGStab2 for a matrix A with preconditioning
%   gm_BICGSTAB_prec          - BiCGStab for a matrix A with preconditioning
%   gm_BICGSTABl_prec         - BiCGStab(ell) for a matrix A with preconditioning
%   gm_CGS_prec               - CGS (conjugate gradient squared) for a matrix A with preconditioning
%   gm_CMRHm_err_new_prec     - restarted CMRH(m) for a matrix A with m directions and preconditioning optimized implementation with permutations
%   gm_CMRHm_err_prec         - restarted CMRH(m) for a matrix A with m directions and preconditioning
%   gm_CMRHm_err_precT        - restarted CMRH(m) for a matrix A with m directions and preconditioning
%   gm_CMRHm_new_prec         - restarted CMRH(m) for a matrix A with m directions and preconditioning optimized implementation with permutations
%   gm_CMRHm_NewtonS_prec     - restarted CMRH(m) for a matrix A with m directions and preconditioning + Newton basis
%   gm_CMRHm_prec             - restarted CMRH(m) for a matrix A with m directions and preconditioning
%   gm_compress_R             - compresses complex d into array shft 
%   gm_expand_R               - expands the array shft into complex d 
%   gm_f_bsigmin_basis        - function for the maximization of a bound of the smallest singular value
%   gm_f_cond_basis           - function for the minimization of the condition number of V_k
%   gm_f_Finv_basis           - function for the minimization of the Frobenius norm of the inverse of V_k^T V_k
%   gm_f_Fnorm_basis          - function for the minimization of the Frobenius norm of V_k^T V_k - I
%   gm_f_norm_basis           - function for the minimization of the norm of V_k
%   gm_f_sigmin_basis         - function for the maximization of the smallest singular value
%   gm_fastlejasym_R          - adds Leja points
%   gm_FGMRESm_prec           - flexible restarted FGMRES(m) for a matrix A with m directions and preconditioning
%   gm_FOM_to_GMRES           - GMRES residual norms from FOM norms
%   gm_FOMm_DEF_prec          - restarted FOM(m) for a matrix A with m directions and preconditioning with deflation
%   gm_FOMm_DR_prec           - restarted FOM(m) with deflated restarting for a matrix A with m directions and preconditioning
%   gm_FOMm_err_prec          - FOM(m) for a matrix A with m directions and preconditioning
%   gm_FOMm_err_precT         - FOM(m) for a matrix A with m directions and preconditioning
%   gm_FOMm_prec              - restarted FOM(m) for a matrix A with m directions and preconditioning
%   gm_GCRm_prec              - restarted GCR(m) for a matrix A with m directions and preconditioning
%   gm_GCROm_prec             - restarted GCRO for a matrix A with m directions and preconditioning
%   gm_GMRES_trunc_err_prec   - truncated GMRES for a matrix A with m directions and preconditioning
%   gm_GMRES_trunc_err_precT  - truncated GMRES for a matrix A with m directions and preconditioning
%   gm_GMRES_trunc_new_prec   - truncated GMRES for a matrix A with m directions and preconditioning
%   gm_GMRES_trunc_prec       - truncated GMRES for a matrix A with m directions and preconditioning
%   gm_GMRESHBm_prec          - restarted GMRES(m) for a matrix A with m directions and preconditioning Heavy Ball restarting method
%   gm_GMRESm_BCGS2_QR_prec   - restarted GMRES(m) for a matrix A with m directions and preconditioning with block CGS with selective reorthogonalization
%   gm_GMRESm_CGS2_QR_prec    - restarted GMRES(m) for a matrix A with m directions and preconditioning with iterated classical Gram-Schmidt + QR
%   gm_GMRESm_CGS_prec        - restarted GMRES(m) for a matrix A with m directions and preconditioning with CGS
%   gm_GMRESm_DEF_prec        - restarted GMRES(m) for a matrix A with m directions and deflation
%   gm_GMRESm_DEFsimple_prec  - restarted GMRES(m) for a matrix A with m directions and preconditioning with deflation
%   gm_GMRESm_dist_prec       - restarted GMRES(m) for a matrix A with m directions and preconditioning, distance basis
%   gm_GMRESm_DR_prec         - restarted GMRES(m) with deflated restarting for a matrix A with m directions and preconditioning
%   gm_GMRESm_err_prec        - restarted GMRES(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm
%   gm_GMRESm_err_precT       - restarted GMRES(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm
%   gm_GMRESm_H_prec_b        - restarted GMRES(m) for a matrix A with m directions and preconditioning + Householder
%   gm_GMRESm_H_prec_opt      - restarted GMRES(m) for a matrix A with m directions and preconditioning + Householder
%   gm_GMRESm_nb_prec         - restarted GMRES(m) for a matrix A with m directions and preconditioning  + || b || stopping criterion
%   gm_GMRESm_Newton_prec     - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton basis
%   gm_GMRESm_NewtonC_prec    - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton-Chebyshev
%   gm_GMRESm_NewtonPR_prec   - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton-PR
%   gm_GMRESm_NewtonR_prec    - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton-spoke sets
%   gm_GMRESm_NewtonRS_prec   - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton-symmetric spoke sets
%   gm_GMRESm_NewtonS_prec    - restarted GMRES(m) for a matrix A with m directions and preconditioning + Newton- half ellipse
%   gm_GMRESm_prec            - restarted GMRES(m) for a matrix A with m directions and preconditioning
%   gm_GMRESm_prec_time       - restarted GMRES(m) for a matrix A with m directions and preconditioning with time measurements
%   gm_GMRESmRH_prec          - restarted GMRES(m) for a matrix A with m directions and preconditioning + harmonic Ritz values
%   gm_IDRs_prec              - IDR(s) for a matrix A with preconditioning
%   gm_IFOMm_err_prec         - IFOM(m) for a matrix A with m directions and preconditioning incomplete orthogonalization
%   gm_IFOMm_err_precT        - IFOM(m) for a matrix A with m directions and preconditioning incomplete orthogonalization
%   gm_IFOMm_prec             - IFOM(m) for a matrix A with m directions and preconditioning incomplete orthogonalization
%   gm_IGMRESm_err_prec       - IGMRES(m) for a matrix A with m directions and preconditioning
%   gm_IGMRESm_err_precT      - IGMRES(m) for a matrix A with m directions and preconditioning
%   gm_IGMRESm_prec           - IGMRES(m) for a matrix A with m directions and preconditioning
%   gm_IOM_DQGMRES_prec       - truncated FOM and GMRES for a matrix A with m vectors and preconditioning, Saad's DQGMRES
%   gm_jacobi                 - Jacobi iterative method
%   gm_LCDm_B_prec            - left semi-conjugate method for a matrix A with m directions and preconditioning
%   gm_LCDm_prec              - left semi-conjugate method for a matrix A with m directions and preconditioning
%   gm_lejashifts_R           - fast Leja points on spoke sets
%   gm_LGMRESm_prec           - restarted loose GMRES(m) for a matrix A with m directions and preconditioning
%   gm_norm_gmres_allk        - analytic formula for the GMRES residual norms
%   gm_norm_gmres_bound_allk  - analytic bounds for the GMRES residual norms
%   gm_norm_gmres_k           - analytic formula for the GMRES residual norm at iteration k
%   gm_norm_gmres_normal_allk - analytic formula for the GMRES residual norms
%   gm_ORTHOMIN_prec          - Orthomin(nd) for a matrix A with preconditioning
%   gm_presc_convFOM          - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRES        - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRES_2      - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRESm       - creates a linear system Ax=b with prescribed GMRES residual norms for N cycles of GMRES(m) 
%   gm_presc_cycle            - creates an upper Hessenberg matrix with real positive subdiagonal for GMRES with prescribed residual norms
%   gm_presc_H_to_A           - creates linear system Ax=b with prescribed GMRES residual norms
%   gm_presc_H_to_chi         - auxiliary function
%   gm_QMRm_cond_prec         - restarted QMR(m) for a matrix A with m directions and preconditioning + cond min basis
%   gm_QMRm_dist_prec         - restarted QMR(m) for a matrix A with m directions and preconditioning + distance basis
%   gm_QMRm_distF_prec        - restarted QMR(m) for a matrix A with m directions and preconditioning + norm F basis
%   gm_QMRm_distO_prec        - restarted QMR(m) for a matrix A with m directions and preconditioning % norm F basis with reorth
%   gm_QMRm_minx_prec         - restarted QMR(m) for a matrix A with m directions and preconditioning + least squares basis
%   gm_QMRm_Newton_prec       - restarted QMR(m) for a matrix A with m directions and preconditioning + Newton basis
%   gm_QMRm_NewtonC_prec      - restarted QMR(m) for a matrix A with m directions and preconditioning + Newton-Chebyshev
%   gm_QMRm_NewtonR_prec      - restarted QMR(m) for a matrix A with m directions and preconditioning + Newton-spoke sets
%   gm_QMRm_NewtonRS_prec     - restarted QMR(m) for a matrix A with m directions and preconditioning + Newton-spoke sets
%   gm_QMRm_NewtonS_prec      - restarted QMR(m) for a matrix A with m directions and preconditioning + Newton-half ellipse
%   gm_QOR_QMR_trunc_prec     - truncated optimal Q-OR and Q-MR for a matrix A with preconditioning
%   gm_QORm_adapt_err_prec    - QOR(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm, variable bandwidth
%   gm_QORm_adapt_err_precT   - QOR(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm, variable bandwidth
%   gm_QORm_adapt_prec        - QOR(m) for a matrix A with m directions and preconditioning, variable bandwidth
%   gm_QORm_CGLS_err_prec     - QOR(m) for a matrix A with m directions and preconditioning + CGLS
%   gm_QORm_CGLS_err_precT    - QOR(m) for a matrix A with m directions and preconditioning + LS basis
%   gm_QORm_CGLS_prec         - QOR(m) for a matrix A with m directions and preconditioning + LS basis
%   gm_QORm_err_prec          - restarted QOR(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm
%   gm_QORm_err_precT         - restarted QOR(m) for a matrix A with m directions and preconditioning with estimate of the l_2 error norm
%   gm_QORm_LS_err_prec       - QOR(m) for a matrix A with m directions and preconditioning + LS basis
%   gm_QORm_LS_err_precT      - QOR(m) for a matrix A with m directions and preconditioning + LS basis
%   gm_QORm_LS_prec           - QOR(m) for a matrix A with m directions and preconditioning + LS basis
%   gm_QORm_opt_partial_prec  - restarted QOR(m) for a matrix A with m directions and preconditioning with truncation of the recurrence
%   gm_QORm_opt_partial_precB - Restarted QOR(m) for a matrix A with m directions and preconditioning with truncation of the recurrence
%   gm_QORm_opt_prec          - QOR(m) for a matrix A with m directions and preconditioning, optimal Q-OR method (first version)
%   gm_QORm_optinv_cs_prec    - QOR(m) for a matrix A with m directions and preconditioning, with compensated summation
%   gm_QORm_optinv_DEF_prec   - restarted QOR_optinv(m) for a matrix A with m directions and deflation
%   gm_QORm_optinv_err_prec   - QOR(m) for a matrix A with m directions and preconditioning with estimates of the error norm
%   gm_QORm_optinv_err_precT  - QOR(m) for a matrix A with m directions and preconditioning with estimates of the error norm
%   gm_QORm_optinv_prec       - QOR(m) for a matrix A with m directions and preconditioning
%   gm_QORm_optinv_T_DEF_prec - Restarted QOR_optinv(m) for a matrix A with m directions and deflation
%   gm_QORm_optinv_T_prec     - QOR(m) for a matrix A with m directions and preconditioning, using the tridiagonal matrix for the inverse of V_k^T V_k
%   gm_QORm_optinvRCD_prec    - QOR(m) for a matrix A with m directions and preconditioning, conjugate directions
%   gm_QORm_optinvRCD_T_prec  - QOR(m) for a matrix A with m directions and preconditioning, conjugate directions
%   gm_QORm_optQR_prec        - QOR(m) for a matrix A with m directions and preconditioning using the QR factorization of V^T V
%   gm_QORm_prec              - restarted QOR(m) for a matrix A with m directions and preconditioning
%   gm_QORm_QMRm_trunc_prec   - truncated optimal Q-OR and Q-MR for a matrix A
%   gm_QORm_VV_prec           - restarted QOR(m) for a matrix A with m directions and preconditioning
%   gm_Ritz_rand              - generates a matrix of random complex conjugate Ritz values
%   gm_RitzCompTrans          - computes the unique unit upper Hessenberg matrix H
%   gm_TFQMR_prec             - transpose-free QMR for a matrix A with preconditioning
