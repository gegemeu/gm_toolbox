% NON_SYMMETRIC
%
% Krylov methods for nonsymmetric linear systems
%
% Files
%   gm_AMG                       - algebraic MultiGrid as an iterative method for a matrix A
%   gm_AMG_options               - get the options for the AMG solver
%   gm_AMG_params                - parameters for the AMG solver
%   gm_ASGMRESm_prec             - preconditioned restarted Adaptive Simpler GMRES(m) for a matrix A
%   gm_BCGS2_QR_prec             - preconditioned block Gram-Schmidt + QR for a matrix A
%   gm_BiCG_prec                 - preconditioned bi-conjugate gradient for a matrix A
%   gm_BiCGStab2_prec            - preconditioned bi-conjugate gradient stabilized for a matrix A, Gutknecht's method
%   gm_BiCGStab_prec             - preconditioned bi-conjugate gradient stabilized for a matrix A
%   gm_BiCGStabl_prec            - preconditioned bi-conjugate gradient stabilized(ell) for a matrix A
%   gm_CGS_prec                  - preconditioned conjugate gradient squared for a matrix A
%   gm_CMRHm_err_prec            - preconditioned restarted CMRH(m) for a matrix A with error estimates
%   gm_CMRHm_prec                - preconditioned restarted CMRH(m) for a matrix A
%   gm_compress_R                - compresses complex d into array shft 
%   gm_expand_R                  - expands the array shft into complex d 
%   gm_fastlejasym_R             - adds Leja points
%   gm_FGMRESm_prec              - preconditioned flexible restarted GMRES(m) for a matrix A 
%   gm_FOM_to_GMRES              - GMRES residual norms from FOM norms
%   gm_FOMm_DEF_prec             - preconditioned restarted FOM(m) for a matrix A with deflation preconditioner
%   gm_FOMm_DR_prec              - preconditioned restarted FOM(m) for a matrix A with deflated restarting
%   gm_FOMm_err_prec             - preconditioned restarted FOM(m) for a matrix A, with error norm estimates
%   gm_FOMm_prec                 - preconditioned restarted FOM(m) for a matrix A 
%   gm_Gauss_Seidel              - Gauss-Seidel iterative method
%   gm_GCRm_prec                 - preconditioned restarted GCR(m) for a matrix A 
%   gm_GCROm_prec                - preconditioned restarted GCRO(m) for a matrix A
%   gm_GMRESm_CGS2_QR_prec       - preconditioned restarted GMRES(m) for a matrix A, iterated classical Gram-Schmidt 
%   gm_GMRESm_CGS_prec           - preconditioned restarted GMRES(m) for a matrix A, classical Gram-Schmidt
%   gm_GMRESm_DEF_prec           - preconditioned restarted GMRES(m) for a matrix A with deflation preconditioner
%   gm_GMRESm_dist_prec          - preconditioned restarted GMRES(m) for a matrix A, distance basis
%   gm_GMRESm_DR_prec            - preconditioned GMRES(m) for a matrix A with deflated restarting
%   gm_GMRESm_err_prec           - preconditioned restarted GMRES(m) for a matrix A with error norm estimates
%   gm_GMRESm_H_prec             - preconditioned restarted GMRES(m) for a matrix A, Hessenberg matrix 
%   gm_GMRESm_HB_prec            - preconditioned restarted GMRES(m) for a matrix A, heavy ball restart
%   gm_GMRESm_Hous_prec          - preconditioned restarted GMRES(m) for a matrix A, Householder variant
%   gm_GMRESm_HRitz_prec         - preconditioned restarted GMRES(m) for a matrix A, harmonic Ritz values
%   gm_GMRESm_NewtonPR_prec      - preconditioned restarted GMRES(m) for a matrix A + Newton-symmetric spoke sets
%   gm_GMRESm_NewtonRS_prec      - preconditioned restarted GMRES(m) for a matrix A + Newton-symmetric spoke sets
%   gm_GMRESm_prec               - preconditioned restarted GMRES(m) for a matrix A, MGS
%   gm_GMRESm_QR_prec            - preconditioned restarted GMRES(m) for a matrix A, QR
%   gm_GMRESm_time_prec          - preconditioned restarted GMRES(m) for a matrix A, time measurements
%   gm_GMRESm_trunc_err_prec     - preconditioned truncated GMRES(m) for a matrix A with error norm estimates
%   gm_GMRESm_trunc_prec         - preconditioned truncated GMRES(m) for a matrix A
%   gm_IDRs_prec                 - preconditioned IDR(s) method for a matrix A
%   gm_IFOMm_err_prec            - preconditioned restarted IFOM(m) for a matrix A with error norm estimates
%   gm_IFOMm_prec                - preconditioned restarted IFOM(m) for a matrix A
%   gm_IGMRESm_err_prec          - preconditioned restarted IGMRES(m) for a matrix A, with error norm estimates 
%   gm_IGMRESm_prec              - preconditioned restarted IGMRES(m) for a matrix A 
%   gm_IOM_DQGMRESm_prec         - preconditioned restarted DQGMRES(m) for a matrix A
%   gm_Jacobi                    - Jacobi iterative method
%   gm_Krylov_ns_options         - get the options for the nonsymmetric Krylov solvers
%   gm_LCDm_prec                 - preconditioned restarted left semi-conjugate method for a matrix A
%   gm_lejashifts_R              - fast Leja points on spoke sets
%   gm_LGMRESm_prec              - preconditioned restarted Loose GMRES(m) for a matrix A 
%   gm_norm_gmres_allk           - Analytic formula for the GMRES residual norms
%   gm_norm_gmres_bound_allk     - Analytic bounds for the GMRES residual norms
%   gm_norm_gmres_k              - Analytic formula for the GMRES residual norm at iteration k
%   gm_norm_gmres_normal_allk    - Analytic formula for the GMRES residual norms for normal matrices
%   gm_ORTHOMIN_prec             - preconditioned Orthomin method for a matrix A
%   gm_presc_convFOM             - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRES           - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRES_2         - computes a matrix with a prescribed spectrum and a right-hand side that give prescribed residual norms 
%   gm_presc_convGMRESm          - creates a linear system Ax=b with prescribed GMRES residual norms for N cycles of GMRES(m) 
%   gm_presc_cycle               - creates an upper Hessenberg matrix with real positive subdiagonal for GMRES with prescribed residual norms
%   gm_presc_H_to_A              - creates linear system Ax=b with prescribed GMRES residual norms
%   gm_presc_H_to_chi            - auxiliary function
%   gm_QMRm_NewtonRS_prec        - preconditioned restarted optimal Q-MR method for a matrix A with a Newton basis
%   gm_QORm_adapt_prec           - preconditioned restarted Q-OR method for a matrix A, variable bandwidth
%   gm_QORm_CGLS_err_prec        - preconditioned restarted optimal Q-OR method for a matrix A, least squares basis, with error norm estimates
%   gm_QORm_CGLS_prec            - preconditioned restarted optimal Q-OR method for a matrix A, least squares basis
%   gm_QORm_LS_err_prec          - preconditioned restarted optimal Q-OR method for a matrix A, least squares basis with error norm estimates
%   gm_QORm_LS_prec              - preconditioned restarted optimal Q-OR method for a matrix A, least squares basis
%   gm_QORm_opt_partial_err_prec - preconditioned restarted Q-OR method for a matrix A with truncation of the recurrence
%   gm_QORm_opt_partial_prec     - preconditioned restarted Q-OR method for a matrix A with truncation of the recurrence
%   gm_QORm_opt_prec             - preconditioned restarted optimal Q-OR method (first version) for a matrix A
%   gm_QORm_optinv_DEF_prec      - preconditioned restarted optimal Q-OR method for a matrix A, with a deflation preconditioner
%   gm_QORm_optinv_err_prec      - preconditioned restarted optimal Q-OR method for a matrix A with error norm estimates
%   gm_QORm_optinv_prec          - preconditioned restarted optimal Q-OR method for a matrix A
%   gm_QORm_optinv_RCD_err_prec  - preconditioned restarted optimal Q-OR method for a matrix A with conjugate directions and error norm estimates
%   gm_QORm_optinv_RCD_prec      - preconditioned restarted optimal Q-OR method for a matrix A with conjugate directions
%   gm_QORm_optinv_T_prec        - preconditioned restarted optimal Q-OR method for a matrix A, tridiagonal inverse of V_k^T V_k
%   gm_QORm_QMRm_trunc_prec      - preconditioned truncated and restarted optimal Q-OR method  for a matrix A
%   gm_Ritz_rand                 - generates a matrix of random complex conjugate Ritz values
%   gm_RitzCompTrans             - computes the unique unit upper Hessenberg matrix H
%   gm_TFQMR_prec                - preconditioned transpose-free QMR for a matrix A 
