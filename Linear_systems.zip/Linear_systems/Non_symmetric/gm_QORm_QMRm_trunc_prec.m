function [xo,xm,nit,iret,resno,resnot,resnm,resnmt,time_mat]=gm_QORm_QMRm_trunc_prec(A,b,x0,epsi,nitmax,m,lefts,reorths,scalings,trueress,iprints,precond,lorth,varargin);
%GM_QORM_QMRM_TRUNC_PREC Truncated optimal Q-OR and Q-MR for a matrix A
%with preconditioning and restarting

%
% Use the Q-OR truncated optimal basis
% We use the matrices P_k = V_k \hat{R}_k^{-1}
% uses Modified Gram-Schmidt

%
% Input:
% A = matrix
% b = right-hand side, x0 = initial vector
% epsi = convergence threshold
% nitmax  = maximum number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% m = truncation parameter, m = [mr, pp, qq]
%      mr restart parameter, pp vector for Av, qq vectors for v, qq >= pp
% lefts = 'left' left preconditioning, otherwise right preconditioning
% reorths = 'reorth' with full reorthogonalization, = 'sorth' selective
%           reorthogonalization
% scalings = 'scaling', scales the matrix before preconditioning
% iprints = 'print' print residual norms
% precond = type of preconditioning
%  = 'no' M=I
%  = 'sc' diagonal
%  = 'ss' SSOR omega = 1
%  = 'gs' Gauss-Seidel
%  = 'lu' ILU(0) Incomplete LU without pivoting
%  = 'lm' Matlab ILU with threshold
%  = 'lb' Incomplete block LU
%  = 'ai' Approximate inverse AINV of Benzi
%  = 'gp' given preconditioning matrix M in varargin
%         inv(M)A x = inv(M)b or A inv(M) x = b
%  = 'ml' multilevel AMG preconditioner
% lorth = threshold for selective reorthogonalization
%
% varargin = block size if precond = 'lb'
%          = M if precond = 'gp'
%          = [alpha, q] for AINV, alpha = threshold, q = max number of non
%          zero entries in one row
%
%  parameters for 'ml' in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
%  q = number of entries kept in a column for smoother AINV (default =
%  size(A,1))
%
% Output:
% xo = Q-OR approximate solution
% xm = Q-MR approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv
% after nitmax iterations
% resno = Q-OR (preconditioned) residual norms
% resnm = Q-MR(preconditioned) residual norms
% resnot = Q-OR true residual norms
% resnmt = Q-MR true residual norms
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items
%

%
% Author G. Meurant
% March 2019
%

warning off

if nargin < 3
 x0 = zeros(size(A,1),1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = size(A,1);
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
  prints = 'noprint';
 end
end

n = size(A,1);

if nargin < 6
 m = [n, 1, n];
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_QORm_QMRm_trunc_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_QORm_QMRm_trunc_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 7
 % left preconditioning
 left = 1;
end
if nargin < 8
 % no reorthogonalization
 reorth = 0;
end
if nargin < 9
 % no scaling
 scaling = 0;
end
if nargin < 10
 % do not compute the true residual norm
 trueres = 0;
end
if nargin < 11
 % no printing
 iprint = 0;
end
if nargin < 12
 % no preconditioning
 precond = 'no';
end
if nargin < 13 && (strcmpi(reorths,'sorth') == 1)
 lorth = sqrt(eps);
end
if nargin < 13 && (strcmpi(reorths,'sorth') ==0)
 lorth = 0;
end

if nargin > 7 && (strcmpi(lefts,'left') == 1)
 left = 1;
else
 left = 0;
end
if nargin > 8 && (strcmpi(reorths,'reorth') == 1)
 reorth = 1;
 sorth = 0;
else
 reorth = 0;
end
if nargin > 8 && (strcmpi(reorths,'sorth') == 1)
 sorth = 1;
 reorth = 0;
else
 sorth = 0;
end
if nargin > 9 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 10 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 11 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if length(m) < 3
 error('gm_QORm_QMRm_trunc_prec: The length of m must be 3')
end
mr = m(1);
pp = m(2);
qq = m(3);
pp = min(pp,nitmax);
qq = min(qq,nitmax);
m = mr;
if pp == 0
 pp = 1;
end
pp = max(pp,2);
if qq == 0
 qq = min(10,n);
end
if qq < pp
 fprintf('\n gm_QORm_QMRm_trunc_prec: Warning, m(3) must be >= m(2), we force them to be equal \n')
 qq = pp;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if iprint == 1
 fprintf('\n gm_QORm_QMRm_trunc_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  number of Av vectors = %d \n',pp)
 fprintf('  number of v vectors = %d \n',qq)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 fprintf('  sorth = %d, threshold = %g \n',sorth,lorth)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
end

tb = 1;
if nargin >= 14 && (strcmpi(precond,'lb') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_QORm_QMRm_trunc_prec: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'lm') == 1)
 % threshold for the Matlab ILU preconditioner
 tb = varargin{1};
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'gm') == 1)
 % number of iterations for GMRES
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 14 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 %  tb = [alp, q] for AINV
 tb = varargin{1};
 if  strcmpi(precond,'ai') == 1 && length(tb) == 1
  tb = [tb n];
 end
end

if nargin < 14 && (strcmpi(precond,'ai') == 1)
 tb = [0.1, n];
end

if nargin < 14 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
 fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >= 14 && (strcmpi(precond,'gp') == 1)
 % given preconditioner
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_QORm_QMRm_trunc_prec: error, M has to be of the same order as A')
end

if nargin >= 14 && strcmpi(precond,'ml') == 1
 % get the input parameters for the multilevel AMG method
 if nargin < 21
  error('gm_QORm_QMRm_trunc_prec: some parameters are not defined for ML')
 end
 
 lmax = varargin{1};
 nu = varargin{2};
 alpmax = varargin{3};
 alb = varargin{4};
 smooth = varargin{5};
 infl = varargin{6};
 coarse = varargin{7};
 interpo = varargin{8};
 if nargin > 21
  qmin = varargin{9};
 else
  qmin = n;
 end
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
end

if nargin < 14 && strcmpi(precond,'ml') == 1
 % defaults for AMG
 lmax = 10;
 nu =1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'lu';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------default ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
end

xo = [];
xm = [];
nit = 0;
iret = 0;
resno = [];
resnot = [];
resnm = [];
resnmt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

xin = zeros(n,1);

% init of preconditioners
if ~strcmpi(precond,'ml')
 [DD,LL,UU] = gm_initprecns(A,precond,tb);
 if strcmpi(precond,'gp')
  LL = M;
 end
else
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_QORm_QMRm_trunc_prec: Error in gm_amg_ns_init \n')
  iret = 1;
  return
 end
end % if strcmpi

xo = x0;
xm = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x0))
end
if left == 0
 if strcmpi(precond,'ml') == 0
  xo = gm_solveprecns(x0,A,DD,LL,UU,precond);
 else
  xo = gm_amg_ns_it(A,x0,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
end % if left

% init residual vector
r = b - A * xo;
nr = norm(r);
matvec = matvec + 1;

if left == 1
 % generalized residual M z = r
 if strcmpi(precond,'ml') == 0
  z = gm_solveprecns(r,A,DD,LL,UU,precond);
 else
  z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
else
 z = r;
end % if left

r = z;
rhs = zeros(m+1,1);
% S contains the (modified) upper Hessenberg matrix
S = zeros(m+1,m);
R = eye(m,m);
matv = zeros(1,nitmax);
resno = zeros(1,nitmax+1);
resnm = zeros(1,nitmax+1);
nuu = zeros(1,nitmax+1);
nuu(1) = 1;
if trueres == 1
 resnot = zeros(1,nitmax+1);
 resnmt = zeros(1,nitmax+1);
end
r0 = r' * r;
bet = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

resno(1) = bet;
resnm(1) = bet;
if trueres == 1
 resnot(1) = nr;
 resnmt(1) = nr;
end
rhs(1) = bet;
resid = realmax;
iconv = 0;
epss = epsi^2;
ni = 0; % number of iterations
nc = 0; % number of ccycles
nreo = 0;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ----------------------Iterations

while resid > (epss * r0) && (ni < nitmax)
 
 %---------Loop on cycles
 nc = nc + 1;
 
 % init basis vectors
 V = zeros(n,qq);
 P = zeros(n,qq);
 AV = zeros(n,pp);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;
 % matrix-vector product
 matvec = matvec + 1;
 if left == 1
  % left preconditioner
  Av = A * V(:,1);
  % solve of M z = Av
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(Av,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if ~
  Av = z;
 else % if left (right preconditioner)
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(V(:,1),A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,V(:,1),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if ~
  Av = A * z;
 end % if left
 AV(:,1) = Av;
 % init Givens rotations
 rot = zeros(2,n);
 
 for k = 1:m
  % number of iterations
  ni = ni + 1;
  kkk = k + 1;
  lp = min(pp,kkk-1); % number of vectors in AV
  lq = min(qq,kkk-1); % number of vectors in V
  kp = max(1,kkk-pp);
  kq = max(1,kkk-qq);
  while lp + lq > kkk  % we do not need more than k vectors
   if lq > 1
    lq = lq - 1;
    kq = kq + 1;
   elseif lp > 1
    lp = lp - 1;
    kp = kp + 1;
   else
    error(' QOR_QMR_trunc_prec: We cannot reduce the number of vectors any longer')
   end % if
  end % while
  if kkk == 2
   vAv = v' * Av;
   alpha = Av' * Av - vAv^2;
   dotprod = dotprod + 2;
   omega = vAv;
   if abs(vAv) <= 1-14 % breakdown?
    fprintf('\n QOR_QMR_trunc_prec: Initialization breakdown, v^T A v = %g \n',vAv)
    return
   else
    z = vAv + alpha / omega;
    v = Av - z * v;
    S(1,1) = z;
   end % if abs
  else % if kkk == 2
   if kkk <= pp
    pstart = kp;
   else
    pstart = pp - lp + 1;
   end % if kkk
   if kkk <= qq
    qstart = kq;
   else
    qstart = qq - lq + 1;
   end % if kkk
   
   Ck = [AV(:,pstart:pstart+lp-2) V(:,qstart:qstart+lq-1)];
   
   sk = size(Ck,2);
   rsk = max(sk-lq,0);
   nut = [zeros(rsk,1); nuu(kkk-lq:kkk-1)'];
   CCk = Ck' * Ck; % matrix-matrix product
   % a part of this matrix has already been computed
   dotprod = dotprod + 2 * (pp + qq); % we just count what must be really done!
   CAv = Ck' * Av; % matrix-vector product
   dotprod = dotprod + 2;
   yy = CCk \ CAv; % linear solve
   %   Y = CCk \ [CAv nut];
%    [QQ,RR] = qr(CCk);
%    Y = RR \ QQ' * [CAv nut];
%    yy = Y(:,1);
   alpha = Av' * Av - CAv' * yy;
   dotprod = dotprod + 1; % we just count those of length n
   yyy = CCk \ nut; % linear solve
%    yyy = Y(:,2);
   omega = Av' * (Ck * yyy);
   dotprod = dotprod + 1;
   if abs(omega) <= 1e-14 % breakdown?
    fprintf('\n gm_QORm_QMRm_trunc_prec: Breakdown iteration %d, value = %g\n',ni,omega)
    %return
   end % if abs
   z = yy + (alpha / omega) * yyy;
   v = Av - Ck * z; % next basis vector
   S(1:kkk-1,kkk-1) = [zeros(kkk-1-lq,1); z(sk-lq+1:end)];
   R(kkk-2-lp+2:kkk-2,kkk-1) = -z(1:lp-1);
  end % if kkk = 2
  nk = norm(v);
  dotprod = dotprod + 1;
  v = v / nk;
  % subdiagonal entry
  S(kkk,kkk-1) = nk;
  gk1 = nk;
  nuu(kkk) = -(nuu(1:kkk-1) * S(1:kkk-1,kkk-1)) / S(kkk,kkk-1);
  
  % matrix-vector product
  matvec = matvec + 1;
  if left == 1
   % left preconditioner
   Av = A * v;
   % solve of M z = Av
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(Av,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if ~
   Av = z;
  else % if left (right preconditioner)
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(v,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,v,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if ~
   Av = A * z;
  end % if left
  
  % apply the preceding Givens rotations to the last column just computed
  for kk = max(k-qq,1):k-1
   g1 = S(kk,k);
   g2 = S(kk+1,k);
   S(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   S(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk
  
  % compute, store and apply a new Givens rotation to zero the last term in kth column
  gk = S(k,k);
  if gk == 0
   rot(1,k) = 0;
   rot(2,k) = 1;
  elseif gk1 == 0
   rot(1,k) = 1;
   rot(2,k) = 0;
  else
   cs = sqrt(abs(gk1)^2 + abs(gk)^2);
   if abs(gk) < abs(gk1)
    mu = gk / gk1;
    tau = conj(mu) / abs(mu);
   else
    mu = gk1 / gk;
    tau = mu / abs(mu);
   end % if
   % store the rotation for the next columns
   rot(1,k) = abs(gk) / cs; % cosine
   rot(2,k) = abs(gk1) * tau / cs; % sine
  end % if gk
  
  % save the values before the last rotation
  skk = S(k,k);
  skk1 = S(k+1,k);
  rhk = rhs(k);
  % modify the diagonal entry and the right-hand side
  S(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
  c = rhs(k);
  rhs(k) = rot(1,k) * c;
  rhs(k+1) = -rot(2,k) * c;
  
  % computation of p
  if k == 1
   p = V(:,1);
  else
   if k <= qq
    p = -P(:,1:k-1) * S(1:k-1,k);
   else
    p = -P(:,1:qq) * S(k-qq:k-1,k);
   end
   if k <= pp
    pstar = 1;
   else
    ps = pstar + 1;
    if ps+lp-1 <= qq
     pstar = ps;
    end % if ps
   end % if k
   p = p + V(:,pstar:pstar+lp-1) * R(k-lp+1:k,k);
  end % if k
  p = p / S(k,k);
  
  if k > qq
   % left shift of the P vectors
   P(:,1:qq-1) = P(:,2:qq);
   % vector p_k
   P(:,qq) = p;
  else
   P(:,k) = p;
  end % if k+1
  
  if k+1 > qq
   % left shift of the basis vectors
   V(:,1:qq-1) = V(:,2:qq);
   % next basis vector
   V(:,qq) = v;
  else
   V(:,k+1) = v;
  end % if k+1
  if k+1 > pp
   % left shift of the basis vectors
   AV(:,1:pp-1) = AV(:,2:pp);
   % next basis vector
   AV(:,pp) = Av;
  else
   AV(:,k+1) = Av;
  end % if k+1
  
  xm_old = xm;
  xm = xm + rhs(k) * p; % Q-MR approximate solution
  xo = xm_old + ((rhk * S(k,k)) / skk) * p; % Q-OR approximate solution
  
  if trueres == 1
   % computation of the true (if left = 0) residual norm
   xx = xo;
   if left == 0
    % right preconditioner
    if strcmpi(precond,'ml') == 0
     xx = gm_solveprecns(xx,A,DD,LL,UU,precond);
    else
     xx = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
   end % if left
   % this is also not the true residual norm if there is some scaling
   resnot(ni+1) = norm(b - A * xx);
   xx = xm;
   if left == 0
    % right preconditioner
    if strcmpi(precond,'ml') == 0
     xx = gm_solveprecns(xx,A,DD,LL,UU,precond);
    else
     xx = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
   end % if left
   % this is also not the true residual norm if there is some scaling
   resnmt(ni+1) = norm(b - A * xx);
  end % if trueres
  
  % nresidu is the estimate of the residual norm given by Q-MR
  % This is the quasi-residual norm
  %  nresidu = abs(rhs(k+1));
  
  resno(ni+1) = abs( skk1 * rhk / skk);
  nresidu = resno(ni+1);
  resnm(ni+1) = abs(rhs(k+1));
  matv(ni+1) = matvec;
  resid = nresidu^2;
  
  if iprint == 1
   fprintf('nit = %5d, Q-MR quasi-residual norm = %12.5e, relative quasi-residual norm = %12.5e \n',ni,resnm(ni+1),resnm(ni+1)/sqrt(r0))
   fprintf('             Q-OR residual norm = %12.5e, relative residual norm = %12.5e \n',resno(ni+1),resno(ni+1)/sqrt(r0))
  end
  
  % convergence test or too many iterations
  if nresidu < (epsi * sqrt(r0)) || ni >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu
  
 end % for k
 
 if iconv == 1
  % we have to stop
  % computation of the solution at convergence
  xx = xo;
  if left == 0
   % right preconditioner
   if strcmpi(precond,'ml') == 0
    xo = gm_solveprecns(xx,A,DD,LL,UU,precond);
   else
    xo = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
  end % if left
  xx = xm;
  if left == 0
   % right preconditioner
   if strcmpi(precond,'ml') == 0
    xm = gm_solveprecns(xx,A,DD,LL,UU,precond);
   else
    xm = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
  end % if left
  % ------ exit
  resno = resno(1:ni+1);
  resnm = resnm(1:ni+1);
  
  if trueres == 1
   resnot = resnot(1:ni+1);
   resnmt = resnmt(1:ni+1);
  end
  
  % number of total iterations
  nit = ni;
  % return code
  iret= 0;
  if ni == nitmax
   iret = 2;
  end
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   xo = dda .* xo;
   xm = dda .* xm;
  end
  
  if iprint == 1
   if ni < nitmax
    fprintf('\n Convergence after %d iterations \n',ni)
   end
   fprintf('\n Final Q-MR true residual norm = %12.5e \n',norm(b - A * xm))
   fprintf('\n Final Q-OR true residual norm = %12.5e \n\n',norm(b - A * xo))
   fprintf(' Number of iterations = %d \n\n',ni)
   if sorth ==1 || reorth == 1
    fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   end
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
  end % if iprint
  
  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  else
   time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  end % if timing
  
  warning on
  return
 end % if iconv
 
 % we have not converged yet, compute the residual and restart
 
 xx = xo;
 if left == 0
  % right preconditioner
  if strcmpi(precond,'ml') == 0
   xx = gm_solveprecns(xo,A,DD,LL,UU,precond);
  else
   xx = gm_amg_ns_it(A,xo,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 end % if left
 
 % residual vector at the end of the cycle
 r = b - A * xx;
 matvec = matvec + 1;
 
 if left == 1
  % left preconditioner
  % generalized residual M z = r
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(r,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cdd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 else
  z = r;
 end % if left
 
 r = z;
 xm = xo;
 bet = norm(r);
 resid = bet^2;
 dotprod = dotprod + 1;
 S = zeros(m+1,m);
 R = eye(m,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 
 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, Q-OR true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nc,ni,bet,bet/sqrt(r0))
 end
 
end % while, loop on iterations

% if we get here we have done the max number of iterations may be without convergence
iret = 0;
nit = ni;
resno = resno(1:ni+1);
resnm = resnm(1:ni+1);

if trueres == 1
 resnot = resnot(1:ni+1);
 resnmt = resnmt(1:ni+1);
end

if ni == nitmax
 iret = 2;
end

xx = xo;
if left == 0
 % right preconditioner
 if strcmpi(precond,'ml') == 0
  xo = gm_solveprecns(xx,A,DD,LL,UU,precond);
 else
  xo = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
end % if left
xx = xm;
if left == 0
 % right preconditioner
 if strcmpi(precond,'ml') == 0
  xm = gm_solveprecns(xx,A,DD,LL,UU,precond);
 else
  xm = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
end % if left

% if scaling go back to the solution of the original system
if scaling == 1
 xo = dda .* xo;
 xm = dda .* xm;
end

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',ni)
 fprintf('\n Final Q-MR true residual norm = %12.5e \n',norm(b - A * xm))
 fprintf('\n Final Q-OR true residual norm = %12.5e \n\n',norm(b - A * xo))
 fprintf(' Number of iterations = %d \n\n',ni)
 if sorth ==1 || reorth == 1
  fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 end
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
end % if timing

warning on
