function [x,nit,iret,resn,resnt,err,time_mat]=gm_QORm_LS_err_prec(A,b,x0,epsi,nitmax,m,lefts,scalings,trueress,iprints,precond,delay,varargin);
%GM_QORM_LS_ERR_PREC QOR(m) for a matrix A with m directions and preconditioning + LS basis
% with estimate of the l_2 error norm

% For left preconditioning it is the true error = x - inv(A) b
% For right preconditioning it is the error of the system A inv(M) y = b
% After a restart the estimates are zero for delay iterations
%
% LS basis using the normal equations for solving the least squares problems

%
% Input:
% b = right-hand side, x0 = initial vector
% epsi = convergence threshold
% nitmax  = maximum number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% m = restarting parameter, QOR(m)
% lefts = 'left' left preconditioning, otherwise right preconditioning
% scalings = 'scaling', scales the matrix before preconditioning
% iprints = 'print' print residual norms
% precond = type of preconditioning
%  = 'no' M=I
%  = 'sc' diagonal
%  = 'ss' SSOR omega = 1
%  = 'gs' Gauss-Seidel
%  = 'lu' ILU(0) Incomplete LU without pivoting
%  = 'lm' Matlab ILU with threshold
%  = 'lb' Incomplete block LU
%  = 'ai' Approximate inverse AINV of Benzi
%  = 'gp' given preconditioning matrix M in varargin
%         inv(M)A x = inv(M)b or A inv(M) x = b
%  = 'ml' multilevel AMG preconditioner
% delay = we estimate the error norm delay iterations before the current
%         on
%
% varargin = block size if precond = 'lb'
%          = M if precond = 'gp'
%          = [alpha, q] for AINV, alpha = threshold, q = max number of non
%          zero entries in one row
%
%  parameters for 'ml' in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
%  q = number of entries kept in a column for smoother AINV (default =
%  size(A,1))
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv
% after nitmax iterations
% resn = (preconditioned) residual norms
% resnt = true residual norms
% err = estimate of the error l_2 norm
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items
%

%
% Author G. Meurant
% April 2015
%

% warning off

if nargin < 3
 x0 = zeros(size(A,1),1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = size(A,1);
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
  prints = 'noprint';
 end
end

n = size(A,1);

if nargin < 6
 m = n;
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_QORm_LS_err_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_QORm_LS_err_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 7
 % left preconditioning
 left = 1;
end
if nargin < 8
 % no scaling
 scaling = 0;
end
if nargin < 9
 % do not compute the true residual norm
 trueres = 0;
end
if nargin < 10
 % no printing
 iprint = 0;
end
if nargin < 11
 % no preconditioning
 precond = 'no';
end
if nargin < 12
 delay = 1;
end

if nargin > 6 && (strcmpi(lefts,'left') == 1)
 left = 1;
else
 left = 0;
end
if nargin > 7 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 8 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 9 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if m > nitmax
 m = nitmax;
end

if m == 0
 m = 10;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if iprint == 1
 fprintf('\n gm_QORm_LS_err_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  delay = %d \n',delay);
end

tb = 1;
if nargin >= 13 && (strcmpi(precond,'lb') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_QORm_LS_err_prec: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 13 && (strcmpi(precond,'lm') == 1)
 % threshold for the Matlab ILU preconditioner 
 tb = varargin{1};
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin >= 13 && (strcmpi(precond,'gm') == 1)
 % number of iterations for GMRES 
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 13 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 %  tb = [alp, q] for AINV
 tb = varargin{1};
 if  strcmpi(precond,'ai') == 1 && length(tb) == 1
  tb = [tb n];
 end
end

if nargin < 13 && (strcmpi(precond,'ai') == 1)
 tb = [0.1, n];
end

if nargin < 13 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
 fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >= 13 && (strcmpi(precond,'gp') == 1)
 % given preconditioner
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_QORm_LS_err_prec: error, M has to be of the same order as A')
end

if nargin >= 13 && strcmpi(precond,'ml') == 1
 % get the input parameters for the multilevel AMG method
 if nargin < 20
  error('gm_QORm_LS_err_prec: some parameters are not defined for ML')
 end

 lmax = varargin{1};
 nu = varargin{2};
 alpmax = varargin{3};
 alb = varargin{4};
 smooth = varargin{5};
 infl = varargin{6};
 coarse = varargin{7};
 interpo = varargin{8};
 if nargin > 20
  qmin = varargin{9};
 else
  qmin = n;
 end
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
 
end

if nargin < 13 && strcmpi(precond,'ml') == 1
 % defaults for AMG
 lmax = 10;
 nu =1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'lu';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------default ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
 
end

if delay >= m
 error('gm_QORm_LS_err_prec: the delay has to be smaller than m')
end

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ----------------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;
matvrect = 0;

xin = zeros(n,1);

% init of preconditioners
if ~strcmpi(precond,'ml')
 [DD,LL,UU] = gm_initprecns(A,precond,tb);
 if strcmpi(precond,'gp')
  LL = M;
 end
else
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,erro] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if erro == 1
  fprintf('\n gm_QORm_LS_err_prec: Error in gm_amg_ns_init \n')
  iret = 1;
  return
 end
end % if strcmpi

x = x0;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end

if left == 0
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(x0,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,x0,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
end % if left

% init residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = norm(r);
end

if left == 1
 % generalized residual M z = r
 if strcmpi(precond,'ml') == 0
  z = gm_solveprecns(r,A,DD,LL,UU,precond);
 else
  z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
else
 z = r;
end % if left

r = z;
rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m+1,m);
% HH contains the unmodified H for error estimation
HH = H;
resn = zeros(1,nitmax);

r0 = r' * r;
nr = r0;
nrr = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',nrr)
end

% number of cycles
nitd = 0;
% number of iterations
ni = 0;
iconv = 0;
resn(1) = nrr;
rhs(1) = nrr;
bet = nrr;
resid = realmax;
epss = epsi^2;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ------------------Iterations

while resid > (epss * r0) && (ni < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 V = zeros(n,m+1);
 % L is the Cholesky factor of V' V
 L = zeros(m+1,m+1);
 ichol = 0;
 % init Givens rotations
 rot = zeros(2,m);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;

 % matrix vector product A v
 if left == 1
  % left preconditioner
  Av = A * v;
  % solve of M z = Av
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(Av,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
  Av = z;
 else % if left (right preconditioner)
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(v,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,v,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
  Av = A * z;
 end % if left
 matvec = matvec + 1;

 L(1,1) = 1;

 % start a cycle of QORm_LS(m)
 
 for k = 1:m
  % number of iterations
  ni = ni + 1;

  % construction of the basis vectors
  % and entries of H (in the last column of H)

  if k == 1
   % choose the optimal value for the first column of H
   v = V(:,1);
   vAv = v' * Av;
   vAAv = Av' * Av;
   dotprod = dotprod + 2;
   H(1,1) = vAAv / vAv;
   vt = Av - H(1,1) * V(:,1);
   H(2,1) = norm(vt);
   dotprod = dotprod + 1;
   V(:,2) = vt / H(2,1);

   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * V(:,2);
    % solve of M z = Av
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(Av,A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = z;
   else % if left (right preconditioner)
    if strcmpi(precond,'ml') == 0
     z = gm_solveprecns(V(:,2),A,DD,LL,UU,precond);
    else
     z = gm_amg_ns_it(A,V(:,2),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
    Av = A * z;
   end % if left
   matvec = matvec + 1;

   L(2,1) = V(:,1)' * V(:,2);
   dotprod = dotprod + 1;
   L(2,2) = sqrt(1 - L(2,1)^2);

  else

   % solve the least squares problem
   if ichol == 0
    % using the Cholesky factorization
    yy = L(1:k,1:k) \ (V(:,1:k)' * Av);
    y = L(1:k,1:k)' \ yy;
    dotprod = dotprod + k;
   else
    y = (V(:,1:k)' * V(:,1:k)) \ (V(:,1:k)' * Av);
    dotprod = dotprod + k + k^2;
   end % if ichol

   % new column of H
   H(1:k,k) = y;
   vt = Av - V(:,1:k) * y;
   h = norm(vt);
   dotprod = dotprod + 1;
   % subdiagonal entry of H
   H(k+1,k) = h;

   if k < m
    % next vectors
    V(:,k+1) = vt / H(k+1,k);
    % matrix-vector product (n x n)
    if left == 1
     % left preconditioner
     Av = A * V(:,k+1);
     % solve of M z = Av
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(Av,A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = z;
    else % if left (right preconditioner)
     if strcmpi(precond,'ml') == 0
      z = gm_solveprecns(V(:,k+1),A,DD,LL,UU,precond);
     else
      z = gm_amg_ns_it(A,V(:,k+1),xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
     end % if strcmpi
     Av = A * z;
    end % if left
    matvec = matvec + 1;

    % compute L for next step
    lk = L(1:k,1:k) \ (V(:,1:k)' * V(:,k+1));
    dotprod = dotprod + k;
    lklk = 1 - lk' * lk;
    lkk = sqrt(lklk);
    if lklk < 0
     warning('gm_QORm_LS_err_prec: V^T V is not positive definite, L may be wrong')
     % we switch to a full solve
     ichol = 1;
    end
    L(k+1,1:k) = lk';
    L(k+1,k+1) = lkk;

   end % if k < m
  end % if k == 1

  gk1 = H(k+1,k);
  % save the new column of H
  HH(1:k+1,k) = H(1:k+1,k);

  % apply the preceding Givens rotations to the last column just computed
  for kk = 1:k-1
   g1 = H(kk,k);
   g2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk

  % error estimates from the paper:
  %  Estimates of the norm of the error in solving linear systems with FOM
  %  and GMRES, SIAM J. Sci. Comp., v 33, (2011), pp. 2686-2705
  if k > delay
   dd = delay;
   % partitioning of HH
   Hk = HH(1:k-dd,1:k-dd);
   Wk = HH(1:k-dd,k-dd+1:k);
   Hkt = HH(k-dd+1:k,k-dd+1:k);
   hkp = HH(k-dd+1,k-dd);
   e1t = zeros(dd,1);
   e1t(1) = 1;
   % hkt1 = Hkt \ e1t;
   [Qkt,Rkt] = qr(full(Hkt));
   hkt1 = Rkt \ (Qkt' * e1t);
   wk = Wk * hkt1;
   % hkwk1 = Hk \ wk;
   [Qk,Rk] = qr(full(Hk));
   hkwk1 = Rk \ (Qk' * wk);
   e1 = zeros(k-dd,1);
   e1(1) = 1;
   % hk1 = Hk \ e1;
   hk1 = Rk \ (Qk' * e1);
   ekhk1 = hk1(k-dd);
   ekhkw = hkwk1(k-dd);
   gammak = hkp * ekhk1 / (1 - hkp * ekhkw);
   sk1 = ekhk1 + gammak * ekhkw;
   % ekk = estimate of the FOM error
   ekk = (hkp * sk1)^2 * (hkt1'*hkt1) + gammak^2 * (hkwk1' * hkwk1);
   el = zeros(k-dd,1);
   el(k-dd) = 1;
   yy = Qk * ( Rk' \ el);
   % vector tk = inv(H_k' H_k) e_k
   tk = Rk \ (Qk' * yy);
   tkk = tk(k-dd);
   dkp = hkp^2 / (1 + hkp^2 * tkk);
   uk = dkp * tk;
   % additional term for GMRES
   add = 2 * gammak * ekhk1 * (hkwk1' * uk) + ekhk1^2 * norm(uk)^2;
   if ekk + add > 0
    err(ni-dd) = sqrt(nr * (ekk + add));
   else
    err(ni-dd) = 0;
   end
  end % if k > delay

  if trueres == 1
   % computation of the true (if left = 0) residual norm
   % triangular solve
   y = triu(H(1:k,1:k)) \ rhs(1:k);
   xx = x0 + V(:,1:k) * y;
   if left == 0
    % right preconditioner
    if strcmpi(precond,'ml') == 0
     xx = gm_solveprecns(xx,A,DD,LL,UU,precond);
    else
     xx = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end % if strcmpi
   end % if left
   % this is also not the true residual norm if there is some scaling
   resnt(ni+1) = norm(b - A * xx);
  end % if trueres

  % nresidu is the estimate of the residual norm given by GMRES
  yk = rhs(k) / H(k,k);
  nresidu = gk1 * abs(yk);
  resid = nresidu^2;

  if iprint == 1
   fprintf('cycle = % d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,ni,nresidu,nresidu/sqrt(r0))
  end
  resn(ni+1) = nresidu;
  matv(ni+1) = matvec;
  
  % convergence test or too many iterations
  if nresidu < (epsi * sqrt(r0)) || ni >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu

  % compute, store and apply a new rotation to zero the last term in kth column
  % except at the end of a cycle
  if k < m
   gk = H(k,k);
   if gk == 0
    rot(1,k) = 0;
    rot(2,k) = 1;
   elseif gk1 == 0
    rot(1,k) = 1;
    rot(2,k) = 0;
   else
    cs = sqrt(abs(gk1)^2 + abs(gk)^2);
    if abs(gk) < abs(gk1)
     mu = gk / gk1;
     tau = conj(mu) / abs(mu);
    else
     mu = gk1 / gk;
     tau = mu / abs(mu);
    end % if
    % store the rotation for the next columns
    rot(1,k) = abs(gk) / cs; % cosine
    rot(2,k) = abs(gk1) * tau / cs; % sine
   end % if gk

   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k < m
  
 end %  for k - end of one cycle
 
 % computation of the solution at the end of the cycle
 % triangular solve
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;

 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   if strcmpi(precond,'ml') == 0
    x = gm_solveprecns(xx,A,DD,LL,UU,precond);
   else
    x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if strcmpi
  end % if left
  % ------ exit
  resn = resn(1:ni+1);
  if trueres == 1
   resnt = resnt(1:ni+1);
  end
  % number of total iterations
  nit = ni;
  % return code
  iret= 0;
  if ni == nitmax
   iret = 2;
  end

  if iprint == 1
   if ni == nitmax
    fprintf('\n No convergence after %d iterations \n',ni)
   end
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
  end % if iprint

  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end

  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  else
   time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  end % if timing

  return
 end % if iconv

 % we have not converged yet, compute the residual and restart

 xx = x;
 if left == 0
  % right preconditioner
  if strcmpi(precond,'ml') == 0
   xx = gm_solveprecns(x,A,DD,LL,UU,precond);
  else
   xx = gm_amg_ns_it(A,x,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 end % if left

 % residual vector
 r = b - A * xx;
 matvec = matvec + 1;

 if left == 1
  % left preconditioner
  % generalized residual M z = r
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(r,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if strcmpi
 else
  z = r;
 end % if left

 r = z;

 x0 = x;
 rk = r' * r;
 nr = rk;
 resid = rk;
 nrr = norm(r);
 bet = nrr;
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;

 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,ni,nrr,nrr/sqrt(r0))
 end

end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
nit = ni;
resn = resn(1:ni);
if trueres == 1
 resnt = resnt(1:ni);
end
if ni == nitmax
 iret = 2;
end

xx = x;
if left == 0
 % right preconditioner
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(xx,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end % if strcmpi
end % if left

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',ni)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint
 
% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
end % if timing

% warning on
