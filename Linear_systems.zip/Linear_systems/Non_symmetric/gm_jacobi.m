function [x,nit,resnt]=gm_jacobi(A,b,x0,epss,nitmax);
%GM_JACOBI Jacobi iterative method
%
% x0 starting vector

%  
% Author G. Meurant
%

resnt = zeros(1,nitmax+1);
d = spdiags(A,0);
d1 = 1 ./ d;
% 
x = x0;
dx = d .* x;
r = b - A * x;
resnt(1) = norm(r);
nit = 0;
r0 = resnt(1);
resid = realmax;

while (resid >= epss*r0) && (nit < nitmax)
 nit = nit + 1;
 dx = r + dx;
 x = d1 .* dx;
 r = b - A * x;
 resid = norm(r);
 resnt(nit+1) = resid;
end
