function [Hm,chi,T] = gm_presc_cycle(f,R);
%GM_PRESC_CYCLE creates an upper Hessenberg matrix with real positive subdiagonal for GMRES with prescribed residual norms
% GMRES extracts prescribed residual norms and Ritz values from it

% Input: 
% f = m+1 prescribed residual norms, (f(1) = ||r0||)
% R = upper triangular matrix of order m whose jth column contains the 
%     coefficients of the polynomials whose roots are the prescribed
%     Ritz values for the jth iteration
%
% Output: 
% Hm = Hessenberg matrix of size m+1 x m
% chi, T = See paper

m = length(f)-1;
ii = sqrt(-1);
Hm = zeros(m+1,m);

chi = ones(1,m+1);
for j = 2:m+1
 chi(j) = (sqrt(f(j-1)^2 - f(j)^2)) / (f(j-1) * f(j));
end % for j

T = eye(m+1);
T(1,1) = 1 / f(1);
chi(1) = T(1,1);
T(2:m+1,2:m+1) = R;
dt = angle(diag(T));
scale = exp(-dt * ii); 
T(1,2:m+1) = chi(2:m+1);
T = T * diag(scale);
chi = chi * diag(scale);
T2 = [zeros(1,m); T(1:m,1:m)];

Hm = T \ T2;

