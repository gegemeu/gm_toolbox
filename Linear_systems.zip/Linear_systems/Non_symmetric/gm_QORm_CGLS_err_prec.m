function [x,nit,iret,results] = gm_QORm_CGLS_err_prec(A,b,x0,options,params);
%GM_QORM_CGLS_ERR_PREC preconditioned restarted optimal Q-OR method for a matrix A, least squares basis, with error estimates

% QOR optimal method with a non-orthogonal basis

% CGLS basis using gm_CGLS for solving the least squares problems

% with estimates of the l_2 error norm

% this method does not work for skew-symmetric matrices (without preconditioning)

%
% Input:
% A = matrix
% b = right-hand side
% x0 = initial vector
%
% options is a structure which can contain the following fields:
% epsi = convergence threshold
% nitmax  = maximum number of iterations
% m = restarting parameter, GMRES(m)
% left = 1 left preconditioning, otherwise right preconditioning
% reorth = 1 with full reorthogonalization, = 2 selective reorthogonalization
% scaling = 1, scales the matrix before preconditioning
% iprint = 1, prints residual norms
% timing = 1, with time measurements
% precond = type of preconditioning
%  = 'no' M = I
%  = 'sc' diagonal
%  = 'gs' Gauss-Seidel
%  = 'ss' SSOR like with omega=1
%  = 'lu' Incomplete LU(0)
%  = 'lm' Matlab ILU(0)
%  = 'ld' Matlab ILU with drop threshold
%  = 'lb' block ILU
%  = 'ai' approximate inverse AINV
%  = 'tw' Tang and Wang approximate inverse
%  = 'sp' SPAI approximate inverse (Huckle and Grote)
%  = 'sh' or 'wl' ILU factorizations from V. Eijkhout
%  = 'gp' given preconditioner
%  = 'gm' GMRES iterations
%  = 'ml' multilevel (AMG)
% lorth = threshold for selective reorthogonalization

% params = structure giving the parameter(s) needed by some preconditioners
%  if params is empty, default values are used
%  one or two fields if the preconditioner is not 'ml'
%
% params.p1
%  = empty for 'no', 'sc', 'gs', 'ss', 'lu', and 'lm'
%  = epsilon for 'ld'
%  = level for 'sh', 'wl'
%  = block size for 'lb'
%  = nb of GMRES iterations for 'gm'
%  = matrix M for 'gp'

% params.p1 and params.p2
%  = threshold and number of nonzero entries  in a column for 'ai'
%  = epsilon and approximate number of nonzero entries in a column for 'sp'
%  = integers k and l defining the neighbothood for 'tw' (must be small)
%
% the parameters for 'ml' are in params as (default)
%  params.lmax = max number of levels (10)
%  params.nu = number of smoothing steps (1)
%  params.alpmax = parameter alpha (0.1)
%  params.alb = number of levels for some smoothers (1)
%  params.smooth = type of smoothing operator ('gs')
%  params.infl = type of influence matrix ('b')
%  params.coarse = type of coarsening algorithm ('st')
%  params.interpo = type of interpolation algorithm ('st')
%  params.qmin = number of nonzero entries in a column for AINV smoother (n)

% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv after nitmax iterations
% results is a structure with some of the following fields:
%  resn = (preconditioned) residual norms
%  resnt = true residual norms
%  norml2 = ell2-norm of the error if option l2norm = 1
%  time_mat = if timing = 1, time_mat is a structure containing the init and iteration
%   times, the number of matrix-vector products, the number of inner products and the
%   number of matrix-vector products as a function of the iteration number,
%   otherwise same without the first two items
%

%
% Author G. Meurant
% January 2025
%

% warning off

n = size(A,1);

if nargin == 1
 error('gm_QORm_CGLS_err_prec: There is no right-hand side')
end % if
nlb = length(b);
nb = norm(b);
nb2 = nb^2;

if nlb ~= n
 error('gm_QORm_CGLS_err_prec: Error, the dimensions of A and b are not compatible')
end % if

if nargin < 3
 x0 = zeros(n,1);
end % if
nx = length(x0);
if nlb ~= nx
 error('gm_QORm_CGLS_err_prec: Error, the dimensions of x0 and b are not compatible')
end % if

if nargin < 4
 options = [];
 params = [];
end % if

if nargin < 5
 params = [];
end % if

% get the optional parameters and options
[epsi,nitmax,m,scaling,trueres,iprint,precond,left,reorth,lorth,timing,l2norm,delay] = gm_Krylov_ns_options(A,options);

if m > nitmax
 m = nitmax;
end

if iprint == 1
 fprintf('\n gm_QORm_CGLS_err_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 if reorth == 2
  fprintf('  threshold = %g \n',lorth)
 end % if
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  l2norm = %d \n',l2norm)
 fprintf('  iprint = %g \n',iprint)
 fprintf('  timing = %g \n',timing)
 fprintf('  delay = %g \n',delay)
end % if

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% -----------------------Initialization

if timing == 1
 tic;
end % if

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;
matvrect = 0;

% init of preconditioners
[cprec,cprec_amg] = gm_init_precond_ns(A,precond,iprint,params);

x = x0;
if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end
% this is useless
% if left == 0
%  x = gm_solve_precond_ns(A,x0,precond,cprec,cprec_amg);
% end % if left

% init residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax+1);
 resnt(1) = norm(r);
end
if l2norm == 1
 norml2 = zeros(1,nitmax+1);
 xec = A \ b;
 norml2(1) = norm(xec -x);
end % if

resn = zeros(1,nitmax+1);
err = zeros(1,nitmax);

bb = b;
if left == 1
 % generalized residual M z = r
 z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 bb = gm_solve_precond_ns(A,b,precond,cprec,cprec_amg);
else
 z = r;
end % if left
nb = norm(bb);
nb2 = nb^2;

r = z;
rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m+1,m);
HH = H;
r0 = r' * r;
nr = r0;
bet = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

% number of cycles
nitd = 0;
% number of iterations
nit = 0;
iconv = 0;
resn(1) = bet;
rhs(1) = bet;
resid = realmax;
epss = epsi^2;
% number of reorthogonalizations
nreo = 0;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% ------------------Iterations

while resid > (epss * nb2) && (nit < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 V = zeros(n,m+1);
 % init Givens rotations
 rot = zeros(2,m);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;
 
 % start a cycle of QOR-CGLS(m)
 
 % matrix-vector product
 if left == 1
  % left preconditioner
  Av = A * v;
  % solve of M z = Av
  z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
  Av = z;
 else % if left (right preconditioner)
  z = gm_solve_precond_ns(A,v,precond,cprec,cprec_amg);
  Av = A * z;
 end % if left
 % we do not count this one because there is a useless matvec at the end of the
 % iterations
 %  matvec = matvec + 1;
 
 for k = 1:m
  % number of iterations
  nit = nit + 1;
  
  % construction of the basis vectors and entries of H (in the last column of H)
  
  if k == 1
   % first iteration
   % choose the optimal value for the first column of H
   v = V(:,1);
   vAv = v' * Av;
   vAAv = Av' * Av;
   dotprod = dotprod + 2;
   
   if abs(vAv) <= 1e-14
    % breakdown
    fprintf('\n gm_QORm_CGLS_err_prec: Initialization breakdown, v^T A v = %g \n',vAv)
    H(1,1) = 0;
   else
    H(1,1) = vAAv / vAv;
   end % if abs
   
   % new basis vector (to be normalized)
   vt = Av - H(1,1) * V(:,1);
   H(2,1) = norm(vt);
   dotprod = dotprod + 1;
   % new basis vector
   V(:,2) = vt / H(2,1);
   HH(1:2,1) = H(1:2,1);
   
   % matrix-vector product
   if left == 1
    % left preconditioner
    Av = A * V(:,2);
    % solve of M z = Av
    z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
    Av = z;
   else % if left (right preconditioner)
    z = gm_solve_precond_ns(A,V(:,2),precond,cprec,cprec_amg);
    Av = A * z;
   end % if left
   matvec = matvec + 1;
   
  else % k ~= 1
   
   % other iterations
   % solve the least squares problem approximately using gm_CGLS
   epsil = 1e-6;
   iter = 3;
   [y,~,~,~,itn] = gm_CGLS(V(:,1:k),Av,[],epsil,iter,0);
   matvrect = matvrect + 2 * k * itn + 1;
   dotprod = dotprod + 3 * itn + 1;

   % new column of H
   H(1:k,k) = y;
   vt = Av - V(:,1:k) * y;
   h = norm(vt);
   dotprod = dotprod + 1;
   % subdiagonal entry of H
   H(k+1,k) = h;
   
   if k < m
    % new basis vector
    V(:,k+1) = vt / H(k+1,k);
    % matrix-vector product
    if left == 1
     % left preconditioner
     Av = A * V(:,k+1);
     % solve of M z = Av
     z = gm_solve_precond_ns(A,Av,precond,cprec,cprec_amg);
     Av = z;
    else % if left (right preconditioner)
     z = gm_solve_precond_ns(A,V(:,k+1),precond,cprec,cprec_amg);
     Av = A * z;
    end % if left
    matvec = matvec + 1;
    
   end % if k < m
  end % if k == 1
  
  % reduce H to upper triangular form with Givens rotations
  gk1 = H(k+1,k);
  % save the new column of H
  HH(1:k+1,k) = H(1:k+1,k);
  
  % apply the preceding Givens rotations to the last column just computed
  for kk = 1:k-1
   g1 = H(kk,k);
   g2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk
  
  % error estimates from the paper:
  %  Estimates of the norm of the error in solving linear systems with FOM
  %  and GMRES, SIAM J. Sci. Comp., v 33, (2011), pp. 2686-2705
  
  if k > delay
   dd = delay;
   % partitioning of HH
   Hk = HH(1:k-dd,1:k-dd);
   Wk = HH(1:k-dd,k-dd+1:k);
   Hkt = HH(k-dd+1:k,k-dd+1:k);
   hkp = HH(k-dd+1,k-dd);
   e1t = zeros(dd,1);
   e1t(1) = 1;
   % hkt1 = Hkt \ e1t;
   [Qkt,Rkt] = qr(full(Hkt));
   hkt1 = Rkt \ (Qkt' * e1t);
   wk = Wk * hkt1;
   % hkwk1 = Hk \ wk;
   [Qk,Rk] = qr(full(Hk));
   hkwk1 = Rk \ (Qk' * wk);
   e1 = zeros(k-dd,1);
   e1(1) = 1;
   % hk1 = Hk \ e1;
   hk1 = Rk \ (Qk' * e1);
   ekhk1 = hk1(k-dd);
   ekhkw = hkwk1(k-dd);
   gammak = hkp * ekhk1 / (1 - hkp * ekhkw);
   sk1 = ekhk1 + gammak * ekhkw;
   % ekk = estimate of the FOM error
   ekk = (hkp * sk1)^2 * (hkt1'*hkt1) + gammak^2 * (hkwk1' * hkwk1);
   el = zeros(k-dd,1);
   el(k-dd) = 1;
   yy = Qk * ( Rk' \ el);
   % vector tk = inv(H_k' H_k) e_k
   tk = Rk \ (Qk' * yy);
   tkk = tk(k-dd);
   dkp = hkp^2 / (1 + hkp^2 * tkk);
   uk = dkp * tk;
   % additional term for GMRES
   add = 2 * gammak * ekhk1 * (hkwk1' * uk) + ekhk1^2 * norm(uk)^2;
   if ekk + add > 0
    err(nit-dd) = sqrt(nr * (ekk + add));
   else
    err(nit-dd) = 0;
   end % if
  end % if k
  
  if trueres == 1 || l2norm == 1
   % computation of the true (if left = 0) residual norm
   % triangular solve
   y = triu(H(1:k,1:k)) \ rhs(1:k);
   xx = x0 + V(:,1:k) * y;
   if left == 0
    % right preconditioner
    xx = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
   end % if left
   % this is also not the true residual norm if there is some scaling
   if trueres == 1
    resnt(nit+1) = norm(b - A * xx);
   end % if
   if l2norm == 1
    norml2(nit+1) = norm(xec -xx);
   end % if
  end % if trueres
  
  % nresidu is the estimate of the residual norm given by GMRES
  yk = rhs(k) / H(k,k);
  nresidu = gk1 * abs(yk);
  resid = nresidu^2;
  
  if iprint == 1
   fprintf('cycle = % d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,nit,nresidu,nresidu/nb)
  end
  
  resn(nit+1) = nresidu;
  matv(nit+1) = matvec;
  
  % convergence test or too many iterations
  if nresidu < (epsi * nb) || nit >= nitmax
   % convergence
   iconv = 1;
   break
  end % if nresidu
  
  if k < m
   % compute, store and apply a new Givens rotation to zero the last term in kth column
   gk = H(k,k);
   if gk == 0
    rot(1,k) = 0;
    rot(2,k) = 1;
   elseif gk1 == 0
    rot(1,k) = 1;
    rot(2,k) = 0;
   else
    cs = sqrt(abs(gk1)^2 + abs(gk)^2);
    if abs(gk) < abs(gk1)
     mu = gk / gk1;
     tau = conj(mu) / abs(mu);
    else
     mu = gk1 / gk;
     tau = mu / abs(mu);
    end % if
    % store the rotation for the next columns
    rot(1,k) = abs(gk) / cs; % cosine
    rot(2,k) = abs(gk1) * tau / cs; % sine
   end % if gk
   
   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k
  
 end %  for k - end of one cycle
 
 % computation of the solution at the end of the cycle
 % triangular solve
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;
 
 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
  end % if left
  % ------ exit
  resn = resn(1:nit+1);
  err = err(1:nit);
  
  if trueres == 1
   resnt = resnt(1:nit+1);
  end
  if l2norm == 1
   norml2 = norml2(1:nit+1);
  end % if
  % return code
  iret= 0;
  if nit == nitmax
   iret = 2;
  end
  
  if iprint == 1
   if nit == nitmax
    fprintf('\n No convergence after %d iterations \n',nit)
   else
    fprintf('\n Convergence after %d iterations \n',nit)
   end % if
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
   if  reorth > 0
    fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   end
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
   fprintf(' Number of rectangular matrix-vector products in CGLS = %d \n\n',matvrect)
  end % if iprint
  
  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  else
   results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
  end % if timing
  
  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end
  
  results.resn = resn;
  if trueres == 1
   results.resnt = resnt;
  end % if
  if l2norm == 1
   results.norml2 = norml2;
  end % if
  results.err = err;
  
  return
  
 end % if iconv
 
 % we have not converged yet, compute the residual and restart
 
 xx = x;
 if left == 0
  % right preconditioner
  xx = gm_solve_precond_ns(A,x,precond,cprec,cprec_amg);
 end % if left
 
 % residual vector
 r = b - A * xx;
 matvec = matvec + 1;
 
 if left == 1
  % left preconditioner
  % generalized residual M z = r
  z = gm_solve_precond_ns(A,r,precond,cprec,cprec_amg);
 else
  z = r;
 end % if left
 
 r = z;
 
 x0 = x;
 rk = r' * r;
 nr = rk;
 resid = rk;
 bet = norm(r);
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 HH = H;
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 
 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,nit,bet,bet/nb)
 end % if
 
end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
resn = resn(1:nit);
err = err(1:nit);

if trueres == 1
 resnt = resnt(1:nit);
end % if
if l2norm == 1
 norml2 = norml2(1:nit);
end % if
if nit == nitmax
 iret = 2;
end % if

xx = x;
if left == 0
 % right preconditioner
 x = gm_solve_precond_ns(A,xx,precond,cprec,cprec_amg);
end % if left

if iprint == 1
 fprintf('\n No convergence after %d iterations \n',nit)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,nit)
 if reorth > 0
  fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 end % if
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/nit)
 fprintf(' Number of rectangular matrix-vector products in CGLS = %d \n\n',matvrect)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end % if
 results.timing = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
else
 results.timing = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:nit+1));
end % if timing

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end % if

results.resn = resn;
if trueres == 1
 results.resnt = resnt;
end % if
if l2norm == 1
 results.norml2 = norml2;
end % if
results.err = err;

% warning on
