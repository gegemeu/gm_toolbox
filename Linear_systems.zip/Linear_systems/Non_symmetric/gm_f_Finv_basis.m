function f=gm_f_Finv_basis(x);
%GM_F_FINV_BASIS function for the minimization of the Frobenius norm of the inverse of V_k^T V_k
% the inverse of V_k^T V_k

%
% Author G. Meurant
% Feb 2016
%

global B VV;

v = B * transpose(x);
v = v / norm(v);

V = [VV v];
VTV = inv(V' * V);

f = norm(VTV,'fro');

