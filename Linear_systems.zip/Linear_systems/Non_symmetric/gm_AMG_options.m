function [epsi,nitmax,scaling,trueres,iprint,timing,l2norm] = gm_AMG_options(A,options);
%GM_AMG_OPTIONS get the options for the AMG solver

% Input:
% options is a structure containing all or some of the following fields with defaults ():
% epsi = threshold for stopping criterion (1e-10)
%  (stop if norm(r^k) <= epss norm(b) or nit > nitmax
% nitmax = maximum number of iterations (order of A)
% scaling = 1, diagonally scales the matrix before preconditioning (0)
% trueres = 1 computes the norm of b - A x_k (0)
% iprint = 1 print residual norms at every iteration (0)
% timing = 1, time measurements (0)
% l2norm = 1, computes the ell_2 norm of the error (0)

%
% Author G. Meurant
% January 2025
%

% Defaults

n = size(A,1);

if isempty(options)
 epsi = 1e-10;
 nitmax = n;
 scaling = 0;
 trueres = 0;
 iprint = 0;
 timing = 0;
 l2norm = 0;
else
 if isfield(options,'epsi')
  epsi = options.epsi;
 else
  epsi = 1e-10;
 end % if
 if isfield(options,'nitmax')
  nitmax = options.nitmax;
 else
  nitmax = n;
 end % if
 if isfield(options,'scaling')
  scaling = options.scaling;
 else
  scaling = 0;
 end % if
 if isfield(options,'trueres')
  trueres = options.trueres;
 else
  trueres = 0;
 end % if
 if isfield(options,'iprint')
  iprint = options.iprint;
 else
  iprint = 0;
 end % if
 if isfield(options,'timing')
  timing = options.timing;
 else
  timing = 0;
 end % if
 if isfield(options,'l2norm')
  l2norm = options.l2norm;
 else
  l2norm = 0;
 end % if
end % if isempty

if timing == 1
 % if we measure the time we turn off printing, true residual norms, and error norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end % if
 trueres = 0;
 l2norm = 0;
end % if

% if iprint == 1
%  fprintf('\n gm_Krylov_ns_options: \n\n')
%  fprintf('  precond = %s \n',precond)
%  fprintf('  epsi =    %12.5e \n',epsi)
%  fprintf('  scaling = %d \n',scaling)
%  fprintf('  trueres = %d \n',trueres)
%  fprintf('  iprint  = %d \n',iprint)
%  fprintf('  timing  = %d \n',timing)
% end % if

