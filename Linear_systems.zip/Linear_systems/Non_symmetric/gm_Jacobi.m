function [x,nit,resnt] = gm_Jacobi(A,b,x0,epss,nitmax);
%GM_JACOBI Jacobi iterative method

% Input:
% x0 = starting vector
% epss = threshold for the stopping criterion
% nitmax = maximum number of iterations

% Output:
% x = approximate solution
% nit = number of iterations
% resnt = true residual norms

%  
% Author G. Meurant
%

nb = norm(b);
resnt = zeros(1,nitmax+1);
d = spdiags(A,0);
d1 = 1 ./ d;

x = x0;
dx = d .* x;
r = b - A * x;
resnt(1) = norm(r);
nit = 0;
resid = realmax;

while (resid >= epss*nb) && (nit < nitmax)
 nit = nit + 1;
 dx = r + dx;
 x = d1 .* dx;
 r = b - A * x;
 resid = norm(r);
 resnt(nit+1) = resid;
end
