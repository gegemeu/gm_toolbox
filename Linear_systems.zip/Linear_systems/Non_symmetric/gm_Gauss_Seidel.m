function [x,nit,resnt] = gm_Gauss_Seidel(A,b,x0,epss,nitmax);
%GM_GAUSS_SEIDEL Gauus-Seidel iterative method

% Input:
% x0 = starting vector
% epss = threshold for the stopping criterion
% nitmax = maximum number of iterations

% Output:
% x = approximate solution
% nit = number of iterations
% resnt = true residual norms

%  
% Author G. Meurant
%

nb = norm(b);
resnt = zeros(1,nitmax+1);
DL = tril(A);
U = triu(A,1);

x = x0;
r = b - A * x;
resnt(1) = norm(r);
nit = 0;
resid = realmax;

while (resid >= epss*nb) && (nit < nitmax)
 nit = nit + 1;
 x = DL \(b - U * x);
 r = b - A * x;
 resid = norm(r);
 resnt(nit+1) = resid;
end % while
