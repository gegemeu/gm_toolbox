function [leja,cpts,scalefactor]=gm_lejashifts_R(ritzvalues,nmbnlpts,leja,cpts,scalefactor);
%GM_LEJASHIFTS_R Fast Leja points on spoke sets

% Input:
%   leja  array of leja points that have been determined during previous
%         calls. this array is augmented with new leja points and then
%         provided as output. the Leja points are also stored in the cpts
%         array. the purpose of the array leja is easy access.
%   cpts  array of leja and candidate points that have been determined at
%         previous call. not required if no Leja poinst available.
%   nmbnlpts  number of (new) pairs of complex conjugate Leja points to be
%         computed. if Leja point real, then just a single point is determined.
%   ritzvalues  leja points are determined on the "legs" between the ritz
%         and the average ritz value. the n by 2 matrix ritzvalues represents
%         the real and imaginary parts of the Ritz values. only points with
%         nonnegative imaginary part are stored. Each call generates a new
%         set of "legs". old "legs" are kept.
%   scalefactor is used to scale the products at all calls but the first one
%         the parameter is set to half the length of the longest "leg" at the
%         first call.
%
% Output:
%   leja  m by 2 array with real and imaginary parts of Leja points. the points
%         are symmetric wrt the real axis. if the imaginary part leja(k,2)>0,
%         then the kth row of leja represents the 2 Leja points
%         leja(k,1)+i*leja(k,2) and leja(k,1)-i*leja(k,2)
%   cpts  n by 2 array of candidate points. they are generated during the
%         computation of Leja points. this array has to be used as input
%         when an available set of Leja points is to be augmented.
%   scalefactor is set to distance between 1st and 2nd Leja point (which
%         approximates the diameter) at the first call.
%
% Possible function calls:
%
% [leja,cpts,scalefactor]=lejashifts(ritzvalues);
%     initialization of cpts and leja. one Leja point is computed and
%     scalefactor is defined. the leja point is put at the center. before
%     subsequent calls, the ritz values in ritzvalues should be scaled by
%     multiplication by the factor scalefactor.
%
% [leja,cpts]=lejashifts([],nmbnlpts,leja,cpts,scalefactor);
%     set of Leja points is augmented by nmbnlpts Leja points on same convex
%     hull. scalefactor set to 1.
%
% [leja,cpts]=lejashifts(ritzvalues,nmbnlpts,leja,cpts,scalefactor);
%     set of Leja points is augmented by nmbnlpts Leja points on new convex
%     hull. scalefactor set to 1.

% code from Lothar Reichel

if nargin == 1
 
 % no leja and candidate points exist. define data structure.
 % x-coordinate of Ritz values stored in ritzvalues(:,1), y-coordinate
 % in ritzvalues(:,2). ritz values assumed to be complex conjugate. only
 % ritz values with nonnegative imaginary part stored in ritzvalues.
 % generate vectors x and y that stores cooordinates for all ritz values.
 nmbritz = size(ritzvalues(:,1),1);
 midptx = sum(ritzvalues(:,1)) / nmbritz;
 midpty = 0;
 
 % cpts data structure defined below for candidate and leja points. the
 % set cpts consist all ritz values and kk additional randomly distributed
 % points on each leg between the midpoint and a ritz value.
 
 kk = 5;
 nmbpts = (kk + 2) * nmbritz;
 
 % define data structure points for points on the convex hull: each row
 % corresponds to one point. the entries of the
 %   1st column contain the x-coordinate,
 %   2nd column contains the y-coordinate,
 %   3th column contains the index (row number) for the previous point on
 %     the convex hull traversed clockwise,
 %   4th column contains the index (row number) for the next point on
 %     the convex hull traversed clockwise,
 %   5th column 1 if leja point, 0 otherwise
 
 cpts = zeros(nmbpts,5);
 for k = 1:nmbritz
  cpts((kk+2)*(k-1)+1,1) = midptx;
  cpts((kk+2)*(k-1)+1,2) = midpty;
  cpts((kk+2)*(k-1)+1,5) = 1; % mark as leja point
  rc = sort(rand(kk,1));  % random coordinates between 0 and 1
  %     rc = gm_leja_shift(0,1,kk); % Leja points on [0, 1]
  for j = 1:kk
   cpts((kk+2)*(k-1)+j+1,1) = midptx + (ritzvalues(k,1) - midptx) * rc(j);
   cpts((kk+2)*(k-1)+j+1,2) = midpty + (ritzvalues(k,2)-midpty) * rc(j);
  end % for j
  cpts((kk+2)*k,1) = ritzvalues(k,1);
  cpts((kk+2)*k,2) = ritzvalues(k,2);
  for j = (kk+2)*(k-1)+2:(kk+2)*k
   cpts(j,3) = j-1;
  end % for j
  for j = (kk+2)*(k-1)+1:(kk+2)*k-1
   cpts(j,4) = j + 1;
  end % for j
 end % for k
 
 % let the first Leja point be mid point
 % its index is li
 leja = [midptx, midpty];
 
 % compute diameter approximation
 scalefactor = max((ritzvalues(:,1) - leja(1,1)).^2 + (ritzvalues(:,2) - leja(1,2)).^2);
 scalefactor = sqrt(scalefactor) / 2;
 
 % initialization of leja and cpts finished. exit
 
end % if nargin

if isempty(ritzvalues)
 
 % generate new Leja points for the spoke set defined by cpts
 [cpts,leja] = gm_fastlejasym_R(cpts,leja,nmbnlpts,scalefactor);
 
 % exit
 
end % if isempty

if nargin == 5 && ~isempty(ritzvalues)
 
 % determine new set of legs from ritz values and allocate leja points
 
 nmbritz = size(ritzvalues(:,1),1);
 midptx = sum(ritzvalues(:,1))/nmbritz;
 midpty = 0;
 
 % cpts data structure defined below for candidate and leja points. the
 % set cpts consist all ritz values and kk additional randomly distributed
 % points on each leg between the midpoint and a ritz value.
 
 kk = 5;
 nmbpts = (kk + 2) * nmbritz;
 
 % define data structure points for points on the convex hull: each row
 % corresponds to one point. the entries of the
 %   1st column contain the x-coordinate,
 %   2nd column contains the y-coordinate,
 %   3th column contains the index (row number) for the previous point on
 %     the convex hull traversed clockwise,
 %   4th column contains the index (row number) for the next point on
 %     the convex hull traversed clockwise,
 %   5th column 1 if leja point, 0 otherwise
 
 offset = size(cpts,1);
 newcpts = zeros(nmbpts,5);
 for k = 1:nmbritz
  newcpts((kk+2)*(k-1)+1,1) = midptx;
  newcpts((kk+2)*(k-1)+1,2) = midpty;
  newcpts((kk+2)*(k-1)+1,5) = 1; % mark as leja point
  rc = sort(rand(kk,1));  % random coordinates between 0 and 1
  %     rc = gm_leja_shift(0,1,kk); % Leja points on [0, 1]
  for j = 1:kk
   newcpts((kk+2)*(k-1)+j+1,1) = midptx + (ritzvalues(k,1) - midptx) * rc(j);
   newcpts((kk+2)*(k-1)+j+1,2) = midpty + (ritzvalues(k,2) - midpty) * rc(j);
  end % for j
  newcpts((kk+2)*k,1) = ritzvalues(k,1);
  newcpts((kk+2)*k,2) = ritzvalues(k,2);
  for j = (kk+2)*(k-1)+2:(kk+2)*k
   newcpts(j,3) = j - 1 + offset;
  end % for j
  for j = (kk+2)*(k-1)+1:(kk+2)*k-1
   newcpts(j,4) = j + 1 + offset;
  end % for j
 end % for k
 
 % merge newcpts with cpts
 
 cpts = [cpts; newcpts];
 [cpts,leja] = gm_fastlejasym_R(cpts,leja,nmbnlpts,scalefactor);
 
end % if nargin == 5

