function [x,nit,iret,resn,resnt,time_mat]=gm_FOMm_prec(A,b,x0,epsi,nitmax,m,lefts,reorths,scalings,trueress,iprints,precond,lorth,varargin);
%GM_FOMM_PREC restarted FOM(m) for a matrix A with m directions and preconditioning

% see: Y. Saad, Krylov subspace methods for solving large unsymmetric linear systems, 
%               Math. Comp., v 37 n 155 (1981), pp. 105-126

% uses Modified Gram-Schmidt

%
% Input:
% b = right-hand side, x0 = initial vector
% epsi = convergence threshold for the residual norm
% nitmax  = maximum number of iterations
%  if nitmax < 0 we measure the computing time and set iprint = 0
% m = restarting parameter, FOM(m)
% lefts = 'left' left preconditioning, otherwise right preconditioning
% reorths = 'reorth' with full reorthogonalization, 
%         = 'sorth' selective reorthogonalization
% scalings = 'scaling', diagonally scales the matrix before preconditioning
% trueress = 'trueres' computes the norm of b - A x_k
% iprints = 'print' print residual norms at every iteration
% precond = type of preconditioning
%  = 'no' without preconditioning M = I
%  = 'sc' diagonal
%  = 'ss' SSOR omega = 1
%  = 'gs' Gauss-Seidel
%  = 'lu' ILU(0) Incomplete LU without pivoting
%  = 'lm' Matlab ILU with threshold
%  = 'lb' Incomplete block LU
%  = 'ai' Approximate inverse AINV of Benzi
%  = 'gp' given preconditioning matrix M in varargin
%         inv(M)A x = inv(M)b or A inv(M) x = b
%  = 'ml' multilevel AMG preconditioner
% lorth = threshold for selective reorthogonalization
%
% varargin = block size if precond = 'lb'
%          = M if precond = 'gp'
%          = [alpha, q] for AINV, alpha = threshold, q = max number of non
%          zero entries in one row
%
%  parameters for preconditioner 'ml' in varargin
%   lmax = max number of levels
%   nu = number of smoothing steps
%   almax = parameter alpha for the influence matrix
%   alb = parameter alpha for the generation of grids with AINV
%   smooth = type of smoothing operator (any of the above preconditioners)
%   influ = type of influence matrix
%   coarse = type of coarsening algorithm
%   interpo = type of interpolation algorithm
%   q = number of entries kept in a column for smoother AINV (default =
%       size(A,1))
%
% Output:
% x = approximate solution
% nit = number of iterations
% iret = return code,  = 0 if convergence, = 1 if init problem, = 2 no conv
% after nitmax iterations
% resn = (preconditioned) residual norms
% resnt = true residual norms
% time_mat = if nitmax < 0 time_mat is a structure containing the init and iteration
%  times, the number of matrix-vector products, the number of inner products and the
%  number of matrix-vector products as a function of the iteration number,
%  otherwise same without the first two items
%

%
% Author G. Meurant
% Dec 2001, july 2006, may 2007
% October 2009: modification to handle complex matrices
% March 2015
%

% warning off

if nargin < 3
 x0 = zeros(size(A,1),1);
end

if nargin < 4
 epsi = 1e-10;
end

timing = 0;
if nargin < 5
 nitmax = size(A,1);
else
 if nitmax < 0
  nitmax = -nitmax;
  timing = 1;
  prints = 'noprint';
 end
end

n = size(A,1);

if nargin < 6
 m = n;
end

if timing == 1
 tic
end

nb = length(b);
nx = length(x0);

if nb ~= n
 error('gm_FOMm_prec: error, the dimensions of A and b are not compatible')
end
if nb ~= nx
 error('gm_FOMm_prec: error, the dimensions of x and b are not compatible')
end

% Defaults
if nargin < 7
 % left preconditioning
 left = 1;
 lefts = 'left';
end
if nargin < 8
 % no reorthogonalization
 reorth = 0;
 sorth = 0;
 reorths = 'noreorth';
end
if nargin < 9
 % no scaling
 scaling = 0;
 scalings = 'noscaling';
end
if nargin < 10
 % do not compute the true residual norm
 trueres = 0;
 trueress = 'notrueres';
end
if nargin < 11
 % no printing
 iprint = 0;
 prints = 'noprint';
end
if nargin < 12
 % no preconditioning
 precond = 'no';
end
if nargin < 13 && (strcmpi(reorths,'sorth') == 1)
 lorth = sqrt(eps);
end
if nargin < 13 && (strcmpi(reorths,'sorth') ==0)
 lorth = 0;
end

if nargin > 7 && (strcmpi(lefts,'left') == 1)
 left = 1;
else
 left = 0;
end
if nargin > 8 && (strcmpi(reorths,'reorth') == 1)
 reorth = 1;
 sorth = 0;
else
 reorth = 0;
end
if nargin > 8 && (strcmpi(reorths,'sorth') == 1)
 sorth = 1;
 reorth = 0;
else
 sorth = 0;
end
if nargin > 9 && (strcmpi(scalings,'scaling') == 1)
 scaling = 1;
else
 scaling = 0;
end
if nargin > 10 && (strcmpi(trueress,'trueres') == 1)
 trueres = 1;
else
 trueres = 0;
end
if nargin > 11 && (strcmpi(iprints,'print') == 1)
 iprint = 1;
else
 iprint = 0;
end

if timing == 1
 % if we measure the time we turn off printing and true residual norms
 if iprint == 1
  iprint = 2;
 else
  iprint = 0;
 end
 trueres = 0;
end

if m > nitmax
 m = nitmax;
end

if m == 0
 m = 10;
end

if iprint == 1
 fprintf('\n gm_FOMm_prec: \n\n')
 fprintf('  max iter = %d \n',nitmax)
 fprintf('  restart parameter = %d \n',m)
 fprintf('  precond = %s \n',precond)
 fprintf('  left = %d \n',left)
 fprintf('  reorth = %d \n',reorth)
 fprintf('  sorth = %d, threshold = %g \n',sorth,lorth)
 fprintf('  scaling = %d \n',scaling)
 fprintf('  trueres = %d \n',trueres)
 fprintf('  iprint = %g \n',iprint)
end

tb = 1;
if nargin >= 14 && (strcmpi(precond,'lb') == 1)
 % block size for the block ILU preconditioner if needed
 tb = varargin{1};
 if rem(n,tb(1)) ~= 0 && (strcmpi(precond,'lb') == 1)
  error('gm_FOMm_prec: error, the block size tb has to divide exactly the dimension of A')
 end
 if iprint == 1
  fprintf('  block size = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'lm') == 1)
 % threshold for the Matlab ILU preconditioner 
 tb = varargin{1};
 if iprint == 1
  fprintf('  ilu threshold = %g \n',tb)
 end
end

if nargin >= 14 && (strcmpi(precond,'gm') == 1)
 % number of iterations for GMRES 
 tb = varargin{1};
 if iprint == 1
  fprintf('  nb of inner iterations = %g \n',tb)
 end
end

if nargin >= 14 &&  ((strcmpi(precond,'ai') == 1) || ...
  (strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 %  tb = [alp, q] for AINV
 tb = varargin{1};
 if  strcmpi(precond,'ai') == 1 && length(tb) == 1
  tb = [tb n];
 end
end

if nargin < 14 && (strcmpi(precond,'ai') == 1)
 tb = [0.1, n];
end

if nargin < 14 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 % for these preconditioners tb is the level number
 tb = 0;
end

if iprint == 1 && (strcmpi(precond,'ai') == 1)
 fprintf('  alpha = %g \n',tb(1))
 fprintf('  q = %g \n',tb(2))
end

if iprint == 1 && ((strcmpi(precond,'sh') == 1) || (strcmpi(precond,'wl') == 1))
 fprintf('  level = %g \n',tb(1))
end

M = [];
if nargin >= 14 && (strcmpi(precond,'gp') == 1)
 % given preconditioning matrix
 M = varargin{1};
end
if (strcmpi(precond,'gp') == 1) && size(M,1) ~= n
 error('gm_FOMm_prec: error, M has to be of the same order as A')
end

if nargin >= 14 && strcmpi(precond,'ml') == 1
 % get the input parameters for the multilevel AMG method
 if nargin < 21
  error('gm_FOMm_prec: some parameters are not defined for ML')
 end

 lmax = varargin{1};
 nu = varargin{2};
 alpmax = varargin{3};
 alb = varargin{4};
 smooth = varargin{5};
 infl = varargin{6};
 coarse = varargin{7};
 interpo = varargin{8};
 if nargin > 21
  qmin = varargin{9};
 else
  qmin = n;
 end
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
end

if nargin < 14 && strcmpi(precond,'ml') == 1
 % defaults for AMG
 lmax = 10;
 nu =1;
 alpmax = 0.1;
 alb = 0.1;
 smooth = 'lu';
 infl = 'b';
 coarse = 'st';
 interpo = 'st';
 qmin = n;
 gam = 1;
 falp = 1;
 alq = 1;
 normal = 0;
 
 if iprint == 1
  fprintf('\n -----------default ml parameters \n')
  fprintf(' lmax = %d \n',lmax)
  fprintf(' nu = %d \n',nu)
  fprintf(' alpmax = %g \n',alpmax)
  fprintf(' alb = %g \n',alb)
  fprintf(' smooth = %s \n',smooth)
  fprintf(' infl = %s \n',infl)
  fprintf(' coarse = %s \n',coarse)
  fprintf(' interpo = %s \n',interpo)
 end
 
end

x = [];
nit = 0;
iret = 0;
resn = [];
resnt = [];
time_mat = [];

% For robustness we may symmetrically scale the matrix
if scaling == 1
 % diagonal scaling
 [A,dda] = gm_normaliz(A);
 b = dda .* b;
else
 dda = ones(n,1);
end

% ------------------Initialization

% number of matrix-vector products and inner products
matvec = 0;
dotprod = 0;

xin = zeros(n,1);

% init of preconditioners
if ~strcmpi(precond,'ml')
 [DD,LL,UU] = gm_initprecns(A,precond,tb);
 if strcmpi(precond,'gp')
  LL = M;
 end
else
 % multilevel preconditioner
 [cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,err] = gm_amg_ns_init(A,alpmax,alb,lmax,falp,qmin,alq,...
  smooth,infl,coarse,interpo,normal,iprint);
 if err == 1
  fprintf('\n gm_FOMm_prec: Error in gm_amg_ns_init \n')
  iret = 1;
  return
 end
end

x = x0;

if iprint == 1
 fprintf('\n Initial true residual norm = %12.5e \n',norm(b - A * x))
end

if left == 0
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(x0,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,x0,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
end

% initial residual vector
r = b - A * x;
matvec = matvec + 1;

if trueres == 1
 resnt = zeros(1,nitmax);
 resnt(1) = norm(r);
end

if left == 1
 % generalized residual M z = r
 if strcmpi(precond,'ml') == 0
  z = gm_solveprecns(r,A,DD,LL,UU,precond);
 else
  z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
else
 z = r;
end % if left

r = z;
rhs = zeros(m+1,1);
% H contains the (modified) upper Hessenberg matrix
H = zeros(m+1,m);
resn = zeros(1,nitmax);
r0 = r' * r;
bet = norm(r);
dotprod = dotprod + 2;

if iprint == 1
 fprintf(' Initial (preconditioned) residual norm = %12.5e \n\n',bet)
end

% number of cycles
nitd = 0;
% number of iterations
ni = 0;
iconv = 0;
resn(1) = bet;
rhs(1) = bet;
resid = realmax;
epss = epsi^2;
% number of reorthogonalizations
nreo = 0;
matv(1) = matvec;

if timing == 1
 tinit = toc;
 if iprint == 2
  fprintf('\n Initialization time = %g \n\n',tinit)
 end
 tic
end

% -------------------Iterations

while resid > (epss * r0) && (ni < nitmax)
 
 % ---- Loop on cycles
 
 % number of cycles
 nitd = nitd + 1;
 
 % init basis vectors
 V = zeros(n,m+1);
 % init Givens rotations
 rot = zeros(2,m);
 % the first vector is the last residual normalized
 v = r / bet;
 V(:,1) = v;

 % start a cycle of FOM(m)
 
 for k = 1:m
  % number of iterations
  ni = ni + 1;
  
  % matrix vector product
  if left == 1
   % left preconditioner
   Av = A * v;
   % solve of M z = Av
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(Av,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,Av,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if ~
   Av = z;
  else % if left (right preconditioner)
   if strcmpi(precond,'ml') == 0
    z = gm_solveprecns(v,A,DD,LL,UU,precond);
   else
    z = gm_amg_ns_it(A,v,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end % if ~
   Av = A * z;
  end % if left
  matvec = matvec + 1;
  w = Av;

  if sorth == 1
   % for selective reorthogonalization
   gin = norm(w);
   dotprod = dotprod + 1;
  end

  % construction of the basis vectors (modified Gram-Schmidt)
  % and entries of H (in the last column of H)
  for l = 1:k
   vl = V(:,l);
   gl = vl' * w;
   H(l,k) = gl;
   w = w - gl * vl;
  end % for l
  dotprod = dotprod + k;
  dk = w;

  % reorthogonalization (twice is enough)
  if reorth == 1
   nreo = nreo + 1;
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end % for j
   dotprod = dotprod + k;
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end % for j
   dotprod = dotprod + k;
   dk = w;
  end % if reorth

  % selective reorthogonalization
  if (sorth == 1) && (norm(w) < lorth * gin)
   nreo = nreo + 1;
   % reorthogonalization
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end
   dotprod = dotprod + k;
   % twice
   for j = 1:k
    vj = V(:,j);
    alpha = vj' * w;
    dotprod = dotprod + 1;
    w = w - alpha * vj;
    H(j,k) = H(j,k) + alpha;
   end
   dotprod = dotprod + k;
   dk = w;
  end % if selective reorth

  % normalization of the new basis vector
  gk = norm(dk);
  dotprod = dotprod + 1;
  v = dk / gk;
  H(k+1,k) = gk;
  % next basis vector
  V(:,k+1) = v;
  gk1 = gk;

  % apply the preceding Givens rotations to the last column just computed
  for kk = 1:k-1
   g1 = H(kk,k);
   g2 = H(kk+1,k);
   H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
   H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
  end % for kk

  % nresidu is the estimate of the residual norm given by FOM
  yk = rhs(k) / H(k,k);
  nresidu = gk * abs(yk);
  resn(ni+1) = nresidu;
  matv(ni+1) = matvec;

  if iprint == 1
   fprintf('cycle = % d, nit = %d, residual norm = %12.5e, relative residual norm = %12.5e \n',nitd,ni,nresidu,nresidu/sqrt(r0))
  end

  if trueres == 1
   % computation of the true (if left = 0) residual norm
   % triangular solve
   y = triu(H(1:k,1:k)) \ rhs(1:k);
   xx = x0 + V(:,1:k) * y;
   if left == 0
    % right preconditioner
    if strcmpi(precond,'ml') == 0
     xx = gm_solveprecns(xx,A,DD,LL,UU,precond);
    else
     xx = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
    end
   end
   % this is also not the true residual norm if there is some scaling
   resnt(ni+1) = norm(b - A * xx);
  end

  % convergence test or too many iterations
  if nresidu < (epsi * sqrt(r0)) || ni >= nitmax
   % convergence
   iconv = 1;
   % get out of the loop
   break
  end % if nresidu

  if k < m
   % compute, store and apply a new rotation to zero the last term in kth column
   gk = H(k,k);
  if gk == 0
   rot(1,k) = 0;
   rot(2,k) = 1;
  elseif gk1 == 0
   rot(1,k) = 1;
   rot(2,k) = 0;
  else
   cs = sqrt(abs(gk1)^2 + abs(gk)^2);
   if abs(gk) < abs(gk1)
    mu = gk / gk1;
    tau = conj(mu) / abs(mu);
   else
    mu = gk1 / gk;
    tau = mu / abs(mu);
   end % if
   % store the rotation for the next columns
   rot(1,k) = abs(gk) / cs; % cosine
   rot(2,k) = abs(gk1) * tau / cs; % sine
  end % if gk

   % modify the diagonal entry and the right-hand side
   H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
   c = rhs(k);
   rhs(k) = rot(1,k) * c;
   rhs(k+1) = -rot(2,k) * c;
  end % if k < m

 end %  for k - end of one cycle

 % computation of the solution at the end of the cycle
 % triangular solve
 y = triu(H(1:k,1:k)) \ rhs(1:k);
 x = x0 + V(:,1:k) * y;

 if iconv == 1
  % we have to stop
  xx = x;
  if left == 0
   % right preconditioner
   if strcmpi(precond,'ml') == 0
    x = gm_solveprecns(xx,A,DD,LL,UU,precond);
   else
    x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
   end
  end % if left
  % ------ exit
  resn = resn(1:ni+1);
  if trueres == 1
   resnt = resnt(1:ni+1);
  end
  % number of total iterations
  nit = ni;
  % return code
  iret= 0;
  if ni == nitmax
   iret = 2;
  end

  if iprint == 1
   if ni == nitmax
    fprintf('\n No convergence after %d iterations \n',ni)
   end
   fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
   fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
   if sorth ==1 || reorth == 1
    fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
   end
   fprintf(' Number of matrix-vector products = %d \n\n',matvec)
   fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
  end % if iprint

  % if scaling go back to the solution of the original system
  if scaling == 1
   x = dda .* x;
  end

  if timing == 1
   titer = toc;
   if iprint == 2
    fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
   end
   time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  else
   time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
  end

  return
 end % if iconv

 % we have not converged yet, compute the residual and restart

 xx = x;
 if left == 0
  % right preconditioner
  if strcmpi(precond,'ml') == 0
   xx = gm_solveprecns(x,A,DD,LL,UU,precond);
  else
   xx = gm_amg_ns_it(A,x,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if ~
 end % if left

 % residual vector
 r = b - A * xx;
 matvec = matvec + 1;

 if left == 1
  % left preconditioner
  % generalized residual M z = r
  if strcmpi(precond,'ml') == 0
   z = gm_solveprecns(r,A,DD,LL,UU,precond);
  else
   z = gm_amg_ns_it(A,r,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
  end % if ~
 else
  z = r;
 end % if left

 r = z;
 x0 = x;
 resid = r' * r;
 bet = norm(r);
 dotprod = dotprod + 2;
 H = zeros(m+1,m);
 rhs = zeros(m+1,1);
 rhs(1) = bet;
 
 if iprint == 1
  fprintf('\n end of cycle = % d, nit = %d, true residual norm = %12.5e, relative residual norm = %12.5e \n\n',nitd,ni,bet,bet/sqrt(r0))
 end
 
end % while, loop on cycles

% if we get here we have done the max number of cycles may be without convergence
iret = 0;
nit = ni;
resn = resn(1:ni);
if trueres == 1
 resnt = resnt(1:ni);
end
if ni == nitmax
 iret = 2;
end

xx = x;
if left == 0
 % right preconditioner
 if strcmpi(precond,'ml') == 0
  x = gm_solveprecns(xx,A,DD,LL,UU,precond);
 else
  x = gm_amg_ns_it(A,xx,xin,nu,1,cA,cM,cP,cR,cperm,ciperm,cS,cw,cdf,cL,cU,cd,cda,lmax,smooth,gam,normal);
 end
end

if iprint == 1
 fprintf ('\n No convergence after %d iterations \n',ni)
 fprintf('\n Final true residual norm = %12.5e \n\n',norm(b - A * x))
 fprintf(' Number of cycles = %d, number of iterations = %d \n\n',nitd,ni)
 if sorth ==1 || reorth == 1
  fprintf(' Number of reorthogonalizations = %d \n\n',nreo)
 end
 fprintf(' Number of matrix-vector products = %d \n\n',matvec)
 fprintf(' Number of inner products = %d, per iteration = %g \n\n',dotprod,dotprod/ni)
end % if iprint

if timing == 1
 titer = toc;
 if iprint == 2
  fprintf(' Iteration time = %g, total time = %g \n\n',titer,tinit+titer)
 end
 time_mat = struct('init_time',tinit,'iter_time',titer,'nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
else
 time_mat = struct('nmatv',matvec,'ndotp',dotprod,'matvec',matv(1:ni+1));
end % if timing

% if scaling go back to the solution of the original system
if scaling == 1
 x = dda .* x;
end

% warning on
