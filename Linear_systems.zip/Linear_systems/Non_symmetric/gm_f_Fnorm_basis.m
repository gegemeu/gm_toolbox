function f=gm_f_Fnorm_basis(x);
%GM_F_FNORM_BASIS function for the minimization of the Frobenius norm of
% V_k^T V_k - I

%
% Author G. Meurant
% Feb 2016
%

global B VV;

v = B * transpose(x);
v = v / norm(v);

z = VV' * v;

f = norm(z);

