function Pols=gm_create(defpoly,varnames,ord,tol);
%GM_CREATE creates a polynomial system using cell arrays

% Input:
% defpoly = polynomial definition (string)
% varnames = strings of the variable names
% ord = the monomials are sorted according to the order ord (string)
% tol = all coefficients smaller than tol are set to 0
%
% Output
% Pols = cell array to be used by gm_grobner

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

% define the polynomial system

if nargin == 1 && ~iscell(defpoly)
 
 % the polynomial is defined by a defpol m-file
 [fpol,addpol,Mnu] = feval(defpoly);
 
 % convert to the new data structure?????????
 
 Pols = {};
 
else
 
 % if there are two arguments or a cell array, we have strings
 if nargin == 1
  varnames = {};
 end
 
 if nargin < 3
  ord = 'lex';
 end
 
 if nargin < 4
  tol = 1e-10;
 end
 
 % obtain the terms from the strings
 
 [Pset,poly_terms] = gm_poly_str2poly(defpoly,varnames);
 
 % we get the coefficients and the exponents in poly_terms (cell array)
 
 % sort the exponents accordind to ord and get the leading term
 
 [poly_terms,lt] = gm_poly_sort(poly_terms,ord,tol);
 
 % number of polynomials
 npol = size(poly_terms,2);
 
 % create the cell array
 % (npol,1) = 1 active, = 0 inactive (deleted)
 % (npol,2) = number of terms in the polynomial
 % (npol,3) = leading term
 % (npol,4) = coefficients and exponents (2D array)
 
 Pols = cell(npol,4);
 
 for k = 1:npol
  % get polynomial k
  P = poly_terms{k};
  leadt = lt{k};
  Pols{k,1} = 1;
  Pols{k,2} = size(P,1);
  Pols{k,3} = leadt;
  Pols{k,4} = P;
 end % for k
 
end % if



