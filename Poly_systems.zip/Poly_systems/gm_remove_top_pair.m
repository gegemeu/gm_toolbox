function [pairs,LCM,P1,P2]=gm_remove_top_pair(p);
%GM_REMOVE_TOP_PAIR removes the first pair P of list p
% and returns it

% Input:
% p = list of pairs
%
% Output:
% pairs = new list of pairs
% LCM = least common multiple
% P1, P2 = elements of the top pair

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npair = size(p,1);

if npair == 1
 pairs = {};
 LCM = p{1,1};
 P1 = p{1,2};
 P2 = p{1,3};
 return
end

if npair ~= 0
 LCM = p{1,1};
 P1 = p{1,2};
 P2 = p{1,3};
 for k = 2:npair
  L = p{k,1};
  Q1 = p{k,2};
  Q2 = p{k,3};
  pairs{k-1,1} = L;
  pairs{k-1,2} = Q1;
  pairs{k-1,3} = Q2;
 end
else
 pairs = {};
 LCM = [];
 P1 = {};
 P2 = {};
end

