function Jcal0=gm_build_Jcal0(n,Mnu,Jord);
%GM_BUILD_JCAL0 constructs the set of indices J_0 for the Auzinger and Stetter
% method

% Input:
% n = number of polynomials
% Mnu = total degrees m_nu of the n polynomial equations
% Jord = set of tuples satisfying the condition sum(indices) <= sum(Mnu) - n + 1
%
% Output:
% Jcal0 = set of indices

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

if size(Jord,1) == 0
 J = gm_build_lexic_order_new(n,Mnu);
else
 J = Jord;
end

Jcal0 = [];

for k = 1:size(J,1)
 Jk = J(k,:);
 Jkm = Jk - Mnu';
 if all(Jkm < 0)
  Jcal0 = [Jcal0; Jk];
 end
end

% (0 ... 0) must be the last element
% instead of the first one

sJcal0 = size(Jcal0,1);

Jcal0 = [Jcal0(2:sJcal0,:); Jcal0(1,:)];



