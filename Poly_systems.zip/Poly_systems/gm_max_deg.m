function D=gm_max_deg(Pset);
%GM_MAX_DEG returns the maximal degree of a polynomial system

% Input:
% Pset = polynomials
%
% Output:
% D = maximum degree

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(Pset,1);

D = 0;

for k = 1:npol
 P = gm_getpol(Pset,k);
 Q = P{1,4};
 Exp = Q(:,2:end);
 D = max(D,max(sum(Exp')));
end % for k

