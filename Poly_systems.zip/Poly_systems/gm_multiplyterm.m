function Q=gm_multiplyterm(P,term,ord);
%GM_MULTIPLYTERM multiplies the polynomial P by the monomial term
%  and sorts according to ord

% the polynomial is assumed to be sorted and the monomial to have
% the same number of variables (in the same order)
% this is not checked

% Input:
% P = polynomial
% term = monomial
% ord = ordering
% 
% Output:
% Q = polynomial result of the multiplication (cell array)

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

Activ = P{1,1};

if Activ == 0
 Q = P;
 return
end % if Activ

Q = cell(1,4);
Q{1,1} = 1;

nT = P{1,2};
T = P{1,4};

for k = 1:nT
 T(k,2:end) = T(k,2:end) + term;
end

% number of monomials
Q{1,2} = size(T,1);

% leading term
Q{1,3} = T(1,:);

% polynomial
Q{1,4} = T;

