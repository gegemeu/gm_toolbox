function [xsol,val_sol]=gm_solve_polsys_moment(defpoly,varnames,ord,tol);
%GM_SOLVE_POLSYS_MOMENT solves the polynomial system using the
% moment-matrix algorithm

% see P. Rostalski's Ph.D. thesis

% Input:
% defpoly = polynomials definition
% varnames = variable names
% ord = ordering
% tol = tolerance for the coefficients
%
% Output:
% xsol = solutions
% val_sol = values of the polynomials at the solutions

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

if nargin < 3
 ord = 'grlex';
end
if nargin < 4
 tol = 1e-10;
end

iprint = 0;

% reproducibility ????
s = RandStream('mt19937ar','Seed', 5489);
RandStream.setGlobalStream(s);

xsol = [];
val_sol = [];

if (numel(defpoly) > 0) && ischar(defpoly{1})
 charout = true;

 Pset = gm_create(defpoly,varnames,ord,tol);
 
else
 charout = false;
end

% number of variables

nvar = size(varnames,2);

% maximal degree of Pset

D = gm_max_deg(Pset);
d = ceil(D/2);
dD = min(d,D);
tmax = max(fix(30/nvar),20);

t = D;

done = 0;
condi = 0;

while done ~= 1

 % find a generic element in K_(t,C)

 [y,M,rM,rm] = gm_generic(Pset,nvar,t);

%  if iprint == 1
%   fprintf('\n for t = %5i, there are %5i monomials \n',t,size(M,1))
%  end

 ts = floor(t / 2);

 % compute the moment matrix M_(t/2)(y)
 
 [Mt,J] = gm_mommat(y,ts,nvar,M,rM,rm);
 
 %  if iprint == 1
%     fprintf('\n size of moment matrix for t = %5i, (%5i,%5i) \n',t,size(Mt,1),size(Mt,2))
 %  end

 % check the rank conditions

 [condi,s,Ms1,Ms] = gm_check_mom(Mt,D,d,ts,nvar,J);

 if condi == 1
  done = 1;

 else
  t = t + 1;
  if t > tmax
   error('gm_solve_polsys_moment: No convergence of rank')
  end % if
 end % if condi

end % while

% if iprint == 1
%   fprintf('\n Criteria satisfied for t = %5i, s = %5i \n',t,s)
% end

% basis of the quotient space

[U,S,V] = svd(Ms1);
rMs1 = gm_rank(diag(S));
U = U(:,1:rMs1);

% if iprint == 1
%  fprintf('\n rank of Ms1 = %5i \n',rMs1)
% end

MBs = U' * Ms1 * U;

for k = 1:nvar
 mon = zeros(1,nvar);
 mon(k) = 1;

 MT = gm_mul_tab(mon,s,Ms,MBs,U,nvar);
 
 MTab{k} = MT;

end % for k

% compute the solution from multiplication tables

xsol = gm_comp_sol(MTab);

% obtain the terms from the strings
[Pset,poly_terms] = gm_poly_str2poly(defpoly,varnames);
% convert to defpol format
[fpol,addpol,Mnu] = gm_str_to_defpol(poly_terms);

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

xx = [];
val = [];

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) <= 1e-5
  xx = [xx xsol(:,k)];
  val = [val val_sol(:,k)];
 end
end % for k

xsol = xx;
val_sol = val;










