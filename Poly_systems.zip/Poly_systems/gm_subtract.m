function Q=gm_subtract(P1,P2,ord,tol);
%GM_SUBTRACT subtracts the 2 polynomials P1 and P2, = P1 - P2
%   and sorts according to ord

% the 2 polynomials are assumed to have the same number
% of variables and to be sorted
% this is not checked

% Input:
% P1, P2 = two polynomials
% ord = ordering
% tol = all coefficients less than tol are removed
%
% Output:
% Q = polynomial result of the subtraction

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

if nargin < 3
 tol = 1e-10;
end

Activ1 = P1{1,1};
Activ2 = P2{1,1};
nT1 = P1{1,2};
nT2 = P2{1,2};
T1 = P1{1,4};
T2 = P2{1,4};

if Activ1 == 0 
 Q = P2;
 return
elseif Activ2 == 0 
 Q = P1;
 return
end % if Activ

QT = zeros(1,size(T1,2));

Q =cell(1,4);
Q{1,1} = 1;

j1 = 1;
j2 = 1;
jQT = 1;
rT1 = nT1;
rT2 = nT2;

while (j1 <= nT1) && (j2 <= nT2)
 M1 = T1(j1,2:end);
 C1 = T1(j1,1);
 M2 = T2(j2,2:end);
 C2 = T2(j2,1);
 
 if isequal(M1,M2)
  % same monomial, subtract the coefficients
  j1 = j1 + 1;
  j2 = j2 + 1;
  rT1 = rT1 - 1;
  rT2 = rT2 - 1;
  C =C1 - C2;
  if abs(C) >= tol
   % filter small coefficients
   QT(jQT,1) = C;
   QT(jQT,2:end) = M1;
   jQT = jQT + 1;
  end
  
 else
  % look for the largest one
  [ind,largest_m] = gm_sort_monomial(1,M1,2,M2,ord);
  
  if ind == 1
   % 1 was the largest
   j1 = j1 + 1;
   rT1 = rT1 - 1;
   if abs(C1) >= tol
    QT(jQT,1) = C1;
    QT(jQT,2:end) = M1;
    jQT = jQT + 1;
   end
  else
   % 2 was the largest
   j2 = j2 + 1;
   rT2 = rT2 - 1;
   if abs(C2) >= tol
    QT(jQT,1) = -C2;
    QT(jQT,2:end) = M2;
    jQT = jQT + 1;
   end
  end % if ind
  
 end % if M1
 
end % while

j1 = min(j1,nT1);
j2 = min(j2,nT2);

if rT1 > 0
 QT(jQT:jQT+rT1-1,:) = T1(j1:end,:);
elseif rT2 > 0
 T2(j2:end,1) = -T2(j2:end,1);
 QT(jQT:jQT+rT2-1,:) = T2(j2:end,:);
end % if rT1

% number of monomials
Q{1,2} = size(QT,1);

% leading term
Q{1,3} = QT(1,:);

% polynomial
Q{1,4} = QT;


  

  