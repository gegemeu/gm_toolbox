function col=gm_get_entries(Q,N);
%GM_GET_ENTRIES collects the coefficients of Q 

% Input:
% Q = polynomial
% N = normal set
%
% Output:
% col = coefficients

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% get the monomials in N

nns = size(N,1);
nm = size(N{1,3},2) - 1;

MN = zeros(nns,nm);

for k = 1:nns
 LT = N{k,3};
 LM = LT(1,2:end);
 MN(k,:) = LM;
end % for k

col = zeros(nns,1);

% we have to compare the monomials in Q with those in N

P = Q{1,4};
coef = P(:,1);
MP = P(:,2:end);

for k = 1:size(MP,1)
 MPk = MP(k,:);
 
 for j = 1:nns
  MNj = MN(j,:);
  if MPk == MNj
   % put the coefficient in the vector
   col(j) = coef(k);
  end % if
 end % for j
 
end % for k

% reverse the order

%col = col(end:-1:1);


