function gbasis=gm_remove_top_pol(gb);
%GM_REMOVE_TOP_POL removes the first polynomial P of list gb

% Input:
% gb = polynomial basis
%
% Output:
% gbasis = new polynomial basis

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(gb,1);
gbasis = {};

if npol == 1
 gbasis = {};
 return
end

if npol ~= 0
 for k = 2:npol
P = gm_getpol(gb,k);
gbasis = gm_putpol(gbasis,P,k-1);
 end
else
 gbasis = {};
end

