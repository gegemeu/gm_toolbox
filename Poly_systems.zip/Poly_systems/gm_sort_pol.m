function poly_t=gm_sort_pol(poly,ord,tol);
%GM_SORT_POL sorts the polynomial according to the monomial order ord

% all coefficients smaller than tol are set to 0
% descending order (largest to smallest)

% Input:
% poly = polynomial
% ord = ordering
% tol = tolerance for the coefficients

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

npol = size(poly,1);

poly_t = {};

for k = 1:npol
 PP = gm_getpol(poly,k);
 p = PP{1,4};
 Exp = p(:,2:end);
 Coef = p(:,1);
 P = zeros(1,size(p,2));
 
 % very simple sort
 i = 0;
 sE = size(Exp,1);
 while sE > 0
  largest_mon = Exp(1,:);
  index = 1;
  for j = 2:sE
   [index,largest_mon] = gm_sort_monomial(index,largest_mon,j,Exp(j,:),ord);
  end % for j
  if abs(Coef(index)) >= tol
   i = i + 1;
   P(i,2:end) = largest_mon;
   P(i,1) = Coef(index);
  end
  % remove the largest one
  Exp = [Exp(1:index-1,:); Exp(index+1:end,:)];
  Coef = [Coef(1:index-1,:); Coef(index+1:end,:)];
  sE = sE - 1;
 end % while
 
 PP{1,4} = P;
 PP{1,2} = size(P,1);
 PP{1,3} = P(1,:);
 poly_t = gm_putpol(poly_t,PP,k);
end % for k

