% EXAMPLES
%
% Files
%   gm_Ex_polsys - Exemples of polynomials systems
