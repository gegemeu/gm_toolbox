% Exemples of polynomials systems

iex = 2;

switch iex
 
 case 1
  % -----------n = 3, d = 2
  % this is an example corresponding to the GMRES system
  % for the matrix [-1 2 -3; 5 4 -3; 9 -10 1]
  % this system has 8 real solutions
  % A Grobner basis (lex) is
  %  Pol1 = x2+506.138*x3^7-660.256*x3^5+157.301*x3^3-1.26559*x3
  %  Pol2 = x1-2521.51*x3^7+3373.56*x3^5-883.744*x3^3+22.1514*x3
  %  Pol3 = x3^8-1.36082*x3^6+0.381451*x3^4-0.0171179*x3^2+0.000192905
  %
  % The normal set is 1, (x3)^i, i = 1:7
  %
  f1 = '-x1^2 + 4*x2^2 + x3^2 + 7*x1*x2 + 6*x1*x3 - 13*x2*x3';
  f2 = '-16*x1^2 + 56*x2^2 + 4*x3^2 + 24*x1*x2 - 56*x1*x3 - 62*x2*x3';
  f3 = 'x1^2 + x2^2 + x3^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 2
  % -----------n = 3, d = 2
  % A Grobner basis (lex) is
  % x+y+z^2-1, y^2-y-z^2+z, 2*y*z^2+z^4-z^2, z^6-4*z^4+4*z^3-z^2
  % the normal set is 1, z^i i = 1:5, y , y*z
  % there are 8 solutions counting multiplicities but (up to finite
  % precision) only 5 distinct solutions
  % the 3 canonical basis vectors and (-1+sqrt(2))e, (-1-sqrt(2))*e
  % with e=ones(3,1)
  %
  f1 = 'x^2 + y + z - 1';
  f2 = 'x + y^2 + z - 1';
  f3 = 'x + y + z^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 3
  % -----------n = 2, d = 2
  % A Grobner basis (lex) is
  % 4*y^3-7*y^2+3*y, -2*y^2+x*y+2*y, x^2+y-1
  % the normal set is 1, y, y^2, x
  % the 4 solutions are
  % (1 0), (-1 0), (0 1) and (-1/2 3/4)
  %
  f1 = 'x^2 + y - 1';
  f2 = '2*x^2 - x*y + 2*y^2 - 2';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 4
  % -----------n = 3, d = 3
  % A Grobner basis with lex is
  % ? {1} ???????
  % there are 8 solutions,  2 real
  % AS fails on this system
  %
  f1 = 'x1^2 - 2*x1*x3 + 5';
  f2 = 'x1*x2^2 + x2*x3 + 1';
  f3 = '3*x2^2 - 8*x1*x3 ';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 5
  % -----------n = 2, d = 2
  % the 4 solutions are
  % (2a 2a), (-2a -2a), (4a -a), (-4a a) with a = 1/sqrt(5)
  % A Grobner basis (lex) is
  %  Pol1 = x1-8.33333*x2^3+5.66667*x2
  %  Pol2 = x2^4-x2^2+0.16
  %
  f1 = 'x1^2 + 4*x2^2 - 4';
  f2 = '-x1^2 + 4*x2^2 - 3*x1*x2';
  
  fpol = {f1, f2};
  varnames = {'x1','x2'};
  
 case 6
  % -----------n = 2, d = 2
  % the 3 finite solutions are
  % (0 0), (1 1), (-1 1)
  % A Grobner basis (lex) is
  %  Pol1 = x2^2-x2
  %  Pol2 = x1*x2-x1
  %  Pol3 = x1^2-x2
  %
  f1 = 'x1*x2 - x1';
  f2 = 'x1^2 - x2';
  
  fpol = {f1, f2};
  varnames = {'x1','x2'};
  
 case 7
  % -----------n = 2, d = 2
  % there are 4 complex solutions
  % A Grobner basis (lex) is
  %  Pol1 = x1+x2^3-2*x2^2+x2
  %  Pol2 = x2^4-3*x2^3+3*x2^2-x2+1
  %
  f1 = 'x1*x2 - x1 - 1';
  f2 = 'x1^2 + x2^2 - x2';
  
  fpol = {f1, f2};
  varnames = {'x1','x2'};
  
 case 8
  % -----------n = 3, d = 3
  % there are 7 distinct solutions (4 complex, 3 real)
  % A Grobner basis (lex) is
  %  Pol1 = z^7-0.5*z^6+0.0625*z^5+3.25*z^4+4.6875*z^3-21.375*z^2+16.625*z-3.75
  %  Pol2 = x+9.33199*z^6-0.150905*z^5+0.530936*z^4+30.6997*z^3+58.5596*z^2-171.111*z+72.6393
  %  Pol3 =
  %  y^2-38.6076*z^6+0.639839*z^5-2.11117*z^4-126.537*z^3-242.373*z^2+708.119*z-299.631
  %
  f1 = '16*x1^2 + 4*x1*x2 - 4*x3 + 1';
  f2 = '2*x2*x3 + 4*x1 + 1';
  f3 = '2*x1^2*x3 - x1 - 2*x2';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 9
  % -----------n = 3, d = 2
  % there are 4 real solutions
  % (-1 3 2), (-5 5 -2), (2 3 -7), (-3 3 -2)
  % A Grobner basis (lex) is
  % Pol1 = x2^2-8*x2+15
  % Pol2 = x3^2+9*x3+14
  % Pol3 = x2*x3+2*x2-3*x3-6
  % Pol4 = x1^2+4*x1-4*x2+3*x3+21
  % Pol5 = x1*x2-3*x1+5*x2-15
  % Pol6 = x1*x3+2*x1-2*x3-4
  %
  f1 = 'x1^2 + x1*x2 + x1*x3 + 3*x1 + x2 + x3 + 2';
  f2 = 'x1*x2 - 3*x1 + 5*x2 - 15';
  f3 = 'x1*x3 + 2*x1 - 2*x3 - 4';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 10
  % -----------n = 3, d = 3
  % cyclic 3-roots
  % A Grobner basis (lex) is
  % x+y+z, y^2+y*z+z^2, z^3-1
  % there are 6 complex solutions
  %
  f1 = 'x + y + z';
  f2 = 'x*y + y*z + z*x';
  f3 = 'x*y*z - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 11
  % this is the same as Pb 8 !!!!!!!!!!
  % -----------n = 3, d = 3
  % there are 14 solutions (9 complex, 4 real)
  % AS fails on this system
  % A Grobner basis (lex) is
  %  Pol1 = z^7-0.5*z^6+0.0625*z^5+3.25*z^4+4.6875*z^3-21.375*z^2+16.625*z-3.75
  %  Pol2 = x+9.33199*z^6-0.150905*z^5+0.530936*z^4+30.6997*z^3+58.5596*z^2-171.111*z+72.6393
  %  Pol3 = y^2-38.6076*z^6+0.639839*z^5-2.11117*z^4-126.537*z^3-242.373*z^2+708.119*z-299.631
  %
  f1 = '4*x^2 + x*y^2 - z + 0.25';
  f2 = 'y^2*z + 2*x + 0.5';
  f3 = '-x^2*z + y^2 + 0.5*x';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 12
  % -----------n = 3, d = 2
  % there are 6 solutions (4 complex, 2 real)
  % The returned Grobner basis (lex) is {1}. However
  % this system has solutions!!!!
  % It works with grevlex
  %
  f1 = '-0.5*x1^2 - 0.5*x2^2 + x3^2';
  f2 = 'x1*x2 + x1*x3 - 2*x3';
  f3 = 'x1^2 - x2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 13
  % -----------n = 4, d = 4
  % there are 3 solutions (2 complex, 1 real)
  % AS fails on this system
  % A Grobner basis (lex) is
  %  Pol1 = x2+4.50001*x4^2-1.5*x4-1.5
  %  Pol2 = x1-4.50001*x4^2+1.5*x4-0.5
  %  Pol3 = x3+3*x4^2
  %  Pol4 = x4^3-0.111111
  %
  f1 = 'x1 + x2 - 2';
  f2 = 'x1*x3 + x2*x4';
  f3 = 'x1*x3^2 + x2*x4^2 - 0.666666';
  f4 = 'x1*x3^3 + x2*x4^2';
  
  fpol = {f1, f2, f3, f4};
  varnames = {'x1','x2','x3','x4'};
  
 case 14
  % -----------n = 3, d = 6
  % this example takes a lot of time!!
  % there are 120 solutions
  % AS does not return a solution
  %
  f1 = 'x1^4 + x2^4 + x3^4 - 4';
  f2 = 'x1^5 + x2^5 + x3^5 - 5';
  f3 = 'x1^6 + x2^6 + x3^6 - 6';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 15
  % -----------n = 2, d = 2
  % there are 3 solutions (2 complex, 1 real)
  % A Grobner basis (lex) is
  %  Pol1 = x+y+0.333333
  %  Pol2 = y^3+1*y^2+0.222222*y+1
  %
  f1 = 'x^2*y + 2*x*y^2 + x*y - 1';
  f2 = 'x^2*y - x*y^2 - x*y + 2';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 16
  % -----------n = 2, d = 2
  % intersection of two ellipses
  % there are 4 real solutions
  % A Grobner basis (lex) is
  %  Pol1 = y^2-1
  %  Pol2 = x^2-1
  %
  f1 = '0.333333*x^2 + 0.666666*y^2 - 1';
  f2 = '0.666666*x^2 + 0.333333*y^2 - 1';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 17
  % -----------n = 2, d = 4
  % there are 16 solutions
  % A Grobner basis (lex) is
  %  Pol1 = x^2*y+1.33333*y^7-1.33333*y^3
  %  Pol2 = x*y^5-0.25*x*y
  %  Pol3 = y^9-1.25*y^5+0.25*y
  %  Pol4 = x^4-2.66667*y^8+3.66667*y^4-1
  %
  f1 = 'x^4 + y^4 + 2*x^2*y^2 - 1';
  f2 = 'x^3*y - x*y^3';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 18
  % -----------n = 4, d = 4
  % this takes a lot of time
  % there are 56 solutions
  % AS fails on this system
  %
  f1 = 'y^2*z + 2*x*y*t - 2*x - z';
  f2 = '-x^3*z + 4*x*y^2*z + 4*x^2*y*t + 2*y^3*t + 4*x^2 -10*y^2 + 4*x*z - 10*y*t + 2';
  f3 = '2*y*z*t + x*t^2 - x - 2*z';
  f4 = '-x*z^3 + 4*y*z^2*t + 4*x*z*t^2 + 2*y*t^3 + 4*x*z + 4*z^2 - 10*y*t -10*t^2 + 2';
  
  fpol = {f1, f2, f3, f4};
  varnames = {'x','y','z','t'};
  
 case 19
  % -----------n = 3, d = 2
  % 0 is the only multiple solution
  % A Grobner basis (lex) is
  %  Pol1 = z^4
  %  Pol2 = y^2*z+0.146136*z^3
  %  Pol3 = y*z^2+0.167082*z^3
  %  Pol4 = y^3-0.102985*z^3
  %  Pol5 = x*y+1.02845*y^2+0.0668563*y*z-0.0739687*z^2
  %  Pol6 = x*z+0.331437*y^2+0.428876*y*z+1.23826*z^2
  %  Pol7 = x^2-2.16358*y^2+0.365576*y*z-1.57468*z^2
  %
  f1 = 'x^2 + 18*x*y + 19*y^2 + 8*x*z + 5*y*z + 7*z^2';
  f2 = '3*x^2 + 7*x*y + 22*x*z + 11*y*z + 22*z^2 + 8*y^2';
  f3 = '6*x^2 + 12*x*y + 4*y^2 + 14*x*z + 9*y*z + 7*z^2';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 20
  % -----------n = 3, d = 3
  % there are 8 solutions (2 real)
  % AS fails on this system
  %
  f1 = 'x1^2 - 2*x1*x3 + 5';
  f2 = 'x1*x2^2 + x2*x3 + 1';
  f3 = '3*x2^2 - 8*x1*x3';
  
  fpol = {f1, f2, f3};
  varnames = {'x1','x2','x3'};
  
 case 21
  % -----------n = 2, d = 2
  % there are 4 real solutions
  % A Grobner basis (lex) is
  %  Pol1 = x+2.5*y^3-3.5*y
  %  Pol2 = y^4-1.4*y^2+0.16
  %
  f1 = 'x^2 + y^2 - x*y - 1';
  f2 = '10*x*y - 4';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 22
  % -----------n = 2, d = 2
  % there are 4 real solutions
  % badly conditioned example for Grobner bases
  % They return {1} but this is wrong
  %
  f1 = '2.267448*x^2 + 0.9643230*y^2 + 3.589658*x*y - 0.1141510*x + 0.1266110*y + 0.1078210';
  f2 = '1.698297*x^2 + 3.356959*y^2 + 2.688612*x*y + 3.310486*x + 2.271471*y - 4.657648';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 23
  % -----------n = 2, d = 3
  % there are 6 real solutions
  % badly conditioned example for Grobner bases
  %
  f1 = 'x^2 + y^2 + 0.000001*x*y - 1';
  f2 = 'y^3 - 3*x^2*y';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 24
  % -----------n = 2, d = 3
  % there are 4 solutions
  % failures of Grobner and AS on this sytem
  %
  f1 = '-x^3  + y^2 - 0.0001*x*y - 1';
  f2 = '-x^3 - 1.1*x^2 + y^2';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 25
  % -----------n = 4, d = 2
  % there are 6 solutions
  % A Grobner basis (lex) is ?????????
  %  Pol1 = x4^10-3.16667*x4^8+3.77778*x4^6-2.11111*x4^4+0.555556*x4^2-0.0555556
  %  Pol2 = x2+0.25*x3*x4^2-0.25*x3+50.0625*x4^9-129.844*x4^7+116.844*x4^5-43.9062*x4^3+6.84375*x4
  %  Pol3 = x1*x4^2-x1+1*x3*x4^2-1*x3-67.5*x4^9+182.25*x4^7-168.75*x4^5+60.75*x4^3-6.75*x4
  %  Pol4 = x3*x4^4-2*x3*x4^2+1*x3+13.5*x4^9-38.25*x4^7+38.25*x4^5-15.75*x4^3+2.25*x4
  %  Pol5 = x3^2-0.25*x3*x4^3+0.25*x3*x4+3.9375*x4^8-9.65625*x4^6+8.40625*x4^4-3.09375*x4^2+0.40625
  %  Pol6 = x1*x3-0.25*x3*x4^3+0.25*x3*x4+9.5625*x4^8-28.5938*x4^6+29.8438*x4^4-12.6563*x4^2+1.84375
  %  Pol7 = x1^2+0.25*x3*x4^3-0.25*x3*x4+34.3125*x4^8-91.2188*x4^6+83.2188*x4^4-29.5313*x4^2+3.21875
  %
  % AS does not find some solutions
  %
  f1 = 'x1^2 + x1*x2 + x1*x3 + x2*x3';
  f2 = 'x2^2 + x1*x3 + x2*x4';
  f3 = 'x3^2 + x1*x3 + x2*x3';
  f4 = 'x1^2 + x2^2 + x3^2 + x4^2 - 1';
  
  fpol = {f1, f2, f3, f4};
  varnames = {'x1','x2','x3','x4'};
  
 case 26
  % -----------n = 3, d = 3
  % there are 12 solutions, 4 simple and 4 double
  %
  f1 = 'x^2 + y^2 - 1';
  f2 = 'x^3 + 2*x*y + z*x*y + y^3 - 1';
  f3 = 'z^2 - 2';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 27
  % -----------n = 3, d = 2
  % caution there are more equations than unknowns!!!!!
  % there are 2 real solutions
  %
  f1 = 'x*y^4 + 3*x^3 - y^4 - 3*x^2';
  f2 = 'y*x^2 - 2*x^2';
  f3 = '2*x*y^4 - x^3 - 2*y^4 + x^2';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y'};
  
 case 28
  % -----------n = 4, d = 4
  % there are 2 real solutions
  % AS fails on this system
  %
  f1 = 'x + y - 2';
  f2 = 'x*z + y*t';
  f3 = 'x*z^2 + y*t^2 - 0.666666';
  f4 = 'x*z^3 + y*t^3';
  
  fpol = {f1, f2, f3, f4};
  varnames = {'x','y','z','t'};
  
 case 29
  % -----------n = 2, d = 2
  % Homlab example
  % A Grobner basis (lex) is
  %  x-2*y-1, y^2+0.5*y-0.5
  % the normal set is 1, y
  % the 2 solutions are
  % (2 0.5), (-1 -1) + 2 solutions at infinity
  % AS fails on this sytem
  %
  f1 = 'x^2 - x - 2';
  f2 = 'x*y - 1';
  
  fpol = {f1, f2};
  varnames = {'x','y'};
  
 case 30
  % -----------n = 3, d = 2
  % system with a redundant equation
  % there are 8 solutions
  %
  f1 = 'x^2 + y^2 + z^2 - 1';
  f2 = 'x^2 - 2*x*y + z^2 - 1';
  f3 = 'x^2 + y^2 + z^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 31
  % -----------n = 3, d = 2
  % same system without the redundant equation
  % there are 8 solutions
  %
  f1 = 'x^2 + y^2 + z^2 - 1';
  f2 = 'x^2 - 2*x*y + z^2 - 1';
  
  fpol = {f1, f2};
  varnames = {'x','y','z'};
  
 case 32
  % deficient GMRES system
  %
  f1 = '-0.432565*x1^2 - 1.54025*x1*x2 + 0.287676*x2^2 - 0.432565*x3^2 - 1.54025*x3*x4 + 0.287676*x4^2 ';
  f2 = '1.79092*x1*x4 - 1.79092*x2*x3';
  f3 = 'x1^2 + x2^2 + x3^2 + x4^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x1', 'x2', 'x3', 'x4'};
  
 case 33
  % -----------n = 3, d = 3
  % there are 24 solutions with 'grlex'
  %
  f1 = 'x^3 - y^3 - 3*y*x^2 + 3*x*y^2 - z^2';
  f2 = 'z^3 - x^3 - 3*x*z^2 + 3*z*x^2 - y^2';
  f3 = 'y^3 - z^3 - 3*z*y^2 + 3*z*y^2 - x^2';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 34
  % -----------n = 3, d = 3
  % same as 33 with constant terms
  % there are 24 solutions
  %
  f1 = 'x^3 - y^3 - 3*y*x^2 + 3*x*y^2 - z^2 - 1';
  f2 = 'z^3 - x^3 - 3*x*z^2 + 3*z*x^2 - y^2 - 1';
  f3 = 'y^3 - z^3 - 3*z*y^2 + 3*z*y^2 - x^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 case 35
  % -----------n = 3, d = 4
  % same as 33 with constant terms
  % there are 44 solutions with 'grlex'
  %
  f1 = 'x^4 - y^4 - 3*y*x^2 + 3*x*y^2 - z^2 - 1';
  f2 = 'z^4 - x^4 - 3*x*z^2 + 3*z*x^2 - y^2 - 1';
  f3 = 'y^3 - z^3 - 3*z*y^2 + 3*z*y^2 - x^2 - 1';
  
  fpol = {f1, f2, f3};
  varnames = {'x','y','z'};
  
 otherwise
  error(['gm_Ex_polsys: The problem ' num2str(iex) ' does not exist'])
end


% Ordering: 'lex', 'grlex', 'grevlex'
ord = 'grlex';
% ord = 'lex';
% Tolerance for the coefficients
tol = 1e-10;

% Solve with a Grobner basis

tic
[xsol,val_sol] = gm_solve_polsys_Grobner(fpol,varnames,ord,tol);
t = toc;
nsol = size(xsol,2);

fprintf('\n gm_solve_polsys_Grobner, problem %d, time = %g \n\n',iex,t)
fprintf(' number of equations = %d, number of variables = %d \n',size(fpol,2),size(varnames,2))
fprintf(' number of solutions = %d \n',nsol)
% for k = 1:nsol
%  fprintf('\n solution %d, polynomial values \n',k)
%  for j = 1:size(val_sol,1)
%   fprintf('  %g \n',val_sol(j,k))
%  end
% end
fprintf(' min value = %g, max value = %g ',min(min(abs(val_sol))),max(max(abs(val_sol))))
fprintf('\n\n')

% Solve with a Grobner basis (with Buchberger's criteria)

tic
[xsol,val_sol] = gm_solve_polsys_Grobner_crit(fpol,varnames,ord,tol);
t = toc;
nsol = size(xsol,2);

fprintf('\n gm_solve_polsys_Grobner_crit, problem %d, time = %g \n\n',iex,t)
fprintf(' number of equations = %d, number of variables = %d \n',size(fpol,2),size(varnames,2))
fprintf(' number of solutions = %d \n',nsol)
% for k = 1:nsol
%  fprintf('\n solution %d, polynomial values \n',k)
%  for j = 1:size(val_sol,1)
%   fprintf('  %g \n',val_sol(j,k))
%  end
% end
fprintf(' min value = %g, max value = %g ',min(min(abs(val_sol))),max(max(abs(val_sol))))
fprintf('\n\n')

% Solve with a Grobner basis (basic version)

tic
[xsol,val_sol] = gm_solve_polsys_Grobner_basic(fpol,varnames,ord,tol);
t = toc;
nsol = size(xsol,2);

fprintf('\n gm_solve_polsys_Grobner_basic, problem %d, time = %g \n\n',iex,t)
fprintf(' number of equations = %d, number of variables = %d \n',size(fpol,2),size(varnames,2))
fprintf(' number of solutions = %d \n',nsol)
% for k = 1:nsol
%  fprintf('\n solution %d, polynomial values \n',k)
%  for j = 1:size(val_sol,1)
%   fprintf('  %g \n',val_sol(j,k))
%  end
% end
fprintf(' min value = %g, max value = %g ',min(min(abs(val_sol))),max(max(abs(val_sol))))
fprintf('\n\n')

% Solve with the moment method

tic
[xsol,val_sol] = gm_solve_polsys_moment(fpol,varnames,ord,tol);
t = toc;
nsol = size(xsol,2);

fprintf('\n gm_solve_polsys_moment, problem %d, time = %g \n\n',iex,t)
fprintf(' number of equations = %d, number of variables = %d \n',size(fpol,2),size(varnames,2))
fprintf(' number of solutions = %d \n',nsol)
% for k = 1:nsol
%  fprintf('\n solution %d, polynomial values \n',k)
%  for j = 1:size(val_sol,1)
%   fprintf('  %g \n',val_sol(j,k))
%  end
% end
fprintf(' min value = %g, max value = %g ',min(min(abs(val_sol))),max(max(abs(val_sol))))
fprintf('\n\n')

% Solve with the Auzinger and Stetter method

tic
[xsol,val_sol] = gm_solve_polsys_AS(fpol,varnames);
t = toc;
nsol = size(xsol,2);

fprintf('\n gm_solve_polsys_AS, problem %d, time = %g \n\n',iex,t)
fprintf(' number of equations = %d, number of variables = %d \n',size(fpol,2),size(varnames,2))
fprintf(' number of solutions = %d \n',nsol)
% for k = 1:nsol
%  fprintf('\n solution %d, polynomial values \n',k)
%  for j = 1:size(val_sol,1)
%   fprintf('  %g \n',val_sol(j,k))
%  end
% end
fprintf(' min value = %g, max value = %g ',min(min(abs(val_sol))),max(max(abs(val_sol))))
fprintf('\n\n')


