function [ind,largest_m]=gm_sort_monomial(index,largest_mon,j,Exp,ord);
%GM_SORT_MONOMIAL returns the largest monomial according to ord

% Input:
% index = index so far
% largest_mon = largest exponent so far
% j = ?
% Exp = exponent
% ord = ordering
%
% Output:
% ind = new index
% largest_m = new largest monomial

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%


if Exp(1) < 0
 largest_m = largest_mon;
 ind = index;
 return
end

if largest_mon(1) < 0
 largest_m = Exp;
 ind = j;
 return
end

switch ord
 
 case 'grlex'
  % graded lexicographic ordering
  
  slm = sum(largest_mon);
  sexp = sum(Exp);
  if slm < sexp
   ind = j;
   largest_m = Exp;
  elseif slm > sexp
   ind = index;
   largest_m = largest_mon;
  else
   diffind = largest_mon - Exp;
   
   indiff = find(diffind);
   
   if isempty(indiff)
    largest_m = largest_mon;
    ind = index;
    return
   end
   
   if diffind(indiff(1)) < 0
    ind = j;
    largest_m = Exp;
   else
    ind = index;
    largest_m = largest_mon;
   end % if indiff
   
  end % if slm
  
 case 'grevlex'
  % reverse graded lexicographic ordering
  % does not seem to work?????
  % gives the same result as grlex for n = 2
  % in the original form
  % correction below????
  
  slm = sum(largest_mon);
  sexp = sum(Exp);
  if slm < sexp
   ind = j;
   largest_m = Exp;
  elseif slm > sexp
   ind = index;
   largest_m = largest_mon;
  else
   diffind = largest_mon - Exp;
   % reverse
   diffind = diffind(end:-1:1);
   
   indiff = find(diffind);
   
   if isempty(indiff)
    largest_m = largest_mon;
    ind = index;
    return
   end
   
   %    if diffind(indiff(1)) > 0
   % correction????
   if diffind(indiff(1)) < 0
    ind = j;
    largest_m = Exp;
   else
    ind = index;
    largest_m = largest_mon;
   end % if indiff
   
  end % if slm
  
 case 'lex'
  % lexicographic ordering
  
  diffind = largest_mon - Exp;
  
  indiff = find(diffind);
  
  if isempty(indiff)
   largest_m = largest_mon;
   ind = index;
   return
  end
  
  if diffind(indiff(1)) < 0
   ind = j;
   largest_m = Exp;
  else
   ind = index;
   largest_m = largest_mon;
  end % if indiff
  
 otherwise
  
  error('gm_sort_monomial: This ordering is not implemented')
  
end % switch

