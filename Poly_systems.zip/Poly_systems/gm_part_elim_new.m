function [Atpart,colZ,valZ,rankA,colperm,Piv_PP,Zcol]=gm_part_elim_new(n,At,col_num);
%GM_PART_ELIM_NEW partial elimination of the variables for the rectangular
% matrix At

% colZ(k,:) gives for row k the columns in which there is a nonzero entry
% in the reduced matrix (in the original numbering)
% At is a rectangular matrix: size(At,2) > size(At,1)
% col_num are the original column numbers before permutation
%

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

nt = size(At,2);
m = size(At,1);
colZ = sparse(n,nt-m);
valZ = sparse(n,nt-m);

[Atpart,jb,rowp,Zcol] = gm_rref_polsys(At);

% Zcol are the zero columns
Zcol = col_num(Zcol);

rankA = length(jb);
Piv_PP = col_num(jb);
colperm = col_num;

% construction of colZ
nzmax = 0;
%km = m;
km = rankA;
for k = 1:km
 %kk = col_num(k);
 % caution!!!!!!!!!!!!!!! changes from the working version
 kk = Piv_PP(k);
 nz = 0;
 for j = k+1:nt
  if Atpart(k,j) ~= 0
   if kk ~= col_num(j)
    nz = nz+1;
    colZ(kk,nz) = col_num(j);
    valZ(kk,nz) = Atpart(k,j);
   end
  end % if Atpart(k,j)
 end % for j
 nzmax = max(nzmax,nz);
end % for k

colZ = colZ(:,1:nzmax);



