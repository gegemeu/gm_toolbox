function N=gm_normal_set(gbasis,ord,tol);
%GM_NORMAL_SET returns the normal set of the quotient ring from the Grobner
% basis

% Input:
% gbasis = Grobner basis
% ord = ordering
% tol = tolerance for the coefficients
%
% Output:
% N = normal set

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

N = {};

LM = gm_leading_monomials(gbasis);

% get the max power in all the monomials
% in the basis

npol = size(gbasis,1);

maxpow = 0;

for k= 1:npol
 P = gm_getpol(gbasis,k);
 Q = P{1,4};
 maxQ = max(max(Q(:,2:end)));
 maxpow = max(maxpow,maxQ);
end % for k

nvar = size(Q,2) - 1;

maxmon = maxpow * ones(1,nvar);
smax = sum(maxmon);

% check all the monomials for irreducibility

next = zeros(1,nvar);
in = 0;

while sum(next) ~= smax
 
 P = gm_create_1pol(next);
 
 Q = gm_reduceset(P,LM,ord,tol);
 
 izero = gm_iszero(Q,tol);
 
 if izero ~= 1
  % the monomial is irreducible, put it in the basis
  in = in + 1;
  N = gm_putpol(N,P,in);
 end % if
 
 next = gm_next_index(next,maxpow,nvar);
 
end % while

N = gm_sort_pol(N,ord,tol);


