function Q=gm_filter(Qset,tol);
%GM_FILTER removes zero polynomials from Qset

% Input:
% Qset = set of polynomials
% tol = tolerance for the coefficients. Those < tol are considered to be
%       zero
%
% Output: 
% Q = new set of polynomials

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(Qset,1);

Q={};

kp = 0;

for k =1:npol
 P = gm_getpol(Qset,k);
 Activ = P{1,1};
 CE = P{1,4};
 Coef = CE(:,1);
 if Activ == 0 || all(Coef < tol) || size(P,1) == 0
  % the polynomial is considered to be zero, skip it
  continue
 else
  % non zero polynomial, store it
  kp = kp + 1;
  Q = gm_putpol(Q,P,kp);
 end
end

