function PP_neigh=gm_neighbour_basis_new(n,PP_basis,Jcal);
%GM_NEIGHBOUR_BASIS_NEW finds the neighbours of PP_basis using Jcal

% Input:
% n = number of elements in a tuple
% PP_basis = basis
% Jcal = set of monomials
%
% Output:
% PP_neigh = neighbours of the PP_basis

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

neighb = [];

nP = length(PP_basis);

Z = Jcal(PP_basis,:);

[rJcal,rcal] = gm_crypt_add(Jcal);

for nu = 1:n
 
 xnu = zeros(1,n);
 xnu(nu) = 1;
 
 % add xnu to the indices in Z
 for k = 1:size(Z,1)
  xZ = xnu + Z(k,:);
  % find the adress in Jcal
  add = gm_find_add(xZ,Jcal,rJcal,rcal);
  % add it to the list
  neighb = [neighb add];
 end
end

% remove the multiple copies and the elements of the current PP_basis
PP_neigh = unique(neighb);
PP_neigh = gm_pol_setdiff(PP_neigh,PP_basis);

