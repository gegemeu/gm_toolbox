function MT=gm_multiplication_table(mon,N,gbasis,ord,tol);
%GM_MULTIPLICATION_TABLE returns the multiplication table
% associated with the monomial mon, normal set N and Grobner basis gbasis

% Input:
% mon = monomial
% N = normal set
% gbasis = Grobner basis
% ord = ordering
% tol = tolerance for the eigenvalues
%
% Output:
% MT = multiplication table (matrix)

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% number of monomials in the normal set basis
% (standard monomials)

nns = size(N,1);

MT = zeros(nns,nns);

for k = 1:nns
 ns = gm_getpol(N,k);
 % get the term
 LT = ns{1,3};
 % get the monomial
 LM = LT(1,2:end);
 % multiply by the monomial mon
 M = mon + LM;
 % create a polynomial from the monomial mon
 P = gm_create_1pol(M);
 % reduce wrt the gbasis
 Q = gm_reduceset(P,gbasis,ord,tol,0);
 % sort the polynomial (descending order)
 Q = gm_sort_pol(Q,ord,tol);
 
 col = gm_get_entries(Q,N);
 
 if size(col,1) > nns
  fprintf('\n gm_multiplication_table: Dimension problem, nns = %d, col = %d \n\n ',nns,col)
  return
 end
 
 MT(:,k) = col;
 
end % for k

