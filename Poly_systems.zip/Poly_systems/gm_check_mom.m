function [condi,s,Ms1,Ms]=gm_check_mom(Mt,D,d,ts,nvar,MJ);
%GM_CHECK_MOM checks the rank conditions for the moment matrix

% Input:
% Mt = moment matrix
% D = 
% d = 
% ts = 
% nvar = number of variables
% MJ = 
%
% Output:
% condi = 1 if the conditions are satisfied
% s = 
% Ms1 = 
% Ms = 

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

condi = 0;
s = 0;

dD = min(D,d);
old_rank = 0;
Ms1 = [];

[rM,rm] = gm_crypt_add(MJ);

for s = 1:ts
 J = gm_build_lexic_order(nvar,s);
 ss = size(J,1);
 S = zeros(1,ss);
 % find the adresses of J in MJ
 for j = 1:ss
  ind = J(j,:);
  rmon = sum(rm .* ind);
  I = find(rmon == rM);
  add = I(1);
  S(j) = add;
 end % for j
 Ms = Mt(S,S);
 sig = svd(Ms);
 rMS = gm_rank(sig);
 rankMS(s) = rMS;
 
 % check the conditions (see Rostalski's Ph.D. thesis)
 if (rMS == old_rank)
  % condition 7.1.1 is satisfied
  condi = 1;
  return
 end % if
 if (s > d) & (rMS == rankMS(s-d))
  % condition 7.1.2 is satisfied
  condi = 1;
  return
 end % if
 
 old_rank = rMS;
 Ms1 = Ms;
 
end % for s

