function Ind=gm_reorder_eig(lambr,lambl);
%GM_REORDER_EIG reorders the eigenvalues in lambl

% Input:
% lambr = right eigenvalues
% lambl = left eigenvalues
% 
% Output:
% Ind = set of indices

%
% Author G. Meurant
% March 2010
%

n = length(lambr);
Ind = zeros(n,1);

[Y,Is] = sort(lambr);

[Z,Js] = sort(lambl);

Ind(Is) = Js;


 