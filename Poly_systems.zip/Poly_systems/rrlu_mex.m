%  SYNTAX:
%
%      [L, U, P, Q] = rrlu_mex(A, version)
%
%  PURPOSE:
%  -----------------------------------------------------------------------
%
%  rrlu computes a rank revealing  LU factorization of a general m-by-n 
%  full real matrix A using partial pivoting with row and column interchanges.
%
%  The factorization has the form
%
%      A(P,Q) = L * U
%
%  where P and Q are permutation vectors, L is lower triangular 
%  (lower trapezoidal if m > n), and U is upper triangular 
%  (upper trapezoidal if m < n).
%
%  if version = 0
%      then L has unit diagonal elements and the matrix U takes form
%
%            U = [ U1  U2 ]            (*)
%                [ 0   0  ]
%
%      where U1 in upper triangular with nonzero elements on diagonal
%
%  if version = 1
%      then U has unit diagonal elements and the matrix L takes form
%
%            L = [ L1  0 ]             (**)
%                [ L2  0 ]
%
%      where L1 in lower triangular with nonzero elements on diagonal
%
%
%  INPUTS:
%  -----------------------------------------------------------------------
%  A                   a M x N full real matrix
%
%  version 
%          = 0:        the matrix L has unit diagonal elements, 
%                      and the matrix U takes the form (*)
%          = 1:        the matrix U has unit diagonal elements, 
%                      and the matrix L takes the form (**)
%
%
%  OUTPUTS:
%  -----------------------------------------------------------------------
%  L       lower triangular matrix
%
%  U       upper triangular matrix
%
%  P       row permutation indices 
%
%  Q       column permutation indices
%
%
%  INSTALATION:
%  -----------------------------------------------------------------------
%
%  In order to create rrlu_mex.dll execute the following statement
%
%       mex rrlu_mex.c rrlu.c utils.c [C:/Matlab]/extern/lib/win32/lcc/libmwlapack.lib
%
%  where [C:/Matlab] is the Matlab root directory

% All rights reserved
% rrlu is available free for noncommercial academic use only.
% pawel.kowal@ibs.org.pl
% 08.2006.

error('mex function not found');