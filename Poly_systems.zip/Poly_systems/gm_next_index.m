function next=gm_next_index(tuple,upbd,n);
%GM_NEXT_INDEX returns the next item in all the possible combinations

% Input:
% tuple = set of integers (to which we add 1) as a row vector
% upbd = max value of the integers
% n = number of integers in the set
%
% Output:
% next = new value after the addition

%
% Author G. Meurant
% Jan 2010
% corrected March 2010
% Updated Sept 2015
%

ltup = n;

if sum(tuple) >= ltup * upbd
 % this is the last element, return upbd + 1 to stop
 for k = 1:ltup
  next(k) = upbd+1;
 end
 % could be next(1:ltup) = upbd + 1:
 return
end

% add 1 to the rightmost element and propagates the carries to the left
next = tuple;

next(ltup) = next(ltup) + 1;

for k = ltup:-1:2
 if next(k) > upbd
  next(k) = 0;
  next(k-1) = next(k-1) + 1;
 else
  break
 end
end


