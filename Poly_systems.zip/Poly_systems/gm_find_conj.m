function L=gm_find_conj(ind,lambrk,lambl);
%GM_FIND_CONJ finds the index L for which lambl(L) = conj(lambrk)

% Input:
% Ind = default index
% lambrk = eigenvalue
% lambl = set of eigenvalues
%
% Output:
% L = index in lambl

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

clamb = conj(lambrk);

L = ind;
rl = real(clamb);
iml = imag(clamb);
epsi = 1e-6;

for k = 1:length(lambl)
 dreal = abs(rl - real(lambl(k)));
 dimag = abs(iml - imag(lambl(k)));
 if (dreal <= epsi * abs(rl)) && (dimag <= epsi * abs(iml))
  L = k;
  return
 end % of
end % for k

