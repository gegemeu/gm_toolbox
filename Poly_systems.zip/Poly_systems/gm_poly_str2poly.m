function [Pset,poly_terms]=gm_poly_str2poly(strcell,varnames);
%GM_POLY_STR2POLY  converts multivariate polynomials from strings to arrays

% Input:
%  strcell = a cell array of strings, one per polynomial
%           all numbers must be whole or decimal form (no scientific notation)
%           brackets and double negatives are not allowed.
%           All spaces in the strings are ignored.
%  varnames (optional) = a cell array of strings which must include all
%           variable names that occur in strcell [default: {'x1','x2',...}]
%
% Output:
%  Pset = a cell array of polynomial coefficients where Pset{i}(k1,k2,...)
%         is the coefficient of the term x1^k1*x2^k2*...

% Example:
%  gm_poly_str2poly({'x1*x2^2'})    % returns {[1,0,0;0,0,0]}
%  gm_poly_str2poly({'-x1*x2^2'})   % returns {[-1,0,0;0,0,0]}
%  gm_poly_str2poly({'-1*x1*x2^2'}) % returns {[-1,0,0;0,0,0]}
%  gm_poly_str2poly({'- 1 * x 1 * x 2 ^ 2'}) % returns {[-1,0,0;0,0,0]}

% Author: Ben Petschel 19/6/2009
%
% modified by G. Meurant
% January 2010
% Updated Sept 2015
%

maxvar = 0;

if nargin < 2
 varnames = {}; % will fill in varnames later, as needed
end
Pset = cell(size(strcell));

for i = 1:numel(strcell)
 str = strcell{i};

 % ignore all spaces
 remain = str;
 remain = strrep(remain,' ','');

 % first insert "+" before every "-", for easier term separation later
 str = '';
 while ~isempty(remain)
  if remain(1) == '-',
   if isempty(str)
    str = '-';
   else
    str = [str,'+-'];
   end
  end
  [tok,remain] = strtok(remain,'-');
  str = [str,tok];
 end

 % now separate into terms
 remain = str;
 terms = [];
 while ~isempty(remain)
  coeff = 1;
  exps = [];
  [term,remain] = strtok(remain,'+');
  % process term, separating into products
  rem2 = term;
  while ~isempty(rem2)
   [part,rem2] = strtok(rem2,'*');
   if ~isnan(str2double(part))
    % part is a number, multiply it by the coefficient
    coeff = coeff * str2double(part);
   else
    % part is var^n or var or -var^n or -var
    if part(1) == '-',
     coeff = -coeff;
     part = part(2:end);
     if isempty(part)
      error('gm_poly_str2poly: Isolated minus sign');
     end
    end
    ind = find(part == '^');
    if isempty(ind)
     var = part;
     expo = 1;
    else
     ind = ind(1);
     var = part(1:ind-1);
     expo = str2double(part(ind+1:end));
     if isnan(expo)
      % exponent is not valid
      error('gm_poly_str2poly: Invalid exponent in part %s',part);
     end
    end
    if isempty(varnames)
     % see if var is of form 'x1' etc
     if (length(var) > 1) && (var(1) == 'x') && ~isnan(str2double(var(2:end)))
      % variable name is ok
      k = str2double(var(2:end));
     else
      error('gm_poly_str2poly: Variable name not of form "x1","x2",...');
     end
    else
     ind = strmatch(var,varnames,'exact');
     if isempty(ind)
      error('gm_poly_str2poly: Variable name not in list');
     end
     k = ind(1);
    end
    if length(exps) < k,
     exps = [exps,zeros(1,k-length(exps))];
    end
    exps(k) = exps(k) + expo;
   end
   
  end % while ~isempty(rem2)
  
  % term is processed, now add it to the list of terms
  if size(terms,2) < (length(exps)+1)
   terms = [terms,zeros(size(terms,1),length(exps)+1-size(terms,2))];
  elseif length(exps)<size(terms,2)-1
   exps = [exps,zeros(1,size(terms,2)-1-length(exps))];
  end
  terms = [terms;coeff,exps];
  
 end % while ~isempty(remain)
 
 maxvar = max(maxvar,size(terms,2)-1);

 poly_terms{i} = terms;

 % now we have all the terms, so convert it to a NxMx... matrix
 % first make it at least 2-dimensions
 if size(terms,2) == 1
  terms = [terms,zeros(size(terms,1),2)];
 elseif size(terms,2) == 2
  terms = [terms,zeros(size(terms,1),1)];
 end
 P = zeros(max(terms(:,2:end),[],1)+1);
 for j = 1:size(terms,1),
  c = num2cell(size(P)-terms(j,2:end));
  P(c{:}) = terms(j,1);
 end
 Pset{i} = P;

end % for i=1:numel(strcell)

% check if some polynomials miss some variables

npol = size(poly_terms,2);
for k = 1:npol
 terms = poly_terms{k};
 maxv = size(terms,2) - 1;
 if maxvar ~= maxv
  % padd with zeros
  terms = [terms zeros(size(terms,1),maxvar-maxv)];
  poly_terms{k} = terms;
 end % if size
end % for k


