function [rJ,r]=gm_crypt_add(J);
%GM_CRYPT_ADD crypts the addresses in J

% Input:
% J = list of n-tuples
%
% Output:
% rJ = result of the crypting
% r = random numbers (keys of the crypting)

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

sm = size(J,2);
r = rand(1,sm);

sJ = size(J,1);

R = r(ones(sJ,1),:);
RJ = R .* J;

rJ = sum(RJ,2);



