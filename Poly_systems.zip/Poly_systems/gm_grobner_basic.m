function gbasis=gm_grobner_basic(polyset,varnames,ord,tol);
%GM_GROBNER_BASIC calculates the reduced Groebner basis of a set of polynomials

% basic Buchberger's algorithm without any test to avoid useless pairs
% and only full reduction at the end

% Input:
%  polyset = a cell array of multivariate polynomial coefficients
%            The cell elements are strings
%            They must use variable names 'x1','x2',...
%            (unless varnames is provided) and be valid inputs for gm_create
%  ord = a string specifying the monomial ordering:
%        'lex': lexicographical, order by highest power of most significant
%         indeterminate,
%        'grlex': graded lex, order by total degree then lex,
%        'grevlex': graded reverse lex, order by total degree then by lowest
%         power of least significant indeterminate
%  varnames (optional) = a cell array of variable names if polyset is a
%           cell array of strings and the variable names are not 'x1', 'x2', etc.
%           If specified, there must always be at least 2 variables.
%  tol (optional) = the zero tolerance for coefficients, otherwise
%       catastrophic cancellation may occur.  Default value is 0
%
% Ouput:
%  gbasis = the reduced Grobner basis of the set of polynomials, as a
%           string if the input is a string

% Updated by G. Meurant
% Sept 2015
%

if nargin < 4
 tol = 0;
end

if (numel(polyset) > 0) && ischar(polyset{1})
 charout = true;
 
 polyset = gm_create(polyset,varnames,ord,tol);
 
else
 charout = false;
end

gbasis = gm_fullreduce(polyset,ord,tol);
oldgbasis = {};

iwg = 0;
while ~isequal(oldgbasis,gbasis)
 iwg = iwg + 1;
 oldgbasis = gbasis;
 Qset = gm_SPoly_basic(gbasis,ord,tol);
 gbasis = Qset;
end % while

gbasis = gm_fullreduce(gbasis,ord,tol);



