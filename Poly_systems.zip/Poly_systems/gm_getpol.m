function P=gm_getpol(Pols,k);
%GM_GETPOL returns a cell array containing polynomial k

% Input:
% Pols = set of polynomials
% k = number of the needed polynomial
%
% Output:
% P = cell array containing polynomial k

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

Activ = Pols{k,1};

if Activ == 1

 P = cell(1,4);

 P{1,1} = Pols{k,1};
 P{1,2} = Pols{k,2};
 P{1,3} = Pols{k,3};
 P{1,4} = Pols{k,4};

else

 P = {};

end

