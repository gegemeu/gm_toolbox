function Pols=gm_putpol(Pols,P,k);
%GM_PUTPOL changes the cell array containing polynomial k

% Input:
% Pols = set of polynomials
% P = polynomial to replace polynomial k
% k = number of the polynomial to be replaced
%
% Output:
% Pols = new set of polynomials

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

Activ = P{1,1};

if Activ == 1

 Pt = P{1,1};
 Pols{k,1} = Pt;
 Pt = P{1,2};
 Pols{k,2} = Pt;
 Pt = P{1,3};
 Pols{k,3} = Pt;
 Pt = P{1,4};
 Pols{k,4} = Pt;

end

