function [fpol,addpol,Mnu]=gm_str_to_defpol(poly_terms);
%GM_STR_TO_DEFPOL takes the output from gm_poly_strt2poly to the
% defpol format 

%
% Input:
% poly_terms = cell array containing the polynomial
%
% Output:
% fpol = polynomial in defpol format
%     for each polynomial number npol we have
%     (npol,1) = 1 active, = 0 inactive (deleted)
%     (npol,2) = number of terms in the polynomial
%     (npol,3) = leading term
%     (npol,4) = coefficients and exponents (2D array)
% addpol = pointer to the start of a polynomial in fpol
% Mnu = maximum degree for each polynomial

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

npol = size(poly_terms,2);
add = 1;

addpol = zeros(npol+1,1);
Mnu = zeros(npol,1);

% number of variables
nvar = 0;
for k = 1:npol
 terms = poly_terms{k};
 nvar = max(nvar,size(terms,2)-1);
end

for k = 1:npol
 
 terms = poly_terms{k};
 
 addpol(k) = add;
 
 maxdeg = 0;
 % eventually padd with zeros if not all the variables are there
 nterm = size(terms,2) - 1;
 addterm = [];
 if nterm < nvar
  addterm = zeros(1, nvar-nterm);
 end
 
 for i = 1:size(terms,1);
  fpol{add,1} = k;
  fpol{add,2} = [terms(i,2:end) addterm];
  fpol{add,3} = terms(i,1);
  add = add + 1;
  maxdeg = max(maxdeg,sum(terms(i,2:end)));
 end
 
 Mnu(k) = maxdeg;
 
end

addpol(npol+1) = add;

