function cond=gm_is_greater_mon(LM,LCM,ord);
%GM_IS_GREATER_MON true if LM > LCM

% Input:
% LM, LCM = monomials
% ord = ordering
%
% Ouput:
% cond = 1 if LM > LCM

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

[ind,largest_m] = gm_sort_monomial(1,LM,2,LCM,ord);

if ind == 1
 cond = 1;
else 
 cond = 0;
end

