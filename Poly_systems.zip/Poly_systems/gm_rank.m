function r=gm_rank(sig);
%GM_RANK computes the rank from the singular values sig

% Input:
% sig = singular values
%
% Output:
% r = numerical rank

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

epss = 1e-14; 
Del = 0.1; 

n = length(sig);

nsig = sqrt(sum(sig));
ensig = epss * nsig;
r = 1;

for k = n:-1:1
 if sig(k) >= ensig
  % k is candidate, check if it is separated from the smaller singular
  % values
  if k ~= n
   if sig(k) >= (Del * sig(k+1))
    r = k;
    return
   end % if 
  else
   r = k; 
   return
  end % if
 end % if
end % for k

