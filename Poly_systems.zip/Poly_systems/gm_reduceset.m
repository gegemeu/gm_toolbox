function Q=gm_reduceset(P,Pset,ord,tol,varargin);
%GM_REDUCESET reduces P wrt all polynomials in Pset

% Input:
% P = polynomial to be reduced
% Pset = set of polynomials
% ord = ordering
% tol = tolerance for the coefficients
% varargin = 1 reduce the leading coefficient (default)
%
% Output:
% Q = reduced polynomial

%
% Author G. Meurant
% March 2010
% from a code by B. Petschel
% Updated Sept 2015
%

if nargin == 4
 red = 1;
else
 red = varargin{1};
end

Q = P;
oldQ = {};

while ~isequal(oldQ,Q)
 oldQ = Q;

 for i = 1:size(Pset,1)
  Pol = gm_getpol(Pset,i);
  Q = gm_reduce(Q,Pol,ord,tol,red);
 end % i

end % while

