function cond=gm_is_contained_pair(B,P1,P2);
%GM_IS_CONTAINED_PAIR true if (P1,P2) is contained in B

% Input:
% B = list of pairs
% P1, P2 = polynomials
%
% Output:
% cond = 1 if (P1,P2) is contained in B

%
% Author G. Meurant
% March 2010
%

cond = 0;

npair = size(B,1);

for k =1:npair
 Q1 = B{k,2};
 Q2 = B{k,3};
 
 c1 = isequal(P1,Q1);
 c2 = isequal(P2,Q2);
 
 if c1 && c2
  cond = 1;
  return
 end % if
 
end % for k

