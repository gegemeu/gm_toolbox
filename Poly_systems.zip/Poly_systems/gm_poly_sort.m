function [poly_t,lt]=gm_poly_sort(poly_terms,ord,tol);
%GM_POLY_SORT sorts the polynomials according to the monomial order ord

% Input:
% poly_terms = polynomial given by the coefficients and the exponents
% ord = ordering
% tol = all coefficients smaller than tol are set to 0
%
% Output:
% poly_t = sorted polynomial
% lt = leading term of the polynomial

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

npol = numel(poly_terms);

poly_t = poly_terms;

lt = cell(npol,1);

for k = 1:npol
 % get the exponents and the coefficient
 P = poly_terms{k};
 Exp = P(:,2:end);
 Coef = P(:,1);
 
 % very simple sort of the exponents
 i = 0;
 sE = size(Exp,1);
 while sE > 0
  largest_mon = Exp(1,:);
  index = 1;
  for j = 2:sE
   % this function is in Interpolation\Utilities
   [index,largest_mon] = gm_sort_monomial(index,largest_mon,j,Exp(j,:),ord);
  end % for j
  if abs(Coef(index)) >= tol
   i = i + 1;
   P(i,2:end) = largest_mon;
   P(i,1) = Coef(index);
  end
  % remove the largest one
  Exp = [Exp(1:index-1,:); Exp(index+1:end,:)];
  Coef = [Coef(1:index-1,:); Coef(index+1:end,:)];
  sE = sE - 1;
 end % while
 
 poly_t{k} = P;
 lt{k} = P(1,:);
end % for k

