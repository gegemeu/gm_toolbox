function N=gm_null_lu(A)
%GM_NULL_LU returns a basis of the left null space of A

% Input:
% A = matrix
%
% Output:
% N = basis of the null space


% All rights reserved
% null_lu is available free for noncommercial academic use only.
% pawel.kowal@ibs.org.pl
% 08.2006.

loadlibrary('rrlu_mex');

[n,m] = size(A);
[L,U,P,Q] = rrlu_mex(A,0);

tol = max([n,m]) * norm(A,1) * eps;
Rank = gm_getRank(0,L,U,tol);
L1 = L(1:Rank,1:Rank);
L2 = L(Rank+1:end,1:Rank);
N  = [-L2/L1 eye(n-Rank)];
[dum,P] = sort(P);
N = N(:,P);



