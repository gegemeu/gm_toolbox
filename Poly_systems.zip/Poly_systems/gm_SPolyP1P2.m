function S=gm_SPolyP1P2(P1,P2,ord,tol);
%GM_SPOLYP1P2 calculates the S-polynomial of P1 and P2

%   S12 = (L12/a1)*P1 - (L12/a2)*P2,
% for the pair of polynomials P1, P2, where a1 and a1 are the leading
% terms of P1 and P2, and L12 is the least common multiple of a1 and a2

% Input:
% P1, P2 = pairs of polynomials
% ord = ordering
% tol = tolerance coefficients
%
% Output:
% S = S - polynomial

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

LT1 = P1{1,3};
d1 = LT1(1,2:end);
  
LT2 = P2{1,3};
d2 = LT2(1,2:end);

L = max(d1,d2); % LCM of leading terms

Q1 = gm_getpol(P1,1);
Q1 = gm_multiplyterm(Q1,L-d2,ord);
Q2 = gm_getpol(P2,1);
Q2 = gm_multiplyterm(Q2,L-d1,ord);
S = gm_subtract(Q2,Q1,ord,tol);





