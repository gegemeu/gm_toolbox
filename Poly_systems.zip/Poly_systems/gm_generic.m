function [y,M,rM,rm]=gm_generic(Pset,nvar,t);
%GM_GENERIC computes a generic element of K_(t,C)

% t must be >= max degree of Pset

% Input:
% Pset = set of polynomials
% nvar = number of variables
% t = parameter (max degree)
%
% Output:
% y = 
% M = lexicographic ordering
% rM = 
% rm = 

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

y = [];

npol = size(Pset,1);

% generate the monomials of degree <= t

M = gm_build_lexic_order(nvar,t);
[rM,rm] = gm_crypt_add(M);

sM = size(M,1);

Ht = zeros(npol*sM,sM);

% multiply each polynomial with monomials of
% appropriate degree

row = 0;

for k = 1:npol
 P = gm_getpol(Pset,k);
 Q = P{1,4};
 Coef = Q(:,1);
 Exp = Q(:,2:end);
 sExp = size(Exp,1);
 % degree of P
 dk = max(sum(Exp,2));
 
 Mk = gm_build_lexic_order(nvar,t-dk);
 
 for j = 1:size(Mk,1)
  Mkj = Mk(j,:);
  row = row + 1;
  % add the indices to multiply
  Expj = Exp + Mkj(ones(sExp, 1), :);
  % find the corresponding columns (indexed by M)
  for ic = 1:sExp
   rmon = sum(rm .* Expj(ic,:),2);
   I = find(rmon == rM);
   add = I(1);
   % put the coefficient in the column add
   Ht(row,add) = Coef(ic,1);
  end % for ic
  
 end % for j
 
end % for k

Ht = Ht(1:row,:);

% null space

Z = null(Ht);

% generate random numbers

c = rand(1,size(Z,2));

y = zeros(size(Z,1),1);
for j = 1:size(Z,2)
 y = y + c(j) * Z(:,j);
end










