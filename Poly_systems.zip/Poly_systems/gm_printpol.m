function gm_printpol(Poly,varnames)
%GM_PRINTPOL prints the polynomials in Poly

% Input:
% Poly = polynomial
% varnames = variable names

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% convert to strings
if numel(varnames) > 0
 strcell = gm_poly_poly2str(Poly,varnames);
else
 strcell = gm_poly_poly2str(Poly);
end

npol = size(Poly,1);

fprintf('\n\n')
k = 0;
for i = 1:npol
 actP = Poly{i,1};
 if actP == 1
  k = k + 1;
  pol = strcell{i};
  fprintf(' Pol%s = %s \n',num2str(k),pol)
 end
end
fprintf('\n')

