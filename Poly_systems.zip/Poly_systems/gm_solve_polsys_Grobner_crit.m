function [xsol,val_sol]=gm_solve_polsys_Grobner_crit(defpoly,varnames,ord,tol);
%GM_SOLVE_POLSYS_GROBNER_CRIT solves the polynomial system using a Grobner basis
% and eigenvalues

% Input:
% defpoly = polynomials definition
% varnames = variable names
% ord = ordering
% tol = tolerance for the coefficients
%
% Output:
% xsol = solutions
% val_sol = values of the polynomials at the solutions

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

if nargin < 3
 ord = 'grlex';
end
if nargin < 4
 tol = 1e-10;
end

xsol = [];
val_sol = [];

% compute the Grobner basis

gbasis = gm_grobner_crit(defpoly,varnames,ord,tol);

if (size(gbasis,1) == 1)
 P = gbasis{1,4};
 izero = sum(P);
 if izero == 1
  fprintf('\n gm_solve_polsys_Grobner_crit: There is no solution to this system \n\n')
  return
 end
end

% compute the normal set (standard polynomials)

N = gm_normal_set(gbasis,ord,tol);

nvar = size(gbasis{1,3},2) - 1;

% multiplication matrix for the first variable

mon = zeros(1,nvar);
mon(1) = 1;

MTx = gm_multiplication_table(mon,N,gbasis,ord,tol);

% compute the eigensystem of the multiplication matrix

[XMT,DMT] = eig(MTx);

% we must test for multiple eigenvalues ??????????????

comp = diag(DMT);

xsol(1,:) = comp';

iXMT = inv(XMT);

% compute and diagonalize the other systems

for k = 2:nvar
 
 mon = zeros(1,nvar);
 mon(k) = 1;
 
 MT = gm_multiplication_table(mon,N,gbasis,ord,tol);
 
 % do the matrices commute?
 
 comm = norm(MTx * MT - MT * MTx,'inf');
 
 if comm > 1e-10
  fprintf('\n gm_solve_polsys_Grobner_crit: The multiplication matrices do not commute, the solutions may be wrong \n\n')
 end
 
 DMT = iXMT * MT *XMT;
 
 comp = diag(DMT);
 
 % could eventually test NaNs in the solution ??
 
 xsol(k,:) = comp';
 
end % for k

% obtain the terms from the strings
[Pset,poly_terms] = gm_poly_str2poly(defpoly,varnames);
% convert to defpol format for the evaluation
[fpol,addpol,Mnu] = gm_str_to_defpol(poly_terms);

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

xx = [];
val = [];

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) <= 1e-5
  xx = [xx xsol(:,k)];
  val = [val val_sol(:,k)];
 end
end % for k

xsol = xx;
val_sol = val;









