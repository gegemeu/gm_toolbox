function Xxj=gm_mul_tab(mon,s,Ms,MBs,U,nvar);
%GM_MUL_TAB multiplication table for the moment algorithm

% Input:
% mon = monomial
% s = degree
% Ms =
% MBs = 
% U = 
% nvar = number of variables
%
% Output:
% Xxj = multiplication table

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

Js1 = gm_build_lexic_order(nvar,s-1);
Js = gm_build_lexic_order(nvar,s);
[rJs,rs] = gm_crypt_add(Js);

% add the indices
sJ = size(Js1,1);
Jx = zeros(sJ,nvar);
for i = 1:sJ
 Jx(i,:) = Js1(i,:) + mon;
end % for i
% get the submatrix of Ms indiced by J and Jx
Px = zeros(sJ,sJ);
for i = 1:sJ
 indi = Js1(i,:);
 rmon = sum(rs .* indi,2);
 I = find(rmon == rJs);
 row = I(1);
 for l = 1:sJ
  indl = Jx(l,:);
  rmon = sum(rs .* indl,2);
  I = find(rmon == rJs);
  col = I(1);
  Px(i,l) = Ms(row,col);
 end % for l
end % for i
Pxj = U' * Px * U;
Xxj = MBs \ Pxj;



