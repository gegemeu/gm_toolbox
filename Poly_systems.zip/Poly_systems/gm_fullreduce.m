function Qset=gm_fullreduce(Pset,ord,tol);
%GM_FULLREDUCE reduces all polynomials wrt each other

% Input:
% Pset = set of polynomials
% ord = ordering
% tol = tolerance for the coefficients
%
% Output:
% Qset = reduced set of polynomials

%
% Author G. Meurant
% March 2010
% from a code by B. Petschel
% Updated Sept 2015
%

Qset = Pset;
oldQset = {};

iw = 0;

while ~isequal(oldQset,Qset)
 iw = iw + 1;
 
 oldQset = Qset;
 
 for i = 1:size(Qset,1)-1
  
  for j = i+1:size(Qset,1)
   Qj = gm_getpol(Qset,j);
   Qi = gm_getpol(Qset,i);
   Qi = gm_reduce(Qi,Qj,ord,tol);
   Qj = gm_reduce(Qj,Qi,ord,tol);
   Qset = gm_putpol(Qset,Qj,j);
   Qset = gm_putpol(Qset,Qi,i);
  end % j
  
 end % i
 
end % while

% keep only the nonzero results (to within zero tolerance tol)

Qset = gm_filter(Qset,tol);

if size(Qset,1) == 1
 % special case, a single equation can slip through without being reduced
 LT = Qset{1,3};
 c = LT(1,1);
 Qset = gm_poly_normalize(Qset,c);
end % if size



