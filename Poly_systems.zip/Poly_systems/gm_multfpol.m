function [At,A01,A00,Jcal0,Jcal,DJcol,addJcal,DJcol0]=gm_multfpol(fpol,addpol,Mnu);
%GM_MULTFPOL multiplies the polynomials f_i by the monomials

% Input:
% fpol = polynomial in defpol format
%     for each polynomial number npol we have
%     (npol,1) = 1 active, = 0 inactive (deleted)
%     (npol,2) = number of terms in the polynomial
%     (npol,3) = leading term
%     (npol,4) = coefficients and exponents (2D array)
% addpol = pointer to the start of a polynomial in fpol
% Mnu = maximum degree for each polynomial
%
% Output:
% variables needed by gm_solve_polsys_AS

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

iprint = 0;

npol = length(addpol) - 1;

[Jcal,Jcals,addJcal,DJcol0] = gm_build_Jcal(npol,Mnu);
[DJcal,DJcol] = gm_build_boundary(npol,Jcal,Mnu);

N = addJcal(npol + 1) - 1;
m = addJcal(npol + 2) - addJcal(npol + 1);

% size of At
At = sparse(N,N + m);

% loop on polynomials

for k = 1:npol
 
 % compute the monomials in Z^(k)
 % they are in given by the sets of indices \hat J_nu
 % for nu = 1,...,n (in Jcalnus) and J_0
 
 Jcalnus = Jcals(addJcal(k):addJcal(k + 1) - 1,:);
  
 % get the indices and the coefficients for the polynomial k
 
 % start and end of polynomial k in the list fpol
 istart = addpol(k);
 iend = addpol(k + 1) - 1;
 
 for j = istart:iend
  % get the triple in the cell array fpol
  ind = fpol{j,2};
  indk(j,:) = ind;
  val = fpol{j,3};
  coeff(j) = val;
 end
 
 % loop on all the monomials in \hat J_nu
 
 [rJcal,rcal] = gm_crypt_add(Jcal);
 
 for i = 1:size(Jcalnus,1)
  
  % loop on the monomials in the k-th polynomial
  
  for j = istart:iend
   
   % add the indices and get the coefficient
   
   indz = Jcalnus(i,:) + indk(j,:);
   
   % find the address in Z
   
   add = gm_find_add(indz,Jcal,rJcal,rcal);
   if add == 0
    Jcnus = Jcalnus(i,:)
    indkj = indk(j,:)
    error('gm_multfpol: Index problem')
   end
      
   % store the coefficient in At, column add, row zstart + i - 1
   zstart = addJcal(k);
   
   At(zstart + i - 1,add) = coeff(j);
   
  end
 end
 
end

% must add J_0

indk = zeros(npol,npol);
indk(1:npol,1:npol) = eye(npol,npol);

Jcal0 = Jcal(addJcal(npol + 1):end,:);

A01 = zeros(m,N,npol);
A00 = zeros(m,m,npol);

% loop on all the monomials in J_0

for i = 1:size(Jcal0,1)
 
 % loop on the monomials in the dummy polynomial
 % except the constant coefficient
 
 for j = 1:npol
  
  % add the indices
  
  indz = Jcal0(i,:) + indk(j,:);
  
  % find the address in Z

  add = gm_find_add(indz,Jcal,rJcal,rcal);
    
  % store the coefficient in At, column add, row  i
  % if the adress is smaller than N it is in A01, else in  A00
  
  if add <= N
   A01(i,add,j) = 1;
  else
   A00(i,add - N,j) = 1;
  end
  
 end
end


