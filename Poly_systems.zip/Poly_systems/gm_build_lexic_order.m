function J=gm_build_lexic_order(n,d);
%GM_BUILD_LEXIC_ORDER build a lexicographic ordering of
% the n-tuples with values from 0, 1, 2, ... of degree <= d

% Input:
% n = size of the tuples
% d = degree
%
% Output:
% J = list of the tuples

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

next = zeros(1,n);

J = next;

% keep only the tuples for which sum <= d

while next(1) ~= d
 % add 1 to the last element and propagates the carries to the left
 next(n) = next(n)+1;
 for k = n:-1:2
  if next(k) > d
   next(k) = 0;
   next(k-1) = next(k-1) + 1;
  else
   break
  end % if
 end % for k
 
 sJ = sum(next);
 if sJ <= d
  J = [J; next];
 end
end







