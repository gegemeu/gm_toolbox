function [Jcal,Jcals,addJcal,DJcol0]=gm_build_Jcal(n,Mnu);
%GM_BUILD_JCAL constructs the sets of indices J_nu and J_nu s
% for the Auzinger and Stetter method

% Input:
% n = number of polynomials
% Mnu = maximum degree for each monomial
%
% Output:
% Jcal, Jcals = sets of indices J_nu and J_nu s
% addJcal = a pointer on the start of each set
% DJcol0 = column indices of Jcal0

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

Jord = [];

[Jcalnu,Jcalnus,Jord] = gm_build_Jcalnu(1,n,Mnu,Jord);
Jcal = Jcalnu;
Jcals = Jcalnus;
addJcal = zeros(n+2,1);
addJcal(1) = 1;
add = size(Jcalnu,1) + 1;

for nu = 2:n
  addJcal(nu) = add;
  [Jcalnu,Jcalnus,Jord] = gm_build_Jcalnu(nu,n,Mnu,Jord);
  Jcal = [Jcal; Jcalnu];
  Jcals = [Jcals; Jcalnus];
  add = add + size(Jcalnu,1);
end

addJcal(n+1) = add;

% add J_0

Jcal0 = gm_build_Jcal0(n,Mnu,Jord);

% DJcol0 gives the column indices of Jcal0
lJcal = size(Jcal,1);
lJcal0 = size(Jcal0,1);
DJcol0 = [lJcal+1:lJcal+lJcal0-1];

Jcal = [Jcal; Jcal0];
Jcals = [Jcals; Jcal0];

add = add + size(Jcal0,1);
addJcal(n+2) = add;

