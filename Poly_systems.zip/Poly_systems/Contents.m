% POLY_SYSTEMS
%
% Files
%   gm_allnormalize               - normalizes all the polynomials in Q
%   gm_append                     - adds the polynomial P to the set Pols
%   gm_append_pair                - appends pairs from gb and h to list p
%   gm_appendset                  - adds the polynomials from the set Pset to the set Pols
%   gm_buch_criteria              - returns the Buchberger criteria
%   gm_build_boundary             - builds the boundary set for the Auzinger and Stetter method
%   gm_build_Jcal                 - constructs the sets of indices J_nu and J_nu s
%   gm_build_Jcal0                - constructs the set of indices J_0 for the Auzinger and Stetter method
%   gm_build_Jcalnu               - constructs the set of indices J_nu for the Auzinger and Stetter method
%   gm_build_lexic_order          - build a lexicographic ordering of the n-tuples
%   gm_build_lexic_order_new      - builds a lexicographic ordering of the n-tuples
%   gm_check_mom                  - checks the rank conditions for the moment matrix
%   gm_comp_sol                   - computes the solutions from the multiplication tables
%   gm_create                     - creates a polynomial system using cell arrays
%   gm_create_1pol                - creates one polynomial system from the monomial mon
%   gm_create_pairs               - creates the "pairs" object from the basis gb
%   gm_crypt_add                  - crypts the addresses in J
%   gm_defpol_to_poly             - translates from defpol to mpol format (for Grobner)
%   gm_eval_polsys                - computes the values of the polynomial system
%   gm_filter                     - removes zero polynomials from Qset
%   gm_find_add                   - finds the address of mon in J
%   gm_find_conj                  - finds the index L for which lambl(L) = conj(lambrk)
%   gm_fullreduce                 - reduces all polynomials wrt each other
%   gm_generic                    - computes a generic element of K_(t,C)
%   gm_get_entries                - collects the coefficients of Q 
%   gm_getpol                     - returns a cell array containing polynomial k
%   gm_getRank                    - estimates matrix rank based on lower and upper triangular
%   gm_grobner                    - computation of the reduced Groebner basis of a set of polynomials
%   gm_grobner_basic              - calculates the reduced Groebner basis of a set of polynomials
%   gm_grobner_crit               - calculates the reduced Groebner basis of a set of polynomials
%   gm_is_contained_pair          - true if (P1,P2) is contained in B
%   gm_is_greater_mon             - true if LM > LCM
%   gm_ismember                   - true for set member
%   gm_iszero                     - returns 1 if all the coefficients of P are zero
%   gm_leading_monomials          - returns the leading monomials of gbasis
%   gm_max_deg                    - returns the maximal degree of a polynomial system
%   gm_mommat                     - computes the moment matrix Ms(y)
%   gm_mul_tab                    - multiplication table for the moment algorithm
%   gm_mult_eig                   - looks for multiple eigenvalues
%   gm_multcoef                   - multiplies the polynomial P by the real term c
%   gm_multfpol                   - multiplies the polynomials f_i by the monomials
%   gm_multiple_mon               - true if LCM is a multiple of LM
%   gm_multiplication_table       - returns the multiplication table
%   gm_multiplyterm               - multiplies the polynomial P by the monomial term
%   gm_neighbour_basis_new        - finds the neighbours of PP_basis using Jcal
%   gm_next_index                 - returns the next item in all the possible combinations
%   gm_normal_set                 - returns the normal set of the quotient ring from the Grobner basis
%   gm_null_lu                    - returns a basis of the left null space of A
%   gm_part_elim_new              - partial elimination of the variables for the rectangular matrix At
%   gm_pol_setdiff                - Set difference
%   gm_poly_normalize             - divides the polynomial P by the real term c
%   gm_poly_poly2str              - converts multivariate polynomials from cell arrays to strings
%   gm_poly_sort                  - sorts the polynomials according to the monomial order ord
%   gm_poly_str2poly              - converts multivariate polynomials from strings to arrays
%   gm_printpol                   - prints the polynomials in Poly
%   gm_putpol                     - changes the cell array containing polynomial k
%   gm_rank                       - computes the rank from the singular values sig
%   gm_reduce                     - reduces a polynomial P1 by subtracting multiples of P2 
%   gm_reduceset                  - reduces P wrt all polynomials in Pset
%   gm_remove_top_pair            - removes the first pair P of list p
%   gm_remove_top_pol             - removes the first polynomial P of list gb
%   gm_reorder_eig                - reorders the eigenvalues in lambl
%   gm_rref_polsys                - reduced row echelon form
%   gm_rSchur                     - finds the clusters of eigenvalues
%   gm_sd_round                   - rounds an array to a specified number of Significant Digits,
%   gm_solve_polsys_AS            - Auzinger and Stetter algorithm for polynomial systems
%   gm_solve_polsys_Grobner       - solves the polynomial system using a Grobner basis
%   gm_solve_polsys_Grobner_basic - solves the polynomial system using a Grobner basis
%   gm_solve_polsys_Grobner_crit  - solves the polynomial system using a Grobner basis
%   gm_solve_polsys_moment        - solves the polynomial system using the
%   gm_sort_mon_small             - returns the smallest monomial according to ord
%   gm_sort_monomial              - returns the largest monomial according to ord
%   gm_sort_pairs                 - sorts the pairs according to LCM of polynomials
%   gm_sort_pol                   - sorts the polynomial according to the monomial order ord
%   gm_SPoly                      - calculates all reduced S-polynomials of Pset (Pset must be reduced)
%   gm_SPoly_basic                - calculates all reduced S-polynomials of Pset (Pset must be reduced)
%   gm_SPolyP1P2                  - calculates the S-polynomial of P1 and P2
%   gm_str_to_defpol              - takes the output from gm_poly_strt2poly to the
%   gm_subtract                   - subtracts the 2 polynomials P1 and P2, = P1 - P2
%   mpol_remove_top_pol           - removes the first polynomial P of list gb

