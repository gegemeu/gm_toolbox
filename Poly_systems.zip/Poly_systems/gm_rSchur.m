function [US,clust,nsol]=gm_rSchur(MTr,U,T);
%GM_RSCHUR finds the clusters of eigenvalues

% Input:
% MTr = multiplication table  (matrix)
% U, T = matrices from the Schur factorization
% 
% Output:
% US = U matrix of the reordered Schur factorization
% clust = pointers on the clusters
% nsol = number of clusters

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

warning off

n = size(T,1);

% compute the left and right eigenvectors and the condition
% numbers of the eigenvalues

% caution: the eigenvalues may not be in the same order!!!!!!!!
% and moreover different in bad cases!!!!!!!!!!!!

% right eigenvectors

[Xr,Dr] = eig(MTr);

% left eigenvectors

[Xl,Dl] = eig(MTr');

lambr = diag(Dr);
lambl = diag(Dl);

% reorder the eigenvalues of the transpose

Ind = gm_reorder_eig(lambr,lambl);

lambl = lambl(Ind);
Xl = Xl(:,Ind);

condlamb = zeros(n,1);

for k = 1:n
 if abs(lambr(k) - lambl(k)) <= 1e-6 % is this useless??????
  % real eigenvalues?
  if isreal(lambr(k))
   condlamb(k) = 1 / abs(Xl(:,k)' * Xr(:,k));
  else
   % find the conjugate eigenvalue
   L = gm_find_conj(k,lambr(k),lambl);
   condlamb(k) = 1 / abs(Xl(:,L)' * Xr(:,k));
  end % if isreal
 else
  error('gm_rSchur: Problem with the eigenvectors')
 end % if
end % for k

nM = max(abs(lambr));
condlamb = eps * nM * condlamb;

% round the eigenvalues according to their conditions

roundlamb = zeros(n,1);

for k = 1:n
 dig = abs(log10(condlamb(k)));
 roundlamb(k) = gm_sd_round(lambr(k),dig,4);
end % for k

% look for clusters

clusters = zeros(n,1);
clu = 0;
for k = 1:n
 if clusters(k) == 0
  clu = clu + 1;
  lambk = roundlamb(k);
  for j = 1:n
   lambj = roundlamb(j);
   if (clusters(j) == 0) && (abs(lambk - lambj) <= 1e-15)
    clusters(j) = clu;
   end % if
  end % for j
 end % if clusters(k)
end % for k

% reorder the Schur factorization

[US,TS] = ordschur(U,T,clusters);

clusters = sort(clusters,'descend');

% pointers to each cluster

clust(1) = 1;
cval = clusters(1);
nsol = 1;

for k = 2:n
 % look for the next value
 if clusters(k) == cval
  continue
 else
  nsol = nsol + 1;
  clust(nsol) = k;
  cval = clusters(k);
 end % if
end % for k

warning on



