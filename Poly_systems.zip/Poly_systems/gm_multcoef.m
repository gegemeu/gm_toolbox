function Q=gm_multcoef(P,c);
%GM_MULTCOEF multiplies the polynomial P by the real term c

% the polynomial is assumed to be sorted 
% this is not checked

% Input:
% P = polynomial
% c = real coefficient
%
% Output:
% Q = polynomial result of the multiplication

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

Activ = P{1,1};

if Activ == 0
 Q = P;
 return
end % if Activ

Q = cell(1,4);
Q{1,1} = 1;

nT = P{1,2};
T = P{1,4};

for k = 1:nT
 T(k,1) = T(k,1) * c;
end

% number of monomials
Q{1,2} = size(T,1);

% leading term
Q{1,3} = T(1,:);

% polynomial
Q{1,4} = T;

