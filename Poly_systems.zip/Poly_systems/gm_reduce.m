function Q1=gm_reduce(P1,P2,ord,tol,varargin);
%GM_REDUCE reduces a polynomial P1 by subtracting multiples of P2 so that leading
%   term coefficient is 1 and leading term of P2 does not divide that of P1

% Input:
% P1, P2 = polynomials
% ord = ordering
% tol = ignore coefficients less than tol
% varargin = 1 reduce the leading coefficient (default)
%
% Output:
% Q1 =  reduced polynomial

%
% Author G. Meurant
% March 2010
% from a code by B. Petschel
% Updated Sept 2015
%

if nargin == 4
 red = 1;
else
 red = varargin{1};
end

if (size(P1,1) == 0)
 Q1 = {};
 return
end

if (size(P2,1) == 0)
 Q1 = P1;
 return
end

iP1 = P1{1,1};
iP2 = P2{1,1};

if (iP1 == 0)
 Q1 = P1;
 return
end

if iP2 == 0
 Q1 = P1;
 return
end

Q2 = P2;
% leading term
LT = Q2{1,3};
c2 = LT(1);
d2 = LT(2:end);

if abs(c2) <= tol
 % ignore terms less than tol
 keepgoing = false;
 Q1 = P1;
else
 keepgoing = true;
 Q2 = gm_poly_normalize(Q2,c2);
 Qz = cell(1,4);
 lead = cell(1,4);
 lead{1,1} = 1;
 lead{1,2} = 1;
 Qz{1,1} = 1;
 Qz{1,2} = 1;
 Qz{1,3} = zeros(1,size(LT,2));
 Qz{1,4} = zeros(1,size(LT,2));
 Q1 = Qz;   % will successively add terms to Q
 % remove the leading terms, in order to reduce wrt lower terms
 remain = P1;
end % if abs


while keepgoing
 
 % leading term of remain
 LT = remain{1,3};
 c1 = LT(1);
 d1 = LT(2:end);
 
 if abs(c1) <= tol
  % ignore terms less than tol
  keepgoing = false;
  
 else
  %reduce remain by Q2, if possible, or remove leading term
  
  if d1 >= d2
   % can reduce Q1 by Q2, so subtract a multiple of Q2 from Q1
   QQ = gm_multiplyterm(Q2,d1-d2);
   QQ = gm_multcoef(QQ,c1);
   remain = gm_subtract(remain,QQ,ord,tol);

  else
   % cannot reduce any further wrt leading term, but try lower terms
   lead{1,3} = LT;
   lead{1,4} = LT;
   remain = gm_subtract(remain,lead,ord,tol);
   % add irreducible terms to Q1
   Q1 = mpol_addpol(Q1,lead,ord,tol);
  end % if d1
  
 end % if abs
 
end % while

% reduce leading coefficient, if possible
if red == 1
 LT = Q1{1,3};
 c1 = LT(1);
 if c1 ~= 1
  Q1 = gm_poly_normalize(Q1,c1);
 end
end


