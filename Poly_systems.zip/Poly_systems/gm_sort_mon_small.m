function [ind,smallest_m]=gm_sort_mon_small(index,smallest_mon,j,Exp,ord);
%GM_SORT_MON_SMALL returns the smallest monomial according to ord

% Input:
% index = index so far
% smallest_mon = smallest monomial so far
% j = 
% Exp = exponent
% ord = ordering
%
% Output:
% ind = new index
% smallest_m = new smallest monomial

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%


if Exp(1) == 1000
 smallest_m = smallest_mon;
 ind = index;
 return
end

if smallest_mon(1) == 1000
 smallest_m = Exp;
 ind = j;
 return
end

switch ord
 
 case 'lex'
  % lexicographic ordering
  
  diffind = smallest_mon - Exp;
  
  indiff = find(diffind);
  
  if numel(indiff) == 0
   smallest_m = smallest_mon;
   ind = index;
   return
  end
  
  if diffind(indiff(1)) < 0
   ind = index;
   smallest_m = smallest_mon;
  else
   ind = j;
   smallest_m = Exp;
  end % if indiff
  
 case 'grlex'
  % graded lexicographic ordering
  
  slm = sum(smallest_mon);
  sexp = sum(Exp);
  if slm < sexp
   ind = index;
   smallest_m = smallest_mon;
  elseif slm > sexp
   ind = j;
   smallest_m = Exp;
  else
   diffind = smallest_mon - Exp;
   
   indiff = find(diffind);
   
   if numel(indiff) == 0
    smallest_m = smallest_mon;
    ind = index;
    return
   end
   
   if diffind(indiff(1)) < 0
    ind = index;
    smallest_m = smallest_mon;
   else
    ind = j;
    smallest_m = Exp;
   end % if indiff
   
  end % if slm
  
 case 'grevlex'
  % graded lexicographic ordering
  
  slm = sum(smallest_mon);
  sexp = sum(Exp);
  if slm < sexp
   ind = index;
   smallest_m = smallest_mon;
  elseif slm > sexp
   ind = j;
   smallest_m = Exp;
  else
   diffind = smallest_mon - Exp;
   % reverse
   diffind = diffind(end:-1:1);
   
   indiff = find(diffind);
   
   if numel(indiff) == 0
    smallest_m = smallest_mon;
    ind = index;
    return
   end
   
   if diffind(indiff(1)) > 0
    ind = index;
    smallest_m = smallest_mon;
   else
    ind = j;
    smallest_m = Exp;
   end % if indiff
   
  end % if slm
  
 otherwise
  
  error('gm_sort_mon_small: This ordering is not implemented')
  
end % switch

