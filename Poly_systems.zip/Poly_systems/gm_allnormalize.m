function Qset=gm_allnormalize(Q);
%GM_ALLNORMALIZE normalizes all the polynomials in Q

% Input:
% Q = set of polynomials
%
% Output:
% Qset = normalized set of polynomials

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(Q,1);

Qset = {};

for k = 1:npol
 P = gm_getpol(Q,k);

 % leading term
 LT = P{1,3};
 c = LT(1,1);
 P = gm_poly_normalize(P,c);
 
 Qset = gm_putpol(Qset,P,k);
 
end % for k

