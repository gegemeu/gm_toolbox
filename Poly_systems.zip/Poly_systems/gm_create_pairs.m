function pairs=gm_create_pairs(gb,ord);
%GM_CREATE_PAIRS creates the "pairs" object from the basis gb

% a "pair" is the LCM and two polynomials from gb
% The pairs are sorted according to the LCM for the order ord
% the polynomials in gb are assumed to be sorted

% Input:
% gb = gb
% ord = ordering
%
% Output:
% pairs = see above

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

pairs = {};

ip = 0;
for i = 1:size(gb,1)-1
 
 for j = i+1:size(gb,1)
  LT1 = gb{i,3};
  d1 = LT1(1,2:end);
  LT2 = gb{j,3};
  d2 = LT2(1,2:end);
  L = max(d1,d2); % LCM of leading terms
  
  Q1 = gm_getpol(gb,j);
  Q2 = gm_getpol(gb,i);
  
  ip = ip + 1;
  pairs{ip,1} = L;
  pairs{ip,2} = Q1;
  pairs{ip,3} = Q2;
  
  ip = ip + 1;
  pairs{ip,1} = L;
  pairs{ip,2} = Q2;
  pairs{ip,3} = Q1;
  
 end % j
 
end % i

% sort the LCMs

pairs = gm_sort_pairs(pairs,ord);


