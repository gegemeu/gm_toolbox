function Pset=gm_defpol_to_poly(fpol,addpol,ord,tol);
%GM_DEFPOL_TO_POLY translates from defpol to mpol format (for Grobner)

% Input:
% defpol = list of polynomials
% addpol = adresses of polynomials in the list)
% ord = ordering
% tol = coefficient tolerance
%
% Output:
% Pset = polynomials in definition suited for Grobner

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% number of polynomials
npol = size(addpol) - 1;
nmon = size(fpol{1,2},2);

Pset = {};

for k = 1:npol
 start = addpol(k);
 endd = addpol(k+1) - 1;
 
 P = zeros(endd-start+1,nmon+1);
 
 ip = 0;
 for j = start:endd
  ip = ip + 1;
  P(ip,2:end) = fpol{j,2};
  P(ip,1) = fpol{j,3};
 end % for j
 
 % this is not true but we will sort later
 leadt = P(1,:);
 Pset{k,1} = 1;
 Pset{k,2} = size(P,1);
 Pset{k,3} = leadt;
 Pset{k,4} = P;
 
end % for k

% sort the polynomials

Pset = gm_sort_pol(Pset,ord,tol);

