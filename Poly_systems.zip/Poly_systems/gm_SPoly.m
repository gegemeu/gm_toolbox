function [Qset,spol]=gm_SPoly(Pset,ord,tol,spol);
%GM_SPOLY calculates all reduced S-polynomials of Pset (Pset must be reduced)

%   Sij = (Lij/ai)*Pi - (Lij/aj)*Pj,
% for all pairs of polynomials Pi, Pj, where ai and aj are the leading
% terms of Pi and Pj, and Lij is the least common multiple of ai and aj
% then reduces Sij wrt Pset

% Input:
% Pset = set of polynomials
% ord = ordering
% tol = tolerance for the coefficients
% spol = number of reduced polynomials so far
%
% Output:
% Qset = reduced S - polynomials
% spol = updated number of reduced polynomials 

%
% Author G. Meurant
% March 2010
% from a code by B. Petschel
% Updated Sept 2015
%

Qset = {};

for i = 1:size(Pset,1)-1
 
 for j = i+1:size(Pset,1)
  LT1 = Pset{i,3};
  d1 = LT1(1,2:end);
  
  LT2 = Pset{j,3};
  d2 = LT2(1,2:end);
  
  if any(and(d1 > 0,d2 > 0))
   spol = spol + 1;
   % Buchberger's first criteria:
   % leading terms have a variable in common, so S-poly is nontrivial
   L = max(d1,d2); % LCM of leading terms
   Q1 = gm_getpol(Pset,j);
   Q1 = gm_multiplyterm(Q1,L-d2,ord);
   Q2 = gm_getpol(Pset,i);
   Q2 = gm_multiplyterm(Q2,L-d1,ord);
   S = gm_subtract(Q2,Q1,ord,tol);
   S = gm_reduceset(S,Pset,ord,tol);
   % is S reduced to zero?
   izero = gm_iszero(S,tol);
   
   if ~izero
    % add S to the list
    Qset = gm_append(S,Qset);
   end % if izero
   
  end % if any(and
  
 end % j
 
end % i

