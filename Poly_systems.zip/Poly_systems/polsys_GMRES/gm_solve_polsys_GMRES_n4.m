function [xsol,val_sol,xxsol]=gm_solve_polsys_GMRES_n4(A);
%GM_SOLVE_POLSYS_GMRES_N4 solves the polynomial real stagnation system for GMRES for
% n=4

% This code can only compute real solutions
% Ad hoc algorithm

% For n > 4, use gm_solve_polsys_GMRES

% Input:
% A = matrix
%
% Output:
% xsol = real solutions
% val_sol = values of the polynomials at the solutions
% xxsol = all solutions

%
% Author G. Meurant
% April 2010
% Updated Sept 2015
%

n = size(A,1);

if n ~= 4
 error('gm_solve_polsys_n4: The matrix A must be of order 4')
end

xsol = [];
xxsol = [];
val_sol = [];

% define the polynomial system corresponding to A

% this definition uses norm(b) = 1
% with diagonalization
[fpol,addpol,Mnu] = gm_polsys_elim(A);

% get the coefficients alpha of the diagonalized system

Alpha = zeros(4,7);

for k =1:4
 add = addpol(k);
 jj = 0;
 for j = add+1:addpol(k+1)-1
  jj = jj + 1;
  Alpha(k,jj) = fpol{j,3};
 end % for j
end % for k

A12 = eye(12,12);

A12(1,4) = Alpha(1,1);
A12(1,5) = Alpha(1,4);
A12(1,6) = Alpha(1,5);

A12(2,7) = Alpha(1,2);
A12(2,8) = Alpha(1,4);
A12(2,9) = Alpha(1,6);

A12(3,10) = Alpha(1,3);
A12(3,11) = Alpha(1,5);
A12(3,12) = Alpha(1,6);

A12(4,1) = Alpha(2,1);
A12(4,2) = Alpha(2,2);
A12(4,3) = Alpha(2,3);

A12(5,7) = Alpha(2,2);
A12(5,8) = Alpha(2,4);
A12(5,9) = Alpha(2,6);

A12(6,10) = Alpha(2,3);
A12(6,11) = Alpha(2,5);
A12(6,12) = Alpha(2,6);

A12(7,1) = Alpha(3,1);
A12(7,2) = Alpha(3,2);
A12(7,3) = Alpha(3,3);

A12(8,4) = Alpha(3,1);
A12(8,5) = Alpha(3,4);
A12(8,6) = Alpha(3,5);

A12(9,10) = Alpha(3,3);
A12(9,11) = Alpha(3,5);
A12(9,12) = Alpha(3,6);

A12(10,1) = Alpha(4,1);
A12(10,2) = Alpha(4,2);
A12(10,3) = Alpha(4,3);

A12(11,4) = Alpha(4,1);
A12(11,5) = Alpha(4,4);
A12(11,6) = Alpha(4,5);

A12(12,7) = Alpha(4,2);
A12(12,8) = Alpha(4,4);
A12(12,9) = Alpha(4,6);

Beta = zeros(12,1);

B1 = -[Alpha(1,2); Alpha(1,1); 0; Alpha(2,4); Alpha(2,1); 0; Alpha(3,4); Alpha(3,2); 0; Alpha(4,4); Alpha(4,2); Alpha(4,1)];

B2 = -[Alpha(1,3); 0; Alpha(1,1); Alpha(2,5); 0; Alpha(2,1); Alpha(3,5); Alpha(3,3); Alpha(3,1); Alpha(4,5); Alpha(4,3); 0];

B3 = -[0; Alpha(1,3); Alpha(1,2); Alpha(2,6); Alpha(2,3); Alpha(2,2); Alpha(3,6); 0; Alpha(3,2); Alpha(4,6); 0; Alpha(4,3)];

B4 = -[Alpha(1,6); Alpha(1,5); Alpha(1,4); 0; Alpha(2,5); Alpha(2,4); 0; Alpha(3,6); Alpha(3,4); 0; Alpha(4,6); Alpha(4,5)];

B5 = -[0; 0; 0; Alpha(2,7); 0; 0; Alpha(3,7); 0; 0; Alpha(4,7); 0; 0];

B6 = -[Alpha(1,7); 0; 0; 0; 0; 0; 0; Alpha(3,7); 0; 0; Alpha(4,7); 0];

B7 = -[0; Alpha(1,7); 0; 0; Alpha(2,7); 0; 0; 0; 0; 0; 0; Alpha(4,7)];

B8 = -[0; 0; Alpha(1,7); 0; 0; Alpha(2,7); 0; 0; Alpha(3,7); 0; 0; 0];

Beta = A12 \ [B1 B2 B3 B4 B5 B6 B7 B8];

A12 = eye(12,12);

A12(1,7) = -Beta(1,1);
A12(1,8) = -Beta(1,3);
A12(1,9) = -Beta(1,4);

A12(2,4) = -Beta(3,1);
A12(2,5) = -Beta(3,2);
A12(2,6) = -Beta(3,4);

A12(3,10) = -Beta(2,2);
A12(3,11) = -Beta(2,3);
A12(3,12) = -Beta(2,4);

A12(4,1) = -Beta(5,1);
A12(4,2) = -Beta(5,2);
A12(4,3) = -Beta(5,3);

A12(5,10) = -Beta(4,2);
A12(5,11) = -Beta(4,3);
A12(5,12) = -Beta(4,4);

A12(6,7) = -Beta(6,1);
A12(6,8) = -Beta(6,3);
A12(6,9) = -Beta(6,4);

A12(7,1) = -Beta(8,1);
A12(7,2) = -Beta(8,2);
A12(7,3) = -Beta(8,3);

A12(8,10) = -Beta(7,2);
A12(8,11) = -Beta(7,3);
A12(8,12) = -Beta(7,4);

A12(9,4) = -Beta(9,1);
A12(9,5) = -Beta(9,2);
A12(9,6) = -Beta(9,4);

A12(10,1) = -Beta(11,1);
A12(10,2) = -Beta(11,2);
A12(10,3) = -Beta(11,3);

A12(11,7) = -Beta(10,1);
A12(11,8) = -Beta(10,3);
A12(11,9) = -Beta(10,4);

A12(12,4) = -Beta(12,1);
A12(12,5) = -Beta(12,2);
A12(12,6) = -Beta(12,4);

G = zeros(12,8);

G(1,1) = Beta(1,2);
G(2,1) = Beta(3,3);
G(3,1) = Beta(2,1);
G(4,1) = Beta(5,4);
G(5,1) = Beta(4,1);
G(6,1) = Beta(6,2);
G(7,1) = Beta(8,4);
G(8,1) = Beta(7,1);
G(9,1) = Beta(9,3);
G(10,1) = Beta(11,4);
G(11,1) = Beta(10,2);
G(12,1) = Beta(12,3);

G(1,2) = -Beta(1,7) * Alpha(3,1);
G(2,2) = Beta(3,5) - Beta(3,6) * Alpha(2,1);
G(3,2) = -Beta(2,8) * Alpha(4,1);
G(4,2) = Beta(5,6) - Beta(5,5) * Alpha(1,1);
G(5,2) = -Beta(4,8) * Alpha(4,1);
G(6,2) = -Beta(6,7) * Alpha(3,1);
G(7,2) = Beta(8,6) - Beta(8,5) * Alpha(1,1);
G(8,2) = -Beta(7,8) * Alpha(4,1);
G(9,2) = Beta(9,5) - Beta(9,6) * Alpha(2,1);
G(10,2) = Beta(11,6) - Beta(11,5) * Alpha(1,1);
G(11,2) = -Beta(10,7) * Alpha(3,1);
G(12,2) = Beta(12,5) - Beta(12,6) * Alpha(2,1);

G(1,3) = Beta(1,5) - Beta(1,7) * Alpha(3,2);
G(2,3) = -Beta(3,6) * Alpha(2,2);
G(3,3) = -Beta(2,8) * Alpha(4,2);
G(4,3) = Beta(5,7) - Beta(5,5) * Alpha(1,2);
G(5,3) = -Beta(4,8) * Alpha(4,2);
G(6,3) = Beta(6,5) - Beta(6,7) * Alpha(3,2);
G(7,3) = Beta(8,7) - Beta(8,5) * Alpha(1,2);
G(8,3) = -Beta(7,8) * Alpha(4,2);
G(9,3) = -Beta(9,6) * Alpha(2,2);
G(10,3) = Beta(11,7) - Beta(11,5) * Alpha(1,2);
G(11,3) = Beta(10,5) - Beta(10,7) * Alpha(3,2);
G(12,3) = -Beta(12,6) * Alpha(2,2);

G(1,4) = -Beta(1,7) * Alpha(3,3);
G(2,4) = -Beta(3,6) * Alpha(2,3);
G(3,4) = Beta(2,5) - Beta(2,8) * Alpha(4,3);
G(4,4) = Beta(5,8) - Beta(5,5) * Alpha(1,3);
G(5,4) = Beta(4,5) - Beta(4,8) * Alpha(4,3);
G(6,4) = -Beta(6,7) * Alpha(3,3);
G(7,4) = Beta(8,8) - Beta(8,5) * Alpha(1,3);
G(8,4) = Beta(7,5) - Beta(7,8) * Alpha(4,3);
G(9,4) = -Beta(9,6) * Alpha(2,3);
G(10,4) = Beta(11,8) - Beta(11,5) * Alpha(1,3);
G(11,4) = -Beta(10,7) * Alpha(3,3);
G(12,4) = -Beta(12,6) * Alpha(2,3);

G(1,5) = Beta(1,6) - Beta(1,7) * Alpha(3,4);
G(2,5) = Beta(3,7) - Beta(3,6) * Alpha(2,4);
G(3,5) = -Beta(2,8) * Alpha(4,4);
G(4,5) = -Beta(5,5) * Alpha(1,4);
G(5,5) = -Beta(4,8) * Alpha(4,4);
G(6,5) = Beta(6,6) - Beta(6,7) * Alpha(3,4);
G(7,5) = -Beta(8,5) * Alpha(1,4);
G(8,5) = -Beta(7,8) * Alpha(4,4);
G(9,5) = Beta(9,7) - Beta(9,6) * Alpha(2,4);
G(10,5) = -Beta(11,5) * Alpha(1,4);
G(11,5) = Beta(10,6) - Beta(10,7) * Alpha(3,4);
G(12,5) = Beta(12,7) - Beta(12,6) * Alpha(2,4);

G(1,6) = -Beta(1,7) * Alpha(3,5);
G(2,6) = Beta(3,8) - Beta(3,6) * Alpha(2,5);
G(3,6) = Beta(2,6) - Beta(2,8) * Alpha(4,5);
G(4,6) = -Beta(5,5) * Alpha(1,5);
G(5,6) = Beta(4,6) - Beta(4,8) * Alpha(4,5);
G(6,6) = -Beta(6,7) * Alpha(3,5);
G(7,6) = -Beta(8,5) * Alpha(1,5);
G(8,6) = Beta(7,6) - Beta(7,8) * Alpha(4,5);
G(9,6) = Beta(9,8) - Beta(9,6) * Alpha(2,5);
G(10,6) = -Beta(11,5) * Alpha(1,5);
G(11,6) = -Beta(10,7) * Alpha(3,5);
G(12,6) = Beta(12,8) - Beta(12,6) * Alpha(2,5);

G(1,7) = Beta(1,8) - Beta(1,7) * Alpha(3,6);
G(2,7) = -Beta(3,6) * Alpha(2,6);
G(3,7) = Beta(2,7) - Beta(2,8) * Alpha(4,6);
G(4,7) = -Beta(5,5) * Alpha(1,6);
G(5,7) = Beta(4,7) - Beta(4,8) * Alpha(4,6);
G(6,7) = Beta(6,8) - Beta(6,7) * Alpha(3,6);
G(7,7) = -Beta(8,5) * Alpha(1,6);
G(8,7) = Beta(7,7) - Beta(7,8) * Alpha(4,6);
G(9,7) = -Beta(9,6) * Alpha(2,6);
G(10,7) = -Beta(11,5) * Alpha(1,6);
G(11,7) = Beta(10,8) - Beta(10,7) * Alpha(3,6);
G(12,7) = -Beta(12,6) * Alpha(2,6);

G(1,8) = -Beta(1,7) * Alpha(3,7);
G(2,8) = -Beta(3,6) * Alpha(2,7);
G(3,8) = -Beta(2,8) * Alpha(4,7);
G(4,8) = -Beta(5,5) * Alpha(1,7);
G(5,8) = -Beta(4,8) * Alpha(4,7);
G(6,8) = -Beta(6,7) * Alpha(3,7);
G(7,8) = -Beta(8,5) * Alpha(1,7);
G(8,8) = -Beta(7,8) * Alpha(4,7);
G(9,8) = -Beta(9,6) * Alpha(2,7);
G(10,8) = -Beta(11,5) * Alpha(1,7);
G(11,8) = -Beta(10,7) * Alpha(3,7);
G(12,8) = -Beta(12,6) * Alpha(2,7);

Delta = zeros(12,8);

Delta = A12 \ G;

A4 = eye(4,4);

A4(1,4) = -Delta(1,1);
A4(2,3) = -Delta(5,1);
A4(3,2) = -Delta(8,1);
A4(4,1) = -Delta(12,1);

H = zeros(4,8);

H(1,1) = Delta(1,4) * Beta(10,1) + Delta(1,6) * Beta(11,1) + Delta(1,7) * Beta(12,1);
H(2,1) = Delta(5,2) + Delta(5,3) * Beta(7,1) + Delta(5,5) * Beta(8,1) + Delta(5,7) * Beta(9,1);
H(3,1) = Delta(8,3) + Delta(8,2) * Beta(4,1) + Delta(8,5) * Beta(5,1) + Delta(8,6) * Beta(6,1);
H(4,1) = Delta(12,5) + Delta(12,2) * Beta(1,1) + Delta(12,3) * Beta(2,1) + Delta(12,4) * Beta(3,1);

H(1,2) = Delta(1,2) + Delta(1,4) * Beta(10,2) + Delta(1,6) * Beta(11,2) + Delta(1,7) * Beta(12,2);
H(2,2) = Delta(5,3) * Beta(7,2) + Delta(5,5) * Beta(8,2) + Delta(5,7) * Beta(9,2);
H(3,2) = Delta(8,4) + Delta(8,2) * Beta(4,2) + Delta(8,5) * Beta(5,2) + Delta(8,6) * Beta(6,2);
H(4,2) = Delta(12,6) + Delta(12,2) * Beta(1,2) + Delta(12,3) * Beta(2,2) + Delta(12,4) * Beta(3,2);

H(1,3) = Delta(1,3) + Delta(1,4) * Beta(10,3) + Delta(1,6) * Beta(11,3) + Delta(1,7) * Beta(12,3);
H(2,3) = Delta(5,4) + Delta(5,3) * Beta(7,3) + Delta(5,5) * Beta(8,3) + Delta(5,7) * Beta(9,3);
H(3,3) = Delta(8,2) * Beta(4,3) + Delta(8,5) * Beta(5,3) + Delta(8,6) * Beta(6,3);
H(4,3) = Delta(12,7) + Delta(12,2) * Beta(1,3) + Delta(12,3) * Beta(2,3) + Delta(12,4) * Beta(3,3);

H(1,4) = Delta(1,5) + Delta(1,4) * Beta(10,4) + Delta(1,6) * Beta(11,4) + Delta(1,7) * Beta(12,4);
H(2,4) = Delta(5,6) + Delta(5,3) * Beta(7,4) + Delta(5,5) * Beta(8,4) + Delta(5,7) * Beta(9,4);
H(3,4) = Delta(8,7) + Delta(8,2) * Beta(4,4) + Delta(8,5) * Beta(5,4) + Delta(8,6) * Beta(6,4);
H(4,4) = Delta(12,2) * Beta(1,4) + Delta(12,3) * Beta(2,4) + Delta(12,4) * Beta(3,4);

H(1,5) = Delta(1,4) * Beta(10,5) + Delta(1,6) * Beta(11,5) + Delta(1,7) * Beta(12,5);
H(2,5) = Delta(5,3) * Beta(7,5) + Delta(5,5) * Beta(8,5) + Delta(5,7) * Beta(9,5);
H(3,5) = Delta(8,2) * Beta(4,5) + Delta(8,5) * Beta(5,5) + Delta(8,6) * Beta(6,5);
H(4,5) = Delta(12,8) + Delta(12,2) * Beta(1,5) + Delta(12,3) * Beta(2,5) + Delta(12,4) * Beta(3,5);

H(1,6) = Delta(1,4) * Beta(10,6) + Delta(1,6) * Beta(11,6) + Delta(1,7) * Beta(12,6);
H(2,6) = Delta(5,3) * Beta(7,6) + Delta(5,5) * Beta(8,6) + Delta(5,7) * Beta(9,6);
H(3,6) = Delta(8,8) + Delta(8,2) * Beta(4,6) + Delta(8,5) * Beta(5,6) + Delta(8,6) * Beta(6,6);
H(4,6) = Delta(12,2) * Beta(1,6) + Delta(12,3) * Beta(2,6) + Delta(12,4) * Beta(3,6);

H(1,7) = Delta(1,4) * Beta(10,7) + Delta(1,6) * Beta(11,7) + Delta(1,7) * Beta(12,7);
H(2,7) = Delta(5,8) + Delta(5,3) * Beta(7,7) + Delta(5,5) * Beta(8,7) + Delta(5,7) * Beta(9,7);
H(3,7) = Delta(8,2) * Beta(4,7) + Delta(8,5) * Beta(5,7) + Delta(8,6) * Beta(6,7);
H(4,7) = Delta(12,2) * Beta(1,7) + Delta(12,3) * Beta(2,7) + Delta(12,4) * Beta(3,7);

H(1,8) = Delta(1,8) + Delta(1,4) * Beta(10,8) + Delta(1,6) * Beta(11,8) + Delta(1,7) * Beta(12,8);
H(2,8) = Delta(5,3) * Beta(7,8) + Delta(5,5) * Beta(8,8) + Delta(5,7) * Beta(9,8);
H(3,8) = Delta(8,2) * Beta(4,8) + Delta(8,5) * Beta(5,8) + Delta(8,6) * Beta(6,8);
H(4,8) = Delta(12,2) * Beta(1,8) + Delta(12,3) * Beta(2,8) + Delta(12,4) * Beta(3,8);

Gama = A4 \ H;

% Multiplication tables

Mx = zeros(16,16);

Mx(2,1) = -Alpha(1,7);
Mx(12,1) = Delta(1,8);
Mx(13,1) = Delta(2,8);
Mx(14,1) = Delta(3,8);
Mx(1,2) = 1;
Mx(6,2) = Beta(1,5);
Mx(7,2) = Beta(2,5);
Mx(8,2) = Beta(3,5);
Mx(16,2) = Gama(1,5);
Mx(6,3) = Beta(1,6);
Mx(7,3) = Beta(2,6);
Mx(8,3) = Beta(3,6);
Mx(16,3) = Gama(1,6);
Mx(6,4) = Beta(1,7);
Mx(7,4) = Beta(2,7);
Mx(8,4) = Beta(3,7);
Mx(16,4) = Gama(1,7);
Mx(6,5) = Beta(1,8);
Mx(7,5) = Beta(2,8);
Mx(8,5) = Beta(3,8);
Mx(16,5) = Gama(1,8);
Mx(2,6) =  -Alpha(1,1);
Mx(3,6) = 1;
Mx(12,6) = Delta(1,2);
Mx(13,6) = Delta(2,2);
Mx(14,6) = Delta(3,2);
Mx(2,7) =  -Alpha(1,2);
Mx(4,7) = 1;
Mx(12,7) = Delta(1,3);
Mx(13,7) = Delta(2,3);
Mx(14,7) = Delta(3,3);
Mx(2,8) =  -Alpha(1,3);
Mx(5,8) = 1;
Mx(12,8) = Delta(1,4);
Mx(13,8) = Delta(2,4);
Mx(14,8) = Delta(3,4);
Mx(2,9) =  -Alpha(1,4);
Mx(12,9) = Delta(1,5);
Mx(13,9) = Delta(2,5);
Mx(14,9) = Delta(3,5);
Mx(2,10) =  -Alpha(1,5);
Mx(12,10) = Delta(1,6);
Mx(13,10) = Delta(2,6);
Mx(14,10) = Delta(3,6);
Mx(2,11) =  -Alpha(1,6);
Mx(12,11) = Delta(1,7);
Mx(13,11) = Delta(2,7);
Mx(14,11) = Delta(3,7);
Mx(6,12) = Beta(1,1);
Mx(7,12) = Beta(2,1);
Mx(8,12) = Beta(3,1);
Mx(9,12) = 1;
Mx(16,12) = Gama(1,1);
Mx(6,13) = Beta(1,2);
Mx(7,13) = Beta(2,2);
Mx(8,13) = Beta(3,2);
Mx(10,13) = 1;
Mx(16,13) = Gama(1,2);
Mx(6,14) = Beta(1,3);
Mx(7,14) = Beta(2,3);
Mx(8,14) = Beta(3,3);
Mx(11,14) = 1;
Mx(16,14) = Gama(1,3);
Mx(6,15) = Beta(1,4);
Mx(7,15) = Beta(2,4);
Mx(8,15) = Beta(3,4);
Mx(16,15) = Gama(1,4);
Mx(12,16) = Delta(1,1);
Mx(13,16) = Delta(2,1);
Mx(14,16) = Delta(3,1);
Mx(15,16) = 1;

MTab{1} = Mx;

My = zeros(16,16);

My(3,1) = -Alpha(2,7);
My(12,1) = Delta(4,8);
My(13,1) = Delta(5,8);
My(15,1) = Delta(6,8);
My(6,2) = Beta(4,5);
My(9,2) = Beta(5,5);
My(10,2) = Beta(6,5);
My(16,2) = Gama(2,5);
My(1,3) = 1;
My(6,3) = Beta(4,6);
My(9,3) = Beta(5,6);
My(10,3) = Beta(6,6);
My(16,3) = Gama(2,6);
My(6,4) = Beta(4,7);
My(9,4) = Beta(5,7);
My(10,4) = Beta(6,7);
My(16,4) = Gama(2,7);
My(6,5) = Beta(4,8);
My(9,5) = Beta(5,8);
My(10,5) = Beta(6,8);
My(16,5) = Gama(2,8);
My(2,6) = 1;
My(3,6) = -Alpha(2,1);
My(12,6) = Delta(4,2);
My(13,6) = Delta(5,2);
My(15,6) = Delta(6,2);
My(3,7) =  -Alpha(2,2);
My(12,7) = Delta(4,3);
My(13,7) = Delta(5,3);
My(15,7) = Delta(6,3);
My(3,8) = -Alpha(2,3);
My(12,8) = Delta(4,4);
My(13,8) = Delta(5,4);
My(15,8) = Delta(6,4);
My(3,9) = -Alpha(2,4);
My(4,9) = 1;
My(12,9) = Delta(4,5);
My(13,9) = Delta(5,5);
My(15,9) = Delta(6,5);
My(3,10) = -Alpha(2,5);
My(5,10) = 1;
My(12,10) = Delta(4,6);
My(13,10) = Delta(5,6);
My(15,10) = Delta(6,6);
My(3,11) = -Alpha(2,6);
My(12,11) = Delta(4,7);
My(13,11) = Delta(5,7);
My(15,11) = Delta(6,7);
My(6,12) = Beta(4,1);
My(7,12) = 1;
My(9,12) = Beta(5,1);
My(10,12) = Beta(6,1);
My(16,12) = Gama(2,1);
My(6,13) = Beta(4,2);
My(8,13) = 1;
My(9,13) = Beta(5,2);
My(10,13) = Beta(6,2);
My(16,13) = Gama(2,2);
My(6,14) = Beta(4,3);
My(9,14) = Beta(5,3);
My(10,14) = Beta(6,3);
My(16,14) = Gama(2,3);
My(6,15) = Beta(4,4);
My(9,15) = Beta(5,4);
My(10,15) = Beta(6,4);
My(11,15) = 1;
My(16,15) = Gama(2,4);
My(12,16) = Delta(4,1);
My(13,16) = Delta(5,1);
My(14,16) = 1;
My(15,16) = Delta(6,1);

MTab{2} = My;

Mz = zeros(16,16);

Mz(4,1) = -Alpha(3,7);
Mz(12,1) = Delta(7,8);
Mz(14,1) = Delta(8,8);
Mz(15,1) = Delta(9,8);
Mz(7,2) = Beta(7,5);
Mz(9,2) = Beta(8,5);
Mz(11,2) = Beta(9,5);
Mz(16,2) = Gama(3,5);
Mz(7,3) = Beta(7,6);
Mz(9,3) = Beta(8,6);
Mz(11,3) = Beta(9,6);
Mz(16,3) = Gama(3,6);
Mz(1,4) = 1;
Mz(7,4) = Beta(7,7);
Mz(9,4) = Beta(8,7);
Mz(11,4) = Beta(9,7);
Mz(16,4) = Gama(3,7);
Mz(7,5) = Beta(7,8);
Mz(9,5) = Beta(8,8);
Mz(11,5) = Beta(9,8);
Mz(16,5) = Gama(3,8);
Mz(4,6) = -Alpha(3,1);
Mz(12,6) = Delta(7,2);
Mz(14,6) = Delta(8,2);
Mz(15,6) = Delta(9,2);
Mz(2,7) = 1;
Mz(4,7) =  -Alpha(3,2);
Mz(12,7) = Delta(7,3);
Mz(14,7) = Delta(8,3);
Mz(15,7) = Delta(9,3);
Mz(4,8) = -Alpha(3,3);
Mz(12,8) = Delta(7,4);
Mz(14,8) = Delta(8,4);
Mz(15,8) = Delta(9,4);
Mz(3,9) = 1;
Mz(4,9) = -Alpha(3,4);
Mz(12,9) = Delta(7,5);
Mz(14,9) = Delta(8,5);
Mz(15,9) = Delta(9,5);
Mz(4,10) = -Alpha(3,5);
Mz(12,10) = Delta(7,6);
Mz(14,10) = Delta(8,6);
Mz(15,10) = Delta(9,6);
Mz(4,11) = -Alpha(3,6);
Mz(5,11) = 1;
Mz(12,11) = Delta(7,7);
Mz(14,11) = Delta(8,7);
Mz(15,11) = Delta(9,7);
Mz(6,12) = 1;
Mz(7,12) = Beta(7,1);
Mz(9,12) = Beta(8,1);
Mz(11,12) = Beta(9,1);
Mz(16,12) = Gama(3,1);
Mz(7,13) = Beta(7,2);
Mz(9,13) = Beta(8,2);
Mz(11,13) = Beta(9,2);
Mz(16,13) = Gama(3,2);
Mz(7,14) = Beta(7,3);
Mz(8,14) = 1;
Mz(9,14) = Beta(8,3);
Mz(11,14) = Beta(9,3);
Mz(16,14) = Gama(3,3);
Mz(7,15) = Beta(7,4);
Mz(9,15) = Beta(8,4);
Mz(10,15) = 1;
Mz(11,15) = Beta(9,4);
Mz(16,15) = Gama(3,4);
Mz(12,16) = Delta(7,1);
Mz(13,16) = 1;
Mz(14,16) = Delta(8,1);
Mz(15,16) = Delta(9,1);

MTab{3} = Mz;

Mt = zeros(16,16);

Mt(5,1) = -Alpha(4,7);
Mt(13,1) = Delta(10,8);
Mt(14,1) = Delta(11,8);
Mt(15,1) = Delta(12,8);
Mt(8,2) = Beta(10,5);
Mt(10,2) = Beta(11,5);
Mt(11,2) = Beta(12,5);
Mt(16,2) = Gama(4,5);
Mt(8,3) = Beta(10,6);
Mt(10,3) = Beta(11,6);
Mt(11,3) = Beta(12,6);
Mt(16,3) = Gama(4,6);
Mt(8,4) = Beta(10,7);
Mt(10,4) = Beta(11,7);
Mt(11,4) = Beta(12,7);
Mt(16,4) = Gama(4,7);
Mt(1,5) = 1;
Mt(8,5) = Beta(10,8);
Mt(10,5) = Beta(11,8);
Mt(11,5) = Beta(12,8);
Mt(16,5) = Gama(4,8);
Mt(5,6) = -Alpha(4,1);
Mt(13,6) = Delta(10,2);
Mt(14,6) = Delta(11,2);
Mt(15,6) = Delta(12,2);
Mt(5,7) = -Alpha(4,2);
Mt(13,7) = Delta(10,3);
Mt(14,7) = Delta(11,3);
Mt(15,7) = Delta(12,3);
Mt(2,8) = 1;
Mt(5,8) = -Alpha(4,3);
Mt(13,8) = Delta(10,4);
Mt(14,8) = Delta(11,4);
Mt(15,8) = Delta(12,4);
Mt(5,9) = -Alpha(4,4);
Mt(13,9) = Delta(10,5);
Mt(14,9) = Delta(11,5);
Mt(15,9) = Delta(12,5);
Mt(3,10) = 1;
Mt(5,10) = -Alpha(4,5);
Mt(13,10) = Delta(10,6);
Mt(14,10) = Delta(11,6);
Mt(15,10) = Delta(12,6);
Mt(4,11) = 1;
Mt(5,11) = -Alpha(4,6);
Mt(13,11) = Delta(10,7);
Mt(14,11) = Delta(11,7);
Mt(15,11) = Delta(12,7);
Mt(8,12) = Beta(10,1);
Mt(10,12) = Beta(11,1);
Mt(11,12) = Beta(12,1);
Mt(16,12) = Gama(4,1);
Mt(6,13) = 1;
Mt(8,13) = Beta(10,2);
Mt(10,13) = Beta(11,2);
Mt(11,13) = Beta(12,2);
Mt(16,13) = Gama(4,2);
Mt(7,14) = 1;
Mt(8,14) = Beta(10,3);
Mt(10,14) = Beta(11,3);
Mt(11,14) = Beta(12,3);
Mt(16,14) = Gama(4,3);
Mt(8,15) = Beta(10,4);
Mt(9,15) = 1;
Mt(10,15) = Beta(11,4);
Mt(11,15) = Beta(12,4);
Mt(16,15) = Gama(4,4);
Mt(12,16) = 1;
Mt(13,16) = Delta(10,1);
Mt(14,16) = Delta(11,1);
Mt(15,16) = Delta(12,1);

MTab{4} = Mt;

% compute the solution from multiplication tables

xxsol = mpol_comp_sol(MTab);

ireal = 0;
for j = 1:size(xxsol,2)
 if norm(imag(xxsol(:,j))) < 1e-14
  ireal = ireal + 1;
  xsol(:,ireal) = real(xxsol(:,j));
 end
end

if size(xsol,2) == 0
 return
end

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) > 1e-5
  xsol = [];
  val_sol = [];
  return
 end
end % for k



