function xsol=gm_comp_sol(MTab);
%GM_COMP_SOL computes the solutions from the multiplication tables

% Input:
% MTab = multiplication tables
%
% Output:
% xsol = solutions

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

nvar = size(MTab,2);

ra = rand(1,nvar);
sra = sum(ra);
ra = ra ./ sra;

% compute a generic matrix from the MTs

MT = MTab{1};
MTr = ra(1) * MT;
for k = 2:nvar
 MT = MTab{k};
 MTr = MTr + ra(k) * MT;
end % for k

% Schur factorization

[U,T] = schur(MTr,'complex');

% look for multiple eigenvalues

lamb = diag(T);
multlamb = gm_mult_eig(lamb);

if multlamb == 0
 
 for k = 1:nvar
  MT = MTab{k};
  UTU = U' * MT * U;
  
  comp = diag(UTU);
  
  xsol(k,:) = comp';
  
 end % for k
 
else
 
 % there are multiple eigenvalues
 % reorder the Schur factorization
 
 [U,clust,nclu] = gm_rSchur(MTr,U,T);
 
 clust(nclu+1) = clust(nclu) + 1;
 
 % look at the clusters
 
 for k = 1:nvar
  MT = MTab{k};
  UTU = U' * MT * U;
  
  comp = diag(UTU);
  
  % average the eigenvalues in clusters
  
  compa = comp;
  
  for j = 1:nclu
   sclu = clust(j+1) - clust(j);
   av = sum(comp(clust(j):clust(j+1)-1)) / sclu;
   compa(clust(j):clust(j+1)-1) = av;
  end % for j
  
  xsol(k,:) = compa';
  
 end % for k
 
end % if multlamb

