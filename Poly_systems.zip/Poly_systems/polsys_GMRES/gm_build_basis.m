function J=gm_build_basis(n);
%GM_BUILD_BASIS constructs a basis of monomials for the quotient space
% of the GMRES real stagnation problem

% Input:
% n = order of the matrix
%
% Output:
% J = basis

%
% Author G. Meurant
% May 2010
% Updated Sept 2015
%

up = 1;

next = zeros(1,n);

J = next;

% keep only the tuples with exponent <= 1

sJtot = 1;
while sum(next) <= n && next(1) <= 1
 
 % add 1 to the last element and propagates the carries to the left
 next(n) = next(n) + 1;
 for k=n:-1:2
  if next(k) > up
   next(k) = 0;
   next(k-1) = next(k-1)+1;
  else
   break
  end % if
 end % for k
 
 if all(next <= 1)
  sJtot = sJtot + 1;
  J = [J; next];
 end
 
end







