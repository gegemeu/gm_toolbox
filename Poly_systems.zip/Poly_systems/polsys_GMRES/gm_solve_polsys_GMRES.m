function [xsol,val_sol,xxsol]=gm_solve_polsys_GMRES(A);
%GM_SOLVE_POLSYS_GMRES solve the polynomial real stagnation system for GMRES for
% a general n

% This code can only compute real solutions
% Ad hoc algorithm

% Caution: This works only for small matrices of order <= 10

% Input:
% A = square matrix
%
% Output:
% xsol = real solutions (that is, stagnation vectors)
% val_sol = values of the polynomials at the solution


%
% Author G. Meurant
% May 2010
% Updated Sept 2015
%

n = size(A,1);

xsol = [];
xxsol = [];
val_sol = [];

% construct the monomials

[fmon,addmon,frow] = gm_build_monomials(n);

% get the monomials and their numbers from fmon

lJ = addmon(end)-1;
nJ = zeros(lJ,1);
J = zeros(lJ,n);
for k = 1:lJ
 nJ(k) = fmon{1,k};
 J(k,:) = fmon{2,k};
end % for k

[rJ,rc] = gm_crypt_add(J);

% define the polynomial system corresponding to A

% this definition uses norm(b) = 1
% with diagonalization
[fpol,addpol,Mnu] = gm_polsys_elim(A);

% get the coefficients alpha of the diagonalized system

m = (n * (n -1)) / 2 + 1;
Alpha = zeros(n,m);
nAlpha = zeros(1,m);

for k = 1:n
 add = addpol(k);
 jj = 0;
 for j = add+1:addpol(k+1)-1
  jj = jj + 1;
  mon = fpol{j,2};
  numj = gm_find_listmonJ(mon,J,rJ,rc);
  Alpha(k,jj) = -fpol{j,3};
  nAlpha(1,jj) = numj;
 end % for j
end % for k

fAlp{1,1} = 0;
fAlp{1,2} = 0;
fAlp{2,1} = Alpha;
fAlp{2,2} = nAlpha;

% initialize the multiplication tables and fill them
% with the basis monomials and x_i^2

nkadd = zeros(n,1);
for k = addmon(2):addmon(3)-1
 nkadd(k-addmon(2)+1) = fmon{1,k};
 nkmon(k-addmon(2)+1,:) = fmon{2,k};
end % for k

nT = 2^n;

for k = 1:n
 T = zeros(nT,nT);
 xB = frow{4,k};
 % basis monomials
 for j = 1:nT
  if xB(j) <= nT
   T(j,xB(j)) = 1;
  end % if
 end % for j
 
 % x_i^2
 for j = 1:n
  for i = 1:size(Alpha,2);
   add = find(nkadd(j)==xB);
   T(add,nAlpha(1,i)) = Alpha(j,i);
  end % for i
 end % for j
 
 MTab{k} = T;
 
end % for k

% next stages starting with monomials with 2 variables

nkadd_old = nkadd;
nkmon_old = nkmon;

for k = 3:n+1
 % get the monomials in this group (starting at addmon(k))
 jend = 0;
 for j = addmon(k):addmon(k+1)-1
  nkadd(j-addmon(k)+1) = fmon{1,j};
  nkmon(j-addmon(k)+1,:) = fmon{2,j};
  jend = jend + 1;
 end % for j
 nkadd = nkadd(1:jend);
 nkmon = nkmon(1:jend,:);
 
 % consider all the monomials in this group (j loop)
 na = length(nkadd);
 % initialize the matrix
 M = eye(na,na);
 % and the right hand side
 rhs = zeros(na,nT);
 % previous group
 % (all the rows are the same?)
 % global addresses
 nadd = nAlpha(1,:);
 % and corresponding monomials
 nmon = J(nadd,:);
 
 for j = 1:na
  mon = nkmon(j,:);
  % find a candidate from the previous group by multiplying
  % with x_1, x_2,...
  % ncand is the rank of the candidate in the group
  % icand is i in x_i
  [ncand,icand,nrhs] = gm_find_cand(mon,nkmon_old,nmon);
  
  if ncand == 0
   error('mpol_solve_polsys_GMRES: Problem in finding a candidate')
  end % if
  
  % we need to multiply the expression from the previous
  % group by x_icand, this is nrhs
  % get the global numbers
  numrhs = gm_find_listmonJ(nrhs,J,rJ,rc);
  
  % look for non-basis monomials
  
  % find the group to which they belong
  % this group (k) goes into the matrix, basis elements go
  % into the right hand side, those in the previous
  % groups (not in the basis) must be resolved by substitution
  ng = gm_find_group(numrhs,addmon,nJ);
  
  % fill the matrix M and collect info for the rhs
  for l = 1:size(ng,1)
   ngl = ng(l);
   if ngl == k
    % this is a matrix term
    M(j,numrhs(l)-addmon(k)+1) = M(j,numrhs(l)-addmon(k)+1) - Alpha(ncand,l);
    
   elseif ngl == 1
    % this is a basis term, put it into rhs
    rhs(j,numrhs(l)) = rhs(j,numrhs(l)) + Alpha(ncand,l);
    
   else
    % this is arising from a previous group. The expression
    % is known as function of the basis
    
    num = numrhs(l) - addmon(ngl) + 1;
    Alph = fAlp{ngl,1};
    nAlph = fAlp{ngl,2};
    Alp = Alph(num,:);
    nAlp = nAlph(1,:);
    for ii = 1:length(nAlp)
     rhs(j,nAlp(ii)) = rhs(j,nAlp(ii)) + Alpha(ncand,l) * Alp(ii);
    end % for ii
    
   end % if ngl
   
  end % for l
  
 end % for j
 
 % remove the zero columns from rhs and get the basis
 % element numbers
 srhs = sum(rhs);
 ind = find(abs(srhs) >= 1e-14);
 nsol = ind;
 rhs = rhs(:,ind);
 
 sol = M\rhs;
 
 % next Alpha
 
 Alpha = sol;
 nAlpha = nsol;
 
 fAlp{k,1} = Alpha;
 fAlp{k,2} = nAlpha;
 
 nkadd_old = nkadd;
 nkmon_old = nkmon;
 
end % for k

% put the solutions into the multiplication tables

for k = 1:n
 
 T = MTab{k};
 % xB = global numbers of the monomials for variable x_k
 xB = frow{4,k};
 % find the group numbers
 ng = gm_find_group(xB,addmon,nJ);
 
 for ii = 1:length(ng)
  % we have already handle groups 1 (basis) and 2 (x_i^2)
  if ng(ii) > 2
   Alpha = fAlp{ng(ii),1};
   nAlpha = fAlp{ng(ii),2};
   
   nmon = xB(ii);
   nr = nmon - addmon(ng(ii)) + 1;
   row = ii;
   
   for j = 1:size(Alpha,2)
    col = nAlpha(1,j);
    T(row,col) = Alpha(nr,j);
   end % for j
  end % if ng
  
 end % for ii
 
 MTab{k} = T;
 
end % for k

% compute the solutions from multiplication tables

xxsol = gm_comp_sol(MTab);

ireal = 0;
for j = 1:size(xxsol,2)
 if norm(imag(xxsol(:,j))) < 1e-10
  ireal = ireal + 1;
  xsol(:,ireal) = real(xxsol(:,j));
 end
end

if size(xsol,2) == 0
 return
end

% evaluate the polynomials

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

xx = [];
val = [];

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) <= 1e-5
  xx = [xx xsol(:,k)];
  val = [val val_sol(:,k)];
 end
end % for k

xsol = xx;
val_sol = val;
