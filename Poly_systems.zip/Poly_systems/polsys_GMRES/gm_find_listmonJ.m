function numBj=gm_find_listmonJ(xB,J,rJ,rc);
%GM_FIND_LISTMONJ finds xB in the list given by J

% Input:
% xB = monomial
% J = list of monomials
% rJ, rc = coding of the monomials
%
% Output:
% numBJ = adresses of the monomials in xB in the list J

%
% Author G. Meurant
% May 2010
% Updated Sept 2015
%

nmon = size(xB,1);
numBj = zeros(nmon,1);

for k = 1:nmon
 xk = xB(k,:);
 add = gm_find_add(xk,J,rJ,rc);
 numBj(k) = add;
end % k

