function [ncand,icand,nrhs]=gm_find_cand(mon,nkmon,nmon);
%GM_FIND_CAND finds a candidate from nkmon such that x_i . nkmon = mon

% checks that there is no monomial with two 2s in nrhs

% Input:
% mon = monomial
% nkmon = monomials
% nmon = 
%
% Output:
% ncand = rank of the candidate in the group
% icand = i in x_i (index of the variable)
% nrhs = x_i . nmon


%
% Author G. Meurant
% May 2010
% Updated Sept 2015
%

ifind = 0;
ncand = 0;
icand = 0;

nk = size(nkmon,1);
n = size(nkmon,2);
nm = size(nmon,1);
k = 0;

while (ifind == 0) && (k <= nk)
 k = k + 1;
 % try all the x_i, i =1,...,n
 for i = 1:n
  xi = zeros(1,n);
  xi(i) = 1;
  for j = 1:nk
   xkmon = xi + nkmon(j,:) - mon;
   % check for equality with mon
   if norm(xkmon) == 0
    % found one, compute and check nrhs
    icand = i;
    ncand = j;
    check = 1;
    for l = 1:nm
     nrhs(l,:) = xi + nmon(l,:);
     n2 = find(nrhs(l,:)==2);
     if length(n2) > 1
      % there is more than one 2
      check = 0;
     end % if
    end % for l
    if check == 0
     continue
    else
     ifind = 1;
     return
    end % if check
   end % if norm
  end % for j
 end % for i
 
end % while

if ncand == 0
 nrhs = [];
end





