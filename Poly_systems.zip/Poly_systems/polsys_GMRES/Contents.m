% POLSYS_GMRES
%
% Files
%   gm_build_basis              - constructs a basis of monomials for the quotient space
%   gm_build_monomials          - constructs the monomials for the ad hoc algorithm
%   gm_comp_sol                 - computes the solutions from the multiplication tables
%   gm_defpol                   - defines the polynomial system for GMRES stagnation
%   gm_Ex_polsys_GMRES          - Examples of computation of stagnation vectors for GMRES
%   gm_find_cand                - finds a candidate from nkmon such that x_i . nkmon = mon
%   gm_find_group               - finds the group in nJ to which numrhs belong
%   gm_find_listmonJ            - finds xB in the list given by J
%   gm_polsys_elim              - diagonalizes the x_i^2 monomials in the GMRES system
%   gm_solve_polsys_GMRES       - solve the polynomial real stagnation system for GMRES for a general n
%   gm_solve_polsys_GMRES_AS    - Auzinger and Stetter algorithm for polynomial systems
%   gm_solve_polsys_GMRES_G     - solve the polynomial real stagnation system for GMRES for a general n
%   gm_solve_polsys_GMRES_n3    - solves the polynomial real stagnation system for GMRES for n=3
%   gm_solve_polsys_GMRES_n4    - solves the polynomial real stagnation system for GMRES for n=4
%   gm_solve_polsys_Grobner_sol - solves the polynomial system using a Grobner basis
