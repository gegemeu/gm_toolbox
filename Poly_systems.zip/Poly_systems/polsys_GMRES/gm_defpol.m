function [fpol,addpol,Mnu]=gm_defpol(A);
%GM_DEFPOL defines the polynomial system for GMRES stagnation
% for real matrices and vectors

% b^T A^j b = 0, j=1,...,n-1 and b^T b = 1
% In this way we can just compute real solutions

% Input:
% A = matrix (must be of small order)
%
% Output:
% fpol = polynomials
% addpol = addresses of polynomials in the list fpol
% Mnu = degrees

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

n = size(A,1);

% we have n polynomials + a dummy one

% number of coefficients per equation
nn = n * (n + 1) / 2;

fpol = cell((n - 1) * nn + n,3);
addpol = zeros(n+1,1);

AA = speye(n,n);

istart = 1;

for k = 1:n - 1
 % we need the powers of A
 AA = A * AA;
 addpol(k) = istart;
 % in lexicographic ordering
 irow = istart - 1;
 % terms b_i^2
 for i = 1:n
  irow = irow + 1;
  % polynomial number k
  fpol{irow,1} = k;
  % index
  ind = zeros(1,n);
  ind(i) = 2;
  fpol{irow,2} = ind;
  % value of the coefficient
  aii = AA(i,i);
  fpol{irow,3} = aii;
 end
 % take the products b_i b_j
 for i = 1:n
  for j = i + 1:n
   irow = irow + 1;
   % polynomial number k
   fpol{irow,1} = k;
   % index
   ind = zeros(1,n);
   ind(i) = 1;
   ind(j) = 1;
   fpol{irow,2} = ind;
   % value of the coefficient
   aij = AA(i,j) + AA(j,i);
   fpol{irow,3} = aij;
  end
 end
 istart = istart + nn;
end

% the last polynomial is sum b_i^2 - 1
% constant term
irow = istart;
addpol(n) = irow;
irow = irow - 1;
for i = 1:n
 irow = irow + 1;
 % polynomial number k
 fpol{irow,1} = n;
 % index
 ind = zeros(1,n);
 ind(i) = 2;
 fpol{irow,2} = ind;
 % value of the coefficient = 1
 fpol{irow,3} = 1;
end
irow = irow + 1;
% polynomial number k
fpol{irow,1} = n;
% index
ind = zeros(1,n);
fpol{irow,2} = ind;
% value of the coefficient = -1
fpol{irow,3} = -1;
istart = istart + n + 1;

addpol(n + 1) = istart;

Mnu = 2 * ones(n,1);



