function [fmon,addmon,frow]=gm_build_monomials(n);
%GM_BUILD_MONOMIALS constructs the monomials for the ad hoc algorithm
% for the GMRES real stagnation problem

% Input:
% n = order of the matrix
%
% Output:
% fmon = monomials
% addpol = adresses in the list of monomials
% frow = ?

%
% Author G. Meurant
% May 2010
% Updated Sept 2015
%

% basis monomials B

J = gm_build_basis(n);
JJ = J;

% store the monomials and number them

addmon = zeros(n+2,1);

addmon(1) = 1;

lJ = size(J,1);
for k = 1:lJ
 fmon{1,k} = k;
 fmon{2,k} = J(k,:);
end % for

add = k + 1;

% construct the monomials with one variable squared
% by computing x_j B and sorting

for j = 1:n
 xj = zeros(1,n);
 xj(j) = 1;
 frow{1,j} = xj;
 % the following will contain the number of the monomial
 % in the global numbering
 frow{2,j} = 0;
 xB = zeros(lJ,n);
 for l = 1:lJ
  xB(l,:) = xj + J(l,:);
 end % for l
 frow{3,j} = xB;
 
end % for j

% sort the monomials

for j = 1:n
 % monomials with j variables and at least a 2
 addmon(j+1) = add;
 nj = 0;
 % look into all the x_i B s
 for i = 1:n
  xB = frow{3,i};
  for k = 1:lJ
   xBk = xB(k,:);
   if (nnz(xBk) == j) && any(xBk==2)
    % found one, store it in fmon
    nj = nj + 1;
    fmon{1,add} = add;
    fmon{2,add} = xBk;
    JJ = [JJ; xBk];
    add = add + 1;
   end % if
  end % for k
 end % for i
end % for j

addmon(n+2) = add;

% put the numbers in frow

[rJ,rc] = gm_crypt_add(JJ);

for j = 1:n
 xj = frow{1,j};
 numj = gm_find_listmonJ(xj,JJ,rJ,rc);
 frow{2,j} = numj;
 xB = frow{3,j};
 numBj = gm_find_listmonJ(xB,JJ,rJ,rc);
 frow{4,j} = numBj;
end % for j








