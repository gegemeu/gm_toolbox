function ng=gm_find_group(numrhs,addmon,nJ);
%GM_FIND_GROUP finds the group in nJ to which numrhs belong

%
% Author G. Meurant
% May 2010
%

n = size(numrhs,1);
ng = zeros(n,1);

for k = 1:n
 num = numrhs(k);
 for j = 1:n
  if (num >= addmon(j)) && (num < addmon(j+1))
   ng(k) = j;
   break
  end % if
 end % for j
end % for k

