function [xsol,val_sol,xxsol]=gm_solve_polsys_GMRES_G(A);
%GM_SOLVE_POLSYS_GMRES_G solve the polynomial real stagnation system for GMRES for
% a general n

% This code can only compute real solutions
% Solutions with a Grobner basis

% Caution: This works only for small matrices of order <= 10

% Input:
% A = square matrix
%
% Output:
% xsol = real solutions (that is, stagnation vectors)
% val_sol = values of the polynomials at the solution


%
% Author G. Meurant
% Sept 2015
%

n = size(A,1);

xsol = [];
xxsol = [];
val_sol = [];
ord = 'grlex';
tol = 1e-10;
varnames = {};

if n == 2
 varnames = {'x1','x2'};
elseif n == 3
 varnames = {'x1','x2','x3'};
elseif n == 4
 varnames = {'x1','x2','x3','x4'};
end

% define the polynomial system
[fpol,addpol,Mnu] = gm_defpol(A);
% with diagonalization
% [fpol,addpol,Mnu] = gm_polsys_elim(A);

% convert to the format for Grobner
Pset = gm_defpol_to_poly(fpol,addpol,ord,tol);

xxsol = gm_solve_polsys_Grobner_sol(Pset,varnames,ord,tol);

% get the real solutions

ireal = 0;
for j = 1:size(xxsol,2)
 if norm(imag(xxsol(:,j))) < 1e-10
  ireal = ireal + 1;
  xsol(:,ireal) = real(xxsol(:,j));
 end
end

if size(xsol,2) == 0
 return
end

% evaluate the polynomials

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

xx = [];
val = [];

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) <= 1e-5
  xx = [xx xsol(:,k)];
  val = [val val_sol(:,k)];
 end
end % for k

xsol = xx;
val_sol = val;

