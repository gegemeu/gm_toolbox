function [fpol,addpol,Mnu]=gm_polsys_elim(A);
%GM_POLSYS_ELIM diagonalizes the x_i^2 monomials in the GMRES system
% and constructs the polynomial system

% Input:
% A = matrix
% 
% Output:
% fpol = list of polynomials
% addpol = adresses in the polynomial list
% Mnu = degrees of each polynomial

%
% Author G. Meurant
% Feb 2010
% Updated Sept 2015
%

n = size(A,1);

AA = speye(n,n);
m = (n*(n+1)) / 2 + 1;
N = zeros(n,m);

for k = 1:n-1
 AA = AA * A;
 d = diag(AA);
 N(k,1:n) = d';
 
 add = n;
 for i = 1:n
  for j = i+1:n
   add = add + 1;
   N(k,add) = AA(i,j) + AA(j,i);
  end % j
 end % i
 
end % k

% last line
N(n,1:n) = ones(1,n);
N(n,m) = -1;

% get the matrix of monomials x_i^2
M = N(1:n,1:n);
% condM = cond(M)
if abs(det(M)) > 1e-10
 D = inv(M);
else
 error(' gm_polsys_elim: The matrix of the monomials x_i^2 is close to singularity')
 fpol = [];
 addpol = [];
 return
end

AE = zeros(size(N,1),size(N,2));
AE(1:n,1:n) = eye(n,n);
AE(:,n+1:end) = M \ N(:,n+1:end);

% tranform this back to the polynomial

% number of coefficients per equation 
nn = n * (n + 1) / 2 - n + 2;

fpol = cell((n - 1) * nn + n,3);
addpol = zeros(n+1,1);

irow = 0;
for k = 1:n
 % in lexicographic ordering
 % only one term b_i^2
 irow = irow + 1;
 addpol(k) = irow;
 % polynomial number k
 fpol{irow,1} = k;
 % index
 ind = zeros(1,n);
 ind(k) = 2;
 fpol{irow,2} = ind;
 % value of the coefficient
 aii = AE(i,i);
 fpol{irow,3} = aii;
 
 % products b_i b_j
 icol = n;
 for i = 1:n
  for j = i + 1:n
   icol = icol + 1;
   aij = AE(k,icol);
   if abs(aij) > 0
    irow = irow + 1;
    % polynomial number k
    fpol{irow,1} = k;
    % index
    ind = zeros(1,n);
    ind(i) = 1;
    ind(j) = 1;
    fpol{irow,2} = ind;
    % value of the coefficient
    fpol{irow,3} = aij;
   end % if aij
  end % for j
 end % for i
 % add the constant term
 aij = AE(k,end);
 if abs(aij) > 0
  irow = irow + 1;
  % polynomial number k
  fpol{irow,1} = k;
  % index
  ind = zeros(1,n);
  fpol{irow,2} = ind;
  % value of the coefficient
  fpol{irow,3} = aij;
 end % if aij
end

addpol(n + 1) = irow + 1;

Mnu = 2 * ones(n,1);

