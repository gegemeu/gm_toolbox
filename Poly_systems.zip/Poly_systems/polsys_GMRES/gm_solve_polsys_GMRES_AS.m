function [xsol,val_sol]=gm_solve_polsys_GMRES_AS(A);
%GM_SOLVE_POLSYS_GMRES_AS Auzinger and Stetter algorithm for polynomial systems
% for the GMRES stagnation system

% computes only real solutions

% Input:
% A = matrix
%
% Output:
% xsol = solutions
% val_sol = values of the polynomials at the solutions

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

xsol = [];
val_sol = [];

% define the polynomial system
[fpol,addpol,Mnu] = gm_defpol(A);
% with diagonalization
% [fpol,addpol,Mnu] = gm_polsys_elim(A);

% compute the matrix At

[At,A01,A00,Jcal0,Jcal,DJcol,addJcal,DJcol0] = gm_multfpol(fpol,addpol,Mnu);
% DJcol is the boundary set
% DJcol0 corresponds to Z_0

N = size(At,1);
m = size(A01,1);
% n is the number of polynomials
n = length(addpol) - 1;
nt = size(At,2);

if (N + m) ~= nt
 error('gm_solve_polsys_AS: There is probably an error in the definition')
end

% case where At11 ((N,N) principal submatrix) may be singular

% select pivot candidates

% do we have zero columns in At?
sZ = sum(At);

% find exactly zero columns
IZ = find(sZ == 0);

% find the monomials in Jcal
[rJcal,rcal] = gm_crypt_add(Jcal);
IM = [];
for ii = 1:n
 ind = zeros(1,n);
 ind(ii) = 1;
 %  add = addr_pp_gen_new(ind,Jcal);
 add = gm_find_add(ind,Jcal,rJcal,rcal);
 IM = [IM add];
end % for ii

% Piv_PP represents bar Z_1
% first in the boundary set of columns Djcol

% find an independent set in Djcol
% put the monomials at the end if they are there
intIM = intersect(DJcol,IM);
if length(intIM) > 0
 re = gm_pol_setdiff(DJcol,intIM);
 DJ = [re intIM];
else
 DJ = DJcol;
end % if length

[R,Dcand] = gm_rref_polsys(At(:,DJ));
DInd = DJcol(Dcand(:));
lDInd = length(DInd);

% consider the remaining columns as pivot candidates
% The set J_0 (except [0 0 ... 0]) is at the end by construction
% nt corresponds to [0 0 ... 0]

% remainder of columns in the bdy set
Dbdy = gm_pol_setdiff(DJcol,DInd);
Dd = [DInd Dbdy'];

Delta = gm_pol_setdiff([1:nt],Dd);
% here are the potential candidates
cand = [Dd Delta'];

% exclude the zero columns from the pivot candidates
% put them at the end

% we also need the monomials to be at the end

IZ = unique([IZ IM]);

if length(IZ) > 0
 candNZ = gm_pol_setdiff(cand,IZ);
 cand = [candNZ' IZ];
end

% permute the columns
Acand = At(:,cand);

% compute the dependancies and the rank by partial elimination
[Atpart,colZ,valZ,rankA,colperm,Piv_PP,Zcol] = gm_part_elim_new(nt,Acand,cand);

% Piv_PP is now the set bar Z_1

% basis candidates for bar Z_0
% remove the pivots
Bas_cand = gm_pol_setdiff(cand,Piv_PP);
% we must exlude those in the independant set (delta) and add 1 = [0 0 0]
% what happens if 1 is in the pivots PP?
Bas_cand = unique([pol_setdiff(Bas_cand,DInd)'; nt]);

Piv_PP = gm_pol_setdiff(Piv_PP,nt);

% should we exclude DInd or DJcol?

% colZ(k,:) gives for row k the columns in which there is a nonzero entry
% in the reduced matrix (in the original numbering)

% we start the PP basis with [0 ... 0]
PP_basis = nt;

ifail = 0;
ibase = 1;
ipass = zeros(1,nt);

% loop until reaching a stationary point or a failure
while ibase == 1
 
 % neighbours of the current PP basis in Jcal
 % elements of the current basis are excluded
 PP_neigh = gm_neighbour_basis_new(n,PP_basis,Jcal);
 
 % current length of the basis
 lPP = length(PP_basis);
 
 % examine the neighours one by one
 for kk = 1:length(PP_neigh)
  k = PP_neigh(kk);
  
  % if k is a basis candidate, add it to the basis
  if gm_ismember(k,Bas_cand) == 1
   PP_basis = [PP_basis k];
   
   % is k a member of the set of pivots
  elseif gm_ismember(k,Piv_PP) == 1
   % k is a pivot PP
   
   % is k representable from the current basis?
   list = full(colZ(k,:));
   % all the elements of the list must be in the current PP basis
   % xk is the elements in list that are not in the basis
   xk = gm_pol_setdiff(list,PP_basis)';
   
   if length(xk) == 0
    % all the elements are in the PP basis
    % node k has passed the test
    ipass(k) = 1;
    % continue with the next element of the basis
    
    continue
    
   else % if length(xk)
    % xk is the set not belonging to the PP basis
    % are they basis candidates?
    sk = intersect(xk,Bas_cand);
    if length(sk) ~= 0
     % the nodes which are basis candidates are added to the PP basis
     PP_basis = [PP_basis sk];
     % continue with the next element of the basis
     continue
    end % if sk
    
    % is there one element on which  k depend that is in DInd
    sk = intersect(list,DInd);
    if length(sk) ~= 0
     % then the algorithm has failed
     ifail = 1;
    end % if length(sk)
    
   end % if xk
   
  else % ismember
   ifail = 1;
  end % is member
  
 end % for kk
 
 PP_basis = unique(PP_basis);
 
 % is the length of the basis the same (no element was added)
 if length(PP_basis) == lPP
  % stop expanding the basis
  ibase = 0;
 end
 
end % while ibase

if ifail == 1
 fprintf('\n gm_solve_polsys_AS: Warning: there was a failure in finding a PP basis \n')
 fprintf(' the solutions may be wrong if the basis was not computed yet \n\n')
end

% we must fix this!!!!!!!!
if length(PP_basis) > m
 % we have too many elements in the basis
 fprintf('\n gm_solve_polsys_AS: There are too many elements (%d) in the basis \n',length(PP_basis))
end

JcalP = Jcal(PP_basis,:);

for i = 1:n
 % compute the multiplication tables
 % directly from the partial elimination
 
 lJcalP = size(JcalP,1);
 Bnu = zeros(lJcalP,lJcalP);
 ind = zeros(1,n);
 ind(i) = 1;
 
 for j = 1:lJcalP
  % compute x_nu x^k for x^k in the PP basis
  index = ind + JcalP(j,:);
  % find the address in Jcal
  add = gm_find_add(index,Jcal,rJcal,rcal);
  if add == 0
   fprintf('\n gm_solve_polsys_AS: The address [%d] was not found in Jcal \n\n',index)
   error('gm_solve_polsys_AS: STOP')
  end
  % is x_nu x^k in the PP basis?
  if gm_ismember(add,PP_basis)
   % yes, put a one in the appropriate location
   J = find(PP_basis == add);
   Bnu(j,J) = 1;
  else % ismember
   % no, get the values from the reduced matrix Atpart
   % the interesting non zero elements are given by colZ
   cols = full(colZ(add,:));
   % remove the zeros
   cols = gm_pol_setdiff(cols,[0]);
   valsI = find( valZ(add,:));
   vals = valZ(add,valsI);
   for jj = 1:length(valsI);
    J = find(PP_basis == cols(jj));
    Bnu(j,J) = -vals(jj);
   end % for jj
  end % if ismember
 end % for j
 
 Bnui(:,:,i) = Bnu;
 
 % compute the eigensystem
 
 [XBnu,DBnu] = eig(full(Bnu));
 
 eigBnu(:,i) = diag(DBnu);
 
 % normalize the eigenvectors (if possible)
 sB = size(Bnu,1);
 
 ifail = 0;
 ieig = 0;
 for k = 1:sB
  if  XBnu(sB,k) ~= 0
   XBnu(:,k) = XBnu(:,k) ./ XBnu(sB,k);
  else
   ieig = 1;
  end % if XBnu
 end % for k
 
 % store the normalized eigenvectors
 
 XB(:,:,i) = XBnu(:,:);
 
end % for i

% in this case we have m solutions
m = size(Bnu,1);

% compute the solution from the eigenvalues and eigenvectors

ifail2 = 0;

for i = 1:n
 % check if Bnu(i) has only simple eigenvalues
 eigB = eigBnu(:,i);
 ueigB = unique(eigB);
 if length(ueigB) < length(eigB)
  % there is a multiple eigenvalue, look for the next Bnu
  continue
 end % if length
 
 % extract the solution from the eigensystem of Bnu(i)
 
 [rJcalP,rcalP] = gm_crypt_add(JcalP);
 
 for j = 1:m
  for l = 1:n
   if l == i
    % the i-th component of the solution is the eigenvalue
    xsol(i,j) = eigB(j);
   else % if l
    % the component is the eigenvector comp corresponding to x_l (ell) in J_0
    ind = zeros(1,n);
    ind(l) = 1;
    add = gm_find_add(ind,JcalP,rJcalP,rcalP);
    if add == 0
     ifail2 = 1;
    else % if add
     xsol(l,j) = XB(add,j,i);
    end % if add
   end % if l
   
  end % l
 end % j
 
 if ifail2 == 0
  % we have found solutions
  val_sol = gm_eval_polsys(xsol,fpol,addpol);
  
  % check the solutions
  
  xx = [];
  val = [];
  
  for k = 1:size(val_sol,2)
   if norm(val_sol(:,k)) <= 1e-5 && isreal(xsol(:,k))
    xx = [xx xsol(:,k)];
    val = [val val_sol(:,k)];
   end
  end % for k
  
  xsol = xx;
  val_sol = val;
  return
 else % ifail2
  % try the next Bnu(i)
  xsol = [];
  continue
 end % if ifail2
 
end % i

if ieig == 1
 ifail2 = 1;
 % recompute the eigensystem
 for ii = 1:n
  Bnu = Bnui(:,:,ii);
  [XBnu,DBnu] = eig(full(Bnu));
  XB(:,:,ii) = XBnu(:,:);
 end % for ii
end % if ieig

if ifail2 == 1
 % it does not work easily with eigenvectors
 % try to find the solution with the eigenvalues only
 xsol = [];
end % if ifail2

ifail3 = 0;
% the tolerance must not be too small
% otherwise we can miss some eigenvectors
tolX = 1e-5;
for j = 1:m
 % take the eigenvector j of the first system and find the corresponding eigenvalues in the n systems
 X = XB(:,j,1);
 for l = 1:n
  % look at the m eigenvectors of system l
  ifind = 0;
  for jj = 1:m
   if norm(X - XB(:,jj,l)) <= tolX
    ifind = 1;
    xsol(l,j) = eigBnu(jj,l);
    break
   end % if norm
  end % for jj
  if ifind == 0
   ifail3 = 1;
  end % if ifind
 end % for l
end % for j

if ifail3 == 1
 xsol = [];
 isol = 0;
 epss = 1e-4;
 % try to combine the eigenvalues to obtain solutions
 next = ones(1,n);
 x = zeros(n,1);
 while next(1) < m+1
  for i = 1:n
   x(i) = eigBnu(next(i),i);
  end % for i
  val_solx = gm_eval_polsys(x,fpol,addpol);
  if norm(val_solx) <= epss
   % accept x as a solution if we do not have it yet
   keep = 1;
   for i = 1:isol
    nx = norm(xsol(:,i));
    if nx == 0
     nx = 1;
    end % if nx
    dif = norm(x - xsol(:,i))/nx;
    if dif <= epss
     keep = 0;
    end % if dif
   end % for i
   if keep == 1
    isol = isol + 1;
    xsol(:,isol) = x;
   end % if keep
  end % if norm
  next = next_index(next,m,n);
 end % while
 
end % if ifail3

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

xx = [];
val = [];

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) <= 1e-5 && isreal(xsol(:,k))
  xx = [xx xsol(:,k)];
  val = [val val_sol(:,k)];
 end
end % for k

xsol = xx;
val_sol = val;


