
% Examples of computation of stagnation vectors for GMRES


% order of the matrix (must be <= 9 or 10)
n = 3;

fprintf('\n Order of the matrix = %d \n\n',n)

isol = 0;
for k = 1:10
 A = randn(n,n);
 
 tic
 [xsol,val_sol,xxsol] = gm_solve_polsys_GMRES(A);
 t = toc;
 
 if size(xsol,2) > 0
  isol = 1;
  break
 end
end

if isol == 0
 return
end

fprintf('\n gm_solve_polsys_GMRES: number of solutions = %d, time = %g \n',size(xsol,2),t)


b = xsol(:,1);
x0 = zeros(n,1);

% GMRES without preconditionning
[x,nit,iret,resn,resnt,time_mat] = gm_GMRESm_prec(A,b,x0,1e-14,n,n,'left','reorth','noscaling','trueres','noprint','no');

diffres = resn(n-1) - resn(1);
diffrest = resnt(n-1) - resnt(1);
fprintf('\n diff res = %g, diffresnt = %g \n',diffres,diffrest)

% resn
% resnt

if n >= 7
 return
end

% Solution with Auzinger and Stetter algorithm

tic
[xsol,val_sol] = gm_solve_polsys_GMRES_AS(A);
t = toc;

fprintf('\n gm_solve_polsys_GMRES_AS: number of solutions = %d, time = %g \n',size(xsol,2),t)

if size(xsol,2) > 0
 
 b = xsol(:,1);
 x0 = zeros(n,1);
 
 % GMRES without preconditionning
 [x,nit,iret,resn,resnt,time_mat] = gm_GMRESm_prec(A,b,x0,1e-14,n,n,'left','reorth','noscaling','trueres','noprint','no');
 
 diffres = resn(n-1) - resn(1);
 diffrest = resnt(n-1) - resnt(1);
 fprintf('\n diff res = %g, diffresnt = %g \n',diffres,diffrest)
 
 % resn
 % resnt
 
end

if n > 4
 return
end

% Solution with a Grobner basis (it may take a long time!!!)

tic
[xsol,val_sol,xxsol] = gm_solve_polsys_GMRES_G(A);
t = toc;

fprintf('\n gm_solve_polsys_GMRES_G: number of solutions = %d, time = %g \n',size(xsol,2),t)

if size(xsol,2) > 0
 
 b = xsol(:,1);
 x0 = zeros(n,1);
 
 % GMRES without preconditionning
 [x,nit,iret,resn,resnt,time_mat] = gm_GMRESm_prec(A,b,x0,1e-14,n,n,'left','reorth','noscaling','trueres','noprint','no');
 
 diffres = resn(n-1) - resn(1);
 diffrest = resnt(n-1) - resnt(1);
 fprintf('\n diff res = %g, diffresnt = %g \n',diffres,diffrest)
 
 % resn
 % resnt
 
end




