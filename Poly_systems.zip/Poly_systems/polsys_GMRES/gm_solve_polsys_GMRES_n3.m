function [xsol,val_sol,xxsol]=gm_solve_polsys_GMRES_n3(A);
%GM_SOLVE_POLSYS_GMRES_N3 solves the polynomial real stagnation system for GMRES for
% n=3

% This code can only compute real solutions
% Ad hoc algorithm

% For n > 4, use gm_solve_polsys_GMRES

% Input:
% A = matrix
%
% Output:
% xsol = real solutions
% val_sol = values of the polynomials at the solutions
% xxsol = all solutions

%
% Author G. Meurant
% April 2010
% Updated Sept 2015
%

n = size(A,1);

if n ~= 3
 error('gm_solve_GMRES_n3: The matrix A must be of order 3')
end

xsol = [];
xxsol = [];
val_sol = [];

% define the polynomial system corresponding to A

% this definition uses norm(b) = 1
% with diagonalization
[fpol,addpol,Mnu] = gm_polsys_elim(A);

% get the coefficients alpha of the diagonalized system

Alpha = zeros(3,4);

for k =1:3
 add = addpol(k);
 jj = 0;
 for j = add+1:addpol(k+1)-1
  jj = jj + 1;
  Alpha(k,jj) = fpol{j,3};
 end % for j
end % for k

A6 = eye(6,6);

A6(1,3) = Alpha(1,1);
A6(1,4) = Alpha(1,3);
A6(2,5) = Alpha(1,2);
A6(2,6) = Alpha(1,3);
A6(3,1) = Alpha(2,1);
A6(3,2) = Alpha(2,2);
A6(4,5) = Alpha(2,2);
A6(4,6) = Alpha(2,3);
A6(5,1) = Alpha(3,1);
A6(5,2) = Alpha(3,2);
A6(6,3) = Alpha(3,1);
A6(6,4) = Alpha(3,3);

iA6 = inv(A6);

Beta = zeros(6,1);

B1 = -[Alpha(1,2); Alpha(1,1); Alpha(2,3); Alpha(2,1); Alpha(3,3); Alpha(3,2)];

B2 = -[0; 0; Alpha(2,4); 0; Alpha(3,4); 0];

B3 = -[Alpha(1,4); 0; 0; 0; 0; Alpha(3,4)];

B4 = -[0; Alpha(1,4); 0; Alpha(2,4); 0; 0];

Beta = iA6 * [B1 B2 B3 B4];

A3 = eye(3,3);

A3(1,3) = -Beta(1,1);
A3(2,1) = -Beta(4,1);
A3(3,2) = -Beta(5,1);

G1 = [-Beta(1,4)*Alpha(3,1); Beta(4,3)-Beta(4,2)*Alpha(1,1); Beta(5,2)-Beta(5,3)*Alpha(2,1)];

G2 = [Beta(1,2)-Beta(1,4)*Alpha(3,2); Beta(4,4)-Beta(4,2)*Alpha(1,2); -Beta(5,3)*Alpha(2,2)];

G3 = [Beta(1,3)-Beta(1,4)*Alpha(3,3); -Beta(4,2)*Alpha(1,3); Beta(5,4)-Beta(5,3)*Alpha(2,3)];

G4 = [-Beta(1,4)*Alpha(3,4); -Beta(4,2)*Alpha(1,4); -Beta(5,3)*Alpha(2,4)];

G = [G1 G2 G3 G4];

Delta = zeros(3,4);

Delta = inv(A3) * G;

% Multiplication tables

Mx = zeros(8,8);

Mx(2,1) = -Alpha(1,4);
Mx(8,1) = Delta(1,4);
Mx(1,2) = 1;
Mx(5,2) = Beta(1,2);
Mx(6,2) = Beta(2,2);
Mx(5,3) = Beta(1,3);
Mx(6,3) = Beta(2,3);
Mx(5,4) = Beta(1,4);
Mx(6,4) = Beta(2,4);
Mx(2,5) = -Alpha(1,1);
Mx(3,5) = 1;
Mx(8,5) = Delta(1,1);
Mx(2,6) = -Alpha(1,2);
Mx(4,6) = 1;
Mx(8,6) = Delta(1,2);
Mx(2,7) = -Alpha(1,3);
Mx(8,7) = Delta(1,3);
Mx(5,8) = Beta(1,1);
Mx(6,8) = Beta(2,1);
Mx(7,8) = 1;

MTab{1} = Mx;

My = zeros(8,8);

My(3,1) = -Alpha(2,4);
My(8,1) = Delta(2,4);
My(5,2) = Beta(3,2);
My(7,2) = Beta(4,2);
My(1,3) = 1;
My(5,3) = Beta(3,3);
My(7,3) = Beta(4,3);
My(5,4) = Beta(3,4);
My(7,4) = Beta(4,4);
My(2,5) = 1;
My(3,5) = -Alpha(2,1);
My(8,5) = Delta(2,1);
My(3,6) = -Alpha(2,2);
My(8,6) = Delta(2,2);
My(3,7) = -Alpha(2,3);
My(4,7) = 1;
My(8,7) = Delta(2,3);
My(5,8) = Beta(3,1);
My(6,8) = 1;
My(7,8) = Beta(4,1);

MTab{2} = My;

Mz = zeros(8,8);

Mz(4,1) = -Alpha(3,4);
Mz(8,1) = Delta(3,4);
Mz(6,2) = Beta(5,2);
Mz(7,2) = Beta(6,2);
Mz(6,3) = Beta(5,3);
Mz(7,3) = Beta(6,3);
Mz(1,4) = 1;
Mz(6,4) = Beta(5,4);
Mz(7,4) = Beta(6,4);
Mz(4,5) = -Alpha(3,1);
Mz(8,5) = Delta(3,1);
Mz(2,6) = 1;
Mz(4,6) = -Alpha(3,2);
Mz(8,6) = Delta(3,2);
Mz(3,7) = 1;
Mz(4,7) = -Alpha(3,3);
Mz(8,7) = Delta(3,3);
Mz(5,8) = 1;
Mz(6,8) = Beta(5,1);
Mz(7,8) = Beta(6,1);

MTab{3} = Mz;

% compute the solution from multiplication tables

xxsol = gm_comp_sol(MTab);

% get the real solutions

ireal = 0;
for j = 1:size(xxsol,2)
 if norm(imag(xxsol(:,j))) < 1e-14
  ireal = ireal + 1;
  xsol(:,ireal) = real(xxsol(:,j));
 end
end

if size(xsol,2) == 0
 return
end

val_sol = gm_eval_polsys(xsol,fpol,addpol);

% check the solutions

for k = 1:size(val_sol,2)
 if norm(val_sol(:,k)) > 1e-5
  xsol = [];
  val_sol = [];
  return
 end
end % for k



