function [Jcalnu,Jcalnus,Jord]=gm_build_Jcalnu(nu,n,Mnu,Jord);
%GM_BUILD_JCALNU constructs the set of indices J_nu for the Auzinger and Stetter
% method

% Input:
% nu = index for which we want to compute the monomials Jcalnu
% n = number of polynomials
% Mnu = total degrees m_nu of the n polynomial equations
% Jord = set of tuples satisfying the condition sum(indices) <= sum(Mnu) - n + 1
% 
% Output:
% Jcalnu = set of indices
% Jcalnus = Jcalnu - (0 ... 0 m_nu 0 ... 0), m_nu in the nu-th position
% Jord = set of tuples satisfying the condition sum(indices) <= sum(Mnu) - n + 

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

if size(Jord,1) == 0
 J = gm_build_lexic_order_new(n,Mnu);
 Jord = J;
else
 J = Jord;
end

Jcalnu = [];

for k = 1:size(J,1)
 Jk = J(k,:);
 if Jk(nu) >= Mnu(nu)
  itrue = 1;
  for i = nu+1:n
   if Jk(i) >= Mnu(i)
    itrue = 0;
   end
  end
  if itrue == 1
   Jcalnu = [Jcalnu; Jk];
  end
 end
end

sJcal = size(Jcalnu,1);

if nu > 1
 z1 = zeros(sJcal,nu-1);
else
 z1 = [];
end

if nu < n
 z2 = zeros(sJcal,n-nu);
else
 z2 = [];
end

Jcalnus = Jcalnu - Mnu(nu) * [ z1 ones(sJcal,1) z2];


