function J=gm_build_lexic_order_new(n,Mnu);
%GM_BUILD_LEXIC_ORDER_NEW builds a lexicographic ordering of
% the n-tuples with values from 0, 1, 2, ...

% This version does not construct the full order
% which is too memory consuming

% Input:
% n = size of the tuples
% Mnu = degree
%
% Output:
% J = list of the tuples

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

up = sum(Mnu) - n + 1;

next=zeros(1,n);

J = next;

% keep only the tuples for which sum <= sum(Mnu) - n + 1

sJtot = 1;
while next(1) ~= up+1
 
 % add 1 to the last element and propagates the carries to the left
 next(n) = next(n)+1;
 for k = n:-1:2
  if next(k) > up
   next(k) = 0;
   next(k-1) = next(k-1) + 1;
  else
   break
  end % if
 end % for k
 
 sJtot = sJtot + 1;
 sJ = sum(next,2);
 if sJ <= up
  J = [J; next];
 end
end % while









