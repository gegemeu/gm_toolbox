function izero=gm_iszero(P,tol);
%GM_ISZERO returns 1 if all the coefficients of P are zero
% that is,  <= tol

% Input:
% P = polynomial
% tolerance for the coefficients
%
% Output:
% izero = 1 if the polynomial is "zero", 0 otherwise

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%
 
izero = 0;

if size(P,1) == 0
 izero = 1;
 return
end

PP = P{1,4};

if sum(any(PP(:,1) > tol)) == 0
 izero = 1;
end



