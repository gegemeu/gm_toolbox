function pairs=gm_append_pair(p,gb,h);
%GM_APPEND_PAIR appends pairs from gb and h to list p

% Input:
% p = list of pairs
% gb = list of pairs
% h = a pair
%
% Output:
% pairs = new set of pairs

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% nb of polynomials in basis gb
ngb = size(gb,1);

% nb of pairs
np = size(p,1);
ip = np;

pairs = p;

for k = 1:ngb
 P = gm_getpol(gb,k);
 
 LT1 = gb{k,3};
 d1 = LT1(1,2:end);
 LT2 = h{1,3};
 d2 = LT2(1,2:end);
 
 L = max(d1,d2); % LCM of leading terms
 
 ip = ip + 1;
 pairs{ip,1} = L;
 pairs{ip,2} = P;
 pairs{ip,3} = h;
 
 ip = ip + 1;
 pairs{ip,1} = L;
 pairs{ip,2} = h;
 pairs{ip,3} = P;
 
end



