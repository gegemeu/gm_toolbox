function Pol=gm_create_1pol(mon);
%GM_CREATE_1POL creates one polynomial system from the monomial mon

% Input:
% mon = monomial
%
% Output:
% Pol = new polynomial

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

Pol = {};

% create the cell array
% (npol,1) = 1 active, = 0 inactive (deleted)
% (npol,2) = number of terms in the polynomial
% (npol,3) = leading term
% (npol,4) = coefficients and exponents (2D array)

P = [1 mon];

Pol{1,1} = 1;
Pol{1,2} = 1;
Pol{1,3} = P;
Pol{1,4} = P;





