function [Ms,J]=gm_mommat(y,s,n,M,rM,rm);
%GM_MOMMAT computes the moment matrix Ms(y)

% Input:
% y = 
% s = 
% n =
% M = 
% rM = 
% rm =
%
% Output:
% Ms = moment matrix
% J = 

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

sy = size(y,1);

J = gm_build_lexic_order(n,s);

sJ = size(J,1);

Ms = zeros(sJ,sJ);

for i = 1:sJ
 for j = i+1:sJ
  ind = J(i,:) + J(j,:);
  rmon = sum(rm .* ind,2);
  I = find(rmon == rM);
  add = I(1);
  Ms(i,j) = y(add);
 end % for j
end % for i

Ms = Ms + Ms';

% add the diagonal
for j = 1:sJ
 ind = J(j,:) + J(j,:);
 % find the adress in y (through M)
 rmon = sum(rm .* ind,2);
 I = find(rmon == rM);
 add = I(1);
 Ms(j,j) = y(add);
end % for j





