function cond=gm_buch_criteria(P1,P2,LCM,gbasis,pairs,ord);
%GM_BUCH_CRITERIA returns the Buchberger criteria
% for eliminating pairs

% Input:
% P1, P2 = elements of a pair
% LCM = least common multiple
% gbasis = Grobner basis
% pairs = list of pairs
% ord = ordering
%
% Output:
% cond = 1 if the criteria is satisfied

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

cond = 1;

% first criteria

LT1 = P1{1,3};
c1 = LT1(1,1);
d1 = LT1(1,2:end);

LT2 = P2{1,3};
c2 = LT2(1,1);
d2 = LT2(1,2:end);

if any(and(d1 > 0,d2 > 0))
 % Buchberger's first criterion:
 % leading terms have a variable in common, so S-poly is nontrivial
 cond = 0;
 return
end

while size(gbasis,1) > 0
 P = gm_getpol(gbasis,1);
 gbasis = gm_remove_top_pol(gbasis);
 LT = P{1,3};
 LM = LT(1,2:end);
 if gm_is_greater_mon(LM,LCM,ord)
  cond = 0;
  return
 end % if
 
 if isequal(P,P1) || isequal(P,P2)
  continue
 end % if
 
 if ~gm_multiple_mon(LCM,LM)
  continue
 end
 
 cond1 = gm_is_contained_pair(pairs,P1,P);
 cond2 = gm_is_contained_pair(pairs,P,P2);
 
 if ~cond1 && ~cond2
  cond = 1;
  return
 end % if
 
end % while

cond = 0;



