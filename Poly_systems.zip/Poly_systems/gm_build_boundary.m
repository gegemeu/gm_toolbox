function [DJ,DJcol]=gm_build_boundary(n,Jcal,Mnu);
%GM_BUILD_BOUNDARY builds the boundary set for the Auzinger and Stetter
% method

% Input: 
% n = number of polynomials
% Jcal = set of indices
% Mnu = maximum degree for each monomial
% 
% Output:
% DJ = boundary set
% DJcol = column indices

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

upbd = sum(Mnu) - n + 1;

JJ = Jcal;

DJ = [];

% keep only the tuples for which sum = sum(Mnu) - n + 1

if length(Mnu) ~= n
 error('gm_build_boundary: Incompatible dimensions')
end

icol = 0;
index = 0;
for k = 1:size(JJ,1)
 sJ = sum(JJ(k,:));
 if sJ <= upbd
  index = index + 1;
  if sJ == upbd && sJ ~= 0
   DJ = [DJ; JJ(k,:)];
   icol = icol + 1;
   DJcol(icol) = index;
  end
 end
end

