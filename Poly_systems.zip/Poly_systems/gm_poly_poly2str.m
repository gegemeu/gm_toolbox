function strcell=gm_poly_poly2str(Poly,varnames);
%GM_POLY_POLY2STR  converts multivariate polynomials from cell arrays to strings

% Input:
% Poly = polynomials as a cell array
% varnames = variable names
%
% Output:
% strcell = polynomials as strings

%
% Author G. Meurant
% March 2010
% from a code by P. Petschel
% Updated Sept 2015
%

% number of polynomials in Poly
npol = size(Poly,1);
if npol == 0
 strcell = {' '};
 return
end

P = Poly{1,4};
% number of variables
% subtract 1 for the coefficient
maxnvars = size(P,2) - 1;

if nargin < 2
 varnames = cell(1,maxnvars);
 for i = 1:maxnvars
  varnames{i} = sprintf('x%d',i);
 end
elseif maxnvars > numel(varnames)
 error('gm_poly_poly2str: Not enough variable names provided');
end

strcell = cell(1,npol);

for i = 1:npol
 str = '';
 P = Poly{i,4};
 s = size(P);
 c = cell(1,length(s));
 
 for j = 1:s(1)
  deg = P(j,2:end);
  Coef = P(j,1);
  if Coef ~= 0
   if (Coef > 0) && ~isempty(str)
    str = [str,'+'];
   end % if Coef > 0
   if Coef == 1
    last1 = true;
   elseif Coef == -1
    % only print the '-'
    last1 = true;
    str = [str,'-'];
   else
    last1 = false;
    str = [str,sprintf('%g',Coef)]; % include coefficient
   end % if Coef = 1
   % degrees of terms in monomials
   for k = 1:length(deg)
    if deg(k) > 0
     if last1
      last1 = false;
     else
      str = [str,'*'];
     end % if last1
     str = [str,varnames{k}]; % print variable name
    end % if deg > 0
    if deg(k) > 1
     str = [str,sprintf('^%d',deg(k))]; % print exponent
    end % if deg > 1
   end % for k
   if last1
    % this must be a constant term 1, so print the 1
    str = [str,'1'];
   end % if last1
  end % if Coef ~= 0
 end % for j
 strcell{i} = str;
end % for i


