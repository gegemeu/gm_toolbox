function LM=gm_leading_monomials(gbasis);
%GM_LEADING_MONOMIALS returns the leading monomials of gbasis

% Input:
% gbasis = Grobner basis
%
% Output:
% LM = leading monomials

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(gbasis,1);

LM = {};

for k = 1:npol
 P = gm_getpol(gbasis,k);
 LT = P{1,3};
 Lm = LT(1,2:end);
 Q = gm_create_1pol(Lm);
 LM = gm_putpol(LM,Q,k);
end

