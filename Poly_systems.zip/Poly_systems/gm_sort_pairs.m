function pairsort=gm_sort_pairs(pairs,ord);
%GM_SORT_PAIRS sorts the pairs according to LCM of polynomials
% in ascending order

% Input:
% pairs = list of pairs
% ord = ordering
%
% Output:
% pairsort = sorted list

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% sort the LCMs

pairsort = {};
npol = size(pairs,1);

if npol == 0
 pairsort = pairs;
 return
end

LT = pairs{1,1};
d1 = size(LT,2);

ips  = 0;
for k = 1:npol
 smallest_mon = 1000 * ones(1,d1);
 index = 1;
 
 for i = 1:npol
  LTi = pairs{i,1};
  [index,smallest_mon] = gm_sort_mon_small(index,smallest_mon,i,LTi,ord);
 end % for i
 
 ips = ips + 1;
 pairsort{ips,1} = smallest_mon;
 pairsort{ips,2} = pairs{index,2};
 pairsort{ips,3} = pairs{index,3};
 
 pairs{index,1} = 1000 * ones(1,size(d1,2));
 
end % for k

