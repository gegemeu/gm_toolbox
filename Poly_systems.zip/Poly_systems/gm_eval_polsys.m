function val_sol=gm_eval_polsys(xsol,defpoly,addpol);
%GM_EVAL_POLSYS computes the values of the polynomial system
% defined by defpoly at the solutions xsol

% Input:
% xsol = set of solutions
% defpoly = polynomials definition
% addpol = pointers to the polynomials in defpoly

%
% Author G. Meurant
% January 2010
% Updated Sept 2015
%

iprint = 0;

Nsol = size(xsol,2);
Nval = size(xsol,1);

if nargin == 2
 
 if ischar(defpoly)
  % in this case defpoly is the name of a  .m file
  [fpol,addpol,Mnu] = feval(defpoly);
 else
  error('gm_eval_polsys: defpoly must be a string giving the name of the file')
 end
 
else
 % defpoly is a cell array
 if iscell(defpoly)
  fpol = defpoly;
 else
  error('gm_eval_polsys: defpoly must be a cell array defining the polynomial system')
 end
 
end

npol = length(addpol) - 1;

val_sol = zeros(npol,Nsol);

% loop on polynomials

for k =1:npol
 
 if iprint == 1
  fprintf('\n\n')
  fprintf(' polynomial number \n',num2str(k))
 end
 
 % get the indices and the coefficients for the polynomial k
 
 % start and end of polynomial k in the list fpol
 istart = addpol(k);
 iend = addpol(k + 1) - 1;
 
 for j = istart:iend
  % get the tuple in the cell array fpol
  ind = fpol{j,2};
  coeff = fpol{j,3};
  if length(ind) ~= Nval
   error('gm_eval_polsys: Mismatch in the number of unknowns and the polynomial definition')
  end
  for i = 1:Nsol
   x = xsol(:,i)';
   val_sol(k,i) = val_sol(k,i) +  coeff * prod(x.^ind);
  end
 end
 
end

