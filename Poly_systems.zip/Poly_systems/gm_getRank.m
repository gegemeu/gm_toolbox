function Rank=gm_getRank(version,L,U,tol);
%GM_GETRANK estimates matrix rank based on lower and upper triangular
%           matrices L, U returned by the rrlu routine

% Input:
% version  
%         = 0
%      then L has unit diagonal elements and the matrix U takes form
%
%            U = [ U1  U2 ]            
%                [ 0   0  ]
%
%      where U1 in upper triangular with nonzero elements on diagonal
%
%        = 1
%      then U has unit diagonal elements and the matrix L takes form
%
%            L = [ L1  0 ]             
%                [ L2  0 ]
%
%      where L1 in lower triangular with nonzero elements on diagonal
% L, U =  rank-revealing LU factorization from rrlu_mex
% tol = tolerance for the entries
%
% Output:
% Rank = matrix rank

% All rights reserved
% pawel.kowal@ibs.org.pl
% 08.2006.

if version == 0
 M = U;
else
 M = L;
end

[n,m] = size(M);
if min([n,m]') == 0
 Rank = 0;
 return
end

if min([n,m]') == 1
 D = abs(M(1));
else
 D = abs(diag(M));
end

I = find(D>tol);
Rank = length(I);

