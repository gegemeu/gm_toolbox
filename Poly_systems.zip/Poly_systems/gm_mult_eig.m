function multlamb=gm_mult_eig(lamb);
%GM_MULT_EIG looks for multiple eigenvalues

% Input:
% lamb = list of eigenvalues
%
% Output:
% multlamb = 1, there are multiple eigenvalues

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

multlamb = 0;
% which value of epsi?
% this can change the results
epsi = 1e-6;

n = length(lamb);

for k = 1:n
 lambk = lamb(k);
 for j = 1:k
  dif = abs(lambk - lamb(j));
  ak = abs(lambk);
  if ak > 0
   dif = dif / ak;
  end % if
  if (j ~= k) && (dif <= epsi)
   % there are multiple eigenvalues
   multlamb = 1;
   return
  end % if
 end % for j
 
 
end % for k