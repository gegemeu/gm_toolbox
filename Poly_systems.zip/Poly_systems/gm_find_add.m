function add=gm_find_add(mon,~,rJ,r);
%GM_FIND_ADD finds the address of mon in J

% Input:
% mon = monomial
% rJ, r = coded monomials
%
% Output:
% add = address in the list of monomials

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

% code the monomial mon
rmon = sum(r .* mon);

I = find(rmon == rJ);

% % it can be dangerous to remove this check, but...
% if length(I) == 0
%  error(' the monomial is not in the list')
% end

add = I(1);



