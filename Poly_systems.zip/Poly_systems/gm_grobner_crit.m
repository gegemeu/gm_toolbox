function gbasis=gm_grobner_crit(polyset,varnames,ord,tol);
%GM_GROBNER_CRIT calculates the reduced Groebner basis of a set of polynomials
% criteria for avoiding useless pairs

% Input:
%  polyset = a cell array of multivariate polynomial coefficients
%            The cell elements are strings
%            They must use variable names 'x1','x2',...
%            (unless varnames is provided) and be valid inputs for gm_create
%  ord = a string specifying the monomial ordering:
%        'lex': lexicographical, order by highest power of most significant
%         indeterminate,
%        'grlex': graded lex, order by total degree then lex,
%        'grevlex': graded reverse lex, order by total degree then by lowest
%         power of least significant indeterminate
%  varnames (optional) = a cell array of variable names if polyset is a
%           cell array of strings and the variable names are not 'x1', 'x2', etc.
%           If specified, there must always be at least 2 variables.
%  tol (optional) = the zero tolerance for coefficients, otherwise
%       catastrophic cancellation may occur.  Default value is 0
%
% Ouput:
%  gbasis = the reduced Grobner basis of the set of polynomials, as a
%           string if the input is a string

% Updated by G. Meurant
% Sept 2015
%

if nargin < 4
 tol = 0;
end

if (numel(polyset) > 0) && ischar(polyset{1})
 charout = true;
 
 polyset = gm_create(polyset,varnames,ord,tol);
 
else
 charout = false;
end

% normalize the input

gbasis = gm_allnormalize(polyset);

% create (and sort) the pairs

pairs = gm_create_pairs(gbasis,ord);

spol = 0;
while size(pairs,1) > 0
 
 % get the first pair (top of the list)
 % and remove it
 
 [pairs,LCM,P1,P2] = gm_remove_top_pair(pairs);
 
 cond = gm_buch_criteria(P1,P2,LCM,gbasis,pairs,ord);
 
 if ~cond
  spol = spol + 1;
  % compute the S-polynomial of P1 and P2
  
  S = gm_SPolyP1P2(P1,P2,ord,tol);
  
  % compute the normal form with respect to the current basis
  
  h = gm_reduceset(S,gbasis,ord,tol);
  h = gm_sort_pol(h,ord,tol);
  
  % is the normal form zero?
  if gm_iszero(h,tol) == 0
   % add the pairs with h
   pairs = gm_append_pair(pairs,gbasis,h);
   % sort the pairs ??????????
   pairs = gm_sort_pairs(pairs,ord);
   % add to the basis
   gbasis = gm_append(h,gbasis);
   gbasis = gm_fullreduce(gbasis,ord,tol);
  end % if iszero
  
 end % cond
 
end % while



