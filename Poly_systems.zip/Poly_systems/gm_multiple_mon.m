function cond=gm_multiple_mon(LCM,LM);
%GM_MULTIPLE_MON true if LCM is a multiple of LM

% Input:
% LCM, LM = monomials
%
% Output:
% cond = 1 if LCM is a multiple of LM

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

cond = 1;

d = LCM - LM;

if any(d < 0) == 1
 cond = 0;
end

