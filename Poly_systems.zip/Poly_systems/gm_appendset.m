function Pols=gm_appendset(Pset,Pols);
%GM_APPENDSET adds the polynomials from the set Pset to the set Pols

% Input:
% Pset = set of polynomials to be added
% Pols = set of polynomials to be updated
%
% Output:
% Pols = result of the append operation

%
% Author G. Meurant
% March 2010
% Updated Sept 2015
%

npol = size(Pset,1);

for n = 1:npol

 P = gm_getpol(Pset,n);

 Activ = P{1,1};

 if Activ == 1

  k = size(Pols,1);
  k = k + 1;

  Pt = P{1,1};
  Pols{k,1} = Pt;
  Pt = P{1,2};
  Pols{k,2} = Pt;
  Pt = P{1,3};
  Pols{k,3} = Pt;
  Pt = P{1,4};
  Pols{k,4} = Pt;

 end % if Activ

end % for n

