function [b,nsol]=gm_find_multi_isotropic_mu(A,colbmax,mu);
%GM_FIND_MULTI_ISOTROPIC_MU computes solutions to b' A b = mu

% to get a solution mu has to be in the field of values of A

% Caution, we compute all the eigenvalues of A - mu I. This may be costly if 
% A is large

% Input:
% A = matrix (may be real or complex)
% colbmax = maximum number of solutions to be computed
% mu = target value for b' A b
%
% Output:
% b = vector such that b' A b = mu
% nsol = number of solutions found

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

n = size(A,1);

A = A - mu * eye(n,n);

[b,nsol] = gm_find_multi_isotropic(A,colbmax);


