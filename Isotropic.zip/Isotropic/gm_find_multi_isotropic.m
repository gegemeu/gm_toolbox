function [bsol,nsol]=gm_find_multi_isotropic(A,colbmax);
%GM_FIND_MULTI_ISOTROPIC finds several isotropic vectors: solutions to b'A b = 0

% to get a solution zero has to be in the field of values of A

% for just one vector, gm_find_isotropic is cheaper

% Caution, we compute all the eigenvalues of A. This may be costly if 
% A is large

% Input:
% A = matrix (may be real or complex)
%
% Output:
% bsol = isotropic vector(s)
% nsol = number of solutions found

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

n = size(A,1);

ii = sqrt(-1) / 2;

b = [];
bsol = [];
dd = [];

% check if A is real
if isreal(A)
 [bsol,nsol] = gm_find_multi_isotropic_real(A,colbmax);
 return
end

% check if A is purely imaginary
if isreal(ii * A)
 [bsol,nsol] = gm_find_multi_isotropic_real(sqrt(-1) * A,colbmax);
 return
end

% A is complex

% eigenvectors of the skew-hermitian part

K = -ii * (A - A'); % Skew-Hermitian part of A

[X, D] = eig(full(K));

% the eigenvalues K are real
[lmbh, k] = sort(real(diag(D)));
lmin = lmbh(1);
lmax = lmbh(n);
if lmin * lmax > 0
 warning('gm_find_multi_isotropic: 0 is outside of the field of values of A')
 nsol = 0;
 return
end

% consider pairs of eigenvalues (one < 0 and one > 0)
% monitor the sign of b' * A * b

colb = 0;
oldsig = 0;
stop = 0;
for j = 1:n
 la1 = lmbh(j);
 % find a negative eigenvalue
 if la1 <= 0
  % look for positive eigenvalues
  for kk = j+1:n
   la2 = lmbh(kk);
   if la2 >= 0
    % use that pair to generate a solution with zero imaginary part
    X1 = X(:,k(j));
    X2 = X(:,k(kk));
    [b,colb,bAb] = gm_find_isotropic_2eig(la1,la2,X1,X2,b,colb,A);
    bAb = real(bAb);
    dd(colb) = bAb;
    sig = sign(bAb);
    if (oldsig ~= 0) && (sig ~= oldsig)
     % the sign has changed, stop
     stop = 1;
    end % if
    oldsig = sig;
    if colb >= colbmax && (stop == 1)
     break
    end % if
   end % if la2
  end % for kk
  if colb >= colbmax && (stop == 1)
   break
  end % i
 end % if la1
end % for j

if isempty(b)
 error('gm_find_multi_isotropic: Did not find suitable vectors')
end

% extract two vectors with different signs

pos = find(dd > 0);
neg = find(dd < 0);

if length(pos) == 0 | length(neg) == 0
 warning('gm_find_multi_isotropic: Did not find different signs, switch to gm_invfovCPU')
 [bsol,err,step] = gm_invfovCPU(A,0,0,0);
 nsol = size(bsol,2);
 return
end

nsol = 0;
istop = 0;
for k = 1:length(pos)
 i = pos(k);
 xc = b(:,i);
 cc = dd(i);
 for kk = 1:length(neg)
  j = neg(kk);
  xa = b(:,j);
  aa = dd(j);
  
  xca = xc' * A * xa;
  
  phi = angle(xca - xa.'* conj(A) * conj(xc));  %    ala Horn + Johnson, Topics, p.25
  
  em = exp(-1i * phi);
  alphminusphi = real(exp(1i * phi) * xa' * A * xc + em * xca);
  
  t = real((-alphminusphi + sqrt(alphminusphi^2 - 4 * aa * cc)) / (2 * cc));
  
  bb = em * xa + t * xc;
  bb = bb / norm(bb);
  nsol = nsol + 1;
  bsol = [bsol bb];
  % err = norm(b' * A * b)
  
  if nsol >= colbmax
   return
  end
  
 end % for kk
end % for k




