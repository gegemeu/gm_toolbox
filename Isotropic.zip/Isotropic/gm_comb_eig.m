function [b,colb,bsol,colsol]=gm_comb_eig(ss,c1,c2,c3,X1,X2,X3,la1,la2,la3,b,colb,bsol,colsol,A,iref,icase);
%GM_COMB_EIG combines the 3 eigenvectors to find isotropic solutions

% This is an auxiliary function, not to be used directly

% c1, c2, c3 are the coefficients
% X1, X2, X3 are the eigenvectors
% when iref = 1 we try to find a solution with a zero imaginary or real part
% depending on icase (icase = 1 imaginary, icase = 0 real)
% for b' A b

%
% Author G. Meurant
% October 2009
% Updated August 2015
%

iprint = 0;

ss = ss(:);
npoint = size(ss,1);
colbfirst = colb + 1;

for k = 1:npoint
 % add to the previous solutions
 colb = colb + 1;
 bcol = c1(k) * X1 + c2(k) * X2 + c3(k) * X3;
 bcol = bcol / norm(bcol);
 b(:,colb) = bcol;
end
colblast = colb;

if iref == 1
 % look at the consecutive points parameterized by ss in [0,1]
 % compute the Rayleigh quotients
 ifv = zeros(npoint,1);
 col = colbfirst;
 for k = 1:npoint
  bcol = b(:,col);
  if icase == 1
   ifv(k) = imag(bcol' * A * bcol);
  else
   ifv(k) = real(bcol' * A * bcol);
  end
  col = col + 1;
 end
 
 % check if there is a point with a small enough imaginary (or real) part
 col = colbfirst;
 imax = max(abs(ifv));
 epsfv = 1e-10;
 for k = 1:npoint
  if abs(ifv(k)) <= epsfv*imax
   % this is a satisfactory solution
   colsol = colsol + 1;
   bsol(:,colsol) = b(:,col);
   if iprint == 1
    fprintf('\n gm_comb_eig: Directly found a solution, return \n\n')
   end
   return
  end
  col = col + 1;
 end
 
 % if no satisfactory solution, look for a change of sign
 % of the Rayleigh quotients
 
 if all(ifv > 0) || all(ifv < 0)
  % no solution
  if iprint == 1
   fprintf('\n gm_comb_eig: No solution, all Rayleigh quotients have the same sign \n\n')
  end
  return
 end
 
 % there is a change of sign
 ifvc = ifv(1);
 col = colbfirst;
 for k = 2:npoint
  % next point on the curve
  ifvnext = ifv(k);
  if ifvc*ifvnext < 0
   % sign change
   if iprint == 1
    fprintf('\n gm_comb_eig: Sign change, refine between points %d and %d \n\n',num2str(k-1),num2str(k))
   end
   colsol_old = colsol;
   [bsol,colsol] = gm_iso_refine(k-1,ss,c1,c2,c3,X1,X2,X3,la1,la2,la3,bsol,colsol,A,icase);
   if colsol == colsol_old && iprint == 1
    fprintf('\n gm_comb_eig: Problem, did not find a solution\n\n')
   end
   break
  end
  ifvc = ifvnext;
  col = col + 1;
 end
 
end



