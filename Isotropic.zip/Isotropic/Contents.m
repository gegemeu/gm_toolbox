% ISOTROPIC
%
% Files
%   gm_comb_eig                  - combines the 3 eigenvectors to find isotropic solutions
%   gm_Cvectinterpol             - find generators on great circle through vQ, vP
%   gm_find_isotropic            - computes an isotropic vector: a solution to b' A b = 0
%   gm_find_isotropic_2eig       - finds isotropic vectors using 2 eigenvectors
%   gm_find_isotropic_3eig       - finds isotropic vectors using 3 eigenvectors
%   gm_find_isotropic_mu         - computes a solution to b' A b = mu
%   gm_find_isotropic_real       - computes a real solution to b' A b = 0
%   gm_find_multi_isotropic      - finds several isotropic vectors: solutions to b'A b = 0
%   gm_find_multi_isotropic_mu   - computes solutions to b' A b = mu
%   gm_find_multi_isotropic_real - finds real solutions to b'A b = 0
%   gm_invfovCPU                 - computes an isotropic vector (if u = 0)
%   gm_iso_refine                - finds a solution with a parameter between ss(k) and ss(k+1)
%   gm_isotropic                 - computes an isotropic vector for A, x' A x = 0
%   gm_isotropic_mu              - computes an isotropic vector for A, x' A x = mu
