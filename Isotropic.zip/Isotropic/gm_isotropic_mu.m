function x = gm_isotropic_mu(A,mu);
%GM_ISOTROPIC_MU computes an isotropic vector for A, x' A x = mu

% to get a solution mu has to be in the field of values of A

% Input:
% A = matrix (must be real)
%
% Output:
% x = isotropic vector

%
% Author G. Meurant
% Updated August 2015
%

n = size(A,1);

A = A - mu * eye(n,n);

x = gm_isotropic(A);


