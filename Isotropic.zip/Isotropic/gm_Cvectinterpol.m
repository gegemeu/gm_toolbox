function X = gm_Cvectinterpol(A,Q,vQ,P,vP,u)
%GM_CVECTINTERPOL finds generators on great circle through vQ, vP that create FOV points on the real axis

%
% code from F. Uhlig
% modified by G. Meurant to handle the case f = 0
% Updated August 2015
%

R = vQ' * A * vP + vP' * A * vQ;
R = [real(R),imag(R)];

q = Q(2);
r = R(2);
p = P(2);
f = p + q - r;
g = (r - 2 * p) / f; % ala Ch. Davis, 1971 Can Math Bull

if (g/2)^2 - p/f < 0     % first via tx + (1-t)y from x to y :
 error('gm_Cvectinterpol: One of H or K is definite and mu lies outside FOV(H + iK)')
end

if abs(f) > 1e-13
 del = g^2 - 4 * p / f;
 del = sqrt(del);
 t1 = (-g + del) / 2;
 t2 = (-g - del) / 2;
 x1 = t1 * vQ + (1 - t1) * vP;
 x1 = x1 / norm(x1);
 x2 = t2 * vQ + (1 - t2) * vP;
 x2 = x2 / norm(x2);
 X = [x1 x2];
else
 X = zeros(size(A,1),1);
end

