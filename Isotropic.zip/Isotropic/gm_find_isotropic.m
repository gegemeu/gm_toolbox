function b=gm_find_isotropic(A);
%GM_FIND_ISOTROPIC computes an isotropic vector: a solution to b' A b = 0

% to get a solution zero has to be in the field of values of A

% Caution, we compute all the eigenvalues of A. This may be costly if 
% A is large
% If A is symmetric, you may use gm_isotropic in that case

% Input:
% A = matrix (may be real or complex)
%
% Output:
% b = isotropic vector

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

n = size(A,1);

% complex matrix
icomp = 2;
if isreal(A)
 % real matrix
 icomp = 0;
end
if isreal(A / sqrt(-1))
 % purely imaginary matrix
 icomp = 1;
end
 
ii = sqrt(-1) / 2;

b = [];
dd = [];
pos = [];
neg = [];
colb = 0;

% check if A is real
if icomp == 0
 b = gm_find_isotropic_real(A);
 return
end

% check if A is imaginary
if icomp == 1
 b = gm_find_isotropic_real(sqrt(-1) * A);
 return
end

% A is complex

% use the skew-Hermitian part
useK = 1;

if useK == 1
 
 % eigenvectors of the skew-hermitian part
 
 K = -ii * (A - A'); % Skew-Hermitian part of A
 
 [X, D] = eig(full(K));

 lmbh = real(diag(D));
 k = [1:n];
 lmin = lmbh(1);
 lmax = lmbh(n);
 
 if lmin * lmax > 0
  fprintf('\n gm_find_isotropic: 0 is outside of the field of values of A \n\n')
  b = [];
  return
 end
 
 % consider pairs of eigenvalues (one < 0 and one > 0)
 % monitor the sign of b' * A * b
 
 ipos = find(lmbh > 0);
 ineg = find(lmbh < 0);
 lp = length(ipos);
 ln = length(ineg);
 lpos = lp;
 lneg = ln;
 
 if n >= 50
  % consider only 10 positive and negative eigenvalues
  lpos = min(lpos,10);
  lneg = min(lneg,10);
 end
 
 % consider the smallest and largest positive and negative eigenvalues
 lneg2 = fix(lneg / 2);
 lpos2 = fix(lpos / 2);
 indneg = [[1:lneg2] [(ln-lneg2):ln]];
 indpos = [[(lp-lpos2):lp] [1:lpos2]];
 oldsig = 0;
 colb = 0;
 istop = 0;
 for j = indneg
  % find a negative eigenvalue
  in = ineg(j);
  la1 = lmbh(in);
  % look for positive eigenvalues
  for kk = indpos
   ip = ipos(kk);
   la2 = lmbh(ip);
   % use that pair to generate a solution with zero imaginary part
   X1 = X(:,k(in));
   X2 = X(:,k(ip));
   bcol = sqrt(la2) * X1 + sqrt(-la1) * X2;
   bcol = bcol / norm(bcol);
   colb = colb + 1;
   b(:,colb) = bcol;
   bAb = real(bcol' * A * bcol);
   if abs(bAb) <= 1e-14
    % we have found a solution
    b = bcol;
    return
   end
   dd(colb) = bAb;
   sig = sign(bAb);
   if (oldsig ~= 0) && (sig ~= oldsig)
    % the sign has changed, stop
    istop = 1;
    break
   end % if
   oldsig = sig;
  end % for kk
  if istop == 1
   break
  end % if
 end % for j
 
 AA = A;
 XK = X;
 
 % extract two vectors with different signs
 
 pos = find(dd > 0);
 neg = find(dd < 0);
 
end % if useK

% use the Hermitian part
useH = 1;

if useH == 1
 
 if length(pos) == 0 || length(neg) == 0
  % try to use the Hermitian part
  H = (A + A') / 2;
  AA = sqrt(-1) * A;
  
  [XH, DH] = eig(full(H));
  
  % the eigenvalues of H are real
  lmbh = real(diag(DH));
  k = [1:n];
  lmin = lmbh(1);
  lmax = lmbh(n);
  
  if lmin * lmax > 0
   fprintf('\n gm_find_isotropic: 0 is outside of the field of values of A \n\n')
   b = [];
   return
  end
  
  % consider pairs of eigenvalues (one < 0 and one > 0)
  % monitor the sign of b' * A * b
  
  ipos = find(lmbh > 0);
  ineg = find(lmbh < 0);
  lp = length(ipos);
  lpos = lp;
  ln = length(ineg);
  lneg = ln;
  
  if n >= 50
   lpos = min(lpos,10);
   lneg = min(lneg,10);
  end
  
  % consider the smallest and largest positive and negative eigenvalues
  lneg2 = fix(lneg / 2);
  lpos2 = fix(lpos / 2);
  indneg = [[1:lneg2] [(ln-lneg2):ln]];
  indpos = [[(lp-lpos2):lp] [1:lpos2]];
  
  oldsig = 0;
  colbb = 0;
  stop = 0;
  for j = indneg
   % find a negative eigenvalue
   in = ineg(j);
   la1 = lmbh(in);
   % look for positive eigenvalues
   for kk = indpos
    ip = ipos(kk);
    la2 = lmbh(ip);
    % use that pair to generate a solution with zero imaginary part
    X1 = XH(:,k(in));
    X2 = XH(:,k(ip));
    bcol = sqrt(la2) * X1 + sqrt(-la1) * X2;
    bcol = bcol / norm(bcol);
    colbb = colbb + 1;
    bb(:,colbb) = bcol;
    bAb = real(bcol' * AA * bcol);
    if abs(bAb) <= 1e-14
     % we have found a solution
     b = bcol;
     return
    end
    ddd(colbb) = bAb;
    sig = sign(bAb);
    if (oldsig ~= 0) & (sig ~= oldsig)
     % the sign has changed, stop
     stop = 1;
     break
    end % if
    oldsig = sig;
   end % for kk
   if stop == 1
    break
   end % if
  end % for j
  
  % extract two vectors with different signs
  
  posH = find(ddd > 0);
  negH = find(ddd < 0);
  
  if length(posH) ~= 0 && length(negH) ~= 0
   % trying H has succeeded
   pos = posH;
   neg = negH;
   b = bb;
   dd = ddd;
  end
  
 end % if length
 
end % if useH

% use ellipses
useell = 1;

if useell == 1
 if length(pos) == 0 || length(neg) == 0
  if useH == 0
   H = (A + A') / 2;
   
   [XH, DH] = eig(full(H));
   
  end
  
  if useK == 0
   K = -ii * (A - A');
   
   [XK, DK] = eig(full(K));
   
   X = XK;
  end

  istop = 0;
  AA = A;
  % try using the ellipses
  ii = sqrt(-1);

  if n >= 50
   ln = min(n,10);
  else
   ln = n;
  end
  
  ln2 = fix(ln / 2);
  indkj = [1 n [2:ln2] [n-ln2:n-1]];
  for k = indkj
   y = XH(:,k);
   % find points with zero imaginary part (if any) for that ellipse
   for jj = indkj
    % here we try all the combinations of eigenvectors
    x = XK(:,jj);
    alp = imag(x' * H * x + ii * x' * K * x);
    bet = imag(y' * H * y + ii * y' * K * y);
    gam = imag(x' * H * y + ii * x' * K * y + y' * H * x + ii * y' * K * x);
    del = gam^2 - 4 * alp * bet;
    xp = [];
    xm = [];
    if del > 0
     tp = (-gam + sqrt(del)) / (2 * bet);
     tm = (-gam - sqrt(del)) / (2 * bet);
     tetp = atan(tp);
     tetm = atan(tm);
     xp = cos(tetp) * x + sin(tetp) * y;
     xp = xp / norm(xp);
     xm = cos(tetm) * x + sin(tetm) * y;
     xm = xm / norm(xm);
     zp = xp' * A * xp;
     zm = xm' * A * xm;
     if length(pos) == 0
      if real(zm) > 0
       colb = colb + 1;
       pos(1) = colb;
       b(:,colb) = xm;
       dd(colb) = real(zm);
       istop = 1;
       break
      end % if zm
      if real(zp) > 0
       colb = colb + 1;
       pos(1) = colb;
       b(:,colb) = xp;
       dd(colb) = real(zp);
       istop = 1;
       break
      end % if zp
     end % if length
     if length(neg) == 0
      if real(zm) < 0
       colb = colb + 1;
       neg(1) = colb;
       b(:,colb) = xm;
       dd(colb) = real(zm);
       istop = 1;
       break
      end % if zm
      if real(zp) < 0
       colb = colb + 1;
       neg(1) = colb;
       b(:,colb) = xp;
       dd(colb) = real(zp);
       istop = 1;
       break
      end % if zp
     end % if length
    end % if del
   end % for jj
   
   if istop == 1
    break
   end % if
   
  end % for k
  
 end % if length(pos)
 
end % if useell

if length(pos) == 0 || length(neg) == 0
 % We still do not have a solution
 AA = A;
 % Use the code from F. Uhlig to find a suitable vector
 % H and K and their eigenvectors have already been computed
 x1p = XH(:,n);
 x1n = XH(:,1);
 rM = x1p' * A * x1p;
 rM = [real(rM); imag(rM)];
 rm = x1n' * A * x1n;
 rm = [real(rm); imag(rm)];
 y1p = X(:,n);
 y1n = X(:,1);
 iM = y1p' * A * y1p;
 iM = [real(iM); imag(iM)];
 im = y1n' * A * y1n;
 im = [real(im); imag(im)];
 
 XX = gm_Cvectinterpol(A,iM,y1p,im,y1n,0); % iM-im segment

 if rm(2) < 0
  Y = gm_Cvectinterpol(A,iM,y1p,rm,x1n,0); % iM-rm segment
  XX = [XX Y];
 else
  Y = gm_Cvectinterpol(A,im,y1n,rm,x1n,0); % im-rm segment
  XX = [XX Y];
 end
 if rM(2) < 0
  Y = gm_Cvectinterpol(A,iM,y1p,rM,x1p,0); % iM-rM segment
  XX = [XX Y];
 else
  Y = gm_Cvectinterpol(A,im,y1n,rM,x1p,0); % im-rM segment
  XX = [XX Y];
 end
 if rm(2)*rM(2) < 0
  Y = gm_Cvectinterpol(A,rm,x1n,rM,x1p,0); % rm-rM segment
  XX = [XX Y];
 end
 xAx = real(diag(XX' * A * XX));
 
 pos = [];
 neg = [];
 
 pos1 = find(xAx > 0);
 if length(pos1) > 0
  bcol = XX(:,pos1(1));
  bcol = bcol / norm(bcol);
  colb = colb + 1;
  b(:,colb) = bcol;
  dd(colb) = xAx(pos1(1));
  pos(1) = colb;
 end

 neg1 = find(xAx < 0);
 if length(neg1) > 0
  bcol = XX(:,neg1(1));
  bcol = bcol / norm(bcol);
  colb = colb + 1;
  b(:,colb) = bcol;
  dd(colb) = xAx(neg1(1));
  neg(1) = colb;
 end

end % if length

% in case it did not work, use F. Uhlig's code
if length(pos) == 0 || length(neg) == 0
 fprintf('gm_find_isotropic: Did not find different signs, switch to gm_invfovCPU')

 [b,err,step] = gm_invfovCPU(A,0,0,0);
 return
end

i = pos(1);
xc = b(:,i);
cc = dd(i);
j = neg(1);
xa = b(:,j);
aa = dd(j);

xca = xc' * AA * xa;

phi = angle(xca - xa.'* conj(AA) * conj(xc));  

em = exp(-1i * phi);
alphminusphi = real(exp(1i * phi) * xa' * AA * xc + em * xca);

t = real((-alphminusphi + sqrt(alphminusphi^2 - 4 * aa * cc)) / (2 * cc));

b = em * xa + t * xc;
b = b / norm(b);




