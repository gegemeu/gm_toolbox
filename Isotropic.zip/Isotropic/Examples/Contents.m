% EXAMPLES
%
% Files
%   gm_Ex_isotropic_real - Examples of computation of isotropic vectors
