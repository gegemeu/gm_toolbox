% Examples of computation of isotropic vectors

% Non symmetric real matrices

% choose the example
% we may shift the matrix to have zero in the field of values

ii = sqrt(-1);

mat = 4;

switch mat
 
 case 1
  Ex = 'gm_supg001_225';
  shift = -0.06;
  target = 0.08 + 0.02 * ii;
  
 case 2
  
  % there are zeros on the diagonal of this matrix
  Ex = 'gm_e05r0500_236';
  shift = 0;
  target = 15 + 10 * ii;
  
 case 3
  
  Ex = 'gm_fs_6_183';
  shift = -2;
  target = 4 + ii;
  
 case 4
  
  Ex = 'gm_pde225_225';
  shift = -4;
  target = 5 + 2 * ii;
  
 case 5
  
  Ex = 'gm_steam1_240';
  shift = 0.5;
  target = -0.5e7 + 1000 * ii;
  
 case 6
  
  % there are zeros on the diagonal of this matrix
  Ex = 'gm_west0_167';
  shift = 0;
  target = 100 * ii;
  
end

% you may have to change the path
file = ['C:\D\new_mfiles\gm_toolbox\Matrices\Non_symmetric\' Ex];

load(file)

AA = A;

fprintf(['\n ' Ex ' \n'])

n = size(A,1);
nnzA = nnz(A);

fprintf('\n Order of A = %5d, number of non zeros = %6d \n',n,nnzA)

% shift the matrix
A = A + shift * eye(n,n);

fprintf('\n Real matrix, shift = %g \n',shift)

% compute one isotropic vector for a real matrix

tic
b = gm_find_isotropic_real(A);
t = toc;

bAb = b' * A * b;

fprintf('\n gm_find_isotropic_real: Norm of b = %g, value of b^T A b = %g, time = %g \n',norm(b),bAb,t)

% F. Uhlig's code

tic
[x,err,step] = gm_invfovCPU(A,0,0,0);
t = toc;

bAb = x' * A * x;

fprintf('\n gm_invfovCPU from F. Uhlig: Norm of b = %g, value of b^T A b = %g, time = %g \n\n',norm(x),bAb,t)

% compute several isotropic vectors

% number of solitions to be computed
nsolmax = 5;

tic
[bsol,nsol] = gm_find_multi_isotropic_real(A,nsolmax);
t = toc;

fprintf(' gm_find_multi_isotropic_real: Number of solutions found = %d, time = %g \n\n',nsol,t)

for k = 1:nsol
 bAb = bsol(:,k)' * A * bsol(:,k);
 fprintf(' solution %d, norm of b = %g, value of b^T A b = %g \n',k,norm(bsol(:,k)),bAb)
end

% complex target

% compute one isotropic vector 

fprintf('\n\n Target = %g + %g i \n',real(target),imag(target))

tic
b = gm_find_isotropic_mu(AA,target);
t = toc;

bAb = target - b' * AA * b;
rel = abs(bAb) / abs(target);

fprintf('\n gm_find_isotropic_mu: Norm of b = %g, error for f b^T A b = %g + %g i, relative error = %g, time = %g \n',...
 norm(b),real(bAb),rel,imag(bAb),t)

% F. Uhlig's code

tic
[x,err,step] = gm_invfovCPU(AA,target,0,0);
t = toc;

bAb = target - x' * AA * x;
rel = abs(bAb) / abs(target);

fprintf('\n gm_invfovCPU from F. Uhlig: Norm of b = %g, error for b^T A b = %g + %g i, relative error = %g, time = %g \n\n',...
 norm(x),real(bAb),imag(bAb),rel,t)

if mat == 3 || mat == 4 || mat == 6
 % compute several isotropic vectors
 
 % number of solutions to be computed
 nsolmax = 5;
 
 tic
 [bsol,nsol] = gm_find_multi_isotropic_mu(AA,nsolmax,target);
 t = toc;
 
 fprintf(' gm_find_multi_isotropic_mu: Number of solutions found = %d, time = %g \n\n',nsol,t)
 
 for k = 1:nsol
  bAb = target - bsol(:,k)' * AA * bsol(:,k);
  rel = abs(bAb) / abs(target);
  fprintf(' solution %d, norm of b = %g, error for b^T A b = %g + %g i, relative error = %g \n',...
   k,norm(bsol(:,k)),real(bAb),imag(bAb),rel)
 end
 
end




