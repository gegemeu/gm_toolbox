function b=gm_find_isotropic_real(A);
%GM_FIND_ISOTROPIC_REAL computes a real solution to b' A b = 0

% to get a solution zero has to be in the field of values of A

% Caution, we compute all the eigenvalues of A. This may be costly if 
% A is large
% If A is symmetric, you may use gm_isotropic in that case

% Input:
% A = matrix (must be real)
%
% Output:
% b = isotropic vector

%
% Author G. Meurant
% October 2009
% Updated August 2015
%


n = size(A,1);

if any(imag(A(:)))
 error('gm_find_isotropic_real: A must b a real matrix')
end

% Hermitian part of A
H = 0.5 * (A + A'); 

[X, D] = eig(full(H));

[lmbh, k] = sort(real(diag(D)));
lmin = lmbh(1);
lmax = lmbh(n);
kmin = k(1);
kmax = k(n);

if lmin * lmax > 0
 error('gm_find_isotropic_real: 0 is outside of the field of values of A')
end

X1 = X(:,kmin);
X2 = X(:,kmax);

% interpolate between the 2 eigenvectors
b = sqrt(lmax) * X1 + sqrt(-lmin) * X2;
b = b / norm(b);

