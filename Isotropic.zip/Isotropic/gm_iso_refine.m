function [bsol,colsol]=gm_iso_refine(k,ss,c1,c2,c3,X1,X2,X3,la1,la2,la3,bsol,colsol,A,icase);
%GM_ISO_REFINE finds a solution with a parameter between ss(k) and ss(k+1)

% This is an auxiliary function, not to be used directly

%
% Author G. Meurant
% October 2009
% Updated August 2015
%

iprint = 0;

% maximum number of tries
irefmax = 20;

% number of discretization points
npoint = length(ss);

if k >= npoint
 fprintf('\n gm_iso_refine: Problem of dimension \n\n')
end

smin = ss(k);
smax = ss(k+1);

iref = irefmax;

% recompute the initial end points of the segment
% intersection points with the two axis
x1 = la3 / (la3 - la1);
y1 = 0;
y2 = la3 / (la3 - la2);
x2 = 0;

% there are two cases to consider

% case 1: la1 < 0 < la2 < la3
% then y2 > 1

% case 2: la1 < la2 < 0 < la3
% then y2 < 1

if y2 >= 1
 p = la2 / (la2 - la1);
 q = -la1 / (la2 - la1);
else
 p = 0;
 q = y2;
end

t1min = x1;
t2min = x2;
t1max = p;
t2max = q;

ss = linspace(0,1,npoint);

while iref > 0
 if iprint == 1
  fprintf('gm_iso_refine: Refinement----------------%d \n',num2str(irefmax-iref+1))
 end
 
 dist = sqrt((t1max - t1min)^2 + (t2max - t2min)^2);
 ds = dist / (npoint - 1);
 fv = zeros(npoint,1);
 c1 = fv;
 c2 = fv;
 c3 = fv;
 
 for k = 1:npoint
  sk = ss(k);
  % point on the segment
  t1 = (1 - sk) * t1min + sk * t1max;
  t2 = (1 - sk) * t2min + sk * t2max;
  % third coordinate
  t3 = 1 - t1 - t2;
  c1(k) = sqrt(t1);
  c2(k) = sqrt(t2);
  c3(k) = sqrt(t3);
 end
 
 % combine the eigenvectors
 for k = 1:npoint
  bcol = c1(k) * X1 + c2(k) * X2 + c3(k) * X3;
  bcol = bcol / norm(bcol);
  if icase == 1
   ifv(k) = imag(bcol' * A * bcol);
  else
   ifv(k) = real(bcol' * A * bcol);
  end
 end
 
 if iref == irefmax
  imax = max(abs(ifv));
 end
 epsfv = 1e-10;
 
 minfv = realmax;
 ifvc = ifv(1);
 for k = 2:npoint
  % next point on the curve
  ifvnext = ifv(k);
  minfv = min([minfv abs(ifvc) abs(ifvnext)]);
  if ifvc*ifvnext <= 0
   if iprint == 1
    fprintf('gm_iso_refine: Sign change in refinement, segment [%d, %d], %d \n\n',num2str(k-1),num2str(k),num2str(abs(ifvnext-ifvc)))
   end
   % sign change
   % look if ifv is small enough
   if abs(ifvc) <= epsfv*imax
    % take this one
    bcol = c1(k-1) * X1 + c2(k-1) * X2 + c3(k-1) * X3;
    bcol = bcol / norm(bcol);
    colsol = colsol + 1;
    bsol(:,colsol) = bcol;
    if iprint == 1
     fprintf('\n gm_iso_refine: Solution found by refinement, level %d \n\n',num2str(irefmax-iref+1))
    end
    return
   elseif abs(ifvnext) <= epsfv*imax
    % take this one
    bcol = c1(k) * X1 + c2(k) * X2 + c3(k) * X3;
    bcol = bcol / norm(bcol);
    colsol = colsol + 1;
    bsol(:,colsol) = bcol;
    if iprint == 1
     fprintf('\n gm_iso_refine: Solution found by refinement, level %d \n\n',num2str(irefmax-iref+1))
    end
    return
   else
    % no satisfactory solution yet, go to the next level
    sk = ss(k-1);
    % point on the segment
    t1mi = (1 - sk) * t1min + sk * t1max;
    t2mi = (1 - sk) * t2min + sk * t2max;
    sk = ss(k);
    % point on the segment
    t1ma = (1 - sk) * t1min + sk * t1max;
    t2ma = (1 - sk) * t2min + sk * t2max;
    t1min = t1mi;
    t1max = t1ma;
    t2min = t2mi;
    t2max = t2ma;
    t3min = 1 - t1min - t2min;
    t3max = 1 - t1max - t2max;
    c1min = sqrt(t1min);
    c2min = sqrt(t2min);
    c3min = sqrt(t3min);
    bcol = c1min * X1 + c2min * X2 + c3min * X3;
    bcol = bcol / norm(bcol);
    ifvmin = imag(bcol' * A * bcol);
    c1max = sqrt(t1max);
    c2max = sqrt(t2max);
    c3max = sqrt(t3max);
    bcol = c1max * X1 + c2max * X2 + c3max * X3;
    bcol = bcol / norm(bcol);
    ifvmax = imag(bcol' * A * bcol);
    if iprint == 1
     fprintf('\n gm_iso_refine: Go to the next level \n\n')
    end
    break
   end
  end
  
  ifvc = ifvnext;
 end
 
 iref = iref - 1;
end
