function [b,colb,bAb] = gm_find_isotropic_2eig(la1,la2,X1,X2,b,colb,A);
%GM_FIND_ISOTROPIC_2EIG finds isotropic vectors using 2 eigenvectors

% This is an auxiliary function, not to be used directly

% lai (resp. Xi) are the eigenvalues (resp. eigenvectors)
% la1 is negative and la2 positive

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

% use the pair of eigenvalues to generate a solution
% using the eigenvectors

bcol = sqrt(la2) * X1 + sqrt(-la1) * X2;
bcol = bcol / norm(bcol);
colb = colb + 1;
b(:,colb) = bcol;
bAb = bcol' * A * bcol;




