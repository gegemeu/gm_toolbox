function [b,nsol]=gm_find_multi_isotropic_real(A,colbmax);
%GM_FIND_MULTI_ISOTROPIC_REAL finds real solutions to b'A b = 0

% this version eventually finds more than one solution

% to get solutions zero has to be in the field of values of A

% Caution, we compute all the eigenvalues of A. This may be costly if 
% A is large
% If A is symmetric, you may use gm_isotropic in that case

% Input:
% A = matrix (must be real)
% colbmax = maximum number of isotropic vector to be computed
%
% Output:
% b = isotropic vectors
% nsol = number of solutions found

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

n=size(A,1);

if any(imag(A(:)))
 error('gm_find__multi_isotropic_real: A must b a real matrix')
end

% Hermitian part of A
H = 0.5 * (A + A');    

[X, D] = eig(full(H));
lmbh = diag(D);
k = [1:n];

lmin = lmbh(1);
lmax = lmbh(n);
if lmin*lmax > 0
 error('gm_find__multi_isotropic_real: 0 is outside of the field of values of A')
end
colb = 0;
b = [];

ipos = find(lmbh > 0);
ineg = find(lmbh < 0);

lpos = length(ipos);
lneg = length(ineg);

% consider pairs of eigenvalues (one < 0 and one > 0)
% start with the first one for negative and the
% last one for positive eigenvalues

for j = 1:lpos
 la2 = lmbh(ipos(j));
 for kk = lneg:-1:1
  la1 = lmbh(ineg(kk));
  % use that pair to generate a solution
  X2 = X(:,k(ipos(j)));
  X1 = X(:,k(ineg(kk)));
  % use the pair of eigenvalues to generate a solution
  % using the eigenvectors
  bcol = sqrt(la2) * X1 + sqrt(-la1) * X2;
  bcol = bcol / norm(bcol);
  colb = colb + 1;
  % check if we have the max number of solutions
  if colb > colbmax
   break
  end
  b(:,colb) = bcol;
  % change the sign
  bcol = -sqrt(la2) * X1 + sqrt(-la1) * X2;
  bcol = bcol / norm(bcol);
  colb = colb + 1;
  if colb > colbmax
   break
  end
  b(:,colb) = bcol;
 end % for kk
 if colb >= colbmax
  break
 end
end % for j

if colb >= colbmax
 nsol = size(b,2);
 return
end

% if we do not have enough solutions, consider triples of eigenvalues
for j = 1:lneg-1
 % la1 is negative
 in = ineg(j);
 la1 = lmbh(in);
 la2 = lmbh(in + 1);
 for kk = 1:lpos
  ip = ipos(kk);
  la3 = lmbh(ip);
  X1 = X(:,k(in));
  X2 = X(:,k(in + 1));
  X3 = X(:,k(ip));
  % npoint is the number of discretization points on the segment of interest
  npoint = 10;
  [b,colb] = gm_find_isotropic_3eig(la1,la2,la3,X1,X2,X3,npoint,b,colb,A,0,[],0,1);
  if colb >= colbmax
   break
  end % if
 end % for kk
 if colb >= colbmax
  break
 end % if
end % for j

if size(b,2) == 0
 warning('gm_find__multi_isotropic_real: Did not find different signs, switch to invfovCPU')
 [b,err,step] = gm_invfovCPU(A,0,0,0);
 return
end

nsol = size(b,2);



