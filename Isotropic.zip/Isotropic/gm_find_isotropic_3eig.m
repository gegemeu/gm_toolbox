function [b,colb,bsol,colsol]=gm_find_isotropic_3eig(la1,la2,la3,X1,X2,X3,npoint,b,colb,A,iref,bsol,colsol,icase);
%GM_FIND_ISOTROPIC_3EIG finds isotropic vectors using 3 eigenvectors

% This is an auxiliary function, not to be used directly

% lai (resp. Xi) are the eigenvalues (resp. eigenvectors)
% la1 is negative and the eigenvalues have to be ordered before

%
% Author G. Meurant
% October 2009
% Updated August 2015
%

if la1 >= 0
  error('gm_find_isotropic_3eig: The first eigenvalue la1 has to be negative')
end

% intersection points with the two axis
x1 = la3 / (la3 - la1);
y2 = la3 / (la3 - la2);

% there are two cases to consider

% case 1: la1 < 0 < la2 < la3
% then y2 > 1

% case 2: la1 < la2 < 0 < la3
% then y2 < 1

if y2  >= 1
  p = la2 / (la2 - la1);
  q = -la1 / (la2 - la1);
else
  p = 0;
  q = y2;
end

% now we have the ends of the segment to consider
% from (x1,0) to (p,q)

ds = 1 / (npoint - 1);
ss = zeros(npoint,1);
fv = ss;
c1 = ss;
c2 = ss;
c3 = ss;

for k = 1:npoint
  s = (k - 1) * ds;
  ss(k) = s;
  % point on the segment
  t1 = (1 - s) * x1 + s * p;
  if t1 < 0 | t1 > 1
    disp('gm_find_isotropic_3eig: Error in the computation of t1')
  end
  t2 = s * q;
  if t2 < 0 | t2 > 1
    disp('gm_find_isotropic_3eig: Error in the computation of t2')
  end
  % third coordinate
  t3 = 1 - t1 - t2;
  if t3 < 0 || t3 > 1
    disp('gm_find_isotropic_3eig: Error in the computation of t3')
  end
  c1(k) = sqrt(t1);
  c2(k) = sqrt(t2);
  c3(k) = sqrt(t3);
end

% combine the eigenvectors

[b,colb,bsol,colsol] = gm_comb_eig(ss,c1,c2,c3,X1,X2,X3,la1,la2,la3,b,colb,bsol,colsol,A,iref,icase);
 











