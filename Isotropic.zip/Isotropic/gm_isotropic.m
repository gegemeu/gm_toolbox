function x = gm_isotropic(A);
%GM_ISOTROPIC computes an isotropic vector for A, x' A x = 0

% to get a solution zero has to be in the field of values of A

% Input:
% A = matrix (must be real)
%
% Output:
% x = isotropic vector

%
% Author G. Meurant
% Updated August 2015
%


[L,D,P,rho,ncomp] = gm_ldlt_symm(A,'p');
% can use ldl in later versions of Matlab

n = size(A,1);

% do we have 2 x 2 blocks in D?
ind = find(diag(D,1),1);

if ~isempty(ind)
 % at least one 2 x 2 block which is non definite
 ind1 = ind;
 ind2 = ind + 1;
else
 % D is diagonal, take two entries with different signs
 ind1 = find(diag(D) > 0,1);
 ind2 = find(diag(D) < 0,1);
 if isempty(ind1) || isempty(ind2)
  % the matrix is definite, there is no solution
  x = [];
  return
 end
end

% compute for the 2 x 2 matrix
w = isotropic2(D([ind1 ind2],[ind1 ind2]));
t = zeros(n,1);
t([ind1 ind2]) = w;
x = P * (L' \ t);

end

function x=isotropic2(A);
% case of a 2 x 2 indefinite matrix

[W,D] = eig(A);

p = W(:,1)' * A * W(:,2);
a = (-p + sqrt(p^2 - D(1,1) * D(2,2))) / D(2,2);
x = W(:,1) + a * W(:,2);
x = x / norm(x);

end
