function b = gm_find_isotropic_mu(A,mu);
%GM_FIND_ISOTROPIC_MU computes a solution to b' A b = mu

% to get a solution mu has to be in the field of values of A

% Caution, we compute all the eigenvalues of A - mu I. This may be costly if A is large
% If A is symmetric, you may use gm_isotropic_mu in that case

% Input:
% A = matrix (may be real or complex)
% mu = target value for b' A b
%
% Output:
% b = vector such that b' A b = mu

%
% Author G. Meurant
% March 2011
% Updated August 2015
%

n = size(A,1);

A = A - mu * eye(n,n);

b = gm_find_isotropic(A);

