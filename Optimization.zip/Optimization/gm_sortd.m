function [d,v]=gm_sortd(dd,vv);
%GM_SORTD sorts dd in descending order and sorts the columns of v accordingly

%
% Author G. Meurant
% March 2007
% Updated August 2015
%

% ascending order

[ddd,ind] = sort(dd);
n = length(dd);
ind = ind(n:-1:1);
d = dd(ind);
v = vv(:,ind);