function [fli,nf]=gm_flin(n,j,l,f,x,nf,v,q0,q1);
%GM_FLIN is the function of one variable to be minimized by gm_minny

% The scalar function F(X), where X is an N dimensional vector is  minimized along a
% fixed line

% See: Richard Brent, Algorithms for Minimization without Derivatives,
%                       Prentice Hall, 1973, Reprinted by Dover, 2002

% Input:
%    n = number of variables
%    j = indicates the kind of search
%        If J is nonzero, then the search is linear in the direction of V(*,J)
%        If J is zero, then the search is parabolic, based on X, Q0 and Q1
%    l =  parameter determining the particular point at which F is to be evaluated
%         For a linear search (J is nonzero), L is the size of the step
%         along the direction V(*,J)
%         For a quadratic search (J is zero), L is a parameter which specifies
%         a point in the plane of X, Q0 and Q1
%    f = name of the function to be minimized
%    x = the base point of the search
%    nf = the function evaluation counter
%    v = a matrix whose columns constitute search directions
%        If J is nonzero, then a linear search is being
%        carried out in the direction of V(*,J)
%    q0, q1 = two auxiliary points used to determine the plane
%             when a quadratic search is performed
%
% Output:
%    fli = value of the function at the given point
%    nf = number of function evaluations

%
% translated from Fortran to Matlab by G. Meurant
% March 2007
% Updated August 2015
%


global qa qb qc qd0 qd1 qf1;
global xpr_opt fpr_opt;

if isempty(l)
 t(1:n) = x(1:n);
end

if  j ~= 0

 %  The search is linear
 if isempty(l)
  t(1:n) = x(1:n);
 else
  t(1:n) = x(1:n) + l * v(1:n,j)';
 end % if isempty
 
else

 %  The search is along a parabolic space curve
 qa = (l * (l - qd1)) / (qd0 * (qd0 + qd1));
 qb = ((l + qd0) * (qd1 - l)) / (qd0 * qd1);
 qc = (l * (l + qd0)) / (qd1 * (qd0 + qd1));
 
 t(1:n) = qa * q0(1:n) + qb * x(1:n) + qc * q1(1:n);
 
end % if j

%  The function evaluation counter nf is incremented
nf = nf + 1;

%  Evaluate the function
fli = feval(f,t);

if fli < fpr_opt
 xpr_opt = t;
 fpr_opt = fli;
end % if fli



