function [d2,x1,f1,x,nf]=gm_minny(n,j,nits,d2,x1,f1,fk,f,x,t,h,v,q0,q1,nf);
%GM_MINNY minimizes a scalar function of N variables along a line

%    GM_MINNY minimizes F along the line from X in the direction V(*,J) unless
%    J is less than 1, when a quadratic search is made in the plane
%    defined by q0,q1,x
%
%    If fk = .true., then f1 is flin(x1).  Otherwise x1 and f1 are ignored
%    on entry unless final fx is greater than f1

% See: Richard Brent, Algorithms for Minimization without Derivatives,
%                       Prentice Hall, 1973, Reprinted by Dover, 2002

% Input:
%    n = number of variables
%    j = indicates the kind of search
%        If J is positive, then the search is linear in the direction of V(*,J)
%        If J is zero, then the search is parabolic, based on X, Q0 and Q1
%    nits =  maximum number of times the interval may be halved
%            to retry the calculation
%    d2 = either zero, or an approximation to the value of (1/2) times
%         the second derivative of F
%    x1 =  an estimate of the distance from X to the minimum
%          along V(*,J), or, if J = 0, a curve
%    f1 = value at x1
%    fk = if fk is TRUE, then on input F1 contains the value FLIN(X1)
%    f = name of the function to be minimized
%    x, t, h = see gm_praxis
%    v = a matrix whose columns are direction
%       vectors along which the function may be minimized
%    q0, q1 = two auxiliary points used to determine the plane
%             when a quadratic search is performed
%    nf = number of function evaluations
%
% Output:
%    same as the inputs but updated
%    x1 = the distance between X and the minimizer that was found

%
% translated from Fortran to Matlab by G. Meurant
% March 2007
% Updated August 2015
%

global fx ldt dmin nl;
global qa qb qc qd0 qd1 qf1;
global xpr_opt fpr_opt;

machep = eps;
small = machep^2;
m2 = sqrt(machep);
m4 = sqrt(m2);
sf1 = f1;
sx1 = x1;
k = 0;
xm = 0;
fm = fx;
f0 = fx;
dz =  d2 < machep;

%  Find the step size
s = sqrt(sum(x(1:n).^2));

if  dz
 temp = dmin;
else
 temp = d2;
end  % if dz

t2 = m4 * sqrt(abs(fx) / temp + s * ldt) + m2 * ldt;
s = m4 * s + t;
if  dz && s < t2
 t2 = s;
end  % if dz

t2 = max(t2,small);
t2 = min(t2,0.01* h);

if  fk && f1 <= fm
 xm = x1;
 fm = f1;
end %  if fk

if ~fk || abs(x1) < t2
 
 if  0 <= x1
  temp = 1;
 else
  temp = - 1;
 end % if 0
 
 x1 = temp * t2;
 [f1,nf] = gm_flin(n,j,x1,f,x,nf,v,q0,q1);
 
end % if ~fk

if  f1 <= fm
 xm = x1;
 fm = f1;
end % if f1

%  Evaluate FLIN at another point and estimate the second derivative
i4=0;
while i4 == 0
 
 if  dz
  
  if  f1 <= f0
   x2 = 2 * x1;
  else
   x2 = - x1;
  end % if f1
  
  [f2,nf] = gm_flin(n,j,x2,f,x,nf,v,q0,q1);
  
  if  f2 <= fm
   xm = x2;
   fm = f2;
  end  % if f2
  
  d2 = (x2 * (f1 - f0) - x1 * (f2 - f0)) / ((x1 * x2) * (x1 - x2));
  
 end % if dz

 %  Estimate the first derivative at 0
 d1 = (f1 - f0) / x1 - x1 * d2;
 dz=1;

 %  Predict the minimum

 if  d2 <= small
  
  if  0 <= d1
   x2 = - h;
  else
   x2 = h;
  end % if 0
  
 else
  
  x2 = (-0.5 * d1) / d2;
  
 end % if d2
 
 if  h < abs(x2)
  
  if  x2 <= 0
   x2 = - h;
  else
   x2 = h;
  end % if x2
  
 end % if h

 %  Evaluate F at the predicted minimum

 ido = 0;
 while ido == 0
  
  [f2,nf] = gm_flin(n,j,x2,f,x,nf,v,q0,q1);
  
  if  nits <= k || f2 <= f0
   ido = 1;
   i4 = 1;
   break
  end % if nits
  
  k = k + 1;
  
  if  f0 < f1 && 0 < x1 * x2
   i4 = 0;
  else
   i4 = 1;
  end % if f0
  
  x2 = 0.5 * x2;
  
 end % while ido
 
end % while i4

%  Increment the one-dimensional search counter
nl = nl + 1;

if  fm < f2
 x2 = xm;
else
 fm = f2;
end % if fm

%  Get a new estimate of the second derivative
if  small < abs(x2 * (x2 - x1))
 d2 = (x2 * (f1 - f0) - x1 * (fm - f0)) / ((x1 * x2) * (x1 - x2));
else
 if  0 < k
  d2 = 0;
 end % if 0
end % if small

d2 = max(d2,small);

x1 = x2;
fx = fm;

if  sf1 < fx
 fx = sf1;
 x1 = sx1;
end % if sf1

%  Update X for linear but not parabolic search
if  j ~= 0
 
 x(1:n) = x(1:n) + x1 * v(1:n,j)';
 
end % if j


