function [x,prax,iter,nf,exitflag]=gm_praxis(epss,t0,h0,n,x,f,itermax,nfmax);
%GM_PRAXIS seeks an N-dimensional minimizer X of a scalar function F(X)

%    PRAXIS returns the minimum of the function F(X,N) of N variables
%    using the principal axis method.  The gradient of the function is
%    not required
%
%    The approximating quadratic form is
%
%      Q(x') = F(x,n) + (1/2) * (x'-x)' * A * (x'-x)
%
%    where X is the best estimate of the minimum and
%
%      A = inverse(V') * D * inverse(V)
%
%    V(*,*) is the matrix of search directions;
%    D(*) is the array of second differences.
%
%    If F(X) has continuous second derivatives near X0, then A will tend
%    to the hessian of F at X0 as X approaches X0.

% See: Richard Brent, Algorithms for Minimization without Derivatives,
%                       Prentice Hall, 1973, Reprinted by Dover, 2002

%
% Input:
% epss = stopping criteria on the relative difference of the
%        objective function
% t0 = tolerance.  PRAXIS attempts to return
%      praxis = f(x) such that if X0 is the true local minimum near X, then
%      norm ( x - x0 ) < T0 + sqrt ( EPSILON(X) ) * norm ( X ),
%      where EPSILON(X) is the machine precision for X
% h0 =  maximum step size.  h0 should be
%      set to about the maximum distance from the initial guess to the minimum.
%      If h0 is set too large or too small, the initial rate of
%      convergence may be slow
% n = number of variables
% x = initial guess
% f = name of the function to be minimized
% itermax = maximum number of iterations
% nfmax = maximum number of function evaluations (approximately)
%
%
% Output:
% x = minimizer
% prax = value of the function at the minimizer
% iter = number of iterations
% nf = number of function evaluations
% exitflag = error code

%
% translated from Fortran to Matlab by G. Meurant
% March 2007
% modifications (stopping criteria) June 2014
% Updated August 2015
%


global fx ldt dmin nl;
global qa qb qc qd0 qd1 qf1;
global nfparm;
global xpr_opt fpr_opt

if nargin <= 6
 itermax = 50;
end
iter = 0;
exitflag = 0;
% approximate maximum number of function evaluations
if nargin <= 7
 nfmax = 3000;
 %  nfmax = 1500;
end
nfparm = 0;

% ---------------------------Initialization

% s = RandStream('mt19937ar','Seed', 5489);
% if one does not work, try the other one!
%RandStream.setDefaultStream(s);
%  RandStream.setGlobalStream(s);
rng('default');

machep = eps;
small = machep * machep;
vsmall = small * small;
large = 1 / small;
vlarge = 1 / vsmall;
m2 = sqrt ( machep );
m4 = sqrt ( m2 );

%  Heuristic numbers:

%  If the axes may be badly scaled (which is to be avoided if
%  possible), then set SCBD = 10.  Otherwise set SCBD = 1
%
%  If the problem is known to be ill-conditioned, initialize ILLC = true
%
%  KTM is the number of iterations without improvement before the
%  algorithm terminates.  KTM = 4 is very cautious; usually KTM = 1
%  is satisfactory
%

x = x(1:n);

xpr_opt = x;
fpr_opt = 1e17;
prax_old = 1e17;

scbd = 1;
%illc = .false.
illc = 0;
ktm = 1;

if  illc
 ldfac = 0.1;
else
 ldfac = 0.01;
end % if illc

kt = 0;
nl = 0;
nf = 1;

xpr_opt_old = xpr_opt;
fpr_opt_old = fpr_opt;

fx = feval(f,x);

xpr_opt = xpr_opt_old;
fpr_opt = fpr_opt_old;

if fx  < fpr_opt
 xpr_opt = x;
 fpr_opt = fx;
end
qf1 = fx;
t = small + abs (t0);
t2 = t;
dmin = small;
h = h0;
h = max (h, 100 * t);
ldt = h;

%  The initial set of search directions V is the identity matrix
v = eye(n,n);

d(1) = 0;
qd0 = 0;
q0(1:n) = x(1:n);
q1(1:n) = x(1:n);

%  ------------------------------The main loop starts here

imain = 0;
while imain == 0
 
 iter = iter + 1;
 
 if iter > itermax || nf > nfmax
  exitflag = 1;
  nf = nf + nfparm;
  xpr_opt_old = xpr_opt;
  fpr_opt_old = fpr_opt;
  
  prax = feval(f,x);
  
  xpr_opt = xpr_opt_old;
  fpr_opt = fpr_opt_old;
  
  if fpr_opt < prax
   % restore the optimal solution
   x = xpr_opt;
   prax = fpr_opt;
  end % if fpr
  return
 end % if iter
 
 sf = d(1);
 d(1) = 0;
 s = 0;
 
 %  Minimize along the first direction v(*,1)
 
 nits = 2;
 value = fx;
 
 xpr_opt_old = xpr_opt;
 fpr_opt_old = fpr_opt;
 
 [d(1),s,value,x,nf] = gm_minny(n,1,nits,d(1),s,value,0,f,x,t,h,v,q0,q1,nf);
 
 xpr_opt = xpr_opt_old;
 fpr_opt = fpr_opt_old;
 
 if nf > nfmax
  exitflag = 1;
  nf = nf + nfparm;
  xpr_opt_old = xpr_opt;
  fpr_opt_old = fpr_opt;
  
  prax = feval(f,x);
  
  xpr_opt = xpr_opt_old;
  fpr_opt = fpr_opt_old;
  
  if fpr_opt < prax
   % restore the optimal solution
   x = xpr_opt;
   prax = fpr_opt;
  end % if fpr
  return
 end % if nf
 
 if  s <= 0
  v(1:n,1) = - v(1:n,1);
 end  % if s
 
 if  sf <= 0.9 * d(1) || d(1) <= 0.9 * sf
  d(2:n) = 0;
 end % if sf
 
 %  -----------------------------The inner loop starts here
 
 for k = 2:n
  
  if nf > nfmax
   exitflag = 1;
   nf = nf + nfparm;
   xpr_opt_old = xpr_opt;
   fpr_opt_old = fpr_opt;
   
   prax = feval(f,x);
   
   xpr_opt = xpr_opt_old;
   fpr_opt = fpr_opt_old;
   
   if fpr_opt < prax
    % restore the optimal solution
    x = xpr_opt;
    prax = fpr_opt;
   end % if fpr
   return
  end % if nf
  
  y(1:n) = x(1:n);
  
  sf = fx;
  
  if  0 < kt
   illc = 1;
  end % if 0
  
  i80 = 0;
  while i80 == 0
   
   kl = k;
   df = 0;

   %  A random step follows (to avoid resolution valleys)
   %  PRAXIS assumes that the random number generator returns a random
   %  number uniformly distributed in (0,1)

   if  illc
    
    for i = 1:n
     r = rand;
     s = (0.1 * ldt + t2 * 10^kt) * (r - 0.5);
     z(i) = s;
     x(1:n) = x(1:n) + s * v(1:n,i)';
    end % for i
    
    xpr_opt_old = xpr_opt;
    fpr_opt_old = fpr_opt;
    
    fx = feval(f,x);
    
    xpr_opt = xpr_opt_old;
    fpr_opt = fpr_opt_old;
    
    if fx < fpr_opt
     xpr_opt = x;
     fpr_opt = fx;
    end % if fx
    nf = nf + 1;
    
   end  % if illc

   %  Minimize along the "non-conjugate" directions V(*,K),...,V(*,N)

   for k2 = k:n
    
    sl = fx;
    s = 0;
    nits = 2;
    value = fx;
    
    xpr_opt_old = xpr_opt;
    fpr_opt_old = fpr_opt;
    
    [d(k2),s,value,x,nf] = gm_minny(n,k2,nits,d(k2),s,value,0,f,x,t,h,v,q0,q1,nf);
    
    xpr_opt = xpr_opt_old;
    fpr_opt = fpr_opt_old;
    
    if nf > nfmax
     exitflag = 1;
     nf = nf + nfparm;
     xpr_opt_old = xpr_opt;
     fpr_opt_old = fpr_opt;
     
     prax = feval(f,x);
     
     xpr_opt = xpr_opt_old;
     fpr_opt = fpr_opt_old;
     
     if fpr_opt < prax
      % restore the optimal solution
      x = xpr_opt;
      prax = fpr_opt;
     end % if fpr
     return
    end % if nf
    
    if  illc
     s = d(k2) * ((s + z(k2))^2);
    else
     s = sl - fx;
    end  % if illc
    
    if  df <= s
     df = s;
     kl = k2;
    end % if df
    
   end % for k2
   
   %  If there was not much improvement on the first try, set
   %  ILLC = true and start the inner loop again
   
   i80 = 1;
   if  ~illc
    if  df < abs(100 * machep * fx)
     illc = 1;
     i80 = 0;
    else
     i80 = 1;
    end % if df
   end % if ~illc
   
  end % while i80
  
  %  Minimize along the "conjugate" directions V(*,1),...,V(*,K-1)
  
  for k2 = 1:k-1
   
   s = 0;
   nits = 2;
   value = fx;
   
   xpr_opt_old = xpr_opt;
   fpr_opt_old = fpr_opt;
   
   [d(k2),s,value,x,nf] = gm_minny(n,k2,nits,d(k2),s,value,0,f,x,t,h,v,q0,q1,nf);
   
   xpr_opt = xpr_opt_old;
   fpr_opt = fpr_opt_old;
   
   if nf > nfmax
    exitflag = 1;
    nf = nf + nfparm;
    xpr_opt_old = xpr_opt;
    fpr_opt_old = fpr_opt;
    
    prax = feval(f,x);
    
    xpr_opt = xpr_opt_old;
    fpr_opt = fpr_opt_old;
    
    if fpr_opt < prax
     % restore the optimal solution
     x = xpr_opt;
     prax = fpr_opt;
    end % if fpr
    return
   end % if nf
   
  end  % for k2
  
  f1 = fx;
  fx = sf;
  lds = 0;
  
  for i = 1:n
   sl = x(i);
   x(i) = y(i);
   sl = sl - y(i);
   y(i) = sl;
   lds = lds + sl^2;
  end % for i
  
  lds = sqrt (lds);
  
  %  Discard direction V(*,kl)

  %  If no random step was taken, V(*,KL) is the "non-conjugate"
  %  direction along which the greatest improvement was made
  
  if  small < lds
   
   for ii = 1:kl-k
    i = kl - ii;
    for j = 1:n
     v(j,i+1) = v(j,i);
    end % for j
    d(i+1) = d(i);
   end  % for i
   
   d(k) = 0;
   
   v(1:n,k) = y(1:n)' / lds;
   
   %  Minimize along the new "conjugate" direction V(*,k), which is
   %  the normalized vector:  (new x) - (old x)
   
   nits = 4;
   value = f1;
   
   xpr_opt_old = xpr_opt;
   fpr_opt_old = fpr_opt;
   
   [d(k),lds,value,x,nf] = gm_minny(n,k,nits,d(k),lds,value,1,f,x,t,h,v,q0,q1,nf);
   
   xpr_opt = xpr_opt_old;
   fpr_opt = fpr_opt_old;
   
   if nf > nfmax
    exitflag = 1;
    nf = nf + nfparm;
    xpr_opt_old = xpr_opt;
    fpr_opt_old = fpr_opt;
    
    prax = feval(f,x);
    
    xpr_opt = xpr_opt_old;
    fpr_opt = fpr_opt_old;
    
    if fpr_opt < prax
     % restore the optimal solution
     x = xpr_opt;
     prax = fpr_opt;
    end % if fpr
    return
   end % if nf
   
   if  lds <= 0
    lds = - lds;
    v(1:n,k) = - v(1:n,k);
   end  % if lds
   
  end %  if small
  
  ldt = ldfac * ldt;
  ldt = max (ldt,lds);
  
  t2 = m2 * sqrt(sum(x(1:n).^2)) + t;
  
  %  See whether the length of the step taken since starting the
  %  inner loop exceeds half the tolerance
  
  if  0.5 * t2 < ldt
   kt = -1;
  end  % if 0.5
  
  kt = kt + 1;
  
  % test convergence of the objective function
  %    xpr_opt_old = xpr_opt;
  %    fpr_opt_old = fpr_opt;
  %
  %    prax = feval(f,x);
  %
  %    xpr_opt = xpr_opt_old;
  %    fpr_opt = fpr_opt_old;
  
  if abs(fx - prax_old) /abs(prax_old) <= epss
   % stop
   if fpr_opt < fx
    % restore the optimal solution
    x = xpr_opt;
    prax = fpr_opt;
   else
    prax = fx;
   end % if fpr
   return
  else
   prax_old = fx;
  end % if abs
  
  if  ktm < kt
   nf = nf + nfparm;
   
   xpr_opt_old = xpr_opt;
   fpr_opt_old = fpr_opt;
   
   prax = feval(f,x);
   
   xpr_opt = xpr_opt_old;
   fpr_opt = fpr_opt_old;
   
   if fpr_opt < prax
    % restore the optimal solution
    x = xpr_opt;
    prax = fpr_opt;
   end % if fpr
   imain = 1;
   return
  end % if ktm
  
 end % for k
 
 %  ----------------------The inner loop ends here

 %  Try quadratic extrapolation in case we are in a curved valley
 
 [x,q0,q1,nf] = gm_bquad(n,f,x,t,h,v,q0,q1,nf);
 
 d(1:n) = 1 ./ sqrt(d(1:n));
 
 dn = max(d(1:n));
 
 for j = 1:n
  v(1:n,j) = (d(j) / dn) * v(1:n,j);
 end % for j

 %  Scale the axes to try to reduce the condition number

 if  1 < scbd
  
  for i = 1:n
   z(i) = sqrt(sum(v(i,1:n).^2));
   z(i) = max(z(i),m4);
  end % for i
  
  s = min(z(1:n));
  
  for i = 1:n
   
   sl = s / z(i);
   z(i) = 1 / sl;
   
   if  scbd < z(i)
    sl = 1 / scbd;
    z(i) = scbd;
   end % if scbd
   
   v(i,1:n) = sl * v(i,1:n);
   
  end % for i
  
 end % if 1
 
 %  Calculate a new set of orthogonal directions before repeating
 %  the main loop
 
 v(1:n,1:n) = v(1:n,1:n)';

 %  find the singular value decomposition of V

 %  This gives the principal values and principal directions of the
 %  approximating quadratic form without squaring the condition number

 [U,d,v] = svd(v);
 d = diag(d);

 %  Unscale the axes

 if  1 < scbd
  
  for i = 1:n
   v(i,1:n) = z(i) * v(i,1:n);
  end % for i
  
  for i = 1:n
   
   s = sqrt(sum(v(1:n,i).^2));
   
   d(i) = s * d(i);
   v(1:n,i) = v(1:n,i) / s;
   
  end % for i
  
 end % if 1
 
 for i = 1:n
  
  dni = dn * d(i);
  
  if  large < dni
   d(i) = vsmall;
  elseif  dni < small
   d(i) = vlarge;
  else
   d(i) = 1 / dni^2;
  end % if large
  
 end % for i

 %  Sort the eigenvalues and eigenvectors

 % descending order d(1) is the largest and d(n) the smallest
 [d,v] = gm_sortd(d,v);
 
 %  Determine the smallest eigenvalue

 dmin = max(d(n),small);

 %  The ratio of the smallest to largest eigenvalue determines whether
 %  the system is ill conditioned

 if dmin < m2 * d(1)
  illc = 1;
 else
  illc = 0;
 end % if dmin

 %  ------------------------The main loop ends here

end % while imain


