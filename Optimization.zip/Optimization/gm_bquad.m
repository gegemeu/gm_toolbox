function [x,q0,q1,nf] = gm_bquad(n,f,x,t,h,v,q0,q1,nf);
%GM_BQUAD seeks to minimize the scalar function F along a particular curve

%    The minimizer to be sought is required to lie on a curve defined
%    by Q0, Q1 and X

% See: Richard Brent, Algorithms for Minimization without Derivatives,
%                       Prentice Hall, 1973, Reprinted by Dover, 2002

% Input:
%    n = the number of variables
%    f =  name of the function to be minimized
%    x = initial value
%    t, h = see gm_praxis
%    v = matrix of search directions
%    q0, q1 = two auxiliary points used to define a curve through x
%    nf = number of function evaluations
%
% Output:
%    same parameters updated

%
% translated to Matlab by G. Meurant
% March 2007
% Updated August 2015
%

global fx ldt dmin nl
global qa qb qc qd0 qd1 qf1

temp = fx;
fx   = qf1;
qf1  = temp;

temp = x;
x = q1;
q1 = temp;

qd1 = sqrt(sum((x(1:n) - q1(1:n)).^2));

l = qd1;
s = 0;

if  qd0 <= 0 || qd1 <= 0 || nl < 3 * n^2 
 fx = qf1;
 qa = 0;
 qb = 0;
 qc = 1;
 
else
 nits = 2;
 value = qf1;
 
 [s,l,value,dum,nf] = gm_minny(n,0,nits,s,l,value,1,f,x,t,h,v,q0,q1,nf);
 
 qa = (l * (l - qd1)) / (qd0 * (qd0 + qd1));
 qb = ((l + qd0) * (qd1 - l)) / (qd0 * qd1);
 qc = (l * (l + qd0)) / (qd1 * (qd0 + qd1));
 
end % if qd0

qd0 = qd1;

for i = 1:n
 s = q0(i);
 q0(i) = x(i);
 x(i) = (qa * s + qb * x(i)) + qc * q1(i);
end % for i


