% OPTIMIZATION 
%
% translation of Brent's PRAXIS algorithm for minimization without derivatives
%
% Files
%   gm_bquad      - seeks to minimize the scalar function F along a particular curve
%   gm_flin       - function of one variable to be minimized by gm_minny
%   gm_minny      - minimizes a scalar function of N variables along a line
%   gm_praxis     - minimization algorithm, seeks an N-dimensional minimizer X of a scalar function F(X)
%   gm_sortd      - sorts dd in descending order and sorts the columns of v accordingly
