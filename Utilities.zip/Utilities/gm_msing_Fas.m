function [msing,Q,R]=gm_msing_Fas(V);
%GM_MSING_FAS estimates of the minimum singular values of V_k

% This is supposed to be cheaper than computing the SVD

% Method from C. Fassino,
% On updating the least singular value: a lower bound,
% Calcolo v 40, no. 4 (2003), pp. 213-229

% Input:
% V = matrix
%
% Output:
% msing = vector of the estimates 
% Q,R = QR factorization of V

% 
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

n = size(V,2);
msing = zeros(1,n);

% initialization
v = V(:,1);
msig = norm(v);
msing(1) = msig;
[Q,R] = qr(v);

for k = 2:n
 [msig,Q,R] = gm_upd_msing_Fas(Q,R,V(:,k),msig);
 msing(k) = msig;
end

