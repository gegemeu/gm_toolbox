function [X,C]=gm_comp_Frob(H);
%GM_COMP_FROB computes the Frobenius factorization of an Hessenberg matrix H

% Algorithm from J.H. Wilkinson (p. 405 of the Algebraic eigenvalue problem)

% Input:
% H = upper Hessenberg matrix
%
% Output:
% X, C = s.t. H = X C inv(X), C = companion matrix

%
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

n = size(H,1);

C = H;
E = speye(n,n);

for k =1:n-1
 Ei = speye(n,n);
 Eii = Ei;
 if abs(C(k+1,k)) > 1e-16
  y = C(1:k,k) / C(k+1,k);
 else
  error(['gm_comp_Frob: Almost zero pivot, step = ' num2str(k+1)])
 end
 Ei(1:k,k+1) = -y;
 Eii(1:k,k+1) = y;
 C = Ei * C * Eii;
 E = Ei * E;
end

D = [1; diag(H,-1)];
D = cumprod(D);
D = diag(D);

X = E \ D;

C = D \ (C * D);

% reconstruct C (which is the companion matrix)
Cn = C(:,n);
C = [zeros(1,n-1) Cn(1); eye(n-1) Cn(2:n)];



