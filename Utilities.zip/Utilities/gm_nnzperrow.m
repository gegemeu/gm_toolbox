function [s,nzpr]=gm_nnzperrow(A);
%GM_NNZPERROW computes the max number of non zeros per row

%
% Author G. Meurant
% Jan 2001
%

B = spones(A);
s = sum(B,2);
nzpr = max(s);
