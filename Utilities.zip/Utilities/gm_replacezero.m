function y = gm_replacezero(x,val);
%GM_REPLACEZERO put the true zeros to val

% works for vectors and matrices

%
% Author G. Meurant
% March 2003
%

y = x;

y(find(abs(x) < realmin)) = val;

