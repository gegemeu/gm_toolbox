%GM_PERFSETDIFF comparison of different setdiff

% Author G. Meurant
% Mar 2009
%

x = [1:20000];
y = [[25:500] 700 [800:900] [15000:15010]];

tic
c = setdiff(x,y);
toc

tic
c = gm_fmt(x,y);
toc

tic
c = gm_setdiff(x,y);
toc

