function msing_new = gm_upd_msingL(R,v,msing);
%GM_UPD_MSINGL update of the estimate of the minimum singular value of R=L'

% method from C. Fassino, Calcolo, v 40 (2003), 213-229

% Input:
% R = upper triangular
% v = vector which is added to the matrix [[R; 0], v]
% msing = estimate for R
%
% Output:
% msing_new = new value after the update

%
% Author G. Meurant
% March 2015
%

k = size(R,2);
m = length(v);

if msing == 0
 % do nothing since msing_new <= msing
 msing_new = 0;
 return
end

qv = v;
c1 = qv(1:k);
c2 = qv(k+1:m);

% norm of the residual of the least squares problem
% || A x - v ||
rho = norm(c2);

if rho == 0
 msing_new = msing;
elseif norm(c1) == 0
 msing_new = min(msing,rho);
else
 % solve the least squares problem
 x = R(1:k,1:k) \ c1;
 nx = norm(x)^2;
 B = nx + rho^2 / msing^2 - 1;
 E = 1 + (B - sqrt(B^2 + 4 * nx)) / 2;
 msing_new = msing * sqrt(E);
end



 