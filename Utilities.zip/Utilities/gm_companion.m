function [C,eigC] = gm_companion(alp);
%GM_COMPANION construction of the companion matrix from the vector alp

% alp is alpha_0,...,alpha_{n-1}

% Input:
% alp = vector, - last column of C
%
% Output:
% C = companion matrix
% eigC = eigenvalues of C

%
% Author G. Meurant
% August 2009
% Updated Sept 2015
%

n = length(alp);

alp = alp(:);

% Companion matrix C
C = [zeros(1,n-1) -alp(1); speye(n-1,n-1) -alp(2:end)];

if nargout == 2
 eigC = eig(full(C));
end




