function [s,c] = gm_2sum(a,b);
%GM_2SUM summation of a and b

% From Ogita, Rump, Oishi

% Input:
% a,b = floating-point numbers
%
% Output:
% s = sum
% c = rounding error

%
% Author G. Meurant
% May 2023
%

s = a + b;
t = s - b;
t2 = s - t;
t3  = a - t;
t4 = b - t2;
c = t4 + t3;

% s = s + c;

