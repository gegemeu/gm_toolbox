function [eigA,X,Xi]=gm_sorteig(A);
%GM_SORTEIG sorted eigenvalues and eigenvectors of A
% A is supposed to be similar to a symmetric matrix

% eigA is the vector of eigenvalues
% X is the sorted matrix of eigenvectors
% Xi is the inverse of X
% If A is symmetric Xi = X'

%
% Author G. Meurant
% August 2004
%

[vec,d] = eig(full(A));
[dd,ind] = sort(real(diag(d)));
X = vec(:,ind);
eigA = dd;

if norm(A - A','fro') == 0
 Xi = X';
else
 Xi = inv(X);
end


