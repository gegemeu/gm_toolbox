function [R,dotprod]=gm_orth_cgsR(A);
%GM_ORTH_CGSR  orthogonalisation of the columns of A
% Classical Gram-Schmidt but returns only R

% Input:
% A = matrix
%
% Output:
% R = matrix such that A = V R
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

dotprod = 0;

[m,n] = size(A);
V = zeros(m,n);
R = zeros(n,n);
v = A(:,1);
nv = norm(v);
V(:,1) = v / nv;
R(1,1) = nv;
dotprod = dotprod + 1;

% orthogonalization (once)

for k = 2:n
 w = A(:,k);
 v = w;
 for j=1:k-1
  alpha = w' * V(:,j);
  R(j,k) = alpha;
  v = v - alpha * V(:,j);
  dotprod = dotprod + 1;
 end % for j
 
 nv = norm(v);
 dotprod = dotprod + 1;
 R(k,k) = nv;
 if nv <= 1e-15
  fprintf('\n gm_orth_cgsR: Breakdown, step %d \n\n',k)
  return
 end
 v = v / norm(v);
 V(:,k) = v;
 
end % for k





