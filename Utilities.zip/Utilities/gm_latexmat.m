function table = gm_latexmat(A,d);
%GM_LATEXMAT converts a Matlab matrix into a LaTeX pmatrix environment

% If A is a matrix, typing gm_latexmat(A) returns in the worspace a LaTeX
% pmatrix. Hence, a matrix like A = [3 4 ; 8 9] returns a string matrixe like
%
% \pmatrix{ 3 & 4 \cr 8 & 9 \cr }
%
% gm_latexmat(A,d) limits the number of decimals to d

%
% Modified by G. Meurant (from Latextab by Jorge Dur�n)
% October 2009
%

if nargin == 1
 dig = 4;
else
 dig = d;
end

colamp = char(kron(' &  ',ones(size(A,1),1)));
colend = char(kron(' \cr',ones(size(A,1),1)));

table = [];
for j=1:size(A,2)
 table = [table num2str(A(:,j),dig) colamp];
end

table(:,size(table,2)-3:size(table,2)) = colend;

header = '\pmatrix{';
footer = '}';

cols = max([size(header,2) size(table,2) size(footer,2)]);

table = [header char(kron(' ',ones(1,cols-size(header,2))))
 table  char(kron(' ',ones(size(table,1),cols-size(table,2))))
 footer char(kron(' ',ones(1,cols-size(footer,2))))];


