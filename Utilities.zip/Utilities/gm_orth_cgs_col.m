function [V,R,dotprod]=gm_orth_cgs_col(A,dreorth);
%GM_ORTH_CGS_COL (double) orthogonalisation of the columns of A
% Classical Gram-Schmidt by columns

% Input:
% A = matrix
% dreorth = 'dreorth' if we do a second orthogonalization
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = upper triangular matrix such that A = V R
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

if nargin == 1
 dreorth = 'nodreorth';
end

dotprod = 0;

[m,n] = size(A);
V = zeros(m,n);
R = zeros(n,n);

% first orthogonalization

for k = 1:n
 w = A(:,k);
 r1 = V(:,1:k-1)' * w;
 R(1:k-1,k) = r1;
 u = w - V(:,1:k-1) * r1;
 dotprod = dotprod + k - 1;
 
 if strcmpi(dreorth,'dreorth') == 1
  % second orthogonalization
  r2 = V(:,1:k-1)' * u;
  u = u - V(:,1:k-1) * r2;
  R(1:k-1,k) = r1 + r2;
  dotprod = dotprod + k - 1;
 end % if
 
 nu = norm(u);
 dotprod = dotprod + 1;
 
 if nu <= 1e-15
  fprintf('\n gm_orth_cgs_col: Breakdown, step %d \n\n',k)
  return
 end
 
 R(k,k) = nu;
 V(:,k) = u / nu;
 
end % for k





