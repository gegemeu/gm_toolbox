function p=gm_cumprod_diffs2(x);
%GM_CUMPROD_DIFFS2 product of |x(j)-x(i)|^2 for all pairs i<j

% Input:
% x = vector
%
% Output:
% p = product of |x(j)-x(i)|^2 for all pairs i < j

%
% Author G. Meurant
% Oct 2013
% Updated Sept 2015
%

x = x(:);
n = length(x);

if n == 1
 p = 1;
 return
end

% list of all pairs
I = gm_all_combi(n,2);

p = prod(abs(x(I(:,2)) - x(I(:,1))).^2);

