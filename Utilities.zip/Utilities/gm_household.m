function [v,beta,P] = gm_household(x,m);
%GM_HOUSEHOLD Householder transformation to zero components m to n of x

% from Golub - Van Loan

% The result is x - beta (v' x) v

% Input:
% x = real vector
%
% Output:
% v = vector defining the Householder transformation
% beta = scalar defining the Householder transformation
% P = I - beta v v', Householder transformation

%
% Author G. Meurant
% Updated October 2016
%

nx = length(x);
if m < 2 || m > nx
 error('gm_household: Wrong value of m')
end

x = x(m-1:nx);
n = length(x);

sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];

if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1) = -sig/(x(1) + mu);
 end % if x
 beta = 2 * v(1)^2 / (sig + v(1)^2);
 v = v / v(1);
end % if sig

v = [zeros(m-2,1); v];

if nargout == 3
 P = speye(nx,nx) - beta * (v * v');
end % if nargout




