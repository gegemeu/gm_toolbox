function [dH,dA]=gm_departure_from_normality(A,eigA);
%GM_DEPARTURE_FROM_NORMALITY computes two measures of the departure from normality

% Input:
% A = matrix
% eigA = eigenvalues of A
%
% Output:
% dH =  Henrici's definition
% dA = norm of A' A - A A'

%
% Author G. Meurant
% November 2013
% Updated Sept 2015
%

if nargin == 1
 eigA = eig(full(A));
end

% Henrici's definition
D = diag(eigA);
nFA = norm(A,'fro');
nFD = norm(D,'fro');
dH = sqrt(nFA^2 - nFD^2);

% Other measure
dA = norm(A' * A - A * A');



