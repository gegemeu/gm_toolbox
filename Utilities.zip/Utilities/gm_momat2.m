function [M,ML,MLL] = gm_momat2(om,lamb);
%GM_MOMAT2 moment matrices from the eigenvalues and the projections on the eigenvectors

% Input:
% om = vector of the moduli squared of the projections on the eigenvectors
% lamb = eigenvalues (real or complex conjugate)
%
% Output:
% M = matrix s.t. M(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j-1)
% ML = matrix s.t. ML(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j)
% MLL = matrix s.t. MLL(i,j) = sum om.*conj(lamb).^(i).*lamb.^(j));

%
% Author G. Meurant
% December 2011
% Updated September 2015
%

n = length(om);
M = zeros(n,n);
ML = zeros(n,n);
MLL = zeros(n,n);
mo = size(om,1);
ml = size(lamb,1);

if mo ~= ml
 lamb = transpose(lamb);
end

for i=1:n
 for j=1:n
  M(i,j) = sum(om.*conj(lamb).^(i-1).*lamb.^(j-1));
  if i == j
   % the diagonal entries must be real
   M(i,i) = real(M(i,i));
  end
 end
end

for i=1:n
 for j=1:n
  ML(i,j) = sum(om.*conj(lamb).^(i-1).*lamb.^(j));
 end
end

for i=1:n
 for j=1:n
  MLL(i,j) = sum(om.*conj(lamb).^(i).*lamb.^(j));
 end
end



