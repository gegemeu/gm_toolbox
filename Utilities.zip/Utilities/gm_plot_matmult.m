function gm_plot_matmult(kmax);
%GM_PLOT_MATMULT computing speed of the matrix-matrix multiply

% Input:
% kmax = maximum order of the matrices (at least 300)

%
% Author G. Meurant
% January 2012
% Updated September 2015
%

kmax = max(300,kmax);

A = randn(kmax,kmax);
s = zeros(kmax,1);
gflop = zeros(kmax,1);
tim = gflop;

kk = 0;
for k = 100:50:kmax
 kk = kk + 1;
 s(kk) = k;
 Ak = A(1:k,1:k);
 B = Ak;
 
 [C,multflops,gflops,time] = gm_matmult(Ak,B);
 
 gflop(kk) = gflops;
 tim(kk) = time;
end

fprintf('\n     times   Gflops \n')
fprintf('---------------------\n')
[tim(1:kk) gflop(1:kk)]

plot(s(1:kk),gflop(1:kk))

