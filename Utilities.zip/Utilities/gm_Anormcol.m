function normcol = gm_Anormcol(A,B);
%GM_ANORMCOL A-norms of the columns of B

% A must be symmetric positive definite

%
% Author G. Meurant
% July 2024
%

m = size(B,2);
normcol = zeros(1,m);
for k = 1:m
 normcol(k) = sqrt(B(:,k)' * A * B(:,k));
end

