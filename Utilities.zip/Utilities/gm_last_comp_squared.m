function Z=gm_last_comp_squared(T,nc);
%GM_LAST_COMP_SQUARED last components of the eigenvectors of T_k

%
% Author G. Meurant
% Sept 2019
%

n = size(T,1);
Z = zeros(n,n);
if nargin == 2
 maxk = min(n,nc);
else
 maxk = 5;
end % if

for k = 1:n
 [Q,D] = eig(full(T(1:k,1:k)));
 if ~isnumeric(T(1,1))
  Q = double(Q);
  D = double(D);
 end % if
 [eigD,I] = sort(diag(D));
 Q = Q(:,I);
 Z(k,1:k) = Q(k,1:k).^2;
end % for k


cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;

set(0,'defaultaxesfontsize',12);
set(0,'defaultlinelinewidth',1); 
set(0,'defaultlinemarkersize',6);

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);

semilogy(Z(:,1))
hold on
for k = 2:maxk
 semilogy([k:n],Z(k:n,k))
end % for k
hold off

xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('last components squared' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
%legend('1st term','max term','delta k','Location','northeastoutside')
ti = ['comp = 1:' num2str(maxk)];
title(ti,'FontSize',12,'FontName','Times')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\CGQ\Tlast_comp_1';
% print(sSaveName,'-dpdf');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);

semilogy(Z(1,1))
hold on
maxiter = 10;
maxiter = 30;
for k = 2:maxiter
 semilogy([1:k],Z(k,1:k))
end % for k
hold off

xlabel('component number' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('last components squared' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
%legend('1st term','max term','delta k','Location','northeastoutside')
ti = 'Last components';
title(ti,'FontSize',12,'FontName','Times')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\CGQ\Tlast_comp_2';
% print(sSaveName,'-dpdf');

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);

semilogy(diag(T,-1).^2)

xlabel('iteration' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('$\beta_k^2$' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
%legend('1st term','max term','delta k','Location','northeastoutside')
title('Subdiagonal entries of T squared','FontSize',12,'FontName','Times')
sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\CGQ\Tbetak_1';
% print(sSaveName,'-dpdf');

