function [Ad,d]=gm_normaliz(A);
%GM_NORMALIZ symmetrically scales the matrix A with 1's on the diagonal
% send back the normalizing factor d in a vector
%

%
% Author G. Meurant
% Sept 2000
%

n = size(A,1);

% diagonal of A
d = spdiags(A,0);

% its inverse
d = 1 ./ sqrt(d);

% make it a diagonal sparse matrix
dd = spdiags(d,0,n,n);

% scale the matrix A
Ad = dd * A * dd;
