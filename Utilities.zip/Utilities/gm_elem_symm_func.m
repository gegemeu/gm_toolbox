function e=gm_elem_symm_func(x,j);
%GM_ELEM_SYMM_FUNC elementary symmetric function of k values 
% sum of products of j of the values with ordered indices

% Input:
% x = vector
% j = integer
%
% Output:
% e = elementary symmetric function

%
% Author G. Meurant
% October 2013
% Updated Sept 2015
%

x = x(:);
k = length(x);

if j > k || j == 0
 e = 1;
 return
end

I = gm_all_combi(k,j);

sI = size(I,1);
xx = zeros(sI,j);
products = zeros(sI,1);
for i = 1:sI
 xx(i,:) = x(I(i,:));
 products(i) = prod(xx(i,:));
end

e = sum(products);

