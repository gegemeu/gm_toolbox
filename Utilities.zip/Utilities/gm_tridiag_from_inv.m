function [alpha,beta,T]=gm_tridiag_from_inv(u,v);
%GM_TRIDIAG_FROM_INV symmetric tridiagonal matrix from its inverse

% formulas from G.H. Golub and G. Meurant
% Matrices, moments and quadrature with applications
% Princeton University Press, 2010

% The inverse of T is
% | u_1 v_1, u_1 v_2, ... u_1 v_n |
% | u_1 v_2, u_2 v_2, ... u_2 v_n |
% |    .       .      ...    .    |
% |    .       .      ...    .    |
% | u_1 v_n, u_2 v_n, ... u_n v_n |

% Input:
% u, v = vectors defining the inverse
% u(1) must equal to 1
%
% Ouput:
% alpha (length n) = vector of diagonal coefficients
% beta (length n-1) = vector of lower and upper diagonal coefficients
% T (optional) = tridiagonal matrix inverse
%

%
% Author G. Meurant
% June 2016
%

n = length(u);
if length(v) ~= n
 error('gm_tridiag_from_inv: u and v must have the same length')
end
if abs(u(1) - 1) >= 1e-14
 error('gm_tridiag_from_inv: u(1) must be equal to 1')
end

alpha = zeros(n,1);
beta = zeros(n-1,1);
T = [];

alpha(1) = u(2) / (u(2) * v(1) - v(2));
beta(1) = 1 / (v(2) - u(2) * v(1));

for i = 3:n
 UV = [u(i-1), u(i); u(i-1) * v(i-1), u(i-1) * v(i)];
 rhs = [-beta(i-2) * u(i-2); 1 - beta(i-2) * u(i-2) * v(i-1)];
 y = UV \ rhs;
 alpha(i-1) = y(1);
 beta(i-1) = y(2);
end

alpha(n) = (1 - beta(n-1) * u(n-1) * v(n)) / (u(n) * v(n));

if nargout == 3
 x = [beta; 0];
 y = alpha;
 z = [0; beta];
 T = spdiags([x y z], -1:1,n,n);
end


