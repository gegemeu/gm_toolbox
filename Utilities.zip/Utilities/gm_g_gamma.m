function om=gm_g_gamma(g,gamma);
%GM_G_GAMMA utility function

% 
% Author G. Meurant
% December 2018
%

n = length(g);
g = g(:);
gamma = gamma(:);
om = zeros(n-1,1);
for k = 1:n-1
 om(k) = g(k) * gamma(k+1) - g(k+1) * gamma(k);
end % for k

