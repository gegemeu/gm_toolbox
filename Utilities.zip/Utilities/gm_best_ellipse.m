function [cx,cy,a,b,count]=gm_best_ellipse(x,y,tolerance);
%GM_BEST_ELLIPSE best enclosing ellipse for a set of 2D points

% Input:
% x,y = coordinates of the points (must not be all on the real axis)
% tolerance = threshold for convergence
%
% Output:
% cx, cy = center of the ellipse
% a, b = semi-axes
% count = number of iterations

%
% From a code by
% Nima Moshtagh (nima@seas.upenn.edu)
% University of Pennsylvania
%
% December 2005
% UPDATE: Jan 2009
%
% modified by G. Meurant
% August 2015
%



%%%%%%%%%%%%%%%%%%%%% Solving the Dual problem%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% ---------------------------------
% data points
% -----------------------------------
P = [x(:)'; y(:)'];
[d N] = size(P);

Q = zeros(d+1,N);
Q(1:d,:) = P(1:d,1:N);
Q(d+1,:) = ones(1,N);


% initialization
% -----------------------------------
count = 1;
err = 1;
u = (1/N) * ones(N,1);          % 1st iteration

countmax = 10000;

% Khachiyan Algorithm
% -----------------------------------
while err > tolerance
 if count > countmax
  error('gm_best_ellipse: too many iterations')
 end
 X = Q * diag(u) * Q';       % X = \sum_i ( u_i * q_i * q_i')  is a (d+1)x(d+1) matrix
%  M = diag(Q' * inv(X) * Q);  % M the diagonal vector of an NxN matrix
 M = diag(Q' * (X \ Q));  % M the diagonal vector of an NxN matrix
 [maximum j] = max(M);
 step_size = (maximum - d -1)/((d+1)*(maximum-1));
 new_u = (1 - step_size)*u ;
 new_u(j) = new_u(j) + step_size;
 count = count + 1;
 err = norm(new_u - u);
 u = new_u;
end

%%%%%%%%%%%%%%%%%%% Computing the Ellipse parameters%%%%%%%%%%%%%%%%%%%%%%
% Finds the ellipse equation in the 'center form':
% (x-c)' * A * (x-c) = 1
% It computes a 2 x 2 matrix 'A' and a 2 dimensional vector 'c' as the center
% of the ellipse.

U = diag(u);

% the A matrix for the ellipse
% --------------------------------------------
A = (1/d) * inv(P * U * P' - (P * u)*(P*u)' );

% center of the ellipse
% --------------------------------------------
c = P * u;
cx = c(1);
cy = c(2);

% semi-axes

[U D V] = svd(A);

dx = abs(max(x) - min(x));
dy = abs(max(y) - min(y));

if dx > dy
 b = 1/sqrt(D(1,1));
 a = 1/sqrt(D(2,2));
else
 a = 1/sqrt(D(1,1));
 b = 1/sqrt(D(2,2));
end




