function gm_draw_circle(n,cx,cy,r);
%GM_DRAW_CIRCLE draws a circle of center [cx,cy] and radius r with n points

%
% Author G. Meurant
% Apr 2012
%

x = zeros(n+1,1);
y = x;

k = [0:n] * 2 * pi / n;

x = cx + r * cos(k);
y = cy + r * sin(k);

plot(x,y)

axis square