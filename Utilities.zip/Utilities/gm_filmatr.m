function B=gm_filmatr(A,alp);
%GM_FILMATR filters the matrix A 
% relative criteria
%

%
% Author G. Meurant
% Updated April 2015
%

[n,m] = size(A);

maxa = max(max(abs(A)));
B = sparse(n,m);

for i = 1:n
 ind = find(abs(A(i,:)) >= alp * maxa);
 ind = gm_fmt(ind,[i]);
 ind = sort([i ind]);
 B(i,ind) = A(i,ind);
end


