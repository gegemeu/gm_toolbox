function [nm,xm,ym] = gm_meshsquare(n,m);
%GM_MESHSQUARE sets up a quadrilateral mesh

% n * m cells
% the bottom left node has coordinates xm,ym
% This is used by gm_vizmatjet

%
% Author G. Meurant
% December 2001
% Updated April 2015
%

nm = n * m;
m1 = m;
yy = [m:-1:1];
xm = zeros(nm,1);
ym = zeros(nm,1);

for i = 1:n
 xx = i;
 ind = [1 + (i - 1) * m1 : m1 + (i - 1) * m1];
 xm(ind) = xx * ones(m1,1);
 ym(ind) = yy;
end
