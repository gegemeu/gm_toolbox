function [c] = gm_setdiff(a,b);
%GM_SETDIFF Set difference
% when A and B are vectors returns the values in A that are not in B
%   A and B must be non-empty row vectors
%

%
% modified from Matlab setdiff
% Author G. Meurant
% Mar 2009
%

numelA = length(a);

% Handle scalar: one element.  Scalar A done only
% Scalar B handled within ISMEMBER and general implementation

if (numelA == 1)
 if ~ismember(a,b)
  c = a;
 else
  c = [];
 end
 return

 % General handling

else

 % Convert to double arrays, which sort faster than other types

 whichclass = class(a);
 isdouble = strcmp(whichclass,'double');

 if ~isdouble
  a = double(a);
 end

 if ~strcmp(class(b),'double')
  b = double(b);
 end

 % Call ISMEMBER to determine list of non-matching elements of A
 tf = ~(ismember(a,b));
 c = a(tf);

 % Call UNIQUE to remove duplicates from list of non-matches.
 %c = unique(c);

 % Re-convert to correct output data type using FEVAL
 if ~isdouble
  c = feval(whichclass,c);
 end
end





