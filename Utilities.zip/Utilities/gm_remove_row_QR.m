function [Q,R]=gm_remove_row_QR(Q,R,k);
%GM_REMOVE_ROW_QR update the QR decomposition when a row is removed

%   [Q,R]=gm_remove_row_QR(Q,R,k); computes the QR decomposition for
%   [A(1,:); A(2,:);...;A(k-1,:); A(k+1,:);...;A(n,:)] when
%   [Q,R]=qr(A)

% from Gander and Gander book

[m,n] = size(R);
Q = [Q(k,:); Q(1:k-1,:); Q(k+1:m,:)];           % permute Q

for j = m-1:-1:1                                % map row to unit vector
  G = planerot(Q(1,j:j+1)');          
  if j <= n
     R(j:j+1,j:n) = G * R(j:j+1,j:n);           % update R
   end;
   Q(:,j:j+1) = Q(:,j:j+1)*G';                  % update Q
end

Q = Q(2:m,2:m);R=R(2:m,:);

