function [C,eigC,alp] = gm_companion_eig(lambda);
%GM_COMPANION_EIG construction of the companion matrix from the eigenvalues

% Input:
% lambda = eigenvalues
%
% Output:
% C = companion matrix
% eigC = eigenvalues of C (must be equal to lambda)
% alp = coefficients of the characteristic polynomial
%   alp is alpha_0,...,alpha_{n-1}

%
% Author G. Meurant
% August 2009
% Updated Sept 2015
%

n = length(lambda);

% compute the coefficients of the polynomial from the eigenvalues
alp = poly(lambda)';
alp = alp(end:-1:2);
alp = alp(:);

% Companion matrix C
C = [zeros(1,n-1) -alp(1); speye(n-1,n-1) -alp(2:end)];

eigC = eig(full(C));


