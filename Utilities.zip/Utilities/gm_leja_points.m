function xleja = gm_leja_points(n,varargin);
%GM_LEJA_POINTS computes the first n Leja points in [-2,2]

% Given the first Leja point X(1) = 2, the Leja points are
% defined recursively in such a way that the function
%
% F(Y,X(1:N-1)) = ABS(PROD(Y-X(1:N-1)))
%
% is maximized over [-2,2] by X(N).
% The maximum of the function above is computed by FMINBND
% (the algorithm is based on golden section search and parabolic
% interpolation).
%
% LEJAPOINTS(N,TYPE) computes the first N Leja points in [-2,2] if
% TYPE = 1 and the first N-(1-MOD(N,2)) symmetrized Leja points in
% [-2,2] if TYPE = 2. Symmetrized Leja points are defined as
%
% X(0) = 0
% X(1) = 2
% X(2) = -2
% ...
% X(N) = argmax(F(Y,X(1:N-1))) if N is odd
% X(N+1) = -X(N)               if N is even
%
% LEJAPOINTS(N,X) sorts the vector X in the Leja order, if LENGTH(X) > 1
% It means that the function above is maximized over X

%
% Updated by G. Meurant
% August 2015
%

if (nargin > 1)
 x = varargin{1};
else
 x = 1;
end
if (length(x) > 1)
 xleja = gm_leja_ord(x,n);
 return
end

options = optimset('fminbnd');
options = optimset('TolX',1e-15);
xleja = zeros(n,1);
xmaxloc = zeros(n-2,1);
fmaxloc = xmaxloc;
if x == 1
 xleja(1) = 2;
 xleja(2) = -2;
 xleja(3) = 0;
else
 xleja(1) = 0;
 xleja(2) = 2;
 xleja(3) = -2;
 n = n - (1 - mod(n,2));
end

xsort = xleja;
for k = 4:x:n
 xsort = sort(xsort(1:k-1));
 for i = 1:(k-2)/x
  [xmaxloc(i),fmaxloc(i)] = fminbnd(@fleja,xsort(i),xsort(i+1),options,xleja,k-1);
 end
 [fmax index] = max(-fmaxloc(1:k-2));
 xleja(k) = xmaxloc(index);
 xleja(k+1) = -xmaxloc(index);
 xsort(k) = xleja(k);
 xsort(k+1) = xleja(k+1);
end
xleja = xleja(1:n);

end


function z = fleja(x,xleja,n)
% the opposite of the Leja function to maximize

z = -abs(prod(x - xleja(1:n)));

end



