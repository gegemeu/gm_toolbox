function [x,y]=gm_Split(a);
%GM_SPLIT splits a double precision number in two parts

% this is for double precision f = 2^27 + 1
f = 134217729;

z = a * f;
x = z - (z - a);
y = a - x;

end