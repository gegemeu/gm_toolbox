function r = gm_quartique(cc);
%GM_QUARTIQUE solutions of x^4 + cc(2) x^3 + cc(3) x^2 + cc(4) x + cc(5)

% Input:
% cc = coefficients
%
% Output:
% r = vector of solutions

%
% Author G. Meurant
% November 2013
% Updated Sept 2015
%

a = 1;
b = cc(2);
c = cc(3);
d = cc(4);
e = cc(5);

D0 = c^2 - 3 * b * d + 12 * a * e;
D1 = 2 * c^3 - 9 * b * c * d + 27 * b^2 * e + 27 * a * d^2 - 72 * a * c * e;
p = (8 * a * c - 3 * b^2) / ( 8 * a^2);
q = (b^3 - 4 * a * b * c + 8 * a^2 * d) / (8 * a^3);
Q = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
S = 0.5 * sqrt(-2 * p / 3 + (Q + D0 / Q) / (3 * a));

x1 = -b / (4 * a) - S + sqrt(-4 * S^2 - 2 * p + q / S) / 2;
x2 = -b / (4 * a) - S - sqrt(-4 * S^2 - 2 * p + q / S) / 2;
x3 = -b / (4 * a) + S + sqrt(-4 * S^2 - 2 * p - q / S) / 2;
x4 = -b / (4 * a) + S - sqrt(-4 * S^2 - 2 * p - q / S) / 2;

r = [x1; x2; x3; x4];

