function l=gm_compzer1(list);
%GM_COMPZER1 eliminates the zeroes in list and compress
%

%
% Author G. Meurant
%

ind = find(list ~= 0);
l = list(ind);
