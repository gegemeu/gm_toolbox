function [ncolor,color]=gm_graph_colorb(A);
%GM_GRAPH_COLORB colors the graph of A
%
% 2 nodes which are linked in the graph of A must not have the same color
% SDO algorithm (see Jones and Plassmann)
% this is a sequential algorithm which assume that A is symmetric
% must be faster than gm_graph_color
%
% ncolor = number of colors
% color  = color of the nodes of the graph
%

%
% Author G. Meurant
% Mar 2009
%


n = size(A,1);
color = zeros(n,1);
A = A - diag(diag(A));

ncolor = 1;
color(1) = 1;
% color the first node

% colors already used
colors = [1];
% number of colored nodes
ncol = 1;
% front = neighbours of already colored nodes
front = gm_neighbs(A,1);
% the degree is the number of already colored neighbours: 1 for now on
degf = ones(1,length(front));

while ncol < n
 % choose the node in the front with maximum degree
 nfront = length(front);
 [y,ii] = max(degf);
 maxk = front(ii);

 % give to maxk the smallest available color
 % neighbours of maxk
 indk = gm_neighbs(A,maxk);
 % colors of neighbours of maxk
 colork = color(indk);
 colk = unique(colork);
 colk = nonzeros(colk);
 if length(colk) == ncolor
  % all the previous colors are used, use a new one
  ncolor = ncolor + 1;
  color(maxk) = ncolor;
  colors = [colors ncolor];
  ncol = ncol + 1;
 else
  % find the smallest available color
  acol = gm_setdiff(colors,colk);
  acol = sort(acol);
  color(maxk) = acol(1);
  ncol = ncol + 1;
 end

 % remove maxk from the front and add its non-colored neighbours
 pf = find(ismember(front,maxk));
 if pf > 1
  if pf < nfront
   front = [front(1:pf-1) front(pf+1:end)];
   degf = [degf(1:pf-1) degf(pf+1:end)];
  else
   front = front(1:pf-1);
   degf = degf(1:pf-1);
  end
 else % pf = 1
  front = front(2:end);
  degf = degf(2:end);
 end
 nfront = nfront-1;

 % check if all the neighbours of maxk are colored
 addfront = unique(indk(colork == 0));
 inter = gm_intersect(front,addfront);
 if ~isempty(inter)
  addfront = gm_setdiff(addfront,inter);
 end
 % update the degrees of the neighbours of maxk in the front
 % which are the nodes in the intersection
 upd = gm_intersect(front,indk);
 if ~isempty(upd)
  for kk = 1:length(upd)
   k = upd(kk);
   % number of colored neighbours
   nk = gm_neighbs(A,k);
   colnk = color(nk);
   degk = length(unique(find(colnk)));
   % position of k in the front
   pk = find(ismember(front,k));
   degf(pk) = degk;
  end % for k
 end

 degaddfront = [];
 % if not empty, compute the degrees of the nodes
 % and add them to the front
 if ~isempty(addfront)
  ladd = length(addfront);
  for kk = 1:ladd
   k = addfront(kk);
   % neighbours of k
   nk = cgml_neighbs(A,k);
   degaddfront = [degaddfront nnz(color(nk))];
  end % for k
  front = [front addfront];
  degf = [degf degaddfront];
  nfront = nfront + ladd;
 end % if

end % while





