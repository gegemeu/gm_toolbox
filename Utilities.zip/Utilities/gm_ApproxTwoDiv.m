function [x,y]=gm_ApproxTwoDiv(a,b);
%GM_APPROXTWODIV computes the division a / b and an approximate rounding error

% Used in solve_triangle

% Input:
% a, b = we return a / b
%
% Output:
% x = a / b
% y = approximate rounding error

%
% April 2014
% Updated August 2015
%

x = a ./ b;
[v,w] = gm_TwoProd(x,b);
y = (a - v - w) ./ b;

