function  [rows,cols,entries,field,symm]=gm_mat_info(filename,iprint);
%GM_MAT_INFO informations about a matrix MAT file

% rows = number of rows
% cols = number of columns
% field = real or complex
% symm = symmetric or unsymmetric
%


if nargin < 2
 iprint = 0;
end

load(filename,'A')

[rows,cols] = size(A);
entries = nnz(A);

if isreal(A)
 field = 'real';
else
 field = 'complex';
end

if rows == cols
 K = A - A';
 if norm(K,'inf') == 0
  symm = 'symmetric';
 else
  symm = 'unsymmetric';
 end
else
 symm = 'rectangular'
end

if iprint == 1
 fprintf('\n The matrix in file %s is %s and %s \n\n',filename,field,symm)
 fprintf(' Number of rows = %5d, number of columns = %5d, number of non zeros = %6d, sparsity = %g \n\n',rows,cols,entries,entries/(rows*cols))
 if rows < 3000
  spy(A)
 end
end

clear A



