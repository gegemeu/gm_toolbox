function [s,T,rhs] = gm_spline(x,y,bc,df1,dfn);
%GM_SPLINE cubic spline interpolation

% Input;
% x = nodes
% y = values to be interpolated
% bc = end condition, 1 = not-a-knot, 2 = free end (natural spline), 3 = clamped
% dfl, dfr = values of the left and right derivatives if bc = 3
%
% Output:
% s = coefficients, (n-1) x 4
% T = tridiagonal matrix
% rhs = right-hand side

%
% Author G. Meurant
% May 2024
%

n = length(x);
ny = length(y);
if ny ~= n
 error('gm_spline: incompatible lengthes  of x and y')
end % if
s = zeros(n-1,4);

if nargin < 3
 bc = 1;
 df1 = [];
 dfn = [];
end % if
if nargin < 4 || nargin < 5
 df1 = [];
 dfn = [];
end % if

rhs = zeros(n,1);
T = zeros(n,n);

h = diff(x);
del = diff(y);

% rows 2 to n-1
for k = 2:n-1
 T(k,k-1) = h(k);
 T(k,k) = 2 * (h(k) + h(k-1));
 T(k,k+1) = h(k-1);
 rhs(k) = 3 * (h(k) * (del(k-1) / h(k-1)) + h(k-1) * (del(k) / h(k)));
end % for k

% we use the first derivatives as unknowns


switch bc
 
 case 1
  
  % not-a-knot
  
  % first row
  T(1,1) = h(2) * (h(1) + h(2));
  T(1,2) = (h(1) + h(2))^2;
  rhs(1) = (3 * h(1) * h(2) + 2 * h(2)^2) * (del(1) / h(1)) + h(1)^2 * (del(2) / h(2));
  
  % last row
  T(n,n-1) = (h(n-2) + h(n-1))^2;
  T(n,n) = h(n-2) * (h(n-2) + h(n-1));
  rhs(n) = (3 * h(n-2) * h(n-1) + 2 * h(n-2)^2) * (del(n-1) / h(n-1)) + h(n-1)^2 * (del(n-2) / h(n-2));
  
  % solve the tridiagonal system for the first derivatives
  yp = T \ rhs;
  
 case 2
  
  % natural spline
  
  % first row
  T(1,1) = 2;
  T(1,2) = 1;
  rhs(1) = 3 * (del(1) / h(1));
  
  % last row
  T(n,n) = 2;
  T(n,n-1) = 1;
  rhs(n) = 3 * (del(n-1) / h(n-1));
  
  yp = T \rhs;
  
 case 3
  
  if isempty(df1) || isempty(dfn)
   error('gm_spline: one or two of the values of the end derivative is missing')
  end % if
  
  rhs(2) = rhs(2) - h(2) * df1;
  rhs(n-1) = rhs(n-1) - h(n-2) * dfn;
  T = T(2:n-1,2:n-1);
  rhs = rhs(2:n-1);
  yp = T \rhs;
  yp = [df1; yp; dfn];
  
 otherwise
  error('gm_spline: wrong value of bc')
  
end % switch

% get the coefficients from the derivatives
% s(i,:) = [a3 a2 a1 a0]

for k = 1:n-1
 s(k,4) = y(k);
 s(k,3) = yp(k);
 s(k,2) = (1 / h(k)) * (3 * (del(k) / h(k)) - 2 * yp(k) - yp(k+1));
 s(k,1) = (1 / h(k)^2) * (-2 * (del(k) / h(k)) + yp(k) + yp(k+1));
end % for k


