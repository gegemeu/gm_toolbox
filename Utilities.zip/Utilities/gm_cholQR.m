function [Q,R]=gm_cholQR(V);
%GM_CHOLQR factorization of a tall and skinny matrix V = Q R

% This works only if the matrix is not too ill conditioned.
% Otherwise the method has to be iterated

% Input:
% V = matrix with columns of unit norm
%
% Output:
% Q = nearly orthogonal matrix
% R = upper triangular matrix such that V = Q R

%
% Author G. Meurant
% Oct 2015
%

% Gram matrix
S = V' * V;

% Cholesky factor
[R,msg] = chol(S);

if msg > 0
 [n,m] = size(V);
 R = zeros(m,m);
 Q = zeros(n,m);
 return
end

Q = V / R;

