function [teig,spsi,sakap] = gm_Toeplitz_asympt_spectrum(c,r,nn);
%GM_TOEPLITZ_ASYMPT_SPECTRUM asymptotic spectrum of a banded Toeplitz matrix

% c and r define theToeplitz matrix
% nn = number of points

% teig contains complex numbers which give the real and imaginary parts
% of points on the asymptotic spectrum

% Finds the asymptotic (size approaches infinity) spectrum �teig�
% and t() �sakap� and �spsi� (see Algorithm 4.1)
% for a banded Toeplitz matrix with first column �c� and first row
% �r� (only banded part of column and row) �nn� is a measure of the
% number of points computed on the spectrum

% From Beam and Warming 1993

diag = c(1);
lr = length(r);
nr = lr - 1;
lc = length(c);
nc = lc - 1;
ct = c(2:lc);
rt = r(2:lr);
mv = nr:-1:-nc;
pc0 = [fliplr(rt) 0 ct];
teig = [1:(nc + nr) * nn];
spsi = [1:(nc + nr) *nn];
sakap = [1:(nc + nr) * nn];
eigct = 0;
epst = 1000 * eps;
for j = 1:nn;
 psi = j * pi / (nn + 1);
 mvs = sin(mv * psi);
 pe = pc0 .* mvs;
 nroot = nc + nr;
 if pe(2) ~= 0
  if(abs(pe(1) / pe(2)) < 1000 * eps);
   pe = pe(2:nroot + 1);
   nroot = nroot- 1;
  end % if
 end % if pe
 ke = roots(pe);
 for k = 1:nroot;
  if ke(k) ~= 0
   kap = ke(k) * exp(1i * psi);
   lam = -(kap.^mv) * pc0.';
   pc = [fliplr(rt) lam ct];
   kc = roots(pc);
   akap = abs(kap);
   akc = abs(kc);
   skap = sort(akc);
   test = abs((skap(nc) - skap(nc + 1)) / (skap(nc) + skap(nc + 1)));
   if test < epst && skap(nc) > akap * (1 - epst) && skap(nc) < akap * (1 + epst);
    eigct = eigct + 1;
    teig(eigct) = -(lam - diag);
    spsi(eigct) = psi;
    sakap(eigct) = akap;
%     plot(real(teig(eigct)),imag(teig(eigct)),'mo')
%     hold on
%     pause
   end % if
  end % if ke
 end % for k
end % for j
teig = teig(1:eigct);
spsi = spsi(1:eigct);
sakap = sakap(1:eigct);


