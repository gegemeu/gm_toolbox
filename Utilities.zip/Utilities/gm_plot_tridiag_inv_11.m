function oneone=gm_plot_tridiag_inv_11(T);
%GM_PLOT_TRIDIAG_INV_11 plot of the (1,1) entries of the inverses of
% the principal submatrices of the tridiagonal T

%
% Author G. Meurant
% Sept 2019
%

n = size(T,1);
oneone = zeros(n,1);

for k = 1:n
 Tk = T(1:k,1:k);
 e1 = eye(k,1);
 x = Tk \ e1;
 oneone(k) = x(1);
end % for k

plot(oneone)


 