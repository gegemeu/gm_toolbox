function l = gm_minnzpr(A);
%GM_MINNZPR minimum number of non zeros per row of A

%
% Author G. Meurant
% October 2001
%

AA = spones(A);
l = full(min(sum(AA,2)));

