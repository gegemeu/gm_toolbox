function [Q,R]=gm_remove_column_QR(Q,R,k);
%GM_REMOVE_COLUMN_QR update QR when a column is removed 

%   [Q,R]=gm_remove_column_QR(Q,R,k); finds a QR decomposition for the
%   matrix [A(:,1),...,A(:,k-1),A(:,k+1),..A(:,n)] where
%   [Q,R]=qr(A)

% from Gander and Gander book

[m,n] = size(R);
R = R(:,[1:k-1,k+1:n]);

for j = k:n-1,
  G = planerot(R(j:j+1,j));
  R(j:j+1,j:n-1) = G * R(j:j+1,j:n-1);
  Q(:,j:j+1) = Q(:,j:j+1)*G';
end