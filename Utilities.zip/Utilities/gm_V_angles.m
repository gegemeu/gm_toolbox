function Theta = gm_V_angles(V);
%GM_V_ANGLES angles between the columns of V

% we also plot the angles

% Input:
% V = n x m matrix with unit norm columns
%
% Output:
% Theta = angles between the columns of V (in columns of Theta)

%
% Author G. Meurant
% October 2015
%

VV = abs(triu(V' * V));

Theta = real(triu(acosd(VV)));

gm_clearallfig

gm_vizmatjet(Theta,0,90);

figure

gm_vizmatjet(Theta);



