function [remd,remterm,gamrk,delta,termdel,firstterm,maxterm,indexmax,theta1,theta2,theta3] = gm_Gauss_Radau_remainder_vp(mu,eigA,vinit,T,dig,Tvp,eigvp,vinitvp,inv11);
%GM_GAUSS_RADAU_REMAINDER_VP analytic formula for the Gauss-Radau remainder with gm_vpc

% variable precision
%
% T is the Lanczos tridiagonal matrix
%
%
% Author G. Meurant
% Sept 2019
% Modified June 2021
%

dig_old = digits;
digits(dig);

fprintf('\n digits = %d \n',dig)
om = vinitvp;
% l = gm_vpc(eigA);
% l = eigvp;
n = length(eigA);
kmax = size(T,1);
rem = zeros(kmax,1);
rem = gm_vpc(rem);
remterm = zeros(kmax,n);
remterm = gm_vpc(remterm);
gamrk = gm_vpc(zeros(kmax,1));
firstterm = gm_vpc(zeros(kmax,1));
maxterm = gm_vpc(zeros(kmax,1));
delta = zeros(kmax,1);
indexmax = zeros(kmax,1);
% 3 first terms of Taylor expansions for j = 1,2,3
theta1 = gm_vpc(zeros(kmax,3)); 
theta2 = gm_vpc(zeros(kmax,3));
theta3 = gm_vpc(zeros(kmax,1));
epsi = (eigvp(1) - mu) / mu;
fprintf('\n relative dist of lambda min to mu = %12.5e \n',double(epsi))
% T = gm_vpc(T);
T = Tvp;

phase = 1;
for k = 4:kmax
 fprintf('\n -----------------------------------------------\n')
 fprintf('\n iteration %d \n',k)
 e1k1 = gm_vpc(eye(k-1,k-1));
 e1k = gm_vpc(eye(k,k));
 e1 = gm_vpc(eye(k,1));
 Tk = T(1:k,1:k);
 gam = Tk(k-1,k);
 Ik = gm_vpc(eye(k-1,k-1));
 vpt = sort(eig(Tk));
 [Xvpt,Dvpt] = eig(Tk(1:k-1,1:k-1));
 [vptm,I] = sort(diag(Dvpt));
 Xvpt = Xvpt(:,I);
 zk = (Xvpt(k-1,:)).^2;
%  termdel = gam^2 * zk' ./ (vptm - mu);
if vptm(1) - eigvp(1) > eigvp(1) - mu
 % phase 1
 theta1(k,1) = 1 ./ (vptm(1) - eigvp(1));
 theta1(k,2) = -(eigvp(1) - mu) ./ (vptm(1) - eigvp(1)).^2;
 theta1(k,3) = (eigvp(1) - mu)^2 ./ (vptm(1) - eigvp(1)).^3;
else
 % phase 2
 if phase == 1
  lambnew = (vptm(1) + mu) / gm_vpc(2);
  %eigvp(1) - lambnew
  %double(eigvp(1) - lambnew)
  phase = 0;
 end
 theta1(k,1) = 1 ./ (eigvp(1) - mu);
 theta1(k,2) = -(vptm(1) - eigvp(1)) ./ (eigvp(1) - mu)^2;
 theta1(k,3) = (vptm(1) - eigvp(1))^2 ./ (eigvp(1) - mu)^3;
end % if vptm(1)
if vptm(2) - eigvp(2) > eigvp(2) - mu
 theta2(k,1) = 1 ./ (vptm(2) - eigvp(2));
 theta2(k,2) = -(eigvp(2) - mu) ./ (vptm(2) - eigvp(2)).^2;
 theta2(k,3) = (eigvp(2) - mu)^2 ./ (vptm(2) - eigvp(2)).^3;
else
 theta2(k,1) = 1 ./ (eigvp(2) - mu);
 theta2(k,2) = -(vptm(2) - eigvp(2)) ./ (eigvp(2) - mu)^2;
 theta2(k,3) = (vptm(2) - eigvp(2))^2 ./ (eigvp(2) - mu)^3;
end % if vptm(2)
if vptm(3) - eigvp(3) > eigvp(3) - mu
 theta3(k,1) = 1 ./ (vptm(3) - eigvp(3));
 theta3(k,2) = -(eigvp(3) - mu) ./ (vptm(3) - eigvp(3)).^2;
 theta3(k,3) = (eigvp(3) - mu)^2 ./ (vptm(3) - eigvp(3)).^3;
else
 theta3(k,1) = 1 ./ (eigvp(3) - mu);
 theta3(k,2) = -(vptm(3) - eigvp(3)) ./ (eigvp(3) - mu)^2;
 theta3(k,3) = (vptm(3) - eigvp(3))^2 ./ (eigvp(3) - mu)^3;
end % if vptm(3)

  %   nextnextterm(k,j) = -(vptm(j) - eigvp(1))^3 ./ (eigvp(1) - mu)^4;

 termdel = zk' ./ (vptm - mu);
 termd = 1 ./ (vptm - mu);
 firstterm(k) = gam^2 * zk(1) * termd(1);
%  firstterm(k) = zk(1) * termd(1);
 [ma,I] = max(termdel);
 maxterm(k) = gam^2 * ma;
%  maxterm(k) = ma;
 indexmax(k) = double(I(1));
 en = gm_vpc(zeros(k-1,1));
 en(k-1) = gm_vpc(1);
 del = (Tk(1:k-1,1:k-1) - mu * Ik) \ (gam^2 * en);
 eigdel  = sort(Tk(1:k-1,1:k-1) - mu * Ik);
 if double(eigdel(1)) < 0
  fprintf('\n ********** k-1 = %d, T (k-1) - mu I not positive definite ***************\n',k-1)
 end % if
%  del = (Tk(1:k-1,1:k-1) - mu * Ik) \ (en);
 if phase == 0
% this is worse than lambnew
%   lambn = (vptm(1) + vptk(1) + gm_vpc(2) * mu) / gm_vpc(4)
%   eigvp(1) - lambn
%   double(eigvp(1) - lambn)
  p = ceil(log10(eigvp(1)) - log10(vptm(1) - eigvp(1)));
  p = double(p) + 1;
  pp = 10^(-p);
  lambnew = (gm_vpc(1) + gm_vpc(pp)) * eigvp(1);
  pt = fix((log10(vptm(1)) - log10(vptm(1) - eigvp(1))));
  pt = double(pt) + 1 / 2;
  ppt = 10^(-pt);
  lambne = (gm_vpc(1) - gm_vpc(ppt)) * vptm(1);
  deln = del + (lambne - mu) * ((Tk(1:k-1,1:k-1) - lambne * Ik) \ del);
%   deln = del + (lambnew - mu) * ((Tk(1:k-1,1:k-1) - lambnew * Ik) \ del);
%   deln = del + (eigvp(1) - mu) * ((Tk(1:k-1,1:k-1) - eigvp(1) * Ik) \ del);
%   [double(del(k-1)) double(deln(k-1))]
%   del = deln;
 end % if
 Tk(k,k) = mu + del(k-1);
 delta(k) = double(del(k-1));
 vptk = sort(eig(Tk));
 xk = Tk \e1k;
 xk1 = Tk(1:k-1,1:k-1) \ e1k1;
 x1 = Tk \ e1;
 gamr = xk(1) - xk1(1);
 gamrk(k) = gamr; % difference between errA^2 and the remainder

 distvpt = gm_vpc(zeros(n,1));
 for j = 1:n
  distvpt(j) = min(abs(eigvp(j) - vpt));
 end % for j
%  fprintf('\n minimum distance of eigenvalues to Ritz values \n')
%  double(distvpt)'
 % vptd = double(vpt)'
 % vptkd = double(vptk)'
 if vptm(1) - eigvp(1) > eigvp(1) - mu
  fprintf('\n Phase 1 for the first term \n')
 else
  fprintf('\n Phase 2 for the first term \n')
 end % if
 fprintf('\n main term and followers, solve for T (%d) \n',k-1)
 fprintf('\n theta - lambda1 = %12.5e, theta - mu = %12.5e \n',double(vptm(1)-eigvp(1)),...
  double(vptm(1)-mu))
 for j = 1:3
  fprintf(' j = %d, %12.5e, %12.5e, %12.5e \n',j,double(theta1(k,j)),double(theta2(k,j)),...
   double(theta3(k,j)));
 end % for j
 fprintf('\n sum first term = %12.5e, true val = %12.5e \n',sum(double(theta1(k,:))),double(1/(vptm(1)-mu)))
 fprintf('\n sum second term = %12.5e, true val = %12.5e \n',sum(double(theta2(k,:))),double(1/(vptm(2)-mu)))
 fprintf('\n sum third term = %12.5e, true val = %12.5e \n',sum(double(theta3(k,:))),double(1/(vptm(3)-mu)))
 d = min(vpt - eigvp(1));
 fprintf('\n\n min dist Ritz val of Tk to lambda min = %12.5e \n',double(d))
 fprintf('\n deltak = %12.5e \n',double(del(k-1)))
 fprintf('\n coeff beta^2 = %12.5e \n',double(gam^2))
 fprintf('\n terms of delta k without multiplicating coeff and without weights \n')
 double(termd)'
 fprintf('\n terms of delta k with multiplicating coeff \n')
 double(gam^2 * termdel)'
 fprintf('\n maxterm = %12.5e, sum = %12.5e, last comp y = %12.5e \n',double(maxterm(k)),double(sum(gam^2 * termdel)), delta(k))
 %fprintf('\n last comp of eigenvectors squared \n')
 %double(zk)
 % terms of the sum
%  fprintf('\n Ritz values of T tilde = \n')
%  vptk(1:2)
 %fprintf('\n (1,1) entry of the inverse of tilde T, diff with inv(1,1) of Tn \n')
 %x1(1)
 %x1(1) - inv11
 %double(x1(1) - inv11)
 s = gm_vpc(0);
 for j = 1:n
  remterm(k,j) = (om(j) / eigvp(j)) * ((eigvp(j) - mu) / mu) * prod((eigvp(j) - vptk(2:k)) ./ vptk(2:k)).^2;
  s = s + remterm(k,j);
 end % for j
 rem(k) = s;
 diff = gm_vpc(zeros(k,1));
 for kk = 1:k
  diff(kk) = min(abs(vptk(kk) - eigvp));
 end % for kk
 [maxrem,J] = max(double(remterm(k,:)));
 fprintf('\n maxterm of remterm = %12.5e for j = %d, sum = %12.5e, gamrk = %12.5e, g - s = %12.5e \n',maxrem,J(1),double(s),double(gamrk(k)),...
  double(gamrk(k)-s))
%  double(vptk)' % eigenvalues of tilde T
%  double(diff)' % minimum distance to an eigenvalue for each Ritz value of tilde T
end % for k

remd = abs(double(rem));
remterm = double(remterm);
gamrk = double(gamrk);
termdel = double(termdel);
firstterm = double(firstterm);
maxterm = double(maxterm);
theta1 = double(theta1);
theta2 = double(theta2);
theta3 = double(theta3);



digits(dig_old);




