function [Q,R]=gm_qr_sym(A);
%GM_QR_SYM QR factorization of a symmetric matrix

% we use an incremental update and Givens rotations

% see: Updating the QR Factorization and the Least Squares Problem
% S. Hammarling and C. Lucas (2008)

% Input:
% A = symmetric matrix
%
% Output:
% Q, R = QR factorization of A
%

%
% Author G. Meurant
% June 2016
%

[m,n] = size(A);
if m ~= n
 error('gm_qr_sym: A must be square')
end

Q = 1;
R = A(1,1);

for k = 2:m
 u = A(1:k-1,k);
 alpha = A(k,k);
 [Q,R] = gm_qr_add(Q,R,u,alpha);
end

