function y=gm_apply_house_rev(V,bet,ns,ne,x);
%GM_APPLY_HOUSE_REV applies the Householder reflections contained in V, bet to
%x in order ne,...,ns

% Input: 
% V = matrix of the Householder vectors
% bet = vector of Householder coefficients
% ns = starting index in V
% ne = ending index in V
% x = vector
%
% Output:
% y = transformed vector

%
% Author G. Meurant
% Oct 2016
%

nv = size(V,2);
if ns < 1 || ne > nv || ns > ne
 error('gm_apply_house: Index error')
end

for k = ne:-1:ns
 vk = V(:,k);
%  x = x - bet(k) * (V(:,k)' * x) * V(:,k);
 x = x - bet(k) * (vk' * x) * vk;
end

y = x;
