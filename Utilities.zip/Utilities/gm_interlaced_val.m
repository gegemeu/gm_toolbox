function Mu = gm_interlaced_val(n,lamb);
%GM_INTERLACED_VAL returns interlaced values

% Input:
% n = number of values used in lamb
% lamb = values to interlace, typically real eigenvalues
%
% Ouput:
% Mu = matrix whose columns contains the interlaced values
%  we use the middle of each interval

% the last column of Mu is equal to lamb

%
% Author G. Meurant
% January 2019
%

if nargin == 1
 % lamb is not given, take random numbers
 rng('default')
 lamb = abs(randn(n,1));
end % if

lamb = lamb(:);
if length(lamb) < n
 error(' There is not enough elements in lamb')
end % if
lamb = sort(lamb,'ascend');

Mu = zeros(n,n);
Mu(:,n) = lamb(1:n);
for k = n-1:-1:1
 y = Mu(1:k+1,k+1);
 Mu(1:k,k) = y(1:k) + diff(y) / 2;
end % for k


