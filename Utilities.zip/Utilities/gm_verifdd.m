function eA = gm_verifdd(A);
%GM_VERIFDD checks if A is diagonally dominant

% the conponents of vector eA must be positive for row diagonal dominance

%
% Author G. Meurant
%

Ab = abs(A);
LU = -(tril(Ab,-1) + triu(Ab,1));
D = diag(diag(Ab));
Am = D + LU;
e = ones(size(A,1),1);
eA = Am * e;
