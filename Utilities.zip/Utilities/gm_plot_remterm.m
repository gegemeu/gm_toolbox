function gm_plot_remterm(remterm,remd);
%GM_PLOT_REMTERM plots the Gauss remainder terms

[n,m] = size(remterm);

for k = 1:n
 plot(log10(abs(remterm(k,:))))
 hold on
 plot(m,log10(abs(remd(k))),'r*')
 title(['k = ' num2str(k)])
 hold off
 pause
end % for k

