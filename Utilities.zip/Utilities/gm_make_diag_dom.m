function ADD=gm_make_diag_dom(A,epsi);
%GM_MAKE_DIAG_DOM shifts the diagonal to make A diagonally dominant

% Input:
% A = matrix
% epsi = factor of diagonal dominance (> 1)
%
% Output:
% ADD = new matrix

%
% Author G. Meurant
% Sept 2012
% Updated Sept 2015
%

if nargin == 1
 epsi = 1;
end

epsi = max(1,epsi);

n = size(A,1);

ADD = A - diag(diag(A));
AMD = abs(ADD);

DD = abs(diag(A));

e = ones(n,1);
x = AMD * e;

ratio = DD ./ x;

fac = ones(n,1);

I = find(ratio < 1);
fac(I) = epsi ./ ratio(I);

ADD = diag(diag(A) .* fac) + ADD;




