function gm_cbar(vp)
%GM_CBAR bar visualization of real eigenvalues

% Input:
% vp = vector giving the eigenvalues (or anything else!)

%
% Author G. Meurant
% updated April 2015
%

n = length(vp);
lmin = min(vp);
lmax = max(vp);

figure

x(1) = vp(1);
x(2) = vp(1);
y(1) = -0.5;
y(2) = 0.5;
plot(x,y,'b')
hold on

for i = 2:n
 x(1) = vp(i);
 x(2) = vp(i);
 plot(x,y,'b')
end

del = (lmax - lmin) / 10;
axis([lmin - del, lmax + del, -1, 1])

set(gca,'YTick',[])

hold off
