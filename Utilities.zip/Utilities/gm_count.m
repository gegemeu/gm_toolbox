function s=gm_count(a,epsi);
%GM_COUNT number of different (by epsi) components in vector a
% relative comparison
%

%
% Author G. Meurant
% updated April 2015
%

if nargin < 2
 epsi = 1e-4;
end

n = length(a);
b = sort(a);
s = 1;

for i = 2:n
 if abs(b(i)-b(i-1)) > epsi * abs(b(i))
  s = s + 1;
 end
end

