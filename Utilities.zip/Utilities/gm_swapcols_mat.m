function B=gm_swapcols_mat(A);
%GM_SWAPCOLS_MAT permutes the columns of A, i -> m-i+1

%
% Author G. Meurant
% Feb 2006
%

[n,m] = size(A);
B = zeros(n,m);

B(:,1:m) = A(:,m:-1:1);