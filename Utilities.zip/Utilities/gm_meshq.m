function QQ = gm_meshq(q)
%GM_MESHQ from a 1D mesh with n elements to a 2D mesh with n = m x m

% q is a vector and QQ a matrix

%
% Author G. Meurant
%

n = size(q,1);
m = sqrt(n);
if m^2 ~= n
 error('gm_meshq: n has to be a square')
end
QQ = zeros(m,m);

for i=1:m
 QQ(:,i) = q((i-1) * m + 1 : i * m);
end
