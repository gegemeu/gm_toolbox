function [x,y] = gm_TwoSum(a,b);
%GM_TWOSUM computes the sum of a and b and its rounding error

% Knuth algorithm

% Input:
% a, b = floating point numbers to be summed
%
% Output:
% x = sum of a and b
% y = rounding error

%
% April 2014
% Updated August 2015
%

x = a + b;
z = x - a;
y = (a - (x - z)) + (b - z);

