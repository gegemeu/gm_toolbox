function B=gm_vecsetmat(A);
%GM_VECSETMAT vectorizes a set of matrices A(:,:,k), k=1,...

% Input:
% A = three-dimensional array
%
% Output:
% B = matrix whose columns are the vectorized  versions of A(:,:,k)

%
% Author G. Meurant
% Feb 2011
% Updated Sept 2015
%

m = size(A,3);
n = size(A,1);
n2 = n * n;

B = zeros(n2,m);

for k = 1:m
 Ak = A(:,:,k);
 B(:,k) = Ak(:);
end

