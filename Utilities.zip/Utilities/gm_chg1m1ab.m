function y = gm_chg1m1ab(x,a,b);
%GM_CHG1M1AB change of coordinate from x in [-1,1] to y in [a,b]

%
% Author G. Meurant
% May 2008
%

y = (x * (b - a) + a + b) / 2;

