function s=gm_num2tex(x,ndec);
%GM_NUM2TEX converts a floating point to a string in TeX format

% Input:
% x = floating point number
% ndec = number of decimal digits after the point
%
% Ouput:
% s = string

%
% Author G. Meurant
% Dec 2016
%

if nargin < 2
 ndec = 5;
end

if ndec <= 0
 ndec = 5;
end

if isempty(x)
 s = '';
 return
end

if isnan(x)
 s = 'NaN';
 return
end

% convert x to a string
% format 
form = ['%' num2str(ndec+7) '.' num2str(ndec) 'e'];
xs = num2str(x,form);

expoo = '';
nxs = length(xs);
% analyze the string, looking for "e"
for k = 1:nxs
 if xs(k) == 'e'
  mant = xs(1:k-1);
  expoo = xs(k+1:nxs);
 end
end

% get the sign and the value of the exponent
sig = '';
nexpo = length(expoo);
for k = 1:nexpo
 if expoo(k) == '-'
  sig = '-';
  mexp = k+1;
 end
 if expoo(k) == '+'
  sig ='';
  mexp = k+1;
 end
end

expoo = expoo(mexp:nexpo);
% get rid of the leading zeros
nexpo = length(expoo);
kk = nexpo;
for k = 1:nexpo
 if expoo(k) ~= '0'
  kk = k;
  break
 end
end
expos = expoo(kk:nexpo);

% put the pieces together
s = [mant '\ 10^{' sig expos '}'];



