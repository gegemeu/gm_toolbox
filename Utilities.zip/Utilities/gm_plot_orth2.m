function north = gm_plot_orth2(V,V2);
%GM_PLOT_ORTH2 deviation form orthonormality

% This can be used to see how an orthonormal basis is loosing orthogonality

% Input:
% V = matrix
%
% Output:
% north = norm(I - V' V)

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

m = size(V,2);
north = zeros(2,m);

for k = 1:m
 north(1,k) = norm(eye(k,k) - V(:,1:k)' * V(:,1:k));
 north(2,k) = norm(eye(k,k) - V2(:,1:k)' * V2(:,1:k));
end

semilogy(north(1,:))
hold on
semilogy(north(2,:),'r--')
title('norm(I_k - V_k^T V_k)')
hold off


