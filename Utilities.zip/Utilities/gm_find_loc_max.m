function [I,J,values] = gm_find_loc_max(A);
%GM_FIND_LOC_MAX finds the local maxima in A

% a local maxima is such that A-i,j) is larger than its 4 neighbours
%
% Input:
% A = real matrix of positive numbers
%
% Output:
% I, J = indices of the local maxima
% values = local maxima

%
% Author G. Meurant
% February 2017
%

[m,n] = size(A);

I = zeros(n,1);
J = zeros(m,1);
values = zeros(m,n);
ind = 0;

for i = 1:n
 for j = 1:m
  % for each point look at the values of the 4 neighbours
  aij = A(j,i);
  l = max(1,i-1);
  r = min(n,i+1);
  b = max(1,j-1);
  t = min(m,j+1);
  al = A(j,l);
  ar = A(j,r);
  ab = A(b,i);
  at = A(t,i);
  if (aij > al) && (aij > ar) && (aij > ab) && (aij > at)
   % local maxima
   ind = ind + 1;
   I(ind) = i;
   J(ind) = j;
   values(ind) = aij;
  end % if
 end % for j
end % for i

I = I(1:ind);
J = J(1:ind);
values = values(1:ind);



   