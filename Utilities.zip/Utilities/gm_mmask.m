function C = gm_mmask(A,B);
%GM_MMASK creates a sparse matrix with the values of A and the pattern of B 

% A and B must be of same dimension

%
% Author G. Meurant
% March 2001
%

[n,m] = size(A);
[nb,mb] = size(B);
if nb ~= n || mb ~= m
 error('gm_mmask: A and B must have the same dimension')
end

[i,j] = find(B);
AA = A(:);
BB = B(:);
ind = find(BB);
C = sparse(i,j,AA(ind),n,m);


