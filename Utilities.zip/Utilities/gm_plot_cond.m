function cA = gm_plot_cond(A);
%GM_PLOT_COND plots the condition number of A(:,1:k), k=1:m

% Input:
% A = matrix

%
% Author G. Meurant
% August 2015
%

[n,m] = size(A);
cA = zeros(1,m);
A = full(A);

for k = 1:m
 cA(k) = cond(A(:,1:k));
end

semilogy(cA);

figure

plot(cA);



