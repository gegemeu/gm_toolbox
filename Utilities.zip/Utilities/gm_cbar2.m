function gm_cbar2(vp,vp1)
%GM_CBAR2 bar visualization of two sets of real data
% on the same scale
%

%
% Author G. Meurant
% updated April 2015
%

n = length(vp);
n1 = length(vp1);
lmin = min(vp);
lmax = max(vp);
lmin1 = min(vp1);
lmax1 = max(vp1);
lmin = min(lmin,lmin1);
lmax = max(lmax,lmax1);

figure

x(1) = vp(1);
x(2) = vp(1);
y(1) = 0.25;
y(2) = 0.75;
plot(x,y,'b')
hold on

for i = 2:n
 x(1) = vp(i);
 x(2) = vp(i);
 plot(x,y,'b')
end

x(1) = vp1(1);
x(2) = vp1(1);
y(1) = -0.25;
y(2) = -0.75;
plot(x,y,'b')

for i = 2:n1
 x(1) = vp1(i);
 x(2) = vp1(i);
 plot(x,y,'b')
end

del = (lmax - lmin) / 10;
axis([lmin - del, lmax + del, -1, 1])

hold off


