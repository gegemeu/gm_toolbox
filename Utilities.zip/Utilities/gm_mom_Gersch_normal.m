function gm_mom_Gersch_normal(A,v,k,fac);
%GM_MOM_GERSCH_NORMAL Gerschgorin-like regions for Arnoldi Ritz values
% for a normal matrix

% Input:
% A = normal matrix
% v = vector
% k = iteration number
% fac = multiplying factor for the FOV window

%
% Author G. Meurant
% Dec 2014
% Updated Sept 2015
%

% plot the field of values

[xmin,xmax,ymin,ymax] = gm_fvmod(A);

hold on

if nargin < 4
 fac = 5;
end

xmin = fac *xmin;
xmax = fac * xmax;
dx = xmax - xmin;
ymin = fac *ymin;
ymax = fac * ymax;
dy = ymax - ymin;
dxy = max( dx,dy);
xmax = xmin + dxy;
ymax = ymin + dxy;
axis([xmin xmax ymin ymax]);
axis square

% moment matrices

[M,ML] = gm_moment2(A,v);

M = M(1:k,1:k);
ML = ML(1:k,1:k);

% we consider the union of the Gerschgorin disks
% but this may be much larger than the FOV of A (which is not known
% in practical problems)
for j = 1:k
 
 z = ML(j,j) / M(j,j);
 
 sumb = sum(abs(M(j,:))) - abs(M(j,j));
 suma = sum(abs(ML(j,:))) - abs(ML(j,j));
 
 rhoa = suma / abs(M(j,j));
%  rhoa = suma / abs(ML(j,j));
 rhob = sumb / abs(M(j,j));
 
 gm_plot_Arn_Gersch(z,rhoa,rhob,xmin,xmax,ymin,ymax);
 
end

% check

check = 1;
if check == 1
 [V,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,v,k,'reorth','noprint');
 eigH = eig(full(H));
 plot(real(eigH),imag(eigH),'b+')
end

hold off

