function gm_fov_scaled(A,nsample);
%GM_FOV_SCALED random estimation of the scaled field of values

% b' A b / ||A b||

% Input:
% A = matrix
% nsample = number of random vectors

%
% Author G. Meurant
% November 2009
%

n = size(A,1);

figure
hold on

for k = 1:nsample/10
 % real vectors
 b = randn(n,1);
 b = b / norm(b);
 Ab = A * b;
 value = b' * Ab / norm(Ab);
 plot(value,0,'m+')
end

for k = 1:nsample
 % complex vectors
 b = randn(n,1) + 1i * randn(n,1);
 b = b / norm(b);
 Ab = A * b;
 value = b' * Ab / norm(Ab);
 plot(real(value),imag(value),'b+')
end

% use the eigenvectors
[X,D] = eig(full(A));

for k = 1:n
 % eigenvectors
 b = X(:,k);
 b = b / norm(b);
 Ab = A * b;
 value = b' * Ab / norm(Ab);
 plot(real(value),imag(value),'g+')
end

% constant vector
b = ones(n,1);
b = b / norm(b);
Ab = A * b;
value = b' * Ab / norm(Ab);
plot(real(value),imag(value),'c+')

% plot the unit circle
oldx = 1;
oldy = 0;
for k = 1:50
 theta = 2 * k * pi / 50;
 y = sin(theta);
 x = cos(theta);
 plot([oldx x],[oldy y],'r')
 oldx = x;
 oldy = y;
end

axis([-1.1 1.1 -1.1 1.1])
axis square

hold off

