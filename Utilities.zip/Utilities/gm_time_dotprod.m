function [c,multflops,gflops,time] = gm_time_dotprod(x,y);
%GM_TIME_DOTPROD dot product timing

% Input:
% x, y = vectors
%
% Output:
% c = x^T y
% multflops = number of floating point operations
% gflops = computation speed (gigaflops)
% time = computing time

%
% Author G. Meurant
% January 2012
% Updated July 2016
%

n = size(x,1);


% number of operations of one multiply (dense vectors)
nop = 2 * n - 1;

% repeat kmax times
kmax = 50000;
if n < 100
 % small vectors
 kmax = 20000;
end
% large vectors
if n > 1000
 kmax = 5000;
end

% tstart = cputime;
tic;

for k = 1:kmax
 c = x' * y;
end

% time = cputime - tstart;
time = toc;

mult = kmax * nop / time;

% gigaflops
gflops = mult * 1e-9;

time = time / kmax;
multflops = nop;

