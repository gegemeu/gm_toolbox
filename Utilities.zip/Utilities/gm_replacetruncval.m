function y=gm_replacetruncval(x,val);
%GM_REPLACETRUNCVAL put values less than val to val

%
% Author G. Meurant
% april 2004
%

y = x;

y(find(abs(x) < val)) = val;

