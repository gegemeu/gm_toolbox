function T = gm_trid_part(A);
%GM_TRID_PART extracts the tridiagonal part of A with spdiags

%
% Author G. Meurant
%

n = size(A,1);
ind = [-1 0 1];
T = spdiags(spdiags(A,ind),ind,n,n);

