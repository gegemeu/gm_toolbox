function x=gm_solve_triangle(A,b);
%GM_SOLVE_TRIANGLE solves a lower triangular system with correction of the rounding errors 
% the rounding errors

% gives a better result for badly conditioned matrices

% Input:
% A = lower triangular matrix
% b = right-hand side
%
% Output:
% x = solution of A x = b

%
% April 2014
% Updated August 2015
%

n = size(A,1);

x = zeros(n,1);
Del = zeros(n,1);

for i = 1:n
 s = b(i);
 u = 0;
 for j = 1:i-1
  [p,pij] = gm_TwoProd(A(i,j),x(j));
  [s,sig] = gm_TwoSum(s,-p);
  u = u - (A(i,j) * Del(j) + pij - sig);
 end % for j
 
 [x(i),del] = gm_ApproxTwoDiv(s,A(i,i));
 Del(i) = u / A(i,i) + del;
end % for i

% correction due to rounding errors

x(2:n) = x(2:n) + Del(2:n);

