function sig=gm_smax_estR(S);
%GM_SMAX_ESTR estimate of the largest singular value of S
% Paige's measure of loss of independence

% this is done incrementally with INE
% see Tebbens and Tuma, SIMAX, v 35 (2014)

% Input:
% S = upper triangular matrix
%
% Output:
% sig = estimate of the largest singular value of S

%
% Author G. Meurant
% March 2015
%

n = size(S,1);
if n == 1
 sig = S(1,1);
 return
end

% initialization
R = S(1:2,1:2);
[U,Sig,V] = svd(R);
s = Sig(1,1);
z = V(:,1);

if n == 2
 sig = s;
 return
end

for k = 3:n
 v = S(1:k-1,k);
 gamma = S(k,k);
 zRv = z' * R' * v;
 M = [s^2, zRv; zRv, v' * v + gamma^2];
 [X,D] = eig(M);
 eigM = diag(D);
 if abs(eigM(1) - eigM(2)) <= 1e-10
  smax = 0;
  cmax = 1;
  eigmax = eigM(1);
 else
  [eigmax,I] = max(eigM);
  smax = X(1,I(1));
  cmax = X(2,I(1));
 end
 s = sqrt(eigmax);
 z = [smax * z; cmax];
 R = S(1:k,1:k);
end

sig = real(s);




