function Ci = gm_inv_companion_matrix(C);
%GM_INV_COMPANION_MATRIX inverse of a companion matrix

% Input:
% C = companion matrix (coefficients in the last column)
%
% Output:
% Ci = inverse of C

%
% Author G. Meurant
% March 2024
%

n = size(C,1);
alp = -C(:,n);

Ci = zeros(n,n);
Ci(1:n-1,2:n) = eye(n-1,n-1);

Ci(1:n-1,1) = -alp(2:n) / alp(1);
Ci(n,1) = -1 / alp(1);

