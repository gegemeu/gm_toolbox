function t = gm_geomspace(a,b,n);
%GM_GEOMSPACE geometric sequence of n points between a and b

%
% March 2012
% Updated Sept 2015
%

a1 = a;
b1 = b;

b = abs(b1-a1) + 1;
a = 1;

r = (b / a)^(1 / (n-1));
m = r.^(0:(n-1));
t = a * m;

t = b + a - fliplr(t);

t = a1 - 1 + t;

if b1 < a1
 t = 2 * a1 - t;
end

