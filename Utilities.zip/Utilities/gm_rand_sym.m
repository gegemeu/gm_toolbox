function A=gm_rand_sym(n);
%GM_RAND_SYM generates a random symmetric matrix

% Input:
% n = order of A
%
% Output:
% A = random symmetric matrix

% 
% Author G. Meurant
% November 2009
% Updated September 2015
%

R = triu(randn(n,n));
RR = triu(R,1);

A = R + RR';

