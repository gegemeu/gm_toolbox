function x = gm_rand_decrease(n);
%GM_RAND_DECREASE random positive decreasing sequence

% Input: 
% n = length of the vector
%
% Output:
% x = vector

%
% Author G. Meurant
% September 2018
%

x = zeros(n,1);
m = 10000;
rng('default')
x(1) = rand;
nn = 2;
for k = 2:m
 y = rand;
 if y > x(nn-1)
  continue
 end % if
 x(nn) = y;
 if nn == n
  break
 end % if
 nn = nn + 1;
end % for k

