function B=gm_trunc_mat_abs_low(A,alp);
%GM_TRUNC_MAT_ABS_LOW truncates the matrix A 

% All the entries whose modulus are smaller than alp are set to +- alp
% depending on their sign

%
% Author G. Meurant
% Jan 2012
% Updated Sept 2015
%

alp = abs(alp);

n = size(A,1);

B = A;

for i = 1:n
 ind = find(A(i,:) > -alp & A(i,:) < 0);
 B(i,ind) = -alp;
 ind = find(A(i,:) < alp & A(i,:) > 0);
 B(i,ind) = alp;
end

