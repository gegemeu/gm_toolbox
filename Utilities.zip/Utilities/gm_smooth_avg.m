function g=gm_smooth_avg(f,m);
%GM_SMOOTH_AVG smoothing a curve by avaraging

% Input:
% f = noisy curve
% m = number of points in the average

% Output:
% g = smoothed curve

% We average only to the left because we assume that f canbe given one
% point at a time

%
% Author G. Meurant
% May 2022
%

n = length(f);
g = zeros(1,n);
g(1:m-1) = f(1:m-1);

for k = 1:n
 mm = min(k,m);
 g(k) = sum(f(max(1,k-m+1):k)) / mm;
end % for

