function table = gm_latextab(A,d);
%GM_LATEXTAB converts a Matlab matrix into a LaTeX tabular environment

%
% If A is a matrix, typing gm_latextab(A) returns in the worspace a LaTeX tabular
% environment. Hence, a matrix like A = [3 4 ; 8 9] returns a string matrix like
%
% \begin{tabular}{cc} 3 & 4 \\ 8 & 9 \end{tabular}
%
% Typing gm_latextab(A,d) limits the number of decimals to d

% Adapted from Jorge Dur�n 2008

if nargin == 1
 dig = 4;
else
 dig = d;
end

colamp = char(kron(' & ',ones(size(A,1),1)));
colend = char(kron(' \\',ones(size(A,1),1)));
colend(size(colend,1),size(colend,2)-2:size(colend,2)) = '   ';

table = [];
for j=1:size(A,2)
 table = [table num2str(A(:,j),dig) colamp];
end

table(:,size(table,2)-2:size(table,2)) = colend;

header = ['\begin{tabular}{' char(kron('c',ones(1,size(A,2)))) '}'];
footer = '\end{tabular}';

cols = max([size(header,2) size(table,2) size(footer,2)]);

table = [header char(kron(' ',ones(1,cols-size(header,2))))
 table  char(kron(' ',ones(size(table,1),cols-size(table,2))))
 footer char(kron(' ',ones(1,cols-size(footer,2))))];



