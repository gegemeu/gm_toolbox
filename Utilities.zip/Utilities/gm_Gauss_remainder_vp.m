function [remd,remterm] = gm_Gauss_remainder_vp(eigA,vinit,T,dig,Tvp,eigvp,vinitvp);
%GM_GAUSS_REMAINDER_VP analytic formula for the Gauss remainder with gm_vpc

% variable precision
%
% T is the Lanczos tridiagonal matrix

%
% Author G. Meurant
% Sept 2019
%

dig_old = digits;
digits(dig);
om = vinitvp;
% l = gm_vpc(eigA);
% l = eigvp;
n = length(eigA);
kmax = size(T,1);
rem = zeros(kmax,1);
rem = gm_vpc(rem);
remterm = zeros(kmax,n);
remterm = gm_vpc(remterm);
% T = gm_vpc(T);
T = Tvp;

for k = 1:kmax
 Tk = T(1:k,1:k);
 vptk = sort(eig(full(Tk)));
 % terms of the sum
 s = gm_vpc(0);
 for j = 1:n
%   p = gm_vpc(1);
%   for kk = 1:k
%    p = p * ((eigvp(j) - vptk(kk)) / vptk(kk))^2;
%   end % for kk
%   remterm(k,j) = (om(j) / eigvp(j)) * p;
  remterm(k,j) = (om(j) / eigvp(j)) * prod((eigvp(j) - vptk) ./ vptk).^2;
  s = s + remterm(k,j);
 end % for j
 rem(k) = s;
 diff = gm_vpc(zeros(k,1));
 for kk = 1:k
  diff(kk) = min(abs(vptk(kk) - eigvp));
 end % for kk
 fprintf('\n -----------------------------------------------\n')
 fprintf('\n iteration %d \n',k)
 vptkd = double(vptk)'
 [maxrem,J] = max(double(remterm(k,:)));
 fprintf('\n maxterm = %12.5e for j = %d, sum = %12.5e \n',maxrem,J(1),double(s))
 double(diff)' % minimum distance to an eigenvalue for each Ritz value
end % for k

remd = double(rem);
remter = double(remterm);

figure
plot(log10(remd))
title(['Gauss remainder ', 'dig = ' num2str(dig)])

figure
plot(log10(abs(remterm')))
title('Gauss, terms of the sums')



digits(dig_old);




