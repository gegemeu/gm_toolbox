function bin=gm_binary(x);
%GM_BINARY binary form of a double precision number

if isa(x,'double')
 [s,e,f] = gm_ieee754(x);
elseif isa(x,'single')
 [s,e,f] = gm_ieee754s(x);
else
 error('gm_binary: the input must be a single or a double')
end % if

bin = [s ' ' e ' ' f];