function [msing_new,Q_new,R_new]=gm_upd_msing_Fas(Q,R,v,msing);
%GM_UPD_MSING_FAS update of the estimate of the min singular value

% Method from C. Fassino,
% On updating the least singular value: a lower bound,
% Calcolo v 40, no. 4 (2003), pp. 213-229

% Input:
% Q,R = factors from the previous matrix A
% v = vector which is added to the matrix -> [A, v]
% msing = estimate for A
%
% Output:
% msing_new, Q_new, R_new = new values after the update

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

k = size(R,2);
m = size(Q,1);

if msing == 0
 % do nothing since msing_new <= msing
 msing_new = 0;
 [Q_new,R_new] = qrinsert(Q,R,k+1,v);
 return
end

qv = Q' * v;
c1 = qv(1:k);
c2 = qv(k+1:m);

% norm of the residual of the least squares problem
% || A x - v ||
rho = norm(c2);

if rho == 0
 msing_new = msing;
elseif norm(c1) == 0
 msing_new = min(msing,rho);
else
 % solve the least squares problem
 x = R(1:k,1:k) \ c1;
 nx = norm(x)^2;
 B = nx + rho^2 / msing^2 - 1;
 E = 1 + (B - sqrt(B^2 + 4 * nx)) / 2;
 msing_new = msing * sqrt(E);
end

% update the QR factorization
[Q_new,R_new] = qrinsert(Q,R,k+1,v);


 