function y = gm_chebyshev(x,p);
%GM_CHEBYSHEV Chebyshev polynomials applied to a vector

% all polynomials up to order p

% Input:
% x = vector
% p = maximum order
% 
% Output:
% the columns of Y contain the Chebyshev polynomials applied to the components of x

%
% Author G. Meurant
%

y = ones(length(x),p);
x = x(:); 
if p == 1
 return
end
%
y(:,2) = x;
for k = 3:p
 y(:,k) = 2 * x .* y(:,k-1) - y(:,k-2);
end
