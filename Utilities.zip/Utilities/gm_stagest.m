function [maxy,ny] = gm_stagest(A,L,dd1,x,precond,maxy);
%GM_STAGEST computes a quantity for the estimation of the maximum accuracy

%
% Author G. Meurant
% March 2001
% updated June 2015
%

switch precond
 
case {'no','po','tw','ml'}
 ny = norm(x);
 maxy = max([maxy ny]);
 
case {'ai','sa'}
 z = L' \ (dd1 .* x);
 y = z;
 ny = norm(y);
 maxy = max([maxy ny]);
 
otherwise
 y = dd1 .* (L' * x);
 ny = norm(y);
 maxy = max([maxy ny]);
 
end