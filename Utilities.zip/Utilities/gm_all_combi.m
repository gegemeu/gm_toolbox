function P = gm_all_combi(n,k);
%GM_ALL_COMBI all combinations of n elements k by k (ordered)

% Input:
% n = number of elements
% k = integer
%
% Output:
% P = list of combinations

%
% Author G. Meurant
% Oct 2012
% Updated Sept 2015
%

warning('off')

if k > n
 P = [1:n];
 return
end

m = gm_Cnk(n,k);
P = zeros(m,k);

tuple = [1:k];
P(1,:) = tuple;

for j = 2:m
 tuple = gm_next_tuple(tuple,n);
 P(j,:) = tuple;
end

warning('on')

