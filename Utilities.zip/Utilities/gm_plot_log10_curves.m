function [] = gm_plot_log10_curves(Name,plotData,window,sSaveName);
%GM_PLOT_LOG10_CURVES

% adapted from Neuenhofen's function

% read data
string_xlabel = plotData(1).xlabel;
string_ylabel = plotData(1).ylabel;
string_title = Name;

% set figure
% specify size
cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;
myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
% label axes
xlabel( {string_xlabel} ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel( {string_ylabel} ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
title(  {string_title} ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             12,...
 'FontName',             'Times');
hold all;
% make the legend
% make empty default plots for the legend
for i = 1:length(plotData)
 plot([-100,-100],[-100,-100], ...
  'LineStyle',            plotData(i).LineStyle,...
  'LineWidth',            plotData(i).LineWidth,...
  'Color',                plotData(i).Color,...
  'Marker',               plotData(i).Marker,...
  'MarkerSize',           plotData(i).MarkerSize,...
  'MarkerEdgeColor',      plotData(i).MarkerEdgeColor,...
  'MarkerFaceColor',      plotData(i).MarkerFaceColor);
 % prepare legend names
 solverName          = plotData(i).solvernamename;
 solveTime           = max(plotData(i).runtime);
 float_string        = sprintf('%3.2f',solveTime);
 legend_names{i}     = [solverName,', ',float_string,'\,sec'];    
end
% set axis
if nargin < 3
 xL  = 0;
 xR  = 800;
 dx  = 100;
 yL  = -12;
 yR  = 2;
 dy  = 2;
else
 xL  = 0;
 xR  = 800;
 dx  = 100;
 yL  = -12;
 yR  = 2;
 dy  = 2;
 if(isfield(window,'xL'))
  xL = window.xL;
 end
 if(isfield(window,'xR'))
  xR = window.xR;
 end
 if(isfield(window,'dx'))
  dx = window.dx;
 end
 if(isfield(window,'xL'))
  yL = window.yL;
 end
 if(isfield(window,'xL'))
  yR = window.yR;
 end
 if(isfield(window,'xL'))
  dy = window.dy;
 end
end
% set axis numbering
set(gca,...
 'Units',                'normalized',...
 'YTick',                yL:dy:yR,...
 'XTick',                xL:dx:xR ,...
 'Position',             [0.57/width 0.48/height 1-0.65/width 1-0.82/height],...    % relative position left, bottom, right, top
 'FontUnits',            'points',...
 'FontWeight',           'normal',...
 'FontSize',             11,...
 'FontName',             'Times');
% set axis intervals
axis manual
axis([xL xR yL yR]);
box on;
% set legend
legend(legend_names,...
 'FontUnits',                'points',...
 'interpreter',              'latex',...
 'FontSize',                 9,...
 'FontName',                 'Times',...
 'Location',                 'northeastoutside');

% make the plots
for i = 1:length(plotData)
 x = plotData(i).x;
 y = plotData(i).y;
 y = log10(y);
 plot(x,y,...
  'LineStyle',            plotData(i).LineStyle,...
  'LineWidth',            plotData(i).LineWidth,...
  'Color',                plotData(i).Color);
 plot(x(1:10:end),y(1:10:end),...
  'lineStyle',            'none',...
  'Marker',               plotData(i).Marker,...
  'MarkerSize',           plotData(i).MarkerSize,...
  'MarkerEdgeColor',      plotData(i).MarkerEdgeColor,...
  'MarkerFaceColor',      plotData(i).MarkerFaceColor);
end % for i

if nargin > 3
%  print(sSaveName,'-dpdf');
 %         close all;
end

end % function

