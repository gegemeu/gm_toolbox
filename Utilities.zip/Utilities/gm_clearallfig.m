function gm_clearallfig
%GM_CLEARALLFIG clears all current figures

%
% Author G. Meurant
% Feb 2003
%

set(0,'ShowHiddenHandles','on')

delete(get(0,'Children'))
