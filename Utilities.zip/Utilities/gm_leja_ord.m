function z=gm_leja_ord(x,n);
%GM_LEJA_ORD Leja order of the first n components of the vector x

% Input:
% x = vector (may be complex)
% n = number of compononents to be considered
%
% Output:
% z = reordered vector (n components)

%
% Author G. Meurant
% Updated August 2015
%

m = length(x);
n = min(n,m);
z = zeros(size(x));

[v index] = max(abs(x));
z(1) = x(index);
temp = abs(x - z(1));
[v index] = max(temp);
z(2) = x(index);

for k = 2:n-1
  for i = 1:m
    temp(i) = temp(i) * abs(x(i) - z(k));
  end
  [v index] = max(temp);
  z(k+1) = x(index);
end

z = z(1:n);

