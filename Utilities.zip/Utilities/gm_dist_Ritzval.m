function Dist=gm_dist_Ritzval(T,lambda);
%GM_DIST_RITZVAL distance of Ritz values to lambda

%
% Author G. Meurant
% June 2021
%

n = size(T,1);
T = full(T);
Dist = zeros(n,n);

for k = 1:n
 eigTk = sort(eig(T(1:k,1:k)));
 Dist(k,1:k) = abs(eigTk - lambda);
 fprintf('\n ---------------------iteration %d \n',k)
 double(Dist(k,1:k))
end % for k

cm_inch = 0.393701;         % 1cm / 1inch
height = cm_inch * 9;
width = cm_inch * 20;

set(0,'defaultaxesfontsize',12);
set(0,'defaultlinelinewidth',1); 
set(0,'defaultlinemarkersize',3);

% muexvp

myfigure = figure('Units','in', 'Position',[1 1 width height],...
 'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);

for k = 1:n
 plot(log10(Dist(k,1:k)),k*ones(1,k),'b*')
 hold on
end % for k

xlabel('$\log_{10}$ of distances to $\lambda_1$' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');
ylabel('iteration number' ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             11,...
 'FontName',             'Times');

axis([-19 1 0 n+1])
hold off

sSaveName = 'C:\D\Doc TeX\papiers\err_Krylov\CGQ\TGRdist';
% print(sSaveName,'-dpdf');



