function [gam,sig] = gm_IUHQR(lambda,nu);
%GM_IUHQR inverse unitary Hessenberg eigenvalue problem

% Algorithm from G.S. Ammar, W.B. Gragg, and L. Reichel
% as coded by H. Fassbinder

% Input:
% lamba = eigenvalues
% nu = weights, sum of weights = 1
%
% Output:
% gam, sig = Schur parameters

% December 2023

n = length(lambda);
gam = zeros(n,1);
sig = zeros(n,1);

sig0 = nu(1);
gam(1) = -lambda(1);
sig(1) = 0;
for i = 2:n
 sig_old = sig0;
 sig0 = sqrt(sig_old^2 + nu(i)^2);
 beta = sig_old / sig0;
 alpha = -nu(i) / sig0;
 gam(i) = -lambda(i) * gam(i-1);
 for k = 1:i-1
  sig_old = sig(k);
  gam_old = gam(k);
  sig(k) = beta * sqrt(sig_old^2 + abs(alpha + gam(k) * conj(alpha) * lambda(i)^(k-2))^2);
  gam(k) = beta^2 * gam(k) - conj(lambda(i))^(k-2) * alpha^2;
  alpha = beta * lambda(i) * (alpha + gam_old * lambda(i)^(k-2) * conj(alpha)) / sig(k);
  beta = beta * sig_old / sig(k);
 end % for k
end % for i