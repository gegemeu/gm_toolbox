function gm_gfov(A1,A2);
%GM_GFOV plot of the generalized field of values of A1 and A2

% The generalized field of values is the set 
% { (x, A1 x), (x, A2 x) | || x || = 1 } in the complex plane

% Input:
% A1, A2 = two symmetric matrices of the same order

%
% Author G. Meurant
% December 2012
% Updated Sept 2015
%

H = full(A1);
H2 = full(A2);

% plot the origin to see if it is in the gfov
plot(0,0,'r*')

hold on

% box of the eigenvalues

vH = eig(H);
mvH = min(vH);
MvH = max(vH);

vH2 = eig(H2);
mvH2 = min(vH2);
MvH2 = max(vH2);

plot([mvH MvH],[mvH2 mvH2],'g')
plot([mvH MvH],[MvH2 MvH2],'g')
plot([mvH mvH],[mvH2 MvH2],'g')
plot([MvH MvH],[mvH2 MvH2],'g')

% the boundary of the gfov according to Polyak

npt = 100;
t = linspace(0,2*pi,npt);

zH = zeros(1,npt);
zH2 = zeros(1,npt);
for k = 1:npt
 Ht = cos(t(k)) * H + sin(t(k)) * H2;
 [VHt,DHt] = eig(Ht);
 [mHt,I] = min(diag(DHt));
 zt = VHt(:,I(1));
 zH(k) = zt' * H * zt;
 zH2(k) = zt' * H2 * zt;
 
 plot(zH(k),zH2(k),'g*')
 
end % for k

plot(zH,zH2,'g')

mmvH = min(mvH,0);
mmvH2 = min(mvH2,0);

facH = 1.1;
if mvH >= 0
 facH = 0.9;
end

facH2 = 1.1;
if mvH2 >= 0
 facH2 = 0.9;
end

axis([facH*mmvH 1.1*MvH facH2*mmvH2 1.1*MvH2])

hold off






