function [ps_pts,eigA]=gm_pseudo_points(A,npts,level);
%GM_PSEUDO_POINTS extraction of points from the pseudo spectrum of A

% Input:
% A = matrix
% npts = number of points on one side of the grid
% level = level of extraction for the log of the resolvent norms
%
% Output:
% ps_pts = set of points in the complex plane
% eigA = eigenvalues of A

%
% Author G. Meurant
% Dec 2015
%

% pseudo spectrum
[x,y,sigmin,eigA] = gm_psa(A,npts);

% contour at level
C = contourc(x,y,log10(sigmin+1e-20),[level, level]);

% extract the points from the matrix C
c2 = size(C,2);
ps_pts = zeros(c2,2);
mc = c2;
mp = 1;

while mc > 0
 np = C(2,1);
 ps_pts(mp:mp+np-2,:) = C(:,2:np)';
 
 mc = mc - np - 1;
 C = C(:,np+2:end);
 mp = mp+np-1;
end % while

ps_pts = ps_pts(1:mp-1,:);


 