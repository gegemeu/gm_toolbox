function TN=gm_thumbn_avg(A,ktn);
%GM_THUMBN_AVG constructs a matrix at most ktn x ktn for visualization of large matrices by taking the average in a block
% of large matrices by taking the average in a block

%
% Author G. Meurant
% May 2015
%

kmax = 100;
if nargin == 1
 ktn = kmax;
end

[n,m] = size(A);
if n <= ktn && m <= ktn
 TN = A;
 return
end

big = realmax;

mn = max(m,n);
% size of the blocks
s = ceil(mn / ktn);
% number of divisions in rows and columns
ni = fix(n / s);
if n == ni * s
 ri = 0;
else
 ri = 1;
end
nj = fix(m / s);
if m == nj * s
 rj = 0;
else
 rj = 1;
end

TN = sparse(ni + ri,nj + rj);

for i = 1:ni
 ist = (i - 1) * s + 1;
 iend = i * s;
 for j = 1:nj
  jst = (j - 1) * s + 1;
  jend = j * s;
  B = A(ist:iend,jst:jend);
  [nb,mb] = size(B);
  sB = sum(sum(B)) / (nb * mb);
  TN(i,j) = sB;
  if isnan(TN(i,j))
   TN(i,j) = big;
  end
 end % for j
 if rj == 1
  % there is a last block for j
  jst = nj * s + 1;
  jend = m;
  B = A(ist:iend,jst:jend);
  [nb,mb] = size(B);
  sB = sum(sum(B)) / (nb * mb);
  TN(i,nj+1) = sB;
  if isnan(TN(i,nj+1))
   TN(i,nj+1) = big;
  end
 end % for rj
end % for i

if ri == 1
 % there are last blocks for i
 ist = ni * s + 1;
 iend = n;
  for j = 1:nj
  jst = (j - 1) * s + 1;
  jend = j * s;
  B = A(ist:iend,jst:jend);
  [nb,mb] = size(B);
  sB = sum(sum(B)) / (nb * mb);
  TN(ni+1,j) = sB;
  if isnan(TN(ni+1,j))
   TN(ni+1,j) = big;
  end
 end % for j
 if rj == 1
  % there is a last block for j
  jst = nj * s + 1;
  jend = m;
  B = A(ist:iend,jst:jend);
  [nb,mb] = size(B);
  sB = sum(sum(B)) / (nb * mb);
  TN(ni+1,nj+1) = sB;
  if isnan(TN(ni+1,nj+1))
   TN(ni+1,nj+1) = big;
  end
 end % for rj
end % for ri
  
 

