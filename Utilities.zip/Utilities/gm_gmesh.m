function xy = gm_gmesh(m);
%GM_GMESH coordinates of the nodes for an m x m mesh on the unit square

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

[x,y] = gm_meshsq(m);
xy = [x; y]';
