function hh=gm_myezplot_simpler(varargin);
%GM_MYEZPLOT_SIMPLER   Easy to use function plotter

%  my own version of ezplot to be able to get the values of x and y
% and to change the number of points npts as well as the color

% removal of useless checks
% accepts only functions of x and y



% Parse possible Axes input
[cax,args,nargs] = axescheck(varargin{:});

cax = gca;

f = args{1};
args = args(2:end);

[f,fx0,varx] = gm_myezfcnchk(f);

labels = {fx0};
if ~iscell(f), f = {f}; end

vars = {'x' 'y'};
nvars = 2;
ninputs = length(args);

argu = args;
color = 'b';
if ninputs > 0
 if length(argu{1}) == 4
  V = argu;
  clear args;
  args{1} = [V{1}(1),V{1}(2)];
  args{2} = [V{1}(3),V{1}(4)];
  if ninputs > 1
   color = argu{2};
  end
 else
  color = argu{1};
 end
end

hp = ezimplicit(cax,f{1},vars,labels,color,args{:});

if nargout > 0
 hh = hp;
end

end

%------------------------

function [hp,newcax] = ezimplicit(cax,f,vars,labels,color,varargin)
% EZIMPLICIT Plot of an implicit function in 2-D

%    EZIMPLICIT(cax,f,vars) plots in cax the string expression f
%    that defines an implicit function f(x,y) = 0 for x0 < x < x1
%    and y0 < y < y1, whose default values are x0 = -2*pi = y0
%    and x1 = 2*pi = y1.  The arguments of f are listed in vars and
%    a non-vector version of the function expression is in labels.
%

eqnHasEqualSign = false;
if (isa(f,'inline') && ~isempty(findstr(char(f), '=')))
 symvars = argnames(f);
 f = char(f);
 f = [strrep(f,'=','-(') ')'];
 f = inline(f, symvars{:});
 eqnHasEqualSign = true;
end

% Choose the number of points in the plot

% npts = 100;
npts = 150;

fig = [];
switch length(vars)
 case 0
  x = 'x'; y = 'y';
 case 1
  x = vars{1}; y = 'y';
 case 2
  x = vars{1}; y = vars{2};
end

% Define the computational space
switch (nargin-4)
 case 1
  X = linspace(-2*pi,2*pi,npts);
  Y = X;
 case 2
  if length(varargin{1}) == 1
   fig = varargin{1};
   X = linspace(-2*pi,2*pi,npts); Y = X;
  else
   X = linspace(varargin{1}(1),varargin{1}(2),npts);
   Y = X;
  end
 case 3
  if length(varargin{1}) == 1
   fig = varargin{1};
   X = linspace(varargin{2}(1),varargin{2}(2),npts);
   Y = X;
  elseif length(varargin{2}) == 1 && length(varargin{1}) == 2
   fig = varargin{2};
   X = linspace(varargin{1}(1),varargin{1}(2),npts);
   Y = X;
  elseif length(varargin{2}) == 1 && length(varargin{1}) == 4
   fig = varargin{2};
   X = linspace(varargin{1}(1),varargin{1}(2),npts);
   Y = linspace(varargin{1}(3),varargin{1}(4),npts);
  else
   X = linspace(varargin{1}(1),varargin{1}(2),npts);
   Y = linspace(varargin{2}(1),varargin{2}(2),npts);
  end
end

[X,Y] = meshgrid(X,Y);

u = gm_myezplotfeval(f,X,Y);

% Determine u scale so that "most" of the u values
% are in range, but singularities are off scale.

u = real(u);
uu = sort(u(isfinite(u)));
N = length(uu);
if N > 16
 del = uu(fix(15*N/16)) - uu(fix(N/16));
 umin = max(uu(1)-del/16,uu(fix(N/16))-del);
 umax = min(uu(N)+del/16,uu(fix(15*N/16))+del);
elseif N > 0
 umin = uu(1);
 umax = uu(N);
else
 umin = 0;
 umax = 0;
end
if umin == umax, umin = umin-1; umax = umax+1; end

% Eliminate vertical lines at discontinuities.

ud = (0.5)*(umax - umin); umean = (umax + umin)/2;
[nr,nc] = size(u);
% First, search along the rows . . .
for j = 1:nr
 k = 2:nc;
 kc = find( abs(u(j,k) - u(j,k-1)) > ud );
 ki = find( max( abs(u(j,k(kc)) - umean), abs(u(j,k(kc)-1) - umean) ) );
 if any(ki), u(j,k(kc(ki))) = NaN; end
end
% . . . then search along the columns.
for j = 1:nc
 k = 2:nr;
 kr = find( abs(u(k,j) - u(k-1,j)) > ud );
 kj = find( max( abs(u(k(kr),j) - umean), abs(u(k(kr)-1,j) - umean) ) );
 if any(kj), u(k(kr(kj)),j) = NaN; end
end

% First check if cax was specified (strongest specification for plot axes)
if isempty(cax)
 % Now allow the fig input to be honored
 cax = determineAxes(fig);
end

% [cmatrix,hp] = contour('v6',cax,X(1,:),Y(:,1),u,[0,0],color);
[cmatrix,hp] = contour(cax,X(1,:),Y(:,1),u,[0,0],color);

newcax = cax;

end

%----------------------------------

function cax = determineAxes(fig)
% Helper function that takes the specified figure handle.  If the handle is
% not empty, find its current axes.  If it is empty, use the current axes.
if ~isempty(fig)
 % In case a figure handle was specified, but the figure does not exist,
 % create one.
 figure(fig);
 cax = gca(fig);
else
 % Neither cax nor fig was specified, so use gca
 cax = gca;
end

end

function str=id(str)
str = ['MATLAB:ezplot:' str];

end
