function C=gm_companionmat(eigA);
%GM_COMPANIONMAT companion matrix of the eigenvalues eigA
%

%
% Author G. Meurant
% April 2013
%

n = length(eigA);

p = poly(eigA);

C = zeros(n,n);

C(:,n) = -p(n+1:-1:2);
C(2:n,1:n-1) = eye(n-1);

