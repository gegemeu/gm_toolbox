function xy=gm_grand(m);
%GM_GRAND generates the coordinates of the nodes for a random mesh
% on the unit square

%
% Author G. Meurant
% 2000
%

[x,y] = gm_randmesh(m);

xy = [x;y]';

