function B = gm_mgfilt(A,alp);
%GM_MGFILT filters the matrix A with a criteria different from gm_filmatr

%
% Author G. Meurant
%

maxs = max(abs(A'))';
n = size(A,1);
B = sparse(n,n);

for i = 1:n
 ind = find(abs(A(i,:)) >= alp * maxs(i));
 B(i,ind) = A(i,ind);
end



