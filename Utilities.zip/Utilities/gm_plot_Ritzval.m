function [eigH,Ritz]=gm_plot_Ritzval(H,it);
%GM_PLOT_RITZVAL plot of the Ritz values every it iterations

% plots the eigenvalues of H (red circles) and Ritz values (blue pluses)

% Input:
% H = upper Hessenberg from Arnoldi
% it = stepsize for the iterations
%
% Ouput:
% eigH = eigenvalues of H
% Ritz = upper triangular matrix with the Ritz values in columns

%
% Author G. Meurant
% July 2015
%

if nargin == 1
 it = 1;
end

if issparse(H)
 H = full(H);
end

eigH = eig(H);

n = size(H,1);

Ritz =zeros(n,n);

kk = 0;
for k = 1:it:n
 kk = kk + 1;
 
 plot(real(eigH),imag(eigH),'ro')
 title(['iteration ' num2str(k)])
 hold on
 
 muu = eig(H(1:k,1:k));
 Ritz(1:k,kk) = muu;
 
 plot(real(muu),imag(muu),'b+')
 
 hold off
 pause
end

Ritz = Ritz(1:n,1:kk);

plot(real(eigH),imag(eigH),'ro')
title(['iteration ' num2str(n)])
hold on

muu = eig(H(1:n,1:n));

plot(real(muu),imag(muu),'b+')

hold off
pause



