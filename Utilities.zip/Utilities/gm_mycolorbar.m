function handle=gm_mycolorbar
%GM_MYCOLORBAR displays a vertical color bar (color scale)

%
% modified by G. Meurant
% Jan 2002
% updated April 2015
%

changeNextPlot = 1;

loc = 'vert';

% Determine color limits by context.  If any axes child is an image
% use scale based on size of colormap, otherwise use current CAXIS.

ch = get(gcda,'children');
hasimage = 0; t = [];
cdatamapping = 'direct';

for i=1:length(ch),
 typ = get(ch(i),'type');
 if strcmp(typ,'image'),
  hasimage = 1;
  cdatamapping = get(ch(i), 'CDataMapping');
 elseif strcmp(typ,'surface') & ...
   strcmp(get(ch(i),'FaceColor'),'texturemap') % Texturemapped surf
  hasimage = 2;
  cdatamapping = get(ch(i), 'CDataMapping');
 elseif strcmp(typ,'patch') | strcmp(typ,'surface')
  cdatamapping = get(ch(i), 'CDataMapping');
 end
end

h = gcda;

origNextPlot = get(gcf,'NextPlot');
if strcmp(origNextPlot,'replacechildren') | strcmp(origNextPlot,'replace'),
 set(gcf,'NextPlot','add')
end

ax = [];

if loc(1)=='v', % Append vertical scale to right of current plot
 
 if isempty(ax),
  units = get(h,'units'); set(h,'units','normalized')
  pos = get(h,'Position');
  [az,el] = view;
  stripe = 0.075; edge = 0.02;
  if all([az,el]==[0 90]), space = 0.05; else space = .1; end
  set(h,'Position',[pos(1) pos(2) pos(3)*(1-stripe-edge-space) pos(4)])
  rect = [pos(1)+(1-stripe-edge)*pos(3) pos(2) stripe*pos(3) pos(4)];
  ud.origPos = pos;
  
  % Create axes for stripe and
  % create DeleteProxy object (an invisible text object in
  % the target axes) so that the colorbar will be deleted
  % properly.
  ud.DeleteProxy = text('parent',h,'visible','off',...
   'tag','ColorbarDeleteProxy',...
   'handlevisibility','off',...
   'deletefcn','eval(''delete(get(gcbo,''''userdata''''))'','''')');
  ax = axes('Position', rect);
  setappdata(ax,'NonDataObject',[]); % For DATACHILDREN.M
  set(ud.DeleteProxy,'userdata',ax)
  set(h,'units',units)
 else
  axes(ax);
  ud = get(ax,'userdata');
 end
 
 % Create color stripe
 n = size(colormap,1);
 image([0 1],t,(1:n)','Tag','TMW_COLORBAR','deletefcn','colorbar(''delete'')'); set(ax,'Ydir','normal')
 set(ax,'YAxisLocation','right')
 set(ax,'xtick',[])
 
 % set up axes deletefcn
 set(ax,'tag','Colorbar','deletefcn','colorbar(''delete'')')
 
elseif loc(1)=='h', % Append horizontal scale to top of current plot
 
 if isempty(ax),
  units = get(h,'units'); set(h,'units','normalized')
  pos = get(h,'Position');
  stripe = 0.075; space = 0.1;
  set(h,'Position',...
   [pos(1) pos(2)+(stripe+space)*pos(4) pos(3) (1-stripe-space)*pos(4)])
  rect = [pos(1) pos(2) pos(3) stripe*pos(4)];
  ud.origPos = pos;
  
  % Create axes for stripe and
  % create DeleteProxy object (an invisible text object in
  % the target axes) so that the colorbar will be deleted
  % properly.
  ud.DeleteProxy = text('parent',h,'visible','off',...
   'tag','ColorbarDeleteProxy',...
   'handlevisibility','off',...
   'deletefcn','eval(''delete(get(gcbo,''''userdata''''))'','''')');
  ax = axes('Position', rect);
  setappdata(ax,'NonDataObject',[]); % For DATACHILDREN.M
  set(ud.DeleteProxy,'userdata',ax)
  set(h,'units',units)
 else
  axes(ax);
  ud = get(ax,'userdata');
 end
 
 % Create color stripe
 n = size(colormap,1);
 image(t,[0 1],(1:n),'Tag','TMW_COLORBAR','deletefcn','colorbar(''delete'')'); set(ax,'Ydir','normal')
 set(ax,'ytick',[])
 
 % set up axes deletefcn
 set(ax,'tag','Colorbar','deletefcn','colorbar(''delete'')')
 
else
 error('COLORBAR expects a handle, ''vert'', or ''horiz'' as input.')
end

if ~isfield(ud,'DeleteProxy'), ud.DeleteProxy = []; end
if ~isfield(ud,'origPos'), ud.origPos = []; end
ud.PlotHandle = h;
set(ax,'userdata',ud)
axes(h)
set(gcf,'NextPlot',origNextPlot)
if ~isempty(legend)
 legend % Update legend
end
if nargout>0, handle = ax; end

%--------------------------------
function h = gcda
%GCDA Get current data axes

h = datachildren(gcf);
if isempty(h) | any(h == gca)
 h = gca;
else
 h = h(1);
end

