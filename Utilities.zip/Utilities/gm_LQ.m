function [L,Q]=gm_LQ(A);
%GM_LQ LQ factorization of A

% this can be done also by computing the QR factorization of A'

[QQ,LL] = ql(flipud(A).');

L = fliplr(flipud(LL.'));
Q = flipud(QQ.');
end

function [Q,L]= ql(A);
%QL QL factorization of A

[QQ,R] = qr(fliplr(A));

L = fliplr(flipud(R));
Q = fliplr(QQ);

end