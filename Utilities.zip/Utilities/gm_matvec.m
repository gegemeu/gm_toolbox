function [c,multflops,gflops,time]=gm_matvec(A,x);
%GM_MATVEC matrix-vector multiplication timing

% Input:
% A = square matrix
% x = vector
%
% Output:
% c = A x
% multflops = number of floating point operations
% gflops = computation speed (gigaflops)
% time = computing time

%
% Author G. Meurant
% Jan 2012
% Updated July 2016
%

n = size(A,1);
nz = nnz(A);

% number of operations of one multiply (dense matrices)
nop = 2 * nz - n;

% repeat kmax times
kmax = 500;
if n < 100
 % small matrices
 kmax = 1000;
end
% large matrices
if n > 1000
 kmax = 200;
end

% tstart = cputime;
tic;

for k = 1:kmax
 c = A * x;
end

% time = cputime - tstart;
time = toc;

mult = kmax * nop / time;

% gigaflops
gflops = mult * 1e-9;

time = time / kmax;
multflops = nop;

