function [flag,x] = gm_check_ineq(H,b);
%GM_CHECK_INEQ solution of linear inequalities

% Input:
% H = an m x n-matrix H
% b = an m-column vector
%
% Output:
% flag = 1 if there exists an x such that H x <= b
% x = solution of the inequalities

% derived from initvert (Matlab file exchange)


% December 2012
% Updated Sept 2015

[m,n] = size(H);
x0 = [];
I = [];
initv = [];
flag = 0;
x = [];

if rank(H) < n
 % polyhedron H x <= b has no vertex
 flag = 0;
 x = [];
 return
end

cnt = 1;
cl = 10;

while 1
 if cnt <= cl
  p = randperm(m);
  p = p(1:n);
  z = zeros(1,m);
  z(p) = ones(1,n);
  cnt =cnt + 1;
 end
 
 if cnt == cl+1
  z = [ones(1,n), zeros(1,m-n)];
  cnt = cl +2;
 end
 
 zz = find(z);
 T = H(zz,:);
 
 if rank(T)==n
  x = T \ (b(zz));
  u = b - H * x;
  f =(u >= -10 * eps);
  if all(f)
   x0 = x;
   I = z;
   initv = [x0, (find(I))'];
   flag = 1;
   x = x0;
   return
  end
 end
 if cnt == cl+2
  if z(m-n+1:m) == 1
   % polyhedron H x <= b is empty
   flag = 0;
   x = [];
   return
  end
  z = nextset(z);
 end
end

end


function nextx=nextset(x)
%NEXTSET

% input: a {0,1}-n-tuple x i.e. characteristic vector of
%  subset of 1...n
%
% output: lexicographically next n-tuple with same number
%  of ones as x; x itself if x is lexicographically
%  last element

lengthx = length(x);
last0 = max(find(x == 0));
xinit = x(1:last0-1);
xfin1s = x(last0+1:lengthx);
j= max(find(xinit == 1));
if isempty(j)
 nextx = x;
 return
end
nextx = x;
nextx([j,j+1]) = [0 1];
nextx = [nextx(1:j+1),xfin1s];
nextx = [nextx, zeros(1,lengthx-length(nextx))];
end

