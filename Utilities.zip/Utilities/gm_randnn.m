function V = gm_randnn(n,m);
%GM_RANDNN random matrix with unit norm vectors

% Input:
% [n,m] = dimension of the matrix
%
% Output:
% V = random matrix with columns of unit norm

%
% Author G. Meurant
% March 2013
% Updated September 2015
%

if nargin == 1
 m = n;
end

V = randn(n,m);

for k = 1:m
 nv = norm(V(:,k));
 V(:,k) = V(:,k) / nv;
end

