function X=gm_qrandn(n,m);
%GM_QRANDN generates a random orthogonal matrix X

% (n,m) size of the matrix X

%
% Author G. Meurant
% November 2009
%

if nargin == 1
 m = n;
end

XX = randn(n,m);

[X,rr] = qr(XX,0);

