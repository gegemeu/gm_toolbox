function [Y,R12,R22]=gm_bgssro(Q,X,rpltol);
%GM_BGSSRO Block Gram-Schmidt orthogonalization (from G.W. Stewart)

% Input:
% Q = orthonormal matrix
% X = matrix whose columns have to be orthogonalized against Q
% rpltol = parameter, has a default value of 1.  Increasing it,
%   say to 100, may improve the performance of bgssro, but will degrade
%   the accuracy of the relation
%
% Output:
% Y = orthonormal matrix in the orthogonal complement of Q
% R12 = matrix
% R22 = upper triangular matrix such that
%       X = Q * R12 + Y * R22


%  Initialization

reorth = false;
if nargin < 3
 rpltol = 1;
else
 rpltol = max(1,rpltol);
end % if nargin

[n,mx] = size(X);
[n,mq] = size(Q);
nu = zeros(1,mx);
Y = zeros(n,mx);

for k = 1:mx
 nu(k) = norm(X(:,k));
end

%  Beginning of the first orthogonalization step
%  Project X onto the orthogonal complement of Q

R12 = Q' * X;
Y = X - Q * R12;

R22 = zeros(mx);

%  Orthogonalize the columns of Y
for k = 1:mx
 nq = k - 1;
 x = Y(:,k);
 nuu = nu(k);
 r = zeros(nq, 1);
 nux = norm(x);
 if nargout >= 4
  northog = 0;
 end % if
 %  If Y(:,1:k-1) has no columns, return normalized x if x~=0, otherwise return
 %  a normalized random vector
 if nq == 0
  if nux == 0
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   rho = 0;
  else % if nux
   y = x / nux;
   rho = nux;
  end % if nux
 else % if nq
  %  If norm(x)==0, set it to a nonzero vector and proceed, noting
  %  the fact in the flag zeronorm.
  if nux ~= 0
   zeronorm = false;
   y = x / nux;
   nuu = nuu / nux;
  else
   zeronorm = true;
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   nuu = 1;
  end % if nux
  %  Main orthogonalization loop
  nu1 = nuu;
  while true
   if nargout == 4
    northog = northog + 1;
   end % if
   s = Y(:,1:k-1)' * y;
   r = r + s;
   y = y - Y(:,1:k-1) * s;
   nu2 = norm(y);
   %  Return if y is orthogonal
   if nu2 > (0.5 * nu1)
    break
   end
   % Continue orthogonalizing if nu2 is not too small
   if nu2 > (rpltol * nu * eps)
    nu1 = nu2;
   else
    % Replace y by a random vector
    nuu = nuu * eps;
    nu1 = nuu;
    y = rand(n,1) - 0.5;
    y = nuu * y / norm(y);
   end % if nu2
  end % while
  % Calculate rho and normalize y
  if ~zeronorm
   rho = norm(y);
   y = y / rho;
   rho = rho * nux;
   r = r * nux;
  else
   y = y / norm(y);
   r = zeros(nq, 1);
   rho = 0;
  end % if
 end % if nq 
 % end of orthogonalization
 Y(:,k) = y;
 R22(1:k-1,k) = r;
 R22(k,k) = rho;
 if rho <= (0.5 * nu(k))
  reorth = true;
 end % if
end % for k

%  Return if Q has zero columns
if mq == 0 || ~reorth
 return
end % if

% Beginning of the reorthogonalization
% Project Y onto the orthogonal complement of Q
S12 = Q' * Y;
Y = Y - Q * S12;

%  Orthogonalize the columns of Y
S22 = zeros(mx);
for k = 1:mx
%  [yk, s, sig, northog] = gssro(Y(:,1:k-1), Y(:,k), 1, rpltol);
 nq = k - 1;
 x = Y(:,k);
 nuu = 1;
 s = zeros(nq, 1);
 nux = norm(x);
 if nargout >= 4
  northog = 0;
 end % if
 %  If Y(:,1:k-1) has no columns, return normalized x if x~=0, otherwise return
 %  a normalized random vector
 if nq == 0
  if nux == 0
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   sig = 0;
  else % if nux
   y = x / nux;
   sig = nux;
  end % if nux
 else % if nq
  %  If norm(x)==0, set it to a nonzero vector and proceed, noting
  %  the fact in the flag zeronorm.
  if nux ~= 0
   zeronorm = false;
   y = x / nux;
   nuu = nuu / nux;
  else
   zeronorm = true;
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   nuu = 1;
  end % if nux
  %  Main orthogonalization loop
  nu1 = nuu;
  while true
   if nargout == 4
    northog = northog + 1;
   end % if
   r = Y(:,1:k-1)' * y;
   s = r + s;
   y = y - Y(:,1:k-1) * r;
   nu2 = norm(y);
   %  Return if y is orthogonal
   if nu2 > (0.5 * nu1)
    break
   end
   % Continue orthogonalizing if nu2 is not too small
   if nu2 > (rpltol * nu * eps)
    nu1 = nu2;
   else
    % Replace y by a random vector
    nuu = nuu * eps;
    nu1 = nuu;
    y = rand(n,1) - 0.5;
    y = nuu * y / norm(y);
   end % if nu2
  end % while
  % Calculate sig and normalize y
  if ~zeronorm
   sig = norm(y);
   y = y / sig;
   sig = sig * nux;
   s = s * nux;
  else
   y = y / norm(y);
   s = zeros(nq, 1);
   sig = 0;
  end % if
 end % if nq 
 % end of orthogonalization
 
 if sig < 0.5
  %  The result, yk, is not satisfactorily orthogonal
  %  Perform an unblocked orthogonalization against Q and the previous
  %   columns of Y
  
%   [y, s, sig, northog] = gssro([Q, Y(:,1:k-1)], Y(:,k), rpltol); % error?
fprintf('\n gssro \n')
 nq = mq + k - 1;
 x = Y(:,k);
 nuu = 1;
 s = zeros(nq, 1);
 nux = norm(x);
 if nargout >= 4
  northog = 0;
 end % if
 %  If Q[ Y(:,1:k-1)] has no columns, return normalized x if x~=0, otherwise return
 %  a normalized random vector
 if nq == 0
  if nux == 0
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   sig = 0;
  else % if nux
   y = x / nux;
   sig = nux;
  end % if nux
 else % if nq
  %  If norm(x)==0, set it to a nonzero vector and proceed, noting
  %  the fact in the flag zeronorm.
  if nux ~= 0
   zeronorm = false;
   y = x / nux;
   nuu = nuu / nux;
  else
   zeronorm = true;
   y = rand(n,1) - 0.5;
   y = y / norm(y);
   nuu = 1;
  end % if nux
  %  Main orthogonalization loop
  nu1 = nuu;
  while true
   if nargout == 4
    northog = northog + 1;
   end % if
   r = [Q, Y(:,1:k-1)]' * y;
   s = r + s;
   y = y - [Q, Y(:,1:k-1)] * r;
   nu2 = norm(y);
   %  Return if y is orthogonal
   if nu2 > (0.5 * nu1)
    break
   end
   % Continue orthogonalizing if nu2 is not too small
   if nu2 > (rpltol * nu * eps)
    nu1 = nu2;
   else
    % Replace y by a random vector
    nuu = nuu * eps;
    nu1 = nuu;
    y = rand(n,1) - 0.5;
    y = nuu * y / norm(y);
   end % if nu2
  end % while
  % Calculate sig and normalize y
  if ~zeronorm
   sig = norm(y);
   y = y / sig;
   sig = sig * nux;
   s = s * nux;
  else
   y = y / norm(y);
   s = zeros(nq, 1);
   sig = 0;
  end % if
 end % if nq 
 % end of orthogonalization
  
  S12(:,k) = S12(:,k) + s(1:mq);
  s = s(mq+1:mq+k-1);
 end % if sig
 Y(:,k) = y;
 S22(1:k-1,k) = s;
 S22(k,k) = sig;
end % for k

R12 = R12 + S12 * R22;
R22 = S22 * R22;


