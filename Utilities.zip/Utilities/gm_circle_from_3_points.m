function [c,r] = gm_circle_from_3_points(z1,z2,z3);
%GM_CIRCLE_FROM_3_POINTS center and radius of a circle from 3 points

% z1, z2, z3 are complex numbers, z_i = x_i + i y_i

%
% Author G. Meurant
% February 2024
%

if z1 == z2 || z2 == z3 || z3 == z1
 error('gm_circle_from_3_points: Duplicate points')
end % if

w = (z3 - z1) / (z2 - z1);

if abs(imag(w)) <= 0
 error('gm_circle_from_3_points: Points are collinear')
end % if

c = (z2 - z1) * (w - abs(w)^2) / (2 * 1i * imag(w)) + z1;
r = abs(z1 - c);

