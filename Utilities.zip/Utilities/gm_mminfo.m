function  [rows,cols,entries,rep,field,symm]=gm_mminfo(filename,iprint);
%GM_MMINFO Informations about a Matrix Market file

%
%  function  [rows, cols, entries, rep, field, symmetry] = mminfo(filename)
%
%      Reads the contents of the Matrix Market file 'filename'
%      and extracts size and storage information.
%
%      In the case of coordinate matrices, entries refers to the
%      number of coordinate entries stored in the file.  The number
%      of non-zero entries in the final matrix cannot be determined
%      until the data is read (and symmetrized, if necessary).
%
%      In the case of array matrices, entries is the product
%      rows*cols, regardless of whether symmetry was used to
%      store the matrix efficiently.
%

if nargin < 2
 iprint = 0;
end

[A,rows,cols,entries,rep,field,symm]=gm_mmread(filename,0);

if iprint == 1
 fprintf('\n The matrix in file %s is %s and %s \n\n',filename,field,symm)
 fprintf(' Number of rows = %5d, number of columns = %5d, number of non zeros = %6d, sparsity = %g \n\n',rows,cols,entries,entries/(rows*cols))
 if rows < 1000
  spy(A)
 end
end

clear A



