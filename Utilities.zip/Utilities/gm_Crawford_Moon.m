function [s,info]=gm_Crawford_Moon(A,B);
%GM_CRAWFORD_MOON Crawford-Moon algorithm for finding s = [s_1 s_2]
% such that s_1 A + s_2 B is definite

% C.R. Crawford & Yiu Sang Moon
% Finding a positive definite linear combination of two Hermitian matrices
% Linear Algebra and its Applications, v 51, (1983), pp. 37-48

% Input:
% A, B = pair of symmetric matrices
%
% Output:
% s = solution
% info = 

%
% Author G. Meurant
% Jan 2011
% Updated Sept 2015
%

nfac = 0;
qr = 1;
s(1) = 0;
s(2) = 1;
quit = 0;
pd = 0;
uabort = 1;
def = 0;
ndef = -1;
fail = 2;
limit = 50;
niter = 0;
flag = 0;

while quit == 0

 prevqr = qr;

 %  is the combination pos. def.?

 [flag,s,niter] = gm_chlsky(flag,A,B,s(1),s(2),niter,limit);
 
 nfac = nfac + 1;
 norme = max(abs(s(1)),abs(s(2)));
 if norme > 0
  norme = norme * sqrt((s(1)/norme)^2 + (s(2)/norme)^2);
  s(1) = s(1) / norme;
  s(2) = s(2) / norme;
 end

 if flag == pd
  info = def;
  quit = 1;

 elseif flag == uabort
  info = uabort;
  s = [0 0];
  quit = 1;

 elseif norme <= 1e-12
  info = ndef;
  s = [0 0];
  quit = 1;

 elseif nfac == 1

  % after the first try, set q and r

  q(1) = s(1);
  q(2) = s(2);
  r(1) = q(1);
  r(2) = q(2);

 elseif nfac == 2

  % after second try keep q and set r = s

  r(1) = s(1);
  r(2) = s(2);

 else

  %  after third or more, compare q and r to s
  %  express s as a linear comb. of q and r;
  %  s = positive*(cq*q + cr*r)

  sr = s(1) * r(1) + s(2) * r(2);
  sq = s(1) * q(1) + s(2) * q(2);
  qr = q(1) * r(1) + q(2) * r(2);
  cq = sq - sr * qr;
  cr = sr - sq * qr;

  % of the 'quadrants' in the plane formed by q, -q,
  %  r and -r, where is s?

  if cq <= 0 && cr <= 0

   % if -q & -r, the pair is indefinite

   info = ndef;
   s = [0 0];
   quit = 1;

  elseif cr <= 0

   % if +q & -r, s replaces q

   q(1) = s(1);
   q(2) = s(2);

  elseif cq <= 0

   % if -q & +r, s replaces r

   r(1) = s(1);
   r(2) = s(2);
  end

 end

 if ~quit && (nfac > 1)

  % set s = midpoint, get the norm,
  % check for zero norm, and normalize

  s(1) = q(1) + r(1);
  s(2) = q(2) + r(2);
  norme = max(abs(s(1)),abs(s(2)));
  if norme > 0
   norme = norme * sqrt((s(1)/norme)^2+ (s(2)/norme)^2);
   s(1) = s(1) / norme;
   s(2) = s(2) / norme;

  else
   info = ndef;
   s = [0 0];
   quit = 1;
  end

 end

 % check for no-convergence.

 if ~quit && (nfac > 2) && (prevqr <= qr)

  % qr is no longer decreasing to -1

  info = fail;
%   s(1) = 1 + qr;
  s = [0 0];
  quit = 1;
 end

 %    end of loop

end % quit


