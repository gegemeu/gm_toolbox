function [Vu,d] = gm_V_unit_norm(V);
%GM_V_UNIT_NORM normalizes the columns of V

%
% Author G. Meurant
% March 2018
%

[n,m] = size(V);
Vu = zeros(n,m);
d = zeros(m,1);

for k = 1:m
 d(k) = norm(V(:,k));
 Vu(:,k) = V(:,k) / d(k);
end % for k

