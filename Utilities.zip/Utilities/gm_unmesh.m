function l = gm_unmesh(ld);
%GM_UNMESH converts a two dimensional array into a one dimensional array

% Matlab function reshape does this

%
% Author G. Meurant
%

[m,n] = size(ld);

for i = 1:n
 l((i-1)*n+1:(i-1)*n+m) = ld(i,:);
end


