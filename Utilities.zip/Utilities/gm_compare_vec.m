function [diff,ang] = gm_compare_vec(V,X);
%GM_COMPARE_VEC norms of the differences of the columns of V and X

% Input:
% V = set of vectors
% X = set of vectors

% Ouput:
% diff = norms of the parwise differences
% ang = angle of vectors

%
% Author G. Meurant
% April 2019
%

[nV,mV] = size(V);
[nX,mX] = size(X);
if nV ~= nX
 error('The first dimensions of V and X must be the same')
end % if

diff = zeros(mV,mX);
ang = zeros(mV,mX);

for i = 1:mV
 for j = 1:mX
  v = V(:,i) / norm(V(:,i));
  x = X(:,j) / norm(X(:,j));
  diff(i,j) = norm(v - x);
  v = v / norm(v); % already done?
  x = x / norm(x);
  ang(i,j) = acosd(v' * x);
 end % for j
end % for i

