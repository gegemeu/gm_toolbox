function rV = gm_rankV(V);
%GM_RANKV computes the rank as a function of the number of columns in V

%
% Author G. Meurant
% December 2005
%

sV = size(V,2);
rV = zeros(sV,1);

for k = 1:sV
 rV(k) = rank(V(:,1:k));
end

figure
plot(rV)

