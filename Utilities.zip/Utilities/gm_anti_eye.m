function J = gm_anti_eye(n);
%GM_ANTI_EYE anti-diagonal matrix

% zero except ones on the main anti-diagonal

%
% Author G. Meurant
% February 2024
%

p = [n:-1:1];
I = eye(n,n);
J = I(p,:);

