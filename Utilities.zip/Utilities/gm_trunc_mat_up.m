function B = gm_trunc_mat_up(A,alp);
%GM_TRUNC_MAT_UP truncates the matrix A 

% All the entries larger than alp are set to alp

%
% Author G. Meurant
% January 2012
% Updated September 2015
%

n = size(A,1);

B = A;

for i = 1:n
 ind = find(A(i,:) > alp);
 B(i,ind) = alp;
end

