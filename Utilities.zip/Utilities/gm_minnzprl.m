function l = gm_minnzprl(A);
%GM_MINNZPRL minimum number of non zeros per row of the lower triangular part of A

%
% Author G. Meurant
% October 2001
%

AA = spones(tril(A));
l =full(min(sum(AA,2)));
