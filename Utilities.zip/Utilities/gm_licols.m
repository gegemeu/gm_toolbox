function [Xind,indep,Xdep,dep] = gm_licols(X,tol);
%GM_LICOLS extracts a linearly independent set of columns of a given matrix X

%
% input:
%
%  X = The given input matrix
%  tol = A rank estimation tolerance. Default=1e-10
%
% output:
%
% Xind = extracted columns of X
% indep = indices (into X) of the extracted columns
% Xdep = dependent columns
% dep = indices of dependent columns

if ~nnz(X) % X has no non-zeros and hence no independent columns
 Xind = []; 
 indep = [];
 Xdep = X; 
 dep = [1:n];
 return
end

if nargin < 2
 tol = 1e-10; 
end

[~, R, E] = qr(X,0);
if ~isvector(R)
 diagr = abs(diag(R));
else
 diagr = R(1);
end
% Rank estimation
r = find(diagr >= tol*diagr(1), 1, 'last'); % rank estimation
indep = sort(E(1:r));
Xind = X(:,indep);
n = size(X,2);
dep = gm_fmt([1:n],indep);
Xdep = X(:,dep);




