function next = gm_next_tuple(tuple,upbd);
%GM_NEXT_TUPLE returns the next item in all the possible combinations

% there are n integers in the tuple (which is a row vector)
% the max value of the integers is upbd

% Input:
% tuple = previous tuple
% upbd = max number of elements
%
% Output:
% next = next tuple

%
% Author G. Meurant
% October 2012
% Updated September 2015
%

n = length(tuple);
ltup = n;

% add 1 to the last element and propagates the carries to the left
next = tuple;

next(ltup) = next(ltup) + 1;

for k = ltup:-1:2
 if next(k) > upbd
  next(k-1) = next(k-1) + 1;
  if next(k-1) > upbd - n + k - 1
   next(k-1) = upbd + 1;
   continue
  end
  for j = k:n
   next(j) = next(j-1) + 1;
  end
 end
end

if any(next > upbd)
 next = zeros(1,n);
end


