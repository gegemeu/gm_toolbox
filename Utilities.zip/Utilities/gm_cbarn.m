function gm_cbarn(vp)
%GM_CBARN bar visualization of n sets of real data on the same scale for comparison
% the sets are the columns of vp
%

%
% Author G. Meurant
% july 2003
% updated April 2015
%

figure

hold on

n = size(vp,2);
ln = 2/n;
yn = linspace(-1 + ln / 2,1 - ln / 2,n);
lmin = min(min(vp));
lmax = max(max(vp));
del = (lmax - lmin) / 10;

for j = 1:n
 vpj = vp(find(vp(:,j)),j);
 m = length(vpj);
 y(1) = yn(n - j + 1) - ln / 4;
 y(2) = yn(n - j + 1) + ln / 4;
 for i = 1:m
  x(1) = vpj(i);
  x(2) = vpj(i);
  plot(x,y,'b')
 end % for i
end % for j

axis([lmin - del, lmax + del, -1, 1])

hold off
