function U=gm_U_from_Hess(H);
%GM_U_FROM_HESS U factor of a (generalized) Hessenberg matrix

n = size(H,2);
H = H(1:n,1:n);

e1 = eye(n,1);
U = gm_Krylovnn(H,e1,n);

