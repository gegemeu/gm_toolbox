function [q,e,e0,alpha,beta] = gm_pftoqd(t,w);
%GM_PFTOQD computes the augmented QD row of a partial fraction given by the points t and the weights w

% from Dirk Laurie's paper

% Input:
% t = nodes
% w = weights, sum(w) = 1
%
% Output:
% q, e, e0 = qd variables
% alpha = diagonal entries of the tridiagonal matrix
% beta = subdiagonal entries

%
% Author G. Meurant
% April 2024
%

n = length(t);

mu = w(n);
alpha(1) = t(n);
beta = [];
if n == 1
  q = 0;
  e = 0;
  e0 = 0;
 return
end

% sort the points and compute the differences
[t,ind] = sort(t);
w = w(ind);
if size(t,1) ~= 1
 t = t';
end % if
t = [0 t];
sig = t(2:end) - t(1:end-1);

if size(w,1) ~= 1
 w = w';
end % if
Q = [w zeros(1,n)];
k = n+1;
Q(k) = sig(n);

for j = n-1:-1:1
 [Q(j:2:k),Q(j+1:2:k)] = dqds(Q(j:2:k),Q(j+1:2:k),0);
 if j > 1
  [Q(j+1:2:k+1),Q(j+2:2:k+1)] = dstqd(Q(j+1:2:k+1),Q(j+2:2:k+1),-sig(j));
 end % if
 k = k + 1;
end

q = Q(2:2:2*n);
e = Q(3:2:2*n-1);
e0 = Q(1);
alpha(1) = q(1);
alpha(2:n) = q(2:n) + e(1:n-1);
% we have to use t_2 instead of t_1 because we put a 0 in front of t
alpha = (alpha + t(2))';
beta(1:n-1) = sqrt(q(1:n-1) .* e(1:n-1));
beta = beta';
end % function

function [q,e] = dqds(q,e,sigma);
%MMQ_DQDS progressive QD algorithm with shift sigma;
% Fernando and Parlett, from Laurie's paper
% based on Rutishauser's qd algorithm

n = length(q);
d = q(1) - sigma;
for k = 1:n-1
 q(k) = d + e(k);
 f = q(k+1) / q(k);
 e(k) = f * e(k);
 d = f * d - sigma;
end % for k
q(n) = d;
end % function dqds

function [q,e] = dstqd(q,e,sigma);
%DSTQD stationary QD algorithm with shift sigma
% Fernando and Parlett, from Laurie's paper
% based on Rutishauser's qd algorithm

n = length(q);

t = -sigma;
for k = 1:n-1
 u = q(k);
 q_old = q(k);
 q(k) = q(k) + t;
 f = e(k) / q(k);
 if isinf(f)
  n1=n-1
  sigma
  q
  k
  q_old
  t
  error('DSTQD: error f infinite')
 end % if
 e(k) = f*u;
 t = t * f - sigma;
end % for k
q(n) = q(n) + t;
end % function dstqd


