function [z1,z2,z3,realsol] = gm_cubic(a2,a1,a0);
%GM_CUBIC solution of a cubic equation

% z^3 + a2 z^2 + a1 z + a0 = 0

% works only for real coefficients a_i

% z1, z2, z3 = solutions
% realsol = number of real solutions

%
% Author G. Meurant
% February 2024
%

q = a1 / 3 - a2^2 / 9;
r = (a1 * a2 - 3 * a0) / 6 - a2^3 / 27;
qr = r^2 + q^3;

if qr > 0 
 % one real solution, two complex conjugate ones
 realsol = 1;
 a = (abs(r) + sqrt(qr))^(1/3);
 if r >= 0
  t1 = a - q / a;
 else
  t1 = q / a - a;
 end % if r
 z3 = t1 - a2 / 3;
 x1 = -t1 / 2 - a2 / 3;
 y1 = (sqrt(3) / 2) * (a + q / a);
 z1 = x1 + 1i * y1;
 z2 = x1 - 1i *y1;
else
 % three real solutions
 realsol = 3;
 if q == 0
  teta = 0;
 else
  teta = acos(r / ((-q)^(3/2)));
 end % if q

 phi1 = teta / 3;
 phi2 = phi1 - (2 * pi) / 3;
 phi3 = phi1 + (2 * pi) / 3;
 rq = 2 *sqrt(-q);
 z3 = rq * cos(phi1) - a2 / 3;
 z1 = rq * cos(phi2) - a2 / 3;
 z2 = rq * cos(phi3) - a2 / 3;
end % if qr


 