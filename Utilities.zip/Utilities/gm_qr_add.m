function [Q,R]=gm_qr_add(Q_old,R_old,u,alpha);
%GM_QR_ADD QR factorization of an augmented symmetric matrix
%
% Q R = [ Q_old Rold, u; u^T alpha]
%

% see: Updating the QR Factorization and the Least Squares Problem
% S. Hammarling and C. Lucas (2008)

% Input:
% Q_old, R_old = QR (square) factors, Q_old orthonormal, R_old upper triangular
% u = vector to be added, last column is [u; alpha]
%
% Output:
% Q, R = QR factorization of the augmented matrix
%

%
% Author G. Meurant
% June 2016
%

[m,n] = size(R_old);
if m ~= n
 error('gm_qr_add: R_old must be square')
end

% add a last row

R = [R_old u; zeros(1,m) alpha];
Q = [Q_old zeros(m,1); zeros(1,m) 1];
c = zeros(1,m);
s = zeros(1,m);

for j = 1:m
 [cc,ss] = gm_givens(R(j,j),u(j));
 c(j) = cc;
 s(j) = ss;
 R(j,j) = c(j) * R(j,j) - s(j) * u(j);
 if m > 1
  t1 = R(j,j+1:m);
  t2 = u(j+1:m);
  R(j,j+1:m) = c(j) * t1 - s(j) * transpose(t2);
  u(j+1:m) = s(j) * transpose(t1) + c(j) * t2;
 end
 t1 = Q(1:m+1,j);
 t2 = Q(1:m+1,m+1);
 Q(1:m+1,j) = c(j) * t1 - s(j) * t2;
 Q(1:m+1,m+1) = s(j) * t1 + c(j) * t2;
end % for j

% add a last column
% we just have to apply Q^T to the last column of R

R(:,m+1) = Q' * R(:,m+1);




 