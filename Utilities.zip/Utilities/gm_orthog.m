function Q = gm_orthog(V,tol);
%GM_ORTHOG keep only the most significant columns in V

% from P. Tichy

[Q,S,~] = svd(V,'econ');
s = diag(S);

s = s / s(1); % normalization with the largest singular value

r = find(s < tol,1);

if ~isempty(r)
 Q = Q(:,1:r-1);
end % if





