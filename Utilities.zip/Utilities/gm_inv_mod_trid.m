function [Ti,T] = gm_inv_mod_trid(n,alpha,beta,delta);
%GM_INV_MOD_TRID inverse of a modified Toeplitz tridiagonal matrix

% T = (-beta,alpha,-beta) except T_{1,1} = T_{n,n} = delta
% beta = + or - 1

%
% Author G. Meurant
% June 2024
%

if beta ~= 1 && beta ~= -1
 error('gm_inv_mod_trid: beta must be equal to 1 or -1')
end

rp = (alpha + sqrt(alpha^2 - 4 * beta^2)) / 2;
rm = (alpha - sqrt(alpha^2 - 4 * beta^2)) / 2;
lamb = alpha - delta;
phip = rp - lamb;
phim = rm - lamb;

Ti = zeros(n,n);
T = [];

if alpha ~= 2
 rho = zeros(n,1);
 nu = zeros(n,1);
 for i = 1:n
  rho(i) = beta^(i-1) * (phip * rp^(n-i) - phim * rm^(n-i)) / (phip^2 * rp^(n-1) - phim^2 * rm^(n-1));
  nu(i) = beta^(i-1) * (phip * rp^(i-1) - phim * rm^(i-1)) / (rp - rm);
 end % for i
 for i = 1:n
  for j = i+1:n
   Ti(i,j) = rho(j) * nu(i);
   Ti(j,i) = Ti(i,j);
  end % for j
  Ti(i,i) = rho(i) * nu(i);
 end % for i
else
 for i = 1:n
  for j = i:n
   Ti(i,j) = beta^(i+j) * ((1 + (1 - lamb) * (i - 1)) * (1 + (1 - lamb) * (n - j))) / ((1 - lamb) * ((1 - lamb) * (n -1) +2));
   if j > i
    Ti(j,i) = Ti(i,j);
   end % if
  end % for j
 end % for i
end % if alpha

if nargout == 2
 T = zeros(n,n);
 for i = 1:n-1
  T(i,i+1) = -beta;
  T(i+1,i) = -beta;
  T(i,i) = alpha;
 end % for i
 T(1,1) = delta;
 T(n,n) = delta;
end % if nargout


  