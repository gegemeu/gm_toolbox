function [info,lamb,dB,k,nr]=gm_lin_comb_PDC(Ak,nitmax,sig);
%GM_LIN_COMB_PDC PDC algorithm for finding a positive definite linear combination
% of A_1, ..., A_k

% the smallest eigenvalue has to be >= sig
% but the stopping test gives only > 0

% see Zaidi's paper;
%  Positive definite combination of symmetric matrices
%   IEEE Transactions on Signal Processing, v 53, no. 11 (2005), pp. 4412-4416

% Input:
% Ak = three-dimensional array, A_i = Ak(i,:,:), A_i symmetric
% nitmax = maximum number of iterations
%
% Output:
% info = 0 if we fail, = 1 if we find a positive definite linear
%        combination, = -1  if we find a negative definite linear
%        combination
% lamb = coefficients of the linear combination
% dB = eiegenvalues of the linear combination
% k = number of iterations
% nr = smallest eigenvalues at each iteration

%
% Author G. Meurant
% Feb 2011
% Updated Sept 2015
%

% initialization

A1 = Ak(:,:,1);
p = size(Ak,3);
n = size(A1,1);
info = 0;
nr = zeros(1,nitmax);

lamb = ones(p,1);
lamb = lamb / norm(lamb);

% linear combination
B = lamb(1) * A1;
for j = 2:p
 Akj = full(Ak(:,:,j));
 B = B + lamb(j) * Akj;
end % for j

At = gm_vecsetmat(Ak);

% transform the initial B and lamb
dB = real(eig(B));
I = find(dB > 0);
cpos = length(I);
cneg = n - cpos;
mu = min(abs(dB));
if cneg > cpos
 B = -B / mu;
 lamb = - lamb / mu;
else
 B = B / mu;
 lamb = lamb / mu;
end % if cneg
% eigen-decomposition of B
[UB,DB] = eig(B);
[y,I] = sort(diag(DB));
y = y(n:-1:1);
I = I(n:-1:1);
DB = diag(y);
UB = UB(:,I);
% init Delta
y = rand(n,1);
y = y(n:-1:1);
Del = diag(y);

% iterations

for k = 1:nitmax
 
 dB = real(diag(DB));
 [lambB,I] = min(dB);
 if lambB > 0
  % we have found a positive definite combination
  info = 1;
  nr(k) = lambB;
  return
 end % if
 
 dd = max(dB,sig);
 D = diag(dd);
 UU = UB * D * UB';
 [B,lamb] = proj_mat(At,UU);
 [UB,DB] = eig(B);
 % sort the eigenvalues in descending order
 [y,I] = sort(diag(DB));
 y = y(n:-1:1);
 I = I(n:-1:1);
 DB = diag(y);
 UB = UB(:,I);
 
 nr(k) = lambB;
 
end % for k

end

function [B,lamb] = proj_mat(At,M);
% projection on the span of A_1,...,A_p

n = size(M,1);
vM = vecmat(M);

AA = At' * At;
lamb = AA \ (At' * vM);
b = At * lamb;
B = reshape(b,n,n);

end




