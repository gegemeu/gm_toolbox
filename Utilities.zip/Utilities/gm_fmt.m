function ft=gm_fmt(f,t);
%GM_FMT for two lists of integers computes f\t
% t is supposed to be included in f
%

%
% Author G. Meurant
% Aug 2000
% Updated April 2015
%

if length(f) == 0
 ft = f;
 return
end

nt = length(t);
if nt == 0
 ft = f;
 return
end

ft = f;
for i = 1:nt
 ind = find(ft ~= t(i));
 if length(ind) == 0
  ft = [];
  return
 else
  ft = ft(ind);
 end
end
