function [As,Dm] = gm_diagonal_scaling(A);
%GM_DIAGONAL_SCALING symmetrically scales the matrix A

% Input:
%  A = symmetric matrix
%
% Ouput:
%  As = matrix scaled
%  Dm = diagonal matrix sqrt(diag(A)) ^{-1}

%
% Author G. Meurant
% March 2016
%

D = diag(A);
Dm = diag(1 ./ sqrt(D));

As = Dm * A * Dm;

As = (As + As') / 2;


