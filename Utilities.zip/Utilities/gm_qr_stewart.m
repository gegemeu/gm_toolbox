function [Q,R]=gm_qr_stewart(A,m);
%GM_QR_STEWART QR factorization using Stewart's block GS

% Input:
% A = matrix
% m = block size
%
% Output:
% Q = orthonormal matrix
% R = upper triangular matrix
%  A = Q * R

%
% Author G. Meurant
% August 2019
%

[n,ncol] = size(A);
Q = zeros(n,ncol);
R = zeros(ncol,ncol);
if m > ncol
 fprintf('\n The block size is too large \n')
 m = ncol;
end % if
nb = fix(ncol / m); % number of blocks
nrem = ncol - nb * m;
if nrem > 0
 nb = nb + 1; 
end % if
 
 % first block
 [Y,R12,R22] = gm_bgssro(A(:,1)/norm(A(:,1)),A(:,2:m));
%  [Y,R12,R22] = bgssro(A(:,1)/norm(A(:,1)),A(:,2:m));
 Y = [A(:,1)/norm(A(:,1)) Y];
 nr = size(R12,1) + size(R22,1);
 Q(:,1:m) = Y;
 R(1,1) = norm(A(:,1));
 R(1:nr,2:m) = [R12; R22];
 
 % other blocks
 for k = 2:nb
  cd = (k - 1) * m + 1;
  cf = k * m;
  if (nrem > 0) && (k == nb)
   cf = ncol;
  end % if
  [Y,R12,R22] = gm_bgssro(Q(:,1:cd-1),A(:,cd:cf));
%   [Y,R12,R22] = bgssro(Q(:,1:cd-1),A(:,cd:cf));
  nr = size(R12,1) + size(R22,1);
  Q(:,cd:cf) = Y;
  R(1:nr,cd:cf) = [R12; R22];
  end % for k
  
  
  
 
 
