function ul = gm_ulp(x);
%GM_ULP unit in the last place

p = 53;
if strcmpi(class(x),'single') == 1
 p = 24;
end % if

ul = 2^(floor(log2(x)) - p + 1);

