function [x,y] = gm_meshpq(p,q);
%GM_MESHPQ coordinates of a p x q mesh of the unit square

%
% Author G. Meurant
%

hx = 1 / (p + 1);
n = p * q;
xx = [hx:hx:1-hx];
hy = 1 / (q + 1);
yy = [hy:hy:1-hy];

for i = 1:p:n
 x(i:i+p-1) = xx;
end

for i = 1:q
 y(i:p:n) = yy;
end
   
 