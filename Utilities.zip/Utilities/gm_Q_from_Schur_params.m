function Q=gm_Q_from_Schur_params(gam,sig);
%GM_Q_FROM_SCHUR_PARAMS constructs a unitary upper Hessenberg matrix
% from the Schur parameters

% sig must be real and > 0

% Input:
% gam, sig = Schur parameters
%
% Output:
% Q = unitary upper Hessenberg matrix

%
% Author G. Meurant
% June 2012
% Updated Sept 2015
%

n = length(gam);

if length(sig) < n - 1
 error('gm_Q_from_Schur_params: The length of sig is too small')
end
if ~isreal(sig)
 error('gm_Q_from_Schur_params: sig must be real')
end
if any(sig < 0)
 error('gm_Q_from_Schur_params: sig must be positive')
end

sig = sig(1:n-1);
gam = gam(:)';
sig = sig(:)';

% sub diagonal
Q = diag(sig,-1);

% first row
Q(1,1) = -gam(1);
cp = cumprod(sig);
Q(1,2:n) = -cp .* gam(2:n);

for k = 2:n-1
 % row k
 cp = cumprod(sig(k:n-1));
 Q(k,k) = -conj(gam(k-1)) * gam(k);
 Q(k,k+1:n) = -conj(gam(k-1)) * cp .* gam(k+1:n);
end

% last row
Q(n,n) = -conj(gam(n-1)) * gam(n);

