function [z1,z2,z3,z4] = gm_quartic(a3,a2,a1,a0,meth);
%GM_QUARTIC solution of a quartic equation

% z^4 + a3 z^3 + a2 z^2 + a1 z + a0 = 0

% works only for real coefficients

%
% Author G. Meurant
% February 2024
%

if nargin == 4
 meth = 1;
end % if

switch meth
 
 case 1
  
  % Modified Ferrari's method
  
  c = a3 / 4;
  b2 = a2 - 6 * c^2;
  b1 = a1 - 2 * a2 * c + 8 * c^3;
  b0 = a0 - a1 * c + a2 * c^2 - 3 * c^4;
  
  [~,~,zz3] = gm_cubic(b2,b2^2/4-b0,-b1^2/8);
  
  if zz3 > 0
   m = zz3;
  else
   m = 0;
  end % if
  
  if b1 > 0
   s = 1;
  else
   s = -1;
  end % if
  
  r = s * sqrt(m^2 + b2 * m + b2^2 / 4 - b0);
  mr = sqrt(-m / 2 - b2 / 2 - r);
  z1 = sqrt(m / 2) - c + mr;
  z2 = sqrt(m / 2) - c - mr;
  mr = sqrt(-m / 2 - b2 / 2 + r);
  z3 = -sqrt(m / 2) - c + mr;
  z4 = -sqrt(m / 2) - c - mr;
  
 case 2
  
  % NBS modified
  
  c2 = - a2;
  c1 = a1 * a3 - 4 * a0;
  c0 = 4 * a0 * a2 - a1^2 - a0 * a3^2;
  [u1,u2,u3,realsol] = gm_cubic(c2,c1,c0);
  if realsol == 1
   u = u3;
  else
   u = max([u1 u2 u3]);
  end % if
  if a1 - a3 * u / 2 > 0
   s = 1;
  else s = -1;
  end % if
  a3u = sqrt(a3^2 / 4 + u - a2);
  p1 = a3 / 2 - a3u;
  p2 = a3 / 2 + a3u;
  ua0 = sqrt(u^2 / 4 - a0);
  q1 = u / 2 + s * ua0;
  q2 = u / 2 - s * ua0;
  p1q1 = sqrt(p1^2 / 4 - q1);
  z1 = -p1 / 2 + p1q1;
  z2 = -p1 / 2 - p1q1;
  p2q2 = sqrt(p2^2 / 4 - q2);
  z3 = -p2 / 2 + p2q2;
  z4 = -p2 / 2 - p2q2;
  
 case 3
  
  % another method
  
  a = 1; b = a3; c = a2; d = a1; e = a0;
  
  D0 = c^2 - 3 * b * d + 12 * a * e;
  D1 = 2 * c^3 - 9 * b * c * d + 27 * b^2 * e + 27 * a * d^2 - 72 * a * c * e;
  p = (8 * a * c - 3 * b^2) / ( 8 * a^2);
  q = (b^3 - 4 * a * b * c + 8 * a^2 * d) / (8 * a^3);
  Q = ((D1 + sqrt(D1^2 - 4 * D0^3)) / 2)^(1/3);
  S = 0.5 * sqrt(-2 * p / 3 + (Q + D0 / Q) / (3 * a));
  
  z1 = -b / (4 * a) - S + sqrt(-4 * S^2 - 2 * p + q / S) / 2;
  z2 = -b / (4 * a) - S - sqrt(-4 * S^2 - 2 * p + q / S) / 2;
  z3 = -b / (4 * a) + S + sqrt(-4 * S^2 - 2 * p - q / S) / 2;
  z4 = -b / (4 * a) + S - sqrt(-4 * S^2 - 2 * p - q / S) / 2;
  
  
end % switch



