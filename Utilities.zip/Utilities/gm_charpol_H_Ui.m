function [Ui,alpha] = gm_charpol_H_Ui(H);
%GM_CHARPOL_H_UI characteristic polynomial of an upper Hessenberg matrix

% Input:
% H = unreduced upper Hessenberg matrix H = U C inv(U)
%
% Output:
% Ui = upper triangular matrix
% alpha = coefficients of the characteristic polynomial of H

% Uses the recurrence for the rows of Ui
% obtained from inv(U) H = C inv(U)

%
% Author G. Meurant
% January 2024
%

n = size(H,1);
Ui = zeros(n,n);

% first row
Ui(1,1) = 1;
for j = 2:n
 Ui(1,j) = -(1 / H(j,j-1)) * (Ui(1,1:j-1) * H(1:j-1,j-1));
end % for j

for i = 2:n-1
 Ui(i,i) = Ui(i-1,i-1) / H(i,i-1);
 for j = i:n-1
  Ui(i,j+1) = (1 / H(j+1,j)) * (Ui(i-1,j) - Ui(i,i:j) * H(i:j,j));
 end % for j
end % for i

Ui(n,n) = Ui(n-1,n-1) / H(n,n-1);

alpha = zeros(1,n+1);
d = 1 ./ diag(Ui);

% characteristic polynomial of H
fac = 1 / Ui(n,n);
alpha(1) = -fac * (Ui(1,1:n) * H(1:n,n));
for i = 2:n
 alpha(i) = fac * (Ui(i-1,n) - Ui(i,i:n) * H(i:n,n));
end % for i

alpha(n+1) = 1;

alpha = alpha(n+1:-1:1);





