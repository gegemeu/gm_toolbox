function [A,L,zt,beta]=gm_chol_incremental(AA,LL,x,alpha);
%GM_CHOL_INCREMENTAL computes incrementally  the Cholesky factorization
% of   | AA    x   |
%      | x'  alpha | 
% given the factorization of AA = LL LL', LL lower triangular

% returns the bordered matrix and the lower triangular
% factor L
%      | LL   0   |
%      | zt  beta |

%
% Author G. Meurant
% March 2015
%

n = size(AA,1);

A = [AA x; x' alpha];

z = LL \ x;

az = alpha - z' * z;

if az <= 0
 error('gm_chol_incremental: The augmented  matrix is not positive definite')
end

beta = sqrt(az);

L = [LL zeros(n,1); z' beta];

zt = z';

