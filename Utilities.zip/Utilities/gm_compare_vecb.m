function diff = gm_compare_vecb(V,X);
%GM_COMPARE_VECB norms of the differences of the columns of V and X

% Input:
% V = set of vectors
% X = set of vectors

% Ouput:
% diff = norms of the parwise differences

%
% Author G. Meurant
% April 2019
%

[nV,mV] = size(V);
[nX,mX] = size(X);
if nV ~= nX
 error('The first dimensions of V and X must be the same')
end % if

diff = zeros(mV,mX);

for i = 1:mV
 for j = 1:mX
  v = V(:,i);
  x = X(:,j);
  diff(i,j) = norm(v - x);
 end % for j
end % for i

