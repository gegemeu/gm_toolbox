function Ts = gm_sym_trid(T);
%GM_SYM_TRID symmetrization of a tridiahonal matrix

% the subdiagonal entries and corresponding superdiagonal entries must have the same sign

% Input:
% T = tridiagonal matrix
%
% Output:
% Ts = symmetric tridiagonal matrix

%
% Author G. Meurant
% May 2024
%

n = size(T,1);
gamma = zeros(n,1);
beta = diag(T,-1);
omega = diag(T,1);
gamma(1) = 1;

for k = 2:n
 gamma(k) = sqrt( prod(beta(1:k-1)) / prod(omega(1:k-1)) );
end % for k

D = diag(gamma);
Di = diag(1 ./ gamma);
Ts = Di * T * D;

