function T = gm_comp_tuples(P,Q);
%GM_COMP_TUPLES finds the tuples which are in P and Q

%
% Author G. Meurant
% August 2024
%

if size(P,1) < size(Q,1)
 PP = P;
 P = Q;
 Q = PP;
end % if

[np,mp] = size(P);
[nq,mq] = size(Q);
if mp ~= mq
 error('the second dimension of P and Q must be the same')
end % if
m = mp;
k = 0;

for i = 1:np
 for j = 1:nq
  s = P(i,:) == Q(j,:);
  if sum(s) == m
   k = k + 1;
   T(k,:) = P(i,:);
  end % if
 end % for j
end % for i

