function estS=gm_norm_Sk(V);
%GM_NORM_SK estimate of the norm of S_k from Paige with INE

% Input:
% V = set of unit norm vectors
%
% Output:
% nS = norm of S_k
% estS = estimate of norm of S_k

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

kmax = size(V,2);
estS = zeros(1,kmax);

for k = 1:kmax
 S = gm_Paige_S(V,k);
 estS(k) = gm_smax_estR(S);
end






