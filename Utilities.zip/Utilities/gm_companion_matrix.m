function C = gm_companion_matrix(A);
%GM_COMPANION_MATRIX companion matrix of A

% Input:
% A = matrix
%
% Output:
% C = companion matrix

%
% Author G. Meurant
% April 2013
% Updated Sept 2015
%

n = size(A,1);

p = poly(full(A));

C = zeros(n,n);

C(:,n) = -p(n+1:-1:2);
C(2:n,1:n-1) = eye(n-1);

