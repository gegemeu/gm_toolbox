function ft=gm_inters(f,t);
%GM_INTERS computes intersection of two lists of integers

% assumes no replications in lists
% use gm_compr before if there are some

%
% Author G. Meurant
% Aug 2000
%

nt = length(t);
nf = length(f); 

if nt == 0 || nf == 0
 ft = [];
 return
end

% find the longest list
if nf >= nt
 f1 = f;
 n1 = nf;
 f2 = t;
else
 f1 = t;
 n1 = nt;
 f2 = f;
end

ft=[];
for i = 1:n1
 ind = find(f2 == f1(i));
 ft = [ft f2(ind)];
end

