function y = gm_apply_house(V,bet,ns,ne,x);
%GM_APPLY_HOUSE applies the Householder reflections contained in V, bet to x

% Input: 
% V = matrix of the Householder vectors
% bet = vector of Householder coefficients
% ns = starting index in V
% ne = ending index in V
% x = vector
%
% Output:
% y = transformed vector

%
% Author G. Meurant
% Oct 2016
%

nv = size(V,2);
if ns < 1 || ne > nv || ns > ne
 error('gm_apply_house: Index error')
end % if

for k = ns:ne
 vk = V(:,k);
 x = x - bet(k) * (vk' * x) * vk;
end % for k

y = x;
