function [s,e]=gm_compsum(x);
%GM_COMPSUM compensated summation of the elements of a vector x

% see Higham's book

% Input:
% x = vector
%
% Output:
% s = sum
% e = rouding error
%

%
% Author G. Meurant
% April 2003, Sept 2016
%

s = 0;
e = 0;

for i = 1:length(x)
 temp = s;
 y = x(i) + e;
 s = temp + y;
 e =  (temp - s) + y;
end

s = s + e;



