function [x,y,sigmin,eigA] = gm_psa(A,npts);
%GM_PSA 2-norm pseudospectra of A

% Input:
% A = matrix
% npts = number of points on one side of the grid
%
% Output:
% x,y = coordinates of the mesh points
% sigmin = resolvent norms at mesh points
% eigA = eigenvalues of A

%
% From L.N. Trefethen
% 1999
%

A = full(A);

% set up grid
% npts = 10;
s = 0.8 * norm(A,1);
xmin = -s;
xmax = s;
ymin = -s;
ymax = s;
x = linspace(xmin,xmax,npts);
y = linspace(ymin,ymax,npts);
[xx,yy] = meshgrid(x,y);
ii = sqrt(-1);
zz = xx + ii * yy;

% Schur form
[U,T] = schur(A);
if isreal(A)
 [U,T] = rsf2csf(U,T);
end
T = triu(T);
eigA = diag(T);

% reorder Schur decomposition
select = find(real(eigA) > -250);
n = length(select);
for i = 1:n
 for k = select(i)-1:-1:i
  G([2 1],[2,1]) = planerot([T(k,k+1) T(k,k) - T(k+1,k+1)]')';
  J = k:k+1;
  T(:,J) = T(:,J) * G;
  T(J,:) = G' * T(J,:);
 end % for k
end % for i

T = triu(T(1:n,1:n));
I = eye(n);

% compute resolvent norm by inverse Lanczos iteration
%sigmin = Inf * ones(length(y),length(x));
sigmin = zeros(length(y),length(x));
for i = 1:length(y);
 if isreal(A) && (ymax == - ymin) && (i > length(y) / 2)
  sigmin(i,:) = sigmin(length(y)+1-i,:);
 else
  for j = 1:length(x)
   z = zz(i,j);
   T1 = z * I - T;
   T2 = T1';
   if real(z) < 100
    sigold = 0;
    qold = zeros(n,1);
    beta = 0;
    H = [];
    q = randn(n,1) + ii * randn(n,1);
    q = q / norm(q);
    for k = 1:99
     v = T1 \ ( T2 \ q) - beta * qold;
     alpha = real(q' * v);
     v = v - alpha * q;
     beta = norm(v);
     qold = q;
     q = v / beta;
     H(k+1,k) = beta;
     H(k+1,k) = beta;
     H(k,k) = alpha;
     sig = max(eig(H(1:k,1:k)));
     if abs(sigold / sig - 1) < 0.001 || (sig < 3 && k > 2)
      break
     end
     sigold = sig;
    end % for k
    
    if abs(sig) > 1e-20
     sigmin(i,j) = 1 / sqrt(sig);
    end % if sig
   end % if real
  end % for j
 end % if
end % for i



