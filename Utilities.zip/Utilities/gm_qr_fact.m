function [R,V,bet,Q]=gm_qr_fact(A);
%GM_QR_FACT QR factorization of A

% The Householder reflections are I - beta v v^T

% The diagonal entries of R are not necessarily positive

% Input:
% A = matrix
%
% Ouput:
% R = upper triangular matrix
% V = matrix containing the Householder vectors
% bet = vector of the Householder coefficients
% Q = orthonormal matrix (optional)

%
% Author G. Meurant
% Oct 2016
%

[n,m] = size(A);
R = zeros(n,m);
V = zeros(n,m);
bet = zeros(m,1);
Q = [];

% first column
[v,beta] = gm_household(A(:,1),2);
V(:,1) = v;
bet(1) = beta;
va = v' * A(:,1);
% apply the reflection to A
R(1,1) = A(1,1) - beta * va * V(1,1);

% other columns
for k = 2:m
 u = A(:,k);
 % apply the preceding reflections to the k-th column of A
 u = gm_apply_house(V,bet,1,k-1,u);
 % add the new column, add to V and bet
 [V,bet] = gm_qr_add_col(V,k-1,bet,u);
 R(1:k-1,k) = u(1:k-1);
 % apply the last reflection for the diagonal entry
 va = V(:,k)' * u;
 R(k,k) = u(k) - bet(k) * va * V(k,k);
end

% this is costly
if nargout == 4
 Q = eye(n,n) - bet(1) * (V(:,1) * V(:,1)');
 for k = 2:m
  Q = Q * (eye(n,n) - bet(k) * (V(:,k) * V(:,k)'));
 end
end
 
 
 