function [Ui,C,U,Uhi,D]=gm_Ui_from_Hess(H);
%GM_UI_FROM_HESS U^(-1) factor of an upper Hessenberg matrix
% H = U C Ui = U C U^(-1)

n = size(H,2);
H = H(1:n,1:n);
e1 = eye(n,1);
x0 = zeros(n,1);
Ui = zeros(n,n);
Ui(1,1) = 1;
C = zeros(n,n);
C(2:n,1:n-1) = eye(n-1);
nu = zeros(1,n);
nu(1) = 1;

% run FOM to obtain the residual norms for (H,e_1)
[x,nit,iret,resn,resnt,time_mat] = gm_FOMm_prec(H,e1,x0,1e-20,n,2*n,'left','reorth','noscaling','trueres','noprint','no');
res = resnt;

% compute the Ritz values
Theta = gm_Ritz_H(H);
% coefficients of the characteristic polynomials
for k = 1:n-1
 p = poly(Theta(1:k,k));
 Ui(1:k+1,k+1) = transpose(p(k+1:-1:1)) / p(k+1);
end % for k
p = poly(Theta(:,n));
C(:,n) = -transpose(p(n+1:-1:2));

% compute nu to have the signs of the first row
for k = 2:n
 nu(k) = -(1 / H(k,k-1)) * sum(nu(1:k-1) * H(1:k-1,k-1));
end % for k

% eventually change the signs
for k = 1:n
 if sign(nu(k)) < 0
  res(k) = -res(k);
 end % if
end % for k

D = diag(1 ./ res(1:n));

Uhi = Ui;
Ui = Ui * D;

% this may be difficult if Ui is badly conditioned
% U = inv(Ui);
[Q,R] = qr(Ui);
% Ri = zeros(n,n);
% U(1,1) = 1;
% Ri(1,1) = 1 / R(1,1);
% for k = 2:n
%  Ri(k,k) = 1 / R(k,k);
%  Ri(1:k-1,k) = -Ri(k,k) * Ri(1:k-1,1:k-1) * R(1:k-1,k);
% end % for k
% U = Ri * Q';
U = R \ Q';





 