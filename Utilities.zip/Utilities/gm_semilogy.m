function gm_semilogy(sdata,iprint,window,SaveName);
%GM_SEMILOGY semilogy of different curves

% Input:
% sdata = structure array with the data
% window = [xmin, xmax, ymin, ymax], default min and max
% SaveName = file name for the plot

% Example:
% sdata(1).x = [0:nit]; sdata(1).y = y; sdata(1).leg = '$\Vert x - x_k\Vert_A$';
% sdata(2).x = [0:nit]; sdata(2).y = y1; sdata(2).leg = '$\Vert b - Ax_k\Vert$';
% window = [0 nit 1e-20 1e3]; SaveName = 'Fig_1'; Name = 'Plot';
% gm_semilogy(sdata,window,SaveName);

%
% Author G. Meurant
% December 2021
%

warning('off');

cm_inch = 0.393701;  % 1cm / 1 inch
height = cm_inch * 9;
width = cm_inch * 20;

myfigure = figure('Units','in', 'Position',[1 1 width height],'PaperPositionMode','auto');
set(myfigure,'Units','Inches');
pos = get(myfigure,'Position');
set(myfigure,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3),pos(4)]);
set(0,'defaultaxesfontsize',10);
set(0,'defaultlinelinewidth',1.5); 
set(0,'defaultlinemarkersize',5);

N = length(sdata); % number of curves

labelx = 0; labely = 0;
if isfield(sdata,'xlabel')
 labelx = 1;
 string_xlabel = sdata(1).xlabel;
end
if isfield(sdata,'ylabel')
 labely = 1;
 string_ylabel = sdata(1).ylabel;
end

if isfield(sdata,'leg') % legend
 lege = 1;
for k = 1:N
 leg{k} = sdata(k).leg;
end % for k
else
 lege = 0;
end % if

cc = {'b','r','g','m', 'k', 'c'};
if isfield(sdata,'col') % color
 for k = 1:N
  col{k} = sdata(k).col;
 end % for k
else
 if N > 6
  error('gm_semilog: Too many curves, please define the colors')
 else
  for k = 1:N
   col{k} = cc{k};
  end % for k
 end % if
end % if isfield

mm = {'-','-.','--',':', '-+', '-o'};
if isfield(sdata,'mk') % marker
 for k = 1:N
  mk{k} = sdata(k).mk;
 end % for k
else
 if N > 6
  error('gm_semilog: Too many curves, please define the colors')
 else
  for k = 1:N
   mk{k} = mm{k};
  end % for k
 end % if
end % if isfield

% plot the curves
xm = realmax; xM = -realmax;
ym = realmax; yM = -realmax;
for k = 1:N
 x = sdata(k).x;
 y = sdata(k).y;
 xm = min(xm,min(x));
 xM = max(xM,max(x));
 ym = min(ym,min(y));
 yM = max(yM,max(y));
 lc = strcat(cc{k},mk{k});
 p(k) = semilogy(x,y,lc);
 hold on
end % for k
dx = xM- xm; dy = yM - ym;
xm = xm - dx / 10;
xM = xM + dy / 10;
ym = ym - dy / 10;
yM = yM + dy / 10;
 
if lege == 1
 legen = legend(p,leg,'Location','southeastoutside','Interpreter','latex','FontSize',12);
end % if

if labelx == 1
 xlabel( {string_xlabel} ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             12,...
 'FontName',             'Times');
end % if
if labely == 1
 xlabel( {string_ylabel} ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             12,...
 'FontName',             'Times');
end % if

if nargin >= 3
 xm = window(1); xM = window(2);
 ym = window(3); yM = window(4);
end % if

if isfield(sdata,'title')
 tit = sdata(1).title;
 if ~isempty(tit)
  title(tit ,...
 'FontUnits',            'points',...
 'interpreter',          'latex',...
 'FontSize',             12,...
 'FontName',             'Times');
 end
end % if isfield

axis([xm xM ym yM]);
hold off

% sN = 'C:\D\CGQ_book\CGQ_Figures\';
% if nargin < 4 || isempty(SaveName)
%  SaveName = [sN 'fig_' date '_' num2str(randi(100))];
% else
%  SaveName = [sN SaveName];
% end % if
if iprint == 1
 fprintf('\n File Name = %s \n',SaveName)
 print(SaveName,'-dpdf');
end

warning('on');




 

 