function m = gm_Cnk(n,k);
%GM_CNK number of combinations C^n_k

% Input:
% n, k = integers
%
% Output:
% m = C^n_k

%
% Author G. Meurant
% Oct 2012
% Updated Sept 2015
%

m = 0;

if k > n
 return
end

m = factorial(n) / (factorial(k) * factorial(n-k));

