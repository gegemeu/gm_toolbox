function [x,y]=gm_transform_ellipse(xe,ye,cx,cy,a,b);
%GM_TRANSFORM_ELLIPSE maps the points (xe,ye) to the ellipse of center
% cx,cy and semi-axes a,b

% xe,ye are assumed to be in the ellipse of center 0,0 and semi-axes 2,1

%
% Author G. Meurant
% August 2015
%

x = cx + (a / 2) * xe;
y = cy + b * ye;

