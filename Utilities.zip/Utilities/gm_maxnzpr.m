function l = gm_maxnzpr(A);
%GM_MAXNZPR maximum number of non zeros per row of A

%
% Author G. Meurant
% February 2001
%

AA = spones(A);
l = full(max(sum(AA,2)));
