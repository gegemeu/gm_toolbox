function [c,s,rot]=gm_givens_comp(a,b);
%GM_GIVENS_COMP computes Givens rotation to zero b in [a; b]

% from Golub-Van Loan
% The rotation matrix is
%  | c  \bar s |
%  | -s   c |

% Input:
% a,b = components of the vector, a may be complex but b must be real
%
% Output:
% c, s = cosine and sine of the rotation
% rot = rotation matrix
%

%
% Author G. Meurant
% July 2017
%

if b == 0
 c = 1;
 s = 0;
else
 cs = sqrt(abs(b)^2 + abs(a)^2);
 if abs(a) < abs(b)
  mu = a / b;
  tau = conj(mu) / abs(mu);
 else
  mu = b / a;
  tau = mu / abs(mu);
 end % if
 c = abs(a) / cs; % cosine
 s = abs(b) * tau / cs; % sine
end % if b

rot = [c conj(s); -s c];




