function [V,dotprod,R]=gm_orth_cgs(A,dreorth);
%GM_ORTH_CGS (double) orthogonalisation of the columns of A
% Classical Gram-Schmidt

% Caution: R is not computed in the standard way (see gm_orth_cgs_col)

% Input:
% A = matrix
% dreorth = 'dreorth' if we do a second orthogonalization
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% dotprod = number of dot products
% R = upper triangular matrix such that A = V R

%
% Author G.Meurant
% October 2010
% Updated Sept 2015
%

if nargin == 1
 dreorth = 'nodreorth';
end

dotprod = 0;

[m,n] = size(A);
V = zeros(m,n);
v = A(:,1);
V(:,1) = v / norm(v);

% first orthogonalization

for k = 2:n
 w = A(:,k);
 v = w;
 for j = 1:k-1
  alpha = w' * V(:,j);
  v = v - alpha * V(:,j);
 end % for j
 dotprod = dotprod + k - 1;
 
 if strcmpi(dreorth,'dreorth') == 1
  % second orthogonalization
  w = v;
  for j = 1:k-1
   alpha = w' * V(:,j);
   v = v - alpha * V(:,j);
  end % for j
  dotprod = dotprod + k - 1;
 end % if
 
 nv = norm(v);
 dotprod = dotprod + 1;
 if nv <= 1e-15
  fprintf('\n gm_orth_cgs: Breakdown, step %d \n\n',k)
  return
 end
 v = v / norm(v);
 V(:,k) = v;
 
end % for k

if nargout == 3 % this must be too expensive and less accurate
 % see gm_orth_cgs_col
 % V might not be fully orthogonal
 VV = V' * V;
 R = VV \ (V' * A);
end



