function north=gm_nivorth(Q);
%GM_NIVORTH computes the level of orthogonality of a set of vectors
% norm(I-Q'Q) as a function of the column index

%
% Author G. Meurant
% june 2003
%

nq = size(Q,2);
north = zeros(nq,1);

for k = 1:nq
 north(k) = norm(eye(k)-Q(:,1:k)'*Q(:,1:k));
end % for k


