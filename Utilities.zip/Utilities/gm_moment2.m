function [M,ML,MLL] = gm_moment2(A,v);
%GM_MOMENT2 moment matrices for A normal

% Input:
% A = normal matrix
% v = vector
%
% Output:
% M = matrix s.t. M(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j-1)
% ML = matrix s.t. ML(i,j) = sum om(k) conj(lamb(k))^(i-1) lamb(k)^(j)
% MLL = matrix s.t. MLL(i,j) = sum om.*conj(lamb).^(i).*lamb.^(j));

%
% Author G. Meurant
% December 2013
% Updated September 2015
%

[X,D] = eig(full(A));

v = v / norm(v);
c = X' * v;
om = abs(c).^2;

[M,ML,MLL] = gm_momat2(om,diag(D));

