function gm_vizmat(A,color,umin,umax);
%GM_VIZMAT visualization of a matrix as a rectangular mesh

% Input:
% A = real matrix
% color = colormap
% umin, umax = min and max of the scale


% available colormaps:
%  jet, HSV, hot, cool, spring, summer, autumn, winter, gray,
%  bone, copper, pink, lines

% nodes coordinates are in xm, ym
% This works only for small matrices order ~ 100

%
% Author G. Meurant
% March 2003
% updated April 2015
%

[n,m] = size(A);

if nargin <= 2
 % default for min and max of the scale
 umin = min(min(A));
 umax = max(max(A));
end

if nargin == 1
 % default colormap
 color = 'jet';
end

% compute the coordinate on [0,1]^2
[nm,xm,ym] = gm_meshsquare(m,n);

h = 1;
hold off
plot([xm(1) xm(1)],[ym(1) ym(1)])
hold on
colormap(color)
c = colormap;
lc = size(c,1);
du = umax-umin;
xmin = min(xm);
xmax = max(xm) + h;
ymin = min(ym);
ymax = max(ym)+h;
hx = xmax - xmin;
hy = ymax - ymin;
hmax = max([hx hy]);
% hxy = hmax / 10;
hxy = hmax / 100;
axis([xmin - hxy, xmax + hxy, ymin - hxy, ymax + hxy]);
u = reshape(full(A),m*n,1);

for i = 1:m*n
 x1 = xm(i);
 y1 = ym(i);
 x2 = x1 + h;
 y2 = y1;
 x3 = x1 + h;
 y3 = y1 + h;
 x4 = x1;
 y4 = y1 + h;
 if du > 0
  ci = fix((umax - u(i) + lc * (u(i) - umin)) / du);
  ci = max([1 ci]);
  ci = min([lc ci]);
 else
  ci = 1;
 end
 col = c(ci,:);
 fill([x1 x2 x3 x4],[y1 y2 y3 y4],col);
end

%gm_mycolorbar1(umin,umax)
colorbar

caxis([umin, umax]);

axis square

axis off

hold off


