function m = gm_print_rounding_mode;
%GM_PRINT_ROUNDING_MODE prints he current rounding mode

%
% Author G. Meurant
% May 2023

m = feature('setround');

if m == 0.5
 fprintf('\n The rounding mode is round to nearest \n')
 return
end % if

if m == Inf
 fprintf('\n The rounding mode is round towards infinity \n')
 return
end % if

if m == -Inf
 fprintf('\n The rounding mode is round towards -infinity \n')
 return
end % if

if m == 0
 fprintf('\n The rounding mode is round towards zero \n')
 return
end % if

