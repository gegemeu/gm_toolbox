function [C,multflops,gflops,time]=gm_matmult(A,B);
%GM_MATMULT matrix-matrix multiplication timing

% Input:
% A, B = square matrices
%
% Output:
% C = A B
% multflops = number of floating point operations
% gflops = computation speed (gigaflops)
% time = computing time

%
% Author G. Meurant
% Jan 2012
% Updated Sept 2015
%

n = size(A,1);

% number of operations of one multiply (dense matrices)
nop = 2 * n^3 + n^2;

% repeat kmax times
kmax = 10;
if n < 100
 % small matrices
 kmax = 100;
end
% large matrices
if n > 1000
 kmax = 10;
end
y = zeros(1,kmax);
C = B;

% tstart = cputime;
tic;

for k = 1:kmax
 %C = A * B;
 C = A * C;
 y(k) = C(1,1);
end

% time = cputime - tstart;
time = toc;

mult = kmax * nop / time;

% gigaflops
gflops = mult * 1e-9;

time = time / kmax;
multflops = nop;
