function [H,rot]=gm_triang_bidiag_Hess(H);
%GM_TRIANG_BIDIAG_HESS reduction to triangular form of a bidiagonal upper Hessenberg matrix
% upper Hessenberg matrix

% Input:
% H = bidiagonal upper Hessenberg matrix (m+1) x m
%
% Output:
% H = bidiagonal upper triangular matrix
% rot = Givens rotations used for the reduction

%
% Author G. Meurant
% Jan 2016
%

m = size(H,2);

% init Givens rotations
rot = zeros(2,m);

for k = 1:m
 
 if k > 1
  % apply the preceding Givens rotations to the next column
  kk = k - 1;
  g1 = H(kk,k);
  g2 = H(kk+1,k);
  H(kk+1,k) = -rot(2,kk) * g1 + rot(1,kk) * g2;
  H(kk,k) = rot(1,kk) * g1 + conj(rot(2,kk)) * g2;
 end
 
 % compute, store and apply a new rotation to zero the last term in kth column
 gk1 = H(k+1,k);
 gk = H(k,k);
 cs = sqrt(abs(gk1)^2 + abs(gk)^2);
 if abs(gk) < abs(gk1)
  mu = gk / gk1;
  tau = conj(mu) / abs(mu);
 else
  mu = gk1 / gk;
  tau = mu / abs(mu);
 end % if
 % store the rotation for the next columns
 rot(1,k) = abs(gk) / cs; % cosine
 rot(2,k) = abs(gk1) * tau / cs; % sine
 
 % modify the diagonal entry
 H(k,k) = rot(1,k) * gk + conj(rot(2,k)) * gk1;
 H(k+1,k) = 0;
 
end %  for k

H = H(1:m,1:m);



