function [Q,R,flag]=gm_cholQR2(V);
%GM_CHOLQR2 iterated factorization of a tall and skinny matrix V = Q R

% Input:
% V = matrix with columns of unit norm
%
% Output:
% Q = nearly orthogonal matrix
% R = upper triangular matrix such that V = Q R
% flag = return code (error if flag = 1)

%
% Author G. Meurant
% Oct 2015
% modified July 2019
%

flag = 0;
% Gram matrix
S = V' * V;

% Cholesky factor
[R1,msg] = chol(S);

if msg > 0
 flag = 1;
 return
end

Q1 = V / R1;

% Iterate once

S = Q1' * Q1;

% Cholesky factor
[R2,msg] = chol(S);

if msg > 0
 flag = 1;
 return
end

R = R2 * R1;

Q = V / R;

