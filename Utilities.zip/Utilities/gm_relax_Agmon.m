function [flag,x,nit] = gm_relax_Agmon(A,b,epss,nitmax);
%GM_RELAX_AGMON solve for A x <= b

% relaxation (projection) algorithm for linear inequalities

% Agmon's projection method:
% Can. J. Math., v 6 (1954), 382-392

% Input:
% A = matrix
% b = right-hand side
% epss = convergence criteria
% nitmax = maximum number of iterations
%
% Output:
% flag = 1 if the inequalities are feasible
% x = solution if any
% nit = number of iterations

%
% Author G. Meurant
% December 2012
% Updated September 2015
%

% change the signs
A = -A;

% the hyperplanes are defined by
% l_i(x) = sum A_{i,j} x_j + b_i = 0

[m,n] = size(A);

% initialization

% randn('state',0);
% s = RandStream('mt19937ar','Seed', 5489);
% RandStream.setDefaultStream(s);
rng('default')

x = randn(n,1);
x_old = x;
flag = 0;

if nargin < 3
 epss = 1e-6;
end
conv = realmax;
if nargin < 4
 nitmax = 100;
end
nit = 0;

% norm of each row of A
norm_row = zeros(m,1);
for k = 1:m
 norm_row(k) = norm(A(k,:));
end

while (conv > epss) && (nit <= nitmax)
 nit = nit + 1;
 
 % evaluate the inequalities
 L = A * x_old + b;
 
 % find the equations that violate the constraints
 I_neg = find(L < 0);
 
 if isempty(I_neg)
  % all inequalities are satisfied
  flag = 1;
  return
 end
 
 val = -L(I_neg) ./ norm_row(I_neg);
 
 % pick the maximum value
 
 [valmax,I] = max(val);
 I0 = I_neg(I(1));
 
 % compute the new iterate by projection on the chosen hyperplane
 
 dx = (L(I0) / norm_row(I0)^2) * A(I0,:)';
 
 x = x_old - dx;
 
 conv = norm(dx) / norm(x);
 
 if conv <= epss
  flag = 1;
  return
 end
 
 x_old = x;
 
end

% no convergence in nitmax iterations

flag = 0;
x = [];

