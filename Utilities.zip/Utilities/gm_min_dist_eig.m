function lmin = gm_min_dist_eig(eigA,T,neig);
%GM_MIN_DIST_EIG minimum distances to a given eigenvalue
%
% T is the Lanczos tridiagonal matrix
% neig is the number of the eigenvalue in eigA (vector of eigenvalues)
%
%
% Author G. Meurant
% Sept 2019
%

l = eigA;
n = length(eigA);
kmax = size(T,1);
lmin = zeros(kmax,1);

for k = 1:kmax
 Tk = T(1:k,1:k);
 vptk = sort(eig(full(Tk)));
 lmin(k) = min(abs(vptk - l(neig)));
end % for k

figure
plot(log10(lmin))
title(['minimum distance to ' num2str(neig)])




