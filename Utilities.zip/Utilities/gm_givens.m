function [c,s]=gm_givens(a,b);
%GM_GIVENS computes Givens rotation to zero b in [a; b]

% from Golub-Van Loan
% The rotation matrix is
%  | c  -s |
%  | s   c |

% Input:
% a,b = components of the vector (real)
%
% Output:
% c, s = cosine and sine of the rotation
%

%
% Author G. Meurant
% June 2016
%

if b == 0
 c = 1;
 s = 0;
else
 if abs(b) > abs(a)
  t = -a / b;
  s = 1 / sqrt(1 + t^2);
  c = s * t;
 else % if abs
  t = -b / a;
  c = 1 / sqrt(1 + t^2);
  s = c * t;
 end % if abs
end % if b


