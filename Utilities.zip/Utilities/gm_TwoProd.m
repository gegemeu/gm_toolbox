function [x,y]=gm_TwoProd(a,b);
%GM_TWOPROD computes the product of a and b and its rounding error

% used in gm_solve_triangle

% Input:
% a, b = real numbers to be mutliplied
%
% Output:
% x = product of a and b
% y = rounding error

%
% April 2014
% Updated August 2015
%

x = a .* b;
[ah,al] = Split(a);
[bh,bl] = Split(b);
y = al .* bl - (((x - ah .* bh) - al .* bh) - ah .* bl);

end

function [x,y]=Split(a);

% this is for double precision f = 2^27 + 1
f = 134217728 + 1; % 2^27 is exact

z = a * f;
x = z - (z - a);
y = a - x;

end

