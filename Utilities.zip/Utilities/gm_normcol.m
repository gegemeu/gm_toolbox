function normcol = gm_normcol(A);
%GM_NORMCOL norms of the columns of A

%
% Author G. Meurant
% April 2018
%

m = size(A,2);
normcol = zeros(1,m);
for k = 1:m
 normcol(k) = norm(A(:,k));
end

