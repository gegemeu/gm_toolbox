function gm_draw_ellipse(n,cx,cy,a,b);
%GM_DRAW_ELLIPSE draws an ellipse of center [cx,cy] with semi-axes a and b
% with n points

%
% Author G. Meurant
% July 2015
%

x = zeros(n+1,1);
y = x;

k = [0:n] * 2 * pi / n;

x = cx + a * cos(k);
y = cy + b * sin(k);

plot(x,y)

