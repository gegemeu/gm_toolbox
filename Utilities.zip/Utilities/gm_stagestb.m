function nb = gm_stagestb(b,L,dd1,x,precond);
%GM_STAGESTB computes a quantity for the estimation of the maximum accuracy

%
% Author G. Meurant
% April 2001
% updated June 2015
%

switch precond
 
case {'no','po','tw','ml'}
 nb = norm(b);
 
case {'ai','sa'}
 w = L * (b ./ dd1);
 nb = norm(w);
 
otherwise
 w = L \ b;
 y = w ./ dd1;
 nb = norm(y);
 
end