function gm_f_circle(f,n);
%GM_F_CIRCLE draws the image of the unit circle with n points

% f = function

%
% Author G. Meurant
% January 2024
%

x = zeros(n+1,1);
y = x;

epsi = 1e-10;
pts = linspace(epsi,n,n);
k = pts * 2 * pi / n;

x = cos(k);
y = sin(k);
z = x + 1i * y;
fz = f(z);
x = real(fz);
y = imag(fz);

plot(x,y)

xmax = max(1, max(x));
xmin = min(-1,min(x));
dx = xmax - xmin;
ymax = max(1, max(y));
ymin = min(-1,min(y));
dy = ymax - ymin;
dxy = max(dx,dy);
xma = xmin + dxy;
yma = ymin + dxy;
axis([1.1*xmin 1.1*xma 1.1*ymin 1.1*yma])

