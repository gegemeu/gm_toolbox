function [z1,z2,z3,realsol] = gm_cubic_gen(a3,a2,a1,a0);
%GM_CUBIC_GEN solution of a general cubic equation

% a3 z^3 + a2 z^2 + a1 z + a0 = 0

% works only for real coefficients

% z1, z2, z3 = solutions
% realsol = number of real solutions

%
% Author G. Meurant
% February 2024
%

if a3 == 0
error('gm_cubic_gen: This is not a cubic equation')
end % if

[z1,z2,z3,realsol] = gm_cubic(a2/a3,a1/a3,a0/a3);

