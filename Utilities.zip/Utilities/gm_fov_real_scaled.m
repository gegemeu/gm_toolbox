function gm_fov_real_scaled(A,nsample);
%GM_FOV_REAL_SCALED random estimation of the real scaled field of values

% |b' A b| / ||A b||

% Input:
% A = real matrix
% nsample = number of random real vectors

%
% Author G. Meurant
% December 2009
% Updated Sept 2015
%

n = size(A,1);

val = zeros(1,nsample);

figure
hold on

maxval = 0;
minval = realmax;
for k = 1:nsample
 % real unit vectors
 b = randn(n,1);
 b = b / norm(b);
 Ab = A * b;
 value = abs(b' * Ab) / norm(Ab);
 plot([value value],[-0.1 0.1],'b')
 maxval = max(maxval,value);
 minval = min(minval,value);
 val(k) = value;
end

% plot

plot([1 1],[-0.1 0.1],'g')
title(['max = ' num2str(maxval) ', min = ' num2str(minval)])

axis([-0.1 1.1 -0.2 0.2])
%axis square

hold off

figure
x = linspace(0,1,20);
hist(val,20)
%hist(val,x)

