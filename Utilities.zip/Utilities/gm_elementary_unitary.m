function G = gm_elementary_unitary(j,gam);
%GM_ELEMENTARY_UNITARY elementary unitary matrix

% Iput:
% j = index for the construction of G_j
% gam = Schur parameters

%
% Author G. Meurant
% December 2023
%

n = length(gam);
if j > n
 error('gm_elementary_unitary: j must be smaller than or equal to the size of gam')
end % if

sig = sqrt(1 - abs(gam(1:n-1)).^2);

G = eye(n);

if j == n
 G(n,n) = -gam(n);
else
 G(j:j+1,j:j+1) = [-gam(j) sig(j); sig(j) conj(gam(j))];
end % if j


