function [V,R,dotprod]=gm_orth_cgs_row(A);
%GM_ORTH_CGS_ROW  orthogonalisation of the columns of A
% Classical Gram-Schmidt by rows

% Input:
% A = matrix
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = upper triangular matrix such that A = V R
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

dotprod = 0;

[m,n] = size(A);
V = A;
R = zeros(n,n);
V = zeros(m,n);

%  orthogonalization

for k = 1:n
 u = A(:,k) - V(:,1:k-1) * R(1:k-1,k);
 nu = norm(u);
 dotprod = dotprod + 1;
 
 if nu <= 1e-15
  fprintf('\n gm_orth_cgs_row: Breakdown, step %d \n\n',k)
  return
 end
 
 R(k,k) = nu;
 V(:,k) = u / nu;
 R(k,k+1:n) = V(:,k)' * A(:,k+1:n);
 dotprod = dotprod + n - k;
 
 
end % for k





