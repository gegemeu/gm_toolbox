function B = gm_vpc(A)
%GM_VPC better version of vpa
%
%   ... convert a matrix in double to vpa
%
[n,m] = size(A);
B = vpa(zeros(n,m));

for i=1:n,
    for j=1:m,                
        B(i,j) = vpa(num2str(A(i,j),'%0.16e'));
    end
end;        

