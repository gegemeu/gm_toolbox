function B = gm_vpc(A)
%GM_VPC a better version of vpa

% From P. Tichy

% convert a matrix in double to vpa

[n,m] = size(A);
B = vpa(zeros(n,m));

for i=1:n,
 for j=1:m,
  B(i,j) = vpa(num2str(A(i,j),'%0.16e'));
 end
end;

