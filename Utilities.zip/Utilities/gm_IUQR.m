function [gam,sig]=gm_IUQR(lambda,w);
%GM_IUQR  computes the Schur parameters
% Inverse Unitary QR algorithm by Ammar, Gragg and Reichel

% version of H. Fassbender (Num Math 1997)

% Input:
% lambda = eigenvalues
% w = weights
%
% Output:
% gam, sigma = Schur parameters

%
% Author G. Meurant
% June 2012
% Updated Sept 2015
%

if any(w) < 0
 error('gm_IUQR: The weights must be positive')
end

n = length(lambda);
v = sqrt(w);
m = length(lambda);
gam = zeros(m,1);
sig = zeros(m-1,1);

sig0 = v(1);
gam(1) = -lambda(1);

for i = 2:n
 sig_old = sig0;
 sig0 = sqrt(sig_old^2 + w(i));
 beta = sig_old / sig0;
 alpha = -v(i) / sig0;
 gam(i) = -lambda(i) * gam(i-1);
 
 for k = 1:i-1
  sig_old = sig(k);
  gam_old = gam(k);
  sig(k) = beta * sqrt(sig_old^2 + abs(alpha + gam(k) * conj(alpha) * lambda(i)^(k-2))^2);
  gam(k) = beta^2 * gam(k) - conj(lambda(i))^(k-2) * alpha^2;
  alpha = beta * lambda(i) * (alpha + gam_old * lambda(i)^(k-2) * conj(alpha)) / sig(k);
  beta = beta * sig_old / sig(k);
 end % for k
 
end % for i



