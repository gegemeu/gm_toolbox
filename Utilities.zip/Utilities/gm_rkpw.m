function [a,b] = gm_rkpw(x,y);
%GM_RKPW Kahan Pal Walker procedure, inverse eigenvalue problem

% Input:
% x = nodes
% y = weights, sum(w) = 1
%
% Output:
% a = diagonal entries of the tridiagonal matrix
% b = subdiagonal entries

%
%    The script is adapted from the routine RKPW in
%    W.B. Gragg and W.J. Harrod, ``The numerically stable
%    reconstruction of Jacobi matrices from spectral data'',
%    Numer. Math. 44 (1984), 317-335.
%

%
% Authors G. Meurant and P. Tichy
% April 2024
%

x = x(:);
n = size(x,1);

for k = 1:n-1
 X = x(k+1);
 Y = y(k+1);
 y(k+1) = 0;
 gam = 1;
 sig = 0;
 t = 0;
 
 for i = 1:k+1
  yi = y(i);
  rho = y(i) + Y;
  y(i) = gam * rho;
  tsig = sig;
  if double(rho) <= 0
   gam = 1;
   sig = 0;
   dx = 2 * t;
   t = -t;
  else
   gam = yi / rho;
   sig = Y / rho;
   tk = sig * (x(i) - X) - gam * t;
   dx = t - tk;
   t = tk;
  end % if
  
  x(i) = x(i) + dx;
  
  if double(sig) <= 0
   Y = tsig * yi;
  else
   Y = t^2 / sig;
  end % if
 end % for i
end % for k
a = transpose(x);
b = sqrt(y(1,2:n));


