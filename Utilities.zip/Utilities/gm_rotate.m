function [xr,yr] = gm_rotate(x,y,theta);
%GM_ROTATE rotates a set of points in the plane

% center of rotation at the origin

% Input:
% x,y = coordinates of the points
% theta = angle of rotation (radians) clockwise
%
% Output:
% xr,yr = coordinates of the rotated points


%
% Author G. Meurant
% April 2017
%

nx = length(x);
xr = zeros(nx,1);
yr = zeros(nx,1);
y = y(1:nx);

% matrix of rotation
c = cos(theta);
s = sin(theta);
% R = [c s; -s c];

xr = c * x + s * y;
yr = -s * x + c *y;

