function A = gm_rhb(filename,iprint)
%GM_RHB reads a Harwell-Boeing file 

%
% Author G. Meurant
%

[fid,mess] = fopen(filename,'r');
title = fscanf(fid,'%c',72);

key = fscanf(fid,'%c',8);

totcrd = fscanf(fid,'%i',1);
ptrcrd = fscanf(fid,'%i',1);
indcrd = fscanf(fid,'%i',1);
valcrd = fscanf(fid,'%i',1);
rhscrd = fscanf(fid,'%i',1);
void = fscanf(fid,'%c',10);

typ = fscanf(fid,'%3c',1);
void = fscanf(fid,'%c',11);
m = fscanf(fid,'%i',1);
n = fscanf(fid,'%i',1);
nnz = fscanf(fid,'%i',1);
neltvl = fscanf(fid,'%i',1);
void = fscanf(fid,'%c',10);
 
ptrfmt = fscanf(fid,'%c',16);
indfmt = fscanf(fid,'%c',16);
valfmt = fscanf(fid,'%c',20);
rhsfmt = fscanf(fid,'%c',20);
void = fscanf(fid,'%c',8);
 
% add test rhs
 
rhstype = 'NUN';
nrhs = 0;
nnzrhs = 0;
%
for i = 1:n+1
 ja(i) = fscanf(fid,'%i4',1);
end
ja = ja';
 
ia = fscanf(fid,'%i4',nnz);
 
% read the values
 
val = fscanf(fid,'%e',nnz);

% find row and column indices

b = zeros(nnz,2);
l = 1;

for i = 1:n
 len = ja(i+1) - ja(i);
 b(l:l+len-1,1) = i * ones(len,1);
 b(l:l+len-1,2) = ia(l:l+len-1);
 l=l+len;
end

A=sparse(b(:,1),b(:,2),val,n,n,nnz);

if iprint == 1
 [rows,cols,entries,field,symm] = gm_mat_infoA(A,iprint);
end

fc = fclose(fid);
