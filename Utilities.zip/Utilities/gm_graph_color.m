function [ncolor,color]=gm_graph_color(A);
%GM_GRAPH_COLOR colors the graph of A
%
% 2 nodes which are linked in the graph of a must not have the same color
% SDO algorithm (see Jones and Plassmann)
% this is a sequential algorithm
%
% ncolor = number of colors
% color  = color of the nodes of the graph
%

%
% Author G. Meurant
% Feb 2009
%

n = size(A,1);

color = zeros(n,1);
A = A - diag(diag(A));

ncolor = 1;
color(1) = 1;
% color the first node

% colors already used
colors = [1];
% number of colored nodes
ncol = 1;
% front of nodes with uncolored neighbours
front = [1];

while ncol < n
 % find the neighbours of the already colored nodes (in the front) with uncolored neighbours
 nfront = length(front);
 indcol = [];
 for jj = 1:nfront
  j = front(jj);
  ind = gm_neighb1(A,j);
  list = find(color(ind) == 0);
  indcol = gm_unique([indcol ind(list)]);
 end
 indcol = sort(indcol);

 maxk = 0;
 maxcol = 0;
 % for all the neighbours
 for kk =1:length(indcol);
  k= indcol(kk);
  % find the number of colors to which k is connected in the graph
  indk = gm_neighb1(A,k);
  nbcolor = 0;
  if length(indk) ~= 0
   col = color(indk);
   % remove the zeros
   ind = find(col);
   col = col(ind);
   nbcolor = length(col);
  end
  if nbcolor > maxcol
   maxcol = nbcolor;
   maxk = k;
  end
 end % for k

 % choose the node in ind with the maximum number of adjacent colors
 % the winner is maxk;
 % give it the smallest available color
 % colors of the neighbours of maxk
 indk = gm_neighb1(A,maxk);
 colk = unique(color(indk));
 colk = gm_setdiff(colk,[0]);
 if length(colk) == ncolor
  % all the previous colors are used, use a new one
  ncolor = ncolor + 1;
  color(maxk) = ncolor;
  colors = [colors ncolor];
  ncol = ncol + 1;
 else
  % find the smallest available color
  acol = gm_setdiff(colors,colk);
  acol = sort(acol);
  color(maxk) = acol(1);
  ncol = ncol + 1;
 end
 
 % add maxk to the front and see if there are nodes to remove
 front = [front maxk];
 % check if all the neighbours are colored
 rem = [];
 for kk = 1:length(front)
  k = front(kk);
  % get the neighbours of k
  indk = gm_neighb1(A,k);
  co = color(indk);
  ico = find(co == 0);
  if length(ico) == 0
   % all the neighbours are colored, remove k from the front
   rem = [rem k];
  end % if
 end % for kk
 % physically remove the nodes
 front = gm_setdiff(front,rem);
   
end % while





