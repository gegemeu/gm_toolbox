function north=gm_plot_orth(V);
%GM_PLOT_ORTH deviation form orthonormality

% This can be used to see how an orthonormal basis is loosing linear
% orthogonality

% Input:
% V = matrix
%
% Output:
% north = norm(I - V' V)

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

m = size(V,2);
north = zeros(1,m);

for k = 1:m
 north(k) = norm(eye(k,k) - V(:,1:k)' * V(:,1:k));
end

semilogy(north)
title('norm(I_k - V_k^T V_k)')
