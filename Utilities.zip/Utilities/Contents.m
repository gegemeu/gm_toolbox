% UTILITIES

% Miscellaneous functions
%
% Files
%   gm_2sum                     - summation of a and b
%   gm_add_column_QR            - updates QR decomposition when a new column is added
%   gm_add_row_QR               - updates QR decomposition when adding a row
%   gm_all_combi                - all combinations of n elements k by k (ordered)
%   gm_Anormcol                 - A-norms of the columns of B
%   gm_anti_eye                 - anti-diagonal matrix
%   gm_apply_house              - applies the Householder reflections contained in V, bet to x
%   gm_apply_house_rev          - applies the Householder reflections contained in V, bet to x (reverse order)
%   gm_ApproxTwoDiv             - computes the division a / b and an approximate rounding error
%   gm_best_ellipse             - best enclosing ellipse for a set of 2D points
%   gm_bgssro                   - block Gram-Schmidt orthogonalization
%   gm_bin2frac                 - converts the input array to a double fractional part
%   gm_binary                   - binary form of a floating-point number
%   gm_cbar                     - bar visualization of real eigenvalues
%   gm_cbar2                    - bar visualization of two sets of real data on the same scale
%   gm_cbarn                    - bar visualization of n sets of real data on the same scale for comparison
%   gm_cbarnpart                - partial bar visualization of n sets of real data on the same scale for comparison witha window
%   gm_charpol_H                - characteristic polynomial of an upper Hessenber matrix
%   gm_charpol_H_Ui             - characteristic polynomial of an upper Hessenberg matrix
%   gm_chebyshev                - Chebyshev polynomials applied to a vector
%   gm_check_ineq               - solution of linear inequalities
%   gm_chg1m1ab                 - change of coordinate from x in [-1,1] to y in [a,b]
%   gm_chgab1m1                 - change of coordinate from x in [a,b] to y in [-1,1]
%   gm_chlsky                   - auxiliary function for Crawford-Moon algorithm
%   gm_circle_from_3_points     - center and radius of a circle from 3 points
%   gm_clearallfig              - clears all current figures
%   gm_Cnk                      - number of combinations C^n_k
%   gm_comp_tuples              - finds the tuples which are in P and Q
%   gm_companion                - construction of the companion matrix from the vector alp
%   gm_companion_eig            - construction of the companion matrix from the eigenvalues
%   gm_companion_matrix         - companion matrix of A
%   gm_companionmat             - companion matrix of the eigenvalues eigA
%   gm_compare_vec              - norms of the differences of the columns of V and X
%   gm_compare_vecb             - norms of the differences of the columns of V and X
%   gm_compr                    - compress a list of integers by deleting extra copies of elements
%   gm_compsum                  - compensated summation of the elements of a vector x
%   gm_compsum_sort             - compensated summation of the elements of a vector x with a sort
%   gm_compzer1                 - eliminates the zeroes in list and compress
%   gm_count                    - number of different (by epsi) components in vector a
%   gm_Crawford_Moon            - Crawford-Moon algorithm for finding s = [s_1 s_2] such that s_1 A + s_2 B is definite
%   gm_cubic                    - solution of a cubic equation
%   gm_cubic_gen                - solution of a general cubic equation
%   gm_cumprod_diffs2           - product of |x(j)-x(i)|^2 for all pairs i<j
%   gm_departure_from_normality - computes two measures of the departure from normality
%   gm_diagonal_scaling         - symmetrically scales the matrix A
%   gm_draw_circle              - draws a circle of center [cx,cy] and radius r with n points
%   gm_draw_ellipse             - draws an ellipse of center [cx,cy] with semi-axes a and b with n points
%   gm_eig_unitary              - generation of n random points on the unit circle
%   gm_elem_symm_func           - elementary symmetric function of k values 
%   gm_elementary_unitary       - elementary unitary matrix
%   gm_f_circle                 - draws the image of the unit circle with n points
%   gm_filmat1                  - filters the matrix A 
%   gm_filmatr                  - filters the matrix A 
%   gm_find_loc_max             - finds the local maxima in A
%   gm_fmt                      - for two lists of integers computes f \ t
%   gm_fmtb                     - for two lists of integers computes f \ t
%   gm_fov_real_scaled          - random estimation of the real scaled field of values
%   gm_fov_scaled               - random estimation of the scaled field of values
%   gm_fvmod                    - field of values (or numerical range) of B and powers
%   gm_fvmod_noax               - field of values (or numerical range) of B and powers
%   gm_g_gamma                  - utility function
%   gm_Gauss_Radau_remainder_vp - analytic formula for the Gauss-Radau remainder with gm_vpc
%   gm_Gauss_remainder_vp       - analytic formula for the Gauss remainder with gm_vpc
%   gm_geomspace                - geometric sequence of n points between a and b
%   gm_gerschgo                 - computes the Gerschgorin bounds for a symmetric matrix A
%   gm_gfov                     - plot of the generalized field of values of A1 and A2
%   gm_givens                   - computes Givens rotation to zero b in [a; b]
%   gm_givens_comp              - computes Givens rotation to zero b in [a; b]
%   gm_gmesh                    - coordinates of the nodes for an m x m mesh on the unit square
%   gm_grand                    - generates the coordinates of the nodes for a random mesh on the unit square
%   gm_graph_color              - colors the graph of A
%   gm_graph_color1             - colors the graph of A
%   gm_graph_colorb             - colors the graph of A
%   gm_Hessp                    - Hessenberg form with a positive subdiagonal
%   gm_house                    - Householder transformation to zero components 2 to n of x
%   gm_household                - Householder transformation to zero components m to n of x
%   gm_housg                    - generalized Householder transformation
%   gm_ieee754                  - decomposes a double precision floating point number
%   gm_ieee754s                 - decomposes a single precision floating point number
%   gm_interlaced_val           - returns interlaced values
%   gm_inters                   - computes intersection of two lists of integers
%   gm_intersect                - set intersection
%   gm_inv_companion_matrix     - inverse of a companion matrix
%   gm_inv_mod_trid             - inverse of a modified Toeplitz tridiagonal matrix
%   gm_invperm                  - inverse permutation of perm
%   gm_invT_from_gamma          - computes the inverse of T_k from G and g
%   gm_is_diag_dom              - answers the question: is A row diagonally dominant?
%   gm_IUHQR                    - inverse unitary Hessenberg eigenvalue problem
%   gm_IUQR                     - computes the Schur parameters
%   gm_last_comp_squared        - last components of the eigenvectors of T_k
%   gm_last_comp_squared_vp     - last components of the eigenvectors of T_k
%   gm_latexmat                 - converts a Matlab matrix into a LaTeX pmatrix environment
%   gm_latexmat_sparse          - converts a Matlab matrix into a LaTeX pmatrix environment
%   gm_latextab                 - converts a Matlab matrix into a LaTeX tabular environment
%   gm_leja_ord                 - Leja order of the first n components of the vector x
%   gm_leja_points              - computes the first n Leja points in [-2,2]
%   gm_leja_shift               - shifted Leja points on [a,b]
%   gm_licols                   - extracts a linearly independent set of columns of a given matrix X
%   gm_lin_comb_PC              - PC algorithm for finding a positive definite linear combination of symmetric matrices A_1, ..., A_k
%   gm_lin_comb_PDC             - PDC algorithm for finding a positive definite linear combination of A_1, ..., A_k
%   gm_make_diag_dom            - shifts the diagonal to make A diagonally dominant
%   gm_make_full_rank           - changes the smallest singular values of A to make it full rank
%   gm_mat_info                 - informations about a matrix MAT file
%   gm_mat_infoA                - informations about a matrix A
%   gm_matmult                  - matrix-matrix multiplication timing
%   gm_matvec                   - matrix-vector multiplication timing
%   gm_maxnzpr                  - maximum number of non zeros per row of A
%   gm_meshpq                   - coordinates of a p x q mesh of the unit square
%   gm_meshq                    - from a 1D mesh with n elements to a 2D mesh with n = m x m
%   gm_meshsq                   - coordinates of an m x m mesh of the unit square
%   gm_meshsquare               - sets up a quadrilateral mesh
%   gm_mgfilt                   - filters the matrix A with a criteria different from gm_filmatr
%   gm_min_dist_eig             - minimum distances to a given eigenvalue
%   gm_min_dist_eig_vp          - minimum distances to a given eigenvalue with gm_vpc
%   gm_minnzpr                  - minimum number of non zeros per row of A
%   gm_minnzprl                 - minimum number of non zeros per row of the lower triangular part of A
%   gm_mmask                    - creates a sparse matrix with the values of A and the pattern of B 
%   gm_mminfo                   - informations about a Matrix Market file
%   gm_mmread                   - reads a Matrix Market file
%   gm_mmwrite                  - writes a Matrix Market file
%   gm_mom_Gersch_normal        - Gerschgorin-like regions for Arnoldi Ritz values for a normal matrix
%   gm_momat2                   - moment matrices from the eigenvalues and the projections on the eigenvectors
%   gm_moment2                  - moment matrices for A normal
%   gm_msing_Fas                - estimates of the minimum singular values of V_k
%   gm_msing_secul              - estimates of the minimum singular values of V_k
%   gm_mycolorbar               - displays a vertical color bar (color scale)
%   gm_next_tuple               - returns the next item in all the possible combinations
%   gm_nivorth                  - computes the level of orthogonality of a set of vectors
%   gm_nnzperrow                - computes the max number of non zeros per row
%   gm_norm_Sk                  - estimate of the norm of S_k from Paige with INE
%   gm_normaliz                 - symmetrically scales the matrix A with 1's on the diagonal
%   gm_normcol                  - norms of the columns of A
%   gm_num2tex                  - converts a floating point number to a string in TeX format
%   gm_orth_cgs                 - (double) orthogonalisation of the columns of A, classical Gram-Schmidt
%   gm_orth_cgs_col             - (double) orthogonalisation of the columns of A, classical Gram-Schmidt by columns
%   gm_orth_cgs_row             - orthogonalisation of the columns of A
%   gm_orth_cgsR                - orthogonalisation of the columns of A
%   gm_orth_cgsR2               - orthogonalisation of the columns of A
%   gm_orth_mgs                 - (double) orthogonalisation of the columns of A
%   gm_orth_mgs_col             - (double) orthogonalisation of the columns of A
%   gm_orth_mgs_rank            - orthogonalisation of the columns of A with pivoting
%   gm_orth_mgs_row             - orthogonalisation of the columns of A, modified Gram-Schmidt by rows
%   gm_orth_Popa                - iterative orthogonalization, method of Popa and Petcu
%   gm_orthog                   - keep only the most significant columns in V
%   gm_Paige_S                  - computes the augmented unitary matrix exhibited by Paige
%   gm_pftoqd                   - computes the augmented QD row of a partial fraction given by the points t and the weights w
%   gm_plot                     - plot of different curves
%   gm_plot_all_Ritzval         - plot of the eigenvalues and all the Ritz values on one plot
%   gm_plot_cond                - plots the condition number of A(:,1:k), k=1:m
%   gm_plot_curves              - a plotting function for a given data
%   gm_plot_log10_curves        - a plotting function for the log10 of data
%   gm_plot_matmult             - computing speed of the matrix-matrix multiply
%   gm_plot_min_sing            - minimum singular values of V(:,1:k)
%   gm_plot_norm_Sk             - norm of S_k from Paige and its estimate with INE
%   gm_plot_orth                - deviation form orthonormality
%   gm_plot_orth2               - deviation form orthonormality
%   gm_plot_rank                - plots the rank of A(:,1:k), k=1:m
%   gm_plot_Ritz                - plot of the eigenvalues of A and Ritz values given by H at each iteration
%   gm_plot_tridiag_inv_11      - plot of the (1,1) entries of the inverses of the principal submatrices of a tridiagonal T
%   gm_polar_companion          - polar factorization of a companion matrix C
%   gm_polar_companion_C1       - polar factorization of a companion matrix C1
%   gm_print_rounding_mode      - prints he current rounding mode
%   gm_psa                      - 2-norm pseudospectra of A
%   gm_pseudo_points            - extraction of points from the pseudo spectrum of A
%   gm_qrandn                   - generates a random orthogonal matrix X
%   gm_quartic                  - solution of a quartic equation
%   gm_quartique                - solutions of x^4 + cc(2) x^3 + cc(3) x^2 + cc(4) x + cc(5)
%   gm_rand_decrease            - random positive decreasing sequence
%   gm_rand_sym                 - generates a random symmetric matrix
%   gm_rand_sym_rot             - generates a rotated random symmetric matrix
%   gm_randmesh                 - m^2 random points in the unit square
%   gm_randnn                   - random matrix with unit norm vectors
%   gm_rank_one_approx          - closest rank-one matrix
%   gm_rankV                    - computes the rank as a function of the number of columns in V
%   gm_relax_Agmon              - solve for A x <= b
%   gm_replacetruncval          - put values less than val to val
%   gm_replacezero              - put the true zeros to val
%   gm_rhb                      - reads a Harwell-Boeing file 
%   gm_rhbsymm                  - reads a Harwell-Boeing file and returns a symmetric matrix
%   gm_rkpw                     - Kahan Pal Walker procedure, inverse eigenvalue problem
%   gm_rotate                   - rotates a set of points in the plane
%   gm_round2dp                 - rounds number x to k decimal places
%   gm_semilogy                 - semilogy of different curves
%   gm_set_rounding_mode        - sets the rounding mode
%   gm_setdiff                  - set difference
%   gm_setmcarre                - computes the coefficients of the least squares polynomial of degree k
%   gm_signature                - computes the signature of the permutation p
%   gm_signqr                   - changes signs by putting positive entries on the diagonal of the QR factorization
%   gm_smalldist                - for each element of a finds the smallest distance with elements of b
%   gm_smax_estR                - estimate of the largest singular value of S, Paige's measure of loss of independence
%   gm_smooth_avg               - smoothing a curve by averaging
%   gm_sorteig                  - sorted eigenvalues and eigenvectors of A
%   gm_sparse_2_csr             - Convert a sparse matrix into compressed row storage arrays
%   gm_spline                   - cubic spline interpolation
%   gm_spline_eval              - evaluates a cubic spline
%   gm_Split                    - splits a double precision number in two parts
%   gm_spyval                   - visualizes sparsity pattern of S with colors
%   gm_stagest                  - computes a quantity for the estimation of the maximum accuracy
%   gm_stagestb                 - computes a quantity for the estimation of the maximum accuracy
%   gm_svd_companion            - SVD of a companion matrix C
%   gm_swapcols_mat             - permutes the columns of A, i -> m-i+1
%   gm_swaprows_mat             - permutes the rows of A, i -> n-i+1
%   gm_sym_trid                 - symmetrization of a tridiahonal matrix
%   gm_thumbn_avg               - constructs a matrix at most ktn x ktn for visualization of large matrices by taking the average in a block
%   gm_thumbn_max               - constructs a matrix at most ktn x ktn for visualization of large matrices by taking the max in a block
%   gm_time_dotprod             - dot product timing
%   gm_Toeplitz_asympt_spectrum - asymptotic spectrum of a banded Toeplitz matrix
%   gm_transform_ellipse        - maps the points (xe,ye) to the ellipse of center cx,cy and semi-axes a,b
%   gm_trid_part                - extracts the tridiagonal part of A with spdiags
%   gm_trunc_mat_abs_low        - truncates the matrix A 
%   gm_trunc_mat_abs_up         - truncates the matrix A 
%   gm_trunc_mat_low            - truncates the matrix A 
%   gm_trunc_mat_up             - truncates the matrix A 
%   gm_ts_gs                    - two-sided Gram-Schmidt (bi-)orthogonalization of two sets of vectors
%   gm_ts_mgs                   - two-sided Gram-Schmidt (bi-)orthogonalization of two sets of vectors
%   gm_TwoProd                  - computes the product of a and b and its rounding error
%   gm_TwoSum                   - computes the sum of a and b and its rounding error
%   gm_ulp                      - unit in the last place
%   gm_unique                   - removes the repetitions in an array
%   gm_unmesh                   - converts a two dimensional array into a one dimensional array
%   gm_upd_msing_Fas            - update of the estimate of the minimum singular value
%   gm_upd_msing_secul          - update of the estimate of the minimum singular value using the secular equation
%   gm_upd_msingL               - update of the estimate of the minimum singular value of R=L'
%   gm_V_angles                 - angles between the columns of V
%   gm_V_unit_norm              - normalization of the columns of V
%   gm_vecmat                   - vectorization of the matrix A
%   gm_vecsetmat                - vectorization of a set of matrices A(:,:,k), k=1,...
%   gm_verifdd                  - checks if A is diagonally dominant
%   gm_vizmat                   - visualization of a matrix as a rectangular mesh
%   gm_vizmat_sparse            - visualization of a sparse matrix as a rectangular mesh
%   gm_vizmatjet                - visualization of a matrix as a rectangular mesh
%   gm_vpc                      - a better version of vpa
