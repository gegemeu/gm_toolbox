function ip = gm_invperm(perm);
%GM_INVPERM inverse permutation of perm

%
% Author G. Meurant
% 2000
% Updated April 2015
%

n = length(perm);

in = [1:n];
ip = perm;
ip(perm) = in;

