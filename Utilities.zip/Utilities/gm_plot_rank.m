function rA=gm_plot_rank(A);
%GM_PLOT_RANK plots the rank of A(:,1:k), k=1:m

% Input:
% A = matrix

%
% Author G. Meurant
% August 2015
%

[n,m] = size(A);
rA = zeros(1,m);

for k = 1:m
 rA(k) = rank(A(:,1:k));
end

maxrA = max(rA);

plot(rA);
axis([0 m 0 maxrA+5])

