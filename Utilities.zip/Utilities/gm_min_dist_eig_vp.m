function lmin = gm_min_dist_eig_vp(eigA,T,neig,dig,Tvp,eigvp);
%GM_MIN_DIST_EIG_VP minimum distances to a given eigenvalue with gm_vpc

% variable precision
%
% T is the Lanczos tridiagonal matrix
% neig is the number of the eigenvalue in eigA (vector of eigenvalues)
%
%
% Author G. Meurant
% Sept 2019
%

dig_old = digits;
digits(dig);
% l = gm_vpc(eigA);
l = eigvp;
n = length(eigA);
kmax = size(T,1);
lmin = zeros(kmax,1);
lmin = vpa(lmin);
% T = gm_vpc(T);
T = Tvp;

for k = 1:kmax
 Tk = T(1:k,1:k);
 vptk = sort(eig(full(Tk)));
 lmin(k) = min(abs(vptk - l(neig)));
end % for k

mlmin = min(lmin)
double(mlmin)

lmin = double(lmin);

figure
plot(log10(lmin))
title(['minimum distance to ' num2str(neig) ', dig = ' num2str(dig)])

digits(dig_old);




