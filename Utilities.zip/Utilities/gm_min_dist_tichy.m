function gm_min_dist_tichy(eigA,b,T);
%GM_MIN_DIST_TICHY minimum distances to the three largest eigenvalues
% in the model problem problem with a cluster of 3 eigenvalues
%
% b is the projection of the initial Lanczos vector on the eigenvectors
% of A
% T is the Lanczos tridiagonal matrix
%
%
% Author G. Meurant
% Sept 2019
%

l = eigA;
n = length(eigA);
% max eigenvalue
ln = l(n);
ln1 = l(n-1);
ln2 = l(n-2);
ln3 = l(n-3);
b = b / norm(b);
lav = (ln * b(n)^2 + ln1 * b(n-1)^2 + ln2 * b(n-2)^2) / (b(n)^2 + b(n-1)^2 + b(n-2)^2)
lav1 = (ln2 * b(n-2)^2 + ln1*b(n-1)^2) / (b(n-2)^2 + b(n-1)^2)
lnav = ln-lav

kmax = size(T,1);
lmin = zeros(kmax,1);
lmin1 = lmin;
lmin2 = lmin;
lminav = lmin;
lminav1 = lmin;
lk = lmin;
lkm1 = lmin;
lkm2 = lmin;
lkm3 = lmin;

for k = 1:kmax
 Tk = T(1:k,1:k);
 vptk = sort(eig(full(Tk)));
 lmin(k) = min(abs(vptk - ln));
 lmin1(k) = min(abs(vptk - ln1));
 lmin2(k) = min(abs(vptk - ln2));
 lminav(k) = min(abs(vptk - lav));
 lminav1(k) = min(abs(vptk - lav1));
 lk(k) = abs(vptk(k) - ln);
 %   [k vptk(k) ln-vptk(k) lav-vptk(k)]
 if k > 1
  lkm1(k) = abs(vptk(k-1) - ln1);
  %    [k vptk(k-1) ln1-vptk(k-1) lav1-vptk(k-1)]
 end
 if k > 2
  lkm2(k) = abs(vptk(k-2) - ln2);
  %    [k vptk(k-2) ln2-vptk(k-2)]
 end
 %[k ln-vptk(k) ln1-vptk(k)]
 if k > 2
  lkm3(k) = min(abs(vptk-ln3));
  %[k ln2-vptk(k-1) ln2-vptk(k-2)]
 end
end
lkm1(1) = lkm1(2);

figure
plot(log10(lmin))
hold on
plot(log10(lmin1),'--')
plot(log10(lminav),'r-.')
plot(log10(lmin2),':')
plot(log10(lminav1),'.')
legend('min ln','min l n-1','min l av','min l n-2','min l av1')
title('minimum distances')
hold off

figure
plot(log10(lk))
hold on
plot(log10(lkm1),'--')
plot(log10(lkm2),'-.')
legend('k','k-1','k-2')
hold off

figure
plot(log10(lkm3))



