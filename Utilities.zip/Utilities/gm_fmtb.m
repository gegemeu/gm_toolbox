function ft = gm_fmtb(f,t);
%GM_FMTB for two lists of integers computes f \ t
% 

%
% Author G. Meurant
% December 2001
%

if length(f) == 0
 ft = f;
 return
end

nt = length(t);
if nt == 0
 ft = f;
 return
end

ft = f;
for i = 1:nt
 ind = find(ft ~= t(i));
 if length(ind) ~= 0
  ft = ft(ind);
 end
end

