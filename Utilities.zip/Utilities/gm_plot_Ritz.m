function [eigH,Ritz,eigA] = gm_plot_Ritz(A,H);
%GM_PLOT_RITZ plot of the eigenvalues of A and Ritz values given by H at each iteration

% Input:
% A = nonsymmetric matrix whose eigenvalues are sought
% H = upper Hessenberg matrix from Arnoldi
%
% Output:
% eigH = eigenvalues of H
% Ritz = upper triangular matrix with the Ritz values in columns
% eigA = eigenvalues of A
%

%
% Author G. Meurant
% December 2011
% Updated April 2015
%

eigA = eig(full(A));

H = full(H);
eigH = eig(H);

n = size(H,1);

Ritz = zeros(n,n);

gm_clearallfig

for k = 1:n
 plot(real(eigA),imag(eigA),'ro')
 title(['iteration ' num2str(k)])
 hold on
 muu = eig(H(1:k,1:k));
 Ritz(1:k,k) = muu;
 if mod(k,2) == 0
  plot(real(muu),imag(muu),'b+')
 else
  plot(real(muu),imag(muu),'g+')
 end
 hold off
 pause
end

