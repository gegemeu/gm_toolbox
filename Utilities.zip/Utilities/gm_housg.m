function P = gm_housg(x,y);
%GM_HOUSG generalized Householder transformation

% Orthogonal transformation P such that P x = y
% x and y being vectors of the same length

%
% Author G. Meurant
%

x = x(:);
y = y(:);
if size(x,1) ~= size(y,1)
 error('gm_housg: vectors x and y must be of the same length')
end

nx = norm(x);
ny = norm(y);
al = -nx / ny;
n = length(x);
v = x + al * y;
vtv = v' * v;
PP = speye(n) - 2 * (v * v') / vtv;
P = ny * PP / nx;