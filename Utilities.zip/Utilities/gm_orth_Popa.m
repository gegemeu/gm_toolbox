function [V,nit,dotprod] = gm_orth_Popa(A,epsi,nitmax);
%GM_ORTH_POPA iterative orthogonalization, method of Popa and Petcu

% Input:
% A = matrix n x m
% epsi = convergence threshold
% nitmax = maximum number of iterations
%
% Output:
% V = orthogonal matrix
% nit = number of iterations
% dotprod = number of dot products

dV = realmax;
nit = 0;
dotprod = 0;
n = size(A,1);
n2 = n^2;
I = eye(n,n);
alpha = 0.5;
nA = norm(A,1);
V = A / nA;

while dV > epsi && nit <= nitmax
 
 nit = nit + 1;
 
 VV = V * V';
 dotprod = dotprod + n2;
 
 K = (I - VV) * (I - alpha * VV);
 V_new = (I + K) * V;
 
 dV = norm(V_new - V,1) / norm(V,1);
 
 V = V_new;

end % while

V = nA * V;

