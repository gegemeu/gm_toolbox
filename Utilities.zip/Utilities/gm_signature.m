function s=gm_signature(p)
%GM_SIGNATURE computes the signature of the permutation p

% Input:
% p = permutation vector
%
% Output:
% s = signature of the permutation

n = length(p);
q = p;
s = 1;

for i=1:n
 while q(i) ~= i
  t = q(i);
  q(i) = q(q(i));
  q(t) = t;
  s = -s;
 end
end
