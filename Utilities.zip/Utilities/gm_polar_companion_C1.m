function [W,S] = gm_polar_companion_C1(C);
%GM_POLAR_COMPANION_C1 polar factorization of a companion matrix C1

% the coefficients of the polynomial are in the last row

% 
% Author G. Meurant
% December 2023
%

n = size(C,1);
a = C(n,:)';
a0 = a(1);
ah = a(2:n);

betas = (abs(a0) + 1)^2 + norm(ah)^2;
beta = sqrt(betas);

S = (1 / beta) * [ beta * eye(n-1,n-1) - (1 / (beta + abs(a0) + 1)) * (ah * ah'), ah; ...
 ah', betas - abs(a0) - 1];

v = (a0 / (abs(a0) * beta)) * [ -ah; abs(a0) + 1];

W = [v S(:,1:n-1)];

