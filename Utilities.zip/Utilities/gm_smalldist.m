function c=gm_smalldist(a,b);
%GM_SMALLDIST for each element of a finds the smallest distance with elements of b
% elements of b, a and b vectors

%
% Author G. Meurant
% april 2004
%

na = length(a);
c = zeros(na,1);

for i = 1:length(a)
 [ma,ii] = min(abs(a(i) - b));
 c(i) = abs(a(i) - b(ii));
end
