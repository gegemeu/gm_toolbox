function B = gm_trunc_mat_abs_up(A,alp);
%GM_TRUNC_MAT_ABS_UP truncates the matrix A 

% All the entries whose modulus are larger than alp are set to +- alp

%
% Author G. Meurant
% January 2012
% Updated September 2015
%

alp = abs(alp);

n = size(A,1);

B = A;

for i = 1:n
 ind = find(A(i,:) > alp);
 B(i,ind) = alp;
 ind = find(-A(i,:) > alp);
 B(i,ind) = -alp;
end

