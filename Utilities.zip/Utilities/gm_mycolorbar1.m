function handle=gm_mycolorbar1(umin,umax)
%GM_MYCOLORBAR1 displays a vertical color bar (color scale)
% corresponding to the current colormap

% umin, umax min and max of the values to be displayed

% this does not work any longer 

%
% modifed by G. Meurant
% March 2003
% Updated May 2015
%

narg = nargin;

% when this is done doing whatever it does
% gcf and gca should be what they were when we got here
% so get them now

GCF = gcf;
GCA = gca;

loc = 'vert';

% Catch colorbar('delete') special case -- must be called by the deleteFcn.
if narg==1 & strcmp(loc,'delete')
 ax = gcbo;
 %
 % If called from ColorbarDeleteProxy, delete the colorbar axes
 %
 if strcmp(get(ax,'tag'),'ColorbarDeleteProxy')
  cbo = ax;
  ax = get(cbo,'userdata');
  if ishandle(ax)
   ud = get(ax,'userdata');
   
   % Do a sanity check before deleting colorbar
   if isfield(ud,'ColorbarDeleteProxy') & ...
     isequal(ud.ColorbarDeleteProxy,cbo) & ...
     ishandle(ax)
    try
     delete(ax)
    end
   end
  end
 else
  %
  % If called from the colorbar image resize the original axes
  %
  if strcmp(get(ax,'tag'),'TMW_COLORBAR')
   ax=get(ax,'parent');
  end
  
  ud = get(ax,'userdata');
  if isfield(ud,'PlotHandle') & ...
    ishandle(ud.PlotHandle) & ...
    isfield(ud,'origPos') & ...
    ~isempty(ud.origPos)
   
   % Get position and orientation of colorbar being deleted
   delpos = get(ax,'Position');
   if delpos(3)<delpos(4)
    delloc = 'vert';
   else
    delloc = 'horiz';
   end
   
   % Search figure for existing colorbars
   % If one is found with the same plothandle but that is not
   % the same colorbar as the one being deleted
   % Get its position and orientation
   otherloc = '';
   otherpos = [];
   othercbar = [];
   phch = get(findall(hfig,'type','image','tag','TMW_COLORBAR'),{'parent'});
   for i=1:length(phch)
    phud = get(phch{i},'userdata');
    if isfield(ud,'PlotHandle') & isfield(phud,'PlotHandle')
     if isequal(ud.PlotHandle,phud.PlotHandle)
      if ~isequal(phch{i},ax)
       othercbar = phch{i};
       otherpos = get(phch{i},'Position');
       if otherpos(3)<otherpos(4)
        otherloc = 'vert';
       else
        otherloc = 'horiz';
       end
       break;
      end
     end
    end
   end
   
   
   % get the current plothandle units
   units = get(ud.PlotHandle,'units');
   % set plothandle units to normalized
   set(ud.PlotHandle,'units','normalized');
   % get current plothandle position
   phpos = get(ud.PlotHandle,'position');
   
   % if the colorbar being deleted is vertical
   % set the plothandle axis width to the original Pos
   % width of the colorbar being deleted
   % if there is another (horizontal) colorbar
   % do the same to that
   if strncmp(delloc,'vert',1)
    phpos(3) = ud.origPos(3);
    set(ud.PlotHandle,'position',phpos);
    if strncmp(otherloc,'horiz',1)
     otherpos(3) = ud.origPos(3);
     set(othercbar,'position',otherpos);
    end
    
    % update legend (which resizes plothandle)
    % only when deleting vertical colorbars
    
    legH=legend(ud.PlotHandle);
    if ~isempty(legH) & ishandle(legH)
     % save size of current plothandle axes with legend ud
     legend('RecordSize',ud.PlotHandle);
     % resize (reposition) legend
     legend('ResizeLegend',legH);
    end
    
    % elseif the colorbar being deleted is horizontal
    % set the plothandle y and height to the original Pos
    % y and height of the colorbar being deleted.
    % if there is another (vertical) colorbar
    % do the same to that
   elseif strncmp(delloc,'horiz',1)
    phpos(4) = ud.origPos(4);
    phpos(2) = ud.origPos(2);
    set(ud.PlotHandle,'position',phpos);
    if strncmp(otherloc,'vert',1)
     otherpos(4) = ud.origPos(4);
     otherpos(2) = ud.origPos(2);
     set(othercbar,'position',otherpos);
    end
    
   end
   
   % restore the plothandle units
   set(ud.PlotHandle,'units',units);
   
   
  end
  
  if isfield(ud,'ColorbarDeleteProxy') & ishandle(ud.ColorbarDeleteProxy)
   try
    delete(ud.ColorbarDeleteProxy)
   end
  end
 end
 % before going, be sure to reset current figure and axes
 set(0,'currentfigure',GCF);
 set(gcf,'currentaxes',GCA);
 return
end

%   If called with COLORBAR(H) or for an existing colorbar, don't change
%   the NextPlot property.

ax = [];
cbarinaxis=0;
if narg==1
 if ishandle(loc)
  ax = loc;
  ud = get(ax,'userdata');
  if isfield(ud,'ColorbarDeleteProxy')
   error('Colorbar cannot be added to another colorbar.')
  end
  if ~strcmp(get(ax,'type'),'axes')
   error('Requires axes handle.');
  end
  
  cbarinaxis=1;
  units = get(ax,'units');
  set(ax,'units','pixels');
  rect = get(ax,'position');
  set(ax,'units',units);
  if rect(3) > rect(4)
   loc = 'horiz';
  else
   loc = 'vert';
  end
 end
end


% the axes handle, shorter name
haxes = gca;
hfig = gcf;
h = haxes;

% Catch attempt to add colorbar to a colorbar or legend
% if the axes h is a colorbar or legend (according to tag)
% reset it to the PlotHandle field of its userdata
tagstr = get(h,'tag');
if strcmpi('Legend',tagstr) | strcmpi('Colorbar',tagstr)
 ud = get(h,'userdata');
 if isfield(ud,'PlotHandle')
  h = ud.PlotHandle;
 else
  % If handle is a dying or mutant colorbar or legend
  % do nothing.
  % but before going, be sure to reset current figure and axes
  set(0,'currentfigure',GCF);
  set(gcf,'currentaxes',GCA);
  return;
 end
end

% Determine color limits by context.  If any axes child is an image
% use scale based on size of colormap, otherwise use current CAXIS.

ch = get(gcda(hfig,h),'children');
hasimage = 0; t = [];
cdatamapping = 'direct';

for i=1:length(ch),
 typ = get(ch(i),'type');
 if strcmp(typ,'image'),
  hasimage = 1;
  cdatamapping = get(ch(i), 'CDataMapping');
 elseif strcmp(typ,'surface') & ...
   strcmp(get(ch(i),'FaceColor'),'texturemap') % Texturemapped surf
  hasimage = 2;
  cdatamapping = get(ch(i), 'CDataMapping');
 elseif strcmp(typ,'patch') | strcmp(typ,'surface')
  cdatamapping = get(ch(i), 'CDataMapping');
 end
end

if ( strcmp(cdatamapping, 'scaled') )
 % Treat images and surfaces alike if cdatamapping == 'scaled'
 t=[umin umax];
 d = (t(2) - t(1))/size(colormap(h),1);
 t = [t(1)+d/2  t(2)-d/2];
else
 if hasimage,
  t = [1, size(colormap(h),1)];
 else
  t = [1.5  size(colormap(h),1)+.5];
 end
end

oldloc = 'none';
oldax = [];
if ~cbarinaxis
 % Search for existing colorbar (parents of TMW_COLORBAR tagged images)
 ch = get(findall(hfig,'type','image','tag','TMW_COLORBAR'),{'parent'});
 ax = [];
 for i=1:length(ch)
  ud = get(ch{i},'userdata');
  d = ud.PlotHandle;
  % if the plothandle (axis) of the colorbar is our axis
  if isequal(d,h)
   pos = get(ch{i},'Position');
   if pos(3)<pos(4)
    oldloc = 'vert';
   else
    oldloc = 'horiz';
   end
   % set ax to the ith colorbar
   % if it's location (orientation) is the same as the
   % new colorbar location (so a second colorbar with
   % the same orientation won't be created, and existing
   % colorbar will be updated
   if strncmp(oldloc,loc,1)
    ax = ch{i};
    % Make sure image deletefcn doesn't trigger a colorbar('delete')
    % for colorbar update - huh?
    set(findall(ax,'type','image'),'deletefcn','')
    break;
   end
  end
 end
end

origNextPlot = get(hfig,'NextPlot');
if strcmp(origNextPlot,'replacechildren') | strcmp(origNextPlot,'replace')
 set(hfig,'NextPlot','add');
end

if loc(1)=='v' % create or refresh vertical colorbar
 
 if isempty(ax)
  % legend('RestoreSize',h); %restore axes to pre-legend size
  units = get(h,'units');
  set(h,'units','normalized');
  pos = get(h,'Position');
  [az,el] = view(h);
  stripe = 0.075; edge = 0.02;
  if all([az,el]==[0 90])
   space = 0.05;
  else
   space = .1;
  end
  set(h,'Position',[pos(1) pos(2) pos(3)*(1-stripe-edge-space) pos(4)]);
  % legend('RecordSize',h); %set this as the new legend fullsize
  
  rect = [pos(1)+(1-stripe-edge)*pos(3) pos(2) stripe*pos(3) pos(4)];
  ud.origPos = pos;
  
  % Create axes for stripe and
  % create ColorbarDeleteProxy object (an invisible text object in
  % the target axes) so that the colorbar will be deleted
  % properly.
  ud.ColorbarDeleteProxy = text('parent',h,...
   'visible','off',...
   'tag','ColorbarDeleteProxy',...
   'HandleVisibility','off',...
   'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))');
  
  axH = graph3d.colorbar('parent',hfig);
  set(axH,'position',rect,'Orientation','vert');
  ax = double(axH);
  
  setappdata(ax,'NonDataObject',[]); % For DATACHILDREN.M
  set(ud.ColorbarDeleteProxy,'userdata',ax)
  set(h,'units',units)
 else
  axH=[];
  ud = get(ax,'userdata');
 end
 
 % Create color stripe
 n = size(colormap(h),1);
 
 img = image([0 1],t,(1:n)',...
  'Parent',ax,...
  'Tag','TMW_COLORBAR',...
  'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))',...
  'SelectionHighlight','off',...
  'HitTest','off');
 
 %set up axes delete function
 set(ax,...
  'Ydir','normal',...
  'YAxisLocation','right',...
  'xtick',[],...
  'tag','Colorbar',...
  'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))');
 
 
elseif loc(1)=='h', % create or refresh horizontal colorbar
 
 if isempty(ax),
  legend('RestoreSize',h); %restore axes to pre-legend size
  units = get(h,'units'); set(h,'units','normalized')
  pos = get(h,'Position');
  stripe = 0.075; space = 0.1;
  set(h,'Position',...
   [pos(1) pos(2)+(stripe+space)*pos(4) pos(3) (1-stripe-space)*pos(4)])
  legend('RecordSize',h); %set this as the new legend fullsize
  rect = [pos(1) pos(2) pos(3) stripe*pos(4)];
  ud.origPos = pos;
  
  % Create axes for stripe and
  % create ColorbarDeleteProxy object (an invisible text object in
  % the target axes) so that the colorbar will be deleted
  % properly.
  ud.ColorbarDeleteProxy = text('parent',h,...
   'visible','off',...
   'tag','ColorbarDeleteProxy',...
   'handlevisibility','off',...
   'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))');
  
  axH = graph3d.colorbar('parent',hfig);
  set(axH,'Orientation','horiz');
  set(axH,'position',rect);
  ax = double(axH);
  
  setappdata(ax,'NonDataObject',[]); % For DATACHILDREN.M
  set(ud.ColorbarDeleteProxy,'userdata',ax)
  set(h,'units',units)
 else
  axH=[];
  ud = get(ax,'userdata');
 end
 
 % Create color stripe
 n = size(colormap(h),1);
 img=image(t,[0 1],(1:n),...
  'Parent',ax,...
  'Tag','TMW_COLORBAR',...
  'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))',...
  'SelectionHighlight','off',...
  'HitTest','off');
 
 % set up axes deletefcn
 set(ax,...
  'Ydir','normal',...
  'Ytick',[],...
  'tag','Colorbar',...
  'deletefcn','colorbar(''delete'',''peer'',get(gcbf,''currentaxes''))')
 
else
 error('COLORBAR expects a handle, ''vert'', or ''horiz'' as input.')
end

if ~isfield(ud,'ColorbarDeleteProxy')
 ud.ColorbarDeleteProxy = [];
end

if ~isfield(ud,'origPos')
 ud.origPos = [];
end

ud.PlotHandle = h;
set(ax,'userdata',ud)
set(hfig,'NextPlot',origNextPlot)

legH=legend(h);
if ~isempty(legH) & ishandle(legH)
 % resize (reposition) legend
 legend('ResizeLegend',legH);
 axes(legH);
end

%make sure annotation layer ends up on top.
plotedit(get(ax,'parent'),'promoteoverlay');

if nargout>0
 handle = ax;
end

% Finally, before going, be sure to reset current figure and axes
set(0,'currentfigure',GCF);
set(gcf,'currentaxes',GCA);

%--------------------------------
function h = gcda(hfig, haxes)
%GCDA Get current data axes

h = datachildren(hfig);
if isempty(h) | any(h == haxes)
 h = haxes;
else
 h = h(1);
end

