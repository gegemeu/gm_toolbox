function [P,Q] = gm_ts_mgs(U,V);
%GM_TS_MGS two-sided Gram-Schmidt (bi-)orthogonalization of two sets of vectors

% modified Gram-Schmidt
% P (resp. Q) spans the same subspace as U (resp. V) and P' Q = I

% Input:
% U, V = matrices (one of them has to be square)
%
% Output:
% P, Q = matrices
%

% Author G. Meurant
% April 2013
% Updated September 2015
%

m = min(size(U,2),size(V,2));
n = size(U,1);

P = zeros(n,m);
Q = zeros(n,m);
om = zeros(1,m);

P(:,1) = U(:,1) / norm(U(:,1));
Q(:,1) = V(:,1) / norm(V(:,1));
om(1) = P(:,1)' * Q(:,1);

for k = 2:m
 q = U(:,k);
 p = V(:,k);
 for j = 1:k-1
  q = q - (P(:,j)' * q / om(j)) * Q(:,j);
  p = p - (Q(:,j)' * p / om(j)) * P(:,j);
  P(:,k) = p / norm(p);
  Q(:,k) = q / norm(q);
  om(k) = P(:,k)' * Q(:,k);
  if abs(om(k)) <= 1e-14
   fprintf('\n gm_ts_mgs: Near breakdown, step %d \n\n',k)
   return
  end
 end
end


  