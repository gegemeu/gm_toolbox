function [c]=gm_intersect(a,b)
%GM_INTERSECT Set intersection
%   INTERSECT(A,B) when A and B are vectors returns the values common
%   to both A and B. The result will be sorted
%
%   INTERSECT(A,B,'rows') when A and B are matrices with the same
%   number of columns returns the rows common to both A and B.
%

numelA = numel(a);
numelB = numel(b);

c = [a([]);b([])];    % Predefined to determine class of output

% Handle scalars: one element

if (numelA == 1)
 % Scalar A: pass to ISMEMBER to determine if A exists in B
 [tf,pos] = ismember(a,b);
 if tf
  c = a;
 end
 return

elseif (numelB == 1)
 % Scalar B: pass to ISMEMBER to determine if B exists in A
 [tf,pos] = ismember(b,a);
 if tf
  c = b;
 end
 return
end

% General handling

% Convert to double arrays, which sort faster than other types

whichclass = class(c);
isdouble = strcmp(whichclass,'double');

if ~isdouble
 if ~strcmp(class(a),'double')
  a = double(a);
 end
 if ~strcmp(class(b),'double')
  b = double(b);
 end
end

% Switch to sort shorter list

if numelA < numelB
 a = sort(a);

 [tf,pos] = ismember(b,a);     % TF lists matches at positions POS

 where = zeros(size(a));       % WHERE holds matching indices
 where(pos(tf)) = find(pos);   % from set B, 0 if unmatched
 tfs = where > 0;              % TFS is logical of WHERE

 % Create intersection list
 c = a(tfs);

else
 b = sort(b);

 [tf,pos] = ismember(a,b);     % TF lists matches at positions POS.

 where = zeros(size(b));       % WHERE holds matching indices
 where(pos(tf)) = find(pos);   % from set B, 0 if unmatched
 tfs = where > 0;              % TFS is logical of WHERE

 % Create intersection list.
 c = b(tfs);

end

% Re-convert to correct output data type using FEVAL
if ~isdouble
 c = feval(whichclass,c);
end
