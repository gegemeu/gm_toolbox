function y=gm_chgab1m1(x,a,b);
%GM_CHGAB1M1 change of coordinate from x in [a,b] to y in [-1,1]
%

%
% Author G. Meurant
% May 2008
%

y = (2 * x - a - b) / (b - a);

