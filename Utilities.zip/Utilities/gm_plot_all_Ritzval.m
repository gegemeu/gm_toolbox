function [V,H,VHs,Rvals,Rvec]=gm_plot_all_Ritzval(A,u,it);
%GM_PLOT_ALL_RITZVAL plot of the eigenvalues and all the Ritz values
% on one plot


%Input:
% A = matrix
% u = starting vector
% it = stepsize for the iterations
%
% Output:
% V= Arnoldi vectors
% H = tridiagonal matrix
% VHs = eigenvectors of H
% Rvals = eigenvalues of H
% Rvec = Ritz vectors

%
% Author G. Meurant
% Oct 2013
% Updated July 2015
%

if nargin < 3
 it = 1;
end

n = size(A,1);

if nargin < 2
 u = randn(n,1);
 u = u / norm(u);
end
 
[V,H,VHs,Rvals,Rvec,res,time_mat] = gm_Arnoldi(A,u,n,'reorth','noprint');
H = full(H);

if it > n-1
 return
end

figure

% field of values
gm_fvmod(A);

hold on

kk = 0;
for k = 1:it:n-1
 kk = kk + 1;
 muu = eig(H(1:k,1:k));
 switch mod(kk,6)
  case 1
   color = 'b+';
  case 2
   color = 'r+';
  case 3
   color = 'g+';
  case 4
   color = 'm+';
  case 5
   color = 'c+';
  otherwise
   color = 'k+';
 end
 plot(real(muu),imag(muu),color)
end

hold off

