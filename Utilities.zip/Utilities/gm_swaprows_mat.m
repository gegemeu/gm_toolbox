function B = gm_swaprows_mat(A);
%GM_SWAPROWS_MAT permutes the rows of A, i -> n-i+1

%
% Author G. Meurant
% February 2006
%

[n,m] = size(A);
B = zeros(n,m);

B(1:n,:) = A(n:-1:1,:);
