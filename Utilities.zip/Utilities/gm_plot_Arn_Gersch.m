function gm_plot_Arn_Gersch(z,rhoa,rhob,xmin,xmax,ymin,ymax);
%GM_PLOT_ARN_GERSCH region for the Arnoldi Ritz values
% from a Gerschgorin-like analysis

% Input:
% z, rhoa, rhob = variables from the moment matrices
% xmin, xmax, ymin, ymax = box for the vizualization

%
% Author G. Meurant
% Dec 2014
% Updated Sept 2015
%

R = real(z);
I = imag(z);

gm_myezplot_simpler(@(x,y)funcg(x,y,R,I,rhoa,rhob),[xmin,xmax,ymin,ymax],'b')

end

function f=funcg(x,y,R,I,rhoa,rhob);

f = sqrt(((R - x).^2 + (I - y).^2)) - rhob * sqrt(x.^2 + y.^2) - rhoa;

end

