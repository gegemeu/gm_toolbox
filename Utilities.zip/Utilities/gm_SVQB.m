function [Q,B,QQ,R]=gm_SVQB(V);
%GM_SVQB factorization of a tall and skinny matrix V = Q B

% Method of Stathopoulos and Wu using the eigenpairs of the Gram matrix
% SISC v 23 n 6 (2002) pp. 2165-2182

% This works only if the matrix is not too ill conditioned.
% Otherwise the method has to be iterated

% Input:
% V = matrix
%
% Output:
% Q = nearly orthogonal matrix
% B = (full) matrix such that V = Q B
%  optional:
% QQ = nearly orthogonal matrix
% R = upper triangular matrix such that V = QQ R

%
% Author G. Meurant
% Oct 2015
%

% Gram matrix
S = V' * V;

Dm12 = diag(1 ./ sqrt(diag(S)));

% scaling of S
S = Dm12 * S * Dm12;

% Eigenpairs
[U,D] = eig(full(S));
d = diag(D);
% filter the smallest eigenvalues
maxd = max(d);
epsi = eps * maxd;
I = find(d < epsi);
d(I) = epsi;

Q = V * Dm12 * U * diag(1 ./ sqrt(d));

% this assumes that Q is "enough" orthogonal
B = Q' * V;

if nargout > 2
 [R,msg] = chol(B' * B);
 if msg > 0
  [n,m] = size(V);
  R = zeros(m,m);
  QQ = zeros(n,m);
  return
 end
 QQ = Q * (B / R);
end






