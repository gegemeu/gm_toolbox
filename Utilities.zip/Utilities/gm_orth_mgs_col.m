function [V,R,dotprod]=gm_orth_mgs_col(A,dreorth);
%GM_ORTH_MGS_COL (double) orthogonalisation of the columns of A
% Modified Gram-Schmidt by columns

% Input:
% A = matrix
% dreorth = 'dreorth' if we do a second orthogonalization
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = matrix such that A = V R
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

if nargin == 1
 dreorth = 'nodreorth';
end

dotprod = 0;

[m,n] = size(A);
V = zeros(m,n);
R = zeros(n,n);

% first orthogonalization

for k = 1:n
 v = A(:,k);
 for j = 1:k-1
  alpha = v' * V(:,j);
  R(j,k) = alpha;
  v = v - alpha * V(:,j);
 end % for j
 dotprod = dotprod + k - 1;
 
 if strcmpi(dreorth,'dreorth') == 1
  % second orthogonalization
  for j=1:k-1
   alpha = v' * V(:,j);
   R(j,k) = R(j,k) + alpha;
   v = v - alpha * V(:,j);
  end % for j
  dotprod = dotprod + k - 1;
 end % if
 
 nv = norm(v);
 dotprod = dotprod + 1;
 if nv <= 1e-15
  fprintf('\n gm_orth_mgs_col: Breakdown, step %d \n\n',k)
  return
 end
 
 V(:,k) = v / nv;
 R(k,k) = nv;
 
end % for k




