function AA=gm_make_full_rank(A);
%GM_MAKE_FULL_RANK changes the smallest singular values of A to make it full rank
% rank

% Input:
% A = matrix
% 
% Output:
% AA = new matrix

%
% Author G. Meurant
% Feb 2015
% Updated Sept 2015
%

[U,S,V] = svd(A);

normA = max(diag(S));

% this is the tolerance used by svd
tol = max(size(A)) * eps(normA);

s = diag(S);
I = find(s <= tol);
% Make the smallest entries larger than tol
% they could be modified less than that
s(I) = 2 * tol;

AA = U * diag(s) * V';


