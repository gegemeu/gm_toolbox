function yy = gm_spline_eval(xx,s,x);
%GM_SPLINE_EVAL evaluates a cubic spline

% Input:
% xx = points for evaluation
% s= spline coefficients
% x = spline points
%
% Output:
% yy = values of the spline at xx

%
% Author G. Meurant
% May 2024
%

nxx = length(xx);
yy = zeros(1,nxx);
n = size(s,1);

for k = 1:nxx
 % find the interval for xx(k)
 dif = x - xx(k);
 I = find(dif<=0);
 i = min(max(I),n);
 % this may not be the best way to evaluate the cubic
 yy(k) = s(i,1) * (xx(k) - x(i))^3 + s(i,2) * (xx(k) - x(i))^2 + s(i,3) * (xx(k) - x(i)) + s(i,4);
end % for k

