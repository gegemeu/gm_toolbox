function z=gm_leja_shift(a,b,n);
%GM_LEJA_SHIFT shifted Leja points on [a,b]

% Input:
% a,b, = end points of the interval
% n = number of points
%
% Output:
% z = Leja points

%
% Author G. Meurant
% May 2008
% Updated August 2015
%

% Leja points on [-2,2]

xleja = gm_leja_points(n);

% shift
lm = (b - a) / 4;
lp = (a + b) / 2;

z = lp + lm * xleja;

