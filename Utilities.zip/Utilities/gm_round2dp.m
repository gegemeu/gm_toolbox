function z = gm_round2dp(x,k);
%GM_ROUND2DP rounds number x to k decimal places

z = round(x / (10^-k)) * (10^-k);


