function [v,beta,P] = gm_house(x);
%GM_HOUSE Householder transformation to zero components 2 to n of x

% from Golub - Van Loan

% The result is x - beta (v' x) v

% Input:
% x = vector
%
% Output:
% v = vector defining the Householder transformation
% beta = scalar defining the Householder transformation
% P = I - beta v v', Householder transformation

%
% Author G. Meurant
% Updated Sept 2015
%

n = length(x);

sig = x(2:n)' * x(2:n);
v = [1; x(2:n)];

if sig == 0
 beta = 0;
else
 mu = sqrt(x(1)^2 + sig);
 if x(1) <= 0
  v(1) = x(1) - mu;
 else
  v(1)=-sig/(x(1) + mu);
 end
 beta = 2 * v(1)^2 / (sig + v(1)^2);
 v = v / v(1);
end

if nargout == 3
 P = speye(n,n) - beta * v * v';
end




