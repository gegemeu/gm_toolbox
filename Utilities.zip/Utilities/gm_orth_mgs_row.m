function [V,R,dotprod] = gm_orth_mgs_row(A);
%GM_ORTH_MGS_ROW orthogonalisation of the columns of A, modified Gram-Schmidt by rows

% Input:
% A = matrix
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = upper triangular matrix such that A = V R
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

dotprod = 0;

[m,n] = size(A);
V = A;
R = zeros(n,n);

%  orthogonalization

for k = 1:n
 nu = norm(V(:,k));
 dotprod = dotprod + 1;
 R(k,k) = nu;
 
 if nu <= 1e-15
  fprintf('\n gm_orth_mgs_row: Breakdown, step %d \n\n',k)
  return
 end
 
 V(:,k) = V(:,k) / nu;
 R(k,k+1:n) = V(:,k)' * V(:,k+1:n);
 dotprod = dotprod + n - k;
 V(:,k+1:n) = V(:,k+1:n) - V(:,k) * R(k,k+1:n);
 
end % for k





