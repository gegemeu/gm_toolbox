function [U,S,V] = gm_svd_companion(C);
%GM_SVD_COMPANION SVD of a companion matrix C

% 
% Author G. Meurant
% November 2023
%

n = size(C,1);
a = -C(:,n);
a0 = a(1);
ah = a(2:n);

U = zeros(n,n);
V = zeros(n,n);
S = eye(n,n);

a1  = norm(a)^2 + 1;
del = sqrt(a1^2 - 4 * abs(a0)^2);

sp = sqrt(a1 + del) / sqrt(2);
sm = sqrt(a1 - del) / sqrt(2);
S(1,1) = sp;
S(n,n) = sm;

gammap = 1 / sqrt(norm(ah)^2/(1 - sp^2)^2 + 1);
vp = gammap * [ah / (1 - sp^2); 1];
gammam = 1 / sqrt(norm(ah)^2/(1 - sm^2)^2 + 1);
vm = gammam * [ah / (1 - sm^2); 1];
V(:,1) = -vp;
V(:,n) = vm;

deltap = 1 / sqrt((norm(ah)^2 * sp^4) / (abs(a(1))^2 * (1 - sp^2)^2) + 1);
up = deltap * [1; (sp^2 / (a(1) * (sp^2 - 1))) * ah];
deltam = 1 / sqrt((norm(ah)^2 * sm^4) / (abs(a(1))^2 * (1 - sm^2)^2) + 1);
um = deltam * [1; (sm^2 / (a(1) * (sm^2 - 1))) * ah];
U(:,1) = up;
U(:,n) = -um;

AO = null(ah'); % orthogonal complement
V(:,2:n-1) = [AO; zeros(1,n-2)];
U(:,2:n-1) = [zeros(1,n-2); AO];






