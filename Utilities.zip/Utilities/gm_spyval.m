function gm_spyval(S,arg2,arg3);
%GM_SPYVAL visualize sparsity pattern of S with colors

%   GM_SPYVAL(S) plots the sparsity pattern of the matrix S
%
%   GM_SPYVAL(S,'LineSpec') uses the color and marker from the line
%   specification string 'LineSpec' (See PLOT for possibilities)
%
%   GM_SPYVAL(S,markersize) uses the specified marker size instead of
%   a size which depends upon the figure size and the matrix order
%
%   GM_SPYVAL(S,'LineSpec',markersize) sets both

%   GM_SPYVAL(S,markersize,'LineSpec') also works


if size(S,1) == 1 && size(S,2) == 1
 return
end

cax = newplot;
next = lower(get(cax,'NextPlot'));
hold_state = ishold;

marker = '';
color = '';
markersize = 0;
linestyle = 'none';

if nargin >= 2
 if ischar(arg2)
  [line,color,marker,msg] = colstyle(arg2); error(msg)
 else
  markersize = arg2;
 end
 
end
if nargin >= 3
 if ischar(arg3)
  [line,color,marker,msg] = colstyle(arg3); error(msg)
 else
  markersize = arg3;
 end
end

if isempty(marker), marker = '.'; end

[m,n] = size(S);
if marker~='.' && markersize==0
 markersize = get(gcf,'defaultlinemarkersize');
end

if markersize == 0
 units = get(gca,'units');
 set(gca,'units','points');
 pos = get(gca,'position');
 markersize = max(4,min(14,round(6*min(pos(3:4))/max(m+1,n+1))));
 set(gca,'units',units);
end

if isempty(color)
 [i,j,v] = find(abs(S));
 if isempty(i)
  i = NaN;
  j = NaN;
 end
 
 if isempty(S)
  facecolor = 'none';
 else
  facecolor='flat';
 end

 patch(j',i',v','FaceColor','none','EdgeColor',facecolor, ...
  'Marker', marker, 'MarkerSize', markersize, ...
  'linestyle',linestyle);
 colorbar;
else
 [i,j] = find(S);
 if isempty(i), i = NaN; j = NaN; end
 if isempty(S), marker = 'none'; end
 plot(j,i,'marker',marker,'markersize',markersize, ...
  'linestyle',linestyle,'color',color);
end

xlabel(['nz = ' int2str(nnz(S))]);
set(gca,'xlim',[0 n+1],'ylim',[0 m+1],'ydir','reverse','plotboxaspectratio',[n+1 m+1 1]);
set(gcf,'renderer','painters')

if ~hold_state
 set(cax,'NextPlot',next);
end

