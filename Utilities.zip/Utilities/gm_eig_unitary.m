function eigu = gm_eig_unitary(n);
%GM_EIG_UNITARY generation of n random points on the unit circle

% 
% Author G. Meurant
% December 2023
%

rng('default')

m = floor(n/2);

ii = sqrt(-1);
a = 0;
b = 2 * pi;
r = (b-a).*rand(m,1) + a;

eigu = [exp(ii * r); exp(-ii * r)];

if 2 * m ~= n
 eigu(n) = 1;
end



