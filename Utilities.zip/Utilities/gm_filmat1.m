function B=gm_filmat1(A,alp);
%GM_FILMAT1 filters the matrix A 
% zero the entries s.t. |A(i,j)| <= alp
% absolute criteria
%

%
% Author G. Meurant
%

n = size(A,1);
B = sparse(n,n);

for i =1:n
 ind = find(abs(A(i,:)) >= alp);
 B(i,ind) = A(i,ind);
end



