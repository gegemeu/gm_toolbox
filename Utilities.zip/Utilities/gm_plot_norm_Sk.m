function [nS,estS]=gm_plot_norm_Sk(V);
%GM_PLOT_NORM_SK norm of S_k from Paige and its estimate with INE

% Input:
% V = set of unit norm vectors
%
% Output:
% nS = norm of S_k
% estS = estimate of norm of S_k

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

kmax = size(V,2);
nS = zeros(1,kmax);
estS = zeros(1,kmax);

for k = 1:kmax
 S = gm_Paige_S(V,k);
 nS(k) = norm(S);
 estS(k) = gm_smax_estR(S);
end

plot(nS)
hold on
plot(estS,'r-x')
title('||S_k|| and its INE estimate')
hold off

figure
semilogy(abs(nS - estS))
title('difference between ||S_k|| and its INE estimate')




