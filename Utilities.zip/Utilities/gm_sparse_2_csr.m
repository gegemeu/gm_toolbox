function [rowp,colind,valA] = gm_sparse_2_csr(A);
%GM_SPARSE_2_CSR Convert a sparse matrix into compressed row storage arrays

% Input:
% A = sparse matrix
%
% Output:
% rowp = pointer to the first entries of rows
% colind = column indices
% valA = values A(i,j) if nargout = 3

%
% Author G. Meurant
% December 2024
%

indA = nargout > 2;
n = size(A,1);
nz = nnz(A);
if indA
 [nzi,nzj,nzv] = find(A);
else
 [nzi,nzj] = find(A);
end % if
colind = zeros(1,nz);
if indA
 valA = zeros(1,nz);
end % if
rowp = zeros(1,n+1);
for i = 1:nz
 rowp(nzi(i)+1) = rowp(nzi(i)+1) + 1;
end % for i
rowp = cumsum(rowp);
for i = 1:nz
 colind(rowp(nzi(i))+1) = nzj(i);
 rowp(nzi(i)) = rowp(nzi(i))+1;
end % for i
if indA
 for i = 1:nz
  valA(rowp(nzi(i))+1) = nzv(i);
 end % for i
end % if
for i = n:-1:1
 rowp(i+1) = rowp(i);
end % for i
rowp(1) = 0;
rowp = rowp + 1;

