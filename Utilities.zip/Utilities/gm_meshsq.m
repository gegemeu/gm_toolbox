function [x,y] = gm_meshsq(m);
%GM_MESHSQ coordinates of an m x m mesh of the unit square

%
% Author G. Meurant
% August 2000
% Updated April 2015
%

% mesh size
h = 1 / (m+1);

n = m^2;
xx = [h:h:1-h];

for i = 1:m:n
 x(i:i+m-1) = xx;
end

for i = 1:m
 y(i:m:n) = xx;
end
   
 