function [u,v,Ti]=gm_tridiag_inv(alpha,beta);
%GM_TRIDIAG_INV inverse of a real symmetric tridiagonal matrix
%

% formulas from G.H. Golub and G. Meurant
% Matrices, moments and quadrature with applications
% Princeton University Press, 2010

% The inverse is
% | u_1 v_1, u_1 v_2, ... u_1 v_n |
% | u_1 v_2, u_2 v_2, ... u_2 v_n |
% |    .       .      ...    .    |
% |    .       .      ...    .    |
% | u_1 v_n, u_2 v_n, ... u_n v_n |

% Input:
% alpha (length n) = vector of diagonal coefficients
% beta (length n-1) = vector of lower and upper diagonal coefficients
%
% Ouput:
% u, v = vectors defining the inverse
% Ti (optional) = matrix inverse
%

%
% Author G. Meurant
% June 2016
%

n = length(alpha);
m = length(beta);
if m < n-1
 error('gm_tridiag_inv: The vector beta is too short')
end

u = zeros(n,1);
v = zeros(n,1);
Ti = [];

del = zeros(n,1);
d = zeros(n,1);

% Cholesky factorizations
% top-down
del(1) = alpha(1);
for k = 2:n
 del(k) = alpha(k) - beta(k-1)^2 / del(k-1);
end
% bottom-up
d(k) = alpha(k);
for k = n-1:-1:1
 d(k) = alpha(k) - beta(k)^2 / d(k+1);
end

v(1) = 1 / d(1);
for k = 2:n
 v(k) = (-1)^(k-1) * prod(beta(1:k-1)) / prod(d(1:k));
end
u(n) = 1 / (del(n) * v(n));
for k = 1:n-1
 u(n-k) = (-1)^k * prod(beta(n-k:n-1)) / (prod(del(n-k:n)) * v(n));
end

if nargout < 3
 return
end

% Matrix inverse

Ti = zeros(n,n);

for i = 1:n-1
 for j = i+1:n
  Ti(i,j) = (-1)^(j-i) * prod(beta(i:j-1)) * prod(d(j+1:n)) / prod(del(i:n));
 end
end
%symmetrize
Ti = Ti + Ti';
% diagonal entries
for i = 1:n
 Ti(i,i) = prod(d(i+1:n)) / prod(del(i:n));
end

