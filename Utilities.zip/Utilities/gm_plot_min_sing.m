function msig=gm_plot_min_sing(V);
%GM_PLOT_MIN_SING minimum singular values of V(:,1:k)

% This can be used to see how a basis is loosing linear independence

% Input:
% V = matrix
%
% Output:
% msig = minimum singular values

%
% Author G. Meurant
% March 2015
% Updated Sept 2015
%

m = size(V,2);
msig = zeros(1,m);

for k = 1:m
 msig(k) = min(svd(V(:,1:k)));
end

semilogy(msig)
title('Min singular values of V_k')
