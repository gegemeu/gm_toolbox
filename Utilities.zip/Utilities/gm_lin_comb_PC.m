function [info,lamb,dB,k,nr] = gm_lin_comb_PC(Ak,nitmax);
%GM_LIN_COMB_PC PC algorithm for finding a positive definite linear combination of symmetric matrices A_1, ..., A_k

% Input:
% Ak = three-dimensional array, A_i = Ak(i,:,:), A_i symmetric
% nitmax = maximum number of iterations
%
% Output:
% info = 0 if we fail, = 1 if we find a positive definite linear
%        combination, = -1  if we find a negative definite linear
%        combination
% lamb = coefficients of the linear combination
% dB = eiegenvalues of the linear combination
% k = number of iterations
% nr = smallest eigenvalues at each iteration

%
% Author G. Meurant
% February 2011
% Updated September 2015
%

% initialization

A1 = Ak(:,:,1);
p = size(Ak,3);
n = size(A1);
info = 0;
Au = zeros(p,1);
nr = zeros(1,nitmax);

% starting coefficients
lamb = ones(p,1);
lamb = lamb / norm(lamb);

% iterations

for k = 1:nitmax
 % linear combination
 B = lamb(1) * A1;
 for j = 2:p
  Akj = full(Ak(:,:,j));
  B = B + lamb(j) * Akj;
 end % for j
 
 if k == 1
  % transform the initial B and lamb
  dB = real(eig(B));
  I = find(dB > 0);
  cpos = length(I);
  cneg = n - cpos;
  mu = min(abs(dB));
  if cneg > cpos
   B = -B / mu;
   lamb = - lamb / mu;
  else
   B = B / mu;
   lamb = lamb / mu;
  end % if cneg
 end % if k = 1
 
 % smallest eigenvalue of B
 [XB,DB] = eig(B);
 dB = real(diag(DB));
 [lambB,I] = min(dB);
 if lambB > 0
  % we have found a positive definite combination
  info = 1;
  nr(k) = lambB;
  return
 end % if
 lambmax = max(dB);
 if lambmax < 0
  % we have found a negative definite combination
  info = -1;
  return
 end
 % eigenvector
 u = XB(:,I(1));
 for j = 1:p
  Au(j) = u' * Ak(:,:,j) * u;
 end % for j
 nlamb = norm(Au);
 dlamb = Au / nlamb;
 lamb = lamb + dlamb;
 nr(k) = lambB;
end % for k



