function gm_set_rounding_mode(mode);
%GM_SET_OUNDING_MODE sets the rounding mode

%
% Author G. Meurant
% May 2023

if strcmpi(mode,'nearest') == 1 || strcmpi(mode,'n') == 1
 feature('setround',0.5);
 return
end % if

if strcmpi(mode,'Inf') == 1 || strcmpi(mode,'u') == 1
 feature('setround',Inf);
 return
end % if

if strcmpi(mode,'-Inf') == 1 || strcmpi(mode,'d') == 1
 feature('setround',-Inf);
 return
end % if

if strcmpi(mode,'0') == 1 || strcmpi(mode,'z') == 1
 feature('setround',0);
 return
end % if

error('gm_set_rounding_mode: This rounding mode does not exist')

