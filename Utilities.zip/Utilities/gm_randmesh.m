function [x,y] = gm_randmesh(m);
%GM_RANDMESH m^2 random points in the unit square

%
% Author G. Meurant
% 2000
%

rng('default')

x = rand(1,m);
y = rand(1,m);

 