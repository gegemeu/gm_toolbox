function [x,y]=gm_randmesh(m);
%GM_RANDMESH m^2 random points in the unit square

%
% Author G. Meurant, 2000
%

% Caution: This is deprecated
rand('state',0);

x = rand(1,m);
y = rand(1,m);

 