function [Q,R]=gm_add_row_QR(Q,R,k,w);
%GM_ADD_ROW_QR update QR decomposition when adding a row

%   [Q,R]=gm_add_row_QR(Q,R,k,w); Given [Q,R]=qr(A),computes the QR
%   decomposition for [A(1,:);A(2,:), ...,A(k-1,:);w;A(k,:),...A(n,:)]

% from Gander and Gander book
    
[p,n] = size(R);
m = size(Q,1);                 % Q is (m x p)
% add row and column to Q and permute
Q = [Q(1:k-1,:), zeros(k-1,1); zeros(1,p), 1; Q(k:m,:), zeros(m-k+1,1)];
R = [R; w];                                   % augment R
k = p + 1;
for j = 1:min(n,p)
  G = planerot(R(j:k-j:k,j));         
  R(j:k-j:k,j:n) = G * R(j:k-j:k,j:n);          % annihilate w
  Q(:,j:k-j:k) = Q(:,j:k-j:k) * G';             % update Q
end