function Z = gm_last_comp_squared_vp(Tvp);
%GM_LAST_COMP_SQUARED_VP last components of the eigenvectors of T_k

% extended precision

%
% Author G. Meurant
% September 2019
%

n = size(Tvp,1);
Z = zeros(n,n);

for k = 1:n
 [Q,D] = eig(full(Tvp(1:k,1:k)));
 Z(k,1:k) = double(Q(k,1:k).^2);
end % for k

semilogy(Z(:,1))
hold on
for k = 2:30
 semilogy([k:n],Z(k:n,k))
end % for k

hold off

