function H=gm_Hessp(A);
%GM_HESSP Hessenberg form with a positive subdiagonal

% Input:
% A = matrix
%
% Output:
% H = upper Hessenberg matrix

%
% Author G. Meurant
% June 2012
% Updated Sept 2015
%

HH = hess(A);

n = size(A,1);
S = sparse(n,n);

S(1,1) = 1;
for i = 2:n
 if S(i-1,i-1) * HH(i,i-1) < 0
  S(i,i) = -1;
 else
  S(i,i) = 1;
 end
end

% make the subdiagonal positive
H = S * HH * S;


