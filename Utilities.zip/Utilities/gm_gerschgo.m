function [lmin,lmax] = gm_gerschgo(A);
%GM_GERSCHGO computes the Gerschgorin bounds for a symmetric matrix A

%
% Author G. Meurant
%

n = size(A,1);
un = ones(n,1);
AA = abs(A);
AA = spdiags(zeros(n,1),0,AA);
b = abs(diag(A));
bb = AA * un;

lmin = min(b - bb);
lmax = max(b + bb);
