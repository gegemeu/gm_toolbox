function alpha = gm_charpol_H(H);
%GM_CHARPOL_H characteristic polynomial of an upper Hessenber matrix

% H = unreduced upper Hessenberg matrix

% method of Misra, Quintana, and Van Dooren (1995)

% alpha = coefficients of the characteristic polynomial

%
% Author G. Meurant
% January 2024
%

n = size(H,1);
alpha = zeros(1,n+1);

F = [ [-1; zeros(n-1,1)] H(:,1:n-1)];
G = zeros(n,n);
for k = 1:n-1
 G(k,k+1) = 1;
end % for k
fn = H(:,n);
gn = zeros(n,1);
gn(n) = 1;

x = -F \ fn;
alpha(n+1) = x(1);
x = F \ (G * x + gn);
alpha(n) = x(1);

for k = 1:n-1
 x = F \ (G * x);
 alpha(n-k) = x(1);
end % for k

