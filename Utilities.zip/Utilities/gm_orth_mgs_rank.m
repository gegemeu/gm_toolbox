function [V,R,rk,pvt,dotprod]=gm_orth_mgs_rank(A,epsi);
%GM_ORTH_MGS_RANK  orthogonalisation of the columns of A with pivoting
% Rank-revealing modified Gram-Schmidt by columns

% Input:
% A = matrix
% epsi = threshold for column switch
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = matrix such that A = V R
% rk = rank of A
% pvt = pivots
% dotprod = number of dot products

%
% Author G.Meurant
% October 2015
%

dotprod = 0;

[m,n] = size(A);
V = A;
R = zeros(n,n);
normy = zeros(1,n);
pvt = zeros(1,n);

%  orthogonalization

for k = 1:n
 
 for j = k:n
  normy(j) = norm(V(:,j));
 end
 normy
 dotprod = dotprod + n - k + 1;
 if norm(normy(k:n)) <= epsi
  rk = k - 1;
  V = V(:,1:rk);
  R = R(1:rk,:);
  pvt = pvt(1:rk);
  return
 end
 
 % column pivoting
 [maxnormy,pvt(k)] = max(normy(k:n));
 pvt(k) = pvt(k) + k - 1;
 temp = V(:,k);
 V(:,k) = V(:,pvt(k));
 Q(:,pvt(k)) = temp;
 temp = R(1:k-1,k);
 R(1:k-1,k) = R(1:k-1,pvt(k));
 R(1:k-1,pvt(k)) = temp;
 
 nv = norm(V(:,k));
 dotprod = dotprod + 1;
 if nv <= 1e-15
  fprintf('\n gm_orth_mgs_rank: Breakdown, step %d \n\n',k)
  return
 end
 
 R(k,k) = nv;
 V(:,k) = V(:,k) / nv;
 R(k,k+1:n) = V(:,k)' * V(:,k+1:n);
 V(:,k+1:n) = V(:,k+1:n) - V(:,k) * R(k,k+1:n);
 
end % for k

rk = n;





