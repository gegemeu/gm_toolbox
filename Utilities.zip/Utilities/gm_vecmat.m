function v=gm_vecmat(A);
%GM_VECMAT vectorizes the matrix A

% Input:
% A = matrix
%
% Output:
% v = vector

%
% Author G. Meurant
% Feb 2011
% Updated Sept 2015
%

v = A(:);

