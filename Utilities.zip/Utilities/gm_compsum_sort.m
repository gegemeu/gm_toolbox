function [s,e]=gm_compsum_sort(x);
%GM_COMPSUM_SORT compensated summation of the elements of a vector x with a sort

% see Higham's book with sorting of the components

% Input:
% x = vector
%
% Output:
% s = sum
% e = rounding error
%

%
% Author G. Meurant
% April 2003, Sept 2016
%

x = x(:);

% sort the vector components

xpos = x(find(x>0));
xneg = x(find(x<0));
xpos = sort(xpos,'ascend');
xneg = sort(xneg,'descend');
x = [xneg; xpos];

s = 0;
e = 0;

for i = 1:length(x)
 temp = s;
 y = x(i) + e;
 s = temp + y;
 e =  (temp - s) + y;
end

s = s + e;



