function s = gm_setmcarre(k,lmin,lmax);
%GM_SETMCARRE computes the coefficients of the least squares polynomial of degree k

% using lmin and lmax estimates of the smallest and largest eigenvalues

%  
% Author G. Meurant
%

s = zeros(k+2,1);
mu0 = -(lmin + lmax) / (lmax - lmin);

s(1) = 1 / sqrt(pi);
s(2) = sqrt(2 / pi) * (lmin + lmax) / (lmin - lmax);
s(3) = sqrt(2 / pi) * ((2 * (lmin + lmax)^2 / (lmin - lmax)^2) - 1);

for j = 4:k+2
 s(j) = 2 * mu0 * s(j-1) - s(j-2);
end
