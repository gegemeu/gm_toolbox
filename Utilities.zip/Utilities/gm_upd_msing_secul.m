function [msing_new,msing_up,msing2,V,VV] = gm_upd_msing_secul(V,VV,v,msing);
%GM_UPD_MSING_SECUL update of the estimate of the minimum singular value using the secular equation

% Input:
% V = previous matrix 
% VV = V' V
% v = vector which is added to the matrix -> [V, v]
% msing = estimate of the minimum singular value of V
%
% Output:
% msing_new, V, VV = new values after the update

%
% Author G. Meurant
% March 2016
%

z = V' * v;

% value of f at 0
Az = VV \ z;
zAz = z' * Az;
f0 = 1 - zAz;
% value of the derivative at 0
f0p = -1 - z' * (VV \ Az);

msing = msing^2;

% rational approximation
s = (1 + f0p) * msing^2;
r = f0 - (1 + f0p) * msing;

% g = r - mu + s / (msing - mu)

% zero of the approximation
delta = (f0 - f0p * msing)^2 - 4 * f0 * msing;
if delta < 0
 fprintf('\n delta < 0, msing new is wrong! \n')
end
mu1 = (msing + r - sqrt(delta)) / 2;
if mu1 < 0
 fprintf('\n mu1 = %g < 0, msing new is wrong! \n',mu1)
end
% taking the real part is useful if the matrix V is complex
msing_new = real(sqrt(mu1));

mu3 = -f0 / f0p;
msing_up = real(sqrt(mu3));
msing2 = real(sqrt((mu1 + mu3) / 2));

VV = [VV z; z' 1];
V = [V v];





