function gm_cbarnpart(vp,vmin,vmax)
%GM_CBARNPART partial bar visualization of n sets of real data on the same scale for comparison
% in the window vmin,vmax
%

%
% Author G. Meurant
% july 2003
% updated April 2015
%

figure

hold on

n = size(vp,2);
ln = 2 / n;
yn = linspace(-1 + ln / 2,1 - ln / 2,n);
lmin = min(min(vp));
lmax = max(max(vp));
% del = (vmax - vmin) / 10;

for j = 1:n
 vpj = vp(find(vp(:,j)),j);
 m = length(vpj);
 y(1) = yn(n - j + 1) - ln / 4;
 y(2) = yn(n - j + 1) + ln / 4;
 for i = 1:m
  x(1) = vpj(i);
  x(2) = vpj(i);
  plot(x,y,'b')
 end % for i
end % for j

del = 0;
axis([vmin - del, vmax + del, -1, 1])

hold off
