function B = gm_rank_one_approx(A);
%GM_RANK_ONE_APPROX closest rank-one matrix

% Input:
% A = matrix
%
% Output:
% B = rank-one approximation

%
% Author G. Meurant
% February 2011
% Updated September 2015
%

% SVD of A

[U,S,V] = svd(full(A));

s = diag(S);
ns = length(s);
s = s(1) * eye(ns,1);
SR = diag(s);

B = U * SR * V';

