function dd = gm_is_diag_dom(A);
%GM_IS_DIAG_DOM answers the question: is A row diagonally dominant?

% Input:
% A = matrix
%
% Output:
% dd = 1, yes
% dd = 0, no

%
% Author G. Meurant
% Sept 2012
% Updated Sept 2015
%

n = size(A,1);

AMD = abs(A - diag(diag(A)));

DD = abs(diag(A));

dd = 1;

e = ones(n,1);
x = AMD * e;

if any(DD < x)
 dd = 0;
end


