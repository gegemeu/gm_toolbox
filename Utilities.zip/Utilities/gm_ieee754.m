function [s,e,f,val]=gm_ieee754(x,fmt)
%GM_IEEE754 decompose a double precision floating point number

% [S,E,F] = GM_IEEE754(X) returns the sign bit, exponent, and mantissa of an
% IEEE 754 floating point value X, expressed as binary digit strings of
% length 1, 11, and 52, respectively.

% from a code by Toby Driscoll 

if ~isreal(x) || numel(x) > 1 || ~isa(x,'double')
 error('gm_ieee754: real, scalar, double input required.')
end
hex = num2hex(x);               % string of 16 hex digits for x
dec = hex2dec(hex');            % decimal for each digit (1 per row)
bin = dec2bin(dec,4);           % 4 binary digits per row
bitstr = reshape(bin',[1 64]);  % string of 64 bits in order

val = 0;
if nargout < 2
 s = bitstr;
else
 s = bitstr(1);
 e = bitstr(2:12);
 f = bitstr(13:64);
 if nargin > 1 && isequal(lower(fmt),'dec')
  s = bin2dec(s);  
  e = bin2dec(e) - 1023;
  
  for k = 1:length(f)
   st = f(k);
   if strcmpi(st,'0') == 1
    bina(k) = 0;
   else
    bina(k) = 1;
   end % if
  end % for k
  f = f_d_bin2frac(bina);
  val = (1 + f) * 2^e;
  
 end % if nargin
end % if nargout

