function terms=gm_one_over_x_plus_h(x,h,n);
%GM_ONE_OVER_X_PLUS_H Taylor expansion of 1 / (x + h)

%
% Author G. Meurant
% Sept 2019
%

terms = zeros(1,n);
for k = 1:n
 terms(k) = (-1)^(k-1) * h^(k-1) / x^k;
end % for 

