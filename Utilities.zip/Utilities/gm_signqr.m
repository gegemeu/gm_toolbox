function [Q,R] = gm_signqr(A);
%GM_SIGNQR changes signs by putting positive entries on the diagonal of the QR factorization

% Input:
% A = matrix
%
% Output:
% Q, R = QR factorization of A with positive diagonal entries for R, A = QR

%
% author G. Meurant
% November 2009
% Updated September 2015
%

[Q,R] = qr(A,0);

S = diag(sign(diag(R)));

R = S * R;

Q = Q * S;


