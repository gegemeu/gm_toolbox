function [s,e,f,val]=gm_ieee754s(x,fmt)
%GM_IEEE754S decompose a single precision floating point number

% [S,E,F] = IEEE754(X) returns the sign bit, exponent, and mantissa of an
% IEEE 754 floating point value X, expressed as binary digit strings of
% length 1, 11, and 52, respectively


% from a code by Toby Driscoll 

if ~isreal(x) || numel(x) > 1 || ~isa(x,'single')
 error('gm_ieee754s: real, scalar, double input required.')
end
hex = num2hex(x);               % string of 16 hex digits for x
dec = hex2dec(hex');            % decimal for each digit (1 per row)
bin = dec2bin(dec,4);           % 4 binary digits per row
bitstr = reshape(bin',[1 32]);  % string of 32 bits in order

val = 0;
if nargout < 2
 s = bitstr;
else
 s = bitstr(1);
 e = bitstr(2:9);
 f = bitstr(10:32);
 if nargin > 1 && isequal(lower(fmt),'dec')
  s = bin2dec(s);  
  e = bin2dec(e)-127;

  for k = 1:length(f)
   st = f(k);
   if strcmpi(st,'0') == 1
    bina(k) = 0;
   else
    bina(k) = 1;
   end % if
  end % for k
  f = f_d_bin2frac(bina);
  val = (1 + f) * 2^e;
  val = single(val);
  f = single(f);
  
 end % if nargin
end % if nargout

