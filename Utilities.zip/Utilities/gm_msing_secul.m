function [msing,msing_up,msing2,VV]=gm_msing_secul(V);
%GM_MSING_SECUL estimates of the minimum singular values of V_k
% using the secular equation

% Input:
% V = matrix
%
% Output:
% msing = vector of the estimates 
% VV = V' V

% 
% Author G. Meurant
% March 2016
%

n = size(V,2);
msing = zeros(1,n);
msing_up = zeros(1,n);
msing2 = zeros(1,n);

% initialization
v = V(:,1);
msig = norm(v);
msing(1) = msig;
msing_up(1) = msig;
msing2(1) = msig;
msig_up = msig;
msig2 = msig;
VV = 1;
V_new = v;

for k = 2:n
 [msig,msig_up,msig2,V_new,VV] = gm_upd_msing_secul(V_new,VV,V(:,k),msig);
 msing(k) = msig;
 msing_up(k) = msig_up;
 msing2(k) = msig2;
end



