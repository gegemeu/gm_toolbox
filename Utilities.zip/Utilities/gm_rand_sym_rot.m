function A=gm_rand_sym_rot(n,theta);
%GM_RAND_SYM_ROT generates a rotated random symmetric matrix

% Input:
% n = order of A
% theta = angle
%
% Output:
% A = random symmetric matrix

% 
% Author G. Meurant
% November 2009
% Updated Sept 2015
%

theta = pi * theta / 180;

R = triu(randn(n,n));
RR = triu(R,1);

A = R + RR';

ii = sqrt(-1);

A = exp(-ii * theta) * A;



