function [S,Q,Q11,Q12,Q21,Q22] = gm_Paige_S(V,k);
%GM_PAIGE_S computes the augmented unitary matrix exhibited by Paige

% Input:
% V = set of unit norm vectors
% k = number of columns to be considered
%
% Output:
% S = Paige's matrix
% Q = (k + n) matrix

%
% Author G. Meurant
% March 2015
% updated March 2023
%

[n,m] = size(V);
if k > m
 error('gm_Paige_S: k is too large')
end

Vk = V(:,1:k);
U = triu(Vk' * Vk,1);
S = (eye(k,k) + U) \ U;

Q11 = S;
Q12 = (eye(k,k) - S) * Vk';
Q21 = Vk * (eye(k,k) - S);
Q22 = eye(n,n) - Vk * (eye(k,k) - S) * Vk';
Q = [Q11, Q12; Q21, Q22];


