function S=gm_Paige_S(V,k);
%GM_PAIGE_S computes the augmented unitary matrix exhibited by Paige

% Input:
% V = set of unit norm vectors
% k = number of columns to be considered
%
% Output:
% S = Paige's matrix

%
% Author G. Meurant
% March 2015
%

n = size(V,2);
if k > n
 error('gm_Paige_S: k is too large')
end

Vk = V(:,1:k);
U = triu(Vk' * Vk,1);
S = (eye(k,k) + U) \ U;

