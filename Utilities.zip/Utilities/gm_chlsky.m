function  [flag,s,niter]=gm_chlsky(flag,A,B,u,v,niter,limit);
%GM_CHLSKY Auxiliary function for Crawford-Moon algorithm

%
% Author G. Meurant
% Jan 2011
% Updated Sept 2015
%

pd = 0;
npd = -1;
uabort = 1;

n = size(A,1);
y = zeros(n,1);

if niter > limit
 flag = uabort;
 s = [0 0];
 return
end

niter = niter + 1;

% save u and v for intermediate print-out

u1 = u;
v1 = v;

% set up the linear combination matrix u*A + v*B

C = u * A + v * B;

% attempt a cholesky factorization

[R,p] = chol(C);

kdp = p - 1;

if p ~= 0
 if kdp > 0
  % the kpd-by-kpd principal minor is positive definite,
  % and its Cholesky factor has been computed
  %  move c(1:kpd,kpd+1) into x(1:kpd)
  
  x = C(1:kdp,kdp+1);
  
  % solve the kpd x kpd triangular system.  The solution cannot
  % fail using the submatrix left by chol
  
  q = R' \ x;
  
  y(1:kdp) = q;
 end
 
 y(kdp+1) = -1;
 y(kdp+2:n) = 0;
 y = y / norm(y);
 
 u = y' * A * y;
 v = y' * B * y;
end

if p == 0
 % C is positive definite
 flag = pd;
else
 % Cholesky failed; u and v have been recomputed
 flag = npd;
end

s = [u v];
