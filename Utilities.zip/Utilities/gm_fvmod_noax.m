function [x1,x2,y1,y2]=gm_fvmod_noax(B,npow,thmax,noplot);
%GM_FVMOD_NOAX field of values (or numerical range) of B and powers

% without calling axes

%       Modification only the fv of B
%       FV(A, NK, THMAX) evaluates and plots the field of values of the
%       NK largest leading principal submatrices of A, using THMAX
%       equally spaced angles in the complex plane.
%       The defaults are NK = 1 and THMAX = 16.
%       (For a `publication quality' picture, set THMAX higher, say 32.)
%       The eigenvalues of A are displayed as `x'.
%       Alternative usage: [F, E] = FV(A, NK, THMAX, 1) suppresses the
%       plot and returns the field of values plot data in F, with A's
%       eigenvalues in E.   Note that NORM(F,INF) approximates the
%       numerical radius,
%                 max {abs(z): z is in the field of values of A}.

%       Theory:
%       Field of values FV(A) = set of all Rayleigh quotients. FV(A) is a
%       convex set containing the eigenvalues of A.  When A is normal FV(A) is
%       the convex hull of the eigenvalues of A (but not vice versa).
%               z = x'Ax/(x'x),  z' = x'A'x/(x'x)
%               => REAL(z) = x'Hx/(x'x),   H = (A+A')/2
%       so      MIN(EIG(H)) <= REAL(z) <= MAX(EIG(H)),
%       with equality for x = corresponding eigenvectors of H.  For these x,
%       RQ(A,x) is on the boundary of FV(A).
%
%       Based on an original routine by A. Ruhe.
%
%       References:
%       R. A. Horn and C. R. Johnson, Topics in Matrix Analysis, Cambridge
%            University Press, 1991; sec. 1.5.
%       A. S. Householder, The Theory of Matrices in Numerical Analysis,
%            Blaisdell, New York, 1964; sec. 3.3.
%       C. R. Johnson, Numerical determination of the field of values of a
%            general complex matrix, SIAM J. Numer. Anal., 15 (1978),
%            pp. 595-602.
% no axes
%
%
% Modified by G. Meurant
% October 2013
% Updated Sept 2015
%

x1 = 0; x2 = 0; y1 = 0; y2 = 0;
nk = 1;
if nargin == 1
 npow=1;
end
if nargin < 3 || isempty(thmax), thmax = 16; end
thmax = 32;

thmax = thmax - 1;  % Because code below uses thmax + 1 angles.

iu = sqrt(-1);
[n, p] = size(B);
if n ~= p, error('Matrix must be square.'), end
f = [];
z = zeros(2*thmax+1,1);
e = eig(full(B));

% Filter out cases where B is Hermitian or skew-Hermitian, for efficiency.
if isequal(B,B')
 
 f = [min(e) max(e)];
 
elseif isequal(B,-B')
 
 e = imag(e);
 f = [min(e) max(e)];
 e = iu*e; f = iu*f;
 
else
 
 axx=[0 0 0 0];
 
 for m = 1:npow
  
  f=[];
  ns = n;
  A = B^m;
  
  for i = 0:thmax
   th = i/thmax*pi;
   Ath = exp(iu*th)*A;               % Rotate A through angle th.
   H = 0.5*(Ath + Ath');             % Hermitian part of rotated A.
   [X, D] = eig(full(H));
   [lmbh, k] = sort(real(diag(D)));
   z(1+i) = rq(A,X(:,k(1)));         % RQ's of A corr. to eigenvalues of H
   z(1+i+thmax) = rq(A,X(:,k(ns)));  % with smallest/largest real part.
  end
  
  f = [f; z];
  
  % Next line ensures boundary is `joined up' (needed for orthogonal matrices).
  f = [f; f(1,:)];
  
  
  if thmax == 0; f = e; end
  
  if nargin < 4
   
   km=rem(m,5)+1;
   switch km
    case{1}
     col='c';
    case{2}
     col='b';
    case{3}
     col='r';
    case{4}
     col='g';
    case{5}
     col='m';
    otherwise
     col='k';
   end
   %       ax = cpltaxes(f);
   %       x1=min(ax(1),axx(1));
   %       x2=max(ax(2),axx(2));
   %       y1=min(ax(3),axx(3));
   %       y2=max(ax(4),axx(4));
   
   x1 = min(real(f)); x2 = max(real(f));
   y1 = min(imag(f)); y2 = max(imag(f));
   
   
   axx=[x1 x2 y1 y2];
   plot(real(f), imag(f),'r')      % Plot the field of values
   %       axis(axx);
   %       axis('square');
   hold on
   
   e=eig(full(A));
   plot(real(e), imag(e), 'ro')    % Plot the eigenvalues too.
   
  end
 end
  
end

function z = rq(A,x)
%RQ      Rayleigh quotient.
%        RQ(A,x) is the Rayleigh quotient of A and x, x'*A*x/(x'*x).

z = x'*A*x/(x'*x);
